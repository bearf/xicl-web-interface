#include <stdio.h>
#include <conio.h>

int main()
{
	int i, n=0, k=0, m=0, z=0, x=0;
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	scanf("%d %d",&n,&k);
	if (n==1) {printf("0");return 0;}
	for(i=k;i<=n;i+=k)
	{
		m++;
		z=i/k;
		while((z%k)==0 && z>0)
		{
			z/=k;
			m++;
		}
	}
	
	x=m/k;

	printf("%d",x);
	return 0;
}
