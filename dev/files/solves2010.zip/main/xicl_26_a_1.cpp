#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

ifstream cin("input.txt");
ofstream cout("output.txt");

#define len(v) (int)(v).size()
#define vi vector<int>
#define vvi vector<vi >

#define int unsigned __int64


__int32 main()
{
	int n, m, a, b, c;
	cin >> n >> m >> a >> b >> c;
	if(a < c)
		swap(a,c);
	int res = 0;
	for(int i = a+2; i <= n; i++)
		for(int j = b+2; j <= m; j++)
		{
			int k = (j-2LL) * (j-b-1LL) * (i-a-1LL) * (i-c-1LL);
			res += k*(n-i+1LL) * (m-j+1LL);			
		}
	cout << res;
}
			