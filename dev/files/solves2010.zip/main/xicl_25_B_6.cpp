#include <iostream>
#include <vector>

using namespace std;

long long w[200][200],fl[200][200];
long long  v[200],n,x,y,m,f=0,kol=0,dir,len=0;
vector<long long> mas,res[50000];

void dfs(long long z)
{
	if (z==y)
	{
		long long j;
		if (mas.size()==1)
		{
			if (fl[x][y]==dir && fl[x][y]>0) 
			{
				res[kol].push_back(x);
				res[kol].push_back(y);
				kol++;
			}
		} else
		{
			if (len==fl[x][y])
			{
			res[kol].push_back(x);
			for (j=0;j<mas.size();j++)
				res[kol].push_back(mas[j]);
			//cout<<endl;
			kol++;
			}
		}
	} else
	{
		long long j;
		for (j=1;j<=n;j++)
			if (/*v[j]==1 && */w[z][j]>0)
			{
				long long q;
				len=len+w[z][j];
				mas.push_back(j);
				v[j]=0;
				q=w[z][j];
				w[z][j]=0;
				dfs(j);
				v[j]=1;
				mas.pop_back();
				len=len-q;
			}
	}
}

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long i,j,k,a,b,cost;
	cin>>n>>m>>x>>y;
	if (n==1) 
	{
		cout<<0;
		return 0;
	}
	for (i=0;i<m;i++)
	{
		cin>>a>>b>>cost;
		w[a][b]=cost;
		fl[a][b]=cost;
	}
	for (i=1;i<=n;i++)
	  for (k=1;k<=n;k++)
		  for (j=1;j<=n;j++)
			  if (k!=j && fl[k][i] && fl[i][j] && (fl[k][j]==0 || fl[k][j]>fl[k][i]+fl[i][j]))
				  fl[k][j]=fl[k][i]+fl[i][j];
	/*for (i=1;i<=n;i++)
	{
		for (k=1;k<=n;k++)
			cout<<fl[i][k]<<" ";
		cout<<endl;
	}*/
	for (i=1;i<=n;i++)
		if (fl[x][i]+fl[i][y]==fl[x][y]) v[i]=1;
	/*if (w[x][y]==fl[x][y]) 
	{
		cout<<"2"<<" "<<x<<" "<<y;
		f=1;
	}*/
	v[y]=1;
	dir=w[x][y];
	v[x]=0;
	dfs(x);
	cout<<kol<<endl;
	for (i=0;i<kol;i++)
	{
		cout<<res[i].size()<<" ";
		for (j=0;j<res[i].size();j++)
			cout<<res[i][j]<<" ";
		cout<<endl;
	}
	return 0;
}