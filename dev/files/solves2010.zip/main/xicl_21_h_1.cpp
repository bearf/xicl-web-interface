#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

struct point {
	double x, y;
	point(double x = 0, double y = 0) : x(x), y(y) {
	}
};

const int L = 128;
const int N = 100;

int dx[L], dy[L];
char cw[L], ccw[L];

point w[L][2];

typedef bool vismap[N][N];

vismap* vis[L];

vismap vis1, vis2, vis3, vis4;

int n, m , k;

int sgn_vec_prod(point p1, point p2) {
	double r = p1.x*p2.y-p1.y*p2.x;
	if (abs(r) < 1e-6) return 0;
	if (r > 0) return 1;
	if (r < 0) return -1;
}

bool check_intersects(point p1, point p2, point a, point b) {
	point v1 = point(p1.x - a.x, p1.y - a.y);
	point v2 = point(p1.x - b.x, p1.y - b.y);
	point v0 = point(p1.x - p2.x, p1.y - p2.y);
	bool r = (sgn_vec_prod(v0, v1) != sgn_vec_prod(v0, v2));
	if (a.x == b.x) {
		r &= max(p1.x, p2.x) > a.x && min(p1.x, p2.x) < a.x;
	} else {
		r &= max(p1.y, p2.y) > a.y && min(p1.y, p2.y) < a.y;
	}
	return r;
}

bool has_wall(point p1, point p2) {
	for(int i = 0; i < k; ++i) {
		if (check_intersects(w[i][0], w[i][1], p1, p2)) {
			return true;
		}
	}
	return false;
}

bool is_ok(point p1, point p2) {
	return check_intersects(point(0,1), point(0, 2), p1, p2);
}

bool advance(point& p, char& d, int& total) {
	point new_p(p.x+dx[d], p.y+dy[d]);
	if (is_ok(p, new_p)) {
		p = new_p;
		++total;
		return true;
	}

	if (has_wall(p, new_p)) {
		d = ccw[d];
		return false;
	}
	++total;
	point r_p(p.x+dx[cw[d]], p.y+dy[cw[d]]);
	if (!has_wall(p, r_p) || is_ok(p, r_p)) {
		d = cw[d];
	}
	new_p = point(p.x+dx[d], p.y+dy[d]);
	if (is_ok(p, new_p)) {
		p = new_p;
		return true;
	}
	p = new_p;
	return false;
}

int main()
{
	//cout << check_intersects(point(0, 0), point(1, 0), point(0.5, -0.5), point(0.5, 0.5)) << endl;
	//cout << check_intersects(point(0, 0), point(1, 0), point(1.5, -0.5), point(1.5, 0.5)) << endl;
	dy['N'] = 1;
	dy['S'] = -1;

	dx['W'] = -1;
	dx['E'] = 1;
	
	cw['N'] = 'E'; ccw['N'] = 'W';
	cw['E'] = 'S'; ccw['E'] = 'N';
	cw['S'] = 'W'; ccw['S'] = 'E';
	cw['W'] = 'N'; ccw['W'] = 'S';

	in >> n >> m >> k;
	vis['N'] = &vis1;
	vis['S'] = &vis2;
	vis['E'] = &vis3;
	vis['W'] = &vis4;

	int x, y;
	in >> y >> x;
	char d;
	in >> d;
	for(int i = 0; i < k; ++i) {		
		in >> w[i][0].x >> w[i][0].y;
		in >> w[i][1].x >> w[i][1].y;
	}
	w[k][0].x = 0; w[k][0].y = n;
	w[k][1].x = m; w[k][1].y = n;
	++k;
	w[k][0].x = 0; w[k][0].y = 0;
	w[k][1].x = 0; w[k][1].y = n;
	++k;
	w[k][0].x = m; w[k][0].y = 0;
	w[k][1].x = m; w[k][1].y = n;
	++k;
	w[k][0].x = 0; w[k][0].y = 0;
	w[k][1].x = m; w[k][1].y = 0;
	++k;
	
	int total = 0;
	while (!(*vis[d])[x][y]) {
		(*vis[d])[x][y] = true;
		point p(x-0.5, y-0.5);		
		if (advance(p, d, total)) {
			out << "YES" << endl;
			out << total << endl;
			return 0;
		} else {
			x = p.x+0.5;
			y = p.y+0.5;
		}
		cout << x << ' ' << y << endl;
	}
	//cout << total << endl;
	//cout << x << ' ' << y << endl;
	out << "NO" << endl;
	return 0;
}


