#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <queue>
#include <memory.h>
//#include <cmath>

using namespace std;

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	int k, n;
	scanf("%d %d", &n, &k);
	int res = 0, N = n;
	while (N > 0)
	{
		res += N / k;
		N /= k;
	}
	printf("%d", res / k);
	return 0;
}