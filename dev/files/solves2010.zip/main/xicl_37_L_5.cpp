#include <iostream>
#include <string>
#include <list>
//#include <set>
#include <algorithm>
#define FILE freopen ("input.txt", "r", stdin); freopen ("output.txt", "w", stdout);
using namespace std;


char itoc(int a)
{
	if(a==0)return '0';
	if(a==1)return '1';
	if(a==2)return '2';
	if(a==3)return '3';
	if(a==4)return '4';
	if(a==5)return '5';
	if(a==6)return '6';
	if(a==7)return '7';
	if(a==8)return '8';
	if(a==9)return '9';
}

string inttostr(int n)
{
	string tmp;
	
	while(n!=0)
	{
		tmp=(itoc(n%10))+tmp;
		n=n/10;
	}
	return tmp;
}

class ves
{
public:
	__int64 weight;
	string str;

	bool operator > (ves v);
	bool operator < (ves v);

	ves operator + (ves v);
};

bool ves::operator > (ves v)
{
	return (this->weight > v.weight);
}

bool ves::operator < (ves v)
{
	return (this->weight < v.weight);
}

ves ves::operator + (ves v)
{
	ves temp;
	temp.weight = this->weight + v.weight;
	temp.str = '(' + this->str + '.' + v.str + ')';
	return temp;
}


list<ves> mass;
int n, x;

list<ves>::iterator find(int n)
{
	list<ves>::iterator result;
	result = mass.begin();
	while (result!=mass.end() && (*result).weight<n )
	{
		++result;
	}
	return result;
}

bool attempt()
{
	ves temp;
	list<ves>::iterator it;
	list<ves>::iterator f;

	while(mass.size()>=2)
	{
		it = mass.begin();
		++it;

		if ((*mass.begin()).weight*x<(*it).weight || (*it).weight*x<(*mass.begin()).weight)
			return false;
		
		temp = (*mass.begin()) + (*it);
		
		++it;
		mass.erase(mass.begin(), it);
//		mass.push_back(temp);
		f = find(temp.weight);
		mass.insert(f, temp); 

		
//		sort(mass.begin(), mass.end());
	}
	return true;
}

int main ()
{
	FILE;
	__int64 i, temp_i;
	ves temp_v;
	list<ves>::iterator f;


	cin >> n >> x;
	for (i=0; i<n; ++i)
	{
		cin >> temp_i;
		temp_v.weight = temp_i;
//		temp_v.str = (char) (i+(int)'1');
		temp_v.str = inttostr(i+1);
//		mass.push_back(temp_v);
		f = find(temp_i);
		mass.insert(f, temp_v); 
	}

	if (n==1)
	{
		cout << "no";
		return 0;
	}

//  sort(mass.begin(), mass.end());
	if (attempt())
		cout << (*mass.begin()).str;
	else 
		cout << "no";

	

	return 0;
}