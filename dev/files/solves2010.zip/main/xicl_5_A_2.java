import java.io.*;

public class Solution
{
	public static void main(String[] args) throws IOException
	{
		StreamTokenizer in;
		PrintWriter out;
		
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new BufferedWriter(new FileWriter("output.txt")));
		
//		in = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
//		out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
		
		long n, m, a, b, c, A, B, C, D;
		in.nextToken();
		n = (long) in.nval;
		
		in.nextToken();
		m = (long) in.nval;
		
		in.nextToken();
		a = (long) in.nval;
		
		in.nextToken();
		b = (long) in.nval;
		
		in.nextToken();
		c = (long) in.nval;
		
		
		
		long sum = 0;
		long r;
		for (int M=3;M<=m;M++)
		{
			for (int N=3;N<=n;N++)
			{
				r = (n-N+1)*(m-M+1);
				A = (M-2)-a+1;
/**/			B = (N-2)-b+1;
/**/			C = (N-2)-c+1;
				D = M-2;
				
/*				if (b>1)
					B++;
				if (c>1)
					C++;*/
				
				if (A>0 && B>0 && C>0 && D>0)
				{
					sum += r*A*B*C*D;
				}
			}
		}
		
		
		
		
		
		out.println(sum);
		out.close();
	}
}