#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;

enum { MAXN= 1000010};
long long kvk[MAXN];
long long fuck[MAXN];
int issimple[MAXN];


int main(){

	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
long long ans=0;
	int k, n;
	cin >> n >> k;
	memset(kvk, 0, sizeof(kvk));
	memset(fuck, 0, sizeof(fuck));
	memset(issimple, 0, sizeof(issimple));
		
	int i;
	for (i = 2; i <= n; ++i) {
		fuck[i] = 1;
	}

	for (i = n; i >= 2; --i) {
		if (fuck[i] > 0) {
			for (int j = 2; j < sqrt(double(i) + 1) && j < i; ++j) {
				if (i % j == 0) {
					fuck[j] += fuck[i];
					fuck[i / j] += fuck[i];
					fuck[i] = 0;
					goto hui;
				}
			}
			issimple[i] = 1;

hui:;
		}
	}

	int c = k;
	for (i = 2; i < sqrt(double(k) + 1) && c > 1 && i < k; ++i) {
		while (c % i == 0) {
			c/=i;
			kvk[i]++;
		}
		
	}	
	if (c > 1) {
		kvk[c]++;
	}

	for (int i = 1; i <= k; ++i) kvk[i]*=k;

	ans = 10000000000;
	for (int i = 1; i <= k; ++i) {
		if (kvk[i]) {
			ans = min(ans, fuck[i] / kvk[i]);
		}
	}


	cout << ans << endl;
	return 0;
}