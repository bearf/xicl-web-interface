#include <fstream>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");
bool a[500][500];
bool w[500][500][4];
int dx[4] = {0, -1, 0, 1};
int dy[4] = {1, 0, -1, 0};
int main() {
	memset(a, 0, sizeof(a));
	memset(w, 0, sizeof(w));
	int n, m, k;
	int x, y, d;
	char dd;
	cin >> n >> m >> k;
	cin >> y >> x >> dd;
	switch (dd) {
		case 'N': d = 0; break;
		case 'W': d = 1; break;
		case 'S': d = 2; break;
		case 'E': d = 3; break;
	}
	x *= 2; y *= 2;
	for (int i = 0; i < k; i++) {
		int x1, x2, y1, y2;
		cin >> x1 >> y1 >> x2 >> y2;
		x1 = x1 * 2 + 1; y1 = y1 * 2 + 1; x2 = x2 * 2 + 1; y2 = y2 * 2 + 1;
		if (x1 > x2) {
			int t = x1; x1 = x2; x2 = t;
		}
		if (y1 > y2) {
			int t = y1; y1 = y2; y2 = t;
		}
		for (int q = x1; q <= x2; q++)
			for (int j = y1; j <= y2; j++) 
				a[q][j] = true;
	}
	for (int i = 0; i < 500; i++) {
		a[1][i] = a[i][1] = a[i][n * 2 + 1] = a[m * 2 + 1][i] = true;
	}
	a[1][4] = false;
	int ans = 0;
	while (true) {
		if (x == 0) {
			cout << "YES\n" << ans;
			return 0;
		}
		if (w[x][y][d]) break;
		w[x][y][d] = true;
		if (a[x + dx[d]][y + dy[d]]) {
			d = (d + 1) % 4;
			continue;
		}
		int dp = (d + 3) % 4;
		if (a[x + dx[dp]][y + dy[dp]]) {
			x += 2 * dx[d];
			y += 2 * dy[d];
			ans++;
			continue;
		}
		d = (d + 3) % 4;
		x += 2 * dx[d];
		y += 2 * dy[d];
		ans++;
	}
	cout << "NO";
	return 0;
}