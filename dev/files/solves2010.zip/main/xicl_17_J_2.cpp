#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>

#include <cstdarg>

using namespace std;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	va_end(args);

	fflush(stderr);
#endif
#endif
}

typedef long long ll;
typedef unsigned long long ull;
typedef pair < int , int > pii;

#define clr(a) memset(a,0,sizeof(a))
#define fill(a,b) memset(a,b,sizeof(a))

const double eps = 1e-9;
const double INF = 1e100;

void my_assert(bool f)
{
}

struct Point {
	double x, y;
	Point () {}
	Point (double _x, double _y) : x(_x), y(_y) {}
	Point operator - (const Point & p) const
	{
		return Point(x - p.x, y - p.y);
	}
	Point operator + (const Point & p) const
	{
		return Point(x + p.x, y + p.y);
	}
	double operator * (const Point & p) const
	{
		return x * p.y - y * p.x;
	}
	double operator % (const Point & p) const
	{
		return x * p.x + y * p.y;
	}
	double abs()
	{
		return sqrt(x * x + y * y);
	}
	double distTo(const Point & p) const
	{
		return (p - (*this)).abs();
	}
	Point operator / (double k) const
	{
		return Point(x / k, y / k);
	}
	bool operator == (const Point & p) const
	{
		return (fabs(x - p.x) < eps && fabs(y - p.y) < eps);
	}
	bool onSegment(Point p1, Point p2) const
	{
		Point p = *this;
		return fabs((p1 - p) * (p2 - p)) < eps &&  ((p1 - p) % (p2 - p) < eps);
	}
	void print()
	{
		dbg("%.5lf %.5lf\n", x, y);
	}
};

struct Line {
	double a, b, c;
	Line(Point p1, Point p2)
	{
		a = p1.y - p2.y;
		b = p2.x - p1.x;
		c = - a * p1.x - b * p1.y;
	}
	Point intersect(const Line & l) const
	{
		if (fabs(a * l.b - l.a * b) < eps)
			return Point(INF, INF);
		double x = (l.c * b - c * l.b) / (a * l.b - l.a * b);
		double y = (l.c * a - c * l.a) / (l.a * b - a * l.b);
		return Point(x, y);
	}
};

Point read()
{
	int x, y;
	scanf("%d%d", &x, &y);
	return Point(x, y);
}

Point a, b;
vector <Point> p, p1, p2;

double resR = 0;
Point resP;

double findDist(Point p1, Point p2, Point q)
{
	return fabs((p1 - q) * (p2 - q)) / p1.distTo(p2);
}

bool insideFigure(vector <Point> & p, Point p0)
{
	int n = p.size() - 1;
	double s = 0;
	for (int i = 0; i < n; ++i)
		s += p[i] * p[i + 1];
	s = fabs(s);

	double s1 = 0;
	for (int i = 0; i < n; ++i)
		s1 += fabs((p[i] - p0) * (p[i + 1] - p0));
	return fabs(s1 - s) < eps;
}

bool checkCircle(vector <Point> & p, Point p0, double r)
{
	if (!insideFigure(p, p0))
		return 0;
	for (int i = 1; i < int(p.size()); ++i)
		if (findDist(p[i - 1], p[i], p0) < r - eps)
			return 0;
	return 1;
}

Point findBisect(Point p1, Point p2)
{
	return (p1 / p1.abs()) + (p2 / p2.abs());
}

void insideTriangle(vector <Point> & p, int i, int j, int k, Point & resP, double & resR)
{
	Line l1(p[i], p[i + 1]);
	Line l2(p[j], p[j + 1]);
	Line l3(p[k], p[k + 1]);

	Point p3 = l1.intersect(l2);
	Point p2 = l1.intersect(l3);
	Point p1 = l2.intersect(l3);

	if (p1 == Point(INF, INF) && p2 == Point(INF, INF) && p3 == Point(INF, INF))
	{
		resR = 0;
		resP = p1;
		return ;
	}

	if (p1 == Point(INF, INF))
	{
		swap(l1, l2);
		swap(p1, p2);
		swap(i, j);
	}

	if (p3 == Point(INF, INF))
	{
		swap(l3, l2);
		swap(p3, p2);
		swap(j, k);
	}

	Point q1, q3;

	if (p2 == Point(INF, INF))
	{
		int idx1 = (p[k] == p1) ? k + 1 : k;
		int idx2 = (p[i] == p1) ? i + 1 : i;
		q1 = p1 + findBisect(p3 - p1, p[idx1] - p1);
		q3 = p3 + findBisect(p1 - p3, p[idx2] - p3);
	}
	else
	{
		q1 = p1 + findBisect(p2 - p1, p3 - p1);
		q3 = p3 + findBisect(p1 - p3, p2 - p3);
	}

	Line b1(p1, q1);
	Line b3(p3, q3);

	resP = b1.intersect(b3);

	resR = findDist(p1, p3, resP);
}

void inside(vector <Point> & p)
{
	int n = (int)p.size() - 1;
	for (int i = 0; i < n; ++i)
		for (int j = i + 1; j < n; ++j)
			for (int k = j + 1; k < n; ++k)
			{
				double curR;
				Point curP;
				insideTriangle(p, i, j, k, curP, curR);
				if (curR > resR && checkCircle(p, curP, curR))
				{
					resR = curR;
					resP = curP;
				}
			}
}

vector <Point> delEqual(vector <Point> & p)
{
	vector <Point> q;
	q.push_back(p[0]);
	for (int i = 1; i < int(p.size()); ++i)
		if (!(p[i] == p[i - 1]))
			q.push_back(p[i]);
	if (q[0] == q[(int)q.size() - 1])
		q.pop_back();
	return q;
}

void split(vector <Point> & p, vector <Point> & p1, vector <Point> & p2, Point a, Point b)
{
	p1.clear();
	p2.clear();

	int n = int(p.size()) - 1;

	Line l1(a, a + b);
	for (int i = 0; i < n; ++i)
	{
		if (l1.a * p[i].x + l1.b * p[i].y + l1.c > 0)
			p1.push_back(p[i]);
		else
			p2.push_back(p[i]);
		Line l2 (p[i], p[i + 1]);
		Point pp = l1.intersect(l2);
		if (pp.onSegment(p[i], p[i + 1]))
		{
			p1.push_back(pp);
			p2.push_back(pp);
		}
	}

	p1 = delEqual(p1);
	p2 = delEqual(p2);

	p1.push_back(p1[0]);
	p2.push_back(p2[0]);
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#ifdef DBG1
#if DBG2
	freopen("err.txt", "w", stderr);
#endif
#endif

	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; ++i)
		p.push_back(read());
	p.push_back(p[0]);
	a = read();
	b = read();

	if (insideFigure(p, a + b / (10 * b.abs())))
	{
		split(p, p1, p2, a, b);

		dbg("split\n");
		for (int i = 0; i < int(p1.size()); ++i)
			p1[i].print();
		dbg("\n");
		for (int i = 0; i < int(p2.size()); ++i)
			p2[i].print();
		dbg("\n");

		inside(p1);
		inside(p2);
	}
	else
		inside(p);

	printf("%.5lf\n%.5lf %.5lf\n", resR, resP.x, resP.y);
	
	return 0;
}