#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>

#include <cstdarg>

using namespace std;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	va_end(args);

	fflush(stderr);
#endif
#endif
}

typedef long long ll;
typedef unsigned long long ull;
typedef pair < int , int > pii;

#define clr(a) memset(a,0,sizeof(a))
#define fill(a,b) memset(a,b,sizeof(a))

#pragma comment(linker, "/STACK:16000000")

struct Wall {
	int x1, y1, x2, y2;
	Wall (int _x1, int _y1, int _x2, int _y2) : x1(_x1), y1(_y1), x2(_x2), y2(_y2)
	{
		if (x1 > x2)
			swap(x1, x2);
		if (y1 > y2)
			swap(y1, y2);
	}
	bool intersect(int X1, int Y1, int X2, int Y2)
	{
		if (X1 == X2)
		{
			if (x1 == x2)
				return 0;
			return (x1 < X1 && X1 <= x2 && y1 == Y1);
		}
		else
		{
			if (y1 == y2)
				return 0;
			return (y1 < Y1 && Y1 <= y2 && x1 == X1);
		}
	}
};

const int N = 256;

vector <Wall> walls;

int d[N][N][8];

const int dx[] =     {  1,   0,  -1,   0};
const int dy[] =     {  0,   1,   0,  -1};
const char dirCh[] = {'E', 'N', 'W', 'S'};

bool isWall(int x1, int y1, int dir)
{
	int x2 = x1 + dx[dir];
	int y2 = y1 + dy[dir];
	
	if (x1 > x2)
		swap(x1, x2);
	if (y1 > y2)
		swap(y1, y2);

	int i = 0;
	while (i < (int)walls.size() && !walls[i].intersect(x1, y1, x2, y2))
		++i;

	return i < (int)walls.size();
}

int dfs(int x, int y, int dir, int parD)
{
	dbg("\n%d %d %d\n", x, y, dir);

	if (d[x][y][dir] != -1)
		return  -1;

	d[x][y][dir] = parD + 1;

	if (x == 1 && y == 2)
		return d[x][y][dir];

	//bool third = 1;

	if (isWall(x, y, dir))
	{
		dbg("1");
		return dfs(x, y, (dir + 1) % 4, d[x][y][dir] - 1);
	}
	if (isWall(x, y, (dir + 3) % 4))
	{
		dbg("2");
		return dfs(x + dx[dir], y + dy[dir], dir, d[x][y][dir]);
	}

	if (1)
	{
		dbg("3");
		int new_dir = (dir + 3) % 4;
		return dfs(x + dx[new_dir], y + dy[new_dir], new_dir, d[x][y][dir]);
	}

	return -1;
}

int findNumberDir(char ch)
{
	int i = 0;
	while (dirCh[i] != ch)
		++i;
	return i;
}

void my_assert(bool f)
{
	if (!f)
	{
		dbg("fail\n");
		while (1);
	}
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#ifdef DBG1
#if DBG2
	freopen("err.txt", "w", stderr);
#endif
#endif

	int n, m, k;
	scanf("%d%d%d", &n, &m, &k);
	int x0, y0;
	char dir;
	scanf("%d%d %c", &y0, &x0, &dir);
	for (int i = 0; i < k; ++i)
	{
		int x1, y1, x2, y2;
		scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
		dbg("%d %d %d %d\n", x1, y1, x2, y2);
		my_assert(x1 == x2 || y1 == y2);
		walls.push_back(Wall(x1, y1, x2, y2));
	}
	walls.push_back(Wall(0, 0, 0, 1));
	walls.push_back(Wall(0, 2, 0, n));
	walls.push_back(Wall(0, n, m, n));
	walls.push_back(Wall(m, 0, m, n));
	walls.push_back(Wall(0, 0, m, 0));

	for (int i = 0; i < int(walls.size()); ++i)
	{
		walls[i].x1 ++;
		walls[i].x2 ++;
	}

	++ x0;

	dbg("read\n");

	fill(d, 0xFF);
	int _dir = findNumberDir(dir);
	int res = dfs(x0, y0, _dir, -1);

	if (res == -1)
		printf("NO\n");
	else
		printf("YES\n%d\n", res);
	
	return 0;
}