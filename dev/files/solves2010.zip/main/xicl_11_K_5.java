import java.io.*;
import java.util.*;

public class Solution {

	private PrintWriter pw;
	private BufferedReader bf;
	private StringTokenizer st;

	int n, k;

	int calc(int v, int k) {
		int ret = 0;
		while (v % k == 0) {
			++ret;
			v /= k;
		}
		return ret;
	}

	int go(int id, int cnt) {
		int ret = 0;
		for (int i = id; i < n + 1; i += id) {
			ret += calc(i, id);
		}
		return ret / cnt;
	}

	boolean solve() throws IOException {
		n = nextInt();
		k = nextInt();

		int ans = Integer.MAX_VALUE;

		int kk = k;
		int cp = 2;

		while (kk > 1 && kk >= cp * cp) {
			int cnt = 0;
			while (kk % cp == 0) {
				++cnt;
				kk /= cp;
			}
			if (cnt > 0) {
				ans = Math.min(ans, go(cp, cnt));
			}

			++cp;
		}

		if (kk > 1) {
			ans = Math.min(ans, go(kk, 1));
		}

		// pw.println(ans);
		ans = ans / k;

		pw.println(ans);

		return false;
	}

	public void run() throws IOException {
		pw = new PrintWriter(new File("output.txt"));
//		pw = new PrintWriter(System.out);
		bf = new BufferedReader(new FileReader(new File("input.txt")));
		while (solve()) {

		}
		pw.flush();
	}

	// GAVNO NIZHE

	String nextString() throws IOException {
		while (st == null || !st.hasMoreTokens()) {
			String str = bf.readLine();
			if (str == null) {
				return null;
			}
			st = new StringTokenizer(str);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.valueOf(nextString());
	}

	double nextDouble() throws IOException {
		return Double.valueOf(nextString());
	}

	public static class Pair<T, V> {
		T first;
		V second;

		public Pair(T first, V second) {
			super();
			this.first = first;
			this.second = second;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((first == null) ? 0 : first.hashCode());
			result = prime * result
					+ ((second == null) ? 0 : second.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Pair other = (Pair) obj;
			if (first == null) {
				if (other.first != null)
					return false;
			} else if (!first.equals(other.first))
				return false;
			if (second == null) {
				if (other.second != null)
					return false;
			} else if (!second.equals(other.second))
				return false;
			return true;
		}

		@Override
		public String toString() {
			return "Pair [first=" + first + ", second=" + second + "]";
		}
	}

	public static class ComparablePair<T extends Comparable<T>, V extends Comparable<V>>
			extends Pair<T, V> implements Comparable<ComparablePair<T, V>> {

		public ComparablePair(T first, V second) {
			super(first, second);
		}

		@Override
		public int compareTo(ComparablePair<T, V> arg0) {
			if (arg0.first.compareTo(first) != 0) {
				return -arg0.first.compareTo(first);
			}
			if (arg0.second.compareTo(second) != 0) {
				return -arg0.second.compareTo(second);
			}
			return 0;
		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		new Solution().run();
	}

}
