#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;

const int INF = 1000000000;

int n, m, x, y;
int a[120][120];
int u[120][120];
int u1[120][120];
int d[120];

bool was[120];

int p[120];
int k = 0;

void dijkstra()
{
	memset(was, 0, sizeof(was));

	for(int i = 1; i <= n; i++)
		d[i] = INF;
	d[x] = 0;
		
	while (true)
	{
		int v = -1;

		for(int i = 1; i <= n; i++)
			if (d[i] <= INF && !was[i] && (v == -1 || d[v] > d[i]))
				v = i;

		if (v == -1)
			break;
		
		was[v] = true;

		for(int i = 1; i <= n; i++)
			if (a[v][i] > 0 && d[i] > d[v] + a[v][i])
				d[i] = d[v] + a[v][i];
	}

}

void newgraph()
{
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= n; j++)
			if (i == j || d[j] != d[i] + a[i][j])
				u[i][j] = 0;
			else
				u[i][j] = 1;
}

bool dfs(int v)
{
	if (v == y)
		return true;

	for(int i = 1; i <= n; i++)
		if (u1[v][i] && dfs(i))
		{
			u1[v][i] ^= 1;
			u1[i][v] ^= 1;
			return true;
		}

	return false;
}

void flow()
{
	memcpy(u1, u, sizeof(u1));
	while (dfs(x))
	{
		cerr << "fuck\n";
	};
}

bool way(int v)
{
	if (v == x)
	{
		return true;
	}
	
	for(int i = 1; i <= n; i++)
		if (u1[v][i] && u[i][v] && way(i))
		{
			p[k] = i;
			k++;
			u1[v][i] = 0;
			return true;
		}

	return false;		
}

void answer()
{
	int ans = 0;
	for(int i = 1; i <= n; i++)
		if (u1[y][i] && u[i][y])
			ans++;

	printf("%d\n", ans);
	
	while (way(y))
	{
		p[k] = y;
		k++;

		printf("%d ", k);
		for(int i = 0; i < k; i++)
			printf("%d ", p[i]);
		
		printf("\n");
		k = 0;
	};
}

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);

	scanf("%d%d%d%d", &n, &m, &x, &y);

	memset(a, 0, sizeof(a));
	memset(u, 0, sizeof(u));

	for(int i = 0; i < m; i++)
	{
		int xi,yi,li;
		scanf("%d%d%d", &xi, &yi, &li);
		a[xi][yi] = li;
	}

	dijkstra();
	newgraph();
	flow();
	answer();

	return 0;
}
