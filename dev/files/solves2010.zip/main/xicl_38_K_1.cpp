#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<stack>
#include<cmath>
using namespace std;
int main(){
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	long long n,k,ans=0; 
	cin>>n>>k;
	long long j=k;
	while (n/j!=0){
		ans+=(n/j);
		j*=k;
	}
	ans/=k;
	cout<<ans;
	return 0;
}