#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

const int N = 10000;

int f[N];
int fc[N];
int p = 0;
void factor(int k) {
	int max = (int)sqrt((double)k)+1;
	for(int i = 2; i <= max; ++i) {
		if (k % i == 0) {
			f[p] = i;
			while (k % i == 0) {
				k /= i;
				++fc[p];
			}
			++p;
		}
	}
}

int nc[N];

void factor_n(int n) {
	for(int i = 0; i < p; ++i) {
		int c = f[i];
		while (c < n) {
			nc[i] += n/c;
			c *= f[i];
		}
	}
}

int main()
{
	int n, k;
	in >> n >> k;
	factor(k);
	factor_n(n);
	int min = 1000000000;
	for(int i = 0; i < p; ++i) {		
		int c = nc[i]/(fc[i]*k);
		if (c < min) {
			min = c;
		}
	}
	out << min << endl;
	return 0;
}

