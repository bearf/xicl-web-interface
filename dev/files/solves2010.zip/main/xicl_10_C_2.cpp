#include <iostream>
#include <ctime>
#include <cmath>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <deque>
#include <sstream>
#include <string>
#include <algorithm>
#include <functional>
#include <numeric>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define ford(i, n) for(int i = int(n) - 1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define X first
#define Y second

typedef long double ld;
typedef long long li;
typedef pair<int, int> pt;

const int INF = (int)1E9;
const ld EPS = (1E-9);

const int P = 1000000000;

int n;
string in[300];
char buff[1000];

stack<int> op, oc, op2, oc2;

int getPr(char op){
	if(isalpha(op))
		return int(op - 'a');
	
	switch (op){
		case '(':
			return -100;
		case ')':
			return 100;

		case '+':
			return 1;
		case '-':
			return 2;

		case '*':
			return 3;
		case '/':
			return 4;
		case '%':
			return 5;

		default:
			throw 1;
	}

}

int makeOp(int x, int y, char op){
	switch(op){
		case '+':
			return (x + y) % P;

		case '-':
			return (x - y + P) % P;

		case '*':
			return (li(x) * li(y)) % P;

		case '/':
			if(y == 0 || x == 0)
				return 0;
			else
				return x / y;

		case '%':
			if(y == 0 || x == 0)
				return 0;
			else
				return x % y;

		default:
			throw 1;
	};
}

void makeOp(){
	char oper = op.top();
	op.pop();

	int y = oc.top();
	oc.pop();

	int x = oc.top();
	oc.pop();

	oc.push(makeOp(x, y, oper));
}

int calcIn(int x, int y, int idx){
	string& s = in[idx];

	forn(i, sz(s)){
		if(s[i] == 'X' || s[i] == 'Y'){
			oc.push((s[i] == 'X') ? x : y);
		}else{
			if(s[i] == '(')
				op.push('(');
			else{
				if(s[i] == ')'){
					while(op.top() != '('){
						makeOp();
					}
					op.pop();
				}else{
					while(!op.empty() && getPr(op.top()) >= getPr(s[i]))
						makeOp();

					op.push(s[i]);
				}
			}
		}
	}

	while(!op.empty())
		makeOp();

	assert(sz(oc) == 1);
	int res = oc.top();
	oc.pop();

	return res;
}

void makeOp2(){
	char oper = op2.top();
	op2.pop();

	int y = oc2.top();
	oc2.pop();

	int x = oc2.top();
	oc2.pop();

	oc2.push(calcIn(x, y, int(oper - 'a')));
}

char s[200010];
int cnt[256];

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	memset(cnt, -1, sizeof(cnt));
	cnt['I'] = 1;
	cnt['V'] = 5;
	cnt['X'] = 10;
	cnt['L'] = 50;
	cnt['C'] = 100;
	cnt['D'] = 500;
	cnt['M'] = 1000;

	cin >> n;
	gets(buff);
	forn(i, n){
		gets(buff);
		in[i] = buff;
	}

	gets(s);
	int n = strlen(s);

	forn(i, n){
		if(s[i] == '(')
			op2.push('(');
		else{
			if(s[i] == ')'){

				if(i == 0 || s[i - 1] == tolower(s[i - 1])){
					oc2.push(0);
				}

				while(op2.top() != '('){
					makeOp2();
				}
				op2.pop();
			}else{
				if(s[i] == tolower(s[i])){

					if(i == 0 || s[i - 1] == tolower(s[i - 1])){
						oc2.push(0);
					}

					while(!op2.empty() && getPr(op2.top()) >= getPr(s[i]))
						makeOp2();

					op2.push(s[i]);
				}else{
					int curN = 0;
					int j = i;
					while(j < n && s[j] == toupper(s[j]) && isalpha(s[j])){
						if(j + 1 < n && cnt[s[j + 1]] > cnt[s[j]])
							curN -= cnt[s[j]];
						else
							curN += cnt[s[j]];
						++j;
					}
					oc2.push(curN);
					i = j - 1;
				}
			}
		}
	}

	while(!op2.empty())
		makeOp2();

	assert(sz(oc2) == 1);

	cout << oc2.top() << endl;

	return 0;
}