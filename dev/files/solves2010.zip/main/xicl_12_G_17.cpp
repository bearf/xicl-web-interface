#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

#define pb push_back
#define all(c) (c).begin(),(c).end()


using namespace std;

int x[15000],y[15000];
int n;
int px1,px2,py1,py2;
int was[15000];

vector<int> answer;

long long vm(int x1,int y1,int x2,int y2,int x3,int y3)
{
	long long X1 = x2-x1;
	long long Y1 = y2-y1;
	long long X2 = x3-x1;
	long long Y2 = y3-y1;
	return X1*Y2-X2*Y1;
}

double dist(int x1,int y1,int x2,int y2)
{
	return sqrt( (double)(x2-x1)*(x2-x1)+(double)(y2-y1)*(y2-y1) );
}

int f(int start,int i)
{
	answer.pb(i);

	int max_j = i;

	for(int j = i+1; j < 2*n; j++)
	{
		if( vm(x[i],y[i],px1,py1,x[j],y[j]) >= 0 && vm(x[i],y[i],px2,py2,x[j],y[j]) >= 0 )
		{
			max_j = j;
			if( j%n == start ) break;
		} else break;
	}
	max_j %= n;
	if( max_j == start ) return 0;

	if( max_j != i )
		return f(start,max_j);
	else return 1;
	

	return 0;
}

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);

	scanf("%d",&n);
	for(int i = 0; i < n; i++)
	{
		scanf("%d%d",&x[i],&y[i]);
		x[n+i] = x[i];
		y[n+i] = y[i];
	}
	int N = n;
	n =  0;
	for(int i = 0; i < N; i++)
	{
		if( x[i] != x[i+1] || y[i] != y[i+1] )
		{
			x[n] = x[i];
			y[n] = y[i];
			n++;
		}
	}
	for(int i = 0; i < n; i++)
	{
		x[n+i] = x[i];
		y[n+i] = y[i];
		x[n+n+i] = x[i];
		y[n+n+i] = y[i];
	}

	scanf("%d%d%d%d",&px1,&py1,&px2,&py2);
	
	memset( was, false, sizeof was );
	answer.clear();
	for(int i = 0; i < n; i++)	
	{
		if (f(i,i))
		{
		}
		if( answer.size() > 4 )
		{
			answer.clear();
		} else break;
	}

	if( answer.size() == 1 ) 
	{
		answer.pb( (answer[0]+1)%n );
	}

	while( answer.size() < 4 )
	{
		sort( all(answer) );
		for(int i = 0; i < (int)answer.size(); i++)
			if( (answer[i]+1)%n != answer[(i+1)%(int)answer.size()] )
			{
				answer.pb( (answer[i]+1)%n );
				break;
			}
	}
	sort( all(answer) );

	for(int i = 0; i < (int)answer.size(); i++)
	{
		printf("%d %d\n",x[ answer[i] ],y[ answer[i] ]);
	}

	return 0;
}
