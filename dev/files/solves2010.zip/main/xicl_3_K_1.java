import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {
	static public void main(String[] args) throws IOException {
		new Solution().run();
	}
	StreamTokenizer in;
	PrintWriter out;
	void run() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		solve();
		out.flush();
	}
	
	void solve() throws IOException {
		int n = ni();
		int k = ni();
		int l = k;
		int res = 0;
		while(n > l) {
			res += n / l;
			l *= k;
		}
		res /= k;
		out.print(res);
	}
	
	int ni() throws IOException {
		in.nextToken();
		return (int)in.nval;
	}
}
