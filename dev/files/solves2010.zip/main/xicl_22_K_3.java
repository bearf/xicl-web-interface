import java.util.*;
import java.awt.geom.*;
import java.math.*;
import static java.lang.Math.*;
import java.io.*;


public class Solution implements Runnable{

	static BufferedReader br = null;
	static PrintWriter pw = null;
	static StringTokenizer stk = new StringTokenizer("");
	
	public static void main(String[] args) throws FileNotFoundException {
		br = new BufferedReader(new FileReader("input.txt")); 
		pw = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}

	void nline() {
		try {
			stk = new StringTokenizer(br.readLine());
		} catch (IOException e) {
			throw new RuntimeException("No new line");
		}
	}
	
	String nwrd() {
		while (!stk.hasMoreElements()) nline();
		return stk.nextToken();
	}
	

	int ni() {
		return Integer.valueOf(nwrd());
	}
	
	long nl() {
		return Long.valueOf(nwrd());
	}
	
	double nd() {
		return Double.valueOf(nwrd());
	}
	
	char nc() {
		return nwrd().charAt(0);
	}
	
	boolean isReady() {
		try {
			return br.ready();
		} catch (IOException e) {
			throw new RuntimeException("Something wrong in br");
		}
	}
	
	public void solve() {
		long n = nl();
		long k = nl();
		long kk = k;
		long max = -1;
		for (int i=2;i<=sqrt(k)+10;i++) {
			if (kk%i==0) {
				long mm = 1;
				while (kk%i==0) {
					mm*=i;
					kk/=i;
				}
				if (mm>max) max=mm;
			}
		}
		if (kk!=1)
			if (kk>max) max=kk;
		long nn = n;
		long q = 0;
		for (int i=1;i<=n;i++) {
			long ee = i;
			while (ee%max==0) {
				q++;
				ee/=max;
			}
		}
		pw.println(q/k);
	}
	
	public void run() {
		solve();
		pw.close();
	}

}
