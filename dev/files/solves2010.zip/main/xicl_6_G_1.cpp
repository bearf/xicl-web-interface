// vish.cpp : Defines the entry point for the console application.
//

#include "stdio.h"
#include <iostream>
using namespace std;
int x[3000];
int y[3000];
long long vect2(long long x1,long long y1,long long x2,long long y2,long long x3,long long y3){
	return (x2-x1)*(y3-y1)-(x3-x1)*(y2-y1);
}
int vect(int i,int j,long long x3,long long y3){
	long long r=vect2(x[i],y[i],x[j],y[j],x3,y3);
	int s=0;
	if (r>0) s=1; 
    if (r==0) s=0;
	if (r<0) s=-1;
	return s;
}
long long abs(long long x) {
	 if (x>0) return x; else return -x;
}
int isin(int c1,int c2,int c3,int c4,int x5,int y5){
	int x1,y1,x2,y2,x3,y3,x4,y4;
	x1=x[c1];x2=x[c2];x3=x[c3];x4=x[c4];
	y1=y[c1];y2=y[c2];y3=y[c3];y4=y[c4];
	return (
		  (abs(vect2(x1,y1,x3,y3,x2,y2))+abs(vect2(x1,y1,x4,y4,x3,y3)))==
(
		  abs(vect2(x1,y1,x4,y4,x5,y5))+
		  abs(vect2(x4,y4,x3,y3,x5,y5))+
		  abs(vect2(x3,y3,x2,y2,x5,y5))+
		  abs(vect2(x2,y2,x1,y1,x5,y5)))
		);
}
void print(int s) { cout << x[s] << " " << y[s] << endl; }
int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int n,x1,y1,x2,y2,i,j,t,t1,t2;
	cin >> n;
	for (i=0;i<n;i++) { cin >> x[i]; cin >> y[i]; };
	cin >> x1 >> y1 >> x2 >> y2;
	for (i=0;i<n;i++) {
		x[i+n]=x[i];y[i+n]=y[i];
	}
	for (i=0;i<n;i++) {
		t=i+1;
		int r1=vect(i,t,x1,y1);
		int r2=vect(i,t,x2,y2);
		while (1) {
			if (r1==0) break;
			int kk=vect(i,t,x1,y1);
			if (kk!=0) if (kk!=r1) break;
			r1=kk;

			if (r2==0) break;
			kk=vect(i,t,x2,y2);
			if (kk!=0) if (kk!=r2) break;
			r2=kk;
			t++;
		}
		t1=t-1;
		t=n+i-1;
		r1=vect(i,t,x1,y1);
		r2=vect(i,t,x2,y2);
		while (1) {
			if (r1==0) break;
			int kk=vect(i,t,x1,y1);
			if (kk!=0) if (kk!=r1) break;
			r1=kk;

			if (r2==0) break;
			kk=vect(i,t,x2,y2);
			if (kk!=0) if (kk!=r2) break;
			r2=kk;
			t--;
		}
		t2=t+1;
		if (t1==t2-1) {
			if (i<t1-1) t1=t1-1; else
			if (n+i>t2+1) t2=t2+1;
		}
		for (j=t1+1;j<=t2-1;t++) {
			if ((isin(i,t1,j,t2,x1,y1))&&(isin(i,t1,j,t2,x2,y2))) {
				print(i);print(t1);print(j);print(t2);
				return 0;
			}
		}
	}
	return 0;
}

