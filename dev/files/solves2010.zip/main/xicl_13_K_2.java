import java.io.*;
import java.util.*;
import java.math.*;

public class Solution {

	BufferedReader cin;
	PrintWriter cout;
	StringTokenizer tok;
	
	public static void main(String[] args) throws IOException 
	{
		new Solution().run();
	}

	void run() throws IOException
	{
		cin = new BufferedReader(new FileReader("input.txt"));
		cout = new PrintWriter(new FileWriter("output.txt"));
		
		solve();
		
		cout.flush();
		System.exit(0);
	}
	
	String next() throws IOException
	{
		if( tok == null || !tok.hasMoreTokens() )
			tok = new StringTokenizer(cin.readLine());
		
		return tok.nextToken();
	}
	
	int nextInt() throws IOException
	{
		return Integer.parseInt(next());
	}
	
	void solve() throws IOException
	{
		long n = nextInt();
		BigInteger k = new BigInteger(next());
		
		long i = 0;
		
		BigInteger s = BigInteger.ONE;
		
		for( int j = 2 ; j <= n ; j++ )
		{
			BigInteger p = new BigInteger(String.valueOf(j));
			int pow = 0;
			while( p.mod(k).equals(BigInteger.ZERO) )
			{
				pow++;
				p = p.divide(k);
			}
			
			i += pow;
			s = p;
		}
		
		cout.println((long)i / k.intValue());
	}
}
