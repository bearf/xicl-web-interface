#include <fstream>
#include <vector>
#include <cmath>
#include <set>

using namespace std;

ifstream cin("input.txt");
ofstream cout("output.txt");

#define len(v) (int)(v).size()
#define vi vector<int>
#define vvi vector<vi >
#define ii pair<int,int>
#define vii vector<ii >
#define vvii vector<vii >
#define inf 987654321

int n, m, x, y;
vvi G;

vi parent;
vi D;

void dijkstra()
{
	parent.assign(n,-1);
	D.assign(n,inf);
	set<ii > q;
	D[x] = 0;
	q.insert(ii(0,x));
	while(!q.empty())
	{
		ii p = *q.begin();
		q.erase(q.begin());
		int from = p.second;
		for(int to = 0; to < n; to++)
		{
			int w = G[from][to];
			if(w == inf)
				continue;
			if(D[from] + w < D[to])
			{
				if(q.find(ii(D[to],to)) != q.end())
					q.erase(ii(D[to],to));
				D[to] = D[from] + w;
				q.insert(ii(D[to],to));
				parent[to] = from;
			}
		}
	}
}

__int32 main()
{
	cin >> n >> m >> x >> y;
	x--,y--;
	G.resize(n, vi(n,inf));
	for(int i = 0; i < m; i++)
	{
		int a, b, d;
		cin >> a >> b >> d;
		a--, b--;
		G[a][b] = d;
	}

	int mi = inf;
	vvi ans;
	while(true)
	{
		dijkstra();
		if(D[y] == inf || D[y] > mi)
			break;
		mi = D[y];
		ans.push_back(vector<int>());
		int cur = y;
		while(cur != x)
		{
			ans.back().push_back(cur);
			int prev = parent[cur];
			G[prev][cur] = inf;
			cur = prev;
		}
		ans.back().push_back(x);
	}
	cout << len(ans);
	for(int i = 0; i < len(ans); i++)
	{
		cout << endl << len(ans[i]);
		for(int j = len(ans[i])-1; j >= 0; j--)
			cout << ' ' << ans[i][j] + 1;
	}
}
			