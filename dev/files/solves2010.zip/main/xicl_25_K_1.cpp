#include <iostream>
#include <vector>

using namespace std;

vector<int> vn,vk;

int a[2000000],b[2000000],r[2000000];

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int i,k,j,n,f;

	
	int tmp,x;
	cin>>n>>k;
	tmp=n;
	i=2;
	while (i<=1000000)
	{
		if (r[i]) i++; 
		else
		{
			vn.push_back(i);
			j=i;
			for (j=i;j<=1000000;j+=i)
			  r[j]=1;
		}
	}
	if (tmp>1) vn.push_back(tmp);
	//for (i=0;i<prime.size();i++) cout<<prime[i]<<" ";	if (tmp>1) vn.push_back(tmp);
	//for (i=0;i<vn.size();i++) cout<<vn[i]<<" ";
	i=2;
	tmp=k;
	while (tmp>0 && i*i<=tmp)
	{
		while (tmp%i==0)
		{
			b[i]++;
			tmp=tmp/i;
		}
		b[i]=b[i]*k;
		i++;
	}
	if (tmp>1) 
	  {
		  b[tmp]++;
		  b[tmp]=b[tmp]*k;
	  }
	//cout<<vn.size()<<endl;
	for (i=0;i<vn.size();i++)
	{
		tmp=n;
		while (tmp>1)
		{
			a[vn[i]]=a[vn[i]]+tmp/vn[i];
			tmp=tmp/vn[i];
		}
	}
	int m=1000000;
	int pow=m;
	//for (i=0;i<20;i++) cout<<a[i]<<" "<<b[i]<<endl;
	for (i=2;i<1000000;i++)
	{
		if (a[i]<b[i]) 
		{
			cout<<0;
			return 0;
		}
       if (b[i]!=0) pow=min(m,a[i]/b[i]);
	}
	cout<<pow;
	return 0;
}