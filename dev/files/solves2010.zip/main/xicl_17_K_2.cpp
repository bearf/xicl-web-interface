#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>

#include <cstdarg>

using namespace std;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	va_end(args);

	fflush(stderr);
#endif
#endif
}

typedef long long ll;
typedef unsigned long long ull;
typedef pair < int , int > pii;

#define clr(a) memset(a,0,sizeof(a))
#define fill(a,b) memset(a,b,sizeof(a))

const int NMAX = 1024 * 1024;
int primes[NMAX];
int primesDeg[NMAX];
int primesCnt;

int isPrime[NMAX];
int cntn[NMAX], cntk[NMAX];


int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#ifdef DBG1
#if DBG2
	freopen("err.txt", "w", stderr);
#endif
#endif
	for(int i = 2; i < NMAX; i++)
	{
		if (isPrime[i] == 0)
		{
			for(int j = i; j < NMAX; j += i)
			{
				isPrime[j] = i;
			}
		}
	}
	int n, k;
	scanf("%d%d", &n, &k);
	if (k > n)
	{
		printf("0\n");
		return 0;
	}
	int ans = 10000000;
	int K = k;
	while(k != 1)
	{
		cntk[isPrime[k]] ++;
		k /= isPrime[k];
	}
	for(int i = 2; i <= n; i++)
	{
		int j = i;
		while(j != 1)
		{
			cntn[isPrime[j]] ++;
			j /= isPrime[j];
		}
	}
	for(int i = 1; i <= n; i++)
		if (cntk[i])
			ans = std::min(ans, cntn[i] / cntk[i]);
	ans /= K;
	printf("%d\n", ans);




	return 0;
}