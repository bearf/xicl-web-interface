#include <fstream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <queue>

using namespace std;

ifstream cin("input.txt");
ofstream cout("output.txt");

#define len(v) (int)(v).size()
#define vi vector<int>
#define vvi vector<vi >
#define ii pair<int,int>
#define vii vector<ii >
#define all(v) (v).begin(),(v).end()
#define vvii vector<vii >
#define inf 1000000000

const int dx[] = {1,0,-1,0}, dy[] = {0,1,0,-1};// ++ - ������ �������

int n, m, x, y;
vector<vector<bool> > visited[4];

struct cell
{
	bool a[4];
};

vector<vector<cell> > v;

__int32 main()
{
	int k;
	cin >> n >> m >> k;
	v.resize(m, vector<cell>(n));
	for(int i = 0; i < 4; i++)
		visited[i].resize(m, vector<bool>(n));
	cin >> y >> x;
	x--, y--;
	char ch;
	int d;
	cin >> ch;
	if(ch == 'E')
		d = 0;
	if(ch == 'N')
		d = 1;
	if(ch == 'W')
		d = 2;
	if(ch == 'S')
		d = 3;
	for(int i = 0; i < k; i++)
	{
		int a, b, c, d;
		cin >> a >> b >> c >> d;
		if(a > c)
			swap(a,c);
		if(b > d)
			swap(b,d);
		if(a == c) // vert
		{
			for(int j = b; j < d; j++)
			{
				if(a != 0)
					v[a-1][j].a[0] = true;
				if(a != m)
					v[a][j].a[2] = true;
			}
		}
		else// hor
		{
			for(int i = a; i < c; i++)
			{
				if(b != 0)
					v[i][b-1].a[1] = true;
				if(b != n)
					v[i][b].a[3] = true;
			}
		}
	}
	int cnt = 0;
	bool done = false;
	for(int i = 0; i < m; i++)
	{
		v[i][0].a[3] = true;
		v[i][n-1].a[1] = true;
	}
	for(int j = 0; j < n; j++)
	{
		v[0][j].a[2] = true;
		v[m-1][j].a[0] = true;
	}

	v[0][1].a[2] = false;

	while(true)
	{
		if(x == -1 && y == 1)
		{
			done = true;
			break;
		}

		if(visited[d][x][y])
			break;
		visited[d][x][y] = true;

		if(v[x][y].a[d])
			d = (d+1)%4;
		else if(v[x][y].a[(d+4-1)%4])
		{
			x += dx[d], y += dy[d];
			cnt++;
		}
		else
		{
			d = (d+4-1)%4;
			x += dx[d], y += dy[d];
			cnt++;
		}
	}
	if(done)
	{
		cout << "YES" << endl;
		cout << cnt;
	}
	else
		cout << "NO";
}