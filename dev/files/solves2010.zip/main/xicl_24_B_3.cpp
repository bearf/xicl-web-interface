#pragma comment( linker, "/stack:32000000" )
#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>

#define filein ""

void prepare( )
{
	freopen( "input.txt", "r", stdin );
#ifndef _DEBUG
	freopen( "output.txt", "w", stdout ); 
#endif
}

#include <cmath>
#include <cassert>
#include <memory.h>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>
#include <ctime>
#include <deque>

using namespace std;

#define fo(a,b,c) for(a=(b);a<(c);++a)
#define fr(a,b) fo(a,0,(b))
#define fi(a) fr(i,(a))
#define fj(a) fr(j,(a))
#define fk(a) fr(k,(a))
#define all(a) (a).begin(),(a).end()
#define sz(a) (int)(a).size()
#define pb push_back
#define mp make_pair
#define _(a,b) memset((a),(b),sizeof(a))
#define __(a) _((a),0)

typedef long long lint;

const int MAXN = 105;
const int INF = 1000000000;

struct Edge
{
	int a, b, cost;
	int id;
};

int n, m;
vector<Edge> v[MAXN];
vector<Edge> rev[MAXN];
vector<int> den;
int last[MAXN];
int d[MAXN];
int el[MAXN];
int w[MAXN];
int ansd;
vector<vector<int> > ans;
set<pair<int, int > > q;

namespace MF
{
	struct Edge
	{
		int a, b, cap;
		int id, rev;
	};

	vector<Edge> e;
	vector<int> v[MAXN];
	int w[MAXN];
	int S, T;
	int CTIME;

	void addEdge( int a, int b, int cap )
	{
		Edge t;
		t.a = a;
		t.b = b;
		t.cap = cap;
		t.id = sz( e );
		t.rev = t.id + 1;
		v[t.a].pb( t.id );
		e.pb( t );

		swap( t.a, t.b );
		swap( t.id, t.rev );
		t.cap = 0;
		v[t.a].pb( t.id );
		e.pb( t );
	}

	bool dfs( int id )
	{
		if ( id == T )
			return true;
		if ( w[id] == CTIME )
			return false;
		w[id] = CTIME;
		int i;
		fi( sz( v[id] ) )
		{
			Edge &t = e[v[id][i]];
			if ( t.cap && dfs( t.b ) )
			{
				-- e[t.id].cap;
				++ e[t.rev].cap;
				return true;
			}
		}
		return false;
	}
	
	void re_dfs( int id, vector<int> &re )
	{
		re.pb( id );
		if ( id == S )
			return;
		int i;
		fi( sz( v[id] ) )
		{
			Edge &t = e[v[id][i]];
			if ( t.cap && t.id > t.rev )
			{
				-- e[t.id].cap;
				re_dfs( t.b, re );
				return;
			}
		}
	}

	int maxFlow( )
	{
		++ CTIME;
		int i, j;
		int ans = 0;
		while ( dfs( S ) )
		{
			++ ans;
			while ( dfs( S ) )
				++ ans; 
			++ CTIME;
		}
		return ans;
	}
};

void add( int id, int nd, int lid, int tid )
{
	if ( d[id] > nd )
	{
		q.erase( mp( d[id], id ) );
		d[id] = nd;
		el[id] = tid;
		last[id] = lid;
		q.insert( mp( d[id], id ) );
	}
}

void dfs( int id, int dd )
{
	if ( w[id] )
		return;
	w[id] = 1;
	int i;
	fi( sz( rev[id] ) )
	{
		Edge &t = rev[id][i];
		if ( d[t.a] + t.cost == dd )
		{
			MF::addEdge( t.a, t.b, 1 );
			dfs( t.a, dd - t.cost );
		}
	}
}

int main( )
{
	prepare( );
	int i, j, k;
	int st, en;
	scanf( "%d %d %d %d", &n, &m, &st, &en );
	-- st;
	-- en;
	den.resize( m, 0 );
	fi( m )
	{
		int a, b, cost;
		scanf( "%d %d %d", &a, &b, &cost );
		-- a; -- b;
		Edge t;
		t.a = a;
		t.b = b;
		t.cost = cost;
		t.id = i;
		rev[b].pb( t );
		v[a].pb( t );
	}
	q.clear( );
	_( d, 127 );
	add( st, 0, -1, -1 );
	int id;
	bool ok = false;
	while ( !q.empty( ) )
	{
		id = q.begin( )->second;
		q.erase( q.begin( ) );
		int cd = d[id];
		fi( sz( v[id] ) )
		{
			Edge &t = v[id][i];
			add( t.b, cd + t.cost, id, t.id );
		}
	}
	int cur = d[en];
	if ( cur == INF )
	{
		printf( "0\n" );
		return 0;
	}
	dfs( en, cur ); 
	MF::S = st;
	MF::T = en;
	int cans = MF::maxFlow( );
	fi( cans )
	{
		vector<int> tmp;
		MF::re_dfs( en, tmp );
		reverse( all( tmp ) );
		ans.pb( tmp );
	}

	printf( "%d\n", sz( ans ) );
	fi( sz( ans ) )
	{
		printf( "%d", sz( ans[i] ) );
		fj( sz( ans[i] ) )
		{
			printf( " %d", ans[i][j] + 1 );
		}
		printf( "\n" );
	}
	return 0;
}