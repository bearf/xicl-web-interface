// bmoto.cpp : Defines the entry point for the console application.
//

#include "stdio.h"
#include <iostream>
using namespace std;
int d[100][100];
int a[100][100];
int b[100][100];
int r[100][100];
int kol;
void rec(int x,int y){
	if (d[x][y]==-1) {
	   r[kol][0]++;
	   r[kol][r[kol][0]]=x+1;
	   r[kol][0]++;
	   r[kol][r[kol][0]]=y+1;
       b[x][y]=100000000;
	} else {
	   rec(x,d[x][y]);
	   r[kol][0]--;
	   rec(d[x][y],y);
	}
}
int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int n,m,x,y,i,j,ttt,k,c1,c2,c3;
	cin >> n >> m >> x >> y;
	for (i=0;i<n;i++) for (j=0;j<n;j++) a[i][j]=100000000;
	for (i=1;i<=m;i++) {
		cin >> c1 >> c2 >> c3;
		a[c1-1][c2-1]=c3;
	}
	x=x-1;
	y=y-1;
	memcpy(b,a,sizeof(a));
	ttt=-1;
	kol=0;	
	while (1) {
		memcpy(a,b,sizeof(b));
		for (i=0;i<n;i++) for (j=0;j<n;j++) d[i][j]=-1;

		 for (k=0;k<n;k++) 
			 for (i=0;i<n;i++)
				 for (j=0;j<n;j++)
					 if (a[i][k]+a[k][j]<a[i][j]) {
						 a[i][j]=a[i][k]+a[k][j];
						 d[i][j]=k;
					 }
		 if (ttt==-1) ttt=a[x][y];
		 if (a[x][y]!=ttt) break;
		 if (a[x][y]>=100000000) break;		 
		 rec(x,y);
		 kol++;

	}	
	cout << kol << endl;
	for (i=0;i<kol;i++) 
	{		
		for (j=0;j<=r[i][0];j++) cout << r[i][j] << " ";
		cout << endl;
	}
	return 0;
}

