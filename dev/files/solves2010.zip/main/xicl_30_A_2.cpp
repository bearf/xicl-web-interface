#define _CRT_SECURE_NO_DEPRECATE

#include<stdio.h>
#include<math.h>
#include<string>
#include<string.h>
#include<vector>
#include<set>
#include<map>
#include<algorithm>
#include<time.h>
#include<memory.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)
#define ZERO(x) memset(x, 0, sizeof(x))
#define SIZE(x) (int)x.size()

typedef long long int64;

int64 how_many(int n, int m, int a, int b, int c) {
	int64 res = 0;
	int64 pseudo;
	int mnac = max(a, c);
	for (int ay = 0; ay < n; ay++) {
	for (int ax = 0; ax < m; ax++) {
		for (int by = ay + mnac +  1; by < n; by++) {
			for (int bx = ax + b +1; bx < m; bx++) {
				pseudo = bx - ax - 1;
				pseudo *= bx - ax - b;
				pseudo *= by - ay - a;
				pseudo *= by - ay - c;
				res += pseudo;
			}
		}
	}
	}

	return res;
}

int main() {

	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	int n, m, a, b, c;

	scanf("%d%d%d%d%d", &n, &m, &a, &b, &c);

	printf("%lld\n", how_many(n, m, a, b, c));

	return 0;
}
