#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <math.h>
#include <time.h>
#pragma comment (linker,"/STACK:32000000")
using namespace std;
long long p[10005]={0};
long long st[10005]={0};
int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long n,k,s = 0,tmp,i,j;
	cin >> n >> k;
	tmp = k;
	for (i=2;i<=k/2;i++)
	{
		if (tmp % i==0)
		{
			p[0]++;
			p[p[0]] = i;
			while (tmp % i==0)
			{
				st[p[0]]++;
				tmp /= i;
			}
		}
	}
	if (tmp!=1)
	{
		p[0]++;
		p[p[0]] = tmp;
		st[p[0]] = 1;
	}

	long long mn = -1;
	for (i=1;i<=p[0];i++)
	{
		s = 0;
		tmp = n;
		while (1)
		{
			s += (tmp / p[i]);
			tmp = tmp / p[i];
			if (tmp==0)
				break;
		}
		if (mn==-1 || (s / (st[i] * k)) < mn)
			mn  = s / (st[i] * k);
	}
	cout << mn;


	return 0;
}
