#pragma comment( linker, "/stack:32000000" )
#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>

#define filein ""

void prepare( )
{
	freopen( "input.txt", "r", stdin );
#ifndef _DEBUG
	freopen( "output.txt", "w", stdout ); 
#endif
}

#include <cmath>
#include <cassert>
#include <memory.h>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>
#include <ctime>
#include <deque>

using namespace std;

#define fo(a,b,c) for(a=(b);a<(c);++a)
#define fr(a,b) fo(a,0,(b))
#define fi(a) fr(i,(a))
#define fj(a) fr(j,(a))
#define fk(a) fr(k,(a))
#define all(a) (a).begin(),(a).end()
#define sz(a) (int)(a).size()
#define pb push_back
#define mp make_pair
#define _(a,b) memset((a),(b),sizeof(a))
#define __(a) _((a),0)

typedef long long lint;

const int MAXN = 200005;

int n, m;
int a[MAXN];
int b[MAXN];
lint v[MAXN];
int x;
set<pair<lint, int > > q;

void print( int id )
{
	if ( a[id] < 0 )
	{
		printf( "%d", id + 1 );
		return;
	}
	printf( "(" );
	print( a[id] );
	printf( "." );
	print( b[id] );
	printf( ")" );
}

bool test( lint a, lint b )
{
	if ( a * x >= b && a <= b * x )
		return true;
	return false;
}

int main( )
{
	prepare( );
	int i, j, k;
	scanf( "%d %d", &n, &x );
	if ( n == 1 )
	{
		printf( "no\n" );
		return 0;
	}
	m = n;
	fi( n )
	{
		scanf( "%d", &j );
		v[i] = j;
		a[i] = -1;
		b[i] = -1;
		q.insert( mp( v[i], i ) );
	}
	fi( n - 1 )
	{
		int id1 = q.begin( )->second;
		q.erase( q.begin( ) );
		int id2 = q.begin( )->second;
		q.erase( q.begin( ) );
		if ( test( v[id1], v[id2] ) )
		{
			a[m] = id1;
			b[m] = id2;
			v[m] = v[id1] + v[id2];
			q.insert( mp( v[m], m ) );
			++ m;
		}
		else
			break;
	}
	if ( i < n - 1 )
	{
		printf( "no\n" );
		return 0;
	}
	print( q.begin( )->second );
	printf( "\n" );
	return 0;
}