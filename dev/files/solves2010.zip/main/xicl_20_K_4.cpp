#include <fstream>
#include <vector>

using namespace std;
fstream fin,fout;

class CompleX{
	public:
		int n,count;
		CompleX(int n1,int k1){
			n = n1;
			count = k1;
			}
	};

vector<CompleX> dat, raz;

void addTo(vector<CompleX> & raz,int n){
	for(int i=0;i<raz.size();i++)
		if(raz[i].n==n){
			raz[i].count++;
			return;
			}
	raz.push_back(CompleX(n,1));
	}

void declay(__int64 n,vector<CompleX> & raz){
	while(n!=1){
		for(int i=2;i<=n;i++)
			if(n%i==0){
				addTo(raz,i);
				n/=i;
				i = n+1;
				}
		}
	}

__int64 n,k;

void dbg(vector<CompleX> & raz){
	for(int i=0;i<raz.size();i++)
		fout << '{' << raz[i].n <<", " << raz[i].count << "} ";
	fout << endl;
	}

bool delTo(vector<CompleX> & dat, CompleX & x){
	for(int i=0;i<dat.size();i++)
		if(dat[i].n == x.n){
			if(dat[i].count >= x.count){
				dat[i].count-=x.count;
				return true;
			    }else
				return false;
			}
			
	return false;
	}

bool iter(vector<CompleX> & dat,vector<CompleX> & re){
	for(int i=0;i<re.size();i++){
		if(!delTo(dat,re[i]))
			return false;
		}
	return true;
	}

void wrk(){
	int n = 0;
	while(iter(dat,raz)){
		n++;
		}
	fout << n << endl;
	}

void mulE(vector<CompleX> & dat){
	for(int i=0;i<dat.size();i++){
		dat[i].count*=k;
		}
	}

int main(void){
	fin.open("./input.txt",fstream::in);
	fout.open("./output.txt",fstream::out);

	fin >> n >> k;

	declay(k,raz);
	mulE(raz);

	for(int i=2;i<=n;i++)
	  declay(i,dat);
	
	//dbg(raz);
	//dbg(dat);

	wrk();


	fin.close();
	fout.close();
	return 0;
	}
