#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <math.h>
#include <time.h>
#pragma comment (linker,"/STACK:32000000")
using namespace std;
const int maxn = 1010;
struct pnt{
	int x;
	int y;
	int next;
};
pnt mas[maxn*10];
int sq(pnt p0, pnt p1, pnt p2)
{
	int res = (p2.y-p0.y) * (p1.x-p0.x) - (p2.x-p0.x) * (p1.y-p0.y);
	if (res>0)
		return 1;
	else if (res<0)
		return -1;
	else return 0;
}
bool ins(pnt p0, pnt p1, pnt p2, pnt a)
{
	int s1,s2,s3;
	s1 = sq(p0,p1,a);
	s2 = sq(p1,p2,a);
	s3 = sq(p2,p0,a);
	if (s1*s2>0 && s1*s3>0 && s2*s3>0)
		return true;
	return false;
}
int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int i,j,n;
	pnt a,b;
	scanf("%d",&n);
	for (i=1;i<=n;i++)
	{
		scanf("%d %d",&mas[i].x,&mas[i].y);
		mas[i].next = i+1;
	}
	mas[n].next = 1;
	scanf("%d %d",&a.x,&a.y);
	scanf("%d %d",&b.x,&b.y);
	int pos = 1;
	pnt A,B,C;
	while (n>4)
	{
		A = mas[pos];
		B = mas[A.next];
		C = mas[B.next];
		if (!ins(A,B,C,a) && !ins(A,B,C,b))	
		{
			mas[pos].next = mas[mas[pos].next].next;
			n--;
		}
		else pos = mas[pos].next;
	}
	printf("%d %d\n",mas[pos].x,mas[pos].y);
	pos = mas[pos].next;
	printf("%d %d\n",mas[pos].x,mas[pos].y);
	pos = mas[pos].next;
	printf("%d %d\n",mas[pos].x,mas[pos].y);
	pos = mas[pos].next;
	printf("%d %d",mas[pos].x,mas[pos].y);

	return 0;
}
