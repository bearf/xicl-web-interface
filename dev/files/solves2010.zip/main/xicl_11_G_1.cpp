#include <stdio.h>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <queue>
#include <deque>
#include <cassert>
#include <memory.h>
#include <algorithm>
#include <math.h>
#include <sstream>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) ((int)(a.size()))

const int INF = 2000000000;

void prepare()
{
	freopen("input.txt", "r", stdin);
#ifndef _DEBUG
	freopen("output.txt", "w", stdout);
#endif
}

struct vec2
{
	int x, y;
	vec2(int x, int y): x(x), y(y) {}
	vec2() {}
	void scan() { scanf("%d%d", &x, &y); }
};
vec2 operator - (const vec2 &a, const vec2 & b)
{
	return vec2(a.x - b.x, a.y - b.y);
}
int operator ^ (const vec2 &a, const vec2 &b)
{
	return a.x * b.y - a.y * b.x;
}

int n;
vec2 a, b;
vec2 p[1005];

inline int test(const vec2 &a, const vec2 &p1, const vec2 &p2)
{
	int v = (p2 - p1) ^ (a - p1);
	if (v < 0) v = -1;
	if (v > 0) v = 1;
	return v;
}

int next(int first, int cur, int k)
{
	int i = cur + 1;
	if (i == n) i = 0;

	int last = first + k;
	if (last < 0) last += n;

	int _g1 = test(a, p[cur], p[i]);
	int _g2 = test(b, p[cur], p[i]);
	//i++; if (i == n) i = 0;

	while (i != last)
	{
		int g1 = test(a, p[cur], p[i]);
		int g2 = test(b, p[cur], p[i]);
		if ((g1 != 0 && _g1 != g1) || (g2 != 0 && _g2 != g2))
			break;
		i++; if (i == n) i = 0;
	}

	int ret = i - 1;
	if (ret < 0) ret += n;
	return ret;
}

int ans[5];
void go()
{
	for (int i = 0; i < n; i++)
	{
		int cur = i;

		for (int j = 0; j < 4; j++)
		{
			ans[j] = cur;
			cur = next(i, cur, j - 2);
		}

		if (cur == i)
		{
			for (int j = 0; j < 4; j++)
				printf("%d %d\n", p[ans[j]].x, p[ans[j]].y);
			break;
		}
	}
}

bool solve()
{
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		p[i].scan();
	a.scan();
	b.scan();

	go();

	return false;
}

int main()
{
	prepare();
	while (solve());
	return 0;
}

