import java.io.*;
import java.util.Scanner;

public class Solution
{
	public static void main(String[] args) throws IOException
	{
		Scanner in2;
		PrintWriter out;

		out = new PrintWriter(new BufferedWriter(new FileWriter("output.txt")));
//		out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
		
		in2 = new Scanner(new BufferedReader(new FileReader("input.txt")));
//		in2 = new Scanner(new BufferedReader(new InputStreamReader(System.in)));
		
		long n = in2.nextLong(), m = in2.nextLong(), a = in2.nextLong(), b = in2.nextLong(), c = in2.nextLong(), A, B, C, D;
		
		long sum = 0;
		long r;
		for (long M=1;M<=m;M++)
		{
			for (long N=1;N<=n;N++)
			{
				r = (n-N+1)*(m-M+1);
				A = (N-2)-a+1;
/**/			B = (M-2)-b+1;
/**/			C = (N-2)-c+1;
				D = M-2;
				
/*				if (b>1)
					B++;
				if (c>1)
					C++;
				s = 0;
				for (long dl=c;dl<n;dl++)
				{
					for (long dp=b;dp<n;dp++)
					{
						s += Math.min(dp, dl) - 1;
					}
				}
				D *= s;*/
				
				if (A>0 && B>0 && C>0 && D>0)
				{
					sum += r*A*B*C*D;
				}
			}
		}
		
		
		
		
		
		out.print(sum);
		out.close();
	}
}