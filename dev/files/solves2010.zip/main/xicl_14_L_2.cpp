#include <iostream>
#include <cstdio>
#include <vector>
#include <sstream>
#include <string>
#include <map>
#include <set>
#include <algorithm>
//#include <cmath>

using namespace std;

#define bublic public
#define sz size()
#define clr(a) memset(a,0,sizeof(a))
#define ll long long
#define ld long double
#define istr istringstream
#define pb push_back
#define mp make_pair
#define forn(i,n) for(int i=0; i<n; i++)

const ld EPS=1e-9;
const ld PI=3.1415926535897932384626433832795;
const int INF=2000000000;

ll n,x,k,z;
vector <ll> v[500000];
set < pair < ll,ll > > S;

void rec(ll x)
{
    if (!v[x].sz)
    {
        printf("%d",x+1);
        return;
    }
    printf("(");
    rec(v[x][0]);
    printf(".");
    rec(v[x][1]);
    printf(")");    
}

int main()
{
    freopen("input.txt","rt",stdin);
    freopen("output.txt","wt",stdout);    
    cout.flags(ios::fixed);
    cout.precision(10);
    cin>>n>>x;
    k=0;
    for(int i=0;i<n;i++)
    {
        scanf("%d",&z);
        S.insert(mp(z,k));
        k++;
    }
    while(S.sz>1)
    {
        pair <ll, ll> p=*S.begin();
        S.erase(S.begin());
        pair <ll, ll> pp=*S.begin();        
        S.erase(S.begin());
        ll a=p.first,b=pp.first;
        if (a>b) swap(a,b);
        if (a*x<b)
        {
            cout<<"no";
            return 0;
        }        
        v[k].pb(p.second);
        v[k].pb(pp.second);
        S.insert(mp(a+b,k));
        k++;
    }
    pair <ll, ll> p=*S.begin();    
    rec(p.second);
//    cout<<p.first<<" ";
    
    return 0;
}
