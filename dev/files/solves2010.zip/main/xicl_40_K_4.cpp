#include <stdio.h>
#include <conio.h>

int main()
{
	int i, n=0, k=0, m=0, z=0, x=0;
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);

	scanf("%d %d",&n,&k);

	int prost[500],kol[500],count[500]={0},prc;
	z=k;
	prc=0;
	if (z%2==0) {
		z/=2;
		kol[prc]=1;
		prost[prc]=2;
		while ((z%2==0)&&z>0) {
			kol[prc]++;
			z=z/2;
		}
		prc++;
	}
	m=3;
	while (z>1) {
		if (z%m==0) {
			z/=m;
			kol[prc]=1;
			prost[prc]=m;
			while ((z%m==0)&&z>0) {
				kol[prc]++;
				z=z/m;
			}
		prc++;
		}
		m=m+2;
	}
	/*for (i=0;i<prc;i++)
		printf("%d:%d ",prost[i],kol[i]);*/
	
	int j;
	for (j=0;j<prc;j++) {
		m=prost[j];
		for(i=m;i<=n;i+=m)
			{
				z=i/m;
				count[j]++;
				while ((z%m==0)&&z>0) {
					count[j]++;
					z=z/m;
			}
		}
	}
	
	int min=1000000;
	for (j=0;j<prc;j++) {
		m=count[j]/kol[j];
		if (m<min) min=m;
	}
	
	x=min/k;

	printf("%d",x);
	//getch();
	return 0;
}
