import java.util.*;
import java.awt.geom.*;
import java.math.*;
import static java.lang.Math.*;
import java.io.*;

public class Solution implements Runnable {

	static BufferedReader br = null;
	static PrintWriter pw = null;
	static StringTokenizer stk = new StringTokenizer("");

	public static void main(String[] args) throws FileNotFoundException {
		br = new BufferedReader(new FileReader("input.txt"));
		pw = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}

	void nline() {
		try {
			stk = new StringTokenizer(br.readLine());
		} catch (IOException e) {
			throw new RuntimeException("No new line");
		}
	}

	String nwrd() {
		while (!stk.hasMoreElements())
			nline();
		return stk.nextToken();
	}

	int ni() {
		return Integer.valueOf(nwrd());
	}

	long nl() {
		return Long.valueOf(nwrd());
	}

	double nd() {
		return Double.valueOf(nwrd());
	}

	char nc() {
		return nwrd().charAt(0);
	}

	boolean isReady() {
		try {
			return br.ready();
		} catch (IOException e) {
			throw new RuntimeException("Something wrong in br");
		}
	}

	public void solve() {
		int n = ni();
		int m = ni();
		int a = ni();
		int b = ni();
		int c = ni();
		long ans = 0;
		for (int i = 0; i < n; i++)
			for (int j = 0; j < m; j++)
				for (int k = j + 1; k < m; k++)
					for (int t = i + 1; t < n; t++) {
						long a1 = k - j - a;
						long b1 = t - i - b;
						long c1 = t - i - c;
						long d1 = k - j - 1;
						if (a1 * b1 * c1 * d1 > 0)
							ans += a1 * b1 * c1 * d1;
					}
		pw.println(ans);
	}

	public void run() {
		solve();
		pw.close();
	}

}
