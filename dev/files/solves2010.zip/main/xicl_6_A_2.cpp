// ablyad.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include <stdio.h>
#include <iostream>
using namespace std;
int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long n,m,a,b,c,i,j,z,k;
	long long res;
	cin >> n >> m >> a >> b >> c;
	res=0;
	for (i=1;i<=n;i++) 
		 for (j=1;j<=n;j++)
			 for (k=i;k<=m;k++)
				 for (z=j;z<=m;z++)
					 if ((i>=b)&&(n-z>=1)&&(j>=a)&&(m-k>=c)) res+=(i-k)*(z-j)*(i-k)*(z-j);
	cout << res;
	return 0;
}

