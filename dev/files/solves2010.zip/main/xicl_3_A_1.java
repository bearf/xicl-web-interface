import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {
	static public void main(String[] args) throws IOException {
		new Solution().run();
	}
	StreamTokenizer in;
	PrintWriter out;
	void run() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		//solve();
		solve1();
		out.flush();
	}
	
	void solve1() throws IOException {
		int n = ni(), m = ni(), a = ni(), b = ni(), c = ni();
		BigInteger res = BigInteger.ZERO;
		int last = n - 1 - Math.max(a, c);
		for(int i = 0; i < last; i++) {
			for(int j = 1; j < m - b; j++) {
				for(int k = Math.max(a, c); k < n; k++) {
					int right = (k-i-c)*(m-j-b);
					int left = (k-i-a)*j;
					res = res.add(new BigInteger(Long.toString(left*right*b)));
					res = res.add(new BigInteger(Long.toString(right*(((j-1)*left)/2))));
					res = res.add(new BigInteger(Long.toString((right*left*(m-j-b-1))/2)));
				}
			}
		}
		out.print(res);
	}
	
	void solve() throws IOException 
	{
		int n = ni(), m = ni(), k = ni();
		char a[][] = new char[2*n][2*m];
		for(int i = 0; i < 2 * n ; ++i)
			Arrays.fill(a[i], '.');
		for(int i = 0; i < 2 * n ; ++i)
			a[i][0] = a[i][2*m-1] = '-';
		for(int i = 0; i < 2 * m ; ++i)
			a[0][i] = a[2*n-1][i] = '-';
		
		int sx = 2*ni()-1, sy = 2*ni()-1;
		char dir =(char) ns();
		for(int i = 0; i < k; ++i){
			int y1 = ni(), x1 = ni(), y2 = ni(), x2 = ni();
			if ( x1 == x2 ) {
				int ny1 = 2 * Math.min(y1, y2) ;
				int ny2 = 2 * Math.max(y1, y2) ;
				for(int j = ny1; j <= ny2; ++j)
					a[j][2*x1] = '-';
				
			} else {
				int nx1 = 2 * Math.min(x1, x2) ;
				int nx2 = 2 * Math.max(x1, x2) ;
				for(int j = nx1; j <= nx2; ++j)
					a[2*y1][j] = '-';
			}
		}
		for(int i = 0 ; i < 2*n; ++i){
			for(int j = 0; j < 2*m; ++j )
				out.print(a[i][j]);
			out.print("\n");
		}
		
	}
	int ni() throws IOException {
		in.nextToken();
		return (int)in.nval;
	}
	char ns() throws IOException {
		in.nextToken();
		return in.sval.charAt(0);
	}
}
