#include <iostream>
#include <cmath>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <sstream>
#include <string>
#include <algorithm>
#include <functional>
#include <numeric>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define ford(i, n) for(int i = int(n) - 1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define X first
#define Y second

typedef long double ld;
typedef long long li;
typedef pair<int, int> pt;

const int INF = (int)1E9;
const ld EPS = (1E-9);

const int NMAX = 1000;

const int dx[] = {0, 1,  0, -1};
const int dy[] = {1, 0, -1,  0};

int sign(int a){
	if(a == 0)
		return 0;
	if(a > 0)
		return 1;
	if(a < 0)
		return -1;
}

int n, m;
bool wall[4][110][110], used[4][110][110];

bool check(const pt& a){
	return 1 <= a.X && a.X <= m && 1 <= a.Y && a.Y <= n;
}

void update(const pt& a, int d){
	if(check(a))
		wall[d][a.X][a.Y] = true;
}

void fillWall(const pt& a, const pt& b){
	int x = a.X, y = a.Y;
	int vx = sign(b.X - a.X), vy = sign(b.Y - a.Y);
	int d = -1;

	forn(i, 4)
		if(vx == dx[i] && vy == dy[i]){
			d = i;
			break;
		}

	if(d == -1)
		throw 1;

	pt cur(a.X, a.Y);

	while(cur.X != b.X || cur.Y != b.Y){	
		
		switch(d){
			case 0:
				update(pt(cur.X + 1, cur.Y + 1), 3);
				update(pt(cur.X, cur.Y + 1), 1);
				break;

			case 1:
				update(pt(cur.X + 1, cur.Y + 1), 2);
				update(pt(cur.X + 1, cur.Y), 0);
				break;

			case 2:
				update(pt(cur.X, cur.Y), 1);
				update(pt(cur.X + 1, cur.Y), 3);
				break;

			case 3:
				update(pt(cur.X, cur.Y), 0);
				update(pt(cur.X, cur.Y + 1), 2);
				break;
		};

		cur.X += dx[d]; cur.Y += dy[d];
	}

}

int ans;
void go(int d, int x, int y){
	if(used[d][x][y])
		return;
	used[d][x][y] = true;

	if(!check(pt(x, y))){
		cout << "YES" << endl << ans << endl;
		exit(0);
	}

	if(wall[d][x][y]){
		go((d + 3)%4, x, y);
		return;
	}

	if(wall[(d + 1)%4][x][y]){
		++ans;
		go(d, x + dx[d], y + dy[d]);
		return;
	}

	int nd = (d + 1)%4;
	++ans;
	go(nd, x + dx[nd], y + dy[nd]);
}

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
		
	int k;
	cin >> n >> m >> k;

	int sd, sx, sy;
	{
		char c;
		cin >> sy >> sx >> c;

		switch(c){
			case 'N':
				sd = 0;
				break;
			case 'E':
				sd = 1;
				break;
			case 'S':
				sd = 2;
				break;
			case 'W':
				sd = 3;
				break;

			default:
				throw 1;
		};
	}

	memset(wall, 0, sizeof(wall));

	fillWall(pt(0, 0), pt(0, n));
	fillWall(pt(0, 0), pt(m, 0));
	fillWall(pt(0, n), pt(m, n));
	fillWall(pt(m, 0), pt(m, n));
	
	forn(i, k){
		pt st, fn;
		cin >> st.X >> st.Y >> fn.X >> fn.Y;

		fillWall(st, fn);
	}

	wall[3][1][2] = false;

	memset(used, 0, sizeof(used));
	ans = 0;
	go(sd, sx, sy);

	cout << "NO" << endl;

	return 0;
}