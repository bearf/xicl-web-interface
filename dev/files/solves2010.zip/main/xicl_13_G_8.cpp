#include <fstream>
#include <math.h>

using namespace std;

ifstream cin("input.txt");
ofstream cout("output.txt");

int vp (int x1, int x2, int y1, int y2)
{
	return x1*y2 - x2*y1;
}

double abv(int x, int y)
{
	return sqrt(double(x*x + y*y));
}

class point
{
public:
	point(int x1, int y1)
	{
		x = x1;
		y = y1;
	}
	int x,y;
	point * next;
};

int main()
{
	int n;
	point *first, *tmp, *tmp1;

	cin >> n;
	int x,y;
	cin >> x >> y;
	first = new point(x,y);
	tmp = first;
	for (int i=1;i<n;i++)
	{
		cin >> x >> y;
		tmp1 = new point(x,y);
		tmp->next = tmp1;
		tmp = tmp1;
	}
	tmp->next = first;
	cin >> x >> y;
	point q(x,y);
	cin >> x >> y;
	point w(x,y);

	int len = n;

	tmp = first->next;
	//tmp1 = first->next->next;

	while (len > 4)
	{
		tmp1 = tmp->next->next;
		int v1 = vp(tmp1->x - tmp->x, tmp1->y - tmp->y, q.x - tmp->x, q.y - tmp->y);  
		int v2 = vp(tmp1->x - tmp->x, tmp1->y - tmp->y, w.x - tmp->x, w.y - tmp->y);

		double d1 = v1/abv(tmp1->x - tmp->x, tmp1->y - tmp->y)/abv(q.x - tmp->x, q.y - tmp->y);
		double d2 = v2/abv(tmp1->x - tmp->x, tmp1->y - tmp->y)/abv(w.x - tmp->x, w.y - tmp->y);
		if ((v1 <= 0 || abs(d1) <= 0.0001) && (v2 <= 0 || abs(d2) <= 0.0001))
		{
			tmp->next = tmp1;
			len--;
		}
		else
		{
			tmp = tmp->next;
		}
	}

	for (int i = 1; i<= 4; i++)
	{
		cout << tmp->x << " " << tmp->y << "\n";
		tmp = tmp->next;
	}
	cin.close();
	cout.close();
	return 0;
}