#include <fstream>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");
long long pr[50];
long long st[50];
long long ans[50];
int main() {
	long long n, k;
	cin >> n >> k;
	int l = 0;
	long long kk = k;
	for (int j = 2; j * j <= kk; j++) {
		if (kk % j == 0) {
			while (kk % j == 0) {
				pr[l] = j;
				st[l]++;
				kk /= j;
			}
			l++;
		}
	}
	if (kk > 1) {
		pr[l] = kk;
		st[l++] = 1;
	}
	long long minn = -1;
	for (int i = 0; i < l; i++) {
		long long nn = n;
		while (nn > 0) {
			ans[i] += nn / pr[i];
			nn /= pr[i];
		}
		ans[i] /= st[i];
		if (minn == -1 || ans[i] < minn) minn = ans[i];
	}
	cout << minn / k;
	return 0;
}