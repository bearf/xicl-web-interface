import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class Solution {
	private static int a, b, c;

	public static void main(String[] args) throws Exception {
		Scanner in = new Scanner(new File("input.txt"));
		PrintWriter out = new PrintWriter("output.txt");
		int n = in.nextInt();
		int m = in.nextInt();
		a = in.nextInt();
		b = in.nextInt();
		c = in.nextInt();

		final long result = solve(n, m);
		out.println(result);

//		for (m = 1; m < 100; ++m) {
//			long a = solve(n, m);
//			System.out.println(m + ": " + a);
//		}

		out.close();
	}

	private static long solve(int n, int m) {
		long sum = 0;
		for (int i = 1; i <= n - 2; ++i) {
			for (int j = 1; j <= m - 2; ++j) {
				sum += sub1(i, j) * (n - 1 - i) * (m - 1 - j);
			}
		}
		return sum;
	}

	private static long sub1(int n, int m) {
		if (a > n || b > m || c > n) {
			return 0;
		} else {
			return (n - a + 1) * (m - b + 1) * (n - c + 1) * m;
		}
	}

	// public static void main(String[] args) throws Exception {
	// Scanner in = new Scanner(new File("input.txt"));
	// PrintWriter out = new PrintWriter("output.txt");
	// int n = in.nextInt();
	// int m = in.nextInt();
	// a = in.nextInt();
	// b = in.nextInt();
	// c = in.nextInt();
	//
	// final long result = solve(n, m);
	// out.println(result);
	//
	// out.close();
	// }
	//
	// private static long solve(int n, int m) {
	// long sum = 0;
	// for (int i = 0; i < n; ++i) {
	// for (int j = 0; j < m; ++j) {
	// sum += sub1(n - i, m - j);
	// }
	// }
	// return sum;
	// }
	//
	// private static long sub1(int n, int m) {
	// if (m <= b || n <= a) {
	// return 0;
	// }
	// long sum = 0;
	// for (int x = b; x < m; ++x) {
	// sum += sub2(n - 1, m - 1, x - 1) * (n - a - 1);
	// }
	// return sum;
	// }
	//
	// private static long sub2(int n, int m, int x) {
	// long sum = 0;
	// for (int i = x + 1; i < m; ++i) {
	// for (int j = c - 1; j < n; ++j) {
	// sum += (n - j - 1) * i;
	// }
	// }
	// return sum;
	// }

}
