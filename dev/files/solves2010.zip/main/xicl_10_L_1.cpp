#include <iostream>
#include <cmath>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <sstream>
#include <string>
#include <algorithm>
#include <functional>
#include <numeric>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define ford(i, n) for(int i = int(n) - 1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define X first
#define Y second

typedef long double ld;
typedef long long li;
typedef pair<int, int> pt;

const int INF = (int)1E9;
const ld EPS = (1E-9);

const int NMAX = 1000;

set<pair<li, string> > s;

string toStr(int a){
	string ans;
	while(a > 0){
		ans += char(a % 10 + '0');
		a /= 10;
	}
	reverse(ans.begin(), ans.end());
	return ans;
}

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int n, x;
	cin >> n >> x;
	if(n == 1){
		cout << "no" << endl;
		return 0;
	}
	forn(i, n){
		int cur;
		scanf("%d", &cur);
		s.insert(mp(cur, toStr(i + 1)));
	}
	
	while(sz(s) > 1){
		pair<li, string> fs = *s.begin();
		s.erase(s.begin());
		pair<li, string> sc = *s.begin();
		s.erase(s.begin());

		if(fs.X * x >= sc.X){
			pair<li, string> nn(fs.X + sc.X, "(" + fs.Y + "." + sc.Y + ")");
			s.insert(nn);
		}else{
			puts("no");
			exit(0);
		}
	}
	
	printf("%s\n", (s.begin()->Y).c_str());	
	return 0;
}