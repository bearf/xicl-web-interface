#include <iostream>
#include <cmath>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <sstream>
#include <string>
#include <algorithm>
#include <functional>
#include <numeric>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define ford(i, n) for(int i = int(n) - 1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define X first
#define Y second

typedef long double ld;
typedef long long li;
typedef pair<int, int> pt;

const int INF = (int)1E9;
const ld EPS = (1E-9);

const int NMAX = 1000;

struct edge{
	int to, f, c, rev;
};

int n, m, st, fn;
vector<edge> g[110];
int has[110][110];
int d[110][110];

void addEdge(int fr, int to, int c){
	edge forv = {to, 0, c, sz(g[to])};
	edge back = {fr, 0, 0, sz(g[fr])};
	g[fr].push_back(forv);
	g[to].push_back(back);
}

int flow;
int p[110], pe[110];

bool enlarge(int s, int t){
	memset(p, -1, sizeof(p));
	p[s] = s;
	queue<int> q;
	q.push(s);

	while(!q.empty() && p[t] == -1){
		int v = q.front();
		q.pop();

		forn(i, sz(g[v])){
			int to = g[v][i].to;

			if(g[v][i].c - g[v][i].f > 0 && p[to] == -1){
				p[to] = v;
				pe[to] = i;
				q.push(to);
			}
		}
	}

	if(p[t] == -1)
		return false;

	int v = t;
	while(v != s){
		int fr = p[v];
		int i = pe[v];

		g[fr][i].f++;
		g[v][g[fr][i].rev].f--;

		v = fr;
	}

	flow++;
	return true;
}

vector<int> cur;

void dfs(int v){
	cur.push_back(v);
	forn(i, sz(g[v])){
		if(g[v][i].f == 1){
			g[v][i].f--;
			g[g[v][i].to][g[v][i].rev].f++;

			dfs(g[v][i].to);
			break;
		}
	}
}

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	cin >> n >> m >> st >> fn;
	st--; fn--;

	if(n == 1 || st == fn){
		puts("0");
		return 0;
	}

	forn(i, n){
		forn(j, n)
			d[i][j] = INF;
		d[i][i] = 0;
	}
	memset(has, -1, sizeof(has));

	forn(i, m){
		int x, y, z;
		scanf("%d%d%d", &x, &y, &z);
		x--; y--;
	
		has[x][y] = z;
		d[x][y] = min(d[x][y], z);
	}

	forn(t, n)
		forn(i, n)
			forn(j, n)
				d[i][j] = min(d[i][j], d[i][t] + d[t][j]);
	
	forn(i, n)
		forn(j, n){
			if(i != j && 
			   d[st][i] < INF / 2 && d[j][fn] < INF / 2 && 
			   d[st][i] + d[i][j] + d[j][fn] == d[st][fn] && has[i][j] == d[i][j])

				addEdge(i, j, 1);
		}

	flow = 0;
	while(enlarge(st, fn));

	cout << flow << endl;

	forn(i, flow){
		cur.clear();
		dfs(st);

		printf("%d ", sz(cur));
		forn(j, sz(cur))
			printf("%d ", cur[j] + 1);
		puts("");
	}

	return 0;
}