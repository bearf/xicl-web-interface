#include <iostream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <cmath>
#include <sstream>
#include <cstring>
#include <string>

#define re return
#define mp make_pair
#define pb push_back
#define rep(i,n) for (int i = 0; i < n; i++)
#define fi first
#define se second
#define sz(x) ((int) (x).size())
#define all(x) ((x).begin(), (x).end())
#define fill(x, y) memset(x, y, sizeof(x))
#define y0 y49743
#define y1 y47543

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef long long ll;
typedef long double ld;
typedef vector<string> vs;

int n;
int m;
int x, y, d;
char c;
int a[200][200];
int q[200][200][5];
int x1, y1, x2, y2;
int k;
int p[4][4] = {{1,2,4,8}, {2,4,8,1}, {4,8,1,2}, {8,1,2,4}};
int s;

int matr[100][100];

void add_v(int x, int y1, int y2){
	for (int i = y1 + 1; i <= y2; ++i){
		a[i][x] |= 8;
		a[i][x + 1] |= 2;
	}
}

void add_h(int y, int x1, int x2){
	for (int i = x1 + 1; i <= x2; ++i){
		a[y][i] |= 4;
		a[y + 1][i] |= 1;
	}
}

void make_step(){
	++s;
	if (d == 0){
		--y;
	}
	if (d == 1){
		--x;
	}
	if (d == 2){
		++y;
	}
	if (d == 3){
		++x;
	}
}

void next_step(){
	if (a[y][x] & p[d][0]){
		d = (d + 3) % 4;
	//	++s;
		return;
	}
	if (a[y][x] & p[d][1]){
		make_step();
	//	++s;
		return;
	}
	d = (d + 1) % 4;
	make_step();
	//s += 1;
}


int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> n >> m >> k;
	cin >> y >> x >> c;
	if (c == 'W') d = 1;
	if (c == 'S') d = 0;
	if (c == 'N') d = 2;
	if (c == 'E') d = 3;
//cout << x << " " << y << " " << d << endl;

	add_v(0,0,1);
	add_v(0,2,n);
	add_v(m,0,n);
	add_h(0,0,m);
	add_h(n,0,m);

/*	for(int i = n; i >= 1; --i){
		for (int j = 1; j <= m; ++j)
			cout << a[i][j] << " ";
		cout << endl;
	}
*/
	for (int i = 0; i < k; ++i){
		cin >> x1 >> y1 >> x2 >> y2;
		if (x1 == x2) add_v(x1, y1, y2);
		if (y1 == y2) add_h(y1, x1, x2);
	}
/*
	for(int i = n; i >= 1; --i){
		for (int j = 1; j <= m; ++j)
			cout << a[i][j] << " ";
		cout << endl;
	}
*/
	q[x][y][d] = true;
	s = 0;
	while(true){
		next_step();
//cout << x << " " << y << " " << d << endl;
//		++s;
		if (x == 0&& y == 2){
			cout << "YES" << endl << s;
			return 0;
		}
		if (q[x][y][d]){
				cout << "NO";
				return 0;
		}
		q[x][y][d] = true;
	}

	re 0;
}