import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {
	static public void main(String[] args) throws IOException {
		new Solution().run();
	}
	StreamTokenizer in;
	PrintWriter out;
	void run() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		solve();
		out.flush();
	}
	
	void solve() throws IOException 
	{
		int n = ni();
		int k = ni();
		int min=1000000;
		int j=k;
		int[] ks = new int[Math.max(k + 1, n + 1)];
		int[] ns = new int[Math.max(k + 1, n + 1)];
		for(int i = 2; i <= j; i++) 
		{
			if(k%i==0)
			{
				int y=0;
				while(k%i==0)
				{
					k=k/i;
					y++;
				}
			int l=i;
			int st=0;
			while(n>=l)
			{
				st+=n/l;
				l=l*i;
			}
			if(st/y<min)
				min=st/y;
			}
		}
		out.print(min/j);
	}
	int ni() throws IOException {
		in.nextToken();
		return (int)in.nval;
	}
}
