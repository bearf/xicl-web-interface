#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <math.h>
#include <time.h>
#pragma comment (linker,"/STACK:32000000")
using namespace std;
const int maxn = 120;
int was[maxn*2][maxn*2][4]={0};
int mas[maxn*2][maxn*2]={0};

int dx[5]={0,1,0,-1};
int dy[5]={1,0,-1,0};
void col(int x1, int y1, int x2, int y2, int val)
{
	int i,j;
	if (x2<x1)
		swap(x1,x2);
	if (y2<y1)
		swap(y1,y2);

	for (i=2*x1;i<=2*x2;i++)
	{
		for (j=2*y1;j<=2*y2;j++)
		{
			mas[i][j] = val;
		}
	}
}

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int n,m,k,i,j,sx,sy;
	char sn;
	cin >> n >> m >> k;
	cin >> sx >> sy >> sn;
	
	int x1,y1,x2,y2;
	for (i=1;i<=k;i++)
	{
		cin >> y1 >> x1 >> y2 >> x2;
		x1 = n - x1;
		x2 = n - x2;
		col(x1,y1,x2,y2,1);
	}

	col(0,0,0,m,1);
	col(n,0,n,m,1);
	col(0,0,n,0,1);
	col(0,m,n,m,1);

	col(n-1,0,n-2,0,0);


	/*for (i=0;i<=2*n;i++)
	{
		for (j=0;j<=2*m;j++)
			cout << mas[i][j];
		cout << "\n";
	}*/


	sx = n - sx + 1;
	sx = sx * 2 - 1;
	sy = sy * 2 - 1;

	int tx,ty,x = sx,y = sy,nap,tnap,tx2,ty2;
	if (sn=='N')
		nap = 3;
	else if (sn=='S')
		nap = 1;
	else if (sn=='E')
		nap = 0;
	else nap = 2;
	
	int cnt = 0; 
	while (1)
	{
		if (was[x][y][nap])
		{
			printf("NO");
			return 0;
		}
		if (y<0)
			break;

		was[x][y][nap] = 1;


		tx = x + dx[nap];
		ty = y + dy[nap];
		tnap = (nap + 1) % 4;

		if (mas[tx][ty]==1)
		{
			nap--;
			if (nap<0)
				nap = 3;
		}
		else 
		{
			tx2 = x + dx[tnap];
			ty2 = y + dy[tnap];
			if (mas[tx2][ty2]==1)//wall right
			{
				x = x + dx[nap]*2;
				y = y + dy[nap]*2;
				cnt++;
			}
			else
			{
				x = x + dx[tnap]*2;
				cnt++;
				y = y + dy[tnap]*2;
				nap++;
				nap %= 4;
			}
		}
	}
	printf("YES\n%d",cnt);
	
	return 0;
}
