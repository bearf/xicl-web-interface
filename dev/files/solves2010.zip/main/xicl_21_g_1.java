import java.io.File;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Solution {

	private static List<Point> points;
	private static Point v1, v2;

	private static class Point {
		public int x;
		public int y;

		public Point(final int x, final int y) {
			this.x = x;
			this.y = y;
		}

		public boolean equals(Object obj) {
			if (obj != null && obj instanceof Point) {
				Point p = (Point) obj;
				return p.x == this.x && p.y == this.y;
			} else {
				return false;
			}
		}
	}

	public static void main(String[] args) throws Exception {

		// System.out.println(isPointInsideTriangle(new Point(2, 8), new
		// Point(9,
		// 7), new Point(10, 4), new Point(6, 7)));

//		System.out.println(isPointInsideTriangle(new Point(2, 6), new Point(8,
//				8), new Point(9, 7), new Point(6, 7)));

		Scanner in = new Scanner(new File("input.txt"));
		PrintWriter out = new PrintWriter("output.txt");
		points = new LinkedList<Point>();
		int n = in.nextInt();
		Point prevPoint = null;
		int x = 0;
		for (int i = 0; i < n; ++i) {
			final Point newPoint = new Point(in.nextInt(), in.nextInt());
			if (!newPoint.equals(prevPoint)) {
				points.add(newPoint);
				prevPoint = newPoint;
			} else {
				x++;
			}
		}
		n -= x;
		v1 = new Point(in.nextInt(), in.nextInt());
		v2 = new Point(in.nextInt(), in.nextInt());

		while (n > 4) {
			Iterator<Point> it = points.iterator();
			Iterator<Point> it1 = points.iterator();
			Iterator<Point> it2 = points.iterator();
			it1.next();
			it2.next();
			it2.next();
			while (it.hasNext()) {
				final Point p1, p2, p3;
				p1 = it.next();
				// moving it1;
				if (it1.hasNext()) {
					p2 = it1.next();
				} else {
					it1 = points.iterator();
					p2 = it1.next();
				}
				// moving it2;
				if (it2.hasNext()) {
					p3 = it2.next();
				} else {
					it2 = points.iterator();
					p3 = it2.next();
				}
				if (!isPointInsideTriangle(p1, p2, p3, v1)
						&& !isPointInsideTriangle(p1, p2, p3, v2)) {
//					System.out.println("Removing: " + p2.x + ", " + p2.y);
					it1.remove();
					--n;
					break;
				}
			}

		}
		for (final Point p : points) {
			out.println(p.x + " " + p.y);
		}

		out.close();
	}

	private static boolean isPointInsideTriangle(final Point t1,
			final Point t2, final Point t3, final Point p) {
		final long s0 = Math.abs(vectProd(t1, t2) + vectProd(t2, t3)
				+ vectProd(t3, t1));
		final long s1 = Math.abs(vectProd(t1, t2) + vectProd(t2, p)
				+ vectProd(p, t1));
		final long s2 = Math.abs(vectProd(t2, t3) + vectProd(t3, p)
				+ vectProd(p, t2));
		final long s3 = Math.abs(vectProd(t1, t3) + vectProd(t3, p)
				+ vectProd(p, t1));
		if (s0 != 0) {
			return s0 == s1 + s2 + s3;
		} else {
			final int left = Math.min(t1.x, Math.min(t2.x, t3.x));
			final int right = Math.max(t1.x, Math.max(t2.x, t3.x));
			final int bottom = Math.min(t1.y, Math.min(t2.y, t3.y));
			final int top = Math.max(t1.y, Math.max(t2.y, t3.y));
			return p.x >= left && p.x <= right && p.y >= bottom && p.y <= top
					&& s0 == s1 + s2 + s3;
		}
	}

	private static long vectProd(final Point p1, final Point p2) {
		return p1.x * p2.y - p2.x * p1.y;
	}

}
