#include <iostream>
#include <algorithm>


using namespace std;
struct pnt{
	long long x,y;
	long long num;
};
bool comp(pnt a, pnt b){
	return a.num<b.num;
}
long long c[3];
long long procPr(pnt x){
	return c[0]*x.x+c[1]*x.y+c[2];
}
bool fff(long long a, long long b){
	if(a==0) return true;
	if(b==0) return false;
	a=a/abs(a);
	b=b/abs(b);
	return a*b<0;
}
int main(){
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
	long long n;
	cin>>n;
	pnt a[1010];
	for(long long i=0; i<n; i++){
		cin>>a[i].x>>a[i].y;
		a[i].num=i;
	}
	pair <long long, long long> f,l;
	cin>>f.first>>f.second>>l.first>>l.second;
	if(f==l){
		l.first=a[0].x;
		l.second=a[0].y;
	}
	c[0]=l.second-f.second;
	c[1]=f.first-l.first;
	c[2]=f.first*(f.second-l.second)+f.second*(l.first-f.first);
	pnt b[4];
	long long cnt=0;
	for(long long i=0; i<n; i++){
		long long t=procPr(a[i]);
		long long t1=procPr(a[(i+1)%n]);
		if(fff(t,t1)){
			b[cnt]=a[i];
			cnt++;
			b[cnt]=a[(i+1)%n];
			cnt++;
			if(cnt==4) break;
		}
	}
	sort(b,b+4, comp);
	if(b[1].num==b[2].num){
		long long t=(b[1].num+2)%n;
		b[1]=a[t];
	}
	if(b[0].num==b[1].num){
		long long t=(b[1].num+2)%n;
		b[1]=a[t];
	}
	if(b[3].num==b[2].num){
		long long t=(b[2].num+2)%n;
		b[2]=a[t];
	}
	sort(b,b+4, comp);
	for(long long i=0; i<4; i++){
		cout<<b[i].x<<" "<<b[i].y<<endl;
	}
	return 0;
}