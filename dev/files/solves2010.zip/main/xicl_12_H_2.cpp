#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;

bool a[105][105][4];

void add(int x1, int y1, int x2, int y2)
{
	if (y1 > y2)
		swap(y1, y2);
	if (x1 > x2)
		swap(x1, x2);

	if (x1 == x2)
	{
		int x = x1;
		for(int y = y1+1; y <= y2; y++)
		{
			a[x][y][1] = false;
			a[x+1][y][3] = false;
		}
	}
	if( y1 == y2 )
	{
		int y = y1;
		for(int x = x1+1; x <= x2; x++)
		{
			a[x][y][0] = false;
			a[x][y+1][2] = false;
		}
	}
}

int n,m,k;
int dx[] = {0,1,0,-1};
int dy[] = {1,0,-1,0};
int cx,cy,cd;

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);

	for(int i = 0; i <= 101; i++)
		for(int j = 0; j <= 101; j++)
			for(int k = 0; k < 4; k++) a[i][j][k] = true;

	scanf("%d%d%d", &n, &m, &k);
	scanf("%d%d", &cy, &cx);
	string s = "";
	cin >> s;

	if (s == "N")
		cd = 0;
	if (s == "E")
		cd = 1;
	if (s == "S")
		cd = 2;
	if (s == "W")
		cd = 3;

	add(0,0,0,n);
	add(0,0,m,0);
	add(0,n,m,n);
	add(m,0,m,n);
	for(int i = 0; i < k; i++)
	{
		int x1,x2,y1,y2;
		scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
		
		add(x1, y1, x2, y2);
	}
	a[1][2][3] = true;


	int t1 = 0;
	for(int t = 0; t <= 500000; t++)
	{
		//cout << cx <<  " " << cy << endl;
		if( cx == 0 && cy == 2 )
		{
			printf("YES\n");
			printf("%d\n",t1);
			return 0;
		}


		if( !a[cx][cy][cd] )
		{
			cd--;
			if(cd<0) cd+=4;
			continue;
		}
		if( !a[cx][cy][(cd+1)%4] )
		{
			cx+=dx[cd];
			cy+=dy[cd];
			t1++;
			continue;
		}

		cd = (cd+1)%4;
		cx+=dx[cd];
		cy+=dy[cd];
		t1++;
		
	}

	cout << "NO" << endl;
	return 0;
}
