#define _CRT_SECURE_NO_DEPRECATE

#include <cassert>
#include<stdio.h>
#include<math.h>
#include<string>
#include<string.h>
#include<vector>
#include<set>
#include<map>
#include<algorithm>
#include<time.h>
#include<memory.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)
#define ZERO(x) memset(x, 0, sizeof(x))
#define SIZE(x) (int)x.size()

typedef long long int64;

#define MAX 200
#define INF 1000000000

int n, m, x, y;

int matr[MAX][MAX];
int color[MAX];

int p[MAX];
int d[MAX];

void Dijkstra() {
	int mn;
	int mnv;
	int i;
	ZERO(color);
	ZERO(p);
	fi(1, n) {
		d[i] = INF;
	}
	d[x] = 0;
	while (1) {
		mnv = -1;
		mn = INF;
		fi(1, n) {
			if (color[i]) continue;
			if (d[i] < mn) {
				mn = d[i];
				mnv = i;
			}
		}
		if (mn == INF) break;
		color[mnv] = 1;
		fi(1, n) {
			if (matr[mnv][i] == -1) continue;
			if (d[mnv] + matr[mnv][i] < d[i]) {
				d[i] = d[mnv] + matr[mnv][i];
				p[i] = mnv;
			}
		}
	}
}

int w;

int sel[MAX][MAX];
int q;

vector<int> ans;

int dfs(int x) {
	int i;
	if (x == y) {
		ans.pb(x);
		return true;
	}
	color[x] = 1;	
	fi(1, n) {
		if (color[i]) continue;
		if (sel[x][i] == 0) continue;
		if (matr[x][i] != -1) while (1) {}
		if (dfs(i)) {
			sel[x][i] = 0;
			ans.pb(x);
			return true;
		}
	}
	return false;
}

void Print() {
	int i;
	ZERO(color);
	ans.clear();
	dfs(x);
	reverse(ans.begin(), ans.end());
	printf("%d ", SIZE(ans));
	fi(0, SIZE(ans) - 1) {
		printf("%d ", ans[i]);
	}
	printf("\n");
}

int main() {
	int g;
	int a, b, c;
	int i, j;
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf("%d %d %d %d", &n, &m, &x, &y);
	fj(1, n) {
		fi(1, n) {
			matr[j][i] = -1;
		}
	}
	fi(1, m) {
		scanf("%d %d %d", &a, &b, &c);
		matr[a][b] = c;
	}
	Dijkstra();
	if (p[y] == 0) {
		printf("0\n");
		return 0;
	}
	w = d[y];

	q = 1;
	g = y;
	while (g != x) {
		sel[p[g]][g] = !sel[p[g]][g];
		matr[p[g]][g] = -matr[p[g]][g];
		swap(matr[p[g]][g], matr[g][p[g]]);
		g = p[g];
	}

	while (1) {
		Dijkstra();
		if (p[y] == 0) break;
		if (d[y] != w) break;
		q++;
		g = y;
		while (g != x) {
			sel[p[g]][g] = !sel[p[g]][g];
			matr[p[g]][g] = -matr[p[g]][g];
			swap(matr[p[g]][g], matr[g][p[g]]);
			g = p[g];
		}
	}
	printf("%d\n", q);
	fi(1, q) {
		Print();
	}
	return 0;
}
