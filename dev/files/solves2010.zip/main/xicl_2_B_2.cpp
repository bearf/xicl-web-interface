#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <math.h>
#include <time.h>
#pragma comment (linker,"/STACK:32000000")
using namespace std;
const int maxn = 210;
int mas[maxn][maxn]={0};
int d[2][maxn]={0};
int flag[maxn]={0};
const int inf = 1000000000;
void dij(int *d, int v, int n, int fl)
{
	int i,j,mn,pos;
	for (i=1;i<=n;i++)
	{
		flag[i] = 0;
		d[i] = inf;
	}
	d[v] = 0;
	int w;
	while (1)
	{
		mn = -1;
		pos = 0;
		for (i=1;i<=n;i++)
		{
			if (flag[i]==0 && (mn==-1 || d[i]<mn))
			{
				mn = d[i];
				pos = i;
			}
		}
		if (pos==0 || mn==inf)
			break;

		v = pos;
		flag[v] = 1;

		for (i=1;i<=n;i++)
		{
			if (fl==0)
				w = mas[v][i];
			else w = mas[i][v];
			if (w!=0 && d[v]+w<d[i])
			{
				d[i] = d[v] + w;
			}
		}
	}
}
struct pnt{
	int x;
	int y;
	int cap;
	int use;
};
pnt e[maxn*maxn*2];
int ce = 0;
int cnt[maxn]={0};
int v[maxn*2][maxn*2]={0};
void adde(int x, int y, int val)
{
	e[ce].x = x;
	e[ce].y = y;
	e[ce].cap = val;
	v[x][cnt[x]] = ce;
	cnt[x]++;
	ce++;

	e[ce].x = y;
	e[ce].y = x;
	e[ce].cap = 0;
	v[y][cnt[y]] = ce;
	cnt[y]++;
	ce++;
	return;
}
int s,t;
bool dfs(int w)
{
	flag[w] = 1;
	if (w==t)
		return true;
	int i,reb,to;
	for (i=0;i<cnt[w];i++)
	{
		reb = v[w][i];
		to = e[reb].y;
		if (e[reb].cap>0 && flag[to]==0 && dfs(to))
		{
			e[reb].cap--;
			e[reb ^ 1].cap++;
			return true;
		}
	}
	return false;
}
int mxflow(int n)
{
	int fl = 0, fnd = 1, i;
	while (fnd)
	{
		for (i=1;i<=n;i++)
			flag[i] = 0;
		fnd = 0;
		while (dfs(s))
		{
			fnd = 1;
			fl++;
			flag[s] = flag[t] = 0;
		}
	}
	return fl;
}
int st[maxn]={0};
bool prdfs(int w)
{
	int i,reb,to,j;
	flag[w] = 1;
	st[0]++;
	st[st[0]]=w;
	if (w==t)
		return true;

	for (i=0;i<cnt[w];i++)
	{
		reb = v[w][i];
		to = e[reb].y;
		if (flag[to]==0 && e[reb].cap==0 && e[reb].use==0 && prdfs(to))
		{
			e[reb].use = 1;
			return true;
		}
	}
	st[0]--;
	return false;
}
int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int i,j,n,m,x,y,a,b,l;
	cin >> n >> m >> x >> y;
	for (i=1;i<=m;i++)
	{
		cin >> a >> b >> l;
		mas[a][b] = l;
	}
	dij(&d[0][0],x,n,0);
	dij(&d[1][0],y,n,1);
	if (d[0][y]==inf)
	{
		printf("0");
		return 0;
	}
	int mnway = d[0][y];
	for (i=1;i<=n;i++)
	{
		for (j=1;j<=n;j++)
		{
			if (mas[i][j]!=0 && d[0][i]+mas[i][j]+d[1][j]==mnway)
			{
				adde(i,j,1);
			}
		}
	}
	s = x;
	t = y;
	int res;
	res = mxflow(n);
	printf("%d",res);
	for (i=0;i<ce;i++)
		e[i].use = 0;

	st[0] = 0;
	while (prdfs(s))
	{
		printf("\n");
		printf("%d",st[0]);
		for (j=1;j<=st[0];j++)
			printf(" %d",st[j]);
		for (i=1;i<=n;i++)
			flag[i] = 0;
		st[0] = 0;
	}


	return 0;
}
