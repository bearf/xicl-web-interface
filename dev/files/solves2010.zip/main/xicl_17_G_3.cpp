#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>

#include <cstdarg>

using namespace std;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	va_end(args);

	fflush(stderr);
#endif
#endif
}

typedef long long ll;
typedef unsigned long long ull;
typedef pair < int , int > pii;

#define clr(a) memset(a,0,sizeof(a))
#define fill(a,b) memset(a,b,sizeof(a))

const int N = 8 * 1024;

struct Point {
	ll x, y;
	void read()
	{
		scanf("%I64d%I64d", &x, &y);
	}
	Point () {}
	Point (ll _x, ll _y) : x(_x), y(_y) {}
	Point operator - (const Point & p) const
	{
		return Point(x - p.x, y - p.y);
	}
	ll operator * (const Point & p) const
	{
		return x * p.y - y * p.x;
	}
};

Point a, b, P[N];

bool good(Point p1, Point p2, Point a, Point b)
{
	return ((p2 - p1) * (a - p1)) >= 0 && ((p2 - p1) * (b - p1)) >= 0;
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#ifdef DBG1
#if DBG2
	freopen("err.txt", "w", stderr);
#endif
#endif

	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; ++i)
		P[i].read();
	a.read();
	b.read();

	for (int ii = 0; ii < n; ++ii)
	{
		vector <int> res;
		res.push_back(n - 1);
		for (int cnt = 2; cnt >= 0; --cnt)
		{
			int p = res[(int)res.size() - 1];
			int q = p;
			while (q > cnt && good(P[p], P[q - 1], a, b))
				--q;
			res.push_back(q);
		}
		if (good(P[res[3]], P[res[0]], a, b))
		{
			for (int i = 3; i >= 0; --i)
				printf("%I64d %I64d\n", P[res[i]].x, P[res[i]].y);
			return 0;
		}

		Point first = P[0];
		for (int i = 1; i < n; ++i)
			P[i - 1] = P[i];
		P[n - 1] = first;
	}

	while(1);

	return 0;
}