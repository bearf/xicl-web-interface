#pragma comment( linker, "/stack:32000000" )
#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>

#define filein ""

void prepare( )
{
	freopen( "input.txt", "r", stdin );
#ifndef _DEBUG
	freopen( "output.txt", "w", stdout ); 
#endif
}

#include <cmath>
#include <cassert>
#include <memory.h>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>
#include <ctime>
#include <deque>

using namespace std;

#define fo(a,b,c) for(a=(b);a<(c);++a)
#define fr(a,b) fo(a,0,(b))
#define fi(a) fr(i,(a))
#define fj(a) fr(j,(a))
#define fk(a) fr(k,(a))
#define all(a) (a).begin(),(a).end()
#define sz(a) (int)(a).size()
#define pb push_back
#define mp make_pair
#define _(a,b) memset((a),(b),sizeof(a))
#define __(a) _((a),0)

typedef long long lint;

const int MAXN = 1000005;
const int INF = 1000000000;

int n, m;
int ma = INF;

int fact( lint a, lint b )
{
	lint t = n;
	lint h = a;
	lint res = 0;
	while ( t >= h )
	{
		res += t / h;
		h *= a;
	}
	return res / b;
}

int main( )
{
	prepare( );
	int i, j, k;
	scanf( "%d %d", &n, &m );
	for ( i = 2; i * i <= m; ++ i )
	{
		int c = 0;
		while( m % i == 0 )
		{
			++ c;
			m /= i;
		}
		if ( c )
		{
			ma = min( ma, fact( i, m * c ) );
		}
	}
	if ( m > 1 )
	{
		ma = min( ma, fact( m, m ) );
	}
	cout << ma << "\n";
	return 0;
}