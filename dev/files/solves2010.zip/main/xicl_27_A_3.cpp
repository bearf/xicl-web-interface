	#include <iostream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <cmath>
#include <sstream>
#include <cstring>
#include <string>

#define re return
#define mp make_pair
#define pb push_back
#define rep(i,n) for (int i = 0; i < n; i++)
#define fi first
#define se second
#define sz(x) ((int) (x).size())
#define all(x) ((x).begin(), (x).end())
#define fill(x, y) memset(x, y, sizeof(x))
#define y0 y49743
#define y1 y47543

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef long long ll;
typedef long double ld;
typedef vector<string> vs;

int n;
int m;

int main() {
	int a, b, c;
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	cin >> n >> m >> b >> a >> c;
	ll s = 0;
	for (int i = 0; i < n - b; i++)
		for (int j = 0; j < m; j++)
			for (int k = 0; k < n - c; k++)
				for (int l = j + a; l < m; l++)
				{
					//cout << i << ' ' << j << ' ' << k << ' ' << l << endl;
					// 1 0 1 2
					s += (ll)min(i, k) * ll(l - j - a) * ll(l - j - 1) * ll(n - max(i + b - 1, k + c - 1) - 1);
					//cout << "s = " << s << endl;
				}

	cout << s;

	re 0;
}