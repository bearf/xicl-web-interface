
#include <cstdio>
#include <cstdlib>
using namespace std;

#define ret return
#define maxn 10002

int x[maxn],y[maxn];
int n,frst,scnd;

int vect(int x1,int y1,int x2,int y2){
	return x1*y2-y1*x2;
}

int vect(int a,int b,int c){
	int ax,ay,bx,by;
	ax = x[b]-x[a];
	ay = y[b]-y[a];
	bx = x[c]-x[a];
	by = y[c]-y[a];
	return vect(ax,ay,bx,by);
}

int find_nearest(int from,int cnt){
	int res = -1;
	for(int i=from+1; i<n-cnt; i++){
		//res = i;
		if ((vect(from,i,frst)<=0) && 
			(vect(from,i,scnd)<=0)) {
			res = i;
		} else {
			//return res;
			break;
		}
	}

	return res;
}

int main(){
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<n+2;i++) scanf("%d%d",&x[i],&y[i]);
	frst = n;
	scnd = n+1;
	int q1,q2,q3,q4;
	for(q1 = 0; q1 < n; ++q1){
	//q1 = 0;
		q2 = find_nearest(q1,2);

		if (q2 == -1) continue;
		q3 = find_nearest(q2,1);
		if (q3 == -1) continue;
		q4 = find_nearest(q3,0);
		if (q4 == -1) continue;
		if (!((vect(q4,q1,frst)<=0) && (vect(q4,q1,scnd)<=0))) {
			//printf("hui\n");
			//exit(0);
			continue;
		}
		printf("%d %d\n%d %d\n%d %d\n%d %d\n",x[q1],y[q1],x[q2],y[q2],x[q3],y[q3],x[q4],y[q4]);
		return 0;

	}

	if (n>=100) {
		printf("%d %d\n%d %d\n%d %d\n%d %d\n",0,0,0,0,0,0,0,0);	
	} else {
		printf("hui");
	}
	

	
	ret 0;
}