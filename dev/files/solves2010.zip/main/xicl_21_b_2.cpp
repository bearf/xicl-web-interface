#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <algorithm>


using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

const int N = 100;
const int INF = (int)1e9;
int d[N];
int a[N][N];
bool vis[N];
bool vise[N][N];

int n, m, x, y;

vector<vector<int> > ans;

void init_shortest_path(int v) {
	for(int i = 0; i < n; ++i) {
		d[i] = INF;
	}
	d[v] = 0;
	while(true) {
		int min = INF; int min_i = -1;
		for(int i = 0; i < n; ++i) {
			if (d[i] < min && !vis[i]) {
				min_i = i;
				min = d[i];
			}
		}
		if (min_i == -1) break;
		vis[min_i] = true;
		for(int i = 0; i < n; ++i) {
			if (d[min_i] + a[min_i][i] < d[i]) {
				d[i] = d[min_i]+a[min_i][i];
			}
		}
	}
}

void reverse_dfs(int v, vector<int>& path) {
	path.push_back(v);
	if (v == x-1) {
		ans.push_back(path);
		reverse(ans.back().begin(), ans.back().end());
	} else {
		for(int i = 0; i < n; ++i) {
			if (!vise[i][v] && d[i] + a[i][v] == d[v]) {
				vise[i][v] =true;
				reverse_dfs(i, path);
			}
		}
	}
	path.pop_back();
}

int main()
{
	in >> n >> m >> x >> y;
	fill_n(&a[0][0], N*N, INF);

	for(int i = 0; i < m; ++i) {
		int t1, t2, t3;
		in >> t1 >> t2 >> t3;
		a[t1-1][t2-1] = t3;
	}
	init_shortest_path(x-1);
	if (!vis[y-1]) {
		out << 0 << endl;
		return 0;
	}
	reverse_dfs(y-1, vector<int>());
	out << ans.size() << endl;
	for(int i = 0; i < ans.size(); ++i) {
		out << ans[i].size() << ' ';
		for(int j = 0; j < ans[i].size(); ++j) {
			out << ans[i][j]+1 << ' ';
		}
		endl(out);
	}
	return 0;
}

