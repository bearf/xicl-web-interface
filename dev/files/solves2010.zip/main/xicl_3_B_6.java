import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {
	static public void main(String[] args) throws IOException {
		new Solution().run();
	}
	StreamTokenizer in;
	PrintWriter out;
	void run() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		//solve();
		solve1();
		//solveC();
		out.flush();
	}
	
	char[] line;
	int pos;
	Stack<Operation>[] expr;
	int leftOp, rightOp;
	void solveC() throws IOException {
		int n = ni();
		expr = new Stack[n];
		for(int i = 0; i < n; i++) {
			processExpr(i);
		}
	}
	
	void processExpr(int i) {
		if(line[pos] == '(') {
			pos++;
		}
		processAdd(i);
		while(pos < line.length && (line[pos] == '+' || line[pos] == '-')) {
			processAdd(i);
			
		}
		if(line[pos] == ')') pos++;
	}
	
	void processAdd(int i) {
		
	}
	
	void processMul(int i) {
		
	}
	
	class Operation {
		int type; // -1 - leftOp, 1 - rightOp
					// 2 - + , 3 - -, 4 - *, 5 - /, 6 - %
		
	}
	
	void solve1() throws IOException {
		int n = ni(), m = ni(), s = ni() - 1, f = ni()- 1;
		int e = 0;
		if ( s == f ) {
			out.print(1);
			return;
		}
		if(s < 0 || s >= n || f < 0 || f >= n || n == 1 || s == f) {
			out.print(1);
			return;
		}
		boolean can[] = new boolean [m];
		Arrays.fill(can, true);
		int to[]  = new int[m];
		int head[] = new int[n];
		Arrays.fill(head, -1);
		int next[] = new int[m];
		int wes[] = new int[m];
		boolean used[] = new boolean[n];
		int dist[] = new int[n];
		int par[] = new int [n];
		int rib[] = new int [n];
		for(int i = 0; i < m; ++i){
			int u = ni()- 1, v = ni() - 1, w = ni();
			to[e] = v; wes[e]  = w;next[e]=head[u];head[u]=e++;
		}
		LinkedList<Integer> [] ar = new LinkedList[n];
		for(int i = 0; i < n; ++i){
			ar[i] = new LinkedList<Integer>();
		}
		boolean first= true;
		int My=-1;
		int pt= 0;
		while ( true ) {
			Arrays.fill(dist, -1);
			Arrays.fill(used, false);
			Arrays.fill(par, -1);
			dist[s] = 0;
			for(int i = 0; i < n; ++i){
				int v = -1;
				for(int j = 0; j < n; ++j){
					if (   !used[j] && ( v == -1 || dist[j] <= dist[v] ) && dist[j] != -1  ) 
						v = j;
				}
				if ( v == -1 ) break;
				if ( dist[v] == -1 ) break;
				used[v] = true;
				for(int j = head[v]; j >= 0; j = next[j]) {
					if ( can[j] && ( dist[to[j]] > dist[v] + wes[j] || dist[to[j]] == -1 ) ) {
						dist[to[j]] = dist[v] + wes[j];
						par[to[j]]=v;
						rib[to[j]]=j;
					}
				}
			}
			if ( dist[f] == -1 ) break;
			
			int v = f;
			if ( first || dist[f] == My  ) {
				if ( first  ){
					My = dist[f];
					first= false;
				}
			} else break;
			LinkedList<Integer> path = new LinkedList<Integer>();
			while ( v != -1 ) {
				if ( par[v] != -1 ) 
					can[rib[v]]=false;
				path.add(v + 1);
				v = par[v];
			}
			ar[pt++] = path;
		}
		out.println(pt);
		for(int i = 0; i < pt; ++i){
			out.print(ar[i].size());
			out.print(' ');
			for(int j = ar[i].size() - 1; j >= 0; --j){
				out.print(ar[i].get(j));
				if(j!=0) out.print(" ");
			}
			if(i != pt - 1) out.println();
		}
	}
	
	void solve() throws IOException 
	{
		int n = ni(), m = ni(), k = ni();
		char a[][] = new char[2*n + 1][2*m + 1];
		for(int i = 0; i <= 2 * n ; ++i)
			Arrays.fill(a[i], '.');
		for(int i = 0; i <= 2 * n ; ++i)
			a[i][0] = a[i][2*m] = '-';
		for(int i = 0; i <= 2 * m ; ++i)
			a[0][i] = a[2*n][i] = '-';
		a[3][0] = '.';
		int sy = 2*ni()-1, sx = 2*ni()-1;
		char dir =(char) ns();
		for(int i = 0; i < k; ++i){
			int x1 = ni(), y1 = ni(), x2 = ni(), y2 = ni();
			if ( x1 == x2 ) {
				int ny1 = 2 * Math.min(y1, y2) ;
				int ny2 = 2 * Math.max(y1, y2) ;
				for(int j = ny1; j <= ny2; ++j)
					a[j][2*x1] = '-';
				
			} else {
				int nx1 = 2 * Math.min(x1, x2) ;
				int nx2 = 2 * Math.max(x1, x2) ;
				for(int j = nx1; j <= nx2; ++j)
					a[2*y1][j] = '-';
			}
		}
		a[sy][sx]='!';
		
		int dist[][][] = new int[2*n+1][2*m+1][4];
		for(int i = 0; i < 2 * n + 1; ++i)
			for(int j = 0; j < 2 * m + 1; ++j)
				for(int u =0 ; u < 4; ++u)
					dist[i][j][u] = -1;
		Queue<Integer> q = new LinkedList<Integer>();
		
		q.add(sx); q.add(sy);q.add(getDir(dir));
		int dx[] = {-1, 0, 1, 0};
		int dy[] = {0, 1, 0, -1};
		dist[sy][sx][getDir(dir)]=0;
		
		boolean ok = true;
		while ( !q.isEmpty() ) {
			int x = q.poll(), y = q.poll(), z = q.poll();
		//	a[y][x] = '*';
			if ( x == 0 && y == 3 && z == 0) {
				break;
			}
			int nx = x + dx[z], ny = y + dy[z];
			int nnx = x + dx[z] * 2 , nny = y + dy[z]  * 2 ;
			if ( a[ny][nx] == '-' ) {
				if ( ny == 3 && nx == 0 ) {
					out.print("YES\n");
					out.print(dist[y][x][z] + 1);
					return ;
				}
				if ( dist[y][x][(z+1)%4] != -1 ) {
					ok = false;
					break;
				}else {
					dist[y][x][(z+1)%4] = dist[y][x][z];
					q.add(x); q.add(y); q.add((z+1)%4);
				}
			} else {
				char c = a[y+dy[(z+3)%4]][x+dx[(z+3)%4]];
				if ( c == '-' ) {
					if ( dist[nny][nnx][z] != -1 ){
						ok = false;
						break;
					}else {
						dist[nny][nnx][z] = dist[y][x][z]+1;
						q.add(nnx);q.add(nny);q.add(z);
					}
				} else {
					int nz = (z+3)%4;
					nx = x + 2*dx[nz];
					ny = y + 2*dy[nz];
					if ( nx == -1 ) nx++;
					if ( dist[ny][nx][nz]!=-1){
						ok = false;
						break;
					}else {
						dist[ny][nx][nz]=dist[y][x][z]+1;
						q.add(nx);q.add(ny);q.add(nz);
						}
				}
			}
		}
		for(int i = 0 ; i <= 2*n; ++i){
			for(int j = 0; j <= 2*m; ++j )
				out.print(a[i][j]);
			out.print("\n");
		}
		if (!ok||dist[3][0][0]==-1){
			out.print("NO");
		}else {
			out.println("YES");
			out.print(dist[3][0][0]);
		}
	}
	int getDir(char x){
		if ( x == 'W' ) return 3;
		if ( x == 'S' ) return 0;
		if ( x == 'E' ) return 1;
		if ( x == 'N' ) return 2;
		return 0;
	}
	int ni() throws IOException {
		in.nextToken();
		return (int)in.nval;
	}
	char ns() throws IOException {
		in.nextToken();
		return in.sval.charAt(0);
	}
}
