#include <stdio.h>
#include <conio.h>

int main()
{
	int i, n=0, k=0, m=0, z=0, x=0;
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	scanf("%d %d",&n,&k);

	for(i=k;i<=n;i+=k)
	{
		m++;
		z=i/k;
		while(((z%k)==0)&&(z>0))
		{
			z=z/k;
			m++;
		}
	}
	
	x=m/k;

	printf("%d",x);
	return 0;
}
