#pragma comment( linker, "/stack:32000000" )
#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>

#define filein ""

void prepare( )
{
	freopen( "input.txt", "r", stdin );
#ifndef _DEBUG
	freopen( "output.txt", "w", stdout ); 
#endif
}

#include <cmath>
#include <cassert>
#include <memory.h>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>
#include <ctime>
#include <deque>

using namespace std;

#define fo(a,b,c) for(a=(b);a<(c);++a)
#define fr(a,b) fo(a,0,(b))
#define fi(a) fr(i,(a))
#define fj(a) fr(j,(a))
#define fk(a) fr(k,(a))
#define all(a) (a).begin(),(a).end()
#define sz(a) (int)(a).size()
#define pb push_back
#define mp make_pair
#define _(a,b) memset((a),(b),sizeof(a))
#define __(a) _((a),0)

typedef long long lint;

const int MAXN = 105;
const char let[] = "NESW";
const int dy[] = { 1, 0, -1, 0 };
const int dx[] = { 0, 1, 0, -1 };

int n, m;
int f[MAXN][MAXN][4];
int hor[MAXN][MAXN];
int ver[MAXN][MAXN];
int w, h;
int sx, sy;
char buf[20];
int dd;

void add_wall( int x1, int y1, int x2, int y2 )
{
	int i;
	if ( x1 == x2 )
	{
		if ( y1 > y2 )
			swap( y1, y2 );
		for( i = y1; i < y2; ++ i )
		{
			ver[i][x1] = 1;
		}
	}
	else
	{
		if ( x1 > x2 )
			swap( x1, x2 );
		for( i = x1; i < x2; ++ i )
		{
			hor[y1][i] = 1;
		}
	}
}

bool is_wall( int y, int x, int d )
{
	if ( d == 0 )
		return hor[y + 1][x];
	if ( d == 1 )
		return ver[y][x + 1];
	if ( d == 2 )
		return hor[y][x];
	return ver[y][x];
}

int main( )
{
	prepare( );
	int i, j, k;
	scanf( "%d %d %d", &h, &w, &n );
	scanf( "%d %d %s", &sx, &sy, &buf );
	fi( 4 )
	{
		if ( buf[0] == let[i] )
			break;			
	}
	assert( i < 4 );
	dd = i;
	add_wall( 1, 1, 1, 2 );
	add_wall( 1, 3, 1, h + 1 );
	add_wall( 1, 1, w + 1, 1 );
	add_wall( 1, h + 1, w + 1, h + 1 );
	add_wall( w + 1, 1, w + 1, h + 1 ); 
	fi( n )
	{
		int x1, y1, x2, y2;
		scanf( "%d %d %d %d", &x1, &y1, &x2, &y2 );
		++ x1; ++ y1; ++ x2; ++ y2;
		add_wall( x1, y1, x2, y2 );
	}
	int ans = 0;
	bool ok = false;
	while ( 1 )
	{
		if ( sy == 2 && sx == 0 )
		{
			ok = true;
			break;
		}
		if ( f[sy][sx][dd] )
			break;
		f[sy][sx][dd] = 1;
		if ( is_wall( sy, sx, dd ) )
		{
			dd = ( dd + 3 ) & 3;
		}
		else
		if ( is_wall( sy, sx, ( dd + 1 ) & 3 ) )
		{
			sx += dx[dd];
			sy += dy[dd];
			++ ans;
		}
		else
		{
			dd = ( dd + 1 ) & 3;
			sx += dx[dd];
			sy += dy[dd];
			++ ans;
		}
	}
	if ( ok )
	{
		printf( "YES\n%d\n", ans );
	}
	else
	{
		printf( "NO\n" );
	}
	return 0;
}