#include <fstream>
using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

int main() 
{
	int n, k, i, step = 0, j, *A;
	bool t = true, f;
	in >> n >> k;
	A = new int[n];
	for(i=0;i<n;i++)
		A[i] = i+1;

	while(t)
	{
		for(i = 0; i < k; i++)
		{
			for(j = 0; j < n; j++)
				if((A[j] % k) == 0)
				{
					A[j] = A[j]/k;
					f = true;
					break;
				}
			if(j == n)
				f = false;
		}
		if(f)
			step++;
		else
			t = false;
	}
	out << step;
	
	return 0;
}