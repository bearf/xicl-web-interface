#pragma comment( linker, "/stack:32000000" )
#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>

#define filein ""

void prepare( )
{
	freopen( "input.txt", "r", stdin );
#ifndef _DEBUG
	freopen( "output.txt", "w", stdout ); 
#endif
}

#include <cmath>
#include <cassert>
#include <memory.h>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>
#include <ctime>
#include <deque>

using namespace std;

#define fo(a,b,c) for(a=(b);a<(c);++a)
#define fr(a,b) fo(a,0,(b))
#define fi(a) fr(i,(a))
#define fj(a) fr(j,(a))
#define fk(a) fr(k,(a))
#define all(a) (a).begin(),(a).end()
#define sz(a) (int)(a).size()
#define pb push_back
#define mp make_pair
#define _(a,b) memset((a),(b),sizeof(a))
#define __(a) _((a),0)

typedef long long lint;

const int MAXN = 45;

int n, m;

const int dx[4] = { 1, 0, -1, 0 };
const int dy[4] = { 0, 1, 0, -1 };

struct Door
{
	int a[4];
	int add;
};

struct C
{
	int x, y;
	int ct;
	C( int _x, int _y, int _ct )
	{
		x = _x;
		y = _y;
		ct = _ct;
	}
	C( ) { }
};

int d[MAXN][MAXN][4];
int mt;
int p[MAXN][MAXN];
int w, h;
int sx, sy;
int ex, ey;
vector<Door> doors;
deque<C> q;

bool check_dir_door( int x, int y, int ct, int side, int dir )
{
	if ( y < 0 || x < 0 )
		return false;
	if ( p[y][x] < 0 )
		return false;
	Door &t = doors[p[y][x]];
	if ( t.add != dir )
		return false;
	if ( t.a[( side + ( 4 - t.add ) * ct ) & 3] )
		return true;
	return false;
}

bool check_neit_door( int x, int y, int side )
{
	if ( y < 0 || x < 0 )
		return false;
	if ( p[y][x] < 0 )
		return false;
	Door &t = doors[p[y][x]];
	if ( t.add )
		return false;
	if ( t.a[side] )
		return true;
	return false;
}

bool can_stay( int y, int x, int ct )
{
	if ( check_dir_door( x - 1, y - 1, ct, 1, 3 ) )
		return false;
	if ( check_dir_door( x - 1, y - 1, ct, 0, 1 ) )
		return false;

	if ( check_dir_door( x, y - 1, ct, 2, 3 ) )
		return false;
	if ( check_dir_door( x, y - 1, ct, 1, 1 ) )
		return false;

	if ( check_dir_door( x, y, ct, 3, 3 ) )
		return false;
	if ( check_dir_door( x, y, ct, 2, 1 ) )
		return false;

	if ( check_dir_door( x - 1, y, ct, 0, 3 ) )
		return false;
	if ( check_dir_door( x - 1, y, ct, 3, 1 ) )
		return false;

	return true;
}

bool can_move( int y, int x, int ct, int dd )
{
	int ny = y + dy[dd];
	int nx = x + dx[dd];
	if ( nx < 0 || nx >= w || ny < 0 || ny >= h )
		return false;
	if ( dd == 0 )
	{
		int ddd = 1;
		if ( check_dir_door( x, y - 1, ct, ddd, 1 ) )
			return false;
		if ( check_neit_door( x, y - 1, ddd ) )
			return false;
		if ( check_dir_door( x + 1, y - 1, ct, ddd, 1 ) )
			return false;
		if ( check_dir_door( x, y - 1, ct, dd, 1 ) )
			return false;

		ddd = 3;

		if ( check_dir_door( x, y, ct, ddd, 3 ) )
			return false;
		if ( check_neit_door( x, y, ddd ) )
			return false;
		if ( check_dir_door( x + 1, y, ct, ddd, 3 ) )
			return false;
		if ( check_dir_door( x, y, ct, dd, 3 ) )
			return false;

		if ( check_dir_door( x - 1, y - 1, ct, dd, 1 ) )
			return false;
		if ( check_dir_door( x - 1, y, ct, dd, 3 ) )
			return false;
	}
	else
	if ( dd == 1 )
	{
		int ddd = 2;
		if ( check_dir_door( x, y, ct, ddd, 1 ) )
			return false;
		if ( check_neit_door( x, y, ddd ) )
			return false;
		if ( check_dir_door( x, y + 1, ct, ddd, 1 ) )
			return false;
		if ( check_dir_door( x, y, ct, dd, 1 ) )
			return false;

		ddd = 0;

		if ( check_dir_door( x - 1, y, ct, ddd, 3 ) )
			return false;
		if ( check_neit_door( x - 1, y, ddd ) )
			return false;
		if ( check_dir_door( x, y + 1, ct, ddd, 3 ) )
			return false;
		if ( check_dir_door( x - 1, y, ct, dd, 3 ) )
			return false;

		if ( check_dir_door( x, y - 1, ct, dd, 1 ) )
			return false;
		if ( check_dir_door( x - 1, y - 1, ct, dd, 3 ) )
			return false;
	}
	else
	if ( dd == 2 )
	{
		int ddd = 3;
		if ( check_dir_door( x - 1, y, ct, ddd, 1 ) )
			return false;
		if ( check_neit_door( x - 1, y, ddd ) )
			return false;
		if ( check_dir_door( x - 2, y, ct, ddd, 1 ) )
			return false;
		if ( check_dir_door( x - 1, y, ct, dd, 1 ) )
			return false;

		ddd = 1;

		if ( check_dir_door( x - 1, y - 1, ct, ddd, 3 ) )
			return false;
		if ( check_neit_door( x - 1, y - 1, ddd ) )
			return false;
		if ( check_dir_door( x - 2, y - 1, ct, ddd, 3 ) )
			return false;
		if ( check_dir_door( x - 1, y - 1, ct, dd, 3 ) )
			return false;

		if ( check_dir_door( x, y, ct, dd, 1 ) )
			return false;
		if ( check_dir_door( x, y - 1, ct, dd, 3 ) )
			return false;

	}
	else // 3
	{
		int ddd = 0;
		if ( check_dir_door( x - 1, y - 1, ct, ddd, 1 ) )
			return false;
		if ( check_neit_door( x - 1, y - 1, ddd ) )
			return false;
		if ( check_dir_door( x - 1, y - 2, ct, ddd, 1 ) )
			return false;
		if ( check_dir_door( x - 1, y - 1, ct, dd, 1 ) )
			return false;

		ddd = 2;

		if ( check_dir_door( x, y - 1, ct, ddd, 3 ) )
			return false;
		if ( check_neit_door( x, y - 1, ddd ) )
			return false;
		if ( check_dir_door( x, y - 1, ct, ddd, 3 ) )
			return false;
		if ( check_dir_door( x, y - 1, ct, dd, 3 ) )
			return false;

		if ( check_dir_door( x - 1, y, ct, dd, 1 ) )
			return false;
		if ( check_dir_door( x, y, ct, dd, 3 ) )
			return false;

	}
	return true;
}

void add( const C &p, int nd )
{
	if ( d[p.y][p.x][p.ct] < 0 )
	{
		d[p.y][p.x][p.ct] = nd;
		q.pb( p );
	}
}

int main( )
{
	prepare( );
	int i, j, k;
	_( p, -1 );
	scanf( "%d %d %d", &w, &h, &n );
	fi( n )
	{
		int x, y;
		char dirs[5];
		char dir[5];
		scanf( "%d %d %s %s", &x, &y, dirs, dir );
		-- x; -- y;
		int len = strlen( dirs );
		Door t;
		__( t.a );
		fj( len )
		{
			if ( dirs[j] == 'R' )
				t.a[0] = 1;
			if ( dirs[j] == 'D' )
				t.a[1] = 1;
			if ( dirs[j] == 'L' )
				t.a[2] = 1;
			if ( dirs[j] == 'U' )
				t.a[3] = 1;
		}
		if ( dir[0] == 'R' )
		{
			t.add = 1;
		}
		else
		if ( dir[0] == 'L' )
		{
			t.add = 3;
		}
		else
			t.add = 0;
		p[y][x] = i;
		doors.pb( t );
	}
	scanf( "%d %d", &sx, &sy );
	scanf( "%d %d", &ex, &ey );
	-- sx; -- sy; -- ex; -- ey;
	scanf( "%d", &mt );
	_( d, -1 );
	add( C( sx, sy, 0 ), 0 );
	while ( !q.empty( ) )
	{
		C cur = q.front( );
		q.pop_front( );
		int cd = d[cur.y][cur.x][cur.ct];
		fi( 4 )
		{
			if ( can_move( cur.y, cur.x, cur.ct, i ) )
			{
				C npos( cur.x + dx[i], cur.y + dy[i], ( cur.ct + 1 ) & 3 );
				add( npos, cd + 1 );
			}
		}
		//try stay
		if ( can_stay( cur.y, cur.x, cur.ct ) )
		{
			C npos = cur;
			npos.ct = ( cur.ct + 1 ) & 3;
			add( npos, cd + 1 );
		}
	}
	int ans = -1;
	fi( 4 )
	{
		if ( d[ey][ex][i] >= 0 && d[ey][ex][i] <= mt )
		{
			if ( ans < 0 || d[ey][ex][i] < ans )
				ans = d[ey][ex][i];
		}
	}
	printf( "%d\n", ans );
	return 0;
}