#include <stdio.h>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <queue>
#include <deque>
#include <cassert>
#include <memory.h>
#include <algorithm>
#include <math.h>
#include <sstream>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) ((int)(a.size()))

const int INF = 2000000000;

typedef long long lint;

void prepare()
{
	freopen("input.txt", "r", stdin);
#ifndef _DEBUG
	freopen("output.txt", "w", stdout);
#endif
}

int n, x;

pair<int, int> f[200005];
multiset< pair<lint, int> > p;

void pognal(int x)
{
	if (x >= 100000)
		printf("(");

	if (x < 100000)
		printf("%d", -f[x].first);
	else
	{
		pognal(f[x].first);
		printf(".");
		pognal(f[x].second);
	}

	if (x >= 100000)
		printf(")");
}

bool solve()
{
	scanf("%d%d", &n, &x);

	for (int i = 0; i < n; i++)
	{
		lint mass;
		scanf("%lli", &mass);
		f[i].first = -i - 1;
		p.insert ( mp( mass, i ) );
	}

	int cur = 100000;

	while (p.size() > 1)
	{
		multiset< pair<lint, int> >::iterator it1 = p.begin();
		multiset< pair<lint, int> >::iterator it2 = p.begin(); it2++;

		int m1 = max(it1->first, it2->first);
		int m2 = min(it1->first, it2->first);

		if (m1 > x * m2)
		{
			printf("no\n");
			return false;
		}

		p.insert( mp(m1 + m2, cur) );
		f[cur++] = mp(it1->second, it2->second);

		p.erase(it1);
		p.erase(it2);
	}

	//printf("yes\n");

	multiset< pair<lint, int> >::iterator its = p.begin();
	pognal(its->second);
	printf("\n");
	
	return false;
}

int main()
{
	prepare();
	while (solve());
	return 0;
}

