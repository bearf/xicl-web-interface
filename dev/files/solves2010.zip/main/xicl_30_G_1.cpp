#define _CRT_SECURE_NO_DEPRECATE

#include<stdio.h>
#include<math.h>
#include<string>
#include<string.h>
#include<vector>
#include<set>
#include<map>
#include<algorithm>
#include<time.h>
#include<memory.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)
#define ZERO(x) memset(x, 0, sizeof(x))
#define SIZE(x) (int)x.size()

typedef long long int64;

#define MAX 4000
#define NEG -1
#define POS 1

int n;

struct Point {
	int x;
	int y;
};

Point pnt[MAX];
Point vishens[3];
Point goals[3];

int vect(Point & a, Point & b, Point & c) {
	int x1, y1, x2, y2;
	x1 = b.x - a.x;
	y1 = b.y - a.y;
	x2 = c.x - a.x;
	y2 = c.y - a.y;
	return x1 * y2 - x2 * y1;
}

inline bool goal(int x, int base, int dir) {
	if (dir * vect(pnt[base], pnt[x], goals[0]) >= 0) {
		if (dir * vect(pnt[base], pnt[x], goals[1]) >= 0) {
			return dir > 0 ? true : false;
		}
	}
	return dir > 0 ? false : true;
}

int srch(int left, int right, int base, int dir) {
	if (goal(left, base, dir) && goal(right, base, dir)) {
		return -1;
	}
	if (!goal(left, base, dir) && !goal(right, base, dir)) {
		return dir > 0 ? left : right;
	}
	while (right - left > 1) {
		int m = (right + left) / 2;
		if (goal(m, base, dir)) {
			right = m;
		} else {
			left = m;
		}
	}

	return dir > 0 ? right : left;
}

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	//
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%d%d", &pnt[i].x, &pnt[i].y);
		pnt[i + n] = pnt[i];
		pnt[i + n + n] = pnt[i];
	}
	scanf("%d%d", &vishens[0].x, &vishens[0].y);
	scanf("%d%d", &vishens[1].x, &vishens[1].y);
	//
	for (int i = 0; i < n; i++) {
		for (int jj = 3; jj < n - 1; jj++) {
			int j = i + jj;

			if (vect(pnt[i], pnt[j], vishens[0]) >= 0) {
				if (vect(pnt[i], pnt[j], vishens[1]) >= 0) {
					// both
					goals[0] = vishens[0];
					goals[1] = vishens[1];
					//
					int a = srch(i + 1, j - 1, i, NEG);
					int b = srch(i + 1, j - 1, j, POS);
					//
					if (a > 0 && b > 0) {
						if (b <= a) {
							printf("%d %d\n", pnt[i].x, pnt[i].y);
							printf("%d %d\n", pnt[b].x, pnt[b].y);
							printf("%d %d\n", pnt[j].x, pnt[j].y);
							printf("%d %d\n", pnt[j + 1].x, pnt[j + 1].y);
							return 0;
						}
					}
				} else {
					// upper
					goals[0] = vishens[0];
					goals[1] = vishens[0];
					//
					int a = srch(i + 1, j - 1, i, NEG);
					int b = srch(i + 1, j - 1, j, POS);
					if (a > 0 && b > 0) {
						if (a <= b) {
							// lower
							goals[0] = vishens[1];
							goals[1] = vishens[1];
							//
							int c = srch(j + 1, i + n - 1, j, NEG);
							int d = srch(j + 1, i + n - 1, i, POS);

							if (c > 0 && d > 0) {
								if (d <= c) {
									printf("%d %d\n", pnt[i].x, pnt[i].y);
									printf("%d %d\n", pnt[b].x, pnt[b].y);
									printf("%d %d\n", pnt[j].x, pnt[j].y);
									printf("%d %d\n", pnt[c].x, pnt[c].y);
									return 0;
								}
							}
						}
					}
				}
			}
		}
	}
	return 0;
}
