#include <iostream>
#include <string>
#include <vector>
//#include <set>
#include <algorithm>
#define FILE freopen ("input.txt", "r", stdin); freopen ("output.txt", "w", stdout);
using namespace std;

class ves
{
public:
	int weight;
	string str;

	bool operator > (ves v);
	bool operator < (ves v);

	ves operator + (ves v);
};

bool ves::operator > (ves v)
{
	return (this->weight > v.weight);
}

bool ves::operator < (ves v)
{
	return (this->weight < v.weight);
}

ves ves::operator + (ves v)
{
	ves temp;
	temp.weight = this->weight + v.weight;
	temp.str = '(' + this->str + '.' + v.str + ')';
	return temp;
}

vector<ves> mass;
int n, x;

bool attempt()
{
	ves temp;
	while(mass.size()>=2)
	{		
		if (mass[0].weight*x<mass[1].weight || mass[1].weight*x<mass[0].weight)
			return false;
		
		temp = mass[0] + mass[1];
		
		mass.erase(mass.begin(), mass.begin()+2);
		mass.push_back(temp);
		
		sort(mass.begin(), mass.end());
	}
	return true;
}

int main ()
{
	FILE;
	int i, temp_i;
	ves temp_v;

	cin >> n >> x;
	if (n==1)
	{
		cout << "no";
		return 0;
	}

	for (i=0; i<n; ++i)
	{
		cin >> temp_i;
		temp_v.weight = temp_i;
		temp_v.str = (char) (i+(int)'1');
		mass.push_back(temp_v);
	}
	sort(mass.begin(), mass.end());
	if (attempt())
		cout << (*mass.begin()).str;
	else 
		cout << "no";

	return 0;
}