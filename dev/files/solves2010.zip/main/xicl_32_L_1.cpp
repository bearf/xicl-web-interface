#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <queue>
#include <memory.h>
//#include <cmath>

using namespace std;
#define REP(i,n) for (int i = 0; i < n; ++i)
#define LL long long
#define MP make_pair

struct trec{
	LL w;
	int n, a, b;
};

int n, x, t, r;
set<pair<LL,int> > q;
pair<LL,int> a, b;
pair<int,int> w[300000];
LL tw[300000];

bool checktree (int v){
	if (w[v].first==-1) return true;
	if (tw[w[v].first] < tw[w[v].second]){
		if (tw[w[v].first]*x < tw[w[v].second]) return false;
	}else if (tw[w[v].first]*x > tw[w[v].second]) return false;
	return (checktree (w[v].first) && checktree (w[v].second));
};

void printtree (int v){
	if (w[v].first==-1){
		printf ("%d", w[v].second+1);
		return;
	};
	printf ("(");
	printtree (w[v].first);
	printf (".");
	printtree (w[v].second);
	printf (")");
};

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf ("%d%d", &n, &x);
	REP(i,n){
		scanf ("%d", &r);
		w[i].first = -1;
		w[i].second = i;
		tw[i] = r;
		q.insert(MP((LL)(tw[i]),i));
	};
	t = n;
	while (q.size()>1){
		a = *q.begin();
		q.erase(q.begin());
		b = *q.begin();
		q.erase(q.begin());
		tw[t] = a.first + b.first;
		w[t].first = a.second;
		w[t++].second = b.second;
		q.insert(MP(tw[t-1],t-1));
	};
	if (!checktree (t-1)){
		printf ("no");
		return 0;
	};
	printtree (t-1);	
	return 0;
}