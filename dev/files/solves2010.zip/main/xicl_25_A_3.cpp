#include <iostream>
using namespace std;

int N,M,A,B,C;
int dp[102][102];

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int i,j,k;
	cin>>N>>M>>A>>B>>C;

	long long res=0;

	for(j=0;j<N;j++)
	{
		for(i=0;i<M;i++)
		{
			if(j<A || j<C || M<i+2)
			{
				dp[i][j]=0;
			}
			else
			{
				dp[i][j]=(j-A+1)*(j-C+1)*(M-i-1);
			}
		//	cout<<dp[i][j]<<' ';
		}
		//cout<<endl;
	}

	for(i=1;i<100;i++)
	{
		if(i>=N) continue;
		for(j=1;j<100;j++)
		{
			if(j+i>=N) continue;
			int w = N-i-j;
		//	cout<<w<<endl;
			for(k=B;k<100;k++)
			{
				res += (k)*(k-B+1)*dp[k][w]; 
			}
		}
	}
	cout<<res;

	return 0;
}