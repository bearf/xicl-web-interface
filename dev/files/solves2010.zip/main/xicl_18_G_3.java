import java.lang.*;
import java.io.*;
import java.math.*;
import java.util.*;
import java.awt.geom.*;

public class Solution {

	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	
	public static void main(String args[]) throws IOException{
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Solution()).run();
	}
	
	public void loadLine(){
		try{
			stk = new StringTokenizer(br.readLine());
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public String nextLine(){
		try{
			return (br.readLine());
		} catch(IOException e) {
			e.printStackTrace();
			return "";
		}
	}
	
	public String nextWord(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return stk.nextToken();
	}
	
	public Integer nextInt(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	public Double nextDouble(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return Double.parseDouble(stk.nextToken());
	}
	
	public void run(){
		int n = nextInt();
		int[] x = new int[n];
		int[] y = new int[n];
		int x1, y1, x2, y2;
		
		for (int i = 0; i < n; ++i) {
			x[i] = nextInt();
			y[i] = nextInt();
		}
		x1 = nextInt();
		y1 = nextInt();
		x2 = nextInt();
		y2 = nextInt();
		
		HashSet<Integer>[] g = new HashSet[n];
		for (int i = 0; i < n; ++i) {
			g[i] = new HashSet<Integer>();
		}
		
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				if (i != j) {
					if (Line2D.relativeCCW(x[i], y[i], x[j], y[j], x1, y1) == -1 &&
							Line2D.relativeCCW(x[i], y[i], x[j], y[j], x2, y2) == -1) {
						g[i].add(j);
					}
				}
			}
		}
		
		int v1 = 0, v2 = 0;
		double dist = Double.MAX_VALUE;
		for (int i = 0; i < n; ++i) {
				int k = (i+1)%n;
				double d = Line2D.ptSegDist(x[i], y[i], x[k], y[k], x1, y1); 
				if (d < dist) {
					dist = d;
					v1 = k;
					v2 = i;
				}
				d = Line2D.ptSegDist(x[i], y[i], x[k], y[k], x2, y2); 
				if (d < dist) {
					dist = d;
					v1 = k;
					v2 = i;
				}
			
		}
		
		boolean found = false;
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				if (i != j && i != v1 && j != v1 && i != v2 && j != v2) {
					if (g[v2].contains(i) && g[i].contains(j) && g[j].contains(v1)) {
						out.println(x[v1] + " " + y[v1]);
						out.println(x[j] + " " + y[j]);
						out.println(x[i] + " " + y[i]);
						out.println(x[v2] + " " + y[v2]);
						
						found = true;
						break;
					}
					
				}
			}
			
			if (found)
				break;
		}
		out.flush();
	}
}
