//#include <fstream>
//using namespace std;
//ifstream cin("input.txt");
//ofstream cout("output.txt");
//#include <vector>
//#include <cmath>
//#include <algorithm>
//#include <iomanip>
//
//bool deleted[1005];
//long long int coords[1005][2];
//int n,nc;
//
//bool inner(long long int x,long long int y)
//{
//	int f=0;
//	while(deleted[f])f++;
//	int s=f+1, c=0;
//	while(deleted[s])s++;
//	do
//	{
//		long long int det=(coords[f][0]-x)*(coords[s][1]-y)-(coords[s][0]-x)*(coords[f][1]-y);
//		if(det>0)
//		{
//			return false;
//		}
//		else
//		if(det==0)return true;
//		f=s;
//		s++;			
//		if(s==n)s=0;
//		while(deleted[s])
//		{
//			s++;
//			if(s==n)s=0;
//		}
//		c++;
//	}while(c!=nc);
//	return true;
//}
//
//int main()
//{
//	cin>>n;
//	long long int x1,y1,x2,y2;
//	for(int i=0;i<n;i++)
//	{
//		cin>>coords[i][0]>>coords[i][1];
//	}
//	cin>>x1>>y1>>x2>>y2;
//	memset(deleted,0,sizeof deleted);
//	int cc=0;
//	nc=n;
//	while(nc!=4)
//	{
//		nc--;
//		while(1)
//		{
//			if(cc==n)cc=0;
//			deleted[cc]=true;
//			if(inner(x1,y1) && inner(x2,y2))
//			{
//				cc++;
//				break;
//			}
//			deleted[cc]=false;
//			cc++;
//		}
//	}
//	for(int i=0;i<n;i++)
//	{
//		if(!deleted[i])cout<<coords[i][0]<<" "<<coords[i][1]<<endl;
//	}
//}

#include <fstream>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");
#include <vector>
#include <cmath>
#include <algorithm>
#include <iomanip>
#include <queue>

typedef unsigned int uint;

int dist[105][105];
uint dist_cur[105];

struct rec
{
	int v;
	uint d;
	rec(int v0,uint d0)
	{
		v=v0;
		d=d0;
	}
	bool operator>(const rec &a)const
	{
		return d>a.d;
	}
	bool operator<(const rec &a)const
	{
		return d<a.d;
	}
};

typedef vector<int> vi;

vector<vi> resp;

int main()
{
	int n,m,x,y;
	cin>>n>>m>>x>>y;
	x--;
	y--;
	memset(dist,0,sizeof dist);
	for(int i=0;i<m;i++)
	{
		int a,b,l;
		cin>>a>>b>>l;
		dist[a-1][b-1]=l;
	}
	int res=0, dmin=2000000000;
	while(1)
	{
		memset(dist_cur,-1,sizeof dist_cur);
		priority_queue<rec,vector<rec>,greater<rec> > q;
		q.push(rec(x,0));
		dist_cur[x]=0;
		while(!q.empty())
		{
			rec v=q.top();
			if(v.d>dist_cur[v.v])
			{
				q.pop();
				continue;
			}
			for(int i=0;i<n;i++)
			{
				if(dist[v.v][i] && dist_cur[i]>dist_cur[v.v]+dist[v.v][i])
				{
					dist_cur[i]=dist_cur[v.v]+dist[v.v][i];
					q.push(rec(i,dist_cur[i]));
				}
			}
			q.pop();
		}
		if(dist_cur[y]==-1)break;
		if(dmin==2000000000)dmin=dist_cur[y];
		else 
		if(dist_cur[y]!=dmin)break;
		int vcur=y;
		vi rcur;
		rcur.push_back(y);
		while(vcur!=x)
		{
			for(int i=0;i<n;i++)
			{
				if(dist[i][vcur] && dist_cur[vcur]==dist_cur[i]+dist[i][vcur])
				{
					vcur=i;
					rcur.push_back(i);
					break;
				}
			}
		}
		reverse(rcur.begin(),rcur.end());
		resp.push_back(rcur);
		for(size_t i=1;i<rcur.size();i++)
		{
			dist[rcur[i-1]][rcur[i]]=0;
		}
		res++;
	}
	cout<<res<<endl;
	for(int i=0;i<res;i++)
	{
		cout<<resp[i].size()<<" ";
		for(vi::iterator j=resp[i].begin();j!=resp[i].end();j++)
		{
			cout<<*j+1<<" ";
		}
		cout<<endl;
	}
}