import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {
	static public void main(String[] args) throws IOException {
		new Solution().run();
	}
	StreamTokenizer in;
	PrintWriter out;
	void run() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		solve();
		out.flush();
	}
	
	void solve() throws IOException 
	{
		int n = ni();
		int k = ni();
		long min=10000000;
		int j=k;
		for(int i = 2; i <= j; i++) 
		{
			if(k%i==0)
			{
				int y=0;
				while(k%i==0)
				{
					k=k/i;
					y++;
				}
				int l=i;
				int st=0;
				while(n>=l)
				{
					st+=n/l;
					l=l*i;
				}
				if(st/y<min)
					min=st/y;
			}
		}
		min /= j;
		out.print(min);
	}
	int ni() throws IOException {
		in.nextToken();
		return (int)in.nval;
	}
}
