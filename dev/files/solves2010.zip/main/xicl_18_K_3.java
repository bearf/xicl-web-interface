import java.lang.*;
import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {

	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	
	public static void main(String args[]) throws IOException{
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Solution()).run();
	}
	
	public void loadLine(){
		try{
			stk = new StringTokenizer(br.readLine());
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public String nextLine(){
		try{
			return (br.readLine());
		} catch(IOException e) {
			e.printStackTrace();
			return "";
		}
	}
	
	public String nextWord(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return stk.nextToken();
	}
	
	public Integer nextInt(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	public Double nextDouble(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return Double.parseDouble(stk.nextToken());
	}
	
	int[] prev;
	long[] cnt, cnt1;
	
	void dfs(int a) {
		if (prev[a] != -1) {
			cnt[prev[a]]++;
			dfs(a / prev[a]);
		} else {
			cnt[a]++;
		}
	}
	
	void dfs1(int a, int k) {
		if (prev[a] != -1) {
			cnt1[prev[a]] += k;
			dfs1(a / prev[a], k);
		} else {
			cnt1[a] += k;
		}
	}
	
	public void run() {
		int n = nextInt();
		int k = nextInt();
		prev = new int[1000000+1];
		cnt = new long[1000000+1];
		cnt1 = new long[1000000+1];
		Arrays.fill(prev, -1);
		for (int i = 2; i <= 1000000; i++) {
			if (prev[i] == -1) {
				for (int j = i+i; j <= 1000000; j += i) {
					prev[j] = i; 
				}
			}
		}
		for (int i = n; i >= 2; i--) {
			dfs(i);
		}
		dfs1(k, k);
		long max = Long.MAX_VALUE;
		for (int i = 0; i <= 1000000; i++) {
			if (cnt1[i] != 0) max = Math.min(max, cnt[i]/cnt1[i]);
		}
		out.println(max);
		out.flush();
	}
}
