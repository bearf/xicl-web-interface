#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

ifstream cin("input.txt");
ofstream cout("output.txt");

#define len(v) (int)(v).size()
#define vi vector<int>
#define vvi vector<vi >

vi primes;

bool isPrime(int n)
{
	for(int i = 0; i < len(primes) && primes[i]*primes[i] <= n; i++)
		if(n % primes[i] == 0)
			return false;
	return true;
}

void getPrimes()
{
	for(int i = 2; i < 1000000; i++)
		if(isPrime(i))
			primes.push_back(i);
}

int main()
{
	int n, k;
	cin >> n >> k;
	int bufk = k;
	getPrimes();
	vi a(len(primes)), b(len(primes));
	for(int i = 0; i < len(primes); i++)
		while(k % primes[i] == 0)
		{
			a[i]++;
			k /= primes[i];
		}
	for(int i = 0; i < len(primes); i++)
		a[i] *= bufk;
	for(int i = 0; i < len(primes); i++)
	{
		int x = primes[i];
		int a = x;
		while(a <= n)
		{
			b[i] += n/a;
			a *= x;
		}
	}
	int mi = 2000000000;
	for(int i = 0; i < len(primes); i++)
		if(a[i] != 0)
			mi = min(mi, b[i]/a[i]);
	cout << mi;
}
			