#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<stack>
#include<cmath>
using namespace std;



int main(){
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	long long n,m,a,b,c,ans=0;
	cin>>n>>m>>a>>b>>c;
	for (long long i=m;i>=b+2;i--){
		for (long long j=max(b,c)+2;j<=n;j++){
			ans+=2*(i-1-b)*(i-2)*(j-1-c)*(j-1-a);
		}
	}
	ans-=(m-1-b)*(m-2)*(n-1-c)*(n-1-a);
	cout<<ans;
	return 0;
}