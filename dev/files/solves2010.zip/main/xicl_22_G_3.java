import java.util.*;
import java.awt.geom.*;
import java.math.*;
import static java.lang.Math.*;
import java.io.*;

public class Solution implements Runnable {

	static BufferedReader br = null;
	static PrintWriter pw = null;
	static StringTokenizer stk = new StringTokenizer("");

	public static void main(String[] args) throws FileNotFoundException {
		br = new BufferedReader(new FileReader("input.txt"));
		pw = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}

	void nline() {
		try {
			stk = new StringTokenizer(br.readLine());
		} catch (IOException e) {
			throw new RuntimeException("No new line");
		}
	}

	String nwrd() {
		while (!stk.hasMoreElements())
			nline();
		return stk.nextToken();
	}

	int ni() {
		return Integer.valueOf(nwrd());
	}

	long nl() {
		return Long.valueOf(nwrd());
	}

	double nd() {
		return Double.valueOf(nwrd());
	}

	char nc() {
		return nwrd().charAt(0);
	}

	boolean isReady() {
		try {
			return br.ready();
		} catch (IOException e) {
			throw new RuntimeException("Something wrong in br");
		}
	}

	long squ(long x1, long y1, long x2, long y2, long x, long y) {
		return x1 * (y2 - y) - (y1 * (x2 - x)) + (x2 * y - x * y2);
	}

	int[] d;

	int nxt(int i) {
		return (i + 1 + d[i]) % n;
	}

	int n;

	public void solve() {
		n = ni();
		d = new int[n];
		long[] x = new long[n];
		long[] y = new long[n];
		for (int i=0;i<n;i++) {
			x[i]=nl();
			y[i]=nl();
		}
		long x1 = nl();
		long y1 = nl();
		long x2 = nl();
		long y2 = nl();
		int cn = n;
		if (cn==4) {
			int cur = 0;
			for (int kk=0;kk<4;kk++) {
				pw.println(x[cur]+" "+y[cur]);
				cur=nxt(cur);
			}
			return;
		}
		for (int i = 0; i < n; i = (i + 1 + d[i]) % n) {
			for (int j = 1; j < n; j++) {
				int a1 = i;
				int a2 = nxt(a1);
				int a3 = nxt(a2);
				long s1 = squ(x[a1], y[a1], x[a3], y[a3], x1, y1);
				long s2 = squ(x[a1], y[a1], x[a3], y[a3], x2, y2);
				long s3 = squ(x[a1], y[a1], x[a2], y[a2], x1, y1);
				long s4 = squ(x[a1], y[a1], x[a2], y[a2], x2, y2);
				if ((s1*s3) >= 0 && (s2*s4) >= 0) {
					cn--;
					d[a1] += d[a2] + 1;
					if (cn==4) {
						int cur = a1;
						for (int kk=0;kk<4;kk++) {
							pw.println(x[cur]+" "+y[cur]);
							cur=nxt(cur);
						}
						return;
					}
				} else
					break;
			}
		}
	}

	public void run() {
		solve();
		pw.close();
	}

}
