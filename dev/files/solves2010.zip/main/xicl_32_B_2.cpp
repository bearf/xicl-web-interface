#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <queue>
#include <memory.h>
//#include <cmath>

using namespace std;
const int inf = 9999999;

int lf[110][110];
int f[110][110];
int c[110][110];
int cost[110][110];
int s, t;
int p[110];
int n;
bool was[110];
int d[110];
int lnk[110];
int LEN = -1;


bool Dijkstra()
{
	LEN = 0;
	memset(d, -1, sizeof(d));
	memset(was, false, sizeof(was));
	d[s] = 0;
	for (int k = 0; k < n; ++k)
	{
		int v = -1;
		for (int i = 0; i < n; ++i)
		{
			if (!was[i] && d[i] != -1)
			{
				if (v == -1)
					v = i;
				if (d[i] < d[v])
					v = i;
			}
		}
		if (v == -1)
			break;
		was[v] = true;
		for (int i = 0; i < n; ++i)
		{
			if (c[v][i] - f[v][i] > 0)
			{
				int l = p[v] - p[i] + cost[v][i];
				if (d[i] > d[v] + l || d[i] == -1)
				{
					lnk[i] = v;
					d[i] = d[v] + l;
				}
			}
		}
	}

	if (d[t] == -1)
		return false;
	for (int v = t; v != s; v = lnk[v])
	{
		--f[v][lnk[v]];
		++f[lnk[v]][v];
	}
	for (int i = 0; i < n; ++i)
	{
		if (d[i] != -1)
		{
			p[i] += d[i];
			if (p[i] > inf)
				p[i] = inf;
		}
		else
			p[i] = inf;
	}
}

int MinCost()
{
	int ret = 0;
	int L = 0;
	if (!Dijkstra())
		return 0;
	ret = 1;
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n; ++j)
		{
			if (f[i][j] > 0)
				L += cost[i][j];
		}
	}
	LEN = L;
	memcpy(lf, f, sizeof(f));
	int LF = L;
	while (Dijkstra())
	{
		int F = 0;
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < n; ++j)
			{
				if (f[i][j] > 0)
					F += cost[i][j];
			}
		}
		if (F != LF + L)
		{
			memcpy(f, lf, sizeof(lf));
			break;
		}
		memcpy(lf, f, sizeof(f));
		++ret;
		LF = F;
	}
	return ret;
}

vector<int> cur;
void dfs(int v)
{
	cur.push_back(v);
	for (int i = 0; i < n; ++i)
	{
		if (f[v][i] > 0 && cost[v][i] >= 0)
		{
			--f[v][i];
			++f[i][v];
			dfs(i);
			return;
		}
	}
}
int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	int N, M, X, Y;
	scanf("%d %d %d %d", &N, &M, &X, &Y);
	for (int i = 0; i < M; ++i)
	{
		int u, v, l;
		scanf("%d %d %d", &u, &v, &l);
		--u; --v;
		cost[u][v] = l;
		cost[v][u] = -l;
		c[u][v] = 1;
	}
	n = N;
	s = X - 1;
	t = Y - 1;

	int res = MinCost();
	printf("%d\n", res);
	for (int i = 0; i < res; ++i)
	{
		cur.resize(0);
		dfs(s);
		printf("%d", cur.size());
		for (int i = 0; i < cur.size(); ++i)
		{
			printf(" %d", cur[i] + 1);
		}
		printf("\n");
	}

	return 0;
}