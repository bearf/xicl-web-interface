#include <fstream>
using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");
/*
__int64 nod(__int64 a, __int64 b)
{
	while(a != b)
	{
		if(a > b)
			a = a-b;
		else
			b = b-a;
	}
	return a;
}*/
__int64 nod(__int64 a, __int64 b)
{
	while(a*b != 0)
	{
		if(a > b)
			a = a % b;
		else
			b = b % a;
	}
	if(a != 0)
		return a;
	else
		return b;
}


int main() 
{
	__int64 n, k, i, step = 0, j, *A, *Km, c;
	bool t = true, f = true;
	in >> n >> k;
	A = new __int64[n];
	Km = new __int64[k];
	for(i=0;i<n;i++)
		A[i] = i+1;

	while(t)
	{
		for(i=0;i<k;i++)
			Km[i] = k;
		for(i = 0; i < k; i++)
		{
			for(j = 1; j < n; j++)
			{
				c = nod(A[j],Km[i]);
				if(c != 1)
				{
					A[j] = A[j]/c;
					Km[i] = Km[i]/c;
					if(Km[i] == 1)
					{
						f = true;
						break;
					}
				}
			}
			if(Km[i] != 1)
			{
				f = false;
				break;
			}
		}
		if(f)
			step++;
		else
			t = false;
	}
	out << step;
	
	return 0;
}