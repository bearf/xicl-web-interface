#include <iostream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <cmath>
#include <sstream>
#include <cstring>
#include <string>

#define re return
#define mp make_pair
#define pb push_back
#define rep(i,n) for (int i = 0; i < n; i++)
#define fi first
#define se second
#define sz(x) ((int) (x).size())
#define all(x) ((x).begin(), (x).end())
#define fill(x, y) memset(x, y, sizeof(x))
#define y0 y49743
#define y1 y47543
#define sqr(x) ((x) * (x))

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef long long ll;
typedef double ld;
typedef vector<string> vs;

int n;
int m;

int g[20];
ld x[100], y[100], z[100];

ld dist[100][100];

ld getdist(int i, int j) {
	re sqrt(sqr(x[i] - x[j]) + sqr(y[i] - y[j]) + sqr(z[i] - z[j]));
}

int was[1000][100];
ld table[1000][100];

int good[100];

ld getans(int mask, int root) {
	if (mask == 0)
		re 0;

	if (was[mask][root])
		re table[mask][root];

	ld &ans = table[mask][root];

	ans = 1e10;
	was[mask][root] = 1;

	int col = 0;
	int last;
	rep(i, m - 1)
		if ((1 << i) & mask) {
			col++;
			last = i;
		}

	if (col == 1) {		
		ans = dist[root][g[last]];
		re ans;
	}

	for (int tmp = mask; tmp > 0; tmp = ((tmp - 1) & mask)) { 		
		ld zz = getans(mask - tmp, root);
		if (zz > ans)
			continue;
		rep(i, m)
			if ((1 << i) & tmp)
				ans = min(ans, dist[g[i]][root] + zz + getans(tmp - (1 << i), g[i]));
	}

	for (int tmp = mask; tmp > 0; tmp = ((tmp - 1) & mask)) { 		
		ld zz = getans(mask - tmp, root);
		if (zz > ans)
			continue;
		rep(i, n) 
			if (!good[i])
				ans = min(ans, dist[i][root] + zz + getans(tmp, i)); 			
	}

	re ans;
}

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	
	cin >> n;

	rep(i, n)
		cin >> x[i] >> y[i] >> z[i];
	cin >> m;
	rep(i, m) {
		cin >> g[i];
		g[i]--;
		good[g[i]] = 1;
		//cout << i << ' ' << g[i] << endl;
	}

	rep(i, n) rep(j, n)
		dist[i][j] = getdist(i, j);

	//cout << dist[1][2] << ' ' << dist[1][3] << endl;

	/*rep(i, (1 << (m - 1)))
		rep(j, n)	
			getans(i, j);*/

	int mask = (1 << (m - 1)) - 1;
	printf("%.3lf", (double) getans(mask, g[m - 1]));

	re 0;
}