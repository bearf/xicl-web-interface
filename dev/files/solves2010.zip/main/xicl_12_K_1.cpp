#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;

int p[1000000], s[1000000], w[1000000];
bool u[1000000];
int n, k, K;

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);

	scanf("%d%d", &n, &K);
	
	memset(u, 0, sizeof(u));

	int K1 = K;

	for(int i = 2; i <= (int)sqrt((double)K) + 1; i++)
		{
			while (K % i == 0)
			{
				K /= i;
				w[k] += K1;
				p[k] = i;
				k++;
			}
		}

	if (K != 1)
	{
		w[k] += K1;
		p[k] = K;
		k++;
	}

	for(int i = 0; i < k; i++)
	{
		int N = n;
		while (N > 0)
		{
			s[i] += N / p[i];
			N /= p[i];
		}
	}


	int ans = 2000000000;
	for(int i = 0; i < k; i++)
	{
		if (w[i] != 0)
		  ans = min(ans, s[i] / w[i]);
	}
	
			
	cout << ans << endl;

	return 0;
}
