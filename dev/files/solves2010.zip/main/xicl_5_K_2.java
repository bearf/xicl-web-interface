import java.io.*;
import java.util.*;

public class Solution
{
	public static void main(String[] args) throws IOException
	{
		StreamTokenizer in;
		PrintWriter out;
		
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new BufferedWriter(new FileWriter("output.txt")));
		
//		in = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
//		out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
		
		int n, k, kk;
		in.nextToken();
		n = (int) in.nval;
		in.nextToken();
		kk = k = (int) in.nval;
		
	if (k>n)
		out.println(0);
	else
	{
		Vector<Integer> v = new Vector<Integer>();
		Vector<Integer> v1 = new Vector<Integer>();
		Vector<Integer> v2 = new Vector<Integer>();

		int num;
		for (int i=2;i<=k/2+1;i++)
		{
			num = 0;
			while (kk%i==0)
			{
				kk /= i;
				num++;
			}
			if (num>0)
			{
				v.add(i);
				v1.add(num);
			}
		}
		
		for (int i=0;i<v.size();i++)
		{
			v1.set(i, v1.get(i)*k);
		}
		int p;
		for (int j = 0;j<v.size();j++)
		{
			p = v.get(j);
			num = 0;
			for (int i=p;i<=n;i+=p)
			{
				kk = i;
				while (kk%p==0)
				{
					kk /= p;
					num++;
				}
			}
			v2.add(num);
		}
		int min = Integer.MAX_VALUE;
		for (int i=0;i<v.size();i++)
		{
			num = v2.get(i)/v1.get(i);
			if (min>num)
				min = num;
		}
		
		
/*		for (int i=0;i<v.size();i++)
			out.println(v.get(i)+" "+v1.get(i)+" "+v2.get(i));*/
		out.println(min);
	}
		out.close();
	}
}