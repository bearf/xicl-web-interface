#include <fstream>
using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

int main() 
{
	__int64 n, k, i, step = 0, j, *A;
	bool t = true, f;
	in >> n >> k;
	A = new __int64[n];
	for(i=0;i<n;i++)
		A[i] = i+1;

	while(t)
	{
		for(i = 0; i < k; i++)
		{
			for(j = n-1; j >= 0; j--)
				if((A[j] % k) == 0)
				{
					A[j] = A[j]/k;
					f = true;
					break;
				}
			if(j == -1)
			{
				f = false;
				break;
			}
		}
		if(f)
			step++;
		else
			t = false;
	}
	out << step;
	
	return 0;
}