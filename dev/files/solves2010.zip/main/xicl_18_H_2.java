import java.lang.*;
import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {

	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	
	public static void main(String args[]) throws IOException{
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Solution()).run();
	}
	
	public void loadLine(){
		try{
			stk = new StringTokenizer(br.readLine());
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public String nextLine(){
		try{
			return (br.readLine());
		} catch(IOException e) {
			e.printStackTrace();
			return "";
		}
	}
	
	public String nextWord(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return stk.nextToken();
	}
	
	public Integer nextInt(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	public Double nextDouble(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return Double.parseDouble(stk.nextToken());
	}
	
	int[] dx = new int[] {-1,0,1,0};
	int[] dy = new int[] {0,1,0,-1};
	
	public void run() {
		int n = nextInt();
		int m = nextInt();
		boolean[][][] can = new boolean[4][n][m];
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < n; j++) 
				Arrays.fill(can[i][j], true);
		}
		for (int i = 0; i < m; i++) {
			can[0][0][i] = can[2][n-1][i] = false;  
		}
		for (int i = 0; i < n; i++) {
			can[3][i][0] = can[1][i][m-1] = false;  
		}
		can[3][n-2][0] = true;
		int k = nextInt();

		boolean[][][] used = new boolean[4][n][m];
		int x = n-nextInt();
		int y = nextInt()-1;
		char c = nextWord().charAt(0);
		int dir = 0;
		dir = (c=='E') ? 1 : dir;
		dir = (c=='S') ? 2 : dir;
		dir = (c=='W') ? 3 : dir;
		
		for (int i = 0; i < k; i++) {
			int y1 = nextInt();
			int x1 = n-nextInt();
			int y2 = nextInt();
			int x2 = n-nextInt();
			if (x1 == x2) {
				for (int j = Math.min(y2,y1); j < Math.max(y2,y1); j++) {
					if (x1 > 0) can[2][x1-1][j] = false;
					if (x1 < n) can[0][x1][j] = false; 
				}
			} else {
				for (int j = Math.min(x2,x1); j < Math.max(x2,x1); j++) {
					if (y1 > 0) can[1][j][y1-1] = false;
					if (y1 < m) can[3][j][y1] = false;
				}
			}
		}
		
		int cnt = 0;
		int ans = 0;
		boolean f = true;
		for (;;cnt++) {
			if (y < 0) break;
			if (used[dir][x][y]) {
				f = false;
				break;
			}
			used[dir][x][y] = true;
			if (!can[dir][x][y]) {
				dir = (dir+3)%4;
				continue;
			}
			if (!can[(dir+1)%4][x][y]) {
				x += dx[dir];
				y += dy[dir];
				ans++;
				continue;
			}
			dir = (dir+1)%4;
			x += dx[dir];
			y += dy[dir];
			ans++;
		}
		out.println(f ? "YES" : "NO");
		if (f) {
			out.println(ans);
		}
		out.flush();
	}
}
