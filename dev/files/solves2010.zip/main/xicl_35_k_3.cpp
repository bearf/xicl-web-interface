#include <fstream>
#include <vector>
using namespace std;
int step(int N,int K)
{
   int sum=0;
	for(int i=1;;i++)
	{
		if(N<=i*K)break;
		else 
		{
		 sum+=N/(i*K);
		};

	};
	return sum/K;
};


int main()
{
	ifstream cin("input.txt");
	ofstream cout("output.txt");
	int N,K;
	cin>>N>>K;
	vector <int> a;
	int i=2;
	int z=K;
	while(z!=1)
	{
		if(z%i==0)
		{
			a.push_back(i);
			z/=i;
			i=2;
		}
		else 
		i++;
	}
    vector <int> b;
	vector<int> c;
	c.resize(a.size());
	b.resize(a.size());
	int l=-1;
	int q=a[0];
	int k=1;
	for (int i=1; i<a.size(); i++)
	{
		if (a[i]==q) {k++;}
		else {
			l++;
			b[l]=q;
			c[l]=k;
			q=a[i];
			k=1;	
		}
	}
	l++;
	b[l]=q;
	c[l]=k;	
	for(int i=0;i<l;i++)
	{
		b[i]=step(N,b[i])/c[i];
	}
	int p=b[0];
    for(int i=0;i<l;i++)
	{
	if(p<b[i])p=b[i];
	}
	cout<<p;
	return 0;
}