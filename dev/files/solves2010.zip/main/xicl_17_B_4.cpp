#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>
#include <queue>

#include <cstdarg>

using namespace std;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	va_end(args);

	fflush(stderr);
#endif
#endif
}

typedef long long ll;
typedef unsigned long long ull;
typedef pair < int , int > pii;

#define clr(a) memset(a,0,sizeof(a))
#define fill(a,b) memset(a,b,sizeof(a))

const int NMAX = 128;
int w[NMAX][NMAX];
int d[NMAX];
int n;
int X,Y;

bool was[NMAX];

int c[NMAX][NMAX];
int f[NMAX][NMAX];

const int INF = 1000000000;

void ford(){
	for (int i = 1; i <= n; i++)
		d[i] = INF;
	d[X] = 0;
	bool ind = true;
	while (ind){
		ind = false;
		for (int i = 1; i <= n; i++){			
			for (int j = 1; j <= n; j++){
				if (d[i] + w[i][j] < d[j]){
					d[j] = d[i] + w[i][j];		
					ind = true;
				}
			}
		}
	}

	if (d[Y] == INF){
		printf("0\n");
		exit(0);
	}

	queue<int> q;
	q.push(Y);
	while (!q.empty()){
		int u = q.front();
		q.pop();
		if (was[u]) continue;
		was[u] = true;

		for (int i = 1; i <= n; i++){
			if (d[i] + w[i][u] == d[u]){
				c[i][u] = 1;
				f[i][u] = 1;
				q.push(i);
			}
		}
	}
}

int used[NMAX];
int Time;
bool dfs(int u){
	if (u == Y) return true;
	used[u] = Time;
	for (int i = 1; i <= n; i++){
		if (used[i] == Time) continue;
		if (c[u][i] && dfs(i)){
			c[u][i]--;
			c[i][u]++;
			return true;
		}
	}
	return false;
}

int max_flow(){
	int cnt = 0;
	Time++;
	while (dfs(X)){
		Time++;
		cnt++;
	}
	return cnt;
}

int arr[NMAX];
void print(int u, int cnt){
	if (u == Y){
		printf("%d ",cnt);
		for (int i = 0; i < cnt; i++)
			printf("%d ",arr[i]);
		printf("\n");
		return;
	}
	for (int i = 1; i <= n; i++){
		if (f[u][i] && !c[u][i]){
			arr[cnt] = i;
			f[u][i] = false;
			print(i,cnt+1);
			if (u != X)	break;
		}
	}
}

void printResult(int cnt){
	printf("%d\n",cnt);
	arr[0] = X;
	print(X,1);
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#ifdef DBG1
#if DBG2
	freopen("err.txt", "w", stderr);
#endif
#endif

	int m;
	scanf("%d%d%d%d",&n,&m,&X,&Y);
	for (int i = 0; i < NMAX; i++)
		for (int j = 0; j < NMAX; j++)
			w[i][j] = INF;

	for (int i = 0; i < m; i++){
		int a,b,W;
		scanf("%d%d%d",&a,&b,&W);
		w[a][b] = W;
	}

	ford();
	int res = max_flow();
	printResult(res);

	return 0;
}
