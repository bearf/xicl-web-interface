#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <queue>
#include <memory.h>
//#include <cmath>

using namespace std;


int Solve(int n, int k)
{
	int ret = 0;
	while (n > 0)
	{
		ret += n / k;
		n /= k;
	}
	return ret;
}

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	int k, n, K;
	scanf("%d %d", &n, &k);
	K = k;
	int res = 999999999;
	for (int i = 2; i * i <= k; ++i)
	{
		if (k % i == 0)
		{
			int j = 0;
			while (k % i == 0)
			{
				k /= i; ++j;
			}
			int z = Solve(n, i);
			res = min(res, z / (j * K));
		}
	}
	if (k > 1)
	{
		int z = Solve(n, k);
		res = min(res, z / K);
	}
	printf("%d", res);
	return 0;
}