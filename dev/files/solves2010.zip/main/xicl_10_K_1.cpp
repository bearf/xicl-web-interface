#include <iostream>
#include <cmath>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <sstream>
#include <string>
#include <algorithm>
#include <functional>
#include <numeric>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define ford(i, n) for(int i = int(n) - 1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define X first
#define Y second

typedef long double ld;
typedef long long li;
typedef pair<int, int> pt;

const int INF = (int)1E9;
const ld EPS = (1E-9);

const int NMAX = 2000000;

int p[NMAX], szp = 0;
int st[NMAX], ans = INF;

bool used[NMAX];

void gen(){
	fore(i, 2, NMAX){
		if(!used[i]){
			p[szp++] = i;
			for(int j = i + i; j < NMAX; j += i)
				used[j] = true;
		}
	}
}

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	gen();
	int n, k, kk;
	cin >> n >> k;
	kk = k;
	
	forn(i, szp){
		if(p[i] > n || p[i] > k) break;
		if(k % p[i] == 0){
			int cnt = 0;
			while(k % p[i] == 0){
				k /= p[i];
				cnt++;
			}
			
			int cnt2 = 0;
			li mul = p[i];
			while(mul <= n){
				cnt2 += (n / mul);
				mul *= p[i];
			}
			ans = min((cnt2 / cnt), ans);
		}
	}

	if(ans == INF) ans = 0;
	
	cout << ans / kk << endl;
	return 0;
}