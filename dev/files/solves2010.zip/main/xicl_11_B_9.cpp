#include <stdio.h>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <queue>
#include <deque>
#include <cassert>
#include <memory.h>
#include <algorithm>
#include <math.h>
#include <sstream>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) ((int)(a.size()))

const int INF = 1000000000;

void prepare()
{
	freopen("input.txt", "r", stdin);
#ifndef _DEBUG
	freopen("output.txt", "w", stdout);
#endif
}

#define MAXN 105

bool use[MAXN];

int is, sto;
int prev[MAXN];
vector< int > path;
int c[MAXN][MAXN], f[MAXN][MAXN], d[MAXN][MAXN];
int n, m;
int r[MAXN], p[MAXN];
int outCnt = 0;

int dij() {
	memset(use,0 , sizeof(use));
	for ( int i = 0;i < n; ++i ) r[i] = INF;
	r[is] = 0;
	prev[is] = -1;

	while (true) {
		int cur = -1;
		for (int i = 0; i < n; ++i)
			if (!use[i]) {
				if (cur == -1 || r[cur] > r[i]) {
					cur = i;
				}
			}

		if (cur == -1)
			break;
		use[cur] = true;
		if ( r[cur] >= INF ) break;

		for (int i = 0; i < n; ++i)
			if (c[cur][i] - f[cur][i] > 0) {
				int cost = d[cur][i];
				if (f[cur][i] < 0)
					cost = -d[i][cur];
				if (r[i] > p[i] - p[cur] + cost + r[cur]) {
					r[i] = p[i] - p[cur] + cost + r[cur];
					prev[i] = cur;
				}
			}
	}
	return 0;
}

bool w[MAXN][MAXN];

vector< vector< int > > ans;

void getAns(int id) {
	if (id == sto) {
		ans.pb( path );
		return;
	}
	for (int i = 0; i < n; ++i)
		if ( c[id][i] > 0 && r[i] == r[id] + d[id][i] ) 
		{
			c[id][i] = 0;
			path.pb( i );
			getAns( i );
			path.pop_back();
		}
		
}
bool solve()
{
	scanf( "%d%d", &n, &m );
	scanf( "%d%d", &is, &sto );
	-- is;
	-- sto;
	for ( int i = 0;i < m; ++ i ) 
	{
		int a, b, dd;
		scanf( "%d%d%d", &a, &b, &dd);
		-- a;
		-- b;
		d[a][b] = dd;
		c[a][b] = 1;
	}

	dij();

	getAns(is);
	
	printf( "%d\n", ans.size( ) );

	for ( int i = 0;i < ans.size(); ++i ) 
	{
		printf( "%d %d", ans[i].size( ) + 1, is + 1 );
		for ( int j = 0;j < ans[i].size( ); ++ j ) 
			printf( " %d", ans[i][j] + 1);
		printf( "\n" );
	}
	
	return false;
}

int main()
{
	prepare();
	while (solve());
	return 0;
}

