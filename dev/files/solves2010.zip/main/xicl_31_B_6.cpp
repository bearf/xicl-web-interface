#include <fstream>
#include <queue>
#define MAX 2000000
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");
int a[110][110];
int r[110], rr[110];
bool w[110];
int ans[110];
int al;
int uk[110];
int f[110][110];
int h[110];
int c[110];
int n, x, y, m;
int ddd(int x, int y) {
	for (int i = 0; i <= n; i++) r[i] = MAX;
	memset(w, 0, sizeof(w));
	memset(rr, 0, sizeof(rr));
	r[x] = 0;
	for (int qq = 0; qq < n; qq++) {
		int mn = -1;
		for (int i = 1; i <= n; i++) {
			if (!w[i]) {
				if (mn == -1 || r[mn] > r[i]) mn = i;
			}
		}
		w[mn] = true;
		for (int i = 1; i <= n; i++) {
			if (a[mn][i] != 0) {
				if (r[i] > r[mn] + a[mn][i]) {
					r[i] = r[mn] + a[mn][i];
					rr[i] = mn;
				}
			}
		}
	}
	return r[y];
}
queue<int> qu;
void lift(int q) {
	int mn = -1;
	for (int i = 1; i <= n; i++) {
		if (a[q][i] - f[q][i] > 0) {
			if (mn == -1 || h[mn] > h[i]) mn = i;
		}
	}
	h[q] = h[mn] + 1;
}
void push(int q, int w) {
	f[q][w] += 1;
	f[w][q] -= 1;
	c[q] -= 1;
	if (c[w] == 0 && w != x && w != y) qu.push(w);
	c[w] += 1;
}
void dis(int q) {
	while (c[q] > 0) {
		while (uk[q] <= n && c[q] > 0) {
			if (h[q] == h[uk[q]] + 1 && a[q][uk[q]] - f[q][uk[q]] > 0) {
				push(q, uk[q]);
			}
			if (c[q] != 0) uk[q]++;
		}
		if (c[q] > 0) {
			uk[q] = 1;
			lift(q);
		}
	}
}
bool dfs(int q) {
	if (q == y) {
		ans[al++] = y;
		return true;
	}
	for (int i = 1; i <= n; i++) {
		if (f[q][i] == 1) {
			if (dfs(i)) {
				ans[al++] = q;
				f[q][i] = 0;
				return true;
			}
		}
	}
	return false;
}
int main() {
	cin >> n >> m >> x >> y;
	for (int i = 0; i < m; i++) {
		int q, w, l;
		cin >> q >> w >> l;
		a[q][w] = l;
	}
	int krp = ddd(x, y);
	if (krp == MAX) {
		cout << "0";
		return 0;
	}
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			if (a[i][j] != 0 && r[i] + a[i][j] == r[j]) {
				a[i][j] = 1;
			} else a[i][j] = 0;
		}
	}
	memset(h, 0, sizeof(h));
	memset(f, 0, sizeof(f));
	memset(c, 0, sizeof(c));
	h[x] = n;
	for (int i = 1; i <= n; i++) {
		uk[i] = 1;
		if (a[x][i] != 0) {
			f[x][i] = 1;
			f[i][x] = -1;
			c[i] += 1;
			if (i != x && i != y) qu.push(i);
		}
	}
	while (!qu.empty()) {
		dis(qu.front()); qu.pop();
	}
	cout << c[y] << "\n";
	for (int i = 0; i < c[y]; i++) {
		al = 0;
		dfs(x);
		cout << al << " ";
		for (int j = al - 1; j >= 0; j--) cout << ans[j] << " ";
		cout << "\n";
	}
	return 0;
}