#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<stack>
#include<cmath>
using namespace std;

long long f(long long n, long long k){
	long long j=k,ans=0;
	while (n/j!=0){
		ans+=(n/j);
		j*=k;
	}
	return ans;
}

int main(){
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	long long n,k,k1,ans=1000000000; 
	cin>>n>>k;
	k1=k;
	int i=2;
	while (k1!=1){
		int c=0;
		while (k1%i==0){
			k1/=i;
			c++;
		}
		if (c!=0){
			ans=min(ans,f(n,i)/c);
		}
		i++;
	}
	ans/=k;
	cout<<ans;
	/*
	long long n,k,ans=0; 
	cin>>n>>k;
	for (int i=1;i<=n;i++){
		int j=i;
		while (j%k==0){
			j/=k;
			ans++;
		}
	}
	ans/=k;
	cout<<ans;*/
	return 0;
}