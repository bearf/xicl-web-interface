import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {
	static public void main(String[] args) throws IOException {
		new Solution().run();
	}
	StreamTokenizer in;
	PrintWriter out;
	void run() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		//solve();
		solve1();
		out.flush();
	}
	
	void solve1() throws IOException {
		int n = ni(), m = ni(), s = ni() - 1, f = ni()- 1;
		int e = 0;
		boolean can[] = new boolean [m];
		Arrays.fill(can, true);
		int to[]  = new int[m];
		int head[] = new int[n];
		Arrays.fill(head, -1);
		int next[] = new int[m];
		int wes[] = new int[m];
		boolean used[] = new boolean[n];
		int dist[] = new int[n];
		int par[] = new int [n];
		int rib[] = new int [n];
		for(int i = 0; i < m; ++i){
			int u = ni()- 1, v = ni() - 1, w = ni();
			to[e] = v; wes[e]  = w;next[e]=head[u];head[u]=e++;
		}
		LinkedList<Integer> [] ar = new LinkedList[n];
		for(int i = 0; i < n; ++i){
			ar[i] = new LinkedList<Integer>();
		}
		boolean first= true;
		int My=-1;
		int pt= 0;
		while ( true ) {
			Arrays.fill(dist, Integer.MAX_VALUE / 10);
			Arrays.fill(used, false);
			Arrays.fill(par, -1);
			dist[s] = 0;
			for(int i = 0; i < n; ++i){
				int v = -1;
				for(int j = 0; j < n; ++j){
					if (   !used[j] && ( v == -1 || dist[j] <= dist[v] ) ) 
						v = j;
				}
				if ( v == -1 ) break;
				if ( dist[v] > Integer.MAX_VALUE / 100 ) break;
				used[v] = true;
				for(int j = head[v]; j >= 0; j = next[j]) {
					if ( can[j] && ( dist[to[j]] > dist[v] + wes[j] ) ) {
						dist[to[j]] = dist[v] + wes[j];
						par[to[j]]=v;
						rib[to[j]]=j;
					}
				}
			}
			if ( dist[f] > Integer.MAX_VALUE / 100 ) break;
			
			int v = f;
			if ( first || dist[f] == My  ) {
				if ( first  ){
					My = dist[f];
					first= false;
				}
			} else break;
			LinkedList<Integer> path = new LinkedList<Integer>();
			while ( v != -1 ) {
				if ( par[v] != -1 ) 
					can[rib[v]]=false;
				path.add(v + 1);
				v = par[v];
			}
			ar[pt++] = path;
		}
		out.println(pt);
		for(int i = 0; i < pt; ++i){
			out.print(ar[i].size());
			out.print(' ');
			for(int j = ar[i].size() - 1; j >= 0; --j){
				out.print(ar[i].get(j));
				out.print(' ');
			}
			out.print('\n');
		}
	
	}
	
	void solve() throws IOException 
	{
		int n = ni(), m = ni(), k = ni();
		char a[][] = new char[2*n][2*m];
		for(int i = 0; i < 2 * n ; ++i)
			Arrays.fill(a[i], '.');
		for(int i = 0; i < 2 * n ; ++i)
			a[i][0] = a[i][2*m-1] = '-';
		for(int i = 0; i < 2 * m ; ++i)
			a[0][i] = a[2*n-1][i] = '-';
		
		int sx = 2*ni()-1, sy = 2*ni()-1;
		char dir =(char) ns();
		for(int i = 0; i < k; ++i){
			int y1 = ni(), x1 = ni(), y2 = ni(), x2 = ni();
			if ( x1 == x2 ) {
				int ny1 = 2 * Math.min(y1, y2) ;
				int ny2 = 2 * Math.max(y1, y2) ;
				for(int j = ny1; j <= ny2; ++j)
					a[j][2*x1] = '-';
				
			} else {
				int nx1 = 2 * Math.min(x1, x2) ;
				int nx2 = 2 * Math.max(x1, x2) ;
				for(int j = nx1; j <= nx2; ++j)
					a[2*y1][j] = '-';
			}
		}
		for(int i = 0 ; i < 2*n; ++i){
			for(int j = 0; j < 2*m; ++j )
				out.print(a[i][j]);
			out.print("\n");
		}
		
	}
	int ni() throws IOException {
		in.nextToken();
		return (int)in.nval;
	}
	char ns() throws IOException {
		in.nextToken();
		return in.sval.charAt(0);
	}
}
