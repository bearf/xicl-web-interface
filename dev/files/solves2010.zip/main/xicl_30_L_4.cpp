#define _CRT_SECURE_NO_DEPRECATE

#include<stdio.h>
#include<math.h>
#include<string>
#include<string.h>
#include<vector>
#include<set>
#include<map>
#include<algorithm>
#include<time.h>
#include<memory.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)
#define ZERO(x) memset(x, 0, sizeof(x))
#define SIZE(x) (int)x.size()

typedef pair<int, int> pii;
typedef long long int64;

int n, x;

#define MAX 200011

pii a[MAX];

int sum[MAX];

inline
int Sum(int x, int y) {
	return sum[y] - sum[x - 1];
}

void No() {
	printf("no\n");
	exit(0);
}

void Fun(int gl, int gr) {
	if (gl == gr) return;
	int l, r;
	int h;
	int m1, m2;
	l = gl;
	r = gr - 1;
	while (r - l > 1) {
		h = (l + r) / 2;
		m1 = Sum(gl, h);
		m2 = Sum(h + 1, gr);
		if (m1 < m2) {
			if (x * m1 < m2) {
				l = h;		
			} else {
				r = h;
			}
		} else {
			if (x * m2 < m1) {
				r = h;
			} else {
				l = h;
			}
		}
	}
	h = l;
	m1 = Sum(gl, h);
	m2 = Sum(h + 1, gr);
	if (m1 < m2) {
		if (x * m1 < m2) h++;
	}
	if (m2 < m1) {
		if (x * m2 < m1) h++;
	}
	m1 = Sum(gl, h);
	m2 = Sum(h + 1, gr);
	if (m1 < m2) {
		if (x * m1 < m2) No();
	}
	if (m2 < m1) {
		if (x * m2 < m1) No();
	}
	Fun(gl, h);
	Fun(h + 1, gr);
}

void Print(int gl, int gr) {
	if (gl == gr) {
		printf("%d", a[gl].second);
		return;
	}
	int l, r;
	int h;
	int m1, m2;
	l = gl;
	r = gr - 1;
	while (r - l > 1) {
		h = (l + r) / 2;
		m1 = Sum(gl, h);
		m2 = Sum(h + 1, gr);
		if (m1 < m2) {
			if (x * m1 < m2) {
				l = h;		
			} else {
				r = h;
			}
		} else {
			if (x * m2 < m1) {
				r = h;
			} else {
				l = h;
			}
		}
	}
	h = l;
	m1 = Sum(gl, h);
	m2 = Sum(h + 1, gr);
	if (m1 < m2) {
		if (x * m1 < m2) h++;
	}
	if (m2 < m1) {
		if (x * m2 < m1) h++;
	}
	m1 = Sum(gl, h);
	m2 = Sum(h + 1, gr);
	if (m1 < m2) {
		if (x * m1 < m2) No();
	}
	if (m2 < m1) {
		if (x * m2 < m1) No();
	}
	printf("(");
	Print(gl, h);
	printf(".");
	Print(h + 1, gr);
	printf(")");
}

int main() {
	int b;
	int i;
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf("%d %d", &n, &x);
	fi(1, n) {
		scanf("%d", &b);
		a[i] = mp(b, i);
	}
	sort(a + 1, a + n + 1);
	fi(1, n) {
		sum[i] = sum[i - 1] + a[i].first;
	}
	Fun(1, n);
	Print(1, n);
	return 0;
}
