#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <queue>
#include <memory.h>
//#include <cmath>

using namespace std;
#define LL long long
#define REP(i,n) for (int i = 0; i < n; ++i)

LL n, m;
LL c[100][100];
LL cm[50], tmp[50];

LL f (int n, int m){
	if (m==1) return n;
	int tek;
	if (m&1){
		tek = m;
		REP(i,m+1) cm[i] = 1;
	}else{
		tek = m+1;
		REP(i,m+1) cm[i] = i;
	};
	while (n > cm[m]){
		n -= cm[m];
		++tek;
		REP(i,m+1) tmp[i] = cm[i];
		for (int i = m; i >= 0; --i) if (i==0) cm[i] = 1; else cm[i] = cm[i-1]+tmp[i-1];
	};
	return tek;	
};

int main(){
	c[0][0] = 1;
	c[1][0] = c[1][1] = 1;
	for (int i = 2; i < 100; ++i){
		c[i][0] = c[i][i] = 1;
		for (int j = 1; j < i; ++j)
			c[i][j] = c[i-1][j-1] + c[i-1][j];
	};
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> n >> m;
	REP(i,m){
		LL p = f (n, m-i);
		n -= c[p][m-i];
		if (n < 0) n = -n;
		cout << p << " ";
	};
	return 0;
}