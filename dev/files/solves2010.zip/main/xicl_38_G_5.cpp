#include <iostream>
#include <algorithm>


using namespace std;
struct pnt{
	long long x,y;
	long long num;
};
bool comp(pnt a, pnt b){
	return a.num<b.num;
}
long long c[3];
long long procPr(pnt x){
	return c[0]*x.x+c[1]*x.y+c[2];
}
bool fff(long long a, long long b){
	if(a==0) return true;
	if(b==0) return false;
	a=a/abs(a);
	b=b/abs(b);
	return a*b<0;
}
int main(){
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
	long long n;
	cin>>n;
	pnt a[1010];
	for(long long i=0; i<n; i++){
		cin>>a[i].x>>a[i].y;
		a[i].num=i;
	}
	pair <long long, long long> f,l;
	cin>>f.first>>f.second>>l.first>>l.second;
	if(f==l){
		l.first=a[0].x;
		l.second=a[0].y;
	}
	c[0]=l.second-f.second;
	c[1]=f.first-l.first;
	c[2]=f.first*(f.second-l.second)+f.second*(l.first-f.first);
	pnt b[4];
	long long ff=0,ll=1;
	while(true){
		long long t=procPr(a[ff]);
		long long t1=procPr(a[ll]);
		if(fff(t,t1)){
			//cout<<a[ff].x<<' '<<a[ff].y<<endl;
			//cout<<a[ll].x<<' '<<a[ll].y<<endl;
			b[0]=a[ff];
			b[1]=a[ll];
			ff=(ff+2)%n;
			ll=(ll+2)%n;
			break;
		}else{
			ff=(ff+1)%n;
			ll=(ll+1)%n;
		}
	}
	while(true){
		long long t=procPr(a[ff]);
		long long t1=procPr(a[ll]);
		if(fff(t,t1)){
			b[2]=a[ff];
			b[3]=a[ll];
			ff=(ff+2)%n;
			ll=(ll+2)%n;
			break;
		}else{
			ff=(ff+1)%n;
			ll=(ll+1)%n;
		}
	}
	sort(b,b+4,comp);
	bool flag=false;
	for(int i=1; i<4; i++){
		if(b[i].num==b[i-1].num){
			flag=true;
			break;
		}
	}
	if(flag){
		ff=0,ll=n-1;
		while(true){
			long long t=procPr(a[ff]);
			long long t1=procPr(a[ll]);
			if(fff(t,t1)){
			//cout<<a[ff].x<<' '<<a[ff].y<<endl;
			//cout<<a[ll].x<<' '<<a[ll].y<<endl;
			b[0]=a[ff];
			b[1]=a[ll];
			ff=(ff-2+n)%n;
			ll=(ll-2+n)%n;
			break;
		}else{
			ff=(ff-1+n)%n;
			ll=(ll-1+n)%n;
		}
	}
	while(true){
			long long t=procPr(a[ff]);
			long long t1=procPr(a[ll]);
			if(fff(t,t1)){
				b[2]=a[ff];
				b[3]=a[ll];
				ff=(ff-2+n)%n;
				ll=(ll-2+n)%n;
				break;
			}else{
				ff=(ff-1+n)%n;
				ll=(ll-1+n)%n;
			}
		}
		sort(b,b+4,comp);
	}
	flag=false;
	for(int i=1; i<4; i++){
		if(b[i].num==b[i-1].num){
			flag=true;
			break;
		}
	}


	if(flag){

		ff=0,ll=1;
		while(true){
			long long t=procPr(a[ff]);
			long long t1=procPr(a[ll]);
			if(fff(t,t1)){
				//cout<<a[ff].x<<' '<<a[ff].y<<endl;
				//cout<<a[ll].x<<' '<<a[ll].y<<endl;
				b[0]=a[ff];
				b[1]=a[ll];
				ff=(ff+1)%n;
				ll=(ll+1)%n;
				b[2]=a[ll];
				b[3]=a[(ll+1)%n];
				break;
			}else{
				ff=(ff+1)%n;
				ll=(ll+1)%n;
			}
		}
		sort(b,b+4,comp);
	}

	for(int i=0; i<4; i++){
		cout<<b[i].x<<" "<<b[i].y<<endl;
	}
	cout.flush();
	return 0;
}