#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace std;

#define ret return
#define maxn 10002


struct P {
	int x,y;
};

P v1, v2;

int vect(int x1,int y1,int x2,int y2){
	return x1*y2-y1*x2;
}

int
pr(P a, P b, P p)
{
	return vect(b.x - a.x, b.y - a.y, p.x - a.x, p.y - a.y) <= 0;
}

int
fuck(const vector<P> &a, int from, int zap)
{
	int good = -1;
	for (int k = from + 1; k < int(a.size()) - zap; ++k) {
		if (pr(a[from], a[k], v1) && pr(a[from], a[k], v2)) {
			good = k;
		} else { 
			break;
		}
	}
	return good;
}

void
hui(P p) 
{
	cout << p.x << " " << p.y << endl;
}

int main(){
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	
	int n;
	cin >> n;
	
	vector<P> a(n);

	for (int i = 0; i < n; ++i) {
		cin >> a[i].x >> a[i].y;
	}
	
	
	cin >> v1.x >> v1.y;
	cin >> v2.x >> v2.y;


	for (int p1 = 0; p1 < n; ++p1) {
		int p2 = fuck(a, p1, 2);
		if (p2 == -1) continue;
		int p3 = fuck(a, p2, 1);
		if (p3 == -1) continue;
		int p4 = fuck(a, p3, 0);
		if (p4 == -1) continue;
		if (pr(a[p3], a[p4], v1) && pr(a[p3], a[p4], v2)) {
			
		} else {
			continue;
		}
		hui(a[p1]);
		hui(a[p2]);
		hui(a[p3]);
		hui(a[p4]);
		return 0;
	}

	cout << "HUI";
	return 0;

	

}






