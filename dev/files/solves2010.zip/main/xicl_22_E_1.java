import java.util.*;
import java.awt.geom.*;
import java.math.*;
import static java.lang.Math.*;
import java.io.*;


public class Solution implements Runnable{

	static BufferedReader br = null;
	static PrintWriter pw = null;
	static StringTokenizer stk = new StringTokenizer("");
	
	public static void main(String[] args) throws FileNotFoundException {
		br = new BufferedReader(new FileReader("input.txt")); 
		pw = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}

	void nline() {
		try {
			stk = new StringTokenizer(br.readLine());
		} catch (IOException e) {
			throw new RuntimeException("No new line");
		}
	}
	
	String nwrd() {
		while (!stk.hasMoreElements()) nline();
		return stk.nextToken();
	}
	

	int ni() {
		return Integer.valueOf(nwrd());
	}
	
	long nl() {
		return Long.valueOf(nwrd());
	}
	
	double nd() {
		return Double.valueOf(nwrd());
	}
	
	char nc() {
		return nwrd().charAt(0);
	}
	
	boolean isReady() {
		try {
			return br.ready();
		} catch (IOException e) {
			throw new RuntimeException("Something wrong in br");
		}
	}
	
	double dist(double[] a, double[] b) {
		double r = 0.0;
		for (int i=0;i<3;i++)
			r+=(b[i]-a[i])*(b[i]-a[i]);
		return r;
	}
	
	public void solve() {
		int n = ni();
		if (n==0) {
			pw.print("0.000");
			return;
		}
		double[][] coords = new double[n][3];
		for (int i=0;i<n;i++) 
			for (int j=0;j<3;j++)
				coords[i][j]=nd();
		boolean[] used = new boolean[n];
		used[0]=true;
		double[] mind = new double[n];
		for (int i=0;i<n;i++)
			mind[i]=dist(coords[0],coords[i]);
		double sd = 0.0;
		for (int i=0;i<n-1;i++) {
			double nead = 1e19;
			int nni = -1;
			for (int j=0;j<n;j++)
				if (!used[j]&&mind[j]<nead) {
					nead=mind[j];
					nni=j;
				}
			sd+=sqrt(nead);
			for (int j=0;j<n;j++)
				mind[j]=min(mind[j],dist(coords[nni],coords[j]));
			used[nni]=true;
		}
		Locale.setDefault(Locale.US);
		pw.printf("%.3f",sd);
	}
	
	public void run() {
		solve();
		pw.close();
	}

}
