#include <iostream>
#include <cstdio>
#include <vector>
#include <sstream>
#include <string>
#include <map>
#include <set>
#include <algorithm>
//#include <cmath>

using namespace std;

#define bublic public
#define sz size()
#define clr(a) memset(a,0,sizeof(a))
#define ll long long
#define ld long double
#define istr istringstream
#define pb push_back
#define forn(i,n) for(int i=0; i<n; i++)

const ld EPS=1e-9;
const ld PI=3.1415926535897932384626433832795;
const int INF=2000000000;

int n,m,k,x,y,a[420][420],x1,y1,x2,y2,u[420][420][4],d[4][2];
char c;


int main()
{
    freopen("input.txt","rt",stdin);
    freopen("output.txt","wt",stdout);    
    cout.flags(ios::fixed);
    cout.precision(10);
    cin>>n>>m>>k;
    cin>>y>>x>>c;
    x--;
    y--;    
    n*=3;
    m*=3;
    clr(a);    
   
    for(int i=0;i<n;i++)
    {
        a[i][0]=1;
        a[i][m-1]=1;
    }
    for(int i=0;i<m;i++)
    {
        a[0][i]=1;
        a[n-1][i]=1;
    }    
    a[4][0]=0;    
    for(int i=0;i<k;i++)
    {
        cin>>y1>>x1>>y2>>x2;
        for(int j=x1*3-1;j<x2*3+1;j++)
        for(int w=y1*3-1;w<y2*3+1;w++)
        if (j>=0 && w>=0)
        a[j][w]=1;
    }
    x=x*3+1;
    y=y*3+1;
  
    d[0][0]=1;
    d[0][1]=0;
    
    d[1][0]=0;
    d[1][1]=1;
    
    d[2][0]=-1;
    d[2][1]=0;
    
    d[3][0]=0;
    d[3][1]=-1;
    
    clr(u);
    int now;
    if (c=='N') now=0;
    if (c=='E') now=1;    
    if (c=='S') now=2;    
    if (c=='W') now=3;    
    int ans=0;
    a[x][y]=2;
    a[x+d[now][0]][y+d[now][1]]=4;
/*    for(int i=n-1;i>=0;i--)
    {
        for(int j=0;j<m;j++)
        cout<<a[i][j];
        cout<<endl;
    }
    cout<<endl;    
    return 0;*/
    while(true)
    {
//        break;
//        cout<<x<<" "<<y<<" "<<now<<endl;
        if (y<0 || x<0)
        {
            break;
        }
        if (u[x][y][now])
        {
            cout<<"NO";
            return 0;
        }
        u[x][y][now]=1;
        int px=x+d[now][0],py=y+d[now][1];
        if (a[px][py]==1)
        {
            now--;
            if (now<0) now+=4;
            continue;
        }
        px=x+d[(now+1)%4][0];
        py=y+d[(now+1)%4][1];        
        if (a[px][py]==1)
        {
            x+=d[now][0]*3;
            y+=d[now][1]*3;
            ans++;
            continue;
        }
        now++;
        now%=4;
        x+=d[now][0]*3;
        y+=d[now][1]*3;
        ans++;        
    }
    cout<<"YES"<<endl;    cout<<ans;
    cout<<endl;

    return 0;
}
