#include <iostream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <cmath>
#include <sstream>
#include <cstring>
#include <string>

#define re return
#define mp make_pair
#define pb push_back
#define rep(i,n) for (int i = 0; i < n; i++)
#define fi first
#define se second
#define sz(x) ((int) (x).size())
#define all(x) ((x).begin(), (x).end())
#define fill(x, y) memset(x, y, sizeof(x))
#define y0 y49743
#define y1 y47543

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef long long ll;
typedef long double ld;
typedef vector<string> vs;

int n;
int x[1005], y[1005];
int x1, y1, x2, y2;

int cross(int x1, int y1, int x2, int y2)
{
	re x1 * y2 - x2 * y1;
}

int gets(int x1, int y1, int x2, int y2)
{
	re abs(cross(x1, y1, x2, y2));
}

void del(int q){
	for (int i = q + 1; i < n; ++i){
		x[i - 1] = x[i];
		y[i - 1] = y[i];
	}
	--n;
}

bool check(int q){
	int a = (q + n - 1) % n;
	int b = (q + 1) % n;
//cout << a << " " << b << endl;

	ll a1 = (y[b] - y[a]) * (x[q] - x[a]) - (x[b] - x[a]) * (y[q] - y[a]);
	ll a2 = (y[b] - y[a]) * (x1 - x[a]) - (x[b] - x[a]) * (y1 - y[a]);
	ll a3 = (y[b] - y[a]) * (x2 - x[a]) - (x[b] - x[a]) * (y2 - y[a]);
	if (a1 * a2 <= 0 && a1 * a3 <= 0){
		del(q);
		return true;
	}
	return false;
}


int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	cin >> n;
	for(int i = 0; i < n; ++i)
			cin >> x[i] >> y[i];
	cin >> x1 >> y1 >> x2 >> y2;
	while(n > 4){
		for (int i = 0; i < n; ++i){
			if (check(i)) break;
		}
	}
	for (int i = 0; i < 4; ++i)
		cout << x[i] << ' ' << y[i] << endl;
	re 0;
}