#pragma comment( linker, "/stack:32000000" )
#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>

#define filein ""

void prepare( )
{
	freopen( "input.txt", "r", stdin );
#ifndef _DEBUG
	freopen( "output.txt", "w", stdout ); 
#endif
}

#include <cmath>
#include <cassert>
#include <memory.h>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>
#include <ctime>
#include <deque>

using namespace std;

#define fo(a,b,c) for(a=(b);a<(c);++a)
#define fr(a,b) fo(a,0,(b))
#define fi(a) fr(i,(a))
#define fj(a) fr(j,(a))
#define fk(a) fr(k,(a))
#define all(a) (a).begin(),(a).end()
#define sz(a) (int)(a).size()
#define pb push_back
#define mp make_pair
#define _(a,b) memset((a),(b),sizeof(a))
#define __(a) _((a),0)

typedef long long lint;

const double eps = 1e-9;

struct C
{
	double x, y;
	C( double _x, double _y ) { x = _x; y = _y; }
	C( ) { x = y = 0; }
	void read( ) { cin >> x >> y; }
};

bool eq( const double &a, const double &b )
{
	return a - b < eps && b - a < eps;
}

C operator+( const C &a, const C &b )
{
	return C( a.x + b.x, a.y + b.y );
}

C operator-( const C &a, const C &b )
{
	return C( a.x - b.x, a.y - b.y );
}

C operator*( const C &a, const double &b )
{
	return C( a.x * b, a.y * b );
}

C operator/( const C &a, const double &b )
{
	return C( a.x / b, a.y / b );
}

bool operator ==( const C &a, const C &b )
{
	return eq( a.x, b.x ) && eq( a.y, b.y );
}

struct Line
{
	C p1, p2;
	double a, b, c;
	Line( ) { }
	Line( const C &_p1, const C &_p2 )
	{
		p1 = _p1;
		p2 = _p2;
		a = p2.y - p1.y;
		b = p1.x - p2.x;
		c = -a * p1.x - b * p1.y;
	}
};

bool inLine( const Line &a, const C &p )
{
	return eq( a.a * p.x + a.b * p.y + a.c, 0 ) &&
		min( a.p1.x, a.p2.x ) < p.x + eps && max( a.p1.x, a.p2.x ) + eps > p.x &&
		min( a.p1.y, a.p2.y ) < p.y + eps && max( a.p1.y, a.p2.y ) + eps > p.y;
}

bool inter( const Line &a, const Line &b, C &p )
{
	double d = a.a * b.b - a.b * b.a;
	if ( eq( d, 0 ) )
	{
		if ( inLine( a, b.p1 ) && inLine( a, b.p2 ) )
			return true;
		return false;
	}
	p.x = - ( a.c * b.b - a.b * b.c ) / d;
	p.y = - ( a.a * b.c - a.c * b.a ) / d;
	return inLine( a, p );
}

const int MAXN = 1005;

int n, m;
C c[MAXN];
vector<Line> v;

int main( )
{
	prepare( );
	int i, j, k;
	scanf( "%d", &n );
	fi( n )
	{
		c[i].read( );
	}
	C st, en;
	st.read( );
	en.read( );
	if ( st == en )
	{
		fi( n )
		{
			if ( !( st == c[i] ) )
			{
				st = c[i];
				break;
			}
		}
	}
	c[n] = c[0];
	fi( n )
	{
		v.pb( Line( c[i], c[i + 1] ) );
	}
	Line t( st, en );
	vector<int> res;
	fi( n )
	{
		C tmp;
		if ( inter( v[i], t, tmp ) )
		{
			res.pb( i );
		}
	}
	assert( sz( res ) > 1 );
	for ( j = 0; j < sz( res ); ++ j )
	{
		fi( sz( res ) ) if ( i != j )
		{
			int d = abs( res[j] - res[i] );
			if ( d != 1 && d != n - 1 )
				break;
		}
		if ( i < sz( res ) )
			break;
	}
	assert( j < sz( res ) );
	vector<C> ans;
	ans.pb( v[res[j]].p1 );
	ans.pb( v[res[j]].p2 );
	ans.pb( v[res[i]].p1 );
	ans.pb( v[res[i]].p2 );
	fi( sz( ans ) )
	{
		printf( "%.0lf %.0lf\n", ans[i].x, ans[i].y );
	}
	return 0;
}