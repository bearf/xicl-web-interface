import java.io.*;
import java.lang.*;
import java.math.*;
import java.util.*;

public class Solution {
	
	int n;
	int[] x, y;
	int vx1, vy1, vx2, vy2;
	int l, r;
	
	void run() throws Exception{
		n = nextInt();
		x = new int[n]; y = new int[n];
		for (int i = 0; i < n; ++i){
			x[i] = nextInt();
			y[i] = nextInt();
		}
		vx1 = nextInt(); vy1 = nextInt();
		vx2 = nextInt(); vy2 = nextInt();
		preCalc();
		for (int i = 0; i < n; ++i){
			
			while (isOK(x[i], y[i], x[l], y[l]))
				l = (l + 1) % n;
			l = (l + n - 1) % n;
			
			while (!isOK(x[r], y[r], x[i], y[i]))
				r = (r + 1) % n;
			//r = (r + n - 1) % n;
			
			if (l == i || r == i || l == r)
				continue;
			if (trySolve(i, l, r))
				return;
			if (((l + n - 1) % n) != i && trySolve(i, (l + n - 1) % n, r))
				return;
			if (((r + 1) % n) != i && trySolve(i, l, (r + 1) % n))
				return;
			int j = (l + 1) % n;
			while (j != r){
				if (test(i, l, j, r)){
					wr(i, l, j, r);
					return;
				}
				/*if (isOK(x[l], y[l], x[j], y[j]) && isOK(x[j], y[j], x[r], y[r])){
					out.println(x[i] + " " + y[i]);
					out.println(x[l] + " " + y[l]);
					out.println(x[j] + " " + y[j]);
					out.println(x[r] + " " + y[r]);
					return;
				}*/
				j = (j + 1) % n;
			}
		}
	}
	
	private boolean trySolve(int i, int l, int r) {
		int j = (l + 1) % n;
		while (j != r){
			if (test(i, l, j, r)){
				wr(i, l, j, r);
				return true;
			}
			j = (j + 1) % n;
		}
		return false;
	}

	private void wr(int i, int l, int j, int r) {
		out.println(x[i] + " " + y[i]);
		out.println(x[l] + " " + y[l]);
		out.println(x[j] + " " + y[j]);
		out.println(x[r] + " " + y[r]);
	}

	private boolean test(int i, int l, int j, int r) {
		return isOK(x[l], y[l], x[j], y[j]) && isOK(x[j], y[j], x[r], y[r]);
	}

	private void preCalc() {
		l = 1;
		while (isOK(x[0], y[0], x[l], y[l]))
			l = (l + 1) % n;
		l = (l + n - 1) % n;
		r = n - 1;
		while (isOK(x[r], y[r], x[0], y[0]))
			r = (r + n - 1) % n;
		r = (r + 1) % n;
	}

	boolean isOK(int x1, int y1, int x2, int y2){
		return isOK(x1, y1, x2, y2, vx1, vy1) && isOK(x1, y1, x2, y2, vx2, vy2);
	}
	
	boolean isOK(int x1, int y1, int x2, int y2, int vx, int vy){
		int a = pssc(x2 - x1, y2 - y1, vx - x1, vy - y1);
		return a <= 0;
	}
	
	int pssc(int x1, int y1, int x2, int y2){
		return x1 * y2 - x2 * y1;
	}
	
	double nextDouble() throws NumberFormatException, IOException{
		return Double.parseDouble(nextToken());
	}
	
	long nextLong() throws NumberFormatException, IOException{
		return Long.parseLong(nextToken());
	}
	
	int nextInt() throws NumberFormatException, IOException{
		return Integer.parseInt(nextToken());
	}
	
	String nextToken() throws IOException{
		while (!St.hasMoreTokens()){
			String line = in.readLine();
			St = new StringTokenizer(line);
		}
		return St.nextToken();
	}
	
	BufferedReader in;
	StringTokenizer St;
	PrintWriter out;
	
	public Solution(){
		try{
			in = new BufferedReader(new FileReader("input.txt"));
			St = new StringTokenizer("");
			out = new PrintWriter(new FileWriter("output.txt"));
			
			run();
			
			in.close();
			out.close();
		}
		catch(Exception e){
			e.printStackTrace();
			System.exit(42);
		}
	}

	public static void main(String[] args) {
		new Solution();
	}

}
