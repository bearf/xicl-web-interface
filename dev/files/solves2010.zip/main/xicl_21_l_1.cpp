#include <iostream>
#include <fstream>
#include <queue>

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

struct elem {
	int w;
	elem(int W=0, int I=0, int I1=0, int I2=0)
	{
		w=W;
		i=I;
		i1=I1;
		i2=I2;
	}
	int i1, i2, i;
	bool operator<(const elem& rhs) const {
		return w > rhs.w;
	}
};

int n,x, curind;
priority_queue<elem, vector<elem>> q;
const int MAX=200011;
elem elems[MAX];

void printres(elem e)
{
	if(e.i1==0)
		out<<e.i+1;
	else {
		out<<"(";
		printres(elems[e.i1]);
		out<<".";
		printres(elems[e.i2]);
		out << ')';
	}
}

int main()
{
	int w;
	in>>n>>x;
	curind=n+1;
	for(int i=1;i<=n;i++)	
	{
		in>>w;
		elem e(w,i);
		q.push(e);
		elems[i+1]=e;
	}
	while(q.size()>1)
	{
		elem a=q.top();
		q.pop();
		elem b=q.top();
		q.pop();

		if(a.w*x>=b.w)
		{
			elem e(a.w+b.w, curind++, a.i, b.i);
			elems[curind-1]=e;
			q.push(e);
		}
		else
		{
			out<<"no"<<endl;
			return 0;
		}
	}
	printres(q.top());
	return 0;
}

