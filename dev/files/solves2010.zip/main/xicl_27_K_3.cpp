#include <iostream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <cmath>
#include <sstream>
#include <cstring>
#include <string>

#define re return
#define mp make_pair
#define pb push_back
#define rep(i,n) for (int i = 0; i < n; i++)
#define fi first
#define se second
#define sz(x) ((int) (x).size())
#define all(x) ((x).begin(), (x).end())
#define fill(x, y) memset(x, y, sizeof(x))
#define y0 y49743
#define y1 y47543

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef long long ll;
typedef long double ld;
typedef vector<string> vs;

int n;
int m;

int d[1000001];

void prep(int n) {
	for (int i = 2; i * i <= n; i++)
		if (d[i] == 0)
			for (int j = i; j * i <= n; j++)
				d[i * j] = 1;
}

int getans(int x) {
	int ans = 0;
	int n = ::n;	
	while (n > 0) {
		ans += n / x;
		n /= x;
	}

	re ans;
}

int step(int n, int p) {
	int ans = 0;
	while (n % p == 0) {
		ans++;
		n /= p;
	}
	re ans;
}


int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	cin >> n >> m;

	prep(m);

	int mm = 2000000;
	for (int i = 2; i <= m; i++) {
		if (d[i] == 0 && m % i == 0) {
			mm = min(mm, getans(i) / (m * step(m, i)));
			//cout << i << ' ' << getans(i) << ' ' << step(m, i) << endl;
		}
	}
	
	cout << mm;

	re 0;
}