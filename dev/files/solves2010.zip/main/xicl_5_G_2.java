import java.io.*;
import java.util.Vector;

public class Solution
{
	public static void main(String[] args) throws IOException
	{
		StreamTokenizer in;
		PrintWriter out;
		
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new BufferedWriter(new FileWriter("output.txt")));
		
//		in = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
//		out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
		
		in.nextToken();
		int n = (int) in.nval;
		
		int[] x = new int[n], y = new int[n];
		for (int i=0;i<n;i++)
		{
			in.nextToken();
			x[i] = (int) in.nval;
			in.nextToken();
			y[i] = (int) in.nval;
		}
		
		double k, b;
		int x1,x2,y1,y2;
		
		in.nextToken();
		x1 = (int) in.nval;
		in.nextToken();
		y1 = (int) in.nval;
		in.nextToken();
		x2 = (int) in.nval;
		in.nextToken();
		y2 = (int) in.nval;
		
		if (x2!=x1)
		{
			k = ((double)(y2-y1))/((double)(x2-x1));
			b = (double) y1- ((double)x1*(y2-y1))/((double)(x2-x1));
		}
		else
		{
			k = Double.MAX_VALUE;
			b = x1;
		}
		Vector<Integer> leftX = new Vector<Integer>();
		Vector<Integer> leftY = new Vector<Integer>();
		
		Vector<Integer> rightX = new Vector<Integer>();
		Vector<Integer> rightY = new Vector<Integer>();
		
		if (x1==x2)
		{
			for (int i=0;i<n;i++)
			{
				if (x[i]>x1)
				{
					rightX.add(x[i]);
					rightY.add(y[i]);
				} else
				{
					leftX.add(x[i]);
					leftY.add(y[i]);
				}
			}
		} else
		{
			for (int i=0;i<n;i++)
			{
				if ((double) y[i]>k*((double)x[i])+b)
				{
					rightX.add(x[i]);
					rightY.add(y[i]);
				} else
				{
					leftX.add(x[i]);
					leftY.add(y[i]);
				}
			}
		}
		
		int minX = 0, minY = 0, maxX = 0, maxY = 0;
		double ang, ang0 = Math.PI, ang180 = 0, AB = Math.hypot(x2-x1, y2-y1), AC, BC;
		
		for (int i=0;i<rightX.size();i++)
		{
			AC = Math.hypot(rightX.get(i)-x1, rightY.get(i)-y1);
			BC = Math.hypot(rightX.get(i)-x2, rightY.get(i)-y2);
			
			ang = Math.acos((AB*AB+BC*BC-AC*AC)/(2*AB*BC));
			if (ang<ang0)
			{
				ang0 = ang;
				minX = rightX.get(i);
				minY = rightY.get(i);
			}
			if (ang>ang180)
			{
				ang180 = ang;
				maxX = rightX.get(i);
				maxY = rightY.get(i);
			}
		}
		
		
		
		
		
		
		
		
		int LminX = 0, LminY = 0, LmaxX = 0, LmaxY = 0;
		ang0 = Math.PI;
		ang180 = 0;
		AB = Math.hypot(x2-x1, y2-y1);
		
		for (int i=0;i<leftX.size();i++)
		{
			AC = Math.hypot(leftX.get(i)-x1, leftY.get(i)-y1);
			BC = Math.hypot(leftX.get(i)-x2, leftY.get(i)-y2);
			
			ang = Math.acos((AB*AB+BC*BC-AC*AC)/(2*AB*BC));
			if (ang<ang0)
			{
				ang0 = ang;
				LminX = leftX.get(i);
				LminY = leftY.get(i);
			}
			if (ang>ang180)
			{
				ang180 = ang;
				LmaxX = leftX.get(i);
				LmaxY = leftY.get(i);
			}
		}
		
		if (minX==maxX && minY==maxY)
		{
			maxX = leftX.get(0);
			maxY = leftY.get(0);
		}
		
		if (LminX==LmaxX && LminY==LmaxY)
		{
			LmaxX = rightX.get(0);
			LmaxY = rightY.get(0);
		}
		
		
		
/*		out.println(minX+" "+minY);
		out.println(maxX+" "+maxY);
		
		out.println(LminX+" "+LminY);
		out.println(LmaxX+" "+LmaxY);
*/		
		
		for(int i=0;i<n;i++)
		{
			if (x[i]==minX && y[i]==minY)
				out.println(minX+" "+minY);
			
			if (x[i]==maxX && y[i]==maxY)
				out.println(maxX+" "+maxY);
			
			if (x[i]==LminX && y[i]==LminY)
				out.println(LminX+" "+LminY);
			
			if (x[i]==LmaxX && y[i]==LmaxY)
				out.println(LmaxX+" "+LmaxY);
			
		}
		
		
		
//		out.println(k+" "+b);
		
		
/*		for (int i=0;i<rightX.size();i++)
			out.println(rightX.get(i)+" "+rightY.get(i));*/
		
		out.close();
	}
}