#define _CRT_SECURE_NO_DEPRECATE
#include <cstdio>

bool V[128][128], H[128][128], B[128][128][4];

bool pered(int x, int y, int r)
{
	if(r==0) return H[x][y];
	if(r==1) return V[x][y];
	if(r==2) return H[x][y-1];
	return V[x-1][y];
}
void Step(int &x, int &y, int &r, int &S)
{
	S++;
	if(r==0) y++;
	else if(r==1) x++;
	else if(r==2) y--;
	else x--;
}

int main()
{
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);

	char c;
	int N, M, K, S, i, j, x, y, r, x1, y1, x2, y2;
	scanf("%d %d %d",&N, &M, &K);

	for(i=0; i<=M; i++)
		for(j=0; j<=N; j++)
			V[i][j] = H[i][j] = B[i][j][0] = B[i][j][1] = B[i][j][2] = B[i][j][3] = false;
	for(i=1; i<=N; i++)
		V[0][i] = V[M][i] = true;
	for(i=1; i<=M; i++)
		H[i][0] = H[i][N] = true;
	V[0][2] = false;

	scanf("%d %d %c", &x, &y, &c);
	if(c=='N') r=0;
	else if(c=='E') r=1;
	else if(c=='S') r=2;
	else if(c=='W') r=3;

	for(i=0; i<K; i++)
	{
		scanf("%d %d %d %d", &x1, &y1, &x2, &y2);
		if(x1==x2)
		{
			if(y1<y2) for(j=y1; j<=y2; j++) V[x1][j] = true;
			else for(j=y2; j<=y1; j++) V[x1][j] = true;
		}
		else 
		{
			if(x1<x2) for(j=x1+1; j<=x2; j++) H[j][y1] = true;
			else for(j=x2+1; j<=x1; j++) H[j][y1] = true;
		}
	}

	S=0;
	while(!((x==0 && y==2) || B[x][y][r]))
	{
		B[x][y][r] = true;
		if(pered(x, y, r))
		{
			if(r==0) r = 3;
			else r--;
		}
		else if(pered(x,y,(r+1)%4))
			Step(x, y, r, S);
		else
		{
			r = (r+1)%4;
			Step(x, y, r, S);
		}
	}

	if(x==0 && y==2)
		printf("YES\n%d", S);
	else printf("NO");
}