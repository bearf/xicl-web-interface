#include <iostream>
#include <cstdio>
#include <vector>
#include <sstream>
#include <string>
#include <map>
#include <set>
#include <algorithm>
//#include <cmath>

using namespace std;

#define bublic public
#define sz size()
#define clr(a) memset(a,0,sizeof(a))
#define ll long long
#define ld long double
#define istr istringstream
#define pb push_back
#define forn(i,n) for(int i=0; i<n; i++)

const ld EPS=1e-9;
const ld PI=3.1415926535897932384626433832795;
const int INF=2000000000;

vector <int> v;

int d[120],lst[120],a[120][120],f[120][120],c[120][120],n,m,x,y,X,Y,Z,e[120][120],u[120];

int way(int s, int t)
{
    for (int i=0; i<n; i++)
    d[i]=INF;
    d[s]=0;
    for (int i=0; i<n; i++)
    {
        bool can=true;
        for (int j=0; j<n; j++)
        for (int k=0; k<n; k++)
        {
            if (a[j][k]-f[j][k]>0 && d[j]+c[j][k]<d[k])
            {
                d[k]=d[j]+c[j][k];
                lst[k]=j;
                can=false;
            }
        }
        if (can) break;
    }
    return d[t];
}

int res(int s,int t)
{
    int ans=0; 
    while (true)
    {
        int q=way(s,t);
        if (q==INF) break;
        int k=t;
        while(k!=s)
        {
            ans+=c[lst[k]][k];
            f[lst[k]][k]++;
            f[k][lst[k]]--;
            k=lst[k];
        }
    }
    return ans;
}

int dijkstra(int s,int t)
{
    for (int i=0; i<n; i++)
    d[i]=INF;
    d[s]=0;
    clr(u);
    for(int i=0;i<n;i++)
    {
        int now=INF+1,bst=0;
        for(int j=0;j<n;j++)
        if (d[j]<now && !u[j])
        {
            now=d[j];
            bst=j;
        }
        u[bst]=1;
        for(int j=0;j<n;j++)
        {
            if (!u[j] && a[bst][j] && d[bst]+c[bst][j]<d[j])
            {
                d[j]=c[bst][j]+d[bst];
            }
        }        
    }
    return d[t];
}

void dfs(int x)
{
    v.pb(x);
    if (x==y)
    {
        return;
    }
    for(int i=0;i<n;i++)
    if (f[x][i]==1 && !e[x][i])
    {
        e[x][i]=1;
        dfs(i);
        return;
    }
}

int main()
{
    freopen("input.txt","rt",stdin);
    freopen("output.txt","wt",stdout);    
    cout.flags(ios::fixed);
    cout.precision(10);
    cin>>n>>m>>x>>y;
    x--;
    y--;
    clr(a);
    clr(f);
    clr(c);
    for(int i=0;i<m;i++)
    {
        scanf("%d%d%d",&X,&Y,&Z);
        X--;
        Y--;
        a[X][Y]=1;
        c[X][Y]=Z;
        e[X][Y]=Z;
    }
    int g=dijkstra(x,y);
    for(int i=0;i<n;i++)
    for(int j=0;j<n;j++)
    if (a[i][j])
    {
        if (dijkstra(x,i)+dijkstra(j,y)+c[i][j]>g)
        e[i][j]=0; else e[i][j]=1;
    }
    for(int i=0;i<n;i++)
    for(int j=0;j<n;j++)
    a[i][j]=e[i][j];    
    dijkstra(x,y);
    cout<<res(x,y)/g<<endl;
    clr(e);
    for(int i=0;i<n;i++)
    if (f[x][i]==1 && !e[x][i])
    {
        v.clear();
        dfs(x);
        cout<<v.sz;
        for(int j=0;j<v.sz;j++)
        printf(" %d",v[j]+1);
        puts("");
    }
    return 0;
}
