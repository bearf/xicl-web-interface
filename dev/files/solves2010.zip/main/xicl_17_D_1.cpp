#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>

#include <cstdarg>

using namespace std;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	va_end(args);

	fflush(stderr);
#endif
#endif
}

typedef long long ll;
typedef unsigned long long ull;
typedef pair < int , int > pii;

#define clr(a) memset(a,0,sizeof(a))
#define fill(a,b) memset(a,b,sizeof(a))

ll build(ll x, int m)
{
	ll cur = 1;
	ll first = 1;
	while(cur <= x - (m % 2))
	{
		cur = cur * (first + m) / first;
		first++;
	}
	printf("%I64d ", first + m - 1);
	return cur - x;
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#ifdef DBG1
#if DBG2
	freopen("err.txt", "w", stderr);
#endif
#endif
	ll n;
	int m;
	scanf("%I64d%d", &n, &m);
	while(m > 0)
		n = build(n, m--);
	//printf("%I64d\n", n);

	return 0;
}