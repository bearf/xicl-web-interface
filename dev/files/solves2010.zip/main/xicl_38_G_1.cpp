#include <iostream>
#include <algorithm>


using namespace std;
struct pnt{
	int x,y;
	int num;
};
bool comp(pnt a, pnt b){
	return a.num<b.num;
}
int c[3];
int procPr(pnt x){
	return c[0]*x.x+c[1]*x.y+c[2];
}
int main(){
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
	int n;
	cin>>n;
	pnt a[1010];
	for(int i=0; i<n; i++){
		cin>>a[i].x>>a[i].y;
		a[i].num=i;
	}
	pair <int, int> f,l;
	cin>>f.first>>f.second>>l.first>>l.second;
	
	c[0]=l.second-f.second;
	c[1]=f.first-l.first;
	c[2]=f.first*(f.second-l.second)+f.second*(l.first-f.first);
	pnt b[4];
	pnt c[1000];
	int k=0;
	
	int t=0;
	for(int i=0; i<n; i++){
		if(procPr(a[i])>=0){
			t=i;
			break;
		}
	}
	int ll=t;
	while(procPr(a[(ll-1+n)%n])>=0){
		ll=(ll-1+n)%n;
	}
	int ff=t;
	while(procPr(a[(ff+1)%n])>=0){
		ff++;
		ff%=n;
	}
	int cnt=0;
	t=ff;
	while((t+1)%n!=ll){
		t=(t+1)%n;
		cnt++;
	}
	if(cnt<2){
		if(procPr(a[ff])==0){
			ff=(ff-1+n)%n;
			cnt++;
		}
	}
	if(cnt<2){
		if(procPr(a[ll])==0){
			ll=(ll+1)%n;
			cnt++;
		}
	}
	b[0]=a[ff];
	b[1]=a[(ff+1)%n];
	b[2]=a[(ll-1+n)%n];
	b[3]=a[ll];
	sort(b,b+4,comp);
	for(int i=0; i<4; i++){
		cout<<b[i].x<<" "<<b[i].y<<endl;
	}
	cout.flush();
	return 0;
}