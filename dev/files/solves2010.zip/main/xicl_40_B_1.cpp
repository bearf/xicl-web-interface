// icl_g.cpp : Defines the entry point for the console application.
//

#include "stdio.h"
#include "conio.h"

int main()
{
	int i, j=0, n, x[1001]={0}, y[1001]={0}, edges[4]={-1}, n1x, n1y, n2x, n2y;
	double k, b, xp, yp, ks, bs, eps=0.000000001;
	
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	
	scanf("%d",&n);
	for(i=0;i<n;i++) scanf("\n%d %d",&x[i],&y[i]);
	scanf("\n%d %d\n%d %d",&n1x,&n1y,&n2x,&n2y);
	x[n]=x[0]; y[n]=y[0];
	
	if(n2x-n1x!=0)
	{
		ks=(n2y-n1y)/(n2x-n1x);
		bs=n2y-ks*n2x;}
	else
	{
		ks=11111111; bs=11111111;
	}

	for(i=0;i<n;i++)
	{
		if(x[i+1]!=x[i])
		{
			k=(y[i+1]-y[i])/(x[i+1]-x[i]);
			b=y[i]-k*x[i];
			xp=(bs-b)/(k-ks);
			yp=ks*xp+bs;
		}
		else
		{
			k=11111111; b=11111111;
			xp=x[i]; yp=ks*xp+bs;

		if ((xp-x[i]>=-eps)&&(xp-x[i+1]<=eps)&&(yp-y[i]>=-eps)&&(yp-y[i+1]<=eps)||
			(xp-x[i]>=-eps)&&(xp-x[i+1]<=eps)&&(yp-y[i]<=eps)&&(yp-y[i+1]>=-eps)||
			(xp-x[i]<=eps)&&(xp-x[i+1]>=-eps)&&(yp-y[i]<=eps)&&(yp-y[i+1]>=-eps)||
			(xp-x[i]<=eps)&&(xp-x[i+1]>=-eps)&&(yp-y[i]>=-eps)&&(yp-y[i+1]<=eps))
			edges[j++]=i;
		if(j==2) break;
	}

	if(edges[1]>edges[2])
	{
		int temp=edges[2]; edges[2]=edges[1]; edges[1]=temp;
	}
	if(edges[1]-edges[0]==1) edges[2]=edges[1]+1;
	
	if(edges[2]==-1) for(i=0;i<2;i++) printf("%d %d\n%d %d\n",x[edges[i]],y[edges[i]],x[edges[i]+1],y[edges[i]+1]);
	else
	{
		printf("%d %d",x[edges[0]],y[edges[0]]);
		printf("%d %d",x[edges[1]],y[edges[1]],x[edges[1]+1],y[edges[1]+1]);
		printf("%d %d",x[edges[2]],y[edges[2]]);
	}
		
	return 0;
}
