#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <queue>
#include <memory.h>
//#include <cmath>

using namespace std;

#define REP(i,n) for (int i = 0; i < n; ++i)

const string dirs = "NESW";
const int dr[4] = {1, 0, -1, 0};
const int dc[4] = {0, 1, 0, -1};

int m, n, k, r1, c1, r2, c2, ans;
string s;
int tr, tc, td;
bool was[200][200][4];
bool wall[200][200][4];

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> m >> n >> k;
	cin >> tr >> tc >> s;
	td = dirs.find(s);
	if (td<0 || td>3) while (true){};
	--tr; --tc;
	memset (was, false, sizeof (was));
	memset (wall, false, sizeof (wall));
	REP(i,n){
		wall[0][i][2] = true;
		wall[m-1][i][0] = true;
	};
	REP(i,m){
		wall[i][0][3] = true;
		wall[i][n-1][1] = true;
	};
	wall[1][0][3] = false;
	REP(i,k){
		cin >> c1 >> r1 >> c2 >> r2;
		if (r1 > r2) swap (r1, r2);
		if (c1 > c2) swap (c1, c2);
		c1 = max(0,c1); c1 = min(n,c1);
		c2 = max(0,c2); c2 = min(n,c2);
		r1 = max(0,r1); r1 = min(m,r1);
		r2 = max(0,r2); r2 = min(m,r2);
		if (r1==r2) for (int c = c1; c < c2; ++c){
			if (r1>0)
				wall[r1-1][c][0] = true;
			wall[r1][c][2] = true;
		};
		if (c1==c2) for (int r = r1; r < r2; ++r){
			if (c1>0)
				wall[r][c1-1][1] = true;
			wall[r][c1][3] = true;
		};
	};
	ans = 0;
	while (tr>=0 && tr < m && tc>=0 && tc<n && !was[tr][tc][td]){
		was[tr][tc][td] = true;
		if (wall[tr][tc][td]) td = (td+3)%4;
		else if (wall[tr][tc][(td+1)%4]){
			tr += dr[td];
			tc += dc[td];
			++ans;
		}
		else{
			td = (td+1)%4;
			tr += dr[td];
			tc += dc[td];
			++ans;
		};
	};
	if (tr>=0 && tr < m && tc>=0 && tc<n) printf ("NO\n");
	else printf ("YES\n%d\n", ans);
	return 0;
}