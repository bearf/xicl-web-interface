#pragma comment( linker, "/stack:32000000" )
#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>

#define filein ""

void prepare( )
{
	freopen( "input.txt", "r", stdin );
#ifndef _DEBUG
	freopen( "output.txt", "w", stdout ); 
#endif
}

#include <cmath>
#include <cassert>
#include <memory.h>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>
#include <ctime>
#include <deque>

using namespace std;

#define fo(a,b,c) for(a=(b);a<(c);++a)
#define fr(a,b) fo(a,0,(b))
#define fi(a) fr(i,(a))
#define fj(a) fr(j,(a))
#define fk(a) fr(k,(a))
#define all(a) (a).begin(),(a).end()
#define sz(a) (int)(a).size()
#define pb push_back
#define mp make_pair
#define _(a,b) memset((a),(b),sizeof(a))
#define __(a) _((a),0)

typedef long long lint;

lint n, m, a, b, c;

int main( )
{
	prepare( );
	lint i, j, k;
	cin >> n >> m >> a >> b >> c;
	lint res = 0;
	for( i = b; i < m - 1; ++ i )
		for ( j = max( a, c ); j < n - 1; ++ j )
		{
			res += i * ( i - b + 1 ) * ( j - a + 1 ) * ( j - c + 1 ) * ( n - j - 1 ) * ( m - i - 1 );
		}
	cout << res << "\n";
	return 0;
}