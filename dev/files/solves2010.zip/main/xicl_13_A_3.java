import java.io.*;
import java.util.*;
import java.math.*;

public class Solution {

	BufferedReader cin;
	PrintWriter cout;
	StringTokenizer tok;
	
	public static void main(String[] args) throws IOException 
	{
		new Solution().run();
	}

	void run() throws IOException
	{
		cin = new BufferedReader(new FileReader("input.txt"));
		cout = new PrintWriter(new FileWriter("output.txt"));
		
		solve();
		
		cout.flush();
		System.exit(0);
	}
	
	String next() throws IOException
	{
		if( tok == null || !tok.hasMoreTokens() )
			tok = new StringTokenizer(cin.readLine());
		
		return tok.nextToken();
	}
	
	int nextInt() throws IOException
	{
		return Integer.parseInt(next());
	}
	
	void solve() throws IOException
	{
		int n = nextInt(), m = nextInt(), a = nextInt(), b = nextInt(), c = nextInt();
		
		long ans = 0;
		
		for( int xt = 2 ; xt < m ; xt++ )
			for( int yt = 1 ; yt <= n - 1 - Math.max(a, c) ; yt++ )
						for( int xb = 2 ; xb <= m - b ; xb++ )
							for( int yb = yt + 1 + Math.max(a, c) ; yb <= n ; yb++ )
								ans += ((long)Math.min(xt, xb) - 1) * (yb - yt - a) * (m - Math.max(xt + 1, xb + b) + 1) * (yb - yt - c);  
		
		cout.print(ans);
	}
}
