#include <iostream>
#include <cmath>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <sstream>
#include <string>
#include <algorithm>
#include <functional>
#include <numeric>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define ford(i, n) for(int i = int(n) - 1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define X first
#define Y second

typedef long double ld;
typedef long long li;
typedef pair<ld, ld> pt;

const int INF = (int)1E9;
const ld EPS = (1E-9);

ld cross(const pt& a, const pt& b){
	return a.X * b.Y - a.Y * b.X;
}

ld S(pt& a, pt& b, pt& c){
	pt ab(b.X - a.X, b.Y - a.Y);
	pt ac(c.X - a.X, c.Y - a.Y);
	return (cross(ab, ac));
}

bool in(pt& a, pt& b, pt& c, pt& d, pt& N){
	ld s = fabs(S(a, b, c)) + fabs(S(a, c, d));
	ld cs = fabs(S(N, a, b)) + fabs(S(N, b, c)) + fabs(S(N, c, d)) + fabs(S(N, d, a));
	return fabs(cs - s) < EPS;
}

int n;
vector<pt> p;
pt V, U;

struct line{
	ld a, b, c;
	line(){}
	line(pt A, pt B){
		a = -(B.Y - A.Y), b = (B.X - A.X), c = -(A.X * a + b * A.Y);
	}

	ld get(pt A){
		return a * A.X + b * A.Y + c;
	}
};

int sign(ld a){
	if(fabs(a) < EPS) return 0;
	if(a < 0) return -1;
	return 1;
}

bool check(pt& a, pt& b, pt& c, pt& d){
	return in(a, b, c, d, U) && in(a, b, c, d, V);
}

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> n;
	p.resize(n);
	forn(i, n)
		cin >> p[i].X >> p[i].Y;
	
	cin >> V.X >> V.Y >> U.X >> U.Y;

	forn(i, n){
		int lf = (i - 1 + n) % n, rg = (i + 1) % n;
		line AV(p[i], V), AU(p[i], U);

		int sv = sign(AV.get(p[lf])), su = sign(AU.get(p[lf])); 
		while(true){
			int cv = sign(AV.get(p[lf])), cu = sign(AU.get(p[lf]));
			if(cv == 0 && cu == 0) break;
			if((cv == 0 && cu == su) || (cv == sv && cu == 0)) break;
			if(cv == 0 || cu == 0){
				lf = (lf + 1) % n;
				break;
			}
			if(!(sv == cv && su == cu)){
				lf = (lf + 1) % n;
				break;
			}
			lf = (lf - 1 + n) % n;
		}
		sv = sign(AV.get(p[rg])), su = sign(AU.get(p[rg])); 
		while(true){
			int cv = sign(AV.get(p[rg])), cu = sign(AU.get(p[rg]));
			if(cv == 0 && cu == 0) break;
			if((cv == 0 && cu == su) || (cv == sv && cu == 0)) break;
			if(cv == 0 || cu == 0){
				rg = (rg - 1 + n) % n;
				break;
			}
			if(!(sv == cv && su == cu)){
				rg = (rg - 1 + n) % n;
				break;
			}
			rg++;
			rg %= n;
		}

		if(rg == lf || (rg + 1) % n == lf){
			if((rg + 1) % n == lf){
				int t;
				if((lf - 1 + n) % n != i){
					t = lf;
					lf = (lf + 1) % n;
				}else{
					t = rg;
					rg = (rg - 1 + n) % n;
				}
				assert(check(p[i], p[rg], p[t], p[lf]));
				cout << int(p[i].X + 0.5) << " " << int(p[i].Y + 0.5) << endl;
				cout << int(p[rg].X + 0.5) << " " << int(p[rg].Y + 0.5) << endl;
				cout << int(p[t].X + 0.5) << " " << int(p[t].Y + 0.5) << endl;
				cout << int(p[lf].X + 0.5) << " " << int(p[lf].Y + 0.5) << endl;
				exit(0);
			}else{
				int t = lf;
				lf = (lf + 1) % n;
				rg = (rg - 1 + n) % n;
				assert(check(p[i], p[rg], p[t], p[lf]));
				cout << int(p[i].X + 0.5) << " " << int(p[i].Y + 0.5) << endl;
				cout << int(p[rg].X + 0.5) << " " << int(p[rg].Y + 0.5) << endl;
				cout << int(p[t].X + 0.5) << " " << int(p[t].Y + 0.5) << endl;
				cout << int(p[lf].X + 0.5) << " " << int(p[lf].Y + 0.5) << endl;
				exit(0);
			}
		}else{
			int t = (rg + 1) % n;
			while(t != lf){
				if(check(p[i], p[rg], p[t], p[lf])){
					cout << int(p[i].X + 0.5) << " " << int(p[i].Y + 0.5) << endl;
					cout << int(p[rg].X + 0.5) << " " << int(p[rg].Y + 0.5) << endl;
					cout << int(p[t].X + 0.5) << " " << int(p[t].Y + 0.5) << endl;
					cout << int(p[lf].X + 0.5) << " " << int(p[lf].Y + 0.5) << endl;
					exit(0);
				}
				t++;
				t %= n;
			}
		}
	}

	return 0;
}