import java.lang.*;
import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {

	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	
	public static void main(String args[]) throws IOException{
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Solution()).run();
	}
	
	public void loadLine(){
		try{
			stk = new StringTokenizer(br.readLine());
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public String nextLine(){
		try{
			return (br.readLine());
		} catch(IOException e) {
			e.printStackTrace();
			return "";
		}
	}
	
	public String nextWord(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return stk.nextToken();
	}
	
	public Integer nextInt(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	public Double nextDouble(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return Double.parseDouble(stk.nextToken());
	}
	
	public void run(){
		int n = nextInt();
		int m = nextInt();
		int a = nextInt();
		int b = nextInt();
		int c = nextInt();
		
		long res = 0;
		
		for (int i = 0; i < n-1; ++i) {
			for (int k = i+1; k < n; ++k) {
				if (k-i > b && k-i > c) {
					int leng = k-i-1;
					for (int j = 1; j < m-a; ++j) {
						for (int l = 1; l < m-1; ++l) {
							int x1 = Math.min(j, l);
							int x2 = m - Math.max(j+a, l+1);
							res += 1L*x1*(leng-b+1)*x2*(leng-c+1);
						}
					}
				}
			}
		}
		
		out.println(res);
		out.flush();
	}
}
