#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<stack>
#include<cmath>
using namespace std;
int b[200][200];
int n,m,k;

void kras(int x1,int y1,int x2,int y2){
	if(x1==x2){
		for(int i=min(y1,y2); i<=max(y1,y2); i++){
			b[x1][i]=1;
		}
	}
	if(y1==y2){
		for(int i=min(x1,x2); i<=max(x1,x2); i++){
			b[i][y1]=1;
		}
	}
}

int main(){
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	
	cin>>n>>m>>k;
	int x,y;
	char ch;
	
	memset(b,0,sizeof(b));
	cin>>x>>y>>ch;
	for(int i=0; i<=m; i++){
		b[0][i]=1;
		b[n+1][i]=1;
	}
	for(int i=0; i<=n; i++){
		b[i][0]=1;
		b[i][m+1]=1;
	}
	for(int i=0; i<k; i++){
		int x1,y1,x2,y2;
		cin>>x1>>y1>>x2>>y2;
		kras(x1,y1,x2,y2);
	}
	
	if(x==0 && y<2){
		cout<<"YES"<<endl;
		cout<<0;
		return 0;
		}
		
	if(b[x][y]==1){
		cout<<"NO";
		cout.flush();
		return 0;
	}
	swap(x,y);
	int dy[]={-1, 0, 1, 0};
	int dx[]={0, 1, 0, -1};
	int napr;
	if(ch=='N'){
		napr=2;
	}
	if(ch=='E'){
		napr=1;
	}
	if(ch=='S'){
		napr=0;
	}
	if(ch=='W'){
		napr=3;
	}
	int cnt=0;
	while(true){
		
		if(cnt>10000000){
			cout<<"NO";
			return 0;
		}
		if(y==1 && x==1 && napr==0){
			break;
		}
		if(y==1 && x==2 && napr==0){
			break;
		}

		if(b[y+dy[napr]][x+dx[napr]]==1){
			napr=(napr-1+4)%4;
			cnt++;
			continue;
		}
		if(b[y+dy[(napr+1)%4]][x+dx[(napr+1)%4]]==1){
			y=y+dy[napr];
			x=x+dx[napr];
			cnt++;
			continue;
		}
		napr=(napr+1)%4;
		y=y+dy[napr];
		x=x+dx[napr];
		cnt++;
		
	}
	cout<<"YES"<<endl<<cnt;
	cout.flush();

	return 0;
}