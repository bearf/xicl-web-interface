#include <iostream>
#include <ctime>
#include <cmath>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <sstream>
#include <string>
#include <algorithm>
#include <functional>
#include <numeric>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define ford(i, n) for(int i = int(n) - 1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define X first
#define Y second

typedef long double ld;
typedef long long li;
typedef pair<int, int> pt;

const int INF = (int)1E9;
const ld EPS = (1E-9);

const int NMAX = 1000;

li n, k;
li C[40][40];

int cnt;
int ans[100];

set< pair<int, pair<int, li> > > used;

const int SMAX = 5000000;

void solve(int idx, int prev, li sum){

	pair<int, pair<int, li> > cur = mp(idx, mp(prev, sum));
	if(used.count(cur))
		return;

	if(sz(used) <= SMAX)
		used.insert(cur);

	if(idx == k){
		if(sum == n){
			ford(i, k)
				cout << ans[i] << " ";
			cout << endl;

			exit(0);
		}
		return;
	}

	if(sum > 3*n || (35 - prev < k - idx + 1))
		return;

	int mn = ((k - idx) & 1) ? 1 : -1;
	for(int j = prev + 1; j < 35; ++j){
		ans[idx] = j;
		solve(idx + 1, j, sum + C[j][idx + 1] * (mn));
	}
}



void fillC(){
	C[0][0] = 1;
	for(int i = 1; i < 40; ++i){
		C[i][0] = 1;
		for(int j = 1; j <= i; ++j){
			C[i][j] = C[i - 1][j] + C[i - 1][j - 1];
			if(C[i][j] > 1e10){
				C[i][j] = 1e10;
			}
		}
	}
}

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	fillC();

	cin >> n >> k;

	solve(0, 0, 0);

	cerr << clock() << endl;
	return 0;
}