#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;

const int INF = 100000000;

struct rec
{
	int w, id, l, r;
	rec () {};
	rec(int w1, int id1, int l1, int r1)
	{
		w = w1;
		id = id1;
		l = l1;
		r = r1;
	}
};

bool operator < (rec a, rec b)
{
	if (a.w != b.w)
		return a.w < b.w;
	else
		return a.id < b.id;
}

int n, x, list= 0 ;
rec a[400000];

set<rec> st;

void answer(rec s)
{
	if (s.r == INF)
		printf("%d", s.id + 1);
	else
	{
		printf("(");
		answer(a[ s.l]);
		printf(".");
		answer(a[ s.r]);
		printf(")");
		return;
	}
}

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);

	scanf("%d%d", &n, &x);
	for(int i = 0; i < n; i++)
	{
		int r;
		scanf("%d", &r);
		a[i].w = r;
		a[i].id = i;
		a[i].l = i;
		a[i].r = INF;

		st.insert(a[i]);
	}

	list = n;

	rec x1, x2;

	while (true)
	{
		x1 = *st.begin();
		st.erase(st.begin());
		
		if (st.empty())
			break;

		x2 = *st.begin();
		st.erase(st.begin());
		
		if (x1.w * x >= x2.w &&
			x2.w * x >= x1.w)
		{

		a[list].w = x1.w + x2.w;
		a[list].id = list;
		a[list].l = x1.id;
		a[list].r = x2.id;

		st.insert( a[list] );
		list++;
		}
		else
		{
			printf("no\n");
			return 0;
		};
	}


	answer(x1);

	return 0;
}
