#include <fstream>
using namespace std;
int main()
{
	ifstream cin("input.txt");
	ofstream cout("output.txt");
	int N,K;
	cin>>N>>K;
	int sum=0;
	for(int i=1;;i++)
	{
		if(N<=i*K)break;
		else 
		{
		 sum+=N/(i*K);
		};

	};
	cout<<sum/K;
	return 0;
}