#include <fstream>
#define eps 1e-9
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");
struct Point {
	int x,y;
};
Point a[1010];
bool u[1010];
Point v1,v2;

bool check(Point p1,Point p2,Point p3) {
	return ( (p2.x-p1.x)*(p3.y-p1.y)-(p3.x-p1.x)*(p2.y-p1.y) < eps);
}
int n,cnt;
int main() {
	cin >> n;
	int i;
	for (i=0;i<n;i++) {
		cin >> a[i].x >> a[i].y;
	}
	cin >> v1.x >> v1.y >> v2.x >> v2.y;
	memset(u,false,sizeof(u));
	cnt = n;
	int j,k;
	bool f;
	while (cnt > 4) {
		i=0;
		f = false;
		while (i < n && cnt > 4) {
			j = (i+1)%n;while (u[j] && j != i) j = (j+1)%n;
			k = (j+1)%n;while (u[k] && k != i) k = (k+1)%n;
			if (check(a[i],a[k],v1) && check(a[i],a[k],v2)) {
				u[j] = true;
				cnt--;
				i=k;
				f = true;
			} else {
				j = i+1;while (j<n && u[j] && j!=i) j = j+1;
				i = j;
			}
		}
		if (!f) break;
	}
	for (int i=0;i<n;i++) {
		if (!u[i]) cout << a[i].x << " " << a[i].y << "\n";
	}
	return 0;
}