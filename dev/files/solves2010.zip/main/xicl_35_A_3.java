import java.io.*;
import java.util.*;
import java.math.*;

public class Solution {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(new File("input.txt"));
		PrintWriter out = new PrintWriter(new File("output.txt"));
		int n= in.nextInt();
		int m=in.nextInt();
		int a= in.nextInt();
		int b=in.nextInt();
		int c= in.nextInt();
		BigInteger[][] room = new BigInteger[n+1][m+1];
		BigInteger tmp;
		for (int i=0; i<=n; i++){
			for (int j=0; j<=m; j++){
				room[i][j]=BigInteger.ZERO;				
			}
		}
		int x=a; if(c>x) x=c;
		int y=b;
		if ((x+2>n) || (y+2>m)){
			out.print(0);
		} else {
			room[x+2][y+2]=new BigInteger(String.valueOf((x+x-a-c+1)*(y+y-b)));
		    for (int i=x+3; i<=n; i++){
		    	room[i][y+2]=room[i-1][y+2].add(room[i-1][y+2]).add(new BigInteger(String.valueOf((i-1-a)*(i-1-c)*(y+1-b)*(y))));
		    }
		    for (int j=y+3; j<=m; j++){
		    	room[x+2][j]=room[x+2][j-1].add(room[x+2][j-1]).add(new BigInteger(String.valueOf((x+1-a)*(x+1-c)*(j-1-b)*(j-2))));
		    }
		    for (int i=x+3; i<=n; i++){
		    	for (int j=y+3; j<=m; j++){
		    		tmp=room[i-1][j].shiftLeft(1);
		    		room[i][j]=tmp;
		    		tmp=room[i][j-1].shiftLeft(1);
		    		room[i][j]=room[i][j].add(tmp);
		    		tmp=room[i-1][j-1].shiftLeft(2);
		    		room[i][j]=room[i][j].subtract(tmp);
		    		room[i][j]=room[i][j].add(new BigInteger(String.valueOf((i-1-a)*(i-1-c)*(j-1-b)*(j-2))));
		    	}
		    }		    
		    out.print((room[n][m].toString()));
		}
		out.flush();
	}

}
