import java.util.*;
import java.awt.geom.*;
import java.math.*;
import static java.lang.Math.*;
import java.io.*;

public class Solution implements Runnable {

	static BufferedReader br = null;
	static PrintWriter pw = null;
	static StringTokenizer stk = new StringTokenizer("");

	public static void main(String[] args) throws FileNotFoundException {
		br = new BufferedReader(new FileReader("input.txt"));
		pw = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}

	void nline() {
		try {
			stk = new StringTokenizer(br.readLine());
		} catch (IOException e) {
			throw new RuntimeException("No new line");
		}
	}

	String nwrd() {
		while (!stk.hasMoreElements())
			nline();
		return stk.nextToken();
	}

	int ni() {
		return Integer.valueOf(nwrd());
	}

	long nl() {
		return Long.valueOf(nwrd());
	}

	double nd() {
		return Double.valueOf(nwrd());
	}

	char nc() {
		return nwrd().charAt(0);
	}

	boolean isReady() {
		try {
			return br.ready();
		} catch (IOException e) {
			throw new RuntimeException("Something wrong in br");
		}
	}

	int n, m, a, b;
	int M = Integer.MAX_VALUE;
	List<int[]> ans = new LinkedList<int[]>();
	
	Edge edges[];
	int[] index;
	public void solve() {
		n = ni();
		m = ni();
		a = ni()-1;
		b = ni()-1;
		edges = new Edge[m];
		for (int i = 0; i < m; i++)
			edges[i] = new Edge(ni()-1, ni()-1, ni());
		Arrays.sort(edges);
		index = new int[n+1];
		Arrays.fill(index, -1);
		for (int i=m-1;i>=0;i--)
			index[edges[i].fr]=i;
		index[n]=m;
		int cu = m;
		for (int i=n-1;i>=0;i--)
			if (index[i]==-1)
				index[i]=cu;
			else cu=index[i];
		while (dijkstra());
		pw.println(ans.size());
		for (int[] xx : ans) {
			int cur = b;
			String otv = (b+1)+"";
			int cc = 1;
			while (cur!=a) {
				edges[xx[cur]].e=false;
				cur=edges[xx[cur]].fr;
				otv=(cur+1)+" "+otv;
				cc++;
			}
			pw.println(cc+" "+otv);
		}
	}
	final int MAX = 1000000;
	private boolean dijkstra() {
		int[] dist = new int[n];
		int[] from = new int[n];
		TreeSet<Integer> ddi = new TreeSet<Integer>();
		for (int i=0;i<n;i++)
			dist[i]=MAX;
		dist[a]=0;
		Arrays.fill(from, -1);
		for (int i=0;i<n;i++)
			ddi.add(dist[i]*n+i);
		for (int kj=0;kj<n;kj++) {
			int di = ddi.pollFirst();
			if (di/n==MAX) break;
			int ind = di%n;
			di/=n;
			for (int i=index[ind];i<index[ind+1];i++)
				if (edges[i].e&&di+edges[i].v<dist[edges[i].to]) {
					ddi.remove(dist[edges[i].to]*n+edges[i].to);
					dist[edges[i].to]=di+edges[i].v;
					ddi.add(dist[edges[i].to]*n+edges[i].to);
					from[edges[i].to]=i;
				}
		}
		if (from[b]==-1||dist[b]>M) {
			return false;
		}
		M=dist[b];
		ans.add(from);
		int cur = b;
		while (cur!=a) {
			edges[from[cur]].e=false;
			cur=edges[from[cur]].fr;
		}
		return true;
	}

	class Edge implements Comparable<Edge> {

		int fr;
		int to;
		int v;
		boolean e;

		public Edge(int fr, int to, int v) {
			this.fr = fr;
			this.to = to;
			this.v = v;
			e = true;
		}

		@Override
		public int compareTo(Edge o) {
			if (this.fr < o.fr)
				return -1;
			if (this.fr == o.fr)
				return v - o.v;
			return 1;
		}
	}

	public void run() {
		solve();
		pw.close();
	}

}
