#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <math.h>
#include <time.h>
#pragma comment (linker,"/STACK:32000000")
using namespace std;
int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long n,k,s = 0;
	cin >> n >> k;

	while (1)
	{
		s += (n / k);
		n = n / k;
		if (n==0)
			break;
	}
	cout << s / k;


	return 0;
}
