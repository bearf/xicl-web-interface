import java.io.*;
import java.util.*;
import java.math.*;

public class Solution {

	BufferedReader cin;
	PrintWriter cout;
	StringTokenizer tok;
	
	public static void main(String[] args) throws IOException 
	{
		new Solution().run();
	}

	void run() throws IOException
	{
		cin = new BufferedReader(new FileReader("input.txt"));
		cout = new PrintWriter(new FileWriter("output.txt"));
		
		solve();
		
		cout.flush();
		System.exit(0);
	}
	
	String next() throws IOException
	{
		if( tok == null || !tok.hasMoreTokens() )
			tok = new StringTokenizer(cin.readLine());
		
		return tok.nextToken();
	}
	
	int nextInt() throws IOException
	{
		return Integer.parseInt(next());
	}
	
	ArrayList<int[]> walls;
	
	void solve() throws IOException
	{
		walls = new ArrayList<int[]>();
		
		int n = nextInt(), m = nextInt(), k = nextInt();
		
		int[] wall = new int[4];
		
		// top
		wall[0] = 0; 
		wall[1] = n;
		wall[2] = m;
		wall[3] = n;
						
		walls.add(wall.clone());
		
		// left
		wall[0] = 0; 
		wall[1] = 0;
		wall[2] = 0;
		wall[3] = n;
					
		// right
		walls.add(wall.clone());
		wall[0] = m; 
		wall[1] = 0;
		wall[2] = m;
		wall[3] = n;
					
		// bottom
		walls.add(wall.clone());
		wall[0] = 0; 
		wall[1] = 0;
		wall[2] = m;
		wall[3] = 0;
						
		walls.add(wall.clone());
		
		Kengooroo ken = new Kengooroo(nextInt(), nextInt(), next());
		
		for( int i = 0 ; i < k ; i++ )
		{
			for( int j = 0 ; j < 4 ; j++ )
				wall[j] = nextInt();
			
			walls.add(wall.clone());
		}
		
		while( !ken.findExit && ken.stepCount < 100000 )
			ken.move();
		
		if( ken.findExit )
		{
			cout.println("YES");
			cout.println(ken.stepCount);
		}
		else
			cout.println("NO");
	}

	int[] turnRight(int[] v)
	{
		int[] rt = new int[2];
		rt[0] = v[1];
		rt[1] = - v[0];
		
		return rt;
	}
	
	int[] turnLeft(int[] v)
	{
		int[] rt = new int[2];
		rt[0] = - v[1];
		rt[1] = v[0];
		
		return rt;		
	}
	
	boolean isWall(int x , int y , int[] way)
	{		
		for( int i = 0 ; i < walls.size() ; i++ )
		{
			int[] wall = walls.get(i);
			
			if( (wall[0] == wall[2]) && (wall[0] == x) && (way[0] == 0) )
			{
				int x1 = Math.min(wall[0], wall[2]);
				int x2 = Math.max(wall[0], wall[2]);
				int x3 = Math.min(x, x + way[0]); 
				int x4 = Math.max(x, x + way[0]);
				if( x3 >= x1 && x4 <= x2 )
					return true;
			}
			if( (wall[1] == wall[3]) && (wall[1] == y) && (way[1] == 0) )
			{
				int y1 = Math.min(wall[1], wall[3]);
				int y2 = Math.max(wall[1], wall[3]);
				int y3 = Math.min(y, y + way[1]); 
				int y4 = Math.max(y, y + way[1]);
				if( y3 >= y1 && y4 <= y2 )
					return true;				
			}
		}
		
		return false;
	}
	
	class Kengooroo
	{
		final int[][] ways = {{1, 0}, {0, -1}, {-1, 0}, {0, 1}};
		
		int x , y;
		int state;
		int stepCount = 0;
		
		Kengooroo(int x , int y, String sState){
			this.x = x;
			this.y = y;
			switch(sState.charAt(0))
			{
				case 'N': state = 3;
				case 'E': state = 0;
				case 'S': state = 1;
				case 'W': state = 2;
			}
		}

		boolean findExit = false;

		void move()
		{
			stepCount++;
			
			if( x == 0 && y == 1 && state == 2 )
			{
				findExit = true;
				return;
			}
			    
			if( isWall(x - 1 + ways[state][0], y - 1 + ways[state][1], turnRight(ways[state]) ) )
				state = (state - 1) % 4;
			else
			{
				int[] right = turnRight(ways[state]);
				if( isWall(x - 1 + right[0], y - 1 + right[1], ways[state]) )
				{
					x += ways[state][0];
					y += ways[state][1];
				}
				else
				{
					state = (state + 1) % 4;
				
					x += ways[state][0];
					y += ways[state][1];				
				}
			}
		}
	}
}
