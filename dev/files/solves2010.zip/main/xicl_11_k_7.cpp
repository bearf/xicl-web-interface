#include <stdio.h>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <queue>
#include <deque>
#include <cassert>
#include <memory.h>
#include <algorithm>
#include <math.h>
#include <sstream>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) ((int)(a.size()))

const int INF = 2000000000;

void prepare()
{
	freopen("input.txt", "r", stdin);
#ifndef _DEBUG
	freopen("output.txt", "w", stdout);
#endif
}

int n, k;

#define MAXN 1000001

int cid[MAXN];

int calc(int v, int k) {
	if ( k == 1 ) return 0;
	if ( v % k == 0 ) cid[v] = cid[v / k] + 1;	
	return cid[v];
}

int go(int id, int cnt) {
	memset( cid, 0, sizeof(cid) );
	int ret = 0;
	for (int i = id; i < n + 1; i += id) {
		ret += calc(i, id);
	}
	return ret / cnt;
}

bool solve()
{
	scanf( "%d%d", &n, &k);
	int ans = 10000000;
	int kk = k;
	int cp = 2;

	while (kk > 1 && kk >= cp * cp) {
		int cnt = 0;
		while (kk % cp == 0) {
			++cnt;
			kk /= cp;
		}
		if (cnt > 0) {
			ans = min(ans, go(cp, cnt));
		}

		++cp;
	}

	if (kk > 1) {
		ans = min(ans, go(kk, 1));
	}

	// pw.println(ans);
	ans = ans / k;
	printf( "%d\n", ans );
	return false;
}

int main()
{
	prepare();
	while (solve());
	return 0;
}

