#include <fstream>
#include <vector>

using namespace std;
fstream fin,fout;

class CPos{
	public:
		int x,y;
	};

vector<CPos> t;int n;
CPos p1, p2;

int ti1,ti2,ti3,ti4;

double po1 = 1,po2 = 0;

double sq(double x1,double y1,double x2,double y2){
	po2+=(x1*y2 - x2*y1);
	return (x1*y2 - x2*y1);
	}

bool in(CPos p,int i1,int i2){
	if(sq(p.x-t[i1].x, p.y-t[i1].y, t[i2].x-t[i1].x, t[i2].y-t[i1].y) < -10e-18)
	  return 0;

	return 1;
	}

int test(CPos p,int i1,int i2,int i3,int i4){
	int r = in(p,i1,i2) && in(p,i2,i3) &&
		   in(p,i3,i4) && in(p,i4,i1);
	if(r)
      return 1;else
	  return 0;
	}

void out(int i){
	fout << t[i].x <<' '<< t[i].y << endl;
	}

void out(int i1,int i2,int i3,int i4){
	out(i1);
	out(i2);
	out(i3);
	out(i4);
	}

bool tst(int i1,int i2,int i3, int i4){
	po2 = 0;
	int r = test(p1,i1,i2,i3,i4) + test(p2,i1,i2,i3,i4);
	if(r==2)
		 return 1;
	if(r==0 || po2 > po1)
		return 0;

	po1 = po2;
	ti1 = i1;
	ti2 = i2;
	ti3 = i3;
	ti4 = i4;
	return 0;

	}

void wrk(){
	for(int i=0;i<t.size();i++)
	  for(int r=i+1;r<t.size();r++)
	   for(int r1=r+1; r1<t.size();r1++)
	    for(int r2=r1+1; r2<t.size();r2++)
		 if(tst(i,r,r1,r2)){
			out(i,r,r1,r2);
			return;
			}
	 out(ti1,ti2,ti3,ti4);
	}

int main(void){
	fin.open("./input.txt",fstream::in);
	fout.open("./output.txt",fstream::out);

	fin >> n ;
	for(int i=0;i<n;i++){
		t.push_back(CPos());
		fin >> t[t.size()-1].x;
		fin >> t[t.size()-1].y;
		}

	fin >> p1.x;
	fin >> p1.y;

	fin >> p2.x;
	fin >> p2.y;

	wrk();

	fin.close();
	fout.close();
	return 0;
	}