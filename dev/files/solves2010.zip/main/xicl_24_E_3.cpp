#pragma comment( linker, "/stack:32000000" )
#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>

#define filein ""

void prepare( )
{
	freopen( "input.txt", "r", stdin );
#ifndef _DEBUG
	freopen( "output.txt", "w", stdout ); 
#endif
}

#include <cmath>
#include <cassert>
#include <memory.h>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>
#include <ctime>
#include <deque>

using namespace std;

#define fo(a,b,c) for(a=(b);a<(c);++a)
#define fr(a,b) fo(a,0,(b))
#define fi(a) fr(i,(a))
#define fj(a) fr(j,(a))
#define fk(a) fr(k,(a))
#define all(a) (a).begin(),(a).end()
#define sz(a) (int)(a).size()
#define pb push_back
#define mp make_pair
#define _(a,b) memset((a),(b),sizeof(a))
#define __(a) _((a),0)

typedef long long lint;
const double eps = 1e-9;
const double inf = 1e+20;
const int MAXN = 101;

struct C
{
	int x, y, z;
	void read( ) { scanf( "%d %d %d", &x, &y, &z ); }
};

double dist[MAXN][MAXN];
double d[MAXN][1 << 10];
int sup[MAXN];
int hru[MAXN];
C c[MAXN];
int n, m;
set<pair<double, pair<int, int > > > q;

double gdist( const C &a, const C &b )
{
	return sqrt( (double) ( a.x - b.x ) * ( a.x - b.x ) +
		(double) ( a.y - b.y ) * ( a.y - b.y ) +
		(double) ( a.z - b.z ) * ( a.z - b.z ) );
}

void add( int id, int msk, double nd )
{
	if ( d[id][msk] > nd + eps )
	{
		q.erase( mp( d[id][msk], mp( id, msk ) ) );
		d[id][msk] = nd;
		q.insert( mp( d[id][msk], mp( id, msk ) ) );
	}
}

void join( int id1, int msk1, int id2, int msk2, double nd )
{
	int nmsk = msk1 | msk2;
	add( id1, nmsk, nd );
	add( id2, nmsk, nd );
	int i;
	fi( m )
	{
		if ( ( 1 << i ) & nmsk )
		{
			add( hru[i], nmsk, nd ); 
		}
	}
}

int main( )
{
	prepare( );
	int i, j, k;
	scanf( "%d", &n );
	fi( n )
	{
		c[i].read( );
	}
	fi( n ) fj( i )
	{
		dist[j][i] = dist[i][j] = gdist( c[i], c[j] );
	}
	scanf( "%d", &m );
	int m2 = 1 << m;
	fi( m )
	{
		scanf( "%d", &j );
		-- j;
		hru[i] = j;
		sup[j] = 1 << i;
	}
	int full = m2 - 1;
	fi( n ) fj( 1 << 10 )
		d[i][j] = 1e+100;
	fi( n )
	{
		add( i, sup[i], 0 );
	}
	double ans = inf;
	bool ok = false;
	while ( !q.empty( ) )
	{
		int id = q.begin( )->second.first;
		int msk = q.begin( )->second.second;
		q.erase( q.begin( ) );
		double cd = d[id][msk];
		if ( msk == full )
		{
			ans = cd;
			ok = true;
			break;
		}
		int rev = full ^ msk;
//		for ( i = rev; i >= 0; i = ( i - 1 ) & rev )
//		{
			for ( j = 0; j < n; ++ j )
			{
				i = sup[j];
				if ( d[j][i] < inf )
					join( id, msk, j, i, cd + d[j][i] + dist[id][j] );				
			}
//			if ( i == 0 )
//				break;
//		}
	}
	assert( ok );
	printf( "%.3lf\n", ans );
	return 0;
}