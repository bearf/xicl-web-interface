#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);

	int n,m,a,b,c;
	cin >> n >> m >> a >> b >> c;
	long long ans = 0;
	
	int dx = max(b,1);
	int dy = max(a,c);

	for(int x1 = 1; x1 < m; x1++)
		for(int y1 = 1; y1 < n; y1++)
			for(int x2 = x1+dx; x2 < m; x2++)
				for(int y2 = y1+dy; y2 < n; y2++)
					ans += (x2-x1-b+1)*(x2-x1-1+1)*(y2-y1-a+1)*(y2-y1-c+1);

	cout<<ans<<endl;

	return 0;
}
