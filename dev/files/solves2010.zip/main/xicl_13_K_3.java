import java.io.*;
import java.util.*;
import java.math.*;

public class Solution {

	BufferedReader cin;
	PrintWriter cout;
	StringTokenizer tok;
	
	public static void main(String[] args) throws IOException 
	{
		new Solution.run();
	}

	void run() throws IOException
	{
		cin = new BufferedReader(new FileReader("input.txt"));
		cout = new PrintWriter(new FileWriter("output.txt"));
		
		solve();
		
		cout.flush();
		System.exit(0);
	}
	
	String next() throws IOException
	{
		if( tok == null || !tok.hasMoreTokens() )
			tok = new StringTokenizer(cin.readLine());
		
		return tok.nextToken();
	}
	
	int nextInt() throws IOException
	{
		return Integer.parseInt(next());
	}
	
	void solve() throws IOException
	{
		int n = nextInt();
		int k = nextInt();
		
		int ans = Integer.MAX_VALUE;

		int temp_k = k;
		
		for( int i = 2 ; i < Math.sqrt(k) + 1 ; i++ )
		{
			int pow = 0;

			while( temp_k % i == 0 ) 
			{
				pow++;
				temp_k /= i;
			}
			
			if( pow > 0 )
			{
				int pow_i = i;
				
				int div_count = 0;
				
				while( pow_i <= n )
				{
					div_count += n / pow_i;
					
					pow_i *= i;
				}
				
				div_count /= pow;
				
				if( div_count < ans )
					ans = div_count;
			}
		}
		
		if( temp_k > 1 )
		{
			int pow = 0;
			
			int i = temp_k;
			
			while( temp_k % i == 0 ) 
			{
				pow++;
				temp_k /= i;
			}
			
			if( pow > 0 )
			{
				int pow_i = i;
				
				int div_count = 0;
				
				while( pow_i <= n )
				{
					div_count += n / pow_i;
					
					pow_i *= i;
				}
				
				div_count /= pow;
				
				if( div_count < ans )
					ans = div_count;
			}
		}			
		
		cout.println(ans / k);
	}
}
