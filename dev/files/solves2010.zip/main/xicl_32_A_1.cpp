#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <queue>
#include <memory.h>
//#include <cmath>

using namespace std;
#define LL long long

int a, b, c, m ,n;
LL ans;

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> n >> m >> a >> b >> c;
	ans = 0;
	for (int r1 = 1; r1 <= n-a; ++r1)
		for (int c1 = 0; c1 <= m-b-2; ++c1)
			for (int r2 = 1; r2 <= n-c; ++r2)
				for (int c2 = c1+b+1; c2 <= m-1; ++c2)
					ans += min(r1,r2)*(c2-c1-b)*(n-max(r1+a,r2+c))*(c2-c1-1);
	cout << ans;
	return 0;
}