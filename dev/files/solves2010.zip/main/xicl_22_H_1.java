import java.util.*;
import java.awt.geom.*;
import java.math.*;
import static java.lang.Math.*;
import java.io.*;

public class Solution implements Runnable {

	static BufferedReader br = null;
	static PrintWriter pw = null;
	static StringTokenizer stk = new StringTokenizer("");

	public static void main(String[] args) throws FileNotFoundException {
		br = new BufferedReader(new FileReader("input.txt"));
		pw = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}

	void nline() {
		try {
			stk = new StringTokenizer(br.readLine());
		} catch (IOException e) {
			throw new RuntimeException("No new line");
		}
	}

	String nwrd() {
		while (!stk.hasMoreElements())
			nline();
		return stk.nextToken();
	}

	int ni() {
		return Integer.valueOf(nwrd());
	}

	long nl() {
		return Long.valueOf(nwrd());
	}

	double nd() {
		return Double.valueOf(nwrd());
	}

	char nc() {
		return nwrd().charAt(0);
	}

	boolean isReady() {
		try {
			return br.ready();
		} catch (IOException e) {
			throw new RuntimeException("Something wrong in br");
		}
	}

	public void solve() {
		int n = ni();
		int m = ni();
		int k = ni();
		boolean[][] lef = new boolean[m + 1][n + 1];
		boolean[][] bot = new boolean[m + 1][n + 1];
		int[] dx = { +0, +1, -0, -1 }; // N, E, S, W
		int[] dy = { +1, +0, -1, -0 }; // N, E, S, W
		for (int i = 0; i < n; i++) {
			lef[0][i] = true;
			lef[m][i] = true;
		}
		for (int i = 0; i < m; i++) {
			bot[i][0] = true;
			bot[i][n] = true;
		}
		char[] dir = { 'N', 'E', 'S', 'W' };
		int sy = ni();
		int sx = ni();
		char ds = nc();
		int dr = 0;
		for (int i = 0; i < 4; i++)
			if (dir[i] == ds)
				dr = i;
		for (int i = 0; i < k; i++) {
			int x1 = ni();
			int y1 = ni();
			int x2 = ni();
			int y2 = ni();
			if (x1 == x2) {
				for (int y = y1; y < y2; y++)
					lef[x1][y] = true;
			} else {
				for (int x = x1; x < x2; x++)
					bot[x][y1] = true;
			}
		}
		lef[0][1]=false;
		HashSet<Integer> hs = new HashSet<Integer>();
		int xx = sx-1;
		int yy = sy-1;
		int dd = dr;
		int sh = 0;
		while (true) {
			boolean rst = false;
			boolean vps = false;
			switch (dd) {
			case 0: {
				rst = lef[xx+1][yy];
				vps = bot[xx][yy+1];
				break;
			}
			case 1: {
				rst = bot[xx][yy];
				vps = lef[xx+1][yy];
				break;
			}
			case 2: {
				rst = lef[xx][yy];
				vps = bot[xx][yy];
				break;
			}
			case 3: {
				rst = bot[xx][yy+1];
				vps = lef[xx][yy];
				break;
			}
			}
			if (xx==0&&yy==1&&dd==2&&!vps) {
				sh++;
				break;
			}
			if (xx==0&&yy==1&&dd==3&&rst) {
				sh++;
				break;
			}
			if (vps)
				dd=(dd+3)%4;
			else if (rst) {
				xx+=dx[dd];
				yy+=dy[dd];
				sh++;
			} else {
				dd=(dd+1)%4;
				xx+=dx[dd];
				yy+=dy[dd];
				sh++;
			}
			int sta = (xx*m+yy)*4+dd;
			if (!hs.add(sta)) {
				pw.println("NO");
				return;
			}
		}
		pw.println("YES");
		pw.println(sh);
	}

	public void run() {
		solve();
		pw.close();
	}

}
