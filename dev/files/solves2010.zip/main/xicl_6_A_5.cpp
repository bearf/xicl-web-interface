// ablyad.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include <stdio.h>
#include <iostream>
using namespace std;
int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long n,m,a,b,c,i,j,z,k;
	long long res;
	cin >> n >> m >> a >> b >> c;
	res=0;
	for (i=b;i<=n-1;i++) 
		 for (j=a;j<=m-c;j++)
			 for (k=i+1;k<=n-1;k++)
				 for (z=j+1;z<=m-c;z++)
					 res+=(i-k)*(z-j)*(i-k)*(z-j);
	cout << res;
	return 0;
}

