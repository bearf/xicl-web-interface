// ablyad.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include <stdio.h>
#include <iostream>
using namespace std;
int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long n,m,a,b,c,i,j,z,k;
	long long res;
	cin >> n >> m >> a >> b >> c;
	res=0;
	for (i=1;i<=n-1;i++) 
		 for (j=1;j<=m-1;j++)
			 for (k=i+1;k<=n-1;k++)
				 for (z=j+1;z<=m-1;z++)
					 if ((k-i-c+1>0)&&(k-i-a+1>0)&&(z-j>0)&&(z-j-b+1>0))
					 res+=(k-i-c+1)*(k-i-a+1)*(z-j)*(z-j-b+1);
	cout << res;
	return 0;
}

