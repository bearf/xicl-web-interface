#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>

#include <cstdarg>

using namespace std;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	va_end(args);

	fflush(stderr);
#endif
#endif
}

typedef long long ll;
typedef unsigned long long ull;
typedef pair < int , int > pii;

#define clr(a) memset(a,0,sizeof(a))
#define fill(a,b) memset(a,b,sizeof(a))


int ar[10*1024];
int buf[1024];

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#ifdef DBG1
#if DBG2
	freopen("err.txt", "w", stderr);
#endif
#endif
	int n,k;
	scanf("%d%d", &n, &k);
	std::vector<pii> ans;
	set<int> perm;
	for(int i = 0; i < n; i++)
	{
		scanf("%d", &ar[i]);
		ar[i]--;
		if (perm.find(ar[i]) != perm.end())
			throw "2";
		if (ar[i] < 0 || ar[i] >= n)
			throw "2";
		perm.insert(ar[i]);
	}
	for(int i = 0; i < n - k; i++)
	{
		int pos;
		for(int j = i;; j++)
			if (ar[j] == i)
			{
				pos = j;
				break;
			}
		if (pos == i)
			continue;
		bool flag = false;	
		if (pos + k > n)
		{
			pos = n - k;
			flag = true;
		}
		ans.push_back(std::make_pair(ar[pos]+1, i));
		for(int j = 0; j < k; j++)
			buf[j] = ar[j+pos];		
		for(int j = pos - i - 1; j >= 0; --j)
		{
			ar[i+k+j] = ar[i+j];
		}
		for(int j = 0; j < k; j++)
			ar[i+j] = buf[j];
		for(int ii = 0; ii < n; ii++)
			dbg("%d ", ar[ii]);
		dbg("\n");
		if (flag) 
			i--;
	
	}
	for(int i = 0; i < n; i++)
		if (ar[i] != i)
		{
			printf("0\n");
			return 0;
		}

	if (ans.size() > 100000)
	{
		printf("0\n");
		return 0;
	}
	for(int i = 0; i < (int) ans.size(); i++)
	{
		printf("%d %d\n", ans[i].first, ans[i].second);
	}


	return 0;
}