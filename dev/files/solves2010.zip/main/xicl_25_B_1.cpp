#include <iostream>
#include <vector>

using namespace std;

int w[200][200],fl[200][200];
int v[200],n,x,y,m,f=0,kol=0;
vector<int> mas,res[10000];

void dfs(int z)
{
	if (z==y)
	{
		int j;
		if (mas.size()==1)
		{
			if (fl[x][y]=w[x][y] && fl[x][y]>0) 
			{
				res[kol].push_back(x);
				res[kol].push_back(y);
				kol++;
			}
		} else
		{
			res[kol].push_back(x);
			for (j=0;j<mas.size();j++)
				res[kol].push_back(mas[j]);
			//cout<<endl;
			kol++;
		}
	} else
	{
		int j;
		for (j=1;j<=n;j++)
			if (v[j]==1 && w[z][j]>0)
			{
				mas.push_back(j);
				v[j]=0;
				w[z][j]=0;
				dfs(j);
				v[j]=1;
				mas.pop_back();
			}
	}
}

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int i,j,k,a,b,cost;
	cin>>n>>m>>x>>y;
	for (i=0;i<m;i++)
	{
		cin>>a>>b>>cost;
		w[a][b]=cost;
		fl[a][b]=cost;
	}
	for (i=1;i<=n;i++)
	  for (k=1;k<=n;k++)
		  for (j=1;j<=n;j++)
			  if (fl[k][i] && fl[i][j] && (fl[k][j]==0 || fl[k][j]>fl[k][i]+fl[i][j]))
				  fl[k][j]=fl[k][i]+fl[i][j];
	/*for (i=1;i<=n;i++)
	{
		for (k=1;k<=n;k++)
			cout<<fl[i][k]<<" ";
		cout<<endl;
	}*/
	for (i=1;i<=n;i++)
		if (fl[x][i]+fl[i][y]==fl[x][y]) v[i]=1;
	/*if (w[x][y]==fl[x][y]) 
	{
		cout<<"2"<<" "<<x<<" "<<y;
		f=1;
	}*/
	dfs(x);
	cout<<kol<<endl;
	for (i=0;i<kol;i++)
	{
		cout<<res[i].size()<<" ";
		for (j=0;j<res[i].size();j++)
			cout<<res[i][j]<<" ";
		cout<<endl;
	}
	return 0;
}