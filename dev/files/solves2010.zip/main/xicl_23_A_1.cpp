#include <iostream>

using namespace std;

int main(){

	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);

	int n, m, a, b, c;
	cin >> n >> m >> a >> b >> c;

	int l, t, r, d;
	long long ans = 0;
	for (l = 2; l <= m - 1; l++) {
		for (t = 2; t <= n - 1; t++) {
			for (r = l; r <= m - 1; r++) {
				for (d = t; d <= n - 1; d++) {
					long long bb = r - l + 1 - b + 1;
					long long tt = r - l + 1;
					long long aa = d - t + 1 - a + 1;
					long long cc = d - t + 1 - c + 1;
					if (bb > 0 && tt > 0 && aa > 0 && cc > 0) {
						ans += bb * tt * aa * cc;
					}


				}
			}
		}
	}

cout << ans << endl;
	return 0;
}