#define _CRT_SECURE_NO_DEPRECATE
#include <cstdio>

int main()
{
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);

	__int64 N, M, a, b, c, x1, x3, y0, y2, Kx, Ky, m;

	scanf("%I64d %I64d %I64d %I64d %I64d", &N, &M, &a, &b, &c);

	Kx = 0;
	for(x1=1; x1<M-b; x1++)
		for(x3=x1+b+1; x3<=M; x3++)
			Kx += (x3-x1-b)*(x3-x1-1);

	if(a>c) m = a;
	else m = c;
	Ky = 0;
	for(y0=1; y0<N-m; y0++)
		for(y2=y0+m+1; y2<=N; y2++)
			Ky += (y2-y0-a)*(y2-y0-c);

	printf("%I64d", Kx*Ky);

	fclose(stdout);
}