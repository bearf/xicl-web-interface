#include <iostream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <cmath>
#include <sstream>
#include <cstring>
#include <string>

#define re return
#define mp make_pair
#define pb push_back
#define rep(i,n) for (int i = 0; i < n; i++)
#define fi first
#define se second
#define sz(x) ((int) (x).size())
#define all(x) (x).begin(), (x).end()
#define fill(x, y) memset(x, y, sizeof(x))
#define y0 y49743
#define y1 y47543

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef long long ll;
typedef long double ld;
typedef vector<string> vs;

int n;
int m;

int matr[100][100];
int len[100][100];
int good[100][100];
int ans[100][100];

int use[100][100];

int pprev[100];
int next[100];

int dist;
int x, y;
int was[100];

int dfs(int v) {
	if (v == y)
		re 1;

	was[v] = 1;

	rep(i, n)
		if (good[v][i] && !was[i])
			if (dfs(i)) {
				next[v] = i;
				re 1;
			}

	re 0;
}

int dfs2(int v) {
	if (v == y)
		re 1;

	was[v] = 1;

	rep(i, n)
		if (use[v][i] && !was[i])
			if (dfs2(i)) {
				next[v] = i;
				re 1;
			}

	re 0;
}

int getmaxflow() {
	fill(next, -1);
	int ans = 0;
	while (1) {
		fill(was, 0);
		if (dfs(x))
			ans++;
		else
			break;
		int p = x;
		while (p != y) {
			good[p][next[p]] = 0;
			good[next[p]][p] = 1;
			p = next[p];
		}
	}

	re ans;
}

int gg[100][100];

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);	
	cin >> n >> m >> x >> y;

	x--;
	y--;

int big = 100000000;

	rep(i, n) rep(j, n) matr[i][j] = big;

	rep(i, n)
		matr[i][i] = 0;

	rep(i, m) {
		int a, b, c;
		cin >> a >> b >> c;
		a--;
		b--;
		len[a][b] = matr[a][b] = c;
		gg[a][b] = 1;
	}

	
	rep(k, n)
	rep(i, n) rep(j, n)	
			matr[i][j] = min(matr[i][j], matr[i][k] + matr[k][j]);
	
	dist = matr[x][y];	
	rep(i, n) rep(j, n)
		if (gg[i][j])
			if (matr[x][i] + len[i][j] + matr[j][y] == dist)
				good[i][j] = 1;

	if (0)
	rep(i, n) {
		rep(j, n)
			cout << good[i][j] << ' ';
		cout << endl;
	}

	memcpy(ans, good, sizeof(ans));	
	int k = getmaxflow();

	cout << k << endl;

	rep(i, n) rep(j, n)
		if (good[i][j] == 0 && ans[i][j])
			use[i][j] = 1;

	rep(i, k) {
		fill(pprev, -1);
		fill(was, 0);
		if (!dfs2(x))
			while (1);
		vi v;
		int p = x;
		while (p != y) {
			v.pb(p);
			
			use[p][next[p]] = 0;
			p = next[p];
		}

		v.pb(y);
		//reverse(all(v));
		cout << sz(v) << ' ';
		rep(i, sz(v))
			cout << v[i] + 1 << ' ';
		cout << endl;
	}
	
	re 0;
}