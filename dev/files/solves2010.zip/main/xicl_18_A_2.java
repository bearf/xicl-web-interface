import java.lang.*;
import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {

	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	
	public static void main(String args[]) throws IOException{
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Solution()).run();
	}
	
	public void loadLine(){
		try{
			stk = new StringTokenizer(br.readLine());
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public String nextLine(){
		try{
			return (br.readLine());
		} catch(IOException e) {
			e.printStackTrace();
			return "";
		}
	}
	
	public String nextWord(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return stk.nextToken();
	}
	
	public Integer nextInt(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	public Double nextDouble(){
		while(stk==null || !stk.hasMoreTokens())
			loadLine();
		return Double.parseDouble(stk.nextToken());
	}
	
	public void run(){
		int n = nextInt();
		int m = nextInt();
		int a = nextInt();
		int b = nextInt();
		int c = nextInt();
		
		long res = 0;
		
		for (int i = 1; i <= m-a-1; ++i) {
			for (int j = 0; j <= n-Math.max(b, c)-2; ++j) {
				for (int k = 1; k < m-1; ++k) {
					for (int l = j+1+Math.max(b, c); l < n; ++l) {
						int left = Math.min(i, k);
						int right = m-Math.max(i+a, k+1);
						res += (left)*(l-j-b)*(right)*(l-j-c);
					}
				}
			}
		}
		out.println(res);
		out.flush();
	}
}
