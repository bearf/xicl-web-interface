#include <iostream>
#include <queue>
#include <stack>
using namespace std;

priority_queue < pair<int,int> > pq;

int t1[100001],t2[100001];

int n,x,a;

void out(int i)
{
	if(i<0)
	{
		printf("%d",-i);
	}
	else
	{
		putc('(',stdout);
		out(t1[i]);
		putc('.',stdout);
		out(t2[i]);
		putc(')',stdout);
	}
}


int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int i;
	int top=1;
	pair<int,int> p1, p2;
	cin>>n>>x;
	for(i=0;i<n;i++)
	{
		scanf("%d",&a);
		pq.push(make_pair(-a,-i-1));
	}
	while(pq.size()!=1)
	{
		p1 = pq.top();
		pq.pop();
		p2 = pq.top();
		pq.pop();
		if(p1.first*x>p2.first)
		{
			cout<<"no";
			return 0;
		}
		t1[top] = p1.second;
		t2[top] = p2.second;
		pq.push(make_pair(p1.first+p2.first, top));
		top++;
	}

	out(pq.top().second);

	return 0;
}