#include <fstream>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");
int a[110][110];
int r[110], rr[110];
bool w[110];
int ans[110][110];
int ansl[110];
int n, x, y, m;
int ddd(int x, int y) {
	memset(r, 127, sizeof(r));
	memset(w, 0, sizeof(w));
	memset(rr, 0, sizeof(rr));
	r[x] = 0;
	for (int qq = 0; qq < n; qq++) {
		int mn = -1;
		for (int i = 1; i <= n; i++) {
			if (!w[i]) {
				if (mn == -1 || r[mn] > r[i]) mn = i;
			}
		}
		w[mn] = true;
		for (int i = 1; i <= n; i++) {
			if (a[mn][i] != 0) {
				if (r[i] == -1 || r[i] > r[mn] + a[mn][i]) {
					r[i] = r[mn] + a[mn][i];
					rr[i] = mn;
				}
			}
		}
	}
	return r[y];
}
void rrr(int q, int x, int y) {
	while (y != 0) {
		ans[q][ansl[q]++] = y;
		a[rr[y]][y] = 0;
		y = rr[y];
	}
}
int main() {
	memset(ansl, 0, sizeof(ansl));
	cin >> n >> m >> x >> y;
	for (int i = 0; i < m; i++) {
		int q, w, l;
		cin >> q >> w >> l;
		a[q][w] = l;
	}
	int krp = ddd(x, y);
	if (krp == 2139062143) {
		cout << "0";
		return 0;
	}
	int skrp = krp;
	int i = 0; 
	while (krp == skrp) {
		rrr(i++, x, y);
		krp = ddd(x, y);
	}
	cout << i << "\n";
	for (int q = 0; q < i; q++) {
		cout << ansl[q] << " ";
		for (int j = ansl[q] - 1; j >= 0; j--) {
			cout << ans[q][j] << " ";
		}
		cout << "\n";
	}
	return 0;
}