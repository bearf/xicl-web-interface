#pragma comment( linker, "/stack:32000000" )
#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>

#define filein ""

void prepare( )
{
	freopen( "input.txt", "r", stdin );
#ifndef _DEBUG
	freopen( "output.txt", "w", stdout ); 
#endif
}

#include <cmath>
#include <cassert>
#include <memory.h>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>
#include <ctime>
#include <deque>

using namespace std;

#define fo(a,b,c) for(a=(b);a<(c);++a)
#define fr(a,b) fo(a,0,(b))
#define fi(a) fr(i,(a))
#define fj(a) fr(j,(a))
#define fk(a) fr(k,(a))
#define all(a) (a).begin(),(a).end()
#define sz(a) (int)(a).size()
#define pb push_back
#define mp make_pair
#define _(a,b) memset((a),(b),sizeof(a))
#define __(a) _((a),0)

typedef long long lint;

const int MAXN = 100;
const int INF = 1000000000;

struct Edge
{
	int b, cost;
	int id;
};

int n, m;
vector<Edge> v[MAXN];
vector<int> den;
int last[MAXN];
int d[MAXN];
int el[MAXN];
int ansd;
vector<vector<int> > ans;
set<pair<int, int > > q;

void add( int id, int nd, int lid, int tid )
{
	if ( d[id] > nd )
	{
		q.erase( mp( d[id], id ) );
		d[id] = nd;
		el[id] = tid;
		last[id] = lid;
		q.insert( mp( d[id], id ) );
	}
}

int main( )
{
	prepare( );
	int i, j, k;
	int st, en;
	scanf( "%d %d %d %d", &n, &m, &st, &en );
	-- st;
	-- en;
	den.resize( m, 0 );
	fi( m )
	{
		int a, b, cost;
		scanf( "%d %d %d", &a, &b, &cost );
		-- a; -- b;
		Edge t;
		t.b = b;
		t.cost = cost;
		t.id = i;
		v[a].pb( t );
	}
	while ( 1 )
	{
		q.clear( );
		_( d, 127 );
		add( st, 0, -1, -1 );
		int id;
		bool ok = false;
		while ( !q.empty( ) )
		{
			id = q.begin( )->second;
			q.erase( q.begin( ) );
			if ( id == en )
			{
				ok = true;
				break;
			}
			int cd = d[id];
			fi( sz( v[id] ) )
			{
				Edge &t = v[id][i];
				if ( den[t.id] )
					continue;
				add( t.b, cd + t.cost, id, t.id );
			}
		}
		int cur = d[en];
		if ( cur < INF && ( sz( ans ) == 0 || cur == ansd ) )
		{
			ansd = cur;
			vector<int> tmp;
			i = en;
			tmp.pb( i );
			while ( i != st )
			{
				den[el[i]] = 1;
				i = last[i];
				tmp.pb( i );
			}
			reverse( all( tmp ) );
			ans.pb( tmp );
		}
		else
			break;
	}
	printf( "%d\n", sz( ans ) );
	fi( sz( ans ) )
	{
		printf( "%d", sz( ans[i] ) );
		fj( sz( ans[i] ) )
		{
			printf( " %d", ans[i][j] + 1 );
		}
		printf( "\n" );
	}
	return 0;
}