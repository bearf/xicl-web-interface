import java.io.*;
import java.util.*;

public class Solution {

	private PrintWriter pw;
	private BufferedReader bf;
	private StringTokenizer st;

	int n, m;
	int d[][], c[][], f[][];
	int p[], r[];

	static final int INF = 100000000;

	List<Integer> path;
	boolean use[];

	int is, sto;
	int prev[];

	int dij() {
		Arrays.fill(use, false);
		Arrays.fill(r, INF);
		r[is] = 0;
		prev[is] = -1;

		while (true) {
			int cur = -1;
			for (int i = 0; i < n; ++i)
				if (!use[i]) {
					if (cur == -1 || r[cur] > r[i]) {
						cur = i;
					}
				}

			if (cur == -1)
				break;
			use[cur] = true;

			for (int i = 0; i < n; ++i)
				if (c[cur][i] - f[cur][i] > 0) {
					int cost = d[cur][i];
					if (f[cur][i] < 0)
						cost = -d[i][cur];
					if (r[i] > p[i] - p[cur] + cost + r[cur]) {
						r[i] = p[i] - p[cur] + cost + r[cur];
						prev[i] = cur;
					}
				}
		}

		for (int i = 0; i < n; ++i)
			if (p[i] < INF)
				p[i] += r[i];

		int cp = sto;
		path.clear();
		while (cp != -1) {
			path.add(cp);
			cp = prev[cp];
		}
		return r[sto];
	}

	void incFlow() {
		for (int i = path.size() - 1; i > 0; --i) {
			int a = path.get(i);
			int b = path.get(i - 1);
			// System.out.println(a + " " + b);
			f[b][a]--;
			f[a][b]++;
		}
	}

	int getCost() {
		int ret = 0;
		for (int i = path.size() - 1; i > 0; --i) {
			int a = path.get(i);
			int b = path.get(i - 1);
			if (f[a][b] < 0) {
				ret -= d[b][a];
			} else {
				ret += d[a][b];
			}
		}
		return ret;
	}

	void getAns(int id) {
		if (id == sto) {
			pw.print((path.size() + 1) + " " + (is + 1));
			for (int i = 0; i < path.size(); ++i) {
				pw.print(" " + (path.get(i) + 1));
			}
			pw.println();
		}
		for (int i = 0; i < n; ++i)
			if (f[id][i] > 0) {
				path.add(i);
				f[id][i] = 0;
				getAns(i);
				path.remove(path.size() - 1);
			}
	}

	boolean solve() throws IOException {
		n = nextInt();
		m = nextInt();
		is = nextInt() - 1;
		sto = nextInt() - 1;

		d = new int[n][n];
		p = new int[n];
		r = new int[n];
		c = new int[n][n];
		f = new int[n][n];
		use = new boolean[n];
		prev = new int[n];
		path = new ArrayList<Integer>();

		for (int i = 0; i < m; ++i) {
			int a = nextInt() - 1, b = nextInt() - 1, dd = nextInt();
			d[a][b] = dd;
			c[a][b] = 1;
		}

		int dist = -1;
		int ans = 0;
		while (true) {
			int dd = dij();
			if (dd == INF)
				break;
			int cd = getCost();
			if (cd == INF)
				break;
			// System.out.println(cd);
			if (dist != -1 && cd > dist) {
				break;
			}
			dist = cd;
			incFlow();
			++ans;
		}
		pw.println(ans);

		path.clear();
		getAns(is);

		return false;
	}

	public void run() throws IOException {
		pw = new PrintWriter(new File("output.txt"));
//		pw = new PrintWriter(System.out);
		bf = new BufferedReader(new FileReader(new File("input.txt")));
		while (solve()) {

		}
		pw.flush();
	}

	// GAVNO NIZHE

	String nextString() throws IOException {
		while (st == null || !st.hasMoreTokens()) {
			String str = bf.readLine();
			if (str == null) {
				return null;
			}
			st = new StringTokenizer(str);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.valueOf(nextString());
	}

	double nextDouble() throws IOException {
		return Double.valueOf(nextString());
	}

	public static class Pair<T, V> {
		T first;
		V second;

		public Pair(T first, V second) {
			super();
			this.first = first;
			this.second = second;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((first == null) ? 0 : first.hashCode());
			result = prime * result
					+ ((second == null) ? 0 : second.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Pair other = (Pair) obj;
			if (first == null) {
				if (other.first != null)
					return false;
			} else if (!first.equals(other.first))
				return false;
			if (second == null) {
				if (other.second != null)
					return false;
			} else if (!second.equals(other.second))
				return false;
			return true;
		}

		@Override
		public String toString() {
			return "Pair [first=" + first + ", second=" + second + "]";
		}
	}

	public static class ComparablePair<T extends Comparable<T>, V extends Comparable<V>>
			extends Pair<T, V> implements Comparable<ComparablePair<T, V>> {

		public ComparablePair(T first, V second) {
			super(first, second);
		}

		@Override
		public int compareTo(ComparablePair<T, V> arg0) {
			if (arg0.first.compareTo(first) != 0) {
				return -arg0.first.compareTo(first);
			}
			if (arg0.second.compareTo(second) != 0) {
				return -arg0.second.compareTo(second);
			}
			return 0;
		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		new Solution().run();
	}

}
