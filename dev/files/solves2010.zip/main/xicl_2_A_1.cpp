#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <math.h>
#include <time.h>
#pragma comment (linker,"/STACK:32000000")
using namespace std;
int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long  n,m,a,b,c,x1,x2,y1,y2,A,B,C,D;
	cin >> n >> m >> a >> b >> c;
	long long res =  0;
	for (x1=1;x1<n-1;x1++)
	{
		for (x2=x1+2;x2<=n;x2++)
		{
			for (y1=1;y1<m-1;y1++)
			{
				for (y2=y1+2;y2<=m;y2++)
				{
					A = x2-x1-a;
					C = x2-x1-c;
					B = y2-y1-b;
					D = y2-y1-1;
					if (A<0 || B<0 || C<0 || D<0 )
						continue;
					res += A * B * C * D;
				}
			}
		}
	}
	cout << res;


	return 0;
}
