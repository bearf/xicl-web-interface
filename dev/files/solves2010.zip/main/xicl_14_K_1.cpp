#include <iostream>
#include <cstdio>
#include <vector>
#include <sstream>
#include <string>
#include <map>
#include <set>
#include <algorithm>
//#include <cmath>

using namespace std;

#define bublic public
#define sz size()
#define clr(a) memset(a,0,sizeof(a))
#define ll long long
#define ld long double
#define istr istringstream
#define pb push_back
#define forn(i,n) for(int i=0; i<n; i++)

const ld EPS=1e-9;
const ld PI=3.1415926535897932384626433832795;
const int INF=2000000000;

int e[1200000];
int n,k;
vector <int> v;

ll pow(ll x,ll y)
{
    ll res=1;
    for(int i=0;i<y;i++)
    {
        res*=x;
        if (res>1000000) return 1000000;
    }
    return res;
}

int main()
{
    freopen("input.txt","rt",stdin);
    freopen("output.txt","wt",stdout);    
    cout.flags(ios::fixed);
    cout.precision(10);
    clr(e);
    for(int i=2;i<=1000000;i++)
    {
        if (e[i]) continue;
        ll z=i;
        z*=i;
        while(z<=1000000)
        {
            e[z]=i;
            z+=i;
        }
    }
    cin>>n>>k;
    ll z=k;
    while(e[z])
    {
        v.pb(e[z]);
        z/=e[z];
    }
    v.pb(z);
    ll ans=9000000000000000000ll;
    for(int i=0;i<v.sz;i++)
    {
        ll q=0;
        ll r=v[i];
        while(r<=n)
        {
            q+=n/r;
            r*=v[i];
        }
        ll t=0;
        for(int j=0;j<v.sz;j++)
        if (v[i]==v[j]) t++;
        t=t*(pow(v[i],t));
        ans=min(ans,q/t);
//        cout<<t<<endl;
    }
    cout<<ans;
    return 0;
}
