#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>

#include <cstdarg>

using namespace std;

#pragma comment(linker,"/STACK:16000000")

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	va_end(args);

	fflush(stderr);
#endif
#endif
}

typedef long long ll;
typedef unsigned long long ull;
typedef pair < int , int > pii;

#define clr(a) memset(a,0,sizeof(a))
#define fill(a,b) memset(a,b,sizeof(a))

int X;

void printNoAndExit(){
	printf("no\n");
	exit(0);
}

ll WW[256 * 1024];
int size;

struct node{
	ll w;
	int id;
	bool leaf;
	int left;
	int right;	

	bool operator < (const node & n) const{
		if (w != n.w) return w < n.w;
		return id < n.id;
	}

	node(){
		w = 0;
		id = 0;
		leaf = true;
	}

	node(node l, node r){
		id = size++;		
		w = l.w + r.w;
		leaf = false;
		left = l.id; right = r.id;		
	}

	node(int Id){		
		w = WW[Id];
		id = Id;
		size++;
		leaf = true;		
	}	
};

node Union(node l, node r){
	if (l.w * X < r.w)
		printNoAndExit();
	return node(l,r);
}

node cache[256 * 1024];

void print(int id){
	if (cache[id].leaf){
		printf("%d",id);
		return;
	}
	printf("(");
	print(cache[id].left);	
	printf(".");
	print(cache[id].right);
	printf(")");
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#ifdef DBG1
#if DBG2
	freopen("err.txt", "w", stderr);
#endif
#endif

	multiset<node> heap;
	int n;	
	scanf("%d%d",&n,&X);
	size = 1;
	for (int i = 1; i <= n; i++){
		scanf("%lld",&WW[i]);
		node cur(i);
		heap.insert(cur);
		cache[cur.id] = cur;
	}	
	while (heap.size() > 1){
		node l = (*heap.begin());
		heap.erase(heap.begin());

		node r = (*heap.begin());
		heap.erase(heap.begin());

		node newNode = Union(l,r);
		heap.insert(newNode);

		cache[newNode.id] = newNode;
	}

	node result = (*heap.begin());
	print(result.id);
	

	return 0;
}