#include<stdio.h>
#include<stdlib.h>
long long i,j,n,v1x,v2x,v1y,v2y,x[1100],y[1100],k1,k2,b1,b2;;
int main(){
freopen("input.txt","r",stdin);
freopen("output.txt","w",stdout);
scanf("%lld",&n);
for(i=0;i<n;i++)
scanf("%lld%lld",&x[i],&y[i]);
x[n]=x[0];y[n]=y[0];
scanf("%lld%lld",&v1x,&v1y);
scanf("%lld%lld",&v2x,&v2y);

for(i=0;i<n;i++)
for(j=i+2;j<n;j++)
if(j-i<n-1){
if(
   (v1x*(y[j+1]-y[i])-v1y*(x[j+1]-x[i])-x[i]*(y[j+1]-y[i])+y[i]*(x[j+1]-x[i]))*
   (v1x*(y[i+1]-y[j])-v1y*(x[i+1]-x[j])-x[j]*(y[i+1]-y[j])+y[j]*(x[i+1]-x[j]))>=0
   &&
   (v2x*(y[j+1]-y[i])-v2y*(x[j+1]-x[i])-x[i]*(y[j+1]-y[i])+y[i]*(x[j+1]-x[i]))*
   (v2x*(y[i+1]-y[j])-v2y*(x[i+1]-x[j])-x[j]*(y[i+1]-y[j])+y[j]*(x[i+1]-x[j]))>=0
   )
{printf("%lld %lld\n%lld %lld\n%lld %lld\n%lld %lld\n",x[i],y[i],x[i+1],y[i+1],x[j],y[j],x[j+1],y[j+1]);return 0;}

}
return 0;
}
