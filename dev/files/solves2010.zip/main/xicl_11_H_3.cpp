#include <stdio.h>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <queue>
#include <deque>
#include <cassert>
#include <memory.h>
#include <algorithm>
#include <math.h>
#include <sstream>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) ((int)(a.size()))

const int INF = 2000000000;

void prepare()
{
	freopen("input.txt", "r", stdin);
#ifndef _DEBUG
	freopen("output.txt", "w", stdout);
#endif
}

int n, m, k;
int sx, sy, sd;
char tmp[10];

int dx[4] = {0, 1, 0, -1};
int dy[4] = {1, 0, -1, 0};

bool l[105][105][4];

bool used[105][105][4];

bool solve()
{
	scanf("%d%d%d", &n, &m, &k);
	scanf("%d%d%s", &sx, &sy, tmp);
	if (tmp[0] == 'N')
		sd = 0;
	else if (tmp[0] == 'E')
		sd = 1;
	else if (tmp[0] == 'S')
		sd = 2;
	else
		sd = 3;

	memset(l, 0, sizeof(l));
	memset(used, 0, sizeof(used));

	for (int i = 0; i < m; i++)
	{
		l[0][i][2] = true;
		l[n - 1][i][0] = true; 
	}

	for (int i = 0; i < n; i++)
	{
		l[i][0][3] = true;
		l[i][m - 1][1] = true;
	}

	for (int i = 0; i < k; i++)
	{
		int x1, y1, x2, y2;
		scanf("%d%d%d%d", &x1, &y1, &x2, &y2); //wtf
		if (y1 != y2)
		{
			if (y1 > y2)
				swap(y1, y2);
			for (int j = y1; j < y2; j++)
			{
				l[j][x1][3] = true;
				if (x1 - 1 >= 0)
					l[j][x1 - 1][1] = true;
			}
		}
		else
		{
			if (x1 > x2)
				swap(x1, x2);
			for (int j = x1; j < x2; j++)
			{
				l[y1][j][2] = true;
				if (y1 - 1 >= 0)
					l[y1 - 1][j][0] = true;
			}
		}
	}

	l[1][0][3] = false;
	//l[0][2][0] = false;0
	sy--;
	sx--;

	int ans = 0;
	while (1)
	{
		//printf("%d %d %d\n", sy, sx, sd);

		if (sx == -1)
			break;

		if (used[sy][sx][sd])
		{
			printf("NO\n");
			return false;
		}

		used[sy][sx][sd] = true;

		if (l[sy][sx][sd])
		{
			sd--;
			if (sd == -1)
				sd = 3;
		}
		else
		{
			int nd = sd + 1;
			if (nd == 4)
				nd = 0;
			if (l[sy][sx][nd])
			{
				sy += dy[sd];
				sx += dx[sd];
				ans++;
			}
			else
			{
				sd = nd;
				if (!l[sy][sx][sd])
				{
					sy += dy[sd];
					sx += dx[sd];
					ans++;
				}
			}
		}
	}

	printf("YES\n%d\n", ans);

	return false;
}

int main()
{
	prepare();
	while (solve());
	return 0;
}

