#include <fstream>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");

typedef long long int lint;

lint prime[100000];

int main()
{
	lint n,k;
	cin>>n>>k;
	prime[0]=2;
	prime[1]=3;
	lint s=5, p=2;
	while(s<=1000000)
	{
		int j=1;
		while(prime[j]*prime[j]<=s)
		{
			if(s%prime[j]==0)goto no_prime;
			j++;
		}
		prime[p++]=s;
no_prime:
		s+=2;
	}
	lint fact_k[20],deg_k[20], prime_c[20], k0=k;
	s=0;p=0;
	lint res=100000000;
	while(k!=1)
	{
		if(k%prime[s]==0)
		{
			fact_k[p]=prime[s];
			deg_k[p]=0;
			while(k%prime[s]==0)
			{
				k/=prime[s];
				deg_k[p]++;
			}
			lint t=prime[s];
			prime_c[p]=0;
			while(n/t!=0)
			{
				prime_c[p]+=n/t;
				t*=prime[s];
			}
			prime_c[p]/=k0*deg_k[p];
			if(prime_c[p]!=0)
			{
				if(prime_c[p]<res)res=prime_c[p];
			}
			else 
			{
				cout<<0;
				return 0;
			}
			p++;
		}
		s++;
	}
	cout<<res;
}