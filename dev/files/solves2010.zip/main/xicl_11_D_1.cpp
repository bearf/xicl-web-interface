#include <stdio.h>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <queue>
#include <deque>
#include <cassert>
#include <memory.h>
#include <algorithm>
#include <math.h>
#include <sstream>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) ((int)(a.size()))

const int INF = 2000000000;

typedef long long lint;

void prepare()
{
	freopen("input.txt", "r", stdin);
#ifndef _DEBUG
	freopen("output.txt", "w", stdout);
#endif
}

lint n;
int m;

bool solve()
{
	scanf("%lli%d", &n, &m);

	lint mul = 1;
	for (int i = 0; i < m; i++)
	{
		if (n < 0) n = -n;

		lint p = 1LL;
		lint sm = m - i;
		lint q = m - i;
		while (p < n || (p == n && i < m - 1))
		{
			q++;
			p *= q;
			p /= (q - sm);
		}

		n -= p;

		printf("%lli", q);
		if (i != m - 1)
			printf(" ");
		else
			printf("\n");

		mul = mul * -1;
	}

	return false;
}

int main()
{
	prepare();
	while (solve());
	return 0;
}

