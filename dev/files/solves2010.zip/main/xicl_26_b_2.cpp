#include <fstream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <queue>

using namespace std;

ifstream cin("input.txt");
ofstream cout("output.txt");

#define len(v) (int)(v).size()
#define vi vector<int>
#define vvi vector<vi >
#define ii pair<int,int>
#define vii vector<ii >
#define all(v) (v).begin(),(v).end()
#define vvii vector<vii >
#define inf 1000000000

int n, m, x, y;
vvi G;

vi parent;
vi D;
vector<vector<bool> > good;

void dijkstra()
{
	parent.assign(n,-1);
	D.assign(n,inf);
	set<ii > q;
	D[x] = 0;
	q.insert(ii(0,x));
	while(!q.empty())
	{
		ii p = *q.begin();
		q.erase(q.begin());
		int from = p.second;
		for(int to = 0; to < n; to++)
		{
			int w = G[from][to];
			if(w == inf)
				continue;
			if(D[from] + w < D[to])
			{
				if(q.find(ii(D[to],to)) != q.end())
					q.erase(ii(D[to],to));
				D[to] = D[from] + w;
				q.insert(ii(D[to],to));
				parent[to] = from;
			}
		}
	}
}

void check(int v)
{
	for(int to = 0; to < n; to++)
		if(G[v][to] != inf)
		{
			if(D[v] + G[v][to] == D[to])
			{
				if(to != n-1)
					check(to);
			}
			else
				G[v][to] = inf;
		}
}

vvi c, f;

inline int cf(int i, int j)
{
	return c[i][j] - f[i][j];
}

bool hasPath(vi &path)
{
	path.resize(0);
	queue<int> q;
	vector<bool> visited(n);
	q.push(x);
	visited[x] = true;
	vi parent(n);
	while(!q.empty())
	{
		int v = q.front();
		q.pop();
		for(int i = 0; i < n; i++)
			if(cf(v,i) != 0 && !visited[i])
			{
				q.push(i);
				visited[i] = true;
				parent[i] = v;
			}
	}
	if(!visited[y])
		return false;

	int cur = y;
	while(cur != x)
	{
		path.push_back(cur);
		cur = parent[cur];
	}
	path.push_back(x);
	reverse(all(path));
	return true;
}


void maxFlow()
{
	vi path;
	while(hasPath(path))
	{
		int mi = inf;
		for(int i = 0; i < len(path)-1; i++)
			mi = min(mi, cf(path[i],path[i+1]));
		for(int i = 0; i < len(path)-1; i++)
		{
			f[path[i]][path[i+1]] += mi;
			f[path[i+1]][path[i]] -= mi;
		}
	}
}

__int32 main()
{
	cin >> n >> m >> x >> y;
	x--,y--;
	G.resize(n, vi(n,inf));
	c.resize(n, vi(n));
	f.resize(n, vi(n));
	for(int i = 0; i < m; i++)
	{
		int a, b, d;
		cin >> a >> b >> d;
		a--, b--;
		G[a][b] = d;
	}

	dijkstra();

	check(x);

	for(int i = 0; i < n; i++)
		for(int j = 0; j < n; j++)
			if(G[i][j] != inf)
				c[i][j] = 1;

	maxFlow();

	vvi ans;
	for(int i = 0; i < n; i++)
		if(f[x][i] > 0)
		{
			ans.push_back(vi());
			ans.back().push_back(x);
			int cur = i;
			while(cur != y)
				for(int j = 0; j < n; j++)
					if(f[cur][j] > 0)
					{
						ans.back().push_back(cur);
						cur = j;
						break;
					}
			ans.back().push_back(y);
		}

	cout << len(ans);
	for(int i = 0; i < len(ans); i++)
	{
		cout << endl << len(ans[i]);
		for(int j = 0; j < len(ans[i]); j++)
			cout << ' ' << ans[i][j] + 1;
	}

	/*int mi = inf;
	vvi ans;
	while(true)
	{
		dijkstra();
		if(D[y] == inf || D[y] > mi)
			break;
		mi = D[y];
		ans.push_back(vector<int>());
		int cur = y;
		while(cur != x)
		{
			ans.back().push_back(cur);
			int prev = parent[cur];
			G[prev][cur] = inf;
			cur = prev;
		}
		ans.back().push_back(x);
	}
	cout << len(ans);
	for(int i = 0; i < len(ans); i++)
	{
		cout << endl << len(ans[i]);
		for(int j = len(ans[i])-1; j >= 0; j--)
			cout << ' ' << ans[i][j] + 1;
	}*/
}