#define _CRT_SECURE_NO_DEPRECATE

#include<stdio.h>
#include<math.h>
#include<string>
#include<string.h>
#include<vector>
#include<set>
#include<map>
#include<algorithm>
#include<time.h>
#include<memory.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)
#define ZERO(x) memset(x, 0, sizeof(x))
#define SIZE(x) (int)x.size()

typedef long long int64;

#define MAX 120

int n, m, k;

int x, y, dir;

int X[4] = {-1,0,1,0};
int Y[4] = {0,-1,0,1};

int wall[10][MAX][MAX];

void Set(int x1, int y1, int x2, int y2) {
	int i, j;
	if (x1 == x2) {
		fj(min(y1, y2) + 1, max(y1, y2)) {
			wall[2][x1][j] = 1;
			wall[0][x1 + 1][j] = 1;
		}
	} else if (y1 == y2) {
		fi(min(x1, x2) + 1, max(x1, x2)) {
			wall[3][i][y1] = 1;
			wall[1][i][y1 + 1] = 1;
		}
	}
}

void Wall() {
	int i, j;
	int x1, y1, x2, y2;
	scanf("%d %d %d %d", &x1, &y1, &x2, &y2);
	if (x1 == x2) {
		fj(min(y1, y2) + 1, max(y1, y2)) {
			wall[2][x1][j] = 1;
			wall[0][x1 + 1][j] = 1;
		}
	} else if (y1 == y2) {
		fi(min(x1, x2) + 1, max(x1, x2)) {
			wall[3][i][y1] = 1;
			wall[1][i][y1 + 1] = 1;
		}
	}
}

int color[10][MAX][MAX];

void No() {
	printf("NO\n");
	exit(0);
}

int ans;

int Inc(int x) {
	x++;
	return x % 4;
}

int Dec(int x) {
	x--;
	if (x < 0) x += 4;
	return x;
}

int main() {
	int x0, y0;
	char s[10];
	int i;
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf("%d %d %d", &m, &n, &k);
	scanf("%d %d %s", &y, &x, s);

	Set(0, 0, 0, m + 1);
	Set(0, 0, n + 1, 0);
	Set(n, 0, n, m + 1);
	Set(0, m, n + 1, m);

	if (s[0] == 'N') dir = 3;
	if (s[0] == 'E') dir = 2;
	if (s[0] == 'S') dir = 1;
	if (s[0] == 'W') dir = 0;
	fi(1, k) {
		Wall();
	}
	wall[0][1][2] = 0;
	while (1) {
		if (x == 0) {
			break;
		}
		if (color[dir][x][y]) No();
		color[dir][x][y] = 1;
		if (wall[dir][x][y]) {
			//ans++;
			dir = Inc(dir);
		} else if (wall[Dec(dir)][x][y] == 1) {
			ans++;
			x += X[dir];
			y += Y[dir];
		} else {
			ans++;
			dir = Dec(dir);
			x += X[dir];
			y += Y[dir];
		}
	}
	printf("YES\n");
	printf("%d\n", ans);
	return 0;
}
