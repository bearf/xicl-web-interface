#include<stdio.h>
#include<stdlib.h>
double v1x,v2x,v1y,v2y,x[1100],y[1100],k1,k2,b1,b2;
int i,j,n;
int main(){
freopen("input.txt","r",stdin);
freopen("output.txt","w",stdout);
scanf("%i",&n);
for(i=0;i<n;i++)
scanf("%lf%lf",&x[i],&y[i]);
x[n]=x[0];y[n]=y[0];
scanf("%lf%lf",&v1x,&v1y);
scanf("%lf%lf",&v2x,&v2y);
for(i=0;i<n;i++)
for(j=i+1;j<n;j++)
if(j-i<n-1)
if(x[i+1]!=x[j] && x[j+1]!=x[i])
{
k1=(y[j+1]-y[i])/(x[j+1]-x[i]);
b1=y[i]-k1*x[i];
k2=(y[i+1]-y[j])/(x[i+1]-x[j]);
b2=y[j]-k2*x[j];

if(y[i]>=y[i+1])
if((v1x*k1+b1>=v1y && v1x*k2+b2<=v1y)&&(v2x*k1+b1>=v2y && v2x*k2+b2<=v2y))
{printf("%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n",x[i],y[i],x[i+1],y[i+1],x[j],y[j],x[j+1],y[j+1]);return 0;}
else if(y[i]<=y[i+1])
if((v1x*k1+b1<=v1y && v1x*k2+b2>=v1y)&&(v2x*k1+b1<=v2y && v2x*k2+b2>=v2y))
{printf("%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n",x[i],y[i],x[i+1],y[i+1],x[j],y[j],x[j+1],y[j+1]);return 0;}
}
else
if(x[i+1]==x[j] && x[j+1]!=x[i])
{

k2=(y[j+1]-y[i])/(x[j+1]-x[i]);
b2=y[j]-k2*x[j];

if(y[i]>=y[i+1])
if((v1x>=x[i] && v1x*k2+b2<=v1y)&&(v2x>=x[i] && v2x*k2+b2<=v2y))
{printf("%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n",x[i],y[i],x[i+1],y[i+1],x[j],y[j],x[j+1],y[j+1]);return 0;}
else if(y[i]<=y[i+1])
if((v1x<=x[i] && v1x*k2+b2>=v1y)&&(v2x<=x[i] && v2x*k2+b2>=v2y))
{printf("%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n",x[i],y[i],x[i+1],y[i+1],x[j],y[j],x[j+1],y[j+1]);return 0;}
}
else
if(x[i+1]!=x[j] && x[j+1]==x[i])
{
k1=(y[i+1]-y[j])/(x[i+1]-x[j]);
b1=y[i]-k1*x[i];


if(y[i]>=y[i+1])
if((v1x*k1+b1>=v1y && v1x<=x[j])&&(v2x*k1+b1>=v2y && v2x<=x[j]))
{printf("%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n",x[i],y[i],x[i+1],y[i+1],x[j],y[j],x[j+1],y[j+1]);return 0;}
else if(y[i]<=y[i+1])
if((v1x*k1+b1<=v1y && v1x>=x[j])&&(v2x*k1+b1<=v2y && v2x>=x[j]))
{printf("%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n",x[i],y[i],x[i+1],y[i+1],x[j],y[j],x[j+1],y[j+1]);return 0;}
}
else
if(x[i+1]==x[j] && x[j+1]==x[i])
{

if(y[i]>=y[i+1])
if((v1x>=x[i] && v1x<x[j])&&(v2x>=x[i] && v2x<=x[j]))
{printf("%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n",x[i],y[i],x[i+1],y[i+1],x[j],y[j],x[j+1],y[j+1]);return 0;}
else if(y[i]<=y[i+1])
if((v1x<=x[i] && v1x>=x[j])&&(v2x<=x[i] && v2x>=x[j]))
{printf("%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n%.0lf %.0lf\n",x[i],y[i],x[i+1],y[i+1],x[j],y[j],x[j+1],y[j+1]);return 0;}
}
return 0;
}