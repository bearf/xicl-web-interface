#include <iostream>
#include <cstdio>
#include <vector>
#include <sstream>
#include <string>
#include <map>
#include <set>
#include <algorithm>
//#include <cmath>

using namespace std;

#define bublic public
#define sz size()
#define clr(a) memset(a,0,sizeof(a))
#define ll long long
#define ld long double
#define istr istringstream
#define pb push_back
#define forn(i,n) for(int i=0; i<n; i++)

const ld EPS=1e-9;
const ld PI=3.1415926535897932384626433832795;
const int INF=2000000000;

ll n,m,a,b,c;

int main()
{
    freopen("input.txt","rt",stdin);
    freopen("output.txt","wt",stdout);    
    cout.flags(ios::fixed);
    cout.precision(10);
    cin>>n>>m>>a>>b>>c;
    ll ans=0;
    for(int i=0;i<n-1;i++)
    for(int j=0;j<m-1;j++)
    for(int ii=i+1;ii<n-1;ii++)
    for(int jj=j+1;jj<m-1;jj++)
    {
        ll now=jj-j;
        now*=max((ll)0,(jj-j)-b+1);
        now*=max((ll)0,(ii-i)-a+1);        
        now*=max((ll)0,(ii-i)-c+1);                
        ans+=now;
    }
    cout<<ans;
    return 0;
}
