import java.io.*;
import java.util.*;

public class Solution {

	BufferedReader cin;
	PrintWriter cout;
	StringTokenizer tok;
	
	public static void main(String[] args) throws IOException 
	{
		new Solution().run();
	}

	void run() throws IOException
	{
		cin = new BufferedReader(new FileReader("input.txt"));
		cout = new PrintWriter(new FileWriter("output.txt"));
		
		solve();
		
		cout.flush();
		System.exit(0);
	}
	
	String next() throws IOException
	{
		if( tok == null || !tok.hasMoreTokens() )
			tok = new StringTokenizer(cin.readLine());
		
		return tok.nextToken();
	}
	
	int nextInt() throws IOException
	{
		return Integer.parseInt(next());
	}

	ArrayList<int[]> points;
	
	int[] pointa, pointb;
	
	void solve() throws IOException
	{
		int n = nextInt();
		
		points = new ArrayList<int[]>();
		
		pointa = new int[2];
		pointb = new int[2];
		
		for( int i = 0 ; i < n ; i++ )
		{
			int[] point = new int[2];
			point[0] = nextInt();
			point[1] = nextInt();
			points.add(point);
		}
		
		pointa[0] = nextInt();
		pointa[1] = nextInt();
		pointb[0] = nextInt();
		pointb[1] = nextInt();
		
		int i = 0;
		
		while( points.size() > 4 )
		{
			int next = (i + 2) % points.size();
			
			if( ((points.get(next)[0] - points.get(i)[0]) * (pointa[1] - points.get(i)[1]) - 
					(pointa[0] - points.get(i)[0]) * (points.get(next)[1] - points.get(i)[1]) <= 0)
					&&
				((points.get(next)[0] - points.get(i)[0]) * (pointb[1] - points.get(i)[1]) - 
					(pointb[0] - points.get(i)[0]) * (points.get(next)[1] - points.get(i)[1]) <= 0)
							)
			{
				points.remove((i + 1) % points.size());
			}
			else
				i = (i + 1) % points.size();
		}
		
		for( int j = 0 ; j < 4; j++ )
			cout.println(points.get(j)[0] + " " + points.get(j)[1]);
	}
}
