#include <fstream>

using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");
int n,m,a,b,c;
int main() {
	cin >> n >> m >> b >> a >> c;
	long long ans = 0;
	for (int i=0;i<n-2;i++) {
		for (int j=1;j<m-a;j++) {
			for (int ii=i+max(b,c)+1;ii<n;ii++) {
				for (int jj=1;jj<m-1;jj++) {
					if (ii -i >=b && ii-i >=c) {
						ans+= min(j,jj)*(ii-i-b) * (m - max(j+a,jj+1))*(ii-i-c);
					}
				}
			}
		}
	}
	cout << ans;
	return 0;
}