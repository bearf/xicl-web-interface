#include <stdio.h>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <queue>
#include <deque>
#include <cassert>
#include <memory.h>
#include <algorithm>
#include <math.h>
#include <sstream>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) ((int)(a.size()))

const int INF = 2000000000;

typedef long long lint;

void prepare()
{
	freopen("input.txt", "r", stdin);
#ifndef _DEBUG
	freopen("output.txt", "w", stdout);
#endif
}

lint n;
int m;

bool test(int last, lint p)
{
	
	vector<int> ans;

	ans.pb(last);

	n -= p;
	n = -n;

	for (int i = 1; i < m - 1; i++)
	{
		if (n < 0)
			return false;

		p = 1LL;
		int sm = m - i;
		int q = m - i;

		while (p < n)
		{
			q++;
			if (q == last)
				return false;
			p *= q;
			p /= (q - sm);
		}

		n -= p;
		n = -n;
		ans.pb(q);
		last = q;
	}

	if (n <= 0)
		return false;

	for (int i = 0; i < ans.size(); i++)
		printf("%d ", ans[i]);
	printf("%d\n", n);

	return true;
}

bool solve()
{
	scanf("%lli%d", &n, &m);

	lint fuck = n;

	lint p = 1LL;
	int sm = m;
	int q = m;
	for (int i = m; ; i++)
	{
		n = fuck;

		if (p > 100000000000000000LL)
		{
			while (true);
		}

		q++;
		p *= q;
		p /= (q - sm);

		if (p >= n)
			if (test(q, p))
				return false;

		
	}

	return false;
}

int main()
{
	prepare();
	while (solve());
	return 0;
}

