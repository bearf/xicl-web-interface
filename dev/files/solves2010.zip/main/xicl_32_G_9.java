import java.io.*;
import java.lang.*;
import java.math.*;
import java.util.*;

public class Solution {
	
	int n;
	long[] x, y;
	long vx1, vy1, vx2, vy2;
	int[] L, R;
	
	void run() throws Exception{
		n = nextInt();
		x = new long[n]; y = new long[n];
		for (int i = 0; i < n; ++i){
			x[i] = nextLong();
			y[i] = nextLong();
		}
		vx1 = nextLong(); vy1 = nextLong();
		vx2 = nextLong(); vy2 = nextLong();
		for (int i = 0; i < n; ++i){
			for (int j = 0; j < n; ++j){
				int a = i, b = (i + 1) % n, c = j, d = (j + 1) % n;
				if (a == b || a == c || a == d || b == c || b == d || c == d)
					continue;
				if (test(a, b, c, d)){
					wr(a, b, c, d);
					return;
				}
			}
		}
		for (int i = 0; i < n; ++i){
			for (int j = 0; j < n; ++j){
				int a = i, b = (i + 1) % n, c = (i + 2) % n;
				if (j == a || j == b || j == c)
					continue;
				if (test(a, b, c, j)){
					wr(a, b, c, j);
					return;
				}
			}
		}
		/*preCalc();
		for (int i = 0; i < n; ++i){
			int l = L[i], r = R[i];
			if (trySolve(i, l, r))
				return;
			if (((l + n - 1) % n) != i && trySolve(i, (l + n - 1) % n, r))
				return;
			if (((r + 1) % n) != i && trySolve(i, l, (r + 1) % n))
				return;
			if (l == r){
				if (((l + n - 1) % n) != i && ((l + n - 2) % n) != i && trySolve(i, (l + n - 2) % n, r))
					return;
				if (((r + 1) % n) != i && ((r + 2) % n) != i && trySolve(i, l, (r + 2) % n))
					return;
				if (((l + n - 1) % n) != i && ((r + 1) % n) != i && trySolve(i, (l + n - 1) % n, (r + 1) % n))
					return;
			}
		}*/
		
		throw new Exception();
	}
	
	/*private boolean trySolve(int i, int l, int r) {
		if (l == r)
			return false;
		int j = (l + 1) % n;
		while (j != r){
			if (test(i, l, j, r)){
				wr(i, l, j, r);
				return true;
			}
			j = (j + 1) % n;
		}
		return false;
	}*/

	private void wr(int i, int l, int j, int r) {
		if (i == l || i == j || i == r || l == j || l == r || j == r){
			while (true) { }
		}
		out.println(x[i] + " " + y[i]);
		out.println(x[l] + " " + y[l]);
		out.println(x[j] + " " + y[j]);
		out.println(x[r] + " " + y[r]);
	}

	private boolean test(int a, int b, int c, int d) {
		return isOK(x[a], y[a], x[b], y[b]) && isOK(x[b], y[b], x[c], y[c]) && isOK(x[c], y[c], x[d], y[d]) && isOK(x[d], y[d], x[a], y[a]);
	}
	/*private boolean test(int i, int l, int j, int r) {
		return isOK(x[l], y[l], x[j], y[j]) && isOK(x[j], y[j], x[r], y[r]);
	}*/

	/*private void preCalc() {
		L = new int[n]; R = new int[n];
		for (int i = 0; i < n; ++i){
			L[i] = (i + 1) % n;
			while (isOK(x[i], y[i], x[L[i]], y[L[i]]))
				L[i] = (L[i] + 1) % n;
			//if (L[i] == i)
			L[i] = (L[i] + n - 1) % n;
			
			R[i] = (i + n - 1) % n;
			while (isOK(x[R[i]], y[R[i]], x[i], y[i]))
				R[i] = (R[i] + n - 1) % n;
			R[i] = (R[i] + 1) % n;
		}
	}*/

	boolean isOK(long x1, long y1, long x2, long y2){
		/*if (x1 == x2 && y1 == y2)
			return false;*/
		return isOK(x1, y1, x2, y2, vx1, vy1) && isOK(x1, y1, x2, y2, vx2, vy2);
	}
	
	boolean isOK(long x1, long y1, long x2, long y2, long vx, long vy){
		long a = pssc(x2 - x1, y2 - y1, vx - x1, vy - y1);
		double d = (double)a / Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
		if (Math.abs(d) < 1e-9)
			return true;
		return a <= 0;
	}
	
	long pssc(long x1, long y1, long x2, long y2){
		return x1 * y2 - x2 * y1;
	}
	
	double nextDouble() throws NumberFormatException, IOException{
		return Double.parseDouble(nextToken());
	}
	
	long nextLong() throws NumberFormatException, IOException{
		return Long.parseLong(nextToken());
	}
	
	int nextInt() throws NumberFormatException, IOException{
		return Integer.parseInt(nextToken());
	}
	
	String nextToken() throws IOException{
		while (!St.hasMoreTokens()){
			String line = in.readLine();
			St = new StringTokenizer(line);
		}
		return St.nextToken();
	}
	
	BufferedReader in;
	StringTokenizer St;
	PrintWriter out;
	
	public Solution(){
		try{
			in = new BufferedReader(new FileReader("input.txt"));
			St = new StringTokenizer("");
			out = new PrintWriter(new FileWriter("output.txt"));
			
			run();
			
			in.close();
			out.close();
		}
		catch(Exception e){
			e.printStackTrace();
			System.exit(42);
		}
	}

	public static void main(String[] args) {
		new Solution();
	}

}
