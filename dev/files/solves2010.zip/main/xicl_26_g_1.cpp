#include <fstream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <queue>

using namespace std;

ifstream cin("input.txt");
ofstream cout("output.txt");

#define len(v) (int)(v).size()
#define vi vector<int>
#define vvi vector<vi >
#define ii pair<int,int>
#define vii vector<ii >
#define all(v) (v).begin(),(v).end()
#define vvii vector<vii >
#define inf 1000000000

struct point
{
	int x, y;
	point (int x, int y)
	{
		this->x = x, this->y = y;
	}
	point () {}
	point operator - (point &a)
	{
		return point (x-a.x, y-a.y);
	}
};

int vp(point &a, point &b, point &c)
{
	point l = b-a, r = c-a;
	int res = l.x*r.y - l.y*r.x;
	return -res;
}

int n;

vector<point> v;

__int32 main()
{
	cin >> n;
	v.resize(n);
	for(int i = 0; i < n; i++)
		cin >> v[i].x >> v[i].y;
	int cur = 0;
	point a, b;
	cin >> a.x >> a.y >> b.x >> b.y;
	while(len(v) > 4)
	{
		int next = (cur+2)%len(v);
		int p1 = vp(v[cur],v[next],a), p2 = vp(v[cur],v[next],b);

		if(p1 >= 0 && p2 >= 0)
		{
			int todel = (cur+1)%len(v);
			v.erase(v.begin() + todel);
			continue;
		}
		else
			cur = (cur+1)%len(v);
	}
	for(int i = 0; i < 4; i++)
		cout << v[i].x << ' ' << v[i].y << endl;
}