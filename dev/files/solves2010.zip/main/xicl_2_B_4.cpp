#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <math.h>
#include <time.h>
#pragma comment (linker,"/STACK:32000000")
using namespace std;
const int maxn = 110;
int mas[maxn][maxn]={0};
int d[maxn]={0};
int from[maxn]={0};
int flag[maxn]={0};
const int inf = 1000000000;
void dij(int v, int n)
{
	int i,j,mn,pos;
	for (i=1;i<=n;i++)
	{
		flag[i] = 0;
		d[i] = inf;
	}
	d[v] = 0;
	from[v] = 0;
	int w;
	while (1)
	{
		mn = -1;
		pos = 0;
		for (i=1;i<=n;i++)
		{
			if (flag[i]==0 && (mn==-1 || d[i]<mn))
			{
				mn = d[i];
				pos = i;
			}
		}
		if (pos==0 || mn==inf)
			break;

		v = pos;
		flag[v] = 1;

		for (i=1;i<=n;i++)
		{
			w = mas[v][i];
			if (w!=0 && d[v]+w<d[i])
			{
				from[i] = v;
				d[i] = d[v] + w;
			}
		}
	}
}
int all = 0;
int way[maxn*maxn][maxn]={0};
void pr(int *st, int y, int n)
{
	st[0] = 0;
	while (y!=0)
	{
		st[++st[0]] = y;
		y = from[y];
	}
	int i;
	for (i=st[0]-1;i>=1;i--)
	{
		mas[st[i+1]][st[i]] = 0;
	}	
	return;
}
int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int i,j,n,m,x,y,a,b,l;
	cin >> n >> m >> x >> y;
	for (i=1;i<=m;i++)
	{
		cin >> a >> b >> l;
		mas[a][b] = l;
	}
	dij(x,n);
	int mnway;
	if (d[y]!=inf)
	{
		mnway = d[y];
		all++;
		pr(&way[all][0],y,n);
		while (1)
		{
			dij(x,n);
			if (d[y]==mnway)
			{
				all++;
				pr(&way[all][0],y,n);
			}
			else break;
		}
	}
	printf("%d",all);
	for (i=1;i<=all;i++)
	{
		printf("\n");
		printf("%d",way[i][0]);
		for (j=way[i][0];j>=1;j--)
			printf(" %d",way[i][j]);
	}

	return 0;
}
