#include <stdio.h>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <queue>
#include <deque>
#include <cassert>
#include <memory.h>
#include <algorithm>
#include <math.h>
#include <sstream>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) ((int)(a.size()))

const int INF = 2000000000;

typedef long long lint;

void prepare()
{
	freopen("input.txt", "r", stdin);
#ifndef _DEBUG
	freopen("output.txt", "w", stdout);
#endif
}

lint n;
int m;

bool solve()
{
	scanf("%lli%d", &n, &m);

	for (int i = 0; i < m - 1; i++)
	{
		assert(n >= 0LL);

		lint p = 1LL;
		lint sm = m - i;
		lint q = m - i;
		while (p < n)
		{
			q++;
			p *= q;
			p /= (q - sm);
		}

		n -= p;

		n = -n;

		printf("%lli ", q);

		//mul = mul * -1;
	}

	assert(n > 0LL);
	printf("%lli\n", n);

	return false;
}

int main()
{
	prepare();
	while (solve());
	return 0;
}

