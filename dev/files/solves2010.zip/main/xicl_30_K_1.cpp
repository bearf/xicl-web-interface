#define _CRT_SECURE_NO_DEPRECATE

#include<stdio.h>
#include<math.h>
#include<string>
#include<string.h>
#include<vector>
#include<set>
#include<map>
#include<algorithm>
#include<time.h>
#include<memory.h>

using namespace std;

#define pb push_back
#define mp make_pair

#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)
#define ZERO(x) memset(x, 0, sizeof(x))
#define SIZE(x) (int64)x.size()

typedef long long int64;
typedef pair<int64, int64> pii;

int64 n, k;

vector <pii> Factor(int64 x) {
	int64 c;
	int64 i;
	vector <pii> v;
	for (i=2; i * i <= x; i++) {
		if (x % i == 0) {
			v.pb(mp(i, 0));
			c = SIZE(v) - 1;
			while (x % i == 0) {
				v[c].second++;
				x /= i;
			}
		}
	}
	if (x != 1) {
		v.pb(mp(x, 1));
	}
	return v;
}

vector <pii> vk;

int64 Count(int64 a) {
	int64 i;
	int64 res;
	int64 x;
	x = a;
	res = 0;
	for (i=1; ; i++) {
		if (a > n) break;
		res += n / a;
		a *= x;
	}
	return res;
}

int main() {
	int64 ans;
	int64 i;
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf("%lld %lld", &n, &k);
	vk = Factor(k);
	fi(0, SIZE(vk) - 1) {
		vk[i].second *= k;
	}
	ans = 1000000000LL * 1000000000LL;
	fi(0, SIZE(vk) - 1) {
		ans = min(ans, Count(vk[i].first) / vk[i].second);
	}
	printf("%lld\n", ans);
	return 0;
}
