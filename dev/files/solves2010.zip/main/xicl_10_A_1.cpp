#include <iostream>
#include <cmath>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <sstream>
#include <string>
#include <algorithm>
#include <functional>
#include <numeric>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define ford(i, n) for(int i = int(n) - 1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define X first
#define Y second

typedef long double ld;
typedef long long li;
typedef pair<int, int> pt;

const int INF = (int)1E9;
const ld EPS = (1E-9);

const int NMAX = 1000;

int A, B, C;

int N, M;

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> N >> M;

	cin >> A >> B >> C;

	li ans = 0;
	forn(tx, N){
		forn(ty, M){
			forn(i, tx){
				forn(j, M){
					int lf = min(ty, j), rg = min(M - ty - 1, M - j - B);

					int w = tx - i - 1;
					
					if(lf == 0 || rg == 0) continue;
					if(w < A || w < C) continue;

					ans += (lf) * (w - A + 1) * (rg) * (w - C + 1);
				}
			}
		}
	}

	cout << ans << endl;
	//cerr << clock() << endl;
	return 0;
}