#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <set>
#include <map>
#include <vector>

using namespace std;

#define mp make_pair
#define pb push_back

int n, tin[ 100100 ], tout[ 100100 ], timer = 0, depth[ 100100 ], order[ 100100 ], answer = 0;
int p[ 20 ][ 100100 ];
set< int > s;
vector< int > graph[ 100100 ];

void dfs( int v, int prev )
{
    p[0][v] = prev;
    for ( int i = 1; i < 20; i++ ) p[i][v] = p[i - 1][ p[i - 1][v] ];
    tin[v] = ++timer;
    order[ timer ] = v;
    for ( int i = 0; i < (int)graph[v].size(); i++ )
    {
        int next = graph[v][i];
        if ( next == prev ) continue;
        depth[next] = depth[v] + 1;
        dfs( next, v );
    }
    tout[v] = timer;
}

int is_parent( int parent, int child )
{
    if ( tin[ parent ] <= tin[ child ] && tout[ child ] <= tout[ parent ] ) return true;
    return false;
}

int lca( int a, int b )
{
    if ( is_parent( a, b ) ) return a;
    if ( is_parent( b, a ) ) return b;
    for ( int i = 19; i >= 0; i-- )
        if ( !is_parent( p[i][a], b ) )
            a = p[i][a];
    return p[0][a];
}

int dist( int a, int b )
{
    return depth[a] + depth[b] - 2 * depth[ lca( a, b ) ];
}

void add( int v )
{
    int id = tin[v];
    set< int >::iterator it1 = s.upper_bound( id );
    if ( it1 == s.end() ) it1 = s.begin();
    set< int >::iterator it2 = s.upper_bound( id );
    if ( it2 == s.begin() ) it2 = s.end();
    it2--;
    int id_a = *it1;
    int id_b = *it2;
    answer -= dist( order[ id_a ], order[ id_b ] );
    answer += dist( v, order[ id_a ] );
    answer += dist( v, order[ id_b ] );
    s.insert( id );
}

int main()
{
    scanf("%d", &n);
    for ( int i = 1; i < n; i++ )
    {
        int a, b; scanf("%d%d", &a, &b);
        graph[a].pb( b );
        graph[b].pb( a );
    }
    dfs( 1, 1 );
    int m; scanf("%d", &m);
    s.insert( 1 );
    while ( m-- )
    {
        int v; scanf("%d", &v);
        add( v );
        printf("%d ", answer - depth[v] );
    }
    return 0;
}
/*
7
1 2
1 3
3 4
3 5
3 6
6 7
6
6 4 2 7 3 5
*/
