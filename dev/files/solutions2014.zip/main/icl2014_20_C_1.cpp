#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <set>
#include <map>
#include <vector>

using namespace std;

int a[ 500 ];

int main()
{
    long long n;
    cin >> n;
    for ( int i = 0; i < 500; i++ )
    {
        a[i] = n % 2;
        n /= 2;
    }
    for ( int i = 0; i < 500; i++ )
    {
        if ( a[i] == 1 && a[i + 1] == 1 )
        {
            a[i + 2] += 1;
            a[i + 1] = 0;
            a[i] = -1;
            for ( int j = i + 2; j < 499; j++ )
            {
                if ( a[j] == 2 )
                {
                    a[j] = 0;
                    a[j + 1] += 1;
                }
            }
        }
    }
    int k = -1;
    for ( int i = 0; i < 500; i++ ) if ( a[i] != 0 ) k = i;
    for ( int i = k; i >= 0; i-- ) cout << a[i] << " ";
    return 0;
}
