#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <queue>
#include <deque>
#include <complex>

using namespace std;

#define pb push_back
#define pbk pop_back
#define all(x) (x).begin(), (x).end()
#define fs first
#define sc second
#define y0 yy0
#define y1 yy1
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define prev _prev
#define rank _rank
#define next _next
#define link _link
#define hash _hash
#ifdef LOCAL
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef complex<double> tc;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));
const int N = int(2e5) + 100;

int a[N], b[N], c[N], link[N], can[N], prev[N], next[N];
vi pos[N];

inline bool check(int l, int r) {
	if (l > r) {
		return true;
	}
	if (b[l] == b[r]) {
		return true;
	}
	int p1 = next[l], p2 = prev[r];
	if (p1 <= p2) {
		if (can[link[p1]] < link[p2] - link[p1] + 1) {
			return false;
		}
		if (pos[link[l]][p1 - l - 1] >= pos[link[p1]][0]) {
			return false;
		}
		if (pos[link[p2]].back() >= pos[link[r]][0]) {
			return false;
		}
		return true;
	}
	if (pos[link[l]][p1 - l - 1] >= pos[link[r]][0]) {
		return false;
	}
	return true;
}

int main() {
#ifdef LOCAL
#define TASK "E"
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; ++i) {
		scanf("%d", &a[i]);
		b[i] = a[i];
	}
	sort(b, b + n);
	for (int i = 0; i < n; ++i) {
		c[i] = b[i];
	}
	int k = unique(c, c + n) - c;
	for (int i = 0; i < n; ++i) {
		pos[lower_bound(c, c + k, a[i]) - c].pb(i);
	}
	for (int i = 0; i < n; ++i) {
		link[i] = lower_bound(c, c + k, b[i]) - c;
	}
	for (int i = k - 1; i >= 0; --i) {
		can[i] = 1;
		if (i + 1 < k && pos[i].back() < pos[i + 1][0]) {
			can[i] += can[i + 1];
		}
	}
	prev[0] = -1;
	for (int i = 1; i < n; ++i) {
		if (b[i - 1] == b[i]) {
			prev[i] = prev[i - 1];
		}
		else {
			prev[i] = i - 1;
		}
	}
	next[n - 1] = n;
	for (int i = n - 2; i >= 0; --i) {
		if (b[i] == b[i + 1]) {
			next[i] = next[i + 1];
		}
		else {
			next[i] = i + 1;
		}
	}
	int ans = n;
	for (int i = 0; i < n; ++i) {
		int l = i + 1, r = n, g = -1;
		while (l <= r) {
			int mid = (l + r) / 2;
			if (check(i, mid - 1)) {
				g = mid;
				l = mid + 1;
			}
			else {
				r = mid - 1;
			}
		}
		ans = min(ans, i + (n - g));
	}
	printf("%d", ans);
	return 0;
}
