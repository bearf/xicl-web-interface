#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <stdio.h>
#include <queue>
#include <deque>
#define USE_MATH_DEFINES
#include <math.h>

#define ll long long
#define ull unsigned ll
#define mp make_pair
#define pb push_back

using namespace std;

const ll MOD = 1000000007;
const ll INF = 1000000000000000;

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif
	int n;
	ll k(0), sum(0);

	cin >> n;
	for (int i(0); i < n; i++) {
		for (int j(0); j < n; j++) {
			int t;
			cin >> t;
			sum += t;
			if (t == 0)
				k++;
		}
	}

	if (k > (n * n - k)) {
		cout << -1;
		return 0;
	}
	else
		cout << sum;
}