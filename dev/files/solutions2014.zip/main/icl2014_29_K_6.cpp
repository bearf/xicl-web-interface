#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cassert>
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <ctime>

using namespace std;

#ifdef _WIN32
	#define LLD "%I64d"
#else
	#define LLD "%lld"
#endif

typedef long double ld;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<long long> vll;

#define mp make_pair
#define pb push_back
#define x first
#define y second
#define sz(x) ((int)(x).size())
#define EPS (1e-9)
#define INF ((int)1e9)
#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define TASK "text"

const ld eps = 1e-9;
struct pnt {
	ld x, y;
	pnt() {
	}
	pnt(ld x, ld y) :x(x),y(y) {
    }	
};
pnt operator -(pnt a, pnt b) {
	return pnt(a.x - b.x, a.y - b.y);
} 
pnt operator +(pnt a, pnt b) {
	return pnt(a.x + b.x, a.y + b.y);
} 
pnt operator *(pnt a, ld c) {
	return pnt(a.x * c, a.y * c);
} 
pnt operator /(pnt a, ld c) {
	return pnt(a.x / c, a.y / c);
} 


ld sp(pnt a, pnt b) {
	return a.x * b.x + a.y * b.y;
}
ld vp(pnt a, pnt b) {
	return a.x * b.y - a.y * b.x;
}

ld dst(pnt a, pnt b) {
	return sqrt(sp(a - b, a - b));
}
vector<pair<pnt, ld> > ls;
int n;
pnt p[111];
int R1, R2;
struct line {
	ld a, b, c;
	line() {
	}
	line(pnt p1, pnt p2) {
		a = p1.y - p2.y;
		b = p2.x - p1.x;
		c = -(a * p1.x + b * p1.y);
		ld d = sqrt(a * a + b * b);
		a /= d;
		b /= d;
		c /= d;
	}
};


line l[100000];
ld a[3][3];
int wh[3];
int was[3];
ld res[3];
int solve() {
	if (scanf("%d", &n) < 1)
		return 0;
	ld ax = 1;
	ld bx = 0;
	ld cx = 0;
	ld ay = 0;
	ld by = 1;
	ld cy = 0;

	for (int i = 0; i < n; i++) {
		int x1, y1, x2, y2;
		scanf("%d %d %d %d", &x1, &y1, &x2, &y2);
		l[i] = line(pnt(x1, y1), pnt(x2, y2));
	}
	l[n] = l[0];
	for (int i = 1; i <= n; i++) {
		ld ah = l[i].a * ax + l[i].b * ay;
		ld bh = l[i].a * bx + l[i].b * by;
		ld ch = l[i].a * cx + l[i].b * cy + l[i].c;
		ax -= ah * l[i].a;
		bx -= bh * l[i].a;
		cx -= ch * l[i].a;

		ay -= ah * l[i].b;
		by -= bh * l[i].b;
		cy -= ch * l[i].b;
	}
	a[0][0] = ax - 1;
	a[0][1] = bx;
	a[0][2] = cx;
	a[1][0] = ay;
	a[1][1] = by - 1;
	a[1][2] = cy;
	int n = 2;
	int m = 2;		
	for (int i = 0; i < n; i++) {
		was[i] = 0;	
	}
	for (int i = 0; i < m; i++) {
		wh[i] = -1;
	}
	for (int i = 0; i < n; i++) {
		ld ff = 1;
		for (int j = 0; j <= m; j++) {
			ff = max(ff, fabs(a[i][j]));
		}
		for (int j = 0; j <= m; j++) {
			a[i][j] /= ff;
		}
	}
	while (1) {
		int dx = -1;
		int dy = -1;
		for (int i = 0; i < n; i++) if (was[i] == 0) {
			for (int j = 0; j < m; j++) {
				if (fabs(a[i][j]) > eps) {
					dx = i;
					dy = j;
				}
			}                          
		}
		if (dx == -1) break;
		wh[dy] = dx;
		was[dx] = 1;
		{
			ld ff = a[dx][dy];
			for (int i = 0; i <= m; i++) {
				a[dx][i] /= ff;
			}
		}
		for (int i = 0; i < n; i++) if (i != dx) {
			ld ff = a[i][dy];
			for (int j = 0; j <= m; j++) {
				a[i][j] -= ff * a[dx][j];
			}
		}
	}
	for (int i = 0; i < n; i++) {
		if (was[i] == 0) {
			if (fabs(a[i][m]) > eps) {
				printf("-1\n");
				return 1;
			}
		}
	}
	for (int i = 0; i < m; i++) {	
		if (wh[i] == -1) {
			res[i] = 0;			
		} else {
			res[i] = -a[wh[i]][m];
		}
	}
	printf("%.18lf %.18lf\n", (double)res[0], (double)res[1]);
	return 1;
}

int main() {
#ifdef DEBUG
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	
	int n;
	while (1) {
		if (!solve())
			break;
		#ifdef DEBUG
		eprintf("%.18lf\n", (double)clock() / CLOCKS_PER_SEC);		
		#endif
	}
	return 0;
}
