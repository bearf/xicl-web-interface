#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cassert>
#include <ctime>
#include <memory.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <complex>
#include <list>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef complex <ld> point;

#define pb push_back
#define mp make_pair
#define fi first
#define se second

#define INF 1000000001
#define INFL 1000000000000000001ll
#define NAME "g"

vector <int> g[100001];
int h[100001];
int used[100001];
int par[100001];

void precalc(int u, int prev = -1, int h = 0) {
    par[u] = prev;
    ::h[u] = h;
    for (int i = 0; i < (int) g[u].size(); ++i) {
        int v = g[u][i];
        if (v == prev)
            continue;
        precalc(v, u, h + 1);
    }
}

int main() {
    #ifdef _GEANY
    assert(freopen(NAME ".in", "r", stdin));
    #endif // _GEANY
    int n;
    cin >> n;
    for (int i = 0; i < n - 1; ++i) {
        int u, v;
        scanf("%d%d", &u, &v);
        --u, --v;
        g[u].pb(v);
        g[v].pb(u);
    }
    precalc(0);
    int q;
    cin >> q;
    int c = 0;
    used[0] = 1;
    for (int i = 0; i < q; ++i) {
        int u;
        scanf("%d", &u);
        --u;
        int ch = h[u];
        while (!used[u]) {
            c += 2;
            used[u] = 1;
            u = par[u];
        }
        cout << c - ch << ' ';
    }
    cout << endl;
}
