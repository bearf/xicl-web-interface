#include <iostream>
#include <cstring>
#include <cstdio>


const int mod = 1000000009;
const int maxk = 21;
const int maxn = 1000146;


using namespace std;


int dp[maxk][maxn];


int main()
{
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
	int n, k;
	scanf("%d%d", &n, &k);
	dp[0][1] = 1;
	for(int i = 0; i <= k; i++)
	{
		for(int j = 1; j <= n; j++)
		{
			dp[i][j] = (dp[i][j] + dp[i][j - 1]) % mod;
			if(2 * j <= n)
				dp[i + 1][2 * j] = (dp[i + 1][2 * j] + dp[i][j]) % mod;
		}
	}
	printf("%d\n", dp[k - 1][n]);
}