#pragma comment(linker, "/STACK:64000000")

#include<iostream>
#include<cstdio>
#include<sstream>

#include<algorithm>
#include<vector>
#include<set>
#include<bitset>
#include<map>
#include<queue>
#include<deque>
#include<stack>

#include<string>
#include<memory.h>
#include<cassert>
#include<time.h>

using namespace std;

#define forn(i, n) for(int i = 0; i < (int)n; i++)
#define forab(i, a, b) for(int i = (int)a; i <= (int)b; i++)
#define fornd(i, n) for(int i = 0; i < (int)n; i--)
#define forabd(i, b, a) for(int i = (int)b; i >= (int)a; i--)
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define _(a, val) memset(a, val, sizeof(a))
#define sz(a) (int)(a).size()

typedef long long lint;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;

const int INF = 1000000000;
const lint LINF = (lint)INF * (lint)INF;
const double eps = 1e-9;

const int NMAX = 100100;

int tmp[NMAX][2];

class matrix
{
public:
	int a[NMAX][2];
	int n;
	matrix(int _n) { n = _n; _(a, 0); }
	matrix(){}
	void mul(const matrix &m)
	{
		int b[4];
		bool used[4];
		forn(i, n)
		{
			if (a[i][0] == -1 && a[i][1] == -1)
			{
				tmp[i][0] = tmp[i][1] = -1;
				continue;
			}
			if (a[i][1] == -1)
			{
				int row = a[i][1];
				tmp[i][0] = m.a[row][0];
				tmp[i][1] = m.a[row][1];
				continue;
			}
			int j = 0, r1, r2;
			r1 = a[i][0];
			r2 = a[i][1];
			b[j++] = m.a[r1][0];
			b[j++] = m.a[r1][1];
			b[j++] = m.a[r2][0];
			b[j++] = m.a[r2][1];
			tmp[i][0] = tmp[i][1] = -1;
			forn(ttt, 4) used[ttt] = false;
			j = 0;
			forn(t, 4) if (!used[t])
			{
				int t2;
				for(t2 = t + 1; t2 < 4 && b[t] != b[t2]; t2++);
				if (t2 >= 4)
				{
					if (b[t] > -1)
					{
						assert( j < 2 );
						tmp[i][j++] = b[t];
					}
				}
				else
					forn(ttt, 4)
						if (b[ttt] == b[t])
							used[ttt] = true;
			}
		}
		forn(i, n)
			forn(j, 2)
				a[i][j] = tmp[i][j];
	}
};

const int NMAX_MAT = 255;

class mat
{
public:
	int a[NMAX_MAT][NMAX_MAT];
	int n;
	mat() { _(a, 0); }

	mat operator*(const mat &m) const
	{
		mat res;

		for(int i = 0; i < n; i++)
		{
			for(int j = 0; j < n; j++)
			{
				for(int k = 0; k < n; k++)
				{
					res.a[i][j] ^= a[i][k] * m.a[k][j];
				}
			}
		}
		res.n = n;
		return res;
	}
	

	bool check()
	{
		int mx = 0;
		forn(i, n)
		{
			int c = 0;
			forn(j, n)
				c += a[i][j];
			mx = max(mx, c);
			//if (c > 2)
			//	return false;
		}
		printf("%d\n", mx);
		return true;
	}
	void print()
	{
		forn(i, n) 
		{
			forn(j, n)
				printf("%d", a[i][j]);
			printf("\n");
		}
	}
};

lint T, n;
char vec_2[NMAX];
int vec[NMAX];
matrix res, mata;

void read()
{
	scanf("%lld %d\n", &T, &n);
	gets( vec_2 );
	forn(i, n)
		vec[i] = vec_2[i] - '0';
}

void test()
{
	int m = 200;
	mat m1;
	matrix m2;
	
	int j = 0;
	_(m2.a, -1);
	_(m1.a, 0);
	m1.n = m;
	m2.n = m;

	for(int row = 1; row < m - 1; row++)
	{
		m2.a[row][0] = j;
		m2.a[row][1] = j + 2;
		m1.a[row][j] = m1.a[row][j + 2] = 1;
		j ++;
	}
	
	mat t1;
	matrix t2;
	t1 = m1;
	t2 = m2;
	for(int i = 0; i < 100; i++)
	{
		t1 = t1*t1;
		t1.check();
		//t2.mul(m2);
		
		/*for(int j = 0; j < m; j++)
		{
			if (t2.a[j][0] > -1)
			{
				int r = t2.a[j][0];
				if (t1.a[j][r] == 0)
					assert( false );
			}
			if (t2.a[j][1] > -1)
			{
				int r = t2.a[j][1];
				if (t1.a[j][r] == 0)
					assert( false );
			}
		}*/
	}
}

int new_a[NMAX];
void go(const matrix &res)
{
	forn(i, n)
	{
		int j = i + 1;
		int ans = 0;
		if (res.a[j][0] > -1)
		{
			int v = res.a[j][0];
			if (v > 0)
				ans ^= vec[v - 1];
		}
		if (res.a[j][1] > -1)
		{
			int v = res.a[j][1];
			if (v > 0)
				ans ^= vec[v - 1];
		}
		new_a[i] = ans;
	}
	forn(i, n)
		vec[i] = new_a[i];
}

void solve()
{
	int m = n + 2;
	_(res.a, -1);
	res.n = m;
	forn(i, m)
		res.a[i][0] = i;
	int j = 0;
	_(mata.a, -1);
	mata.n = m;
	for(int row = 1; row < m - 1; row++)
	{
		mata.a[row][0] = j;
		mata.a[row][1] = j + 2;
		j ++;
	}

	for(; T; T >>= 1)
	{
		if (T & 1)
			go(mata);
		mata.mul(mata);
	}

	forn(i, n)
		printf("%d", vec[i]);

}

int main()
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	read();
	solve();
	//test();

	return 0;
}