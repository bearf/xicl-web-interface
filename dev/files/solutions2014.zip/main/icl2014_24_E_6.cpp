#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <math.h>

//#define _DEBUG
#define forn(i,n) for (int i=0;i<n;i++)
using namespace std;


int main()
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	int n;
	cin>>n;
	vector <int> a(n),arr(n);
	forn(i,n){
		cin>>a[i];
		arr[i]=a[i];
	}
	sort(arr.begin(),arr.end());
	map <int, int> aa;
	int q=0;
	int l=arr[0];
	aa[l]=q;
	forn(i,arr.size())
	{
		if (arr[i]!=l)
		{
			q++;
			l=arr[i];
			aa[l]=q;
		}
	}

	vector<vector<int> > pos(q+1);
	forn(i,n)
	{
		a[i]=aa[a[i]];
		pos[a[i]].push_back(i);
	}

	int res=0,p,y;
	vector <int> len(n,0);
    for (int i=n-1;i>=0;i--)
	{
		len[i]=1;

		q=a[i];
		p=upper_bound(pos[q].begin(),pos[q].end(),i+1)-pos[q].begin();
		if (p<pos[q].size())
		{
			len[i]=max(len[i],len[pos[q][p]]+1);
		}

		if ((q+1)!=pos.size()){
			p=upper_bound(pos[q+1].begin(),pos[q+1].end(),i+1)-pos[q+1].begin();
			if (p==0)
			{
				len[i]=max(len[i],len[pos[q+1][p]]+1);
			}
			else
			if (p<pos[q+1].size())
			{
				int y=pos[q+1].size();
				len[i]=max(len[i],y-p+1);
			}
		}
		res=max(res,len[i]);
	}
	cout<<n-res;

	return 0;
}