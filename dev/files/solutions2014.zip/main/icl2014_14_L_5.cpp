#include <iostream>

using namespace std;

int main(){	
	int n, i, j, cnt=0, s=0;

	cin >> n;
	int field[14][14];

	for (i=0; i<n; i++){
		for (j=0; j<n; j++){
			field[i][j]=0;
			cin >> field[i][j];
			if (field[i][j]==0) cnt++;
			s+=field[i][j];
		}
	}

	if (cnt<(n*n-cnt)) {
		cout << s;
	} else {
		cout << "-1";
	}

	return 0;
}