#include <iostream>
#include<stdio.h>
using namespace std;
void main()
{
	int n;
	int k;
	char str[100000];

	cin >> n;
	itoa(n, str,10);

	int flag = 0;
	for(int i=0; i<10000; i++)
	{
		if(str[i]==-52)
		{
			k = i-1;
			break;
		}
	}
	if(str[0]=='1')
		flag=1;
	for(int i=1; i<10000; i++)
	{
		if(str[i+1]==-52)
		{
			break;
		}
		if(str[i]!='0')
			{
				flag = 0;
			}
	}
	if(n<10)
	{
		for(int i=1; i<=n; i++)
			printf("%d",i);
		return;
	}
	if(flag==0 && n>=10)
	{
		if(n>10)
		{
		printf("%c",str[0]);
		for(int i=1; i<=str[0]-'0'-1; i++)
		{
			printf("%d",i);
		}
		for(int i=0; i<k-1; i++)
		{
			for(int i=0; i<10; i++)
				printf("%d",i);
		}
		}
	}
	else
	{
		printf("%c",str[0]);
		for(int i=0; i<10; i++)
				if(i!=1)
					printf("%d",i);
		for(int i=1; i<k-1; i++)
		{
			for(int i=0; i<10; i++)
				printf("%d",i);
		}
	}
}