#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>
using namespace std;

const int N = (int)1e5;

struct Point
{
	double x, y;
	Point () {}
	Point (double x, double y) : x(x), y(y) {}
	Point operator + (Point a)
	{
		return Point(x + a.x, y + a.y);
	}
	Point operator - (Point a)
	{
		return Point(x - a.x, y - a.y);
	}
	Point operator * (double k)
	{
		return Point(x * k, y * k);
	}
	Point operator / (double k)
	{
		return Point(x / k, y / k);
	}
	Point ort()
	{
		return Point(-y, x); 
	}
	void scan()
	{
		scanf("%lf%lf", &x, &y);
	}
	void print()
	{
		printf("%.5lf %.5lf\n", x, y);
	}
};

struct Item
{
	double a, b, c;
	Item () {}
	Item (double a, double b, double c) : a(a), b(b), c(c) {}
	Item operator + (Item x)
	{
		return Item(a + x.a, b + x.b, c + x.c);
	}
	Item operator + (double x)
	{
		return Item(a, b, c + x);
	}
	Item operator - (Item x)
	{
		return Item(a - x.a, b - x.b, c - x.c);
	}
	Item operator * (double k)
	{
		return Item(a * k, b * k, c * k);
	}
	void print()
	{
		printf("a = %lf, b = %lf, c = %lf\n", a, b, c);
	}
};

double sqr(double a)
{
	return a * a;
}

Point lineA[N], lineB[N];
double A[N], B[N], C[N];

void getEquation(Point A, Point B, double &a, double &b, double &c)
{
	double x0 = A.x, y0 = A.y;
	double x1 = B.x, y1 = B.y;

	a = y1 - y0;
	b = -(x1 - x0);
	c = -x0 * (y1 - y0) + y0 * (x1 - x0);
}

int main()
{
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		lineA[i].scan();
		lineB[i].scan();
		getEquation(lineA[i], lineB[i], A[i], B[i], C[i]);
		double t = sqrt(sqr(A[i]) + sqr(B[i]));
		A[i] /= t;
		B[i] /= t;
		C[i] /= t;
//		cout << A[i] << ":" << B[i] << ":" << C[i] << endl;
	}

	Item x = Item(1, 0, 0);
	Item y = Item(0, 1, 0);
	for (int i = 1; i <= n; i++)
	{
		int ind = (i == n ? 0 : i);
//		cout << A[ind] << ":" << B[ind] << endl;
		Item zx = x;
		Item zy = y;
		x = zx - (zx * A[ind] + zy * B[ind] + C[ind]) * A[ind];
		y = zy - (zx * A[ind] + zy * B[ind] + C[ind]) * B[ind];
//		x.print();
//		y.print();
//		puts("-------------");
	}

	double A0 = x.a - 1;
	double B0 = x.b;
	double C0 = x.c;

	double A1 = y.a;
	double B1 = y.b - 1;
	double C1 = y.c;

	double yAns = (C0 * A1 - C1 * A0) / (A0 * B1 - A1 * B0);
	double xAns = (B0 * C1 - B1 * C0) / (A0 * B1 - A1 * B0);
	cout << xAns << " " << yAns;

	return 0;
}