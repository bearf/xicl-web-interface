#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cassert>
#include <ctime>
#include <memory.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <complex>
#include <list>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef complex <ld> point;

#define pb push_back
#define mp make_pair
#define fi first
#define se second

#define INF 1000000001
#define MOD 1000000009
#define INFL 1000000000000000001ll
#define NAME "b"

int d[22][1000002];
int pr[22][1000002];

int main() {
    #ifdef _GEANY
    assert(freopen(NAME ".in", "r", stdin));
    #endif // _GEANY
    int n, k;
    cin >> n >> k;
    for (int i = 1; i <= n; ++i)
        d[1][i] = 1;
    for (int j = 0; j <= n; ++j) {
        pr[1][j + 1] = (pr[1][j] + d[1][j]);
        if (pr[1][j + 1] >= MOD)
            pr[1][j + 1] -= MOD;
    }
    for (int i = 2; i <= k; ++i) {
        for (int j = 0; j <= n; ++j)
            d[i][j] = pr[i - 1][j / 2 + 1];
        for (int j = 0; j <= n; ++j) {
            pr[i][j + 1] = (pr[i][j] + d[i][j]);
            if (pr[i][j + 1] >= MOD)
                pr[i][j + 1] -= MOD;
        }
    }
    cout << d[k][n] << endl;
}
