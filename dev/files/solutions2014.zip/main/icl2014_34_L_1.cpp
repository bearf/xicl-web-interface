#include<iostream>
#include<algorithm>
using namespace std;

int main()
{
	//freopen("input.txt", "r", stdin);	freopen("output.txt", "w", stdout);

	int n;
	cin >> n;
	int sum = 0, emp = 0;
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
		{
			int x;
			cin >> x;
			sum += x;
			emp += (x == 0);
		}

	int figs = n * n - emp;
	if (figs >= emp)
		cout << sum;
	else
		cout << -1;
}