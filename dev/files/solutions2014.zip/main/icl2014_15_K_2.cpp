#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <valarray>
using namespace std;

bool doubleEqual (double val1, double val2)
{
	return fabs(val1 - val2) < 1e-7;
}
bool doubleLess (double val1, double val2)
{
	return val1 < val2 && !doubleEqual(val1, val2);
}
bool doubleGreater (double val1, double val2)
{
	return val1 > val2 && !doubleEqual(val1, val2);
}

double mySqrt (double val)
{
	if (doubleLess(val, 0) )
		throw 42;
	if (val < 0)
		return 0;
	return sqrt(val);
}

struct Point
{
	double x, y;

	Point () : x(0), y(0) {}
	Point (double x, double y) : x(x), y(y) {}

	bool operator == (Point P)
	{
		return doubleEqual(x, P.x) && doubleEqual(y, P.y);
	}
	bool operator != (Point P)
	{
		return !(*this == P);
	}
	Point operator + (Point P)
	{
		return Point(x + P.x, y + P.y);
	}
	Point operator - (Point P)
	{
		return Point(x - P.x, y - P.y);
	}
	Point operator * (double c)
	{
		return Point(x * c, y * c);
	}
	double operator % (Point P)
	{
		return x * P.x + y * P.y;
	}
	double operator * (Point P)
	{
		return x * P.y - y * P.x;
	}
	double length ()
	{
		return mySqrt(*this % *this);
	}
	double length2 ()
	{
		return *this % *this;
	}
	Point normalize (double newLen)
	{
		double oldLen = length();
		if (doubleEqual(oldLen, 0) )
			throw 42;
		return *this * (newLen / oldLen);
	}
	Point rotate90 ()
	{
		return Point(-y, x);
	}

	void scan ()
	{
		scanf("%lf%lf", &x, &y);
	}
};

struct Koef
{
	double x, y, c;

	Koef () : x(x), y(y), c(c) {}
	Koef (double x, double y, double c) : x(x), y(y), c(c) {}

	Koef operator + (Koef K)
	{
		return Koef(x + K.x, y + K.y, c + K.c);
	}
	Koef operator - (Koef K)
	{
		return Koef(x - K.x, y - K.y, c - K.c);
	}
	Koef operator * (double mult)
	{
		return Koef(x * mult, y * mult, c * mult);
	}
	Koef operator / (double mult)
	{
		if (doubleEqual(mult, 0) )
			throw 42;
		return Koef(x / mult, y / mult, c / mult);
	}
};

valarray < double > g[3];
Point P[10005], Q[10005];
int n;

void transform (Koef & Kx, Koef & Ky, Point P, Point Q)
{
	Kx.c -= P.x;
	Ky.c -= P.y;

	Point vNorm = (Q - P).rotate90();
	double A = vNorm.x, B = vNorm.y;
	double len2 = vNorm.length2();

	Koef V = Kx * A + Ky * B;
	V = V / len2;

	Kx = Kx - V * A;
	Ky = Ky - V * B;

	Kx.c += P.x;
	Ky.c += P.y;
}

bool gauss (valarray < double > * g, int n, int m, Point & ans)
{
	/*for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			printf("%lf ", g[i][j] );
		}

		printf("\n");
	}
	printf("\n");*/

	int r = 0, c = 0;
	for ( ; c < n; c++)
	{
		double maxVal = 0;
		int rMax = -1;
		for (int rCur = r; rCur < m; rCur++)
		{
			if (doubleGreater(fabs(g[rCur][c] ), maxVal) )
			{
				maxVal = fabs(g[rCur][c] );
				rMax = rCur;
			}
		}

		if (rMax == -1)
			continue;

		g[r].swap(g[rMax] );
		double temp = g[r][c];
		g[r] /= temp;

		for (int i = 0; i < m; i++)
		{
			if (i == r)
				continue;

			double val = g[i][c];
			g[i] -= g[r] * val;
		}

		r++;
	}

	if (r != 1 && r != 2)
		throw 42;

	/*for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			printf("%lf ", g[i][j] );
		}

		printf("\n");
	}
	printf("\n");*/

	for (int i = r; i < m; i++)
		if (!doubleEqual(g[i][n], 0) )
			return false;

	if (r == 1)
	{
		if (doubleEqual(g[0][0], 0) )
			ans = Point(0, g[0][n] );
		else if (doubleEqual(g[0][1], 0) )
			ans = Point(g[0][n], 0);
		else
			ans = Point(1, (g[0][n] - 1) / (g[0][1] * 1.) );
	}else
	{
		ans = Point(g[0][n], g[1][n] );
	}

	return true;
}

int main ()
{
	//freopen("input.txt", "rt", stdin);
	//freopen("output.txt", "wt", stdout);

	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		P[i].scan();
		Q[i].scan();
	}

	P[n] = P[0]; Q[n] = Q[0];

	Koef Kx = Koef(1, 0, 0);
	Koef Ky = Koef(0, 1, 0);
	/*printf("%lf %lf %lf\n", Kx.x, Kx.y, Kx.c);
	printf("%lf %lf %lf\n", Ky.x, Ky.y, Ky.c);
	printf("\n");*/
	for (int i = 1; i <= n; i++)
	{
		transform(Kx, Ky, P[i], Q[i] );
		/*printf("%lf %lf %lf\n", Kx.x, Kx.y, Kx.c);
		printf("%lf %lf %lf\n", Ky.x, Ky.y, Ky.c);
		printf("\n");*/
	}

	for (int i = 0; i < 3; i++)
		g[i].resize(3, 0);
	g[0][0] = Kx.x - 1; g[0][1] = Kx.y;     g[0][2] = -Kx.c;
	g[1][0] = Ky.x;     g[1][1] = Ky.y - 1; g[1][2] = -Ky.c;
	Point vNorm = (P[0] - Q[0] ).rotate90();
	double A = vNorm.x, B = vNorm.y;
	double C = - P[0].x * A - P[0].y * B;
	g[2][0] = A; g[2][1] = B; g[2][2] = -C;

	Point ans;
	if (!gauss(g, 2, 3, ans) )
		printf("-1");
	else
		printf("%.12lf %.12lf", ans.x, ans.y);

	return 0;
}