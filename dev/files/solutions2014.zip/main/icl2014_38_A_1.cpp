#include<stdio.h>
//#include<iostream>
#include<algorithm>
#include<cstring>
#include<vector>
#define pb push_back
#define mp make_pair

using namespace std;

int n, p;
vector<pair<int, int> > ans;
vector<vector<pair<int, int> > > aa;
vector<int> v[333333];
int mintot = 1e9;
vector<vector<int> > ret;

void rec(int p, int sum, int tot) {
//	printf("%d %d %d\n", p, sum, tot);
	if (p == 1) {
		if (sum != n) return;
		if (tot > mintot) return;
		if (tot < mintot) {
			mintot = tot;
			aa.clear();
		}
		aa.pb(ans);
		return;
	}
	for (int i = 1; i < v[p].size(); i++) {
		int kol = v[p][i] / 2;
		int ss = sum + kol * (sum + sum + 1);
		if (ss > n) break;
		ans.pb(mp(kol, sum + sum + 1));
		rec(p / v[p][i], ss, tot + kol);
		ans.pop_back();
	}
}

int main() {
//	freopen("1.in", "r", stdin);
//	freopen("1.out", "w", stdout);
	scanf("%d", &n);
	p = n + n + 1;
	for (int i = 1; i <= p; i++) for (int j = 1; j * j <= i; j++) if (i % j == 0) {
		v[i].pb(j);
		if (j * j != i) v[i].pb(i / j);
	}
	rec(p, 0, 0);
	printf("%d %d\n", aa.size(), mintot);
	
	for (int i = 0; i < aa.size(); i++) {
		ret.pb(vector<int>(0));
		for (int j = 0; j < aa[i].size(); j++) {
//			printf("%d %d ", aa[i][j].first, aa[i][j].second);
//			for (int k = 0; k < aa[i][j].first; k++) printf("%d ", aa[i][j].second);
			for (int k = 0; k < aa[i][j].first; k++) ret[i].pb(aa[i][j].second);
		}
//		puts("");
	}
	sort(ret.begin(), ret.end());
	for (int i = 0; i < ret.size(); i++) {
		for (int j = 0; j < ret[i].size(); j++) printf("%d ", ret[i][j]);
		puts("");
	}
	return 0;
}