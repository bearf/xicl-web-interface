#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include <iostream>
#include <algorithm>

using namespace std;

#pragma comment(linker, "/STACK:65536000")
#define M 1000100
#define K 20

int n,ans[M*K],m=0,p[K],a[M];
bool u[M][K];

void build(void){
	p[0]=1;

	for (int i=1; i<K; ++i)
		p[i]=2*p[i-1];
}

void dfs(int v){
	for (int i=a[v]; i<n; ++i)
		if (!u[v][i]){
			u[v][i]=1;
			a[v]++;
			dfs(v^p[i]);
			ans[m++]=i+1;
		}
}


int main(){
	
	scanf("%d",&n);
	build();
	dfs(0);
	cout<<m<<"\n";
	for (int i=0; i<m; ++i)
		printf("%d ",ans[i]);
	return 0;
}