#include <iostream>
#include <algorithm>
using namespace std;

const double EPS = 1e-7;

bool eq(double a, double b)
{
	return fabs(a - b) < EPS;
}

bool ls(double a, double b)
{
	return a < b && !eq(a, b);
}

bool ls_eq(double a, double b)
{
	return a < b || eq(a, b);
}

bool gr(double a, double b)
{
	return a > b && !eq(a, b);
}

bool gr_eq(double a, double b)
{
	return a > b || eq(a, b);
}

double my_sqrt(double a)
{
	if (ls(a, 0))
		throw;
	if (a < 0)
		a = 0;
	return sqrt(a);
}

struct Point
{
	double x, y;

	Point(): x(0), y(0) {}

	Point(double x, double y): x(x), y(y) {}

	void scan()
	{
		scanf("%lf%lf", &x, &y);
	}

	Point operator + (Point p)
	{
		return Point(x + p.x, y + p.y);
	}

	Point operator - (Point p)
	{
		return Point(x - p.x, y - p.y);
	}

	Point operator * (double k)
	{
		return Point(x * k, y * k);
	}

	Point operator / (double k)
	{
		return Point(x / k, y / k);
	}

	double operator % (Point p)
	{
		return x * p.x + y * p.y;
	}

	double operator * (Point p)
	{
		return x * p.y - y * p.x;
	}

	double length()
	{
		return my_sqrt(*this % *this);
	}

	double length2()
	{
		return *this % *this;
	}

	double dist_to(Point p)
	{
		return (*this - p).length();
	}

	Point height(Point A, Point B)
	{
		Point C = *this;
		double len = (B - A) % (C - A) / (B - A).length2();
		return A + (B - A) * len;
	}

	void print()
	{
		printf("%.10lf %.10lf\n", x, y);
	}

	Point set_length(double k)
	{
		double len = length();
		if (eq(len, 0))
		{
			if (eq(k, 0))
				return Point();
			//throw;
		}
		return *this / len * k;
	}

	Point rotate()
	{
		return Point(-y, x);
	}

	Point operator - ()
	{
		return Point(-x, -y);
	}

	bool operator == (Point p)
	{
		return eq(x, p.x) && eq(y, p.y);
	}

	double get_angle(Point p)
	{
		return atan2(*this * p, *this % p);
	}
};

const int MAXN = 10500;

int n;
Point A[MAXN], B[MAXN];

Point project(Point P)
{
	/*for (int i = 0; i < n - 1; i++)
	{
		if (!eq((A[i] - B[i]) * (A[i + 1] - B[i]), 0))
		{
			Point X = A[i];
			Point H = X.height(A[i + 1], B[i + 1]);
			Point M;
			if (!get_intersection(A[i], B[i], A[i + 1], B[i + 1], M))
				throw;
			if (eq(H.dist_to(M), 0))
			{
				Point X = B[i];
				Point H = X.height(A[i + 1], B[i + 1]);
			}

			double angle = (X - 
		}
	}*/

	for (int i = 1; i < n; i++)
		P = P.height(A[i], B[i]);
	P = P.height(A[0], B[0]);
	return P;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		A[i].scan();
		B[i].scan();
	}

	Point C = project(A[0]);
	Point D = project(B[0]);
	Point v = B[0] - A[0];
	Point u = D - C;

	if (eq(u.length(), 0) && eq(v.length(), 0))
	{
		if (A[0] == C)
			A[0].print();
		else
			puts("-1");
		return 0;
	}

	if (u == v)
		A[0].print();
	else
	{
		double t = (B[0] - A[0]).length() / (v - u).length();
		Point res = A[0] + v.set_length(t);
		res.print();
	}

	return 0;
}