#include <iostream>
#include<stdio.h>
using namespace std;
void main()
{
	int n=1;
	int k=1;

	cin >> n;
	cin >> k;


	k--;
	int ind[21]={0};
	
	int kol=0;
	bool b = true;
	while(ind[k+1]==0)
	{
		int sum=1+ind[k];
		for(int j=0;j<k;j++)
		{
			sum=2*sum+ind[k-j-1];
		}


		if(sum<=n)
		{

			if(b)
			kol++;
			b=false;
			ind[0]++;
		}
		else
		{
			int l=0;
			while(ind[l]==0&&l<k)
			{
				l++;
			}
			for(int i=0;i<l+1;i++)
				ind[i]=0;
			ind[l+1]++;
			b=true;
		}
	}

	cout << kol;
}