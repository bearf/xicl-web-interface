#include<stdio.h>
//#include<iostream>
#include<algorithm>
#include<cstring>

using namespace std;

int main() {
//	freopen("1.in", "r", stdin);
//	freopen("1.out", "w", stdout);
	int n;
	scanf("%d", &n);
	long long sum = 0;
	int kol = 0;
	for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) {
		int x;
		scanf("%d", &x);
		if (x > 0) {
			sum += x;
			kol++;
		}
	}
	if (kol + kol >= n * 1ll * n) {
		printf("%d\n", (int) sum);
	} else puts("-1");
	return 0;
}