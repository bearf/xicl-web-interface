#include <iostream>
#include <vector>
#define fin cin
#define fout cout

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

const int nmax = 110000;
const int logmax = 20;

vector<int> gr[nmax];
vector<int> ans;
int jump[nmax][logmax];
int p[nmax];
int pl[nmax];
int h[nmax];
int pred[nmax];
bool razdv[nmax];
bool busy[nmax];
bool next[nmax];
int n, m, kol_edge, first;


void readdata()
{
    fin >> n;
    for (int i = 0; i < n - 1; i++)
    {
        int b, e;
        fin >> b >> e;
        b--;
        e--;
        gr[b].push_back(e);
        gr[e].push_back(b);
    }
    fin >> m;
    for (int i = 0; i < m; i++)
    {
        fin >> pl[i];
        pl[i]--;
    }
}


void init()
{
    pred[0] = -1;
    h[0] = 0;
    kol_edge = -1;
    first = -1;
    for (int i = 0; i < n; i++)
    {
        razdv[i] = false;
        busy[i] = false;
    }
}


void dfs(int v)
{
    for (int i = 0; i < gr[v].size(); i++)
    {
        int to = gr[v][i];
        if (to != pred[v])
        {
            pred[to] = v;
            h[to] = h[v] + 1;
            dfs(to);
        }
    }
}


void count_jump()
{
    for (int i = 0; i < 20;  i++)
        for (int j = 0; j < n; j++)
            if (i == 0)
                jump[j][i] = pred[j];
            else
            {
                if (jump[j][i - 1] == -1)
                    jump[j][i] = -1;
                else
                    jump[j][i] = jump[jump[j][i - 1]][i - 1];
            }
}


int find_razdv(int v)
{
    int cur = v;
    while ((cur >= 0) && !razdv[cur])
    {
        int jj = 0;
        for (int j = 18; j >= 0; j--)
        {
            int nw = jump[cur][j];
            if ((nw >= 0) && (!razdv[nw]))
            {
                jj = j;
                break;
            }
        }
        cur = jump[cur][jj];
    }
    return cur;
}


void solve()
{
    for (int i = 0; i < m; i++)
    {
        int cur = pl[i];
        int v = cur;
        int kol1 = 0;
        int up;
        while ((v >= 0) && (!busy[v]))
        {
            busy[v] = true;
            kol_edge++;
            kol1++;
            v = pred[v];
            //fout << v << endl;
        }
        //fout << cur << " kol_edge = " << kol_edge << " h[cur] = " << h[cur] <<  " up= " << up << " h[up]= " << h[up] << " first= " << first << " h[first] = " << h[first] << endl;
        //fout << "i " << i << endl;
        ans.push_back(kol_edge * 2 - h[cur]);
    }
}


void write_answer()
{
    for (int i = 0; i < m; i++)
        fout << ans[i] << ' ';
    fout << endl;
}


int main()
{
    readdata();
    init();
    dfs(0);
    count_jump();
    solve();
    write_answer();
    return 0;
}
