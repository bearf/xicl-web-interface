#ifdef SU2_PROJ
//#define _GLIBCXX_DEBUG
#endif

#include <algorithm>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <string>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define forn(i, n) for (int i = 0; i < int(n); i++)
#define forl(i, n) for (int i = 1; i <= int(n); i++)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; i--)
#define fore(i, l, r) for (int i = int(l); i <= int(r); i++)
#define correct(x, y, n, m) (0 <= (x) && (x) < (n) && 0 <= (y) && (y) < (m))
#define pb(a) push_back(a)
#define all(a) (a).begin(), (a).end()
#define mp(x, y) make_pair((x), (y))
#define sz(a) int((a).size())
#define ft first
#define sc second
#define x first
#define y second

using namespace std;

typedef long long li;
typedef long double ld;
typedef pair <int, int> pt;

inline ostream& operator << (ostream& out, const pt& p) { return out << "(" << p.x << ", " << p.y << ")"; }

const int INF = int(1e9);
const li INF64 = li(1e18);
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

#ifdef SU2_PROJ
const int M = 1000 * 100 + 13;
#else
const int M = 1000 * 1000 + 13;
#endif
const int N = 100 * 1000 + 13;
const int K = 100 + 3;

int n, ans = K - 3;
int can[K][N];
int szcan[K];
int used[N], u;
vector <int> res[M];
int szres;
int result[K];

int CNT = 300 * 1000 * 1000;

void go (int idx, int last, int sum)
{
	if (sum > n) return;
	if (idx > ans) return;
	
	if (szcan[idx] == n + 1 && sum == n)
	{
		if (idx < ans) szres = 0, ans = idx;
		res[szres].clear();
		forn(i, idx) res[szres].pb(result[i]);
		szres++;
		return;
	}
	
	if (last > n - sum) return;
	
	go(idx, last + 1, sum);
	
	//cerr << idx << ' ' << last << ' ' << sum << endl;
	
	for (int cnt = 1; cnt <= ans - idx && sum + last * cnt <= n; cnt++)
	{
		u++;
		bool ok = true;
		
		fore(taken, -cnt, cnt)
		{
    		forn(i, szcan[idx])
    		{
    			if (can[idx][i] == 0 && taken < 0) continue;
    			
	if (--CNT < 0)
	{
		cout << "1 " << n << endl;
		forn(i, n) printf("1 ");
		puts("");
		exit(0);
	}
	
				int val = abs(can[idx][i] + last * taken);
				if (val > n) continue;
				if (val <= n && used[val] == u)
				{
					ok = false;
					goto done;
				}
				used[val] = u;
				can[idx + cnt][szcan[idx + cnt]++] = val;
    		}
    	}
    	
    	//cerr << "st = " << ok << ' ' << cnt << ' ' << last << endl;
    	
    	done:;
    	
    	if (!ok)
    	{
    		szcan[idx + cnt] = 0;
    		break;
    	}
		
    	forn(i, cnt) result[idx + i] = last;
		go(idx + cnt, last + 1, sum + last * cnt);
		szcan[idx + cnt] = 0;
	}
}

inline bool read ()
{
	return cin >> n;
}

inline void solve ()
{
	can[0][szcan[0]++] = 0;
	go(0, 1, 0);
	
	if (ans > INF / 2)
	{
		ans = n;
		szres = 1;
		forn(i, n) res[0].pb(1);
	}
	
	cout << szres << ' ' << ans << endl;
	
	sort(res, res + szres);
	
	forn(i, szres)
	{
		forn(j, sz(res[i])) printf("%d ", res[i][j]);
		puts("");
	}
}

int main()
{
#ifdef SU2_PROJ
	freopen("input.txt", "rt", stdin);
	//freopen("output.txt", "wt", stdout);
#endif

	cout << setprecision(10) << fixed;
	cerr << setprecision(5) << fixed;
	
	assert(read());
	solve();
	
#ifdef SU2_PROJ
	cerr << "=== Time: " << clock() << " ===" << endl;
#endif

	return 0;
}
