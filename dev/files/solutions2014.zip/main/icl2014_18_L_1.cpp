#include <cstdio>
#include <cstdlib>
#include <iostream>
#define ll long long
using namespace std;

int a[14][14];

int main() {
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);

	int n;
	cin >> n;
	ll z = 0, ans = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cin >> a[i][j];
			if (a[i][j] == 0) {
				z++;
			} else if (a[i][j] == 1) {
				ans++;
			} else if (a[i][j] == 2) {
				ans += 2;
			} else if (a[i][j] == 3) {
				ans += 3;
			} else {
				ans += 4;
			}
		}
	}
	if (z > n*n-z) {
		cout << -1;
	} else {
		cout << ans;
	}
}