#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
//ifstream cin ("input.txt");
//ofstream cout ("output.txt");



long long n, k;


int main(){
	cin >> n >> k;
	cout << n / k;
}