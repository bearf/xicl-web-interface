#pragma comment(linker, "/STACK:64000000")

#include<iostream>
#include<cstdio>
#include<sstream>

#include<algorithm>
#include<vector>
#include<set>
#include<bitset>
#include<map>
#include<queue>
#include<deque>
#include<stack>

#include<string>
#include<memory.h>
#include<cassert>
#include<time.h>

using namespace std;

#define forn(i, n) for(int i = 0; i < (int)n; i++)
#define forab(i, a, b) for(int i = (int)a; i <= (int)b; i++)
#define fornd(i, n) for(int i = 0; i < (int)n; i--)
#define forabd(i, b, a) for(int i = (int)b; i >= (int)a; i--)
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define _(a, val) memset(a, val, sizeof(a))
#define sz(a) (int)(a).size()

typedef long long lint;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;

const int INF = 1000000000;
const lint LINF = (lint)INF * (lint)INF;
const double eps = 1e-9;

const int nmax = 2 * 100005 + 16;

pii a[nmax];
int n;

void read()
{
	scanf("%d",&n);
	for (int i = 0; i < n; i ++)
	{
		scanf("%d",&a[i].first);
		a[i].second = i;
	}
}

int nxt[nmax], bound[nmax];

int calc(int l, int r, int cnt)
{
	int lx = a[l].second, rx = a[l + cnt - 1].second;
	if (r == n)
		return cnt;
	if (a[r].second < rx)
		return cnt;
	int ret = cnt + (nxt[r] - r);
	if (nxt[r] == n)
		return ret;
	rx = a[nxt[r] - 1].second;
	int lb = nxt[r], rb = bound[nxt[r]] - 1;
	if (a[rb].second < rx)
		return ret;
	while (rb - lb > 1)
	{
		int mid = (lb + rb) >> 1;
		if (a[mid].second > rx)
			rb = mid;
		else
			lb = mid;
	}
	return bound[nxt[r]] - rb + ret;
}

vector < pii > segm;

void solve()
{
	sort(a, a + n);
	int ans = n;
	for (int l = 0, r = 0; l < n; l = r)
	{
		for (r = l + 1; r < n && a[r].second == a[r - 1].second; r ++);
		bound[l] = r;
		segm.pb(mp(l,r));
		ans = min(ans, n - (r - l));
	}
	for (int l = 0, r = 0; l < sz(segm); l = r)
	{
		for (r = l + 1; r < sz(segm) && a[segm[r - 1].second - 1].second < a[segm[r].first].second; r ++);
		for (int i = l; i < r; i ++)
			nxt[segm[i].first] = segm[r - 1].second;
	}
	
	nxt[n] = n;
	bound[n] = n;

	for (int i = 0; i < sz(segm); i ++)
	{
		int l = segm[i].first, r = segm[i].second;
		for (int i = l; i < r; i ++)
		{
			int cur = calc(l, r, i - l + 1);
			ans = min(ans, n - cur);
		}
	}

	printf("%d\n", ans);
}

int main()
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	read();
	solve();

	return 0;
}