#include <iostream>
#include<stdio.h>
using namespace std;
void main()
{
	int n;
	int k;
	char str[100000];

	cin >> n;
	itoa(n, str,10);


	for(int i=0; i<10000; i++)
		if(str[i]==-52)
		{
			k = i-1;
			break;
		}
	if(n<10)
		for(int i=1; i<=n; i++)
			printf("%d",i);
	if(n==10)
		printf("1023456789");
	if(n>10)
	{
		printf("%c",str[0]);
		for(int i=1; i<=str[0]-'0'-1; i++)
		{
			printf("%d",i);
		}
		for(int i=0; i<k-1; i++)
		{
			for(int i=0; i<10; i++)
				printf("%d",i);
		}
	}
}