#define MAXL 10000
#define INF 1E+9
#define EPS 1E-9 
#define PROB "a"

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <string>
#include <cstring>
#include <cmath>

using namespace std;

long long n;
vector <int> ans;

int main(){
	
	long long n;
	bool f = 1;

	cin >> n;

	vector <int> a, ans;

	while (n!=0){
		a.push_back(n%2);
		n/=2;
	}

	ans = a;

	ans.push_back(0);

	while (f){
		
		int i = 0, len = 0;

		for (int i = 0; i < ans.size()-1; ++i){
			
			if (ans[i] == 1 && ans[i+1]==-1)
				ans[i] = -1, ans[i+1] = 0;
			else if (ans[i] == -1 && ans[i + 1] == 1)
				ans[i] = 1, ans[i + 1] = 0;

			while (i < ans.size() && ans[i] == 1)
				++i, ++len;

			if (len > 1)
				ans[i] = 1, ans[i-len] = -1;

			for (int x = i-len+1; x < i; ++x)
				ans[x] = 0;
			len = 0;
		}

		f = false;

		for (int i = 0; i < ans.size()-1; ++i)
			if (ans[i]*ans[i+1])
				f = true;

	}
	
	for (int i = ans.size()-1; i > -1; --i)
		printf("%d ", ans[i]);

	return 0;
}





/*

	cin >> n;

	ans.push_back (n % 2);	
	for (int i = 1; i < 64; ++i) {
		if ((n & (1 << i)) > 0) 
			++ans[i];
		if (ans [i] == 2) {
			ans[i] = 0;
			ans[i+1] = 1
		}else if (ans[i] == 1 && ans[i-1] == 1){
			
		}
	}
	
	*/