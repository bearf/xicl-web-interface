#include<stdio.h>
#include<iostream>
#include<math.h>
using namespace std;
long long log2(long long n)
{
	int k=0;
	while(n>0)
	{
		k++;
		n=n/2;
	}
	return k;
}
long long pow2(long long n)
{
	long long res=1;
	for(int i=0;i<n;i++)
		res*=2;
	return res;
}

int main()
{
	long long n;
	cin>>n;
	int a[70]={0};
	int i=0;
	int r=0;
	while(n>0)
	{
		a[i]=n%2;
		n/=2;
		i++;
		r++;
	}
	
	for(int i=1;i<r;i++)
	{
		if((a[i]==1)&&(a[i-1]==1))
		{
			a[i]=0;
			a[i-1]=-1;
			a[i+1]+=1;
			int k=i+1;
			while(a[k++]==2){
				a[k]+=1;
				a[k-1]=0;
			}
		}			
	}
	int fl=0;
	for(int i=69;i>=0;i--)
	{
		if(a[i]==1)
			fl=1;
		if(fl==1)
			cout<<a[i]<<" ";
	}
	return 0;
}