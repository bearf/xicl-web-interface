#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <algorithm>
#define ll long long
using namespace std;

const ll md = 1000 * 1000 * 1000 + 9;
ll n, k;
ll ans = 0;

ll bin_pow(ll a, ll n) {
	if (n == 0) {
		return 1;
	}
	if (n % 2) {
		return bin_pow(a, n-1) * a;
	} else {
		ll b = bin_pow(a, n/2);
		return b*b;
	}
}

void solve(ll sum, ll st) {
	if (st == k && sum == n) {
		ans++;
	}
	if (st >= k) {
		return;
	}
	for (ll i = sum; i <= n - sum; i++) {
		solve(sum + i,  st+1);
	}
}

int main() {
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);

	cin >> n >> k;
	if (k >= 2) {
		if (n / 2 >= bin_pow(2, k-2)) {
			solve(1, 1);
			cout << ans % md;
		} else {
			cout << 0;
		}
	}
	if (k == 1) {
		cout << 1;
	}
}