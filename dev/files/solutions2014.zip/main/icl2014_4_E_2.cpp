#undef NDEBUG
#ifdef ssu1
#define _GLIBCXX_DEBUG
#endif

#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define fore(i, l, r) for(int i = (l); i < (r); ++i)
#define forn(i, n) fore(i, 0, n)
#define fori(i, l, r) fore(i, l, (r) + 1)
#define X first
#define Y second
#define sz(v) ((int)(v).size())
#define pb push_back
#define mp make_pair
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acosl(-1.0);

const int N = 500500;

int n;
int a[N];
pt p[N];

map<int, vector<int> > m;

int main(){
    #ifdef ssu1
    assert(freopen("__input.txt", "r", stdin));
    #endif

    cin >> n;
    
    forn(i, n){
        scanf("%d", &a[i]);
        p[i].X = a[i];
        p[i].Y = i;
        
        m[a[i]].pb(i);
    }    
    
    sort(p, p + n);
    
    int ans = 0;
    
    for(int i = 0; i < n; ){
        int j = i + 1;
        while(j < n && p[j - 1].Y < p[j].Y)
            j++;

        int ln = j - i;
        int mn = p[i].Y;
        int mx = p[j - 1].Y;
            
        if(i > 0){
            const vector<int>& ps = m[p[i - 1].X];
            ln += upper_bound(all(ps), mn) - ps.begin();            
        }    
        if(j < n){
            const vector<int>& ps = m[p[j].X];
            ln += sz(ps) - (upper_bound(all(ps), mx) - ps.begin());
        }

        ans = max(ans, ln);
        
        i = j;    
    }    
    
    
    printf("%d\n", n - ans);
    return 0;
}






