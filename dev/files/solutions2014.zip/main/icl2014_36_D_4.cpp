#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main(){
	string A;
	cin>>A;
	vector<int> a;
	a.resize(10);
	for(int i=0;i<10;i++){
		a[i]=A.length()-1;
	}
	int b;
	b=A[0]-'0';
	for(int i=1;i<b;i++){
		if(b==1){
			break;
		}
		a[i]++;
	}
	int sum=0;
	for(int i=0;i<A.length();i++){
		if(A[i]-'0'==b){
			sum++;
		} else {
			break;
		}
	}
	if(sum>a[b]){
		a[b]=sum;
	}
	a[1]--;
	if(A[0]=='2'){
		cout<<2;
		a[2]--;
	} else if(A[0]=='3'){
		cout<<23;
		a[2]--;
		a[3]--;
	} else if(A[0]=='4'){
		cout<<234;
		a[2]--;
		a[3]--;
		a[4]--;
	} else if(A[0]=='5'){
		cout<<2345;
		a[2]--;
		a[3]--;
		a[4]--;
		a[5]--;
	} else if(A[0]=='6'){
		cout<<23456;
		a[2]--;
		a[3]--;
		a[4]--;
		a[5]--;
		a[6]--;
	} else if(A[0]=='7'){
		cout<<234567;
		a[2]--;
		a[3]--;
		a[4]--;
		a[5]--;
		a[6]--;
		a[7]--;
	} else if(A[0]=='8'){
		cout<<2345678;
		a[2]--;
		a[3]--;
		a[4]--;
		a[5]--;
		a[6]--;
		a[7]--;
		a[8]--;
	} else if(A[0]=='9'){
		cout<<23456789;
		a[2]--;
		a[3]--;
		a[4]--;
		a[5]--;
		a[6]--;
		a[7]--;
		a[8]--;
		a[9]--;
	}
	cout<<1;
	for(int i=0;i<a[0];i++){
		cout<<0;
	}
	for(int i=0;i<a[1];i++){
		cout<<1;
	}
	for(int i=0;i<a[2];i++){
		cout<<2;
	}
	for(int i=0;i<a[3];i++){
		cout<<3;
	}
	for(int i=0;i<a[4];i++){
		cout<<4;
	}
	for(int i=0;i<a[5];i++){
		cout<<5;
	}
	for(int i=0;i<a[6];i++){
		cout<<6;
	}
	for(int i=0;i<a[7];i++){
		cout<<7;
	}
	for(int i=0;i<a[8];i++){
		cout<<8;
	}
	for(int i=0;i<a[9];i++){
		cout<<9;
	}

	return 0;
}