#include <iostream>
#include <vector>
using namespace std;

int x;
int dp[100100][2];
vector<int> a[100100];
int ans[1000][1000];
int it;

void solve (int x)
{
	if (dp[x][0] != -1)
		return;
	if (x == 0)
	{
		dp[x][0] = 0;
		dp[x][1] = 1;
		return;
	}
	for (int i = 1; i <= x; i++)
	{
		if ((x - i) % (2 * i + 1) != 0)
			continue;
		int y = (x - i) / (2 * i + 1);
		solve(y);
		if (dp[x][0] == -1 || i + dp[y][0] < dp[x][0])
		{
			dp[x][0] = dp[y][0] + i;
			dp[x][1] = dp[y][1];
			a[x].clear();
			a[x].push_back(i);
		}
		else if (i + dp[y][0] == dp[x][0])
		{
			dp[x][1] += dp[y][1];
			a[x].push_back(i);
		}
	}
	return;
}

void print (int x, int mul)
{
	if (x == 0)
	{
		it++;
		return;
	}
	for (int i = a[x].size() - 1; i >= 0; i--)
	{
		int sz = dp[ (x - a[x][i]) / (2 * a[x][i] + 1) ][1];
		for (int j = it; j < it + sz; j++)
		{
			for (int k = 0; k < a[x][i]; k++)
			{
				ans[j][0]++;
				ans[j][ ans[j][0] ] = mul;
			}
		}
		print((x - a[x][i]) / (2 * a[x][i] + 1), mul * (2 * a[x][i] + 1));
	}
	return;
}

int main()
{
	scanf("%d", &x);
	for (int i = 0; i <= x; i++)
		dp[i][0] = -1;
	solve(x);
	printf("%d %d\n", dp[x][1], dp[x][0]);
	
	it = 0;
	print(x, 1);
	for (int i = 0; i < dp[x][1]; i++)
	{
		for (int j = 1; j <= dp[x][0]; j++)
			printf("%d ", ans[i][j]);
		printf("\n");
	}
//	cin >> x;
	return 0;
}