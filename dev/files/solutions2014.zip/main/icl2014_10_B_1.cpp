#include <iostream>
#include <vector>

using namespace std;


int main ()
{
    int n,k;
    cin >> n >> k;
    vector < vector<int> > c (n+1, vector<int> (k+1, -1));

    for (int i = 1 ; i <= k ; i++)
    {
        c[1][i] = 0;
    }
    for (int i = 1 ; i <= n ; i++)
    {
        c[i][1] = 1;
    }
    for (int j = 2 ; j <= k ; j++)
    {
        for (int i = 2 ; i <= n ; i++)
        {
            c[i][j] = c[i-1][j];
            if ((i-1)/2 != i/2)
            {
                c[i][j] = (c[i][j]+c[i/2][j-1]) % 1000000009;
            }
        }
    }
    
    cout << c[n][k];
    return 0;
}
