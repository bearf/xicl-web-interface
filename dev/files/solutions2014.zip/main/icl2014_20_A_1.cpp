#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <iomanip>
#include <list>

using namespace std;

#define mp make_pair
#define pb push_back
#define X first
#define Y second

vector<vector<int> >v;
int a[100100];
int mint=(1<<20), n;
void rec(int t, int mx, int sum)
{
    //cout<<t<<" "<<mx<<" "<<sum<<endl;
    //for (int i=1; i<=t; i++)
    //    cout<<a[i]<<" ";
    //cout<<endl;
    if ( t>mint )
        return ;
    if ( sum>n )
        return ;
    if ( sum==n )
    {
        if ( mint>t )
            v.clear(), mint=t;
        if ( mint==t )
        {
            vector<int>q;
            for (int i=1; i<=t; i++)
                q.push_back(a[i]);
            v.push_back(q);
        }
        return ;
    }
    if ( sum+(sum+sum+1)<=n )
    {
        a[t+1]=sum+sum+1;
        rec(t+1, sum+sum+1, sum+sum+sum+1);
    }
    if ( sum+mx<=n )
    {
        a[t+1]=mx;
        rec(t+1, mx, sum+mx);
    }
}
int main()
{
    cin>>n;
    a[1]=1;
    rec(1, 1, 1);
    //cout<<"hel"<<endl;
    printf("%d %d\n", (int)v.size(), (int)v[0].size());
    for (int i=0; i<v.size(); i++)
    {
        for (int j=0; j<v[i].size(); j++)
            printf("%d ", v[i][j]);
        printf("\n");
    }

    return 0;
}

