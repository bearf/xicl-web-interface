#include <iostream>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
using namespace std;

#if LOCAL
	#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
	#define eprintf(...) 42;
#endif

const int MAXE = 1 << 23;
int fst[1 << 18];
int nxt[MAXE];
int eend[MAXE];
int eid[MAXE];
int edges = 0;

inline void addEdge(int u, int v, int id) {
	nxt[edges] = fst[u];
	eend[edges] = v;
	eid[edges] = id;
	fst[u] = edges++;
}

int n;
vector <int> answer;

void dfs(int v) {
	for (int i = fst[v]; i != -1; i = fst[v]) {
		fst[v] = nxt[i];
		int to = eend[i];
		dfs(to);
		answer.push_back(eid[i]);
	}
}

int main() {
#ifdef LOCAL
	freopen("f.in", "r", stdin);
#endif
	scanf("%d", &n);
	for (int i = 0; i < (1 << n); i++) {
		fst[i] = -1;
	}
	for (int i = 0; i < (1 << n); i++) {
		for (int j = 0; j < n; j++) {
			int k = i ^ (1 << j);
			addEdge(i, k, j);
		}
	}
	eprintf("%d\n", edges);
	dfs(0);
	printf("%d\n", answer.size());
	for (int i = 0; i < (int)answer.size(); i++) {
		if (i > 0) {
			printf(" ");
		}
		printf("%d", answer[i] + 1);
	}
	puts("");
	return 0;
}