#include <iostream>
using namespace std;
typedef long long ll;

ll x;
int n;
int a[65];
int b[65];

int main()
{
	scanf("%lld", &x);
	n = 0;
	while (x > 0)
	{
		a[n++] = x % 2;
		x /= 2LL;
	}
	
	for (int i = n; i >= 0;)
	{
		if (a[i] == 1)
		{
			int r = i;
			while (r >= 0 && a[r] == 1) r--;
			r++;
			b[i + 1] = 1;
			b[r] = -1;
			i = r - 1;
		}
		else
		{
			i--;
		}
	}
	for (int i = 64; i > 0; i--)
	{
		if (b[i] * b[i - 1] != 0)
		{
			b[i - 1] = b[i];
			b[i] = 0;
		}
	}
	n = 64;
	while (b[n] == 0) n--;
	for (int i = n; i >= 0; i--)
	{
		printf("%d ", b[i]);
	}
//	cin >> n;
	return 0;
}