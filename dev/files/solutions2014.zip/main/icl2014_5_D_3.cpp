#include <iostream>
#include <string>
using namespace std;

string s;
int n;

int main()
{
	cin >> s;
	n = s.length();
	if (n == 1)
	{
		int x = (int)(s[0] - '0');
		for (int i = 1; i <= x; i++)
			printf("%d", i);
		return 0;
	}
	int x = (int)(s[0] - '0');
	
	int k = 0;
	while (k < n && s[k] == s[0])
		k++;
	if (k < n)
	{
		if (s[k] > s[0])
			k = n;
	}

	for (int i = 1; i <= x; i++)
		printf("%d", i);
	for (int i = 1; i < n; i++)
		for (int j = 0; j < 10; j++)
		{
			if (i != k || j != x || (k != 1 && x != 1))
				printf("%d", j);
		}
//	cin >> n;
	return 0;
}