#pragma comment(linker, "/STACK:268435456")

#include <iostream>
#include <iomanip>

#include <vector>
#include <string>
#include <deque>
#include <queue>
#include <set>
#include <map>

#include <algorithm>

#include <cstdio>
#include <cstdlib>
#include <complex>
#include <ctime>
#include <cstring>
#include <cassert>

using namespace std;

#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define ford(i,n) for (int i = int(n) - 1; i >= 0; --i)

#define pb push_back
#define mp make_pair
#define fs first
#define sc second
#define all(a) (a).begin(), (a).end()
#define sz(a) int((a).size())

#ifdef SG
    #define debug(x) cerr << #x << ": " << (x) << endl
#else
    #define debug(x)
#endif

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

template <typename T>
ostream & operator << (ostream & out, vector<T> const & a) {
    out << "[";
    for (int i = 0; i < sz(a); ++i) {
        if (i != 0) {
            out << ", ";
        }
        out << a[i];
    }
    out << "]";
    return out;
}

template <typename T1, typename T2>
ostream & operator << (ostream & out, pair<T1, T2> const & p) {
    out << "(" << p.fs << ", " << p.sc << ")";
    return out;
}

struct Data {
    int n;
    int a[110][110];
    bool ok;
    int ans;
    bool read () {
        if (scanf ("%d", &n) != 1)
            return false;
        forn(i, n)
            forn(j, n){
                scanf ("%d", &a[i][j]);
            }
        return true;
    }

    void write () {
        cout << ans << endl;
    }

    virtual void solve () {
    }

    virtual void clear () {
        *this = Data();
    }
};

struct Solution: Data {
    void solve () {
        int kol = 0, sum = 0;
        forn(i, n){
            forn(j, n){
                if (a[i][j] != 0) kol ++;
                sum += a[i][j];
            }
        }
        if (n * n - kol > kol){
            ok = false;
            ans = -1;
        } else {
            ok = true;
            ans = sum;
        }
    }

    Solution (Data d = Data()): Data(d) {}

    void clear () {
        
        *this = Solution();
    }
};

Solution sol;
int main () {
#ifdef SG
    freopen("input.txt", "r", stdin);
//    freopen("", "w", stdout);
    while (sol.read()) {
        sol.solve();
        sol.write();
        sol.clear();
    }
#else
//    freopen("", "r", stdin);
//    freopen("", "w", stdout);
    sol.read();
    sol.solve();
    sol.write();    
#endif

    return 0;
}
