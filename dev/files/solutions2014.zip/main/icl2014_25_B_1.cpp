#define MAXN 1001000
#define INF 1000000009
#define EPS 1E-9 
#define PROB "a"

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <string>
#include <cstring>
#include <cmath>
#include <set>

using namespace std;

int d[MAXN][25],  s[25], n, k;

int main(){
	
	scanf ("%d%d", &n, &k);

	memset (d, 0, sizeof (d));
	memset (s, 0, sizeof (s));
	
	s[0] = 1; 
	for (int i = 1; i < n+1; ++i) {
		if (i % 2 == 0)
			for (int j = 1; j < k+1; ++j)
				s[j] = (s[j] + d[i/2][j]) % INF;
		
		for (int j = 1; j < k+1; ++j) {
			d[i][j] = s[j-1];
			//printf ("%d ", d[i][j]);
		}

		
		//printf ("\n");
	}

	

	printf ("%d", d[n][k]);
	return 0;
}