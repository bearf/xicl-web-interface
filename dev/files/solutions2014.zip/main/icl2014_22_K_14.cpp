#pragma comment(linker, "/STACK:64000000")

#include<iostream>
#include<cstdio>
#include<sstream>

#include<algorithm>
#include<vector>
#include<set>
#include<bitset>
#include<map>
#include<queue>
#include<deque>
#include<stack>

#include<string>
#include<memory.h>
#include<cassert>
#include<time.h>

using namespace std;

#define forn(i, n) for(int i = 0; i < (int)n; i++)
#define forab(i, a, b) for(int i = (int)a; i <= (int)b; i++)
#define fornd(i, n) for(int i = 0; i < (int)n; i--)
#define forabd(i, b, a) for(int i = (int)b; i >= (int)a; i--)
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define _(a, val) memset(a, val, sizeof(a))
#define sz(a) (int)(a).size()

typedef long long lint;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;

const int INF = 1000000000;
const lint LINF = (lint)INF * (lint)INF;
const ld eps = 1e-9;

bool eq(long double a,long double b)
{
	return fabs(a - b) < eps;
}

long double sq(long double a)
{
	return a * a;
}

struct Vec
{
	long double x, y;
	Vec(){}
	Vec(long double _x, long double _y) { x = _x; y = _y; }
	Vec operator + (Vec oth) { return Vec(x + oth.x, y + oth.y); }
	Vec operator - (Vec oth) { return Vec(x - oth.x, y - oth.y); }
	Vec operator * (long double k) { return Vec(x * k, y * k); }
	Vec operator / (long double k) { return Vec(x / k, y / k); }
	long double length() { return sqrt(sq(x) + sq(y)); }
	void read() { int _x, _y; scanf("%d%d",&_x,&_y); x = _x; y = _y; }
	Vec norm() { return Vec(x / length(), y / length()); }
	bool operator == (const Vec &oth) const
	{
		return eq(x, oth.x) && eq(y, oth.y);
	}
};

struct Line
{
	Vec from, to;
	long double A, B, C;

	void read()
	{
		from.read();
		to.read();
		A = from.y - to.y;
		B = to.x - from.x;
		C = - (A * from.x + B * from.y);

		long double zn = sqrt(sq(A) + sq(B));
		A /= zn;
		B /= zn;
		C /= zn;
	}
};

const int nmax = 10005;
Line a[nmax];
int n;

void read()
{
	scanf("%d",&n);
	for (int i = 0; i < n; i ++)
		a[i].read();
	a[n] = a[0];
}

Vec mov(Vec cur, Line l)
{
	long double dist = l.A * cur.x + l.B * cur.y + l.C;
	cur = cur - Vec(l.A, l.B) * dist;
	return cur;
}

long double fun(Vec p)
{
	Vec cur = p;
	for (int i = 1; i <= n; i ++)
	{
		cur = mov(cur, a[i]);
	}
	return (cur - p).length();
}

void solve()
{
	Vec l, r, m1, m2, O, dir = Vec(-a[0].B, a[0].A);
	if (eq(a[0].B, 0.0))
		O = Vec( -a[0].C / a[0].A, 0.0);
	else
		O = Vec(0, - a[0].C / a[0].B);
	const long double magic = 100000000000.0 * 10.0;
	l = O - dir * magic;
	r = O + dir * magic;
	for (int it = 0; it < 3000; it ++)
	{
		m1 = l + (r - l) / 3.;
		m2 = r - (r - l) / 3.;
		if (fun(m1) > fun(m2))
			l = m1;
		else
			r = m2;
	}
	{
		if (eq(l.x, 0.0)) l.x = 0;
		if (eq(l.y, 0.0)) l.y = 0;
		printf("%.8lf %.8lf\n",	(double)l.x, (double)l.y);
	}
}

int main()
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	read();
	solve();

	return 0;
}