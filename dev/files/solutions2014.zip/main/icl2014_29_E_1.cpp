#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <cassert>

using namespace std;

#ifdef _WIN32
	#define LLD "%I64d"
#else
	#define LLD "%lld"
#endif

typedef long double ld;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<long long> vll;

#define mp make_pair
#define pb push_back
#define sz(x) ((int)(x).size())
#define EPS (1e-9)
#define INF ((int)1e9)
#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define TASK "text"

const int maxn = (int)2e5 + 100;
int a[maxn];
pair<int, int> ps[maxn];

int solve() {
	int n;
	if (scanf("%d", &n) < 1)
		return 0;
	for (int i = 0; i < n; ++i) {
		scanf("%d", &a[i]);
		ps[i] = mp(a[i], i);
	}

	sort(ps, ps + n);
	
	int ans = 0;
	for (int i = 0; i < n;) {
		int i0 = i;
		++i;
		while (i < n && ps[i].second >= ps[i - 1].second)
			++i;
		ans = max(ans, i - i0);
	}

	printf("%d\n", n - ans);
	return 1;
}

int main() {
#ifdef DEBUG
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	
	int n;
	while (1) {
		if (!solve())
			break;
		#ifdef DEBUG
		eprintf("%.18lf\n", (double)clock() / CLOCKS_PER_SEC);		
		#endif
	}
	return 0;
}
