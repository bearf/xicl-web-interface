#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

#pragma comment(linker, "/STACK:16000000")

const int MAXN = 100500;

int n, m;
vector<int> g[MAXN];
int par[MAXN];
int height[MAXN];
bool marked[MAXN];

void dfs_par(int v, int p, int h)
{
	par[v] = p;
	height[v] = h;

	for (int i = 0; i < g[v].size(); i++)
	{
		int to = g[v][i];
		if (to == p)
			continue;

		dfs_par(to, v, h + 1);
	}
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	scanf("%d", &n);

	for (int i = 0; i < n - 1; i++)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		u--; v--;

		g[u].push_back(v);
		g[v].push_back(u);
	}

	dfs_par(0, -1, 0);

	scanf("%d", &m);
	int total_cnt = 0;

	for (int i = 0; i < m; i++)
	{
		int v;
		scanf("%d", &v);
		v--;

		int cur_h = height[v];

		int cnt = 0;
		while (v != -1 && !marked[v])
		{
			if (v != 0)
				cnt++;
			marked[v] = true;
			v = par[v];
		}
		total_cnt += cnt;

		printf("%d ", total_cnt * 2 - cur_h);
	}

	return 0;
}