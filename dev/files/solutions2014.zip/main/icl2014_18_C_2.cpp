#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <algorithm>
#define ll long long
using namespace std;

int main() {
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);

	ll n;
	cin >> n;
	vector<long long> ans;
	while (n > 0) {
		ans.push_back(n % 2);
		n /= 2;
	}
	reverse(ans.begin(), ans.end());
	cout << 1 << ' ';
	long long j = 0;
	long long ss=0;
	if (ans[1] == 1)
	{
		
		while(ss < ans.size())
		{

		   
			
			if (ans[ss]==0)
				break;
			j+=1;
			ss++;
		}
		j--;
	}
	if (j>0)
	{
		for (long long i=0;i<j;i++)
		{
			cout << "0 ";
		}
		cout << "-1 ";
	}
	long long topol = 0;
	for (long long i=j+1;i<ans.size();i++)
	{
		if (ans[i] == 0)
		{
			if (topol!=0)
			{
				
				if (topol==1)
					cout << "1 ";
				else
				{
					cout << "-1 ";
				for (long long q=1;q<topol;q++)
				{
					cout << "0 ";
				}
				}
				if (topol>=2)
					cout << "-1 ";
			}
			cout << "0 ";
			topol = 0;
		}
		if (ans[i] == 1)
			topol+=1;
	}
	if (topol!=0)
			{
				
				if (topol==1)
					cout << "1 ";
				else
				{
					cout << "-1 ";
				for (long long q=1;q<topol;q++)
				{

					cout << "0 ";
				}
				}
				if (topol>=2)
					cout << "-1 ";
			}
}
