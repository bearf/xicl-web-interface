#include<iostream>
#include <deque>
#include <vector>
using namespace std;
int main()
{
	_int64 n,i=0;
	cin>>n;
	vector<int> a;
	a.push_back(n%2);
	n/=2;
	while(n)
	{
		a.push_back(n%2);
		if(a[i]==a[i+1] && a[i]==1)
		{
			a[i]=-1;
			n++;	
			a.pop_back();
			a.push_back(0);
			//i--;
		}
		i++;
		n/=2;
	}
	reverse(a.begin(), a.end());
	for(int i=0;i<a.size();i++)
		cout<<a[i]<<' ';
}
