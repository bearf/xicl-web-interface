#include <iostream>
#include <math.h>
using namespace std;


int main()
{
	int n;
	cin >> n;
	int p = (int) (log((double)n) / log(2.0));
	cout << 1 << " ";
	int s = (int) pow(2.0, (double)p);
	while (s < n)
	{
		p--;
		if ((int) pow(2.0, (double)p) + s <= n)
		{
			s+=(int) pow(2.0, (double)p);
			cout << 1 << " ";
		}
		else
			cout << 0 << " ";
	}
	return 0;
}