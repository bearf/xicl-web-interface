#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <math.h>

//#define _DEBUG
#define forn(i,n) for (int i=0;i<n;i++)
#define LL long long

using namespace std;
const LL mod=1000000009;

LL work(int n, int k, LL **&a){
	if (k==1)
	{
		if (n>0)
			return 1;
		return 0;
	}

	if (a[n][k]!=-1)
		return a[n][k];

	a[n][k]=0;

	int st=n/2+(n%2>0);
	int fin=n;
	for (int i=0;i<k-3;i++)
	{	
		fin-=1<<i;
	}
	fin--;
	for (int i=st;i<=fin;i++)
	{
		a[n][k]=(a[n][k]+work(n-i,k-1,a))%mod;
	}
	return a[n][k];
}
const int N1=1000002;
const int K1=23;
typedef struct{LL a[K1];}tp;
tp *sums;//[21];
tp *res;//[21];
void solve(int N,int K){
	int i,k;
	sums[0].a[0]=1;
	for(i=1;i<=N;++i){
		sums[i].a[0]=sums[i-1].a[0];
		for(k=0;k<K;++k){
 			res[i].a[k+1]=sums[i/2].a[k];
			sums[i].a[k+1]=(sums[i-1].a[k+1]+res[i].a[k+1])%mod;
		}
	}
}

int main()
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	sums=new tp[N1];memset(sums,0,sizeof(tp)*N1);
	res=new tp[N1];memset(res,0,sizeof(tp)*N1);
	int n, k;
	cin>>n>>k;
	solve(n,k);
	//cout<<sums[n].a[k];
	cout<<res[n].a[k];
	return 0;
/*
	LL **a=new LL*[n+1];
	for (int i=0;i<=n;i++)
	{
		a[i]=new LL[k+1];
		for (int j=0;j<=k;j++)
			a[i][j]=-1;
	}

	cout<<work(n,k,a);*/
}