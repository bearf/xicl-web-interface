#include <iostream>
#define fin cin
#define fout cout

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

const int nmax = 1100;

int a[nmax][nmax];
int n;


void readdata()
{
    fin >> n;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            fin >> a[i][j];
}


void solve()
{
    int summ = 0;
    int kol = 0;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
        {
            summ += a[i][j];
            if (a[i][j] == 0)
                kol++;
        }
    if (kol > n * n - kol)
        fout << -1 << endl;
    else
        fout << summ << endl;
}


int main()
{
    readdata();
    solve();
    return 0;
}
