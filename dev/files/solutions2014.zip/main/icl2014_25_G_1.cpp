#define MAXN 100010
#define INF 1E+9
#define EPS 1E-9 
#define PROB "a"

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <string>
#include <cstring>
#include <cmath>
#include <queue>

using namespace std;


int n, m, used[MAXN], d[MAXN];

vector<int> g[MAXN];




	int bfs (int v) {
		queue<int> q; 
		q.push (v);
		used[v] = 1; 

		while (!q.empty ()) {
			int u = q.front ();
			q.pop ();
			
			for (int i = 0; i < g[u].size (); ++i) 
				if (used[ g[u][i] ] == 1) {
					//
				}else {
					used[ g[u][i] ] = 1;
					d[g[u][i]] = d[u] + 1;
					q.push (g[u][i]);

					g[u][i] = g[u].back ();
					g[u].pop_back ();
					--i;
				}
		}
		return 0;
	}


int main(){

	scanf ("%d", &n);

	for (int i = 0; i < n-1; ++i) {
		int x, y;
		scanf ("%d%d", &x, &y);
		g[x].push_back (y);
		g[y].push_back (x);
	}

	memset (used, 0, sizeof (used));
	memset (d, 0, sizeof (d));
	bfs(1); 

	scanf ("%d", &m);

	int ans = 0, p = 1;
	memset (used, 0, sizeof (used));
	used[1] = 1;

	for (int i = 0; i < m; ++i) {
		int x, y, l;
		scanf ("%d", &x);	
		
		y = x; l = 0;
		while (used[y] == 0) {
			used[y] = 1;
			y = g[y][0];
			++l;
		}

		ans = ans + d[p] - d[y] + l;
		p = x;

 		printf ("%d ", ans);
	}

	return 0;
}