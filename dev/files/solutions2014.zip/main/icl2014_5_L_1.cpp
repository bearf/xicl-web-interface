#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;

int a[100][100];

int main()
{
	int n;
	scanf("%d", &n);
	int cntZ = 0, cntN = 0, sum = 0;
	for (int i = 0; i < n; i++)
		for (int s = 0; s < n; s++)
		{
			scanf("%d", &a[i][s]);
			if (a[i][s] == 0)
				cntZ++;
			else
				cntN++;
			sum += a[i][s];
		}
	if (cntZ > cntN)
		puts("-1");
	else
		printf("%d", sum);
	return 0;
}