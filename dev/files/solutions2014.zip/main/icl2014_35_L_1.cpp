#include <iostream>
#include <cstdio>
using namespace std;

int main() {
#ifdef LOCAL
	freopen("l.in", "r", stdin);
#endif
	int sc = 0;
	int n;
	scanf("%d", &n);
	int a = 0, b = 0, x;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			scanf("%d", &x);
			sc += x;
			if (x > 0) {
				a++;
			} else {
				b++;
			}
		}
	}
	printf("%d\n", a >= b ? sc : -1);
	return 0;
}