#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cassert>
#include <ctime>
#include <memory.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <complex>
#include <list>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef complex <ld> point;

#define pb push_back
#define mp make_pair
#define fi first
#define se second

#define INF 1000000001
#define INFL 1000000000000000001ll
#define NAME "k"

point a[100001];
point b[100001];
int n;

inline ld operator%(point a, point b) {
    return (conj(a) * b).imag();
}

inline point go(point p, point a, point b) {
    ld s = (a - p) % (b - p);
    point v = (b - a) * point(0, -1);
    v /= abs(v);
    v *= s / abs(a - b);
    v += p;
//    assert(fabsl((v - a) % (v - b)) < 1e-2);
    return v;
}

inline point solve(point p) {
    for (int i = 1; i <= n; ++i) {
        p = go(p, a[i], b[i]);
//        cerr << p << '\n';
    }
    return p;
}

int main() {
    cout.precision(10);
    cout.setf(ios::fixed);
    #ifdef _GEANY
    assert(freopen(NAME ".in", "r", stdin));
    #endif // _GEANY
    cin >> n;
    for (int i = 0; i < n; ++i) {
        ld x1, y1, x2, y2;
        cin >> x1 >> y1 >> x2 >> y2;
        a[i] = point(x1, y1);
        b[i] = point(x2, y2);
    }
    a[n] = a[0];
    b[n] = b[0];
    point a1 = solve(a[0]);
    point a2 = solve(b[0]);
    if (abs(a1 - a[0]) < 1e-6) {
        cout << a[0].real() << ' ' << a[0].imag() << '\n';
        return 0;
    }
//    cerr << a1 << ' ' << a2 << '\n';
    ld A = ((a2 - a1) / (b[0] - a[0])).real();
    if (fabsl(A - 1) < 1e-6) {
        cout << -1 << endl;
        return 0;
    }

    point p = a[0] + (a1 - a[0]) / (1 - A);
    cout << p.real() << ' ' << p.imag() << '\n';
}
