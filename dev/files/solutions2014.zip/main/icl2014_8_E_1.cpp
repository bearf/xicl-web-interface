#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include <iostream>
#include <algorithm>

using namespace std;

#define M 1000100
#define K 22
#define p 1000000007

int a[200200], d[200200], n;

const int inf = 1000000010;

int main() {
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		scanf("%d", &a[i]);
	fill(d, d + 200200, inf);
	for (int i = 0; i < n; i++)
	{
		int t = upper_bound(d, d + 200200, a[i]) - d;
		d[t] = a[i];
	}
	int cur = 0;
	while (d[cur] != inf) cur++;
	printf("%d", n - cur);
	return 0;
}