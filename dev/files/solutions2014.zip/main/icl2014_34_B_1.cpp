#include <iostream>
#include <algorithm>
using namespace std;

const int MAXN = 1000500;
const int MAXK = 21;
const int MOD = (int)1e9 + 9;

int add(int a, int b)
{
	int c = a + b;
	if (c >= MOD)
		c -= MOD;
	return c;
}

int sub(int a, int b)
{
	int c = a - b;
	if (c < 0)
		c += MOD;
	return c;
}

int N, K;
int dp[MAXK][MAXN];
int adder[MAXK][MAXN];

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	scanf("%d%d", &N, &K);

	dp[0][0] = 1;

	for (int k = 0; k <= K; k++)
	{
		int sum = 0;

		for (int n = 0; n <= N; n++)
		{
			sum = add(sum, adder[k][n]);
			dp[k][n] = add(dp[k][n], sum);

			int L = max(1, (N - n + 1) / 2);
			int R = N - n - K + k + 1;
			if (k < K && L <= R)
			{
				adder[k + 1][n + L] = add(adder[k + 1][n + L], dp[k][n]);
				adder[k + 1][n + R + 1] = sub(adder[k + 1][n + R + 1], dp[k][n]);
			}
		}
	}

	printf("%d\n", dp[K][N]);

	return 0;
}