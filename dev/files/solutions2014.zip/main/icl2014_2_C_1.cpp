#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cassert>
#include <ctime>
#include <memory.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <complex>
#include <list>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef complex <ld> point;

#define pb push_back
#define mp make_pair
#define fi first
#define se second

#define INF 1000000001
#define INFL 1000000000000000001ll
#define NAME "c"

vector <int> a;

int main() {
    #ifdef _GEANY
    assert(freopen(NAME ".in", "r", stdin));
    #endif // _GEANY
    ll n;
    cin >> n;
    while (n) {
        if (n % 4 == 1) {
            a.pb(1);
            a.pb(0);
            n /= 4;
        } else if (n % 4 == 3) {
            a.pb(-1);
            a.pb(0);
            n /= 4;
            ++n;
        } else {
            a.pb(0);
            n /= 2;
        }
    }
    while (a.size() && a.back() == 0)
        a.pop_back();
    for (int i = (int) a.size() - 1; i >= 0; --i)
        cout << a[i] << ' ';
    cout << endl;
}
