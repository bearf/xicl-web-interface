#include <cstdlib>
#include <cstdio>
#include <iostream>

using namespace std;

int main() {
	int n;
	cin >> n;

	int cnt_z = 0;
	int cnt_nz = 0;
	int sum_nz = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			int a;
			cin >> a;

			if (a == 0) {
				cnt_z++;
			} else {
				cnt_nz++;
				sum_nz += a;
			}
		}
	}

	if (cnt_z > cnt_nz) {
		cout << -1 << endl;
	} else {
		cout << sum_nz << endl;
	}

	return 0;
}