#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <stdio.h>
#include <queue>
#include <deque>
#define USE_MATH_DEFINES
#include <math.h>

#define ll long long
#define ull unsigned ll
#define mp make_pair
#define pb push_back

using namespace std;

const ll MOD = 1000000007;
const ll INF = 1000000000000000;

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif
	ll n;
	vector <int> q;

	cin >> n;

	int k = 0;
	while (n) {
		q.push_back(n & 1);
		n >>= 1;
	}

	int l = 0;
	int p = q.size();

	for (int i(0); i < p; i++) {
		if (q[i] == 1){
			if (k == 0) {
				l = i;
				k = 1;
			}
			else {
				k++;
			}
		}
		else {
			if (k > 1) {
				q[l] = -1;
				for (int j(l + 1); j < i; j++) {
					q[j] = 0;
				}
				q[i] = 1;
				i--;
			}
			k = 0;
		}
	}

	if (k > 1) {
		q[l] = -1;
		for (int j(l + 1); j < q.size(); j++) {
			q[j] = 0;
		}
		q.push_back(1);
	}

	for (int i(q.size() - 1); i >= 0; i--) {
		cout << q[i] << ' ';
	}
}