import java.io.*;
import java.util.*;

public class FOK {

	FastScanner in;
	PrintWriter out;
	
	int diff(int a, int b) {
		return Integer.bitCount((a ^ b) - 1);
	}
	
	void solve(int n) {
		int[] seq = new int[n * (1 << n)];

		int[] last = new int[1 << n];
		
		int pos = 0;
		List<Integer> stack = new ArrayList<>();
		stack.add(0);
		while (pos < n * (1 << n)) {
			int cur = stack.get(stack.size() - 1);
			int bit = last[cur];
			if (last[cur] == n) {
				stack.remove(stack.size() - 1);
				seq[pos++] = diff(stack.get(stack.size() - 1), cur);
			} else {
				last[cur]++;
				int newMask= cur ^ (1 << bit);
				stack.add(newMask);
			}
		}
		
//		check(n, seq);

		out.println(seq.length);
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < seq.length; i++) {
			sb.append(seq[i] + 1);
			if (i + 1 < seq.length) {
				sb.append(" ");
			}
		}
		out.println(sb.toString());
	}

	private void check(int n, int[] seq) {
		boolean[][] vis = new boolean[n][1 << n];
		int curMask = 0;
		for (int i = 0; i < seq.length; i++) {
			int bit = seq[i];
			curMask ^= 1 << bit;
			if (vis[bit][curMask]) {
				throw new AssertionError();
			}
			vis[bit][curMask] = true;
		}
	}

	void run() {
		try {
			in = new FastScanner();
			out = new PrintWriter(System.out);
			int n = in.nextInt();
			solve(n);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	class FastScanner {
		BufferedReader br;
		StringTokenizer st;

		public FastScanner() {
			br = new BufferedReader(new InputStreamReader(System.in));
		}

		String nextToken() {
			while (st == null || !st.hasMoreElements()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return st.nextToken();
		}

		int nextInt() {
			return Integer.parseInt(nextToken());
		}

		long nextLong() {
			return Long.parseLong(nextToken());
		}

		double nextDouble() {
			return Double.parseDouble(nextToken());
		}
	}

	public static void main(String[] args) {
		new FOK().run();
	}
}
