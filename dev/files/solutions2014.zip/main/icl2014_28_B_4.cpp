#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <stdio.h>
#include <queue>
#include <deque>
#define USE_MATH_DEFINES
#include <math.h>

#define ll long long
#define ull unsigned ll
#define mp make_pair
#define pb push_back

using namespace std;

const int MOD = 1000000009;
const ll INF = 1000000000000000;

ll d[20];
ll q[1000006] = {0};
ll ans = 0;
ll n, k;
int kk;

ll summ(int r) {
	ll res = 0;
	for (; r >= 0; r = (r & (r + 1)) - 1) {
		res = (res + q[r]) % MOD;
	}
	return res;
}

void inc(int v, ll d) {
	for (int i(v); i < n; i = (i | (i + 1))) {
		q[i] = (q[i] + d) % MOD;
	}
}

ll f(int v) {
	for (int i(1); i < kk; i++) {
		v /= 2;
		if (v == 0)
			return 0;
	}
	return v;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	cin >> n >> k;

	if (k == 1) {
		cout << 1;
		return 0;
	}

	ll sum = 1;
	d[0] = 1;
	for (int i(1); i < k; i++) {
		d[i] = sum;
		sum += d[i];
	}

	if (sum > n) {
		cout << 0;
		return 0;
	}

	d[k-1] += n - sum;

	ll q = n / 2 + bool(n % 2);
	
	kk = k;
	k = d[k-1] - q;

	int ans = 0;
	for (int i(1); i <= k; i++) {
		ll t = summ(i / 2) - summ(f(i)) + 1;
		ans = (ans + t) % MOD;
		inc(i, t);
	}

	cout << ((ans + 1) % MOD + MOD) % MOD;
}