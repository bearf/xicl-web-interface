#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <algorithm>
using namespace std;

int main(){
	//freopen("1.txt","r",stdin);
	int n;
	cin>>n;
	vector<vector<int> > a(n,vector<int> (n));
	int p=0,s=0;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++){
			int d;
			cin>>d;
			if(d==0) p++;
			else s+=d;
			//cin>>a[i][j];
		}
	if(p <= n*n-p)
		cout<<s<<endl;
	else
		cout<<-1<<endl;
	

}