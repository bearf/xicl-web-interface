#include<iostream>
#include <deque>

using namespace std;

int main(){
	int n, x, s = 0;;
	cin >> n;
	deque <int> d;

	for(int i = 0; i < n; i++){
		cin >> x;
		d.push_back(x);
	}

	if(n == 2){
		if(d[0] <= d[1]){
			cout << 0;
			return 0;
		} else {
			cout << 1;
			return 0;
		}
	}

	bool b = true;

	while(1){
		b = true;
		for(int i = 1; i < d.size()-1; i++){
			if(d[i] != -1){
				if(d[i] < d[i-1]){
					d.push_front(d[i]);
					d[i] = -1;
					s++;
				}
				if(d[i] > d[i+1]){
					d.push_back(d[i]);
					d[i] = -1;
					s++;
				}
			}
		}
		if(b == true){
			cout << s;
			return 0;
		}
	}


	return 0;
}