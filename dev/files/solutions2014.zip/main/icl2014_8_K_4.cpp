#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cassert>
#include <ctime>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

#define M 1000100
#define K 20

typedef long long ll;
typedef long long li;

void Solve(void);

int main(){
	/*int a[4];
	srand(time(NULL));
	freopen("test.in", "w", stdout);
	int n = 10000, bd = 10;
	printf("%d\n", n);
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < 4; j++)
			a[j] = rand() % (2 * bd + 1) - bd;
		while (a[0] == a[2] && a[3] == a[1]) a[0] = rand() % (2 * bd + 1) - bd;
		for (int j = 0; j < 4; j++)
			printf("%d ", a[j]);
		printf("\n");
	}*/
#ifdef BANANA_MOTEL
	freopen("test.in", "r", stdin);
	freopen("test.out", "w", stdout);
#else
#endif
	Solve();
	return 0;
}

struct point
{
	long double x, y;
	point() {x = y = 0; }
	point(long double x_, long double y_) {x = x_; y = y_; }
};

int n;
point a[20100][4];

const long double eps = 1e-9;

long double count(long double st)
{
	//cerr << st << endl;
	for (int i = 0; i < n; i++)
	{
	//	cerr << i << ' ' << st << endl;
		st = st * (a[i + 1][1].x * a[i][1].x + a[i + 1][1].y * a[i][1].y) + a[i + 1][1].x * (a[i][0].x - a[i + 1][0].x) + a[i + 1][1].y * (a[i][0].y - a[i + 1][0].y);
		st /= (a[i + 1][1].x * a[i + 1][1].x + a[i + 1][1].y * a[i + 1][1].y);
		//cerr << st << endl;
	}
	//cerr << st << endl;
	return st;
}

void Solve()
{
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> a[i][0].x >> a[i][0].y >> a[i][1].x >> a[i][1].y;
		a[i][1].x -= a[i][0].x; a[i][1].y -= a[i][0].y;
	}
	a[n][0] = a[0][0], a[n][1] = a[0][1];
	/*for (int i = 0; i <= n; i++)
		err << a[i][0].x << ' ' << a[i][0].y << ' ' << a[i][1].x << ' ' << a[i][1].y << endl;*/
	long double lt = count(0), rt = count(1), res;
	//cerr << lt << ' ' << rt << endl;
	if (fabsl(rt - lt - 1) <= eps)
	{
		if (fabsl(lt) <= eps) res = lt;
		else { cout << -1; return; }
	}
	else res = -lt / (rt - lt - 1);
	long double ax = res * a[0][1].x + a[0][0].x, ay = res * a[0][1].y + a[0][0].y;
	cout.precision(8); cout << fixed << ax << ' ' << ay;
	/*long double tx = ax, ty = ay;
	assert(fabs((tx-a[0][0].x)*a[0][1].y-(ty-a[0][0].y)*(a[0][1].x)) <= eps);
	for (int i = 0; i < n; i++)
	{
		long double vx = a[i + 1][1].x * (a[i + 1][1].x * (tx - a[i + 1][0].x) + a[i + 1][1].y * (ty - a[i + 1][0].y)) / (a[i + 1][1].x * a[i + 1][1].x + a[i + 1][1].y * a[i + 1][1].y);
		long double vy = a[i + 1][1].y * (a[i + 1][1].x * (tx - a[i + 1][0].x) + a[i + 1][1].y * (ty - a[i + 1][0].y)) / (a[i + 1][1].x * a[i + 1][1].x + a[i + 1][1].y * a[i + 1][1].y);
		tx = a[i + 1][0].x + vx, ty = a[i + 1][0].y + vy;
		assert(fabs((tx-a[i + 1][0].x)*a[i + 1][1].y-(ty-a[i + 1][0].y)*(a[i + 1][1].x)) <= eps);
	}
	assert(fabs(tx - ax) <= eps && fabs(ty - ay) <= eps);*/
}