#include <iostream>
using namespace std;

int n;
int a[5000000], b[5000000];
int sz1, sz2;
int mask;
bool u[500000];

int main()
{
	scanf("%d", &n);
	sz1 = 2;
	a[0] = 1;
	a[1] = 1;
	for (int k = 2; k <= n; k++)
	{
		sz2 = 1;
		b[0] = k;
		mask = 0;
		for (int i = 0; i < (1 << k); i++)
			u[i] = 0;
		u[0] = 1;
		for (int i = 0; i < sz1; i++)
		{
			b[sz2++] = a[i];
			mask ^= 1 << a[i];
			if (!u[mask])
			{
				b[sz2++] = k;
				b[sz2++] = k;
				u[mask] = 1;
			}
		}
		b[sz2++] = k;
		for (int i = 0; i < sz1; i++)
		{
			b[sz2++] = a[i];
		}
		sz1 = sz2;
		for (int i = 0; i < sz2; i++)
			a[i] = b[i];
	}
	printf("%d\n", sz1);
	for (int i = 0; i < sz1; i++)
		printf("%d ", a[i]);
//	cin >> n;
	return 0;
}