#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>
#include <cmath>


const int maxn = 146;
const double eps = 1e-6;
const double PI = acos(-1.);


using namespace std;


bool doubleEqual(double a, double b)
{
	return fabs(a - b) < eps;
}


bool doubleLess(double a, double b)
{
	return a < b && !doubleEqual(a, b);
}


bool doubleLessOrEqual(double a, double b)
{
	return a < b || doubleEqual(a, b);
}


struct Point
{
	double x, y;
	Point(double x, double y): x(x), y(y) {};
	Point() {};

	void scan()
	{
		scanf("%lf%lf", &x, &y);
	}

	Point operator+(const Point & p) const
	{
		return Point(x + p.x, y + p.y);
	}

	Point operator-(const Point & p) const
	{
		return Point(x - p.x, y - p.y);
	}

	double operator%(const Point & p) const
	{
		return x * p.x + y * p.y;
	}

	double operator*(const Point & p) const
	{
		return x * p.y - y * p.x;
	}

	Point operator*(double d) const
	{
		return Point(x * d, y * d);
	}

	Point operator/(double d) const
	{
		return Point(x / d, y / d);
	}

	double len() const
	{
		return sqrt(*this % *this);
	}

	double distTo(const Point & p) const
	{
		return (*this - p).len();
	}

	Point norm(double d) const
	{
		return *this / len() * d;
	}

	Point rotate()
	{
		return Point(-y, x);
	}

	Point rotate(double alpha)
	{
		Point u = *this;
		Point v = u.rotate();
		return v * sin(alpha) + u * cos(alpha);
	}

	void print()
	{
		printf("%lf %lf\n", x, y);
	}
}p[maxn];


double r, R;


double distTo(Point a, Point p, Point q)
{
	return fabs((p - a) * (q - a) / p.distTo(q));
}


void makeConvex(vector<Point> & v)
{
	while(true)
	{
		bool found = false;
		for(int i = 0; i < (int)v.size() - 2; i++)
		{
			Point a = v[i];
			Point b = v[i + 1];
			Point c = v[i + 2];
			if(doubleLess(0, (b - a) * (c - b)))
			{
				found = true;
				double dist = distTo(b, a, c);
				Point diff = (c - a).rotate().norm(2 * dist);
				Point res = b + diff;
				if(!doubleEqual(dist, distTo(res, a, c)))
					res = b - diff;
				if(!doubleEqual(dist, distTo(res, a, c)))
					throw 42;
				v[i + 1] = res;
			}
		}
		if(!found)
			break;
	}
}


vector<pair<Point, double> > hull;


void solve(Point p, Point q)
{
	Point dir = (q - p).norm(1);
	Point a = p + dir * R;
	Point b = q - dir * R;
	double curR = R;
	vector<Point> left, right;
	while(true)
	{
		if(doubleEqual(a.distTo(b), 0))
			break;
		double d = 2 * curR + a.distTo(b);
		if(doubleLessOrEqual(2 * curR + 4 * r, d))
		{
			left.push_back(a + dir * r);
			right.push_back(b - dir * r);
			a = a + dir * 2 * r;
			b = b - dir * 2 * r;
		}
		else if(doubleEqual(d, 2 * curR + 2 * r))
		{
			left.push_back(a + dir * r);
			break;
		}
		else if(doubleLess(2 * curR + 2 * r, d))
		{
			double alpha = acos((d - 2 * r) / (2 * (curR + r)));
			Point c1 = a - dir * curR + dir.rotate(alpha).norm(curR + r);
			Point c2 = c1 + dir.norm(2 * r);
			left.push_back(c1);
			right.push_back(c2);
			break;
		}
		else
		{
			double alpha = acos(d / (2 * (curR + r)));
			Point c1 = a - dir * curR + dir.rotate(alpha).norm(curR + r);
			left.push_back(c1);
			break;
		}
		curR = r;
	}
	vector<Point> result;
	result.push_back(p);
	for(int i = 0; i < left.size(); i++)
		result.push_back(left[i]);
	for(int i = (int)right.size() - 1; i >= 0; i--)
		result.push_back(right[i]);
	result.push_back(q);
	makeConvex(result);
	/*for(int i = 0; i < result.size(); i++)
	{
		result[i].print();
	}*/
	for(int i = 1; i < (int)result.size() - 1; i++)
	{
		hull.push_back(make_pair(result[i], r));
	}
	hull.push_back(make_pair(q, R));
}


int norm(int a)
{
	return (a + hull.size()) % hull.size();
}


Point getInter(int a, int b)
{
	a = norm(a);
	b = norm(b);
	Point p = hull[a].first;
	Point q = hull[b].first;
	return p + (q - p).norm(hull[a].second);
}


double getAngle(Point p1, Point p2)
{
	double alpha = acos(p1 % p2 / p1.len() / p2.len());
	if(doubleLess(0, p1 * p2))
		alpha = 2 * PI - alpha;
	return alpha;
}


double getLen(int i)
{
	Point p1 = getInter(i, i - 1);
	Point p2 = getInter(i, i + 1);
	/*printf("\n");
	p1.print();
	p2.print();
	printf("\n");*/
	return getAngle(p1 - hull[i].first, p2 - hull[i].first) * hull[i].second;
}


int main()
{
	int n;
	scanf("%d", &n);
	for(int i = 0; i < n; i++)
	{
		p[i].scan();
	}
	p[n] = p[0];
	double res = 0;
	for(int i = 0; i < n; i++)
		res += p[i] * p[i + 1];
	if(!doubleLess(res, 0))
		throw 42;//printf("%lf\n", res);
	scanf("%lf%lf", &r, &R);
	for(int i = 0; i < n; i++)
	{
		solve(p[i], p[i + 1]);
	}
	double ans = 0;
	for(int i = 0; i < hull.size(); i++)
	{
		//hull[i].first.print();
		//printf("%lf\nlen: %lf\n", hull[i].second, getLen(i));
		ans += getLen(i);
	}
	printf("%d\n%lf\n", hull.size() - n, ans);
	return 0;
}