#include<iostream>
#include <deque>
using namespace std;
int main()
{
	//freopen("stdin","r",stdin);
	//freopen("stdout","w",stdout);
	int a;
	cin >> a;
	deque <int> d;
	while(a > 0){
		d.push_front(a%2);
		a /= 2;
	}
	for(int i = 0; i < d.size(); i++){
		cout << d[i];
	}
	return 0;
}
