#include <cstdio>
#include <cmath>
#include <cassert>
#include <algorithm>

#define eprintf(...) fprintf(stderr, __VA_ARGS__)


const double eps = 1e-9;
const int maxn = (int)1e5 + 123;
long double a[maxn], b[maxn], c[maxn];
long double mat[3][3];
long double temp[3][3];
long double res[3][3];

long double det(long double a, long double b, long double c, long double d) {
  return a * d - b * c;
}
int solve() {
  int n; 
  if (scanf("%d", &n) != 1) return 0;
  for (int i = 0; i < 3; i++) 
    for (int j = 0; j < 3; j++)
      res[i][j] = i == j;
     
  for (int i = 0; i < n; i++) {
    int x0, y0, x1, y1;
    scanf("%d%d%d%d", &x0, &y0, &x1, &y1);
    a[i] = y1 - y0;
    b[i] = x0 - x1;
    c[i] = - x0 * a[i] - y0 * b[i];
    //assert(a[i] * x0 + b[i] * y0 + c[i] == 0);
    //assert(a[i] * x1 + b[i] * y1 + c[i] == 0);
    long double len = sqrt(1. * a[i] * a[i] + 1. * b[i] * b[i]);
    a[i] /= len;
    b[i] /= len;
    c[i] /= len;
    long double a0 = -c[i] * a[i];
    long double b0 = -c[i] * b[i];
    mat[0][0] = 1 - a[i] * a[i];
    mat[0][1] = -a[i] * b[i];
    mat[0][2] = a0;
    mat[1][0] = - a[i] * b[i];
    mat[1][1] = 1 - b[i] * b[i];
    mat[1][2] = b0;
    mat[2][0] = 0;
    mat[2][1] = 0;
    mat[2][2] = 1;
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        temp[j][k] = 0;
        for (int l = 0; l < 3; l++) {
          temp[j][k] += mat[j][l] * res[l][k];
        }
      }
    } 
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        res[j][k] = temp[j][k];
      }
    }
    /*
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        eprintf("%lf%c", res[j][k], " \n"[k + 1 == 3]);
      }
    }
    eprintf("----\n");*/
  }
  for (int i = 0; i < 1; i++) {
    long double len = sqrt(1. * a[i] * a[i] + 1. * b[i] * b[i]);
    a[i] /= len;
    b[i] /= len;
    c[i] /= len;
    long double a0 = -c[i] * a[i];
    long double b0 = -c[i] * b[i];
    mat[0][0] = 1 - a[i] * a[i];
    mat[0][1] = -a[i] * b[i];
    mat[0][2] = a0;
    mat[1][0] = -a[i] * b[i];
    mat[1][1] = 1 - b[i] * b[i];
    mat[1][2] = b0;
    mat[2][0] = 0;
    mat[2][1] = 0;
    mat[2][2] = 1;
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        temp[j][k] = 0;
        for (int l = 0; l < 3; l++) {
          temp[j][k] += mat[j][l] * res[l][k];
        }
      }
    } 
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        res[j][k] = temp[j][k];
      }
    }
    /*
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        eprintf("%lf%c", res[j][k], " \n"[k + 1 == 3]);
      }
    }
    eprintf("----\n");*/
  }
  res[0][0] -= 1.;
  res[1][1] -= 1.;
  /*
  for (int j = 0; j < 3; j++) {
    for (int k = 0; k < 3; k++) {
      eprintf("%lf%c", res[j][k], " \n"[k + 1 == 3]);
    }
  }*/
  long double _det = det(res[0][0], res[0][1], res[1][0], res[1][1]);
  /*for (int i = 0; i < 2; i++) {
    eprintf("%lfx%+lfy=%lf\n", res[i][0], res[i][1], -res[i][2]);
  }*/
//  eprintf("det = %lf\n", _det);
  //eprintf("%lf\n", fabs(_det));
  if (fabs(_det) > eps) {
    long double x = -det(res[0][2], res[0][1], res[1][2], res[1][1]) / _det;
    long double y = -det(res[0][0], res[0][2], res[1][0], res[1][2]) / _det;
    long double x0 = x;
    long double y0 = y;
    /*assert(fabs(x * a[0] + y * b[0] + c[0]) < eps);

    for (int i = 1; i <= n; i++) {
      long double q = x0 * a[i % n] + y0 * b[i % n];
      x0 -= a[i % n] * q;
      y0 -= b[i % n] * q;
      x0 += -c[i % n] * a[i % n];
      y0 += -c[i % n] * b[i % n];
    } 
        eprintf("%lf %lf\n", x, y);
    eprintf("%lf %lf\n", x0, y0);
    assert(fabs(x - x0) < eps && fabs(y - y0) < eps);*/
    //assert(fabs(res[0][0] * x + res[0][1] * y + res[0][2]) < eps);
    // assert(fabs(res[1][0] * x + res[1][1] * y + res[1][2]) < eps);
    printf("%.20lf %.20lf\n", (double)x, (double)y);
  } else {
   // eprintf("2!!!!\n");
    /*int _i = 0;
    int _j = 0;
    for (int i = 0; i < 2; i++) {
      for (int j = 0; j < 2; j++) {
        if (fabs(res[i][j]) > fabs(res[_i][_j])) {
         _i = i;
          _j = j;
        }
      } 
    }
    if (j == 0) {
      x = (-res[_i][1] * y - res[_i][2])/ res[_i][0];
      y = 
    }   
    int ok = 1;
    for (int i = 0; i < 2; i++) {
      ok &= fabs(x * res[i][0] + y * res[i][1] + res[i][2]) < 1e-5;
    }*/
    int ok = 1;
    long double x = -a[0] * c[0];
    long double y = -b[0] * c[0];
    if (ok) {
      printf("%.20lf %.20lf\n", (double)x, (double)y);
    } else {
      printf("-1\n");
    }
  }
  return 1;
}
int main() {
  while(solve());
}