#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <math.h>

//#define _DEBUG
#define forn(i,n) for (int i=0;i<n;i++)
#define N 200000
#define LL long long
using namespace std;

int main()
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif

	int n;
	cin>>n;
	vector < vector <int> > gr(n);
	int a1,b1;
	forn(i,n-1)
	{
		cin>>a1>>b1;
		a1--;
		b1--;
		gr[a1].push_back(b1);
		gr[b1].push_back(a1);
	}

	vector <int> deq(n), dist(n,0);
	vector <int> par(n,-1);
	vector <bool> fl(n);

	deq[0]=0;
	fl[0]=1;

	int l=0,r=0,p,t;
	while (l<n)
	{
		p=deq[l];
		forn(i,gr[p].size())
		{
			t=gr[p][i];
			if  (fl[t])
				continue;
			fl[t]=1;
			par[t]=p;
			dist[t]=dist[p]+1;
			r++;
			deq[r]=t;
		}
		l++;
	}

	fl.assign(n,0);
	int m;
	cin>>m;

	LL res=0,add;

	forn(i,m)
	{
		cin>>a1;
		a1--;
		add=0;
		while (a1!=0 && fl[a1]==0){
			fl[a1]=1;
			a1=par[a1];
			add++;
		}
		cout<<(res+add-dist[a1]);
		if (i!=m-1)
			cout<<" ";
		res+=2*add;
	}

	return 0;
}