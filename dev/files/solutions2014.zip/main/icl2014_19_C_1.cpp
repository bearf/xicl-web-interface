#include <cstdio>

int d[123];

int main() {
  long long n;
  scanf("%lld", &n);
  for (int i = 0; i < 20; i++) {
    d[i] = n & 1;
    n >>= 1;
  }
  for (int i = 0; i < 20; ) {
    int j = i;
    if (d[i] == 0) {
      ++i;
      continue;
    }
    while (d[j] == 1) {
      ++j;
    }
    if (j - i == 1) {
      ++i;
      continue;
    }
    d[i] = -1;
    ++i;
    while (i < j) d[i++] = 0;
    d[j] = 1;
  }
  int lastone = 40;
  while (d[lastone] == 0) --lastone;
  for (int i = lastone; i >= 0; i--) printf("%d ", d[i]);
  puts("");
}