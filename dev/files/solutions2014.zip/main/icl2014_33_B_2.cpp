#include<iostream>
using namespace std;
__int64 ds[1000000][20];
int dz[1000000][20];
int main()
{
	const __int64 ir=1000000009;
	__int64 n,k;
	cin>>n>>k;
	for(int i=1; i<=n; i++)
	{
		dz[i][1]=1;
		if(i>1)
		ds[i][1]=dz[i-1][1]+dz[i][1];
		if(i<21)
			ds[i][i]=1;
	}
	for(int i=2; i<=n; i++)
		for(int j=2; j<=k; j++)
		{
			dz[i][j]=ds[i/2][j-1];
			ds[i][j]=ds[i-1][j]%ir+dz[i][j]%ir;
			ds[i][j]%=ir;
		}
		cout<<dz[n][k];
}