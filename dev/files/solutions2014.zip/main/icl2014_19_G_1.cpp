import java.io.*;
import java.util.*;

public class Solution {

	static List<Integer>[] edges;
	static int ctime;
	static int[] en;
	static int[] depth;
	static int[] ex;
	static int[] pv;
	static int[][] lca;

	static void dfs(int v, int p, int d) {
		en[v] = ctime++;
		depth[v] = d;
		pv[v] = p;
		for (int i = 0; i < edges[v].size(); i++) {
			int to = edges[v].get(i);
			if (to == p)
				continue;
			dfs(to, v, d + 1);
		}
		ex[v] = ctime;
	}

	static void solve() throws IOException {
		int n = nextInt();
		edges = new List[n];
		for (int i = 0; i < n; i++)
			edges[i] = new ArrayList<>();
		for (int i = 0; i < n - 1; i++) {
			int v = nextInt() - 1;
			int u = nextInt() - 1;
			edges[v].add(u);
			edges[u].add(v);
		}
		en = new int[n];
		ex = new int[n];
		pv = new int[n];
		depth = new int[n];
		dfs(0, -1, 0);
		lca = new int[20][n];
		for (int v = 0; v < n; v++) {
			lca[0][v] = pv[v] < 0 ? v : pv[v];
		}
		for (int i = 1; i < lca.length; i++) {
			for (int v = 0; v < n; v++) {
				lca[i][v] = lca[i - 1][lca[i - 1][v]];
			}
		}
		int[] vs = new int[n];
		for (int i = 0; i < n; i++)
			vs[en[i]] = i;
		int m = nextInt();
		NavigableSet<Integer> set = new TreeSet<>();
		set.add(en[0]);
		long ans = 0;
		Fenwick f = new Fenwick(n);
		f.add(en[0], 1);
		for (int i = 0; i < m; i++) {
			int v = nextInt() - 1;
			long curAns = ans;
			curAns += depth[v];
			if (f.get(en[v], ex[v]) > 0) {
				curAns -= depth[v];
			} else {
				int cur = v;
				for (int j = lca.length - 1; j >= 0; j--) {
					if (f.get(en[lca[j][cur]], ex[lca[j][cur]]) == 0) {
						cur = lca[j][cur];
					}
				}
				cur = pv[cur];
				curAns -= depth[cur];
				if (f.get(en[cur], en[cur] + 1) > 0) {
					f.add(en[cur], -1);
				}
				f.add(en[v], 1);
			}
			out.print(2 * curAns - depth[v] + " ");
			Integer prev = set.lower(en[v]);
			Integer next = set.higher(en[v]);
			if (prev != null && next != null) {
				ans += depth[lca(vs[prev], vs[next])];
			}
			if (prev != null) {
				ans -= depth[lca(vs[prev], v)];
			}
			if (next != null) {
				ans -= depth[lca(vs[next], v)];
			}
			ans += depth[v];
			set.add(en[v]);
		}
	}

	static class SegmentTree {
		int[] min;
		int n;

		public SegmentTree(int n) {
			this.n = Integer.highestOneBit(n) << 1;
			min = new int[this.n * 2];
		}

		void set(int x, int y) {
			x += n;
			min[x] = y;
			while (x > 1) {
				x >>= 1;
				min[x] = Math.min(min[x * 2], min[x * 2 + 1]);
			}
		}

		int getmin(int l, int r) {
			--r;
			l += n;
			r += n;
			int ret = Integer.MAX_VALUE;
			while (l <= r) {
				if ((l & 1) == 1) {
					ret = Math.min(ret, min[l++]);
				}
				if ((r & 1) == 0) {
					ret = Math.min(ret, min[r--]);
				}
				l >>= 1;
				r >>= 1;
			}
			return ret;
		}
	}

	static class Fenwick {
		int[] a;

		public Fenwick(int n) {
			a = new int[n];
		}

		void add(int x, int y) {
			for (int i = x; i < a.length; i |= i + 1) {
				a[i] += y;
			}
		}

		int get(int x) {
			int ret = 0;
			for (int i = x; i >= 0; i = (i & i + 1) - 1) {
				ret += a[i];
			}
			return ret;
		}

		int get(int l, int r) {
			return get(r - 1) - get(l - 1);
		}
	}

	static boolean anc(int v, int u) {
		return en[v] <= en[u] && ex[u] <= ex[v];
	}

	static int lca(int u, int v) {
		if (anc(u, v))
			return u;
		for (int i = lca.length - 1; i >= 0; i--) {
			if (!anc(lca[i][u], v))
				u = lca[i][u];
		}
		return pv[u];
	}

	public static void main(String[] args) throws IOException {
		File file = new File("g.in");
		InputStream input = System.in;
		if (file.canRead()) {
			input = new FileInputStream(file);
		}
		br = new BufferedReader(new InputStreamReader(input));
		out = new PrintWriter(System.out);
		solve();
		out.close();
		br.close();
	}

	static BufferedReader br;
	static PrintWriter out;
	static StringTokenizer st;

	static String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) {
			String line = br.readLine();
			if (line == null) {
				return null;
			}
			st = new StringTokenizer(line);
		}
		return st.nextToken();
	}

	static int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
}
