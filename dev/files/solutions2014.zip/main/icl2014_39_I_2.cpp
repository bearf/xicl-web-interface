#include <iostream>
#include<stdio.h>
using namespace std;
void main()
{

	int k=0, t=0;

	cin >> t;
	cin >> k;

	char str1[100000];
	cin >> str1;
	int b[100000], s[100000]={0};
	char str[1];
	for(int i=0; i<k ; i++)
	{
		str[0]=str1[i];
		b[i] = atoi(str);
	}

	for(int i = 0; i<t; i++)
	{
		for(int j=0; j<k; j++)
		{
			if(b[j]==1)
			{
				if(j-1>-1) { s[j-1]++; }
				if(j+1<k) { s[j+1]++;}
			}
		}
		for(int j=0; j<k; j++) 
		{ 
			if(s[j]==1) { b[j]=1; }
			else { b[j]=0; }
			s[j]=0;
		}
	}
	for(int i=0; i<k; i++)
	{
		printf("%d",b[i]);
	}
}