#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <map>
using namespace std;

map < int , int > m;
vector < int > v[100005];
int a[100005];
int srt[100005];
int n, ans;
int size;

bool cmp (int d1, int d2)
{
	return a[d1] < a[d2];
}

int getAns (int s)
{
	int minVal = v[s].front();
	int maxVal = v[s].back();

	int last = s + 1;
	int curAns = v[s].size();
	for ( ; last < n; last++)
	{
		if (v[last].front() < maxVal)
			break;
		maxVal = v[last].back();
		curAns += v[last].size();
	}
	last--;

	if (s != 0)
	{
		for (int i = 0; i < v[s - 1].size(); i++)
		{
			if (v[s - 1][i] > minVal)
				break;
			curAns++;
		}
	}

	if (last != n - 1)
	{
		for (int i = (int) v[last + 1].size() - 1; i >= 0; i--)
		{
			if (v[last + 1][i] < maxVal)
				break;
			curAns++;
		}
	}

	ans = min(ans, size - curAns);

	return last;
}

void getAnsPart (int l)
{
	int r = l + 1;

	ans = min(ans, size - (int) v[r].size() );

	for (int i = 0, j = 0; i < v[l].size(); i++)
	{
		int lVal = v[l][i];

		while (j < v[r].size() && v[r][j] < lVal)
			j++;

		ans = min(ans, size - (i + 1) - ( (int) v[r].size() - j) );
	}
}

int main ()
{
	//freopen("input.txt", "rt", stdin);
	//freopen("output.txt", "wt", stdout);

	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &a[i] );
	}

	for (int i = 0; i < n; i++)
		srt[i] = i;
	sort(srt, srt + n, cmp);
	int prv = -1;
	for (int i = 0; i < n; i++)
	{
		int cur = srt[i];
		if (a[cur] != prv)
		{
			int mSize = m.size();
			m[a[cur] ] = mSize;
			prv = a[cur];
		}
	}

	for (int i = 0; i < n; i++)
		a[i] = m[a[i] ];
	
	for (int i = 0; i < n; i++)
		v[a[i] ].push_back(i);

	ans = n;

	size = n;
	n = m.size();

	for (int i = 0; i < n; )
	{
		int last = getAns(i);
		i = last + 1;
	}

	for (int i = 0; i < n - 1; i++)
	{
		getAnsPart(i);
	}

	printf("%d", ans);

	return 0;
}