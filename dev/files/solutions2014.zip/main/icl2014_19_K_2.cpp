#include <cstdio>
#include <cmath>
#include <cassert>
#include <algorithm>

#define eprintf(...) fprintf(stderr, __VA_ARGS__)

const double eps = 1e-9;
const int maxn = (int)1e5 + 123;
double a[maxn], b[maxn], c[maxn];
double mat[3][3];
double temp[3][3];
double res[3][3];

double det(double a, double b, double c, double d) {
  return a * d - b * c;
}
int solve() {
  int n; 
  if (scanf("%d", &n) != 1) return 0;
  for (int i = 0; i < 3; i++) 
    for (int j = 0; j < 3; j++)
      res[i][j] = i == j;
     
  for (int i = 0; i < n; i++) {
    int x0, y0, x1, y1;
    scanf("%d%d%d%d", &x0, &y0, &x1, &y1);
    a[i] = y1 - y0;
    b[i] = x0 - x1;
    c[i] = - x0 * a[i] - y0 * b[i];
    assert(a[i] * x0 + b[i] * y0 + c[i] == 0);
    assert(a[i] * x1 + b[i] * y1 + c[i] == 0);
    double len = sqrt(1. * a[i] * a[i] + 1. * b[i] * b[i]);
    a[i] /= len;
    b[i] /= len;
    c[i] /= len;
    double a0 = -c[i] * a[i];
    double b0 = -c[i] * b[i];
    mat[0][0] = 1 - a[i] * a[i];
    mat[0][1] = -a[i] * b[i];
    mat[0][2] = a0;
    mat[1][0] = - a[i] * b[i];
    mat[1][1] = 1 - b[i] * b[i];
    mat[1][2] = b0;
    mat[2][0] = 0;
    mat[2][1] = 0;
    mat[2][2] = 1;
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        temp[j][k] = 0;
        for (int l = 0; l < 3; l++) {
          temp[j][k] += res[j][l] * mat[l][k];
        }
      }
    } 
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        res[j][k] = temp[j][k];
      }
    }
    /*
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        eprintf("%lf%c", res[j][k], " \n"[k + 1 == 3]);
      }
    }
    eprintf("----\n");*/
  }
  for (int i = 0; i < 1; i++) {
    double len = sqrt(1. * a[i] * a[i] + 1. * b[i] * b[i]);
    a[i] /= len;
    b[i] /= len;
    c[i] /= len;
    double a0 = -c[i] * a[i];
    double b0 = -c[i] * b[i];
    mat[0][0] = 1 - a[i] * a[i];
    mat[0][1] = -a[i] * b[i];
    mat[0][2] = a0;
    mat[1][0] = -a[i] * b[i];
    mat[1][1] = 1 - b[i] * b[i];
    mat[1][2] = b0;
    mat[2][0] = 0;
    mat[2][1] = 0;
    mat[2][2] = 1;
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        temp[j][k] = 0;
        for (int l = 0; l < 3; l++) {
          temp[j][k] += res[j][l] * mat[l][k];
        }
      }
    } 
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        res[j][k] = temp[j][k];
      }
    }
    /*
    for (int j = 0; j < 3; j++) {
      for (int k = 0; k < 3; k++) {
        eprintf("%lf%c", res[j][k], " \n"[k + 1 == 3]);
      }
    }
    eprintf("----\n");*/
  }
  res[0][0] -= 1.;
  res[1][1] -= 1.;
  /*
  for (int j = 0; j < 3; j++) {
    for (int k = 0; k < 3; k++) {
      eprintf("%lf%c", res[j][k], " \n"[k + 1 == 3]);
    }
  }*/
  double _det = det(res[0][0], res[0][1], res[1][0], res[1][1]);
  /*for (int i = 0; i < 2; i++) {
    eprintf("%lfx%+lfy=%lf\n", res[i][0], res[i][1], -res[i][2]);
  }*/
  //eprintf("det = %lf\n", _det);
  //eprintf("%lf\n", fabs(_det));
  if (fabs(_det) > eps) {
    double x = -det(res[0][2], res[0][1], res[1][2], res[1][1]) / _det;
    double y = -det(res[0][0], res[0][2], res[1][0], res[1][2]) / _det;
    //assert(fabs(res[0][0] * x + res[0][1] * y + res[0][2]) < eps);
    // assert(fabs(res[1][0] * x + res[1][1] * y + res[1][2]) < eps);
    printf("%.20lf %.20lf\n", x, y);
  } else {
    double x = 0. / 0.;
    double y = 1;
    for (int i = 0; i < 2; i++) {
      if (fabs(res[i][0]) > eps) {
        x = (- y * res[i][1] - res[i][2]) / res[i][0];
        break;
      }
    }
    if (x != x || y != y) {
      x = 1;
      y = 0. / 0.;
      for (int i = 0; i < 2; i++) {
        if (fabs(res[i][1]) > eps) {
          y = (-x * res[i][0] - res[i][2]) / res[i][1];
          break;
        }
      }
    }
    if (x != x || y != y) {
      x = -c[0] * a[0];
      y = -c[0] * b[0];
    }
    int ok = 1;
    for (int i = 0; i < 2; i++) {
      ok &= fabs(x * res[i][0] + y * res[i][1] + res[i][2]) < eps;
    }
    if (ok) {
      printf("%.20lf %.20lf\n", x, y);
    } else {
      printf("-1\n");
    }
  }
  return 1;
}
int main() {
  while(solve());
}