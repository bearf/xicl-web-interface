#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

#define f first
#define s second
#define next lkdsfgj

const int maxN = 100001;

int a[maxN];
vector<int> b[maxN];
int n, ans, kol;

void rec(int x, int ls, int s) {
	if (s > n)
		return;
	if (x > ans)
		return;
	if (s == n) {
		
		if (x < ans) {
			ans = x;
			kol = 1;
			b[0].resize(x);
			for (int i = 0; i < x; i++)
				b[0][i] = a[i];
		}
		else {
			kol++;
			b[kol - 1].resize(x);
			for (int i = 0; i < x; i++)
				b[kol - 1][i] = a[i];
		}
		return;
	}

	a[x] = ls;
	rec(x + 1, ls, s + ls);
	a[x] = s * 2 + 1;
	rec(x + 1, a[x], s * 3 + 1);
	a[x] = 0;
}
	
int main() {

	cin >> n;
	
	a[0] = 1;
	ans = n + 1;
	rec(1, 1, 1);
	
	
	cout << kol << ' ' << ans << endl;
	for (int i = 0; i < kol; i++) {
		for (int j = 0; j < ans; j++)
			cout << b[i][j] << ' ';
		cout << endl;
	}

	return 0;
}
