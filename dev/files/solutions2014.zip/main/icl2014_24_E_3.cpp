#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <math.h>

//#define _DEBUG
#define forn(i,n) for (int i=0;i<n;i++)
#define N 200000
using namespace std;

vector< pair<int, int>> a;
vector<int> pos, len, vals;

int main()
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
#endif
	int n;
	cin>>n;
	a.resize(n);
	pos.resize(n);
	len.resize(n);
	vals.resize(n);

	for(int i=0; i<n; ++i){ cin >> a[i].first; a[i].second = i; }
	stable_sort(a.begin(), a.end());


	for(int i=0; i<n; ++i) pos[a[i].second] = i;
	for(int i=0; i<n; ++i) vals[pos[i]] = i;

	for(int i=0; i<n; ++i){
		int cur = pos[i];
		if(cur > 0 && vals[cur - 1] < i) len[i] = len[vals[cur - 1]] + 1;
		else len[i] = 1;
	}
	int maxl = 0;
	for(int i=0; i<n; ++i) if(len[i] > maxl) maxl = len[i];
	cout << n - maxl;

	return 0;
}