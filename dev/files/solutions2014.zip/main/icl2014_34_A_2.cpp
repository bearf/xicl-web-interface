#include <iostream>
#include <algorithm>
#include <vector>
#include<cstdio>
#include <string>
using namespace std;

const int N = 1e5 + 100;
const int INF = 1e9;

int n;
int dp[N];
vector<pair<int, int> > par[N];

vector<int> cur_list;
vector<vector<int> > ans;

void put_ans(int sum)
{
	if (sum == n)
	{
		ans.push_back(cur_list);
		return;
	}

	for (int i = (int)par[sum].size() - 1; i >= 0; i--)
	{
		int num = par[sum][i].first;
		int cnt = par[sum][i].second;

		for (int j = 0; j < cnt; j++)
			cur_list.push_back(num);

		put_ans(sum + num * cnt);

		for (int j = 0; j < cnt; j++)
			cur_list.pop_back();
	}
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	cin >> n;
	for (int i = 0; i < N; i++)
		dp[i] = INF;

	dp[n] = 0;
	for (int k = n - 1; k >= 0; k--)
	{
		int t = 2 * k + 1;
		for (int i = 1; ; i ++)
		{
			int new_k = k + t * i;
			if (new_k > n)
				break;

			int new_dp = dp[new_k] + i;

			if (dp[k] > new_dp)
			{
				dp[k] = new_dp;
				par[k].clear();
			}

			if (dp[k] == new_dp)
				par[k].push_back(make_pair(t, i));
		}
	}

	put_ans(0);

	printf("%d %d\n", (int)ans.size(), dp[0]);
	for (int i = 0; i < (int)ans.size(); i++)
	{
		for (int j = 0; j < (int)ans[i].size(); j++)
			printf("%d ", ans[i][j]);
		printf("\n");
	}

	return 0;
}