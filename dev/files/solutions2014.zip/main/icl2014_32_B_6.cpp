#include <iostream>
#include <string>
#include <math.h>
#include <vector>
#include <stdio.h>
#include <stdlib.h>	
#include <algorithm>
using namespace std;
	int main() {
	int n,k;
	long long kol = 0;
	cin >> n>>k;
	if(k==1)
		kol = 1;
	else
		for (int i = n/(k-1) ;i<=n;i++)
			if(n-i<=i && n-i>=k-1)
			{
					kol++;
			}
		cout<<kol;
		return 0;
	}