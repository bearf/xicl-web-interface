#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <ctime>

using namespace std;

typedef long double ld;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<long long> vll;

#define mp make_pair
#define pb push_back
#define sz(x) ((int)(x).size())
#define EPS (1e-9)
#define INF ((int)1e9)
#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define TASK "text"

vector<vector<int> > es;
int n;

vector<vector<int> > v;
const int maxk = 18, maxn = (1 << maxk);
int getBack[1 << maxk];

int its[maxn];

vector<int> ans;

void dfs(int v) {
	for (int &it = its[v]; it < sz(es[v]);) {
	 	int u = es[v][it++];
	 	dfs(u);
		ans.pb(getBack[v ^ u]);
	}
}

int solve() {
	int k;
	if (scanf("%d", &k) < 1)
		return 0;
	n = (1 << k);
	es = vector<vector<int> >(n);
	for (int mask = 0; mask < n; ++mask) {
		its[mask] = 0;
		getBack[mask] = -1;
		for (int i = 0; i < k; ++i) {
			int nmask = (mask ^ (1 << i));
			es[mask].pb(nmask);
		}
	}

	for (int i = 0; i < k; ++i)
		getBack[1 << i] = i;
    
    ans.clear();
    dfs(0);

    printf("%d\n", sz(ans));
    for (int i = 0; i < sz(ans); ++i)
    	printf("%d%c", ans[i] + 1, " \n"[i == sz(ans) - 1]);
	return 1;
}

int main() {
#ifdef DEBUG
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	
	int n;
	while (1) {
		if (!solve())
			break;
		#ifdef DEBUG
		eprintf("%.18lf\n", (double)clock() / CLOCKS_PER_SEC);		
		#endif
	}
	return 0;
}
