#pragma comment(linker, "/STACK:268435456")

#include <iostream>
#include <iomanip>

#include <vector>
#include <string>
#include <deque>
#include <queue>
#include <set>
#include <map>

#include <algorithm>

#include <cstdio>
#include <cstdlib>
#include <complex>
#include <ctime>
#include <cstring>
#include <cassert>

using namespace std;

#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define ford(i,n) for (int i = int(n) - 1; i >= 0; --i)

#define pb push_back
#define mp make_pair
#define fs first
#define sc second
#define all(a) (a).begin(), (a).end()
#define sz(a) int((a).size())

#ifdef SG
    #define debug(x) cerr << #x << ": " << (x) << endl
#else
    #define debug(x)
#endif

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

template <typename T>
ostream & operator << (ostream & out, vector<T> const & a) {
    out << "[";
    for (int i = 0; i < sz(a); ++i) {
        if (i != 0) {
            out << ", ";
        }
        out << a[i];
    }
    out << "]";
    return out;
}

template <typename T1, typename T2>
ostream & operator << (ostream & out, pair<T1, T2> const & p) {
    out << "(" << p.fs << ", " << p.sc << ")";
    return out;
}

typedef pair<int, int> point;
#define x first
#define y second

point operator + (const point &a, const point &b) {
    return point(a.x + b.x, a.y + b.y);
}

point operator - (const point &a, const point &b) {
    return point(a.x - b.x, a.y - b.y);
}

point operator * (const point &a, int b) {
    return point(a.x * b, a.y * b);
}

int operator * (const point &a, const point &b) {
    return a.x * b.x + a.y * b.y;
}

int operator ^ (const point &a, const point &b) {
    return a.x * b.y - a.y * b.x;
}

const int N = 10000;

struct Data {
    int n;

    pair<point, point> p[N];

    bool read () {
        if (!(cin >> n)) {
            return 0;
        }
        forn (i, n) {
            scanf("%d%d%d%d", &p[i].fs.x, &p[i].fs.y, &p[i].sc.x, &p[i].sc.y);
        }
        return 1;
    }

    bool res;
    pair<ld, ld> ans;

    void write () {
        if (!res) {
            puts("-1");
            return;
        }
        cout.precision(20);
        cout.setf(ios::fixed | ios::showpoint);
        cout << ans.x << ' ' << ans.y << endl;
    }

    virtual void solve () {
    }

    virtual void clear () {
        *this = Data();
    }
};

struct Solution: Data {
    ld prj (const point &a, const point &b, const point &c) {
        return ld((a - b) * (c - b)) / ((c - b) * (c - b));
    }

    void solve () {
        {
            bool par = 1;
            forn (i, n) {
                if ((p[i].sc - p[i].fs) ^ (p[0].sc - p[0].fs)) {
                    par = 0;
                    break;
                }
            }
            if (par) {
                res = 0;
                return;
            }
            res = 1;
        }
        ld a = 1, b = 0;
        forn (i, n) {
            ld b1 = prj(p[i].fs, p[(i + 1) % n].fs, p[(i + 1) % n].sc);
            ld a1 = prj(p[i].sc, p[(i + 1) % n].fs, p[(i + 1) % n].sc) - b1;
            b = a1 * b + b1;
            a = a1 * a;
        }
        ld alpha = b / (1 - a);
        debug(alpha);
        ans.x = alpha * (p[0].sc.x - p[0].fs.x) + p[0].fs.x;
        ans.y = alpha * (p[0].sc.y - p[0].fs.y) + p[0].fs.y;
    }

    Solution (Data d = Data()): Data(d) {}

    void clear () {
        *this = Solution();
    }
};

Solution sol;
int main () {
#ifdef SG
    freopen("k.in", "r", stdin);
//    freopen("", "w", stdout);
    while (sol.read()) {
        sol.solve();
        sol.write();
        sol.clear();
    }
#else
//    freopen("", "r", stdin);
//    freopen("", "w", stdout);
    sol.read();
    sol.solve();
    sol.write();    
#endif

    return 0;
}
