#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

const int con = 62;

int b[100];
ll st[100];
ll n;

int main() {

	cin >> n;

	st[0] = 1;
    for (int i = 1; i <= con; i++)
        st[i] = st[i - 1] * 2;

	for (int i = con; i >= 0; i--) {
		if (n >= st[i]) {
			b[i] = 1;
			n -= st[i];
		}
	}

	for (int i = 0; i < con; i++) {
		if (b[i] > 1) {
			b[i] -= 2;
			b[i + 1]++;
		}
		if (b[i] == 1 && b[i + 1] == 1) {
			b[i] = -1;
			b[i + 1] = 0;
			b[i + 2] += 1;
		}
		if (b[i] == -1 && b[i + 1] == -1) {
			b[i] = 1;
			b[i + 1] = 0;
			b[i + 2]--;
		}
	}


	bool bl = false;
	for (int i = con + 3; i >=0; i--) {
		if (b[i] != 0) {
			bl = true;
			cout << b[i] << ' ';
		}
		else
			if (bl)
				cout << 0 << ' ';
	}

	return 0;
}
