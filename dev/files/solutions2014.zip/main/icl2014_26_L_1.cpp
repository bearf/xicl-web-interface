#include<iostream>
#include <deque>
using namespace std;
int main()
{
	int n;
	cin >> n;
	int a[22][22];
	int z=0,ans=0;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
		{
			cin>>a[i][j];
			ans+=a[i][j];
			if(!a[i][j])
				z++;
		}
	if(z>n*n-z)
	{
		cout<<-1;
		return 0;
	}
	cout<<ans<<endl;
	return 0;
}
