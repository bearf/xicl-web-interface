
#include <cstdio>
#include <iostream>

using namespace std;

int d[123];
const int CO = 70;

int main() {
  long long n;
  cin >> n;
  for (int i = 0; i < CO; i++) {
    d[i] = n & 1;
    n >>= 1;
  }
  for (int i = 0; i < CO; ) {
    int j = i;
    if (d[i] == 0) {
      ++i;
      continue;
    }
    while (d[j] == 1) {
      ++j;
    }
    if (j - i == 1) {
      ++i;
      continue;
    }
    d[i] = -1;
    ++i;
    while (i < j) d[i++] = 0;
    d[j] = 1;
  }
  int lastone = CO;
  while (d[lastone] == 0) --lastone;
  for (int i = lastone; i >= 0; i--) printf("%d ", d[i]);
  puts("");
}