#define MAXN 300000
#define INF 1E+9
#define EPS 1E-9 
#define PROB "a"

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <string>
#include <cstring>
#include <cmath>
#include <set>
#include <map>

#define itset set<pair <int, int>>::iterator

using namespace std;

int n;
map <int, int > st;



	int f(vector <int> a, vector <int> b){
		st.clear();
		int i = 0, j = 0, r = 0;

		for (i = 0; i < n && j < n; ++i){
			while (st[b[j]] > 0)  {
				--st[b[j]];
				++j;
			}

			if (a[i] == b[j]) {
				++j;
				
			}else {
				++st[a[i]];
				++r;
			}	
		}
		return r;
	}
	
int main(){
	
	vector <int> a, b;
	
	
	int k;
	

	scanf ("%d", &n);

	for (int i = 0; i < n; ++i){
		scanf ("%d", &k);

		a.push_back(k);
	}
	b = a;
	sort (a.begin(), a.end());
	
	printf ("%d", min (f(a, b), f(b, a)));


	return 0;
}