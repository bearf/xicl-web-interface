#include <iostream>
using namespace std;

long long n, k, i, j, a[1000005][30], mod = 1e9 + 9;

int main(){
	cin >> n >> k;
	for (i = 1; i <= n; i++) a[i][1] = 1;
	a[2][2] = 1;
	for (j = 2; j <= k; j++){
		for (i = j + 1; i <= n; i++){
			long long l = (i + 1) / 2, r = i - j + 1, llast = i / 2;
			if (i - l > (i - 1) - llast) a[i][j] = (a[i - 1][j] + a[i - l][j - 1]) % mod;
			else a[i][j] = a[i - 1][j];
		}
	}
	/*for (i = 1; i <= n; i++){
		for (j = 1; j <= k; j++) cout << a[i][j] << " ";
		cout << endl;
	}*/
	cout << a[n][k];
}