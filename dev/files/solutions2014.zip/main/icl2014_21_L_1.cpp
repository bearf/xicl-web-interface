#ifdef SU2_PROJ
#define _GLIBCXX_DEBUG
#endif

#include <algorithm>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <string>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define forn(i, n) for (int i = 0; i < int(n); i++)
#define forl(i, n) for (int i = 1; i <= int(n); i++)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; i--)
#define fore(i, l, r) for (int i = int(l); i <= int(r); i++)
#define correct(x, y, n, m) (0 <= (x) && (x) < (n) && 0 <= (y) && (y) < (m))
#define pb(a) push_back(a)
#define all(a) (a).begin(), (a).end()
#define mp(x, y) make_pair((x), (y))
#define ft first
#define sc second
#define x first
#define y second

using namespace std;

typedef long long li;
typedef long double ld;
typedef pair <int, int> pt;

inline ostream& operator << (ostream& out, const pt& p) { return out << "(" << p.x << ", " << p.y << ")"; }

const int INF = int(1e9);
const li INF64 = li(1e18);
const ld EPS = 1e-9;
//const ld PI = acos(-1);

const int N = 20 + 3;

int n;
int a[N][N];

inline bool read ()
{
	if (scanf("%d", &n) != 1) return false;
	
	forn(i, n)
		forn(j, n)
			assert(scanf("%d", &a[i][j]) == 1);
	
	return true;
}

inline void solve ()
{
	int cntNot0 = 0;
	int cnt0 = 0;
	int sum = 0;
	
	forn(i, n)
		forn(j, n)
		{
			if (a[i][j] != 0)
			{
				cntNot0++;
				sum += a[i][j];
			}
			else
				cnt0++;
		}
		
	if (cntNot0 >= cnt0)
	{
		cout << sum << endl;
	}
	else
		cout << -1 << endl;
}

int main()
{
	//freopen("input.txt", "rt", stdin);
	//freopen("output.txt", "wt", stdout);

	cout << setprecision(10) << fixed;
	cerr << setprecision(5) << fixed;
	
	assert(read());
	solve();
	
//#ifdef SU2_PROJ
	//cerr << "=== Time: " << clock() << " ===" << endl;
//#endif

	return 0;
}
