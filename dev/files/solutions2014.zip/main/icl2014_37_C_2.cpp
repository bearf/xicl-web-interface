#include <iostream>
#include <math.h>
using namespace std;


int main()
{
	_int64 n;
	cin >> n;
	int p = (int) (log((double)n) / log(2.0));
	int koef[60];

	int s;

	s = (int) pow(2.0, (double)p);
	int lastKoef = 1;
	koef[p] = 1;
	for (int i = p - 1; i >= 0; i--)
	{
		if ((int) pow(2.0, (double)i) > abs(s-n) || lastKoef != 0)
		{
			lastKoef = 0;
			koef[i] = 0;
		}
		else
		{
			if (s > n)
			{
				lastKoef = -1;
				s -= (int) pow(2.0, (double)i);
				koef[i] = -1;
			}
			else
			{
				lastKoef = 1;
				s += (int) pow(2.0, (double)i);
				koef[i] = 1;
			}
		}
	}
	if (s == n)
	{
		for (int i = p; i >= 0; i--)
			cout << koef[i] << " ";
		return 0;
	}

	p++;
	s = (int) pow(2.0, (double)p);
	lastKoef = 1;
	koef[p] = 1;
	for (int i = p - 1; i >= 0; i--)
	{
		if ((int) pow(2.0, (double)i) > abs(s-n) || lastKoef != 0)
		{
			lastKoef = 0;
			koef[i] = 0;
		}
		else
		{
			if (s > n)
			{
				lastKoef = -1;
				s -= (int) pow(2.0, (double)i);
				koef[i] = -1;
			}
			else
			{
				lastKoef = 1;
				s += (int) pow(2.0, (double)i);
				koef[i] = 1;
			}
		}
	}
	for (int i = p; i >= 0; i--)
		cout << koef[i] << " ";
	return 0;
}