#include <iostream>
#include <cmath>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
using namespace std;

#if LOCAL
	#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
	#define eprintf(...) 42;
#endif

#define sqr(x) ((x) * (x))

const double EPS = 1e-7;

class Number {
public:
	double x;
	double y;
	double c;

	Number() {
	};

	Number(double x, double y, double c) {
		this->x = x;
		this->y = y;
		this->c = c;
	}
};

inline Number operator + (const Number &a, const Number &b) {
	return Number(a.x + b.x, a.y + b.y, a.c + b.c);
}

inline Number operator - (const Number &a, const Number &b) {
	return Number(a.x - b.x, a.y - b.y, a.c - b.c);
}

inline Number operator - (const Number &a) {
	return Number(-a.x, -a.y, -a.c);
}

inline Number operator * (const Number &a, double k) {
	return Number(a.x * k, a.y * k, a.c * k);
}

inline Number operator / (const Number &a, double k) {
	return Number(a.x / k, a.y / k, a.c / k);
}

class Line {
public:
	double A;
	double B;
	Number C;
	
	Line() {
	};

	inline Line(double x1, double y1, double x2, double y2) {
		A = y2 - y1;
		B = x1 - x2;
		C = Number(0, 0, -(A * x1 + B * y1));
	}

	inline Line(double A, double B, const Number &C) {
		this->A = A;
		this->B = B;
		this->C = C;
	}

	inline bool cross(const Line &ln, Number &x, Number &y) {
		eprintf("crossing A = %.3lf B = %.3lf C = (%.3lf %.3lf %.3lf)\n", A, B, C.x, C.y, C.c);
		eprintf("and A = %.3lf B = %.3lf C = (%.3lf %.3lf %.3lf)\n", ln.A, ln.B, ln.C.x, ln.C.y, ln.C.c);
		double d = A * ln.B - ln.A * B;
		if (fabs(d) < EPS) {
			return false;
		}
		x = (ln.C * B - C * ln.B) / d;
		y = (C * ln.A - ln.C * A) / d;
		eprintf("result\n");
		eprintf("x = (%.3lf %.3lf %.3lf)\n", x.x, x.y, x.c);
		eprintf("y = (%.3lf %.3lf %.3lf)\n", y.x, y.y, y.c);
		return true;
	}

	inline Line getPerp(const Number &x, const Number &y) const {
		Number CC = -(x * (-B) + y * (A));
		return Line(-B, A, CC);
	}

	inline double eval(double x, double y) {
		return A * x + B * y + C.c;
	}
};

int n;
Line lines[11111];

inline bool solve(const Number &cx, const Number &cy, double A, double B, double C, double &x, double &y) {
	double a[3][3];
	a[0][0] = 1 - cx.x;
	a[0][1] = -cx.y;
	a[0][2] = cx.c;
	a[1][0] = -cy.x;
	a[1][1] = 1 - cy.y;
	a[1][2] = cy.c;
	a[2][0] = A;
	a[2][1] = B;
	a[2][2] = -C;
	bool ok[2] = {false, false};
	for (int i = 0; i < 3; i++) {
		int jj = -1;
		for (int j = 0; j < 2; j++) {
			if (fabs(a[i][j]) > EPS) {
				jj = j;
				break;
			}
		}
		if (jj == -1) {
			if (fabs(a[i][2]) > EPS) {
				return false;
			}
			continue;
		}
		ok[jj] = true;
		double pivot = a[i][jj];
		for (int j = 0; j < 3; j++) {
			a[i][j] /= pivot;
		}
		for (int ii = 0; ii < 3; ii++) {
			if (i == ii) {
				continue;
			}
			pivot = a[ii][jj];
			for (int j = 0; j < 3; j++) {
				a[ii][j] -= a[i][j] * pivot;
			}
		}
	}
	double val[2] = {0, 0};
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 2; j++) {
			if (fabs(a[i][j]) > EPS && ok[j]) {
				val[j] = a[i][2] / a[i][j];
				break;
			}
		}
	}
	x = val[0];
	y = val[1];
	return true;
}

void solve() {
	Number cx(1, 0, 0);
	Number cy(0, 1, 0);
	for (int i = 0; i < n; i++) {
		eprintf("!!! %d\n", i);
		Line tmp = lines[(i + 1) % n].getPerp(cx, cy);
		eprintf("tmp: A = %.3lf B = %.3lf C = (%.3lf %.3lf %.3lf)\n", tmp.A, tmp.B, tmp.C.x, tmp.C.y, tmp.C.c);
		Number nx, ny;
		assert(tmp.cross(lines[(i + 1) % n], nx, ny));
		eprintf("nx = (%.3lf %.3lf %.3lf)\n", nx.x, nx.y, nx.c);
		eprintf("ny = (%.3lf %.3lf %.3lf)\n", ny.x, ny.y, ny.c);
		cx = nx;
		cy = ny;
	}
	eprintf("x = (%.3lf %.3lf %.3lf)\n", cx.x, cx.y, cx.c);
	eprintf("y = (%.3lf %.3lf %.3lf)\n", cy.x, cy.y, cy.c);
	double x, y;
	if (!solve(cx, cy, lines[0].A, lines[0].B, lines[0].C.c, x, y)) {
		puts("-1");
	} else {
		assert(fabs(lines[0].eval(x, y)) < EPS);
		printf("%.8lf %.8lf\n", x, y);
	}
}
	
int main() {
#ifdef LOCAL
	freopen("k.in", "r", stdin);
#endif
	scanf("%d", &n);
	int x1, y1, x2, y2;
	for (int i = 0; i < n; i++) {
		scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
		lines[i] = Line(x1, y1, x2, y2);
	}
	solve();
	return 0;
}