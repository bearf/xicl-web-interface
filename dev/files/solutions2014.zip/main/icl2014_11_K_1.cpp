#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <queue>
#include <deque>
#include <complex>

using namespace std;

#define pb push_back
#define pbk pop_back
#define all(x) (x).begin(), (x).end()
#define fs first
#define sc second
#define y0 yy0
#define y1 yy1
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define prev _prev
#define rank _rank
#define link _link
#define hash _hash
#ifdef LOCAL
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef complex<double> tc;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));

struct vt
{
	double x, y;
	vt(double _x, double _y)
	{
		x = _x, y = _y;
	}
	friend vt operator +(vt a, vt b)
	{
		return vt(a.x + b.x, a.y + b.y);
	}
	friend vt operator -(vt a, vt b)
	{
		return vt(a.x - b.x, a.y - b.y);
	}
	friend double operator *(vt a, vt b)
	{
		return a.x * b.x + a.y * b.y;
	}
	friend double operator ^(vt a, vt b)
	{
		return a.x * b.y - b.x * a.y;
	}
	double abs()
	{
		return sqrt(x * x + y * y);
	}
	friend vt operator /(vt a, double k)
	{
		return vt(a.x / k, a.y / k);
	}
	friend vt operator *(vt a, double k)
	{
		return vt(a.x * k, a.y * k);
	}
	vt norm()
	{
		return vt(x, y) / abs();
	}
	friend vt operator ~(vt v)
	{
		return vt(-v.y, v.x);
	}
	vt(){}
};

const int N = 10500;

vt A[N], B[N];

int n;
const int IT = 300;

vt walk(vt x)
{
	A[n] = A[0];
	B[n] = B[0];
	for (int i = 1; i <= n; i++)
	{
		x = x + (~(B[i] - A[i])) * ((x - A[i]) ^ (B[i] - A[i]));
	}
	return x;
}

int main() {
#ifdef LOCAL
#define TASK "K"
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%lf %lf %lf %lf", &A[i].x, &A[i].y, &B[i].x, &B[i].y);
		vt v = B[i] - A[i];
		B[i] = A[i] + v.norm();
	}
	/*n = 10000;
	for (int i = 0; i < n; i++)
	{
		here:
		A[i] = vt(rand() % 201 - 100, rand() % 201 - 100);
		B[i] = vt(rand() % 201 - 100, rand() % 201 - 100);
		if ((A[i] - B[i]).abs() < 1e-2)
			goto here;
		B[i] = A[i] + (B[i] - A[i]).norm();
	}*/
	const double inf = 1e5;
	swap(A[0], B[0]);
	for (int it = 0; it < 2; it++)
	{
		double l = -inf, r = inf;
		for (int bit = 0; bit < IT; bit++)
		{
			double m = (l + r) / 2;
			vt x = (A[0] + (B[0] - A[0]) * m);
			vt y = walk(x);
			if ((y - x) * (B[0] - A[0]) > 0)
				l = m;
			else
				r = m;
		}
		vt x = A[0] + (B[0] - A[0]) * l;
		vt y = walk(x);
		if ((x - y).abs() < 1e-6)
		{
			printf("%.6lf %.6lf", x.x, x.y); 
			return 0;
		}
		swap(A[0], B[0]);
	}
	printf("-1");
	return 0;
}
