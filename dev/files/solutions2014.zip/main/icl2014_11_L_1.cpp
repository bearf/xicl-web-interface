#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <queue>
#include <deque>
#include <complex>

using namespace std;

#define pb push_back
#define pbk pop_back
#define all(x) (x).begin(), (x).end()
#define fs first
#define sc second
#define y0 yy0
#define y1 yy1
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define prev _prev
#define rank _rank
#define link _link
#define hash _hash
#ifdef LOCAL
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef complex<double> tc;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));

const int N = 20;
int A[N][N];

int main() {
#ifdef LOCAL
#define TASK "L"
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	int n;
	scanf("%d", &n);
	int sum = 0;
	int cnt = 0;
	int fr = 0;
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			scanf("%d", &A[i][j]), sum += A[i][j], fr += !A[i][j], cnt += !!A[i][j];
	int ans;
	if (cnt >= fr)
		ans = sum;
	else
		ans = -1;
	printf("%d", ans);
	return 0;
}
