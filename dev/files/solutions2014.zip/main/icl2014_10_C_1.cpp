#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <vector>

using namespace std;
typedef unsigned long long ull;

int main() {
	ull n;
	cin >> n;

	int len = 0;

	for (int i = 8 * sizeof(ull) - 2; i >= 0; i--) {
		bool is_one = (n & (1ULL << i)) != 0;

		if (is_one) {
			len = i;
			break;
		}
	}
	
	vector<int> res;
	for (int i = 0; i <= len; i++) {
		bool is_next_one;
		if (i != len )
			is_next_one = ((n & (1ULL << (i+1))) != 0);

		bool is_prev_one;
		if (i != 0)
			is_prev_one = ((n & (1ULL << (i-1))) != 0);

		bool is_one = ((n & (1ULL << i)) != 0);

		if (!is_one) {
			if (i != 0 && is_prev_one) {
				res.push_back(1);
			} else {
				res.push_back(0);
			}
			
		} else {
			if ((i == 0 || !is_prev_one) && (i == len || !is_next_one)) {
				res.push_back(1);
			} else {
				if (i != 0 && is_prev_one) {
					res.push_back(0);
					
				} else {
					res.push_back(-1);
				}
			}
		}
	}

	bool is_prev_one = ((n & (1ULL << (len))) != 0);

	bool is_prevprev_one;
	if (len >= 1)
		is_prevprev_one = ((n & (1ULL << (len-1))) != 0);

	if (is_prev_one && (len >= 1 && is_prevprev_one))
		res.push_back(1);

	for (int i = res.size() - 1; i >= 0; i--) {
		cout << res[i] << " ";
	}



	

	return 0;
}