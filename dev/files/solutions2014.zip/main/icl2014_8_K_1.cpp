#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

#define M 1000100
#define K 20

typedef long long ll;
typedef long long li;

void Solve(void);

int main(){

#ifdef BANANA_MOTEL
	freopen("test.in", "r", stdin);
	freopen("test.out", "w", stdout);
#else
#endif
	Solve();
	return 0;
}

struct point
{
	int x, y;
	point() : x(0), y(0) {}
	point(int x, int y) : x(x), y(y) {}
};

int n;
point a[10100][2];

const long double eps = 1e-9;

int cross(const point &a, const point &b) { return (a.x * b.x + a.y * b.y); }

long double count(long double st)
{
	for (int i = 0; i < n; i++)
	{
		st = st * cross(a[i + 1][1], a[i][1]) + cross(a[i + 1][1], point(a[i][0].x - a[i + 1][0].x, a[i][0].y - a[i + 1][0].y));
		st /= cross(a[i + 1][1], a[i + 1][1]);
	}
	return st;
}

void Solve()
{
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%d%d%d%d", &a[i][0].x, &a[i][0].y, &a[i][1].x, &a[i][1].y);
		a[i][1].x -= a[i][0].x; a[i][1].y -= a[i][0].y;
	}
	a[n][0] = a[0][0], a[n][1] = a[0][1];
	long double lt = count(0), rt = count(1), res;
	if (fabsl(rt - lt - 1) <= eps)
	{
		if (fabsl(lt) <= eps) res = lt;
		else { cout << -1 << endl; return; }
	}
	else res = -lt / (rt - lt - 1);
	long double ax = res * a[0][1].x + a[0][0].x, ay = res * a[0][1].y + a[0][0].y;
	cout.precision(5);
	cout << fixed << ax << ' ' << ay << endl;
}