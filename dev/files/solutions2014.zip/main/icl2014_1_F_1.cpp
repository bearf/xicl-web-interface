#include<iostream>
#include<vector>

using namespace std;

vector<int> s[20][20];

vector<int> fnd(int n, int k)
{
	vector<int> v;
	if ((n == 1) && (k == 1))
	{
		v.push_back(1);
		//v.push_back(1);
	}
	else
	{
		if (n == k)
		{
			int m = s[n - 1][n - 1].size();

			for (int i = 0; i < m; i++)
			{
				v.push_back(s[n - 1][n - 1][i]);
			}

			v.push_back(n);

			for (int i = 0; i < m; i++)
			{
				v.push_back(s[n - 1][n - 1][i]);
			}
		}
		else
		{
			int m = s[n][n].size();

			for (int i = 0; i < m; i++)
			{
				if ((s[n][n][i] + k) % n == 0)
				{
					v.push_back(n);
				}
				else
				{
					v.push_back((s[n][n][i] + k) % n);
				}
			}
		}
	}

	return v;
}

void prnt(int n, int k)
{
	int m = s[n][k].size();

	for (int i = 0; i < m; i++)
	{
		cout << s[n][k][i] << ' ';
	}
}

int main()
{
	int n;
	cin >> n;
	
	for (int i = 1; i <= n; i++)
	{
		s[i][i] = fnd(i, i);

		for (int j = 1; j <= n; j++)
		{
			if (j != i)
			{
				s[i][j] = fnd(i, j);
			}
		}
	}
	
	int m = (1 << n);
	cout << (m * n) << '\n';

	for (int i = 1; i <= n; i++)
	{
		cout << i << ' ';
		prnt(n, i);
	}

	//prnt(2, 1);
	//cin >> n;
	return 0;
}