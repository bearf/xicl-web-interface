#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <math.h>

//#define _DEBUG
#define forn(i,n) for (int i=0;i<n;i++)
#define N 200000
using namespace std;

pair<int, int> a[N];
int pos[N];
int prev[N];
int len[N];

int main()
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
#endif
	int n;
	cin>>n;
	for(int i=0; i<n; ++i){ cin >> a[i].first; a[i].second = i; }
	stable_sort(a, a + n);

	for(int i=0; i<n; ++i) pos[a[i].second] = i;
	for(int i=0; i<n; ++i){
		int cur = a[i].second;
		if(cur > 0 && pos[cur - 1] < i) len[i] = len[pos[cur - 1]] + 1;
		else len[i] = 1;
	}
	int maxl = 0;
	for(int i=0; i<n; ++i) if(len[i] > maxl) maxl = len[i];
	cout << n - maxl;

	return 0;
}