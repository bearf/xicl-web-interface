#pragma comment(linker, "/STACK:256000000")
#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <algorithm>
using namespace std;
//const int b=1000000009;
typedef long long ll; 
vector<int> f(ll n, int &len){
	vector<int> res;
	int c=0;
	ll h = n;
	while(h){
		h/=2;
		c++;
	}
	ll s = (1ll << (c-1));
	vector<int> a1,a2;
	int len1,len2;
	if(n == s){
		res.resize(c);
		res[0] = 1;
		len = c;
		return res;
	}
	a1 = f(n-s, len1);
	
	if(len1 <= c - 2){
		//1
		res.resize(c,0);
		res[0] = 1;
		for(int i=0;i<len1;i++)
			res[c - len1 + i] = a1[i];
	}
	else{
		//2
		a2 = f(s*2 - n, len2);
		if(len2 > c - 1){
			len = 1000000;
			return res;
		}	
		c++;
		res.resize(c,0);
		res[0] = 1;
		for(int i=0;i<len2;i++)
			res[c - len2 + i] = -a2[i];
	}
	len = c;
	//if(n==0){
	//	res.push_back(0);
	//	return res;
	//}
	//if(n==1){
	//	res.push_back(1);
	//	return res;
	//}
	//if(n==2){
	//	res.push_back(1);
	//	res.push_back(0);
	//	return res;
	//}
	//if(n==3){
	//	res.push_back(1);
	//	res.push_back(0);
	//	res.push_back(-1);
	//	return res;
	//}
	//if(n==4){
	//	res.push_back(1);
	//	res.push_back(0);
	//	res.push_back(0);
	//	return res;
	//}
	//if(n==5){
	//	res.push_back(1);
	//	res.push_back(0);
	//	res.push_back(1);
	//	return res;
	//}
	//ll h=n;
	//ll c=0;
//	while(h){
////		res.push_back(h%2);
//		h/=2;
//		c++;
//	}
	//ll s = (1ll << (c-1));
	//if (n-s <= 5)
	//{
	//	//+
	//	//
	//	res.push_back(1);
	//	res.push_back(0);
	//	vector<int> p;
	//	p = f(n-s);
	//	for(int i=0;i<p.size();i++)
	//		res.push_back(p[0]);
	//}
	//else
	//{
	//	//-
	//	res.push_back(1);
	//	res.push_back(0);
	//	vector<int> p;
	//	p = f(s*2 - n);
	//	for(int i=0;i<p.size();i++)
	//		res.push_back(-p[0]);
	//}
	return res;
}

int main(){
	//freopen("1.txt","r",stdin);
	ll n;
	//while(cin>>n){
	cin>>n;
	//for(n=1;n<=100;n++){
	int len;
	vector<int> d;
	d = f(n, len);
	//ll t=0;
	for(int i=0;i<d.size();i++){
		cout<<d[i]<<" ";
	//	t=t*2+d[i];
	}
	cout<<endl;
	//if (n!=t)
	//	cout<<"Err " <<t<<endl;
	//}
}