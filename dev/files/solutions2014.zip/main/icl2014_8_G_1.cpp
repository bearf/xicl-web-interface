#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

#define M 1000100
#define K 20

typedef long long ll;
typedef long long li;

void Solve(void);

int main(){

#ifdef BANANA_MOTEL
	freopen("test.in", "r", stdin);
	freopen("test.out", "w", stdout);
#else
#endif
	Solve();
	return 0;
}

#define M 100100

int n;
vector<int> g[M];
int d[M],ans[M],s=0,p[M];
bool u[M],a[M];

void read(void){
	cin>>n;
	for (int i=1,a,b; i<n; ++i){
		cin>>a>>b;
		g[a].push_back(b);
		g[b].push_back(a);
	}
}

void dfs(int v, int deep){
	u[v]=1;
	d[v]=deep;
	for (int i=0,to; i<g[v].size(); ++i){
		to=g[v][i];
		if (!u[to]){
			dfs(to,deep+1);
			p[to]=v;
		}
	}
}


void add(int v){
	int x=v;
	a[1]=1;
	while (!a[x]){
		a[x]=1;
		++s;
		x=p[x];
	}
	cout<<2*s-d[v]<<" ";
}

void Solve()
{
	read();
	p[1]=1;
	dfs(1,0);
	int m;
	cin>>m;
	for (int i=0,x; i<m; ++i){
		cin>>x;
		add(x);
	}
}