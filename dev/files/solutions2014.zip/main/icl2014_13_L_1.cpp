#include <iostream>
using namespace std;
//ifstream cin ("input.txt");
//ofstream cout ("output.txt");

int main(){
	int n, a, cnt = 0, sum = 0;
	cin >> n;
	for(int i = 0; i < n; i++){
		for(int j = 0; j < n; j++){
			cin >> a;
			if(a > 0)
				cnt++;
			sum += a;
		}
	}
	if(cnt * 2 >= (n * n))
		cout << sum;
	else
		cout << -1;
	return 0;
}