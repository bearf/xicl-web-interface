#include <cstdio>

int main() {
  int n;
  scanf("%d", &n);
  printf("%d\n", (1 << n) * n);
  for (int j = 0; j < n; j++) {
    for (int i = 0; i < 1 << n; i++) {
      int x = i ^ (i + 1);
      int c = 0;
      while (x > 0) {
        x /= 2;
        c++;
      }
      printf("%d ", (c + j) % n + 1);
    }
  }
  puts("");
}