#include<stdio.h>
#include<iostream>
#include<math.h>

int main()
{
	int n;
	int a[15][15];
	scanf("%d",&n);
	int c0=0, c1=0;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
			if(a[i][j]!=0)
				c0++;
			c1+=a[i][j];
		}
	}
	if(c0<(n*n-c0))
		printf("-1");
	else
		printf("%d",c1);

	return 0;
}