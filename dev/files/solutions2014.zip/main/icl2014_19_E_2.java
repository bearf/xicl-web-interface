import java.io.*;
import java.util.*;

public class Solution {

	static void solve() throws IOException {
		int n = nextInt();
		int[] a = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = nextInt();
		}
		int all;
		{
			int[] b = a.clone();
			Arrays.sort(b);
			int j = 1;
			for (int i = 1; i < b.length; i++) {
				if (b[i] != b[j - 1]) {
					b[j++] = b[i];
				}
			}
			b = Arrays.copyOf(b, j);
			for (int i = 0; i < a.length; i++) {
				a[i] = Arrays.binarySearch(b, a[i]);
			}
			all = b.length;
		}
		List<Integer>[] en = new List[all];
		for (int i = 0; i < all; i++)
			en[i] = new ArrayList<>();
		for (int i = 0; i < n; i++)
			en[a[i]].add(i);
		int[] jump = new int[all];
		int[] count = new int[all];
		for (int i = all - 1; i >= 0; i--) {
			jump[i] = 1;
			count[i] = en[i].size();
			if (i + 1 < all && en[i + 1].get(0) > en[i].get(en[i].size() - 1)) {
				jump[i] += jump[i + 1];
				count[i] += count[i + 1];
			}
		}
		int ans = 0;
		for (int i = 0; i < all; i++) {
			ans = Math.max(ans, en[i].size());
		}
		for (int i = 0; i + 1 < all; i++) {
			for (int j = 0; j < en[i + 1].size(); j++) {
				int got = count[i + 1] - j;
				{
					int last = en[i + 1].get(j);
					int l = -1;
					int r = en[i].size();
					while (l < r - 1) {
						int mid = (l + r) >> 1;
						if (en[i].get(mid) >= last) {
							r = mid;
						} else {
							l = mid;
						}
					}
					got += r;
				}
				{
					int next = i + 1 + jump[i + 1];
					if (next < all) {
						int first = en[next - 1].get(en[next - 1].size() - 1);
						int l = -1;
						int r = en[next].size();
						while (l < r - 1) {
							int mid = (l + r) >> 1;
							if (en[next].get(mid) <= first) {
								l = mid;
							} else {
								r = mid;
							}
						}
						got += en[next].size() - r;
					}
				}
				ans = Math.max(ans, got);
			}
		}
		out.println(n - ans);
	}

	public static void main(String[] args) throws IOException {
		File file = new File("e.in");
		InputStream input = System.in;
		if (file.canRead()) {
			input = new FileInputStream(file);
		}
		br = new BufferedReader(new InputStreamReader(input));
		out = new PrintWriter(System.out);
		solve();
		out.close();
		br.close();
	}

	static BufferedReader br;
	static PrintWriter out;
	static StringTokenizer st;

	static String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) {
			String line = br.readLine();
			if (line == null) {
				return null;
			}
			st = new StringTokenizer(line);
		}
		return st.nextToken();
	}

	static int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
}
