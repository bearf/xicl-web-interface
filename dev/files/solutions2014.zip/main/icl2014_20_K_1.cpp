#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <iomanip>
#include <list>

using namespace std;

#define mp make_pair
#define pb push_back
#define X first
#define Y second

const double eps=1e-8;
struct point
{
    double x, y;
    point(double xx=0.0, double yy=0.0){x=xx; y=yy;};
};
struct line
{
    double A, B, C;
    line(double a=0.0, double b=0.0, double c=0.0){A=a; B=b;C=c;};
    line (point a, point b)
    {
        A=a.y-b.y;
        B=-(a.x-b.x);
        C=0.0-a.x*A-a.y*B;
    };
};

double det(double a, double b, double c, double d)
{
    return a*d-b*c;
}
point inter(line a, line b)
{
    double o, q1, q2;
    o=det(a.A, a.B, b.A, b.B);
    q1=det(-a.C, a.B, -b.C, b.B);
    q2=det(a.A, -a.C, b.A, -b.C);
    return point(q1/o, q2/o);
}
point perp(point q, line w)
{
    line e(w.B, -w.A, 0.0-w.B*q.x+w.A*q.y);
    return inter(w, e);
}
pair<point, point>l[10100];
line p[10100];
int n;
point getx(double y)
{
    return point((0.0-p[1].C-p[1].B*y)/p[1].A, y);
}
point gety(double x)
{
    return point(x, (0.0-p[1].C-p[1].A*x)/p[1].B);
}
point solve(point st)
{
    for (int i=2; i<=n+1; i++)
    {
        if ( fabs(p[i].A*st.x+p[i].B*st.y+p[i].C)>eps )
            st=perp(st, p[i]);
    }
    return st;
}
double dist(point a, point b)
{
    return sqrt( (a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y) );
}
point get(double x)
{
    double dx, dy;
    dx=l[1].X.x-l[1].Y.x;
    dy=l[1].X.y-l[1].Y.y;
    point u(l[1].X.x+dx*x, l[1].X.y+dy*x);
    return u;
}
double f(double x)
{
    point u=get(x);
    return dist(u, solve(u));
}
point tern()
{
    double l=-1E9, r=1E8;
    int it=0;
    while ( it<130 )
    {
        double m1, m2, d;
        d=(r-l)/3.0;
        m1=l+d; m2=r-d;
        if ( f(m1)<f(m2) )
            r=m2;
        else
            l=m1;
        it++;
    }
    return get(l);
}
int main()
{
    cout<<fixed<<setprecision(8);
    cin>>n;
    for (int i=1; i<=n; i++)
    {
        cin>>l[i].X.x>>l[i].X.y>>l[i].Y.x>>l[i].Y.y;
        p[i]=line(l[i].X, l[i].Y);
        //cout<<p[i].A<<" "<<p[i].B<<" "<<p[i].C<<endl;
    }
    p[n+1]=p[1];
    /*for (double xst=-3.0; xst<=10.0; xst+=0.1)
    {
        point st=gety(xst);
        point fin=solve(st);
        cout<<st.x<<" "<<st.y<<"   "<<fin.x<<" "<<fin.y<<endl;
    }*/
    point res=tern();
    if ( dist(res, solve(res))>10.0*eps )
        return 1;
    cout<<res.x<<" "<<res.y;
    return 0;
}
/*
6
0 0 11 0
1 1 3 4
6 5 7 8
1 8 3 5
6 4 11 3
5 3 7 1

*/
