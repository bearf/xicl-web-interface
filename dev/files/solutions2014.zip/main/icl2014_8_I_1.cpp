#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

#define M 100100

typedef long long ll;
typedef long long li;

void Solve(void);

int main(){

#ifdef BANANA_MOTEL
	freopen("test.in", "r", stdin);
	freopen("test.out", "w", stdout);
#else
#endif
	Solve();
	return 0;
}


#define M 100100

long long n;
long long a[M],b[M];
long long t;

void perf(long long k){
	for (long long i=1; i<=n; ++i)
		b[i]=0;
	for (long long i=1; i+k<=n; ++i)
		b[i]+=a[i+k];
	for (long long i=1+k; i<=n; ++i)
		b[i]+=a[i-k];
	for (long long i=1; i<=n; ++i)
		a[i]=b[i]&1;
}

void Solve()
{
	cin>>t>>n;
	char ch;
	for (long long i=1; i<=n; ++i){
		cin>>ch;
		a[i]=ch-'0';
	}

	long long x=1;
	while (x<=t){
		if (x&t)
			perf(x);
		x*=2;
	}

	for (long long i=1; i<=n; ++i)
		cout<<a[i];
}