#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>
using namespace std;

typedef long long ll;
const int N = (int)1e5;
char str[N];
char rStr[N];

char part[N], lPart[N];
char nStr[N];

int getVal(int pos, int len)
{
	pos %= len;
	if (pos < 0)
		pos += len;
	return part[pos] - '0';
}

int calc(int n, int pos, ll t)
{
	int len = 2 * n + 2;
	int sum = 0;
	int stPos = (pos + t) % 2;

	int allSum = 0;
	for (int i = stPos; i < len; i += 2)
		allSum ^= (part[i] - '0');

	bool isJump = false;
	for (ll i = pos - t; i <= pos + t;)
	{
		if ((i % len == 0 || (i - 1) % len == 0) && !isJump)
		{
			ll p = pos + t - i + 1;
			ll cntBlock = p / len;
			sum ^= allSum & (cntBlock & 1);
			i += len * cntBlock;
			isJump = true;
		}
		else
		{
			int q = i % len;
			if (q < 0)
				q += len;
			sum ^= part[q] - '0';
			i += 2;
		}
	}
	return sum;
}
void genPart(int n)
{
	for (int i = 0; i < n; i++) rStr[i] = str[i];
	reverse(rStr, rStr + n);
	
	for (int i = 0; i < n; i++)
		part[i] = str[i];
	part[n] = '0';
	for (int i = 0; i < n; i++)
		part[i + n + 1] = rStr[i];
	part[2 * n + 1] = '0';
}

void solve(int n, ll t)
{
	genPart(n);
	if (n == 1)
	{
		str[0] = calc(n, 0, t);
		return;
	}
	int len = 2 * n + 2;
	int t0 = calc(n, 0, t);
	int t1 = calc(n, 1, t);
	str[0] = t0 + '0';
	str[1] = t1 + '0';
	for (int i = 2; i < n; i++)
	{
		if (i % 2 == 0)
		{
			t0 ^= getVal((i - 2 - t), len) ^ getVal(i + t, len);
			str[i] = t0 + '0';
		}
		else
		{
			t1 ^= getVal((i - 2 - t), len) ^ getVal(i + t, len);
			str[i] = t1 + '0';
		}
	}
}

int getChar(int pos, int n)
{
	if (pos < 0 || pos >= n)
		return 0;
	return str[pos] - '0';
}

void go(int n)
{
	for (int i = 0; i < n; i++)
	{
		nStr[i] = (getChar(i - 1, n) ^ getChar(i + 1, n)) + '0';
	}
	for (int i = 0; i < n; i++)
		str[i] = nStr[i];
}

void simpleSolve(int n, ll t)
{
	for (int i = 0; i < t; i++)
	{
		go(n);
	}
}

int main()
{
//	freopen ("input.txt", "r", stdin);
//	freopen ("output.txt", "w", stdout);
	int n;
	ll t;

	scanf("%lld%d", &t, &n);
	
	scanf(" %s", str);

	for (ll i = 63; i >= 1;)
	{
		ll pow2 = (1ll << (ll)i) - 1;
		if (pow2 <= t)
		{
			solve(n, pow2);
			t -= pow2;
		}
		else
			i--;
	}

	for (int i = 0; i < n; i++)
		printf("%c", str[i]);

	return 0;
}