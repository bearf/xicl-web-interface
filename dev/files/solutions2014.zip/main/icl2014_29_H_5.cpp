#include <cstdio> 
#include <cstdlib> 
#include <algorithm> 
#include <iostream> 
#include <cstring> 
#include <cassert> 
#include <string> 
#include <cmath> 
#include <vector> 
#include <set> 
#include <map> 
#include <ctime> 
using namespace std; 
#ifdef _WIN32 
#define LLD "%I64d" 
#else 
#define LLD "%lld" 
#endif 
typedef long double ld; 
typedef long long ll; 
typedef pair<int, int> pii; 
typedef vector<int> vi; 
typedef vector<long long> vll;
#define mp make_pair 
#define pb push_back 
#define x first 
#define y second 
#define sz(x) ((int)(x).size()) 
#define EPS (1e-9) 
#define INF ((int)1e9) 
#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr) 
#define TASK "text" 
const ld eps = 1e-9;
struct pnt { 
	ld x, y; 
	pnt() {} 
	pnt(ld x, ld y) :x(x),y(y) {} 
}; 
pnt operator -(pnt a, pnt b) { 
	return pnt(a.x - b.x, a.y - b.y); 
} 
pnt operator +(pnt a, pnt b) { 
	return pnt(a.x + b.x, a.y + b.y); 
} 
pnt operator *(pnt a, ld c) { 
	return pnt(a.x * c, a.y * c); 
} 
pnt operator /(pnt a, ld c) { 
	return pnt(a.x / c, a.y / c); 
} 
ld sp(pnt a, pnt b) { 
	return a.x * b.x + a.y * b.y; 
} 
ld vp(pnt a, pnt b) { 
	return a.x * b.y - a.y * b.x; 
} 
ld dst(pnt a, pnt b) { 
	return sqrt(sp(a - b, a - b)); 
} vector<pair<pnt, ld> > ls; int n; pnt p[111]; int R1, R2; pnt otr(pnt p, pnt a, pnt b) { pnt v = b - a; v = v / dst(a, b); pnt n = pnt(-v.y, v.x); ld h = fabs(vp(p - a, p - b)) / dst(a, b); 
return p + n * h * 2; } void norm(vector<pnt>& ls) { int m = sz(ls); while (1) { bool was = false; for (int i = 1; i < m - 1; i++) { if (vp(ls[i] - ls[i - 1], ls[i + 1] - ls[i]) > eps) { 
ls[i] = otr(ls[i], ls[i - 1], ls[i + 1]); was = true; } } for (int i = m - 2; i >= 1; i--) { if (vp(ls[i] - ls[i - 1], ls[i + 1] - ls[i]) > eps) { ls[i] = otr(ls[i], ls[i - 1], ls[i + 1]); was = true; } } 
if (!was) { break; } } } 
ld alp(pnt a, pnt b) { 
	ld res = atan2(vp(a, b), sp(a, b)); 
	if (res > eps) {
		return 2 * M_PI - res;
	} else {
		return abs(res);
	}
} 
void add(pnt a, pnt b) { ld ds = dst(a, b); ld d = ds - 2 * R2; 
int k = (int)(d / (2 * R1) + eps); ls.pb(mp(a, R2)); vector<pnt> ls2; ls2.pb(a); for (int i = 0; i < k / 2; i++) { ls2.pb(a + (b - a) / ds * (R2 + R1 * (i * 2 + 1))); } ld z = d - (k / 2) * 2 * 2 * R1; 
// assert(z >= -eps); 
if (z <= eps) { } else if (z <= 2 * R1 + eps) { ld lR = R1; if (k / 2 == 0) { lR = R2; } pnt md = (a + b) / 2; 
// cerr<<((lR + R1) * (lR + R1) - (lR + z / 2) * (lR + z / 2))<<endl; 
ld h = sqrt(max((ld)0., (lR + R1) * (lR + R1) - (lR + z / 2) * (lR + z / 2))); pnt v = b - a; v = v / ds; pnt n = pnt(-v.y, v.x); ls2.pb(md + n * h); } else { 
//assert(z <= 4 * R1 + eps); 
ld lR = R1; if (k / 2 == 0) { lR = R2; } pnt md = (a + b) / 2; pnt v = b - a; v = v / ds; pnt n = pnt(-v.y, v.x); 
ld h = sqrt(max((ld)0., (lR + R1) * (lR + R1) - (lR + z / 2 - R1) * (lR + z / 2 - R1))); ls2.pb(md + n * h - v * R1); 
ls2.pb(md + n * h + v * R1); } for (int i = k / 2 - 1; i >= 0; i--) { ls2.pb(a + (b - a) / ds * (ds - R2 - R1 * (i * 2 + 1))); } 
ls2.pb(b); norm(ls2); for (int i = 1; i < sz(ls2) - 1; i++) { ls.pb(mp(ls2[i], R1)); } } int solve() { if (scanf("%d", &n) < 1) return 0; 
for (int i = 0; i < n; i++) { int x, y; scanf("%d %d", &x, &y); p[i] = pnt(x, y); } p[n] = p[0]; scanf("%d %d", &R1, &R2); ls.clear(); 
for (int i = 0; i < n; i++) { add(p[i], p[i + 1]); } for (int i = 0; i < sz(ls); i++) { 
//cerr<<ls[i].x.x<<" "<<ls[i].x.y<<endl; 
//assert(fabs(dst(ls[i].x, ls[(i + 1) % sz(ls)].x) - ls[i].y - ls[(i + 1) % sz(ls)].y) <= eps); 
} ld res = 0; for (int i = 0; i < sz(ls); i++) { 
ld alp0 = 2 * M_PI - alp(ls[(i + 1) % sz(ls)].x - ls[i].x, ls[(i - 1 + sz(ls)) % sz(ls)].x - ls[i].x); 
res += alp0 * ls[i].y; } printf("%d\n", sz(ls) - n); printf("%.18lf\n", (double)res); return 0; } int main() { 
#ifdef DEBUG 
freopen(TASK".in", "r", stdin); freopen(TASK".out", "w", stdout); 
#endif 
int n; while (1) { if (!solve()) break; 
#ifdef DEBUG 
eprintf("%.18lf\n", (double)clock() / CLOCKS_PER_SEC); 
#endif 
} return 0; }
