#pragma comment(linker, "/STACK:268435456")

#include <iostream>
#include <iomanip>

#include <vector>
#include <string>
#include <deque>
#include <queue>
#include <set>
#include <map>

#include <algorithm>

#include <cstdio>
#include <cstdlib>
#include <complex>
#include <ctime>
#include <cstring>
#include <cassert>

using namespace std;

#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define ford(i,n) for (int i = int(n) - 1; i >= 0; --i)

#define pb push_back
#define mp make_pair
#define fs first
#define sc second
#define all(a) (a).begin(), (a).end()
#define sz(a) int((a).size())

#ifdef SG
    #define debug(x) cerr << #x << ": " << (x) << endl
#else
    #define debug(x)
#endif

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

template <typename T>
ostream & operator << (ostream & out, vector<T> const & a) {
    out << "[";
    for (int i = 0; i < sz(a); ++i) {
        if (i != 0) {
            out << ", ";
        }
        out << a[i];
    }
    out << "]";
    return out;
}

template <typename T1, typename T2>
ostream & operator << (ostream & out, pair<T1, T2> const & p) {
    out << "(" << p.fs << ", " << p.sc << ")";
    return out;
}

struct Data {
    int n;
    vector<int> a;

    int ans;

    bool read () {
        if (!(cin >> n)) {
            return false;
        }
        a.resize(n);
        for (int i = 0; i < n; ++i) {
            cin >> a[i];
        }

        return true;
    }

    void write () {
        cout << ans << "\n";
    }

    virtual void solve () {
    }

    virtual void clear () {
        *this = Data();
    }
};

const int N = 2e5;

struct Solution: Data {
    vector<int> pos[N];
    int k;

    map<int, int> num;
    vector<int> zip (vector<int> a) {
        vector<int> c(a);
        sort(all(c));
        c.resize(unique(all(c)) - c.begin());
        for (int i = 0; i < sz(c); ++i) {
            num[c[i]] = i;
        }
        for (int i = 0; i < sz(a); ++i) {
            a[i] = num[a[i]];
        }

        return a;
    }

    int getTwo (int x) {
        int res = 0;
        for (int i = 0, j = 0; i < sz(pos[x]); ++i) {
            while (j < sz(pos[x + 1]) && pos[x][i] > pos[x + 1][j]) {
                ++j;
            }    
            res = max(res, i + 1 + sz(pos[x + 1]) - j);
        }    

        return res;
    }

    bool ok (int x) {
        if (x + 1 >= k) {
            return false;
        }

        return pos[x].back() < pos[x + 1][0];
    }

    void solve () {
        vector<int> b = zip(a);
        k = 0;
        for (int i = 0; i < n; ++i) {
            k = max(k, b[i] + 1);
            pos[b[i]].pb(i);            
        }
        for (int i = 0; i < k; ++i) {
            sort(all(pos[i]));
        }

        ans = 0;
        for (int i = 0; i + 1 < k; ++i) {
            ans = max(ans, getTwo(i));
        }
        // debug(ans);
        for (int i = 0; i < k;) {
            int u = i, e = sz(pos[i]);

            while (ok(i)) {
                ++i;
                e += sz(pos[i]);
            }
            // debug(i);
            // debug(e);
            // debug(pos[i].back());
            if (i + 1 < k) {
                e += pos[i + 1].end() - upper_bound(all(pos[i + 1]), pos[i].back());
            }
            if (u != 0) {
                e += upper_bound(all(pos[u - 1]), pos[u][0]) - pos[u - 1].begin();
            }
            // debug(e);
            ++i;
            ans = max(ans, e);
        }

        ans = n - ans;
    }

    Solution (Data d = Data()): Data(d) {}

    void clear () {
        *this = Solution();
    }
};

Solution sol;
int main () {
#ifdef SG
//    freopen("", "r", stdin);
//    freopen("", "w", stdout);
    while (sol.read()) {
        sol.solve();
        sol.write();
        sol.clear();
    }
#else
//    freopen("", "r", stdin);
//    freopen("", "w", stdout);
    sol.read();
    sol.solve();
    sol.write();    
#endif

    return 0;
}
