#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
//ifstream cin ("input.txt");
//ofstream cout ("output.txt");
long long n, i, ds, razn = 12345678999999999;
double p;
vector <int> ans;

int main(){
	cin >> n;
	long long nt = n;
	while (nt != 1){
		nt /= 2;
		p++;
	}
	ds = pow(2.0 , p);
	razn = abs(n - ds);
	double pt = p;
	ans.push_back(1);
	ans.push_back(0);
	p -= 2;

		while (ds != n && p >= 0){
			if (abs(n - (ds + pow(2.0, p))) < razn){
				razn = abs(n - (ds + pow(2.0, p)));
				ds += pow(2, p);
				ans.push_back(1);
				if (p != 0)ans.push_back(0);
				p--;
			}else if (abs(n - (ds - pow(2.0, p))) < razn){
				razn = abs(n - (ds - pow(2.0, p)));
				ds -= pow(2, p);
				ans.push_back(-1);
				if (p != 0) ans.push_back(0);
				p--;
			}else{
				ans.push_back(0);
			}
		p--;
		}
		while (p >= 0){
			ans.push_back(0);
			p--;
		}


	if (ds != n){
		ans.clear();
		p = pt + 1;
		ds = pow(2, p);
		razn = abs(n - ds);
		p -= 2;
		ans.push_back(1);
		ans.push_back(0);
		while (ds != n && p >= 0){
			if (abs(n - (ds + pow(2.0, p))) < razn){
				razn = abs(n - (ds + pow(2.0, p)));
				ds += pow(2, p);
				ans.push_back(1);
				if (p != 0)ans.push_back(0);
				p--;
			}else if (abs(n - (ds - pow(2.0, p))) < razn){
				razn = abs(n - (ds - pow(2.0, p)));
				ds -= pow(2, p);
				ans.push_back(-1);
				if (p != 0) ans.push_back(0);
				p--;
			}else{
				ans.push_back(0);
			}
		p--;
		}
		while (p >= 0){
			ans.push_back(0);
			p--;
		}
	}
	for (i = 0; i < ans.size(); i++) cout << ans[i] << " ";
}