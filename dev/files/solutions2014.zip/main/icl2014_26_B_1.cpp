#include<iostream>
#include <deque>
#include <vector>

using namespace std;



int main()
{
	int n, k;
	cin >> n >> k;
	if(k == 1){
		cout << 1;
	} else {

	cout << (n - k)/2;
	}
	return 0;
}





