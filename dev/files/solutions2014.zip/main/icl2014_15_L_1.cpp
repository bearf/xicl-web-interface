#include <iostream>
#include <cstdio>
#include <cstring>


using namespace std;


int a[500];


int main()
{
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
	int n;
	scanf("%d", &n);
	int a = 0, b = 0;
	int ans = 0;
	for(int i = 0; i < n; i++)
		for(int j = 0; j < n; j++)
		{
			int x;
			scanf("%d", &x);
			if(x == 0)
				a++;
			else
			{
				b++;
				ans += x;
			}
		}
	if(a > b)
		ans = -1;
	printf("%d\n", ans);
}