#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <cassert>

using namespace std;

#ifdef _WIN32
	#define LLD "%I64d"
#else
	#define LLD "%lld"
#endif

typedef long double ld;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<long long> vll;

#define mp make_pair
#define pb push_back
#define sz(x) ((int)(x).size())
#define EPS (1e-9)
#define INF ((int)1e9)
#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define TASK "text"

const int maxn = (int)1e5 + 100;
int used[maxn];
vector<vector<int> > es;
int depth[maxn];
int pr[maxn];

void dfs(int v) {
	used[v] = 1;
	for (int it = 0; it < sz(es[v]); ++it) {
		int u = es[v][it];
		if (used[u])
			continue;
		depth[u] = depth[v] + 1;
		pr[u] = v;
		dfs(u);
	}
}

int cnt;
void add(int v) {
	while (v != -1 && !used[v]) {
		used[v] = 1;
		v = pr[v];
		++cnt;
	}
}

int solve() {
	int n;
	if (scanf("%d", &n) < 1)
		return 0;
	es = vector<vector<int> >(n);
	for (int i = 0; i < n - 1; ++i) {
		int s, t;
		scanf("%d%d", &s, &t);
		--s, --t;
		es[s].pb(t), es[t].pb(s);
	}

	for (int i = 0; i < n; ++i)
		used[i] = 0;
	depth[0] = 0;
	pr[0] = -1;
	dfs(0);

	for (int i = 0; i < n; ++i)
		used[i] = 0;

	int m;
	scanf("%d", &m);
	
	cnt = 0;
	for (int i = 0; i < m; ++i) {
		int x;
		scanf("%d", &x);
		--x;
		add(x);
		printf("%d%c", (cnt - 1) * 2 - depth[x], " \n"[i == m - 1]);
	}
	return 1;
}

int main() {
#ifdef DEBUG
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	
	int n;
	while (1) {
		if (!solve())
			break;
		#ifdef DEBUG
		eprintf("%.18lf\n", (double)clock() / CLOCKS_PER_SEC);		
		#endif
	}
	return 0;
}
