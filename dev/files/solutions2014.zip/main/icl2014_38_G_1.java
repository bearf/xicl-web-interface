import java.io.*;
import java.util.*;

public class G {

	FastScanner in;
	PrintWriter out;

	ArrayList<Integer>[] g;

	int MAX = 20;

	int[][] up;
	int[] h;

	void go(int v, int p, int hh) {
		h[v] = hh;
		up[0][v] = p;
		for (int i = 1; i < MAX; i++)
			up[i][v] = up[i - 1][up[i - 1][v]];
		for (int i = 0; i < g[v].size(); i++) {
			int to = g[v].get(i);
			if (to != p) {
				go(to, v, hh + 1);
			}
		}
	}

	boolean[] was;

	int getWas(int x) {
		if (was[x])
			return x;
		for (int i = MAX - 1; i >= 0; i--)
			if (!was[up[i][x]])
				x = up[i][x];
		return up[0][x];
	}

	void color(int x) {
		while (!was[x]) {
			was[x] = true;
			x = up[0][x];
		}
	}

	void solve() {
		int n = in.nextInt();
		g = new ArrayList[n];
		for (int i = 0; i < n; i++)
			g[i] = new ArrayList<>();
		for (int i = 0; i < n - 1; i++) {
			int fr = in.nextInt() - 1;
			int to = in.nextInt() - 1;
			g[fr].add(to);
			g[to].add(fr);
		}
		up = new int[MAX][n];
		h = new int[n];
		go(0, 0, 0);
		was = new boolean[n];
		was[0] = true;
		int m = in.nextInt();
		int curTotal = 0;
		for (int i = 0; i < m; i++) {
			int cur = in.nextInt() - 1;
			int w = getWas(cur);
			long res = curTotal;
			if (w == cur) {
				res -= h[cur];
			} else {
				int dh = h[cur] - h[w];
				res -= h[w];
				res += dh;
				curTotal += 2 * dh;
			}
			out.print(res + " ");
			color(cur);
		}
	}

	void run() {
		try {
			in = new FastScanner();
			out = new PrintWriter(System.out);
			solve();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	class FastScanner {
		BufferedReader br;
		StringTokenizer st;

		public FastScanner() {
			br = new BufferedReader(new InputStreamReader(System.in));
		}

		String nextToken() {
			while (st == null || !st.hasMoreElements()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return st.nextToken();
		}

		int nextInt() {
			return Integer.parseInt(nextToken());
		}

		long nextLong() {
			return Long.parseLong(nextToken());
		}

		double nextDouble() {
			return Double.parseDouble(nextToken());
		}
	}

	public static void main(String[] args) {
		new G().run();
	}
}
