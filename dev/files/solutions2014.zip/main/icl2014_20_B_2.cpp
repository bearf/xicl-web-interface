#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <set>
#include <map>
#include <vector>

using namespace std;

int base=1000000009;
int f[1000100][21], d[1000100][21], n, k;

int main()
{
    f[0][0]=1;

    cin>>n>>k;
    for (int i=0; i<=n; i++)
        d[i][0]=1;
    for (int i=1; i<=n; i++)
    {

        for (int j=1; j<=k; j++)
        {
            f[i][j]=d[i/2][j-1];
            f[i][j]%=base;
            d[i][j]=d[i-1][j]+f[i][j];
            d[i][j]%=base;
        }

    }
    cout<<f[n][k]<<endl;
    return 0;
}
/*
7
0 0 0 1 0 0 0
0 4 0 1 0 0 0
0 0 0 1 0 0 0
1 1 1 1 1 1 1
0 0 0 1 0 0 0
0 0 0 1 0 3 0
0 0 0 1 0 0 0
*/
