#include <iostream>
#include <fstream>

using namespace std;

int main(){
	ifstream fIn("stdin");
	ofstream fOut("stdout");
	
	unsigned int field[14][14];
	unsigned int n,i,j, cnt=0;
	unsigned long sum=0;

	fIn >> n;

	for (i=0; i<n; i++){
		for (j=0; j<n; j++){
			fIn >> field[i][j];
		}
	}

	for (i=0; i<n; i++){
		for (j=0; j<n; j++){
			sum+=field[i][j];
			if (field[i][j]==0) cnt++;
		}
	}

	if (cnt<=(n*n/2)) fOut << sum;
	else fOut << "-1";

	return 0;
}