#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cassert>
#include <ctime>
#include <memory.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <complex>
#include <list>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef complex <ld> point;

#define pb push_back
#define mp make_pair
#define fi first
#define se second

#define INF 1000000001
#define INFL 1000000000000000001ll
#define NAME "e"

int a[300001];
int d[300001];

int main() {
    #ifdef _GEANY
    assert(freopen(NAME ".in", "r", stdin));
    #endif // _GEANY
    int n;
    cin >> n;
    for (int i = 0; i < n; ++i)
        cin >> a[i];
    d[0] = -INF;
    for (int i = 1; i <= n; ++i)
        d[i] = INF;
    int res = 0;
    for (int i = 0; i < n; ++i) {
        int pos = upper_bound(d, d + n + 1, a[i]) - d;
        d[pos] = a[i];
        res = max(res, pos);
    }
    cout << n - res << endl;
}
