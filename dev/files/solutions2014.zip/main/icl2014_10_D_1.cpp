#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <vector>
#include <string>

using namespace std;
typedef unsigned long long ull;

int main() {
	string n;
	cin >> n;

	if (n.size() == 1) {
		int a = n[0] - '0';

		for (int i = 1; i <= a; i++) {
			cout << i;
		}

		return 0;
	}
	
	int a = n[0] - '0';
	int b = a;
	char c = n[0];
	for (int i = 1; i < n.size(); i++) {
		if (n[i] != c) {
			if (n[i] > c) {
				b++;
			}
			break;
		}
	}


	for (int i = 1; i <= a; i++) {
		cout << i;
	}

	// aaa < n => a != b
	if (a == b) {
		for (int i = 0; i <= b-1; i++) {
			cout << i;
		}

		for (int i = b + 1; i <= 9; i++) {
			cout << i;
		}
	} else {
		cout << "0123456789";
	}

	for (int i = 0; i < n.size() - 2; i++) {
		cout << "0123456789";
	}


	return 0;
}