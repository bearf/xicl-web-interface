#include<iostream>
#include <deque>
#include <vector>

using namespace std;

int s = 0;

int f(int n, int m, int k){

	if(k == 0){
		return 1;
	}

	for(int i = n; i <= m; i++){
		if(i % 2 == 0){
			s += f(i/2, i - k, k-1);
		} else {
			s += f(i/2+1, i - k, k-1);
		}
	}

 	return s;

}

int main()
{
	int n, k, x;
	cin >> n >> k;
	if(n % 2 == 0){
		x = f(n/2, n - k, k-1);
	} else {
		x = f(n/2+1, n - k, k-1);
	}

	cout << x;

	return 0;

}





