#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <iomanip>
#include <queue>
#include <deque>
#include <complex>

using namespace std;

#define pb push_back
#define pbk pop_back
#define all(x) (x).begin(), (x).end()
#define fs first
#define sc second
#define y0 yy0
#define y1 yy1
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define prev _prev
#define rank _rank
#define link _link
#define hash _hash
#ifdef LOCAL
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const int inf = int(1e9);

struct vt
{
	ld x, y;
	vt(ld _x, ld _y)
	{
		x = _x, y = _y;
	}
	friend vt operator +(vt a, vt b)
	{
		return vt(a.x + b.x, a.y + b.y);
	}
	friend vt operator -(vt a, vt b)
	{
		return vt(a.x - b.x, a.y - b.y);
	}
	friend ld operator *(vt a, vt b)
	{
		return a.x * b.x + a.y * b.y;
	}
	friend ld operator ^(vt a, vt b)
	{
		return a.x * b.y - b.x * a.y;
	}
	ld abs()
	{
		return sqrt(x * x + y * y);
	}
	friend vt operator /(vt a, ld k)
	{
		return vt(a.x / k, a.y / k);
	}
	friend vt operator *(vt a, ld k)
	{
		return vt(a.x * k, a.y * k);
	}
	vt norm()
	{
		return vt(x, y) / abs();
	}
	friend vt operator ~(vt v)
	{
		return vt(-v.y, v.x);
	}
	ld sabs()
	{
		return ((x < 0) ? -x : x) + ((y < 0) ? -y : y);
	}
	vt(){}
};

const int N = 10500;

vt A[N], B[N];

int n;
const int IT = 300;

vt walk(vt x)
{
	A[n] = A[0];
	B[n] = B[0];
	for (int i = 1; i <= n; i++)
	{
		x = x + (~(B[i] - A[i])) * ((x - A[i]) ^ (B[i] - A[i]));
	}
	return x;
}

int main() {
#ifdef LOCAL
#define TASK "K"
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> A[i].x >> A[i].y >> B[i].x >> B[i].y;
		vt v = B[i] - A[i];
		B[i] = A[i] + v.norm();
	}
	/*n = 10000;
	for (int i = 0; i < n; i++)
	{
		here:
		A[i] = vt(rand() % 201 - 100, rand() % 201 - 100);
		B[i] = vt(rand() % 201 - 100, rand() % 201 - 100);
		if ((A[i] - B[i]).abs() < 1e-2)
			goto here;
		B[i] = A[i] + (B[i] - A[i]).norm();
	}*/
	const ld inf = 1e9;
	swap(A[0], B[0]);
	cout << fixed << setprecision(6);
	for (int it = 0; it < 2; it++)
	{
		ld l = -inf, r = inf;
		for (int bit = 0; bit < IT; bit++)
		{
			ld m = (l + r) / 2;
			vt x = (A[0] + (B[0] - A[0]) * m);
			vt y = walk(x);
			if ((y - x) * (B[0] - A[0]) > 0)
				l = m;
			else
				r = m;
		}
		vt x = A[0] + (B[0] - A[0]) * l;
		vt y = walk(x);
		if ((x - y).sabs() < 1e-6)
		{
			cout << x.x << ' ' << x.y << endl;
			return 0;
		}
		swap(A[0], B[0]);
	}
	cout << -1 << endl;
	return 0;
}
