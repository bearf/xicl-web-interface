import java.io.*;
import java.util.*;

public class Solution {

	static class Fenwick {
		int[] a;

		public Fenwick(int n) {
			a = new int[n];
		}

		void add(int l, int r, int x) {
			add(l - 1, -x);
			add(r - 1, x);
		}

		void add(int x, int y) {
			for (int i = x; i >= 0; i = (i & i + 1) - 1) {
				a[i] += y;
			}
		}

		int get(int x) {
			int ret = 0;
			for (int i = x; i < a.length; i |= i + 1) {
				ret += a[i];
			}
			return ret;
		}
	}

	static void solve() throws IOException {
		int n = nextInt();
		int[] type = new int[n];
		int[] val = new int[n];
		for (int i = 0; i < n; i++) {
			String op = next();
			type[i] = op.equals("FIND") ? 0 : op.equals("ADD") ? 1 : 2;
			val[i] = nextInt();
		}
		int all;
		Random rand = new Random();
		{
			int[] b = val.clone();
			for (int i = 0; i < b.length; i++) {
				int j = rand.nextInt(i + 1);
				int t = b[i];
				b[i] = b[j];
				b[j] = t;
			}
			Arrays.sort(b);
			int j = 1;
			for (int i = 1; i < b.length; i++) {
				if (b[i] != b[j - 1]) {
					b[j++] = b[i];
				}
			}
			b = Arrays.copyOf(b, j);
			for (int i = 0; i < val.length; i++) {
				val[i] = Arrays.binarySearch(b, val[i]);
			}
			all = b.length;
		}
		for (int i = 0; i < n; i++) {
			val[i] = val[i] * 2 + 1;
		}
		all = all * 2 + 1;
		NavigableSet<Integer> set = new TreeSet<>();
		set.add(-1);
		set.add(all);
		Fenwick f = new Fenwick(all);
		int[] left = new int[all];
		int[] right = new int[all];
		f.add(0, all, 1);
		for (int q = 0; q < n; q++) {
			if (type[q] == 0) {
				if (set.contains(val[q])) {
					out.println("TRUE " + f.get(val[q]));
				} else {
					out.println("FALSE "
							+ (set.size() == 2 ? 1 : f.get(val[q]) - 1));
				}
				continue;
			}
			if (type[q] == 1) {
				if (!set.contains(val[q])) {
					out.print("TRUE");
					Integer prev = set.lower(val[q]);
					Integer next = set.higher(val[q]);
					left[val[q]] = prev + 1;
					right[val[q]] = next - 1;
					f.add(prev + 1, next, 1);
					f.add(val[q], val[q] + 1, -1);
					set.add(val[q]);
				} else {
					out.print("FALSE");
				}
				out.println(" " + f.get(val[q]));
				continue;
			}
			if (!set.contains(val[q])) {
				out.println("FALSE "
						+ (set.size() == 2 ? 1 : (f.get(val[q]) - 1)));
			} else {
				Integer prev = set.lower(val[q]);
				Integer next = set.higher(val[q]);
				if (prev >= left[val[q]] && next <= right[val[q]]) {
					int nextD = f.get(next);
					int curD = f.get(val[q]);
					f.add(left[next], right[next] + 1, -1);
					f.add(next, next + 1, 1);
					f.add(next, next + 1, curD - nextD);
					right[next] = right[val[q]];
					left[next] = left[val[q]];
					f.add(val[q], val[q] + 1, f.get(prev) + 1 - curD);
					out.println("TRUE " + nextD);
				} else {
					out.println("TRUE " + f.get(val[q]));
				}
				set.remove(val[q]);
			}
		}
	}

	public static void main(String[] args) throws IOException {
		File file = new File("j.in");
		InputStream input = System.in;
		if (file.canRead()) {
			input = new FileInputStream(file);
		}
		br = new BufferedReader(new InputStreamReader(input));
		out = new PrintWriter(System.out);
		solve();
		out.close();
		br.close();
	}

	static BufferedReader br;
	static PrintWriter out;
	static StringTokenizer st;

	static String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) {
			String line = br.readLine();
			if (line == null) {
				return null;
			}
			st = new StringTokenizer(line);
		}
		return st.nextToken();
	}

	static int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
}
