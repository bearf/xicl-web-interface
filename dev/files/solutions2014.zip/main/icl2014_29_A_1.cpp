#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <cassert>

using namespace std;

#ifdef _WIN32
	#define LLD "%I64d"
#else
	#define LLD "%lld"
#endif

typedef long double ld;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<long long> vll;

#define mp make_pair
#define pb push_back
#define sz(x) ((int)(x).size())
#define EPS (1e-9)
#define INF ((int)1e9)
#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define TASK "text"

int s;

vector<int> cur;
vector<vector<int> > ans;
int res;

void solve(int sum, int last) {
	if (sz(cur) > res)
		return;
	
	if (sum == 0) {
		if (sz(cur) < res)
			ans.clear();
		ans.pb(cur);
		res = sz(cur);
		return;
	}
	if (last <= 0)
		return;
	solve(sum, last - 1);
	if (!(last & 1))
		return;
	int x = last / 2;
	if (sum % last != x)
		return;
	int k = (sum - x) / last;
	for (int i = 0; i < k; ++i)
		cur.pb(last);
	int nsum = sum - last * k;
	solve(nsum, nsum);
	for (int i = 0; i < k; ++i)
		cur.pop_back();
}


int solve() {
	if (scanf("%d", &s) < 1)
		return 0;
	ans.clear();
	cur.clear();
	res = INF;
	solve(s, s);
	printf("%d %d\n", sz(ans), res);
	for (int i = 0; i < sz(ans); ++i)
		reverse(ans[i].begin(), ans[i].end());
		
	sort(ans.begin(), ans.end());
	for (int i = 0; i < sz(ans); ++i) {
		for (int j = 0; j < sz(ans[i]); ++j)
			printf("%d%c", ans[i][j], " \n"[j == sz(ans[i]) - 1]);
	}
	return 1;
}

int main() {
#ifdef DEBUG
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	
	int n;
	while (1) {
		if (!solve())
			break;
		#ifdef DEBUG
		eprintf("%.18lf\n", (double)clock() / CLOCKS_PER_SEC);		
		#endif
	}
	return 0;
}
