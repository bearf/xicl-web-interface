#undef NDEBUG
#ifdef ssu1
#define _GLIBCXX_DEBUG
#endif

#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define fore(i, l, r) for(int i = (l); i < (r); ++i)
#define forn(i, n) fore(i, 0, n)
#define fori(i, l, r) fore(i, l, (r) + 1)
#define X first
#define Y second
#define sz(v) ((int)(v).size())
#define pb push_back
#define mp make_pair
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acosl(-1.0);

const int mod = 1000000000 + 9;
const int NMAX = 1000010;
const int KMAX = 21;

int g = 0;
int d[NMAX][KMAX], val[NMAX];

int calc(int n, int k){
    if(n < 0)
        return 0;
    if(n == 0 && k == 0)
        return 1;
    if(k == 0)
        return 0;

    int& ans = d[n][k];
    if(ans == -1){
        ans = calc(n - (1 << (k - 1)), k);
        ans += calc(n, k - 1);
        
        while(ans >= mod)
            ans -= mod;
    }
    return ans;
}

int main(){
    #ifdef ssu1
    assert(freopen("__input.txt", "r", stdin));
    #endif
    
    int n, k;
    cin >> n >> k;
    memset(d, -1, sizeof d);
    cout << calc(n - (1 << (k - 1)), k) << endl;
    return 0;
}






