#ifdef SU2_PROJ
#define _GLIBCXX_DEBUG
#endif

#include <algorithm>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <string>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define forn(i, n) for (int i = 0; i < int(n); i++)
#define forl(i, n) for (int i = 1; i <= int(n); i++)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; i--)
#define fore(i, l, r) for (int i = int(l); i <= int(r); i++)
#define correct(x, y, n, m) (0 <= (x) && (x) < (n) && 0 <= (y) && (y) < (m))
#define sz(a) int((a).size())
#define pb(a) push_back(a)
#define all(a) (a).begin(), (a).end()
#define mp(x, y) make_pair((x), (y))
#define ft first
#define sc second
#define x first
#define y second

using namespace std;

typedef long long li;
typedef long double ld;
typedef pair <int, int> pt;

inline ostream& operator << (ostream& out, const pt& p) { return out << "(" << p.x << ", " << p.y << ")"; }

const int INF = int(1e9);
const li INF64 = li(1e18);
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

li x;

inline bool read ()
{
	return cin >> x;
}

inline void solve ()
{
	//cerr << x << endl;
	vector<int> a;
	while (x)
	{
		a.pb(int(x & 1));
		x >>= 1;
	}
	
	while (true)
	{
		//forn(i, sz(a)) cerr << a[i] << ' '; cerr << endl;
		
		bool upd = false;
		for (int i = 0, j = 0; i < sz(a); i = j)
		{
			if (a[j] <= 0)
			{
				j++;
				continue;
			}
			
			while (j < sz(a) && a[j] == 1) j++;
			
			if (j - i > 1)
			{
				fore(k, i, j - 1) a[k] = 0;
				a[i] = -1;
				
				if (j < sz(a)) a[j] = 1;
				else a.pb(1);
				
				upd = true;
				break;
			}
		}
		
		if (!upd) break;
	}
	
	ford(i, sz(a))
		printf("%d ", a[i]);
	puts("");
}

int main()
{
#ifdef SU2_PROJ
	freopen("input.txt", "rt", stdin);
	//freopen("output.txt", "wt", stdout);
#endif

	cout << setprecision(10) << fixed;
	cerr << setprecision(5) << fixed;
	
	assert(read());
	solve();
	
#ifdef SU2_PROJ
	cerr << "=== Time: " << clock() << " ===" << endl;
#endif

	return 0;
}
