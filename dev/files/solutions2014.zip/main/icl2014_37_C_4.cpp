#include <iostream>
#include <math.h>
#include <string>
using namespace std;

int main()
{
	_int64 n;
	cin >> n;
	int p = (int) (log((double)n) / log(2.0));
	int koef[60];
	_int64 s = (int)pow(2.0, (double)p);
	int lastKoef = 1;
	koef[p] = 1;
	for (int i = p-1; i >= 0; i--)
	{
		if (lastKoef != 0)
		{
			lastKoef = 0;
			koef[i] = 0;
			continue;
		}
		_int64 s1 = s - (int)pow(2.0, (double)i);
		_int64 s2 = s + (int)pow(2.0, (double)i);
		_int64 delta = abs(n-s);
		int k = 0;
		if (abs(n-s2) < delta)
		{
			delta = abs(n-s2);
			k = 1;
		}
		if (abs(n-s1) < delta)
		{
			delta = abs(n-s1);
			k = 1;
		}
		koef[i] = k;
		lastKoef = 1;
		s += k * ((int)pow(2.0, (double)i));
	}
	if (s == n)
	{
		for (int i = p; i >= 0; i--)
			cout << koef[i] << " ";
		return 0;
	}
	p++;
	lastKoef = 1;
	koef[p] = 1;
	s = (int)pow(2.0, (double)p);
	for (int i = p-1; i >= 0; i--)
	{
		if (lastKoef != 0)
		{
			lastKoef = 0;
			koef[i] = 0;
			continue;
		}
		_int64 s1 = s - (int)pow(2.0, (double)i);
		_int64 s2 = s + (int)pow(2.0, (double)i);
		_int64 delta = abs(n-s);
		int k = 0;
		if (abs(n-s2) < delta)
		{
			delta = abs(n-s2);
			k = 1;
		}
		if (abs(n-s1) < delta)
		{
			delta = abs(n-s1);
			k = -1;
		}
		koef[i] = k;
		lastKoef = k;
		s += k * ((int)pow(2.0, (double)i));
	}
	if (s == n)
		for (int i = p; i >= 0; i--)
			cout << koef[i] << " ";
	return 0;
}