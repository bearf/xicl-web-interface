#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <vector>

using namespace std;
typedef unsigned long long ull;

int main() {
	ull n;
	cin >> n;



	vector<int> a;
	vector<int> b;

	bool st = false;
	for (int i = 8 * sizeof(ull) - 2; i >= 0; i--) {
		bool is_one = (n & (1ULL << i)) != 0;

		if (is_one) {
			st = true;
			
		}

		if (st) {
			a.push_back(is_one ? 1 : 0);
		}
	}
	vector <int> res;
	vector <int> c;
	for(int i = a.size()-1 ; i >= 0; i--)
		c.push_back(a[i]);
	int k = 0, j = 0;
	for(int i = 0; i < c.size(); i++){
		if(c[i] == 1){
			k++;
		}
		else{
			if(k == 0){
				res.push_back(0);
			}else{
				if(k == 1){
					res.push_back(1);
					res.push_back(0);
				}
				else{
					res.push_back(-1);
					for(int l = 0; l <= k-2; l++)
					//for(int l = j+1; l <= i-1; l++)
						res.push_back(0);
					c[i] = 1;
					j = i;
					i--;
					
				}
			}
			k = 0;
		}
	}

	if(k == 1)
		cout << 1 << " ";
	else{
		cout << "1 ";
		for(int i = 1; i < k; i++)
			cout << "0 ";
		cout << -1 << " ";
		
	}
	for(int i = res.size() - 1; i >= 0; i--)
		cout << res[i] << " ";
	return 0;
}