#undef NDEBUG
#ifdef ssu1
#define _GLIBCXX_DEBUG
#endif

#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define fore(i, l, r) for(int i = (l); i < (r); ++i)
#define forn(i, n) fore(i, 0, n)
#define fori(i, l, r) fore(i, l, (r) + 1)
#define X first
#define Y second
#define sz(v) ((int)(v).size())
#define pb push_back
#define mp make_pair
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<ld, ld> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-11;
const ld PI = acosl(ld(-1));

pt operator -(const pt& a, const pt& b) {
    return pt(a.X - b.X, a.Y - b.Y);
}
pt operator +(const pt& a, const pt& b) {
    return pt(a.X + b.X, a.Y + b.Y);
}

ld dot(const pt& a, const pt& b) {
    return a.X * b.X + a.Y * b.Y;
}

pt rot90(const pt& v) {
    return pt(-v.Y, v.X);
}

pt operator *(const pt& v, ld k) {
    return pt(v.X * k, v.Y * k);
}

ld len(const pt& v) {
    return sqrtl(dot(v, v));
}

pt norm(const pt& v) {
    return v * (ld(1) / len(v));
}

ld readLd() {
    double x;
    assert(scanf("%lf", &x) == 1);
    return ld(x);
}

ld cross(const pt& a, const pt& b) {
    return a.X * b.Y - a.Y * b.X;
}

const int N = 200;
int n, totalN;
ld totalAng;

ld r, R;

ld getAng(const pt& v1, const pt& v2) {
    ld cs = dot(v1, v2) / len(v1) / len(v2);
    return acosl(max(ld(-1), min(ld(1), cs)));
}

bool cw(pt a, pt b, pt c) {
    return cross(b - a, c - b) < 0;
}

void add(ld left) {
    ld prevR = R;
    vector<pt> cur;
    cur.pb(pt(0, 0));
    while (left > EPS) {
        if (left + EPS >= 2 * r) {
            left -= 2 * r;
            totalN += 2;
            cur.pb(cur.back() + pt(prevR + r, 0));
        } else {
            if (left > r) {
                totalN++;
                left -= r;
            }
            totalN++;
            ld x = left + prevR;
            ld d = prevR + r;
            ld y = sqrtl(max(ld(0), d*d - x*x));
            cur.pb(cur.back() + pt(x, y));
            break;
        }
        prevR = r;
    }
    for (int i = sz(cur) - 3; i >= 0; i--) {
        int j = i + 1;
        int k = i + 2;
        if (!cw(cur[i], cur[j], cur[k])) {
            pt nrm = norm(rot90(cur[k] - cur[i]));
            cur[j] = cur[j] + nrm * (dot(cur[i] - cur[j], nrm) * 2);
        }
    }
    if (sz(cur) > 1)
        totalAng += 2 * getAng(cur[1], pt(1, 0));
}

pt a[N];
int main(){
    #ifdef ssu1
    assert(freopen("__input.txt", "r", stdin));
    #endif
    
    cin >> n;
    forn(i, n) {
        a[i].X = readLd();
        a[i].Y = readLd();
    }
    
    r = readLd();
    R = readLd();
    
    totalN = n;
    totalAng = (n - 2) * PI;
    
    forn(i, n) {
        int j = (i + 1) % n;
        add(len(a[i] - a[j]) / ld(2) - R);
    }
    
    cout << totalN - n << endl;
    ld ans = R * (2 * PI * n - totalAng) + r * (2 * PI * (totalN - n) - (PI * (totalN - 2) - totalAng));
    printf("%.10lf\n", double(ans));
    
    return 0;
}






