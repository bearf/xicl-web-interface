#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cmath>
#include <stack>
#include <map>
#include <algorithm>

using namespace std;
typedef long long ll;

struct tree  {
	int val, l, r;
	tree() {}
	tree(int val,  int l, int r): val(val), l(l), r(r) {}
};

tree t[1000002];

void build(int i, int l, int r) {
	t[i].l = l;
	t[i].r = r;
	if (l + 1 == r) {
		t[i].val = 0;
		return;
	}
	build(i * 2, l, (l + r) / 2);
	build(i * 2 + 1, (l + r) / 2, r);
	t[i].val = 0;
}

int getMax (int node, int l, int r) {
	if (t[node].r <= l || t[node].l >= r) {
		return 0;
	}
	if (l <= t[node].l && t[node].r <= r) {
		return t[node].val;
	}
	return max(getMax(node * 2, l, r), getMax(node * 2 + 1, l, r));
}

void update (int node, int pos, int x) {
	if (t[node].r <= pos || t[node].l > pos) {
		return;
	}
	if (t[node].l == pos && t[node].r == pos + 1) {
		t[node].val = x;
		return;
	}
	update(node * 2, pos, x);
	update(node * 2 + 1, pos, x);
	t[node].val = max(t[node * 2].val, t[node * 2 + 1].val);
}


int n;
vector <int> a, b;
map <int, int> s;

int main () {
//	freopen("input.txt", "r", stdin);freopen("output.txt", "w", stdout);
	cin >> n;
	build(1, 0, n + 1);
	a.resize( n + 1);
	b.resize(n + 1);
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		b[i] = a[i];
	}
	sort(b.begin() + 1, b.end());
	int coor = 1;
	for (int i = 1; i <= n; i++) {
		s[b[i]] = coor;
		coor++;
	}
	for (int  i = 1; i <= n; i++) {
		int mx = getMax(1, 0, s[a[i]] + 1);
		update(1, s[a[i]], mx + 1); 
	}
	cout << n - t[1].val;
	return 0;
}