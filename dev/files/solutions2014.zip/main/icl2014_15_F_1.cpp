#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;

int n;

const int maxn = (1 << 18) + 100;
int cur[maxn];

void dfs(int x, int pr = -1)
{
	while (cur[x] < n)
	{
		int a = cur[x];
		cur[x]++;
		dfs(x ^ (1 << a), a);
	}
	if (pr != -1)
		printf("%d ", pr + 1);
}



int main ()
{


	scanf("%d", &n);
	printf("%d\n", (1 << n) * n);
	dfs(0);

	

	return 0;
}