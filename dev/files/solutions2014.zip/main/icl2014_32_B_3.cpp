#include <iostream>
#include <string>
#include <math.h>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;
int main() {
	int n,k;
	long long kol = 0;
	cin >> n>>k;
	for (int i = 0 ;i<10000000;i++)
		if(n-i<=i && n-i>=k-1 )
		{
			kol++;
		}
	cout<<kol;
	return 0;
}