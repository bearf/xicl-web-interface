#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;

typedef pair<int, int> pii;
#define X first
#define Y second
#define mp make_pair
const int N = (int)1e6 + 10;

int a[N];
int go[N];
pii listC[N];
int endBlock[N];
int ans = 0;

void solve(int a, int b, int n)
{
	ans = max(ans, b - a + 1);
	int pos = (b + 1 == n ? n + 1 : listC[b + 1].Y);
	int l = a - 1, r = b + 1;
	while (r - l > 1)
	{
		int m = (l + r) / 2;
		if (listC[m].Y > pos)
			r = m;
		else
			l = m;
	}
	int locCnt = 0;
	if (l >= a && b + 1 < n)
	{
		int to = go[b + 1];
		locCnt = l - a + 1 + to - (b + 1) + 1;
		if (to != n - 1)
		{
			l = (to + 1) - 1;
			r = endBlock[to + 1] + 1;
			while (r - l > 1)
			{
				int m = (l + r) / 2;
				if (listC[m].Y > listC[to].Y)
					r = m;
				else
					l = m;
			}
			locCnt += endBlock[to + 1] - r + 1;
		}
	}
	ans = max(ans, locCnt);
	if (b + 1 < n)
	{
		for (int i = a; i <= b; i++)
		{
			l = (b + 1) - 1;
			r = endBlock[b + 1] + 1;
			while (r - l > 1)
			{
				int m = (l + r) / 2;
				if (listC[m].Y > listC[i].Y)
					r = m;
				else
					l = m;
			}
			ans = max(ans, i - a + 1 + endBlock[b + 1] - r + 1);
		}
	}
}

int main()
{
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
		listC[i] = mp(a[i], i);
	}

	sort(listC, listC + n);

	go[n - 1] = n - 1;
	for (int i = n - 2; i >= 0; i--)
	{
		if (listC[i].Y < listC[i + 1].Y)
			go[i] = go[i + 1];
		else
			go[i] = i;
	}

	int lst = listC[0].X;
	int cnt = 1;
	for (int i = 1; i < n; i++)
	{
		if (listC[i].X == lst)
			cnt++;
		else
		{
			endBlock[i - cnt] = i - 1;
			lst = listC[i].X;
			cnt = 1;
		}
	}
	endBlock[n - cnt] = n - 1;

	lst = listC[0].X;
	cnt = 1;
	for (int i = 1; i < n; i++)
	{
		if (listC[i].X == lst)
			cnt++;
		else
		{
			solve(i - cnt, i - 1, n);
			lst = listC[i].X;
			cnt = 1;
		}
	}

	solve(n - cnt, n - 1, n);
	cout << n - ans;

	return 0;
}