#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <stdio.h>
#include <queue>
#include <deque>
#define USE_MATH_DEFINES
#include <math.h>

#define ll long long
#define ull unsigned ll
#define mp make_pair
#define pb push_back

using namespace std;

const int MOD = 1000000009;
const ll INF = 1000000000000000;

int dp[1000006][20];
int ans = 0;

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	int n, k;
	int pow2[25];

	pow2[0] = 1;
	for (int i(1); i < 25; i++) {
		pow2[i] = pow2[i-1] * 2;
	}

	cin >> n >> k;

	dp[0][0] = 1;
	for (int j(0); j < k; j++) {
		for (int i(0); i < n; i++) {
			if (j == k - 1) {
				if (i <= n - i)
					ans += dp[i][j];
				continue;
			}

			if (dp[i][j] != 0) {
				int a;
				if (i == 0)
					a = 1;
				else
					a = i;

				int q = (n - a) / (pow2[k - j - 1] - 1) - i;

				for (; a <= q; a++) {
					dp[i + a][j + 1] = (dp[i + a][j + 1] + dp[i][j]) % MOD;
				}
			}
		}
	}

	cout << ans;
}