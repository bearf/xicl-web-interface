#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;

const int mod = (int)1e9 + 9;
const int pow2 = (1 << 20);
const int K = 30;
const int N = (int)1e6 + 10;

int add(int a, int b)
{
	a += b;
	if (a >= mod)
		a -= mod;
	return a;
}

struct SegmentTree
{
	int tree[pow2 * 2];
	void build()
	{
		for (int i = 0; i < pow2 * 2; i++)
			tree[i] = 0;
	}
	void relax(int pos, int val, int v = 1, int l = 0, int r = pow2 - 1)
	{
		if (l == r)
		{
			tree[v] = max(tree[v], val);
			return;
		}
		int m = (l + r) / 2;
		if (pos <= m)
			relax(pos, val, 2 * v, l, m);
		else
			relax(pos, val, 2 * v + 1, m + 1, r);
		tree[v] = max(tree[2 * v], tree[2 * v + 1]);
	}
	int getMax(int a, int b, int v = 1, int l = 0, int r = pow2 - 1)
	{
		if (l >= a && r <= b)
			return tree[v];
		if (l > b || r < a)
			return 0;
		int m = (l + r) / 2;
		return max(getMax(a, b, 2 * v, l, m), getMax(a, b, 2 * v + 1, m + 1, r));
	}
} tree; 
int a[N];
int listC[N];

int main()
{
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
		listC[i] = a[i];
	}
	sort(listC, listC + n);
	int cnt = unique(listC, listC + n) - listC;

	for (int i = 0; i < n; i++)
	{
		a[i] = lower_bound(listC, listC + cnt, a[i]) - listC;
	}


	for (int i = 0; i < n; i++)
	{
		int t = tree.getMax(0, a[i]);
		tree.relax(a[i], t + 1);
	}

	cout << n - tree.getMax(0, n);

	return 0;
}