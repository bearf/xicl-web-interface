#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cassert>
#include <ctime>
#include <memory.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <complex>
#include <list>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef complex <ld> point;

#define pb push_back
#define mp make_pair
#define fi first
#define se second

#define INF 1000000001
#define INFL 1000000000000000001ll
#define NAME "i"

char s[200001];
char S[200001];

int main() {
    #ifdef _GEANY
    assert(freopen(NAME ".in", "r", stdin));
    #endif // _GEANY
    ll t;
    int n;
    cin >> t >> n;
    scanf("%s", s);
    for (int i = 0; i < n; ++i)
        s[i] -= '0';
    ll d = 1;
    while (t) {
        if (t % 2 == 1) {
            for (ll i = 0; i < n; ++i) {
                int x1 = (i - d < 0 ? 0 : s[i - d]);
                int x2 = (i + d >= n ? 0 : s[i + d]);
                S[i] = char(x1 ^ x2);
            }
            memcpy(s, S, sizeof(s));
        }
        d *= 2;
        t /= 2;
    }
    for (int i = 0; i < n; ++i)
        cout << int(s[i]);
    cout << endl;
}
