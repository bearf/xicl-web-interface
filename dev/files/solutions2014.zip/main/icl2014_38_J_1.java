import java.io.*;
import java.util.*;

public class J {

	FastScanner in;
	PrintWriter out;

	List<String> coms = Arrays.asList("ADD", "FIND", "REMOVE");

	int[] left, right, parent;

	void removeChild(int v) {
		int par = parent[v];
		if (par == -1) {
			return;
		}
		if (left[par] == v) {
			left[par] = -1;
		} else {
			right[par] = -1;
		}
	}

	void setLeftChild(int v) {
		if (v == -1) {
			return;
		}
		int par = parent[v];
		if (par == -1) {
			return;
		}
		left[par] = v;
	}

	void setRightChild(int v) {
		if (v == -1) {
			return;
		}
		int par = parent[v];
		if (par == -1) {
			return;
		}
		right[par] = v;
	}

	void solve() {
		int n = in.nextInt();
		int[] type = new int[n], val = new int[n];
		for (int i = 0; i < n; i++) {
			type[i] = coms.indexOf(in.nextToken());
			val[i] = in.nextInt();
		}

		Map<Integer, Integer> map = compress(val);
		for (int i = 0; i < n; i++) {
			val[i] = map.get(val[i]);
		}

		int m = map.size();
		left = new int[m];
		right = new int[m];
		parent = new int[m];

		Arrays.fill(left, -1);
		Arrays.fill(right, -1);
		Arrays.fill(parent, -1);

		SegmentTree height = new SegmentTree(m);
		TreeSet<Integer> have = new TreeSet<>();
		for (int i = 0; i < n; i++) {
			int cur = val[i];

			if (type[i] == 0) {
				if (have.contains(cur)) {
					out.print("FALSE ");
				} else {
					out.print("TRUE ");
					have.add(cur);

					Integer lower = have.lower(cur), upper = have.higher(cur);
					if (lower == null && upper == null) {
						height.set(cur, 1);
					} else {

						int max = -1, maxH = -1;

						if (lower != null) {
							if (height.get(lower) > maxH) {
								max = lower;
								maxH = height.get(lower);
							}
						}
						if (upper != null) {
							if (height.get(upper) > maxH) {
								max = upper;
								maxH = height.get(upper);
							}
						}

						if (max > cur) {
							setLeftChild(cur);
						} else {
							setRightChild(cur);
						}
						height.set(cur, maxH + 1);
					}
				}

				out.println(height.get(cur));
			} else if (type[i] == 1) {

				if (have.contains(cur)) {
					out.print("TRUE ");
					out.println(height.get(cur));
				} else {
					out.print("FALSE ");
					Integer lower = have.lower(cur), upper = have.higher(cur);
					int max = 1;
					if (lower != null) {
						max = Math.max(max, height.get(lower));
					}
					if (upper != null) {
						max = Math.max(max, height.get(upper));
					}
					out.println(max);
				}

			} else {

				if (!have.contains(cur)) {
					out.print("FALSE ");
					Integer lower = have.lower(cur), upper = have.higher(cur);
					int max = 1;
					if (lower != null) {
						max = Math.max(max, height.get(lower));
					}
					if (upper != null) {
						max = Math.max(max, height.get(upper));
					}
					out.println(max);
				} else {
					out.print("TRUE " + height.get(cur));
					have.remove(cur);

					if (left[cur] == -1 && right[cur] == -1) {
						removeChild(cur);
					} else if (left[cur] == -1) {

						int l = cur, r = m;
						int curH = height.get(cur);
						while (l + 1 < r) {
							int mid = (l + r) >> 1;
							int min = height.get(cur, mid);
							if (min < curH) {
								r = mid;
							} else {
								l = mid;
							}
						}

						height.add(cur, l, -1);
						int par = parent[cur];
						if (par != -1) {
							if (left[par] == cur) {
								left[par] = right[cur];
							} else {
								right[par] = right[cur];
							}
						}

						parent[right[cur]] = par;

					} else if (right[cur] == -1) {

						int l = -1, r = cur;
						int curH = height.get(cur);
						while (l + 1 < r) {
							int mid = (l + r) >> 1;
							int min = height.get(cur, mid);
							if (min < curH) {
								l = mid;
							} else {
								r = mid;
							}
						}

						height.add(r, cur, -1);
						int par = parent[cur];
						if (par != -1) {
							if (left[par] == cur) {
								left[par] = left[cur];
							} else {
								right[par] = left[cur];
							}
						}

						parent[left[cur]] = par;

					} else {
						int newNode = have.higher(cur);
						removeChild(newNode);

						left[newNode] = left[cur];
						right[newNode] = right[cur];
						parent[newNode] = parent[cur];

						if (left[newNode] != -1) {
							parent[left[newNode]] = newNode;
						}
						if (right[newNode] != -1) {
							parent[right[newNode]] = newNode;
						}

						height.set(newNode, height.get(cur));
						int par = parent[cur];
						if (par != -1) {
							if (left[par] == cur) {
								left[par] = newNode;
							} else {
								right[par] = newNode;
							}
						}
					}

					left[cur] = right[cur] = parent[cur] = -1;
					height.set(cur, Integer.MAX_VALUE / 2);
				}
			}
		}

	}

	class SegmentTree {
		int[] add, tree;
		int size;

		public SegmentTree(int n) {
			size = n;
			add = new int[4 * n];
			tree = new int[4 * n];
			Arrays.fill(tree, Integer.MAX_VALUE);
		}

		void addValue(int i, int val) {
			add[i] += val;
			tree[i] += val;
		}

		void give(int i, int l, int r) {
			if (l + 1 != r) {
				addValue(2 * i + 1, add[i]);
				addValue(2 * i + 2, add[i]);
			}
			add[i] = 0;
		}

		int get(int k) {
			return get(k, k);
		}

		int get(int left, int right) {
			return get(left, right + 1, 0, size, 0);
		}

		int get(int l, int r, int left, int right, int i) {
			give(i, left, right);
			if (l <= left && right <= r) {
				return tree[i];
			} else if (right <= l || r <= left) {
				return Integer.MAX_VALUE;
			} else {
				int mid = (left + right) >> 1;
				int ans1 = get(l, r, left, mid, 2 * i + 1);
				int ans2 = get(l, r, mid, right, 2 * i + 2);
				update(i);
				return Math.min(ans1, ans2);
			}
		}

		private void update(int i) {
			tree[i] = Math.min(tree[i * 2 + 1], tree[2 * i + 2]);
		}

		void set(int pos, int val) {
			set(pos, val, 0, size, 0);
		}

		void set(int pos, int val, int left, int right, int i) {
			if (left + 1 == right) {
				tree[i] = val;
				return;
			}
			give(i, left, right);
			int mid = (left + right) >> 1;
			if (pos < mid) {
				set(pos, val, left, mid, 2 * i + 1);
			} else {
				set(pos, val, mid, right, 2 * i + 2);
			}
		}

		void add(int from, int to, int val) {
			add(0, size, from, to, val, 0);
		}

		void add(int left, int right, int l, int r, int val, int i) {
			give(i, left, right);
			if (l <= left && right <= r) {
				addValue(i, val);
				return;
			} else if (right <= l || r <= left) {
				return;
			} else {
				int mid = (left + right) >> 1;
				add(left, mid, l, r, val, 2 * i + 1);
				add(mid, right, l, r, val, 2 * i + 2);
			}
		}
	}

	private Map<Integer, Integer> compress(int[] val) {
		int[] a = val.clone();
		Arrays.sort(a);
		int size = 1;
		Map<Integer, Integer> map = new HashMap<>();
		map.put(a[0], 0);
		for (int i = 1; i < a.length; i++) {
			if (a[i] != a[i - 1]) {
				map.put(a[i], size);
				size++;
			}
		}
		return map;
	}

	void run() {
		try {
			in = new FastScanner();
			out = new PrintWriter(System.out);
			solve();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	class FastScanner {
		BufferedReader br;
		StringTokenizer st;

		public FastScanner() {
			br = new BufferedReader(new InputStreamReader(System.in));
		}

		String nextToken() {
			while (st == null || !st.hasMoreElements()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return st.nextToken();
		}

		int nextInt() {
			return Integer.parseInt(nextToken());
		}

		long nextLong() {
			return Long.parseLong(nextToken());
		}

		double nextDouble() {
			return Double.parseDouble(nextToken());
		}
	}

	public static void main(String[] args) {
		new J().run();
	}
}
