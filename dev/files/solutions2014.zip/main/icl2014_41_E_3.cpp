#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

#define f first
#define s second

const int maxN = 200002;
const int mx = 1e9;

pii a[maxN];
int b[maxN], c[maxN], d[maxN], e[maxN];
int n;
int ans;

int main() {

    cin >> n;
	for (int i = 0; i < n; i++) {
		scanf("%d", &a[i].f);
		a[i].s = i;
	}
	a[n].f = mx + 1;
	a[n].s = n;
	sort(a, a + n + 1);
	c[n] = n;
	for (int i = n - 1; i >= 0; i--)
		if (a[i].f != a[i + 1].f)
			c[i] = i;
		else
			c[i] = c[i + 1];

	b[n] = 0;
	b[n - 1] = 1;
	d[n - 1] = n;
	e[n] = 0;
	e[n - 1] = 1;
	int ans = 1;
	for (int i = n - 2; i >= 0; i--) {
		b[i] = 1;
		if (a[i].s < a[i + 1].s)
			b[i] = b[i + 1] + 1;
		if (c[i] == i) {
			d[i] = c[i + 1];
			while (d[i] > c[i] && a[i].s < a[d[i]].s)
				d[i]--;
			b[i] = max(b[i], c[c[i] + 1] - d[i] + 1);
		}
		e[i] = b[i];
		if (c[i] != i)
			e[i] = max(e[i], e[i + 1] + 1);
		if (a[i].s < a[c[i] + 1].s)
			e[i] = max(e[i], b[c[i] + 1] + 1);
		if (c[i] != i) {
			d[i] = d[i + 1];
			while (d[i] > c[i] && a[i].s < a[d[i]].s)
				d[i]--;
			e[i] = max(e[i], c[c[i] + 1] - d[i] + 1);
		}		
		//cout << b[i] << ' ' << e[i] << ' ' << d[i] << endl;
		
		ans = max(ans, e[i]);
	}

	cout << n - ans << endl;

	return 0;
}
