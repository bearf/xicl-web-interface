#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <list>

using namespace std;

#define mp make_pair
#define pb push_back

int n, a[ 200100 ], answer = 0, pref[ 200100 ], h;
pair< int, int > range[ 200100 ];
map< int, int > compress;
vector< int > pos[ 200100 ];

int fnum( int l, int r )
{
    return pref[r] - pref[l - 1];
}

int find_below( int lim, int id )
{
    if ( pos[ id ].size() == 0 ) return 0;
    if ( pos[ id ][ 0 ] >= lim ) return 0;
    int l = 1, r = pos[ id ].size() - 1, result = 0;
    while ( l <= r )
    {
        int x = (l + r) / 2;
        if ( pos[ id ][ x ] < lim )
        {
            result = max( result, x );
            l = x + 1;
        } else r = x - 1;
    }
    return result + 1;
}

int find_above( int lim, int id )
{
    if ( pos[ id ].size() == 0 ) return 0;
    if ( pos[ id ].back() <= lim ) return 0;
    if ( pos[ id ].size() == 1 ) return 1;
    int l = 0, r = pos[ id ].size() - 2, result = pos[ id ].size() - 1;
    while ( l <= r )
    {
        int x = (l + r) / 2;
        if ( pos[ id ][ x ] > lim )
        {
            result = min( result, x );
            r = x - 1;
        } else l = x + 1;
    }
    return pos[ id ].size() - result;
}

int main()
{
    scanf("%d", &n);
    for ( int i = 1; i <= n; i++ )
    {
        scanf("%d", &a[i]);
        compress[ a[i] ] = 1;
    }
    for ( map< int, int >::iterator it = compress.begin(); it != compress.end(); it++ )
    {
        range[ ++h ] = make_pair( n + 1, 0 );
        it->second = h;
    }
    for ( int i = 1; i <= n; i++ )
    {
        a[i] = compress[ a[i] ];
        range[ a[i] ].first = min( range[ a[i] ].first, i );
        range[ a[i] ].second = max( range[ a[i] ].second, i );
        pos[ a[i] ].push_back( i );
    }
    for ( int i = 1; i <= h; i++ ) pref[i] = pref[i - 1] + pos[i].size();
    /*for ( int i = 1; i <= h; i++ )
    {
       cout << i << " " << range[i].first << " " << range[i].second << " " << pos[i].size() << "\n";
    }*/
    int pointer = 1;
    for ( int i = 1; i <= h; i++ )
    {
        pointer = max( i, pointer );
        while ( true )
        {
            if ( pointer == h ) break;
            if ( range[pointer].second > range[pointer + 1].first ) break;
            pointer++;
        }
        int current = fnum( i, pointer ) + find_below( range[i].first, i - 1 ) + find_above( range[pointer].second, pointer + 1 );
        answer = max( answer, current );
    }
    for ( int i = 1; i < h; i++ )
        for ( int j = 0; j < (int)pos[i].size(); j++ )
        {
            int id = pos[i][j];
            int current = j + 1 + find_above( id, i + 1 );
            answer = max( answer, current );
        }
    printf("%d", n - answer);
    return 0;
}

