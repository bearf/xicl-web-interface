#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cmath>
#include <stack>

using namespace std;

long long n;
stack<int> st;
int main () {
	//freopen("input.txt", "r", stdin);freopen("output.txt", "w", stdout);
	cin >> n;
	while(n != 0){
		if(n % 2 == 0){
			st.push(0);
			n /= 2;
			continue;
		}
		if((n & 3) == 3){
			st.push(-1);
			st.push(0);
			n /= 4;
			n++;
		} else {
			st.push(1);
			n /= 2;
		}
	}
	while(!st.empty()){
		cout << st.top() << " ";
		st.pop();
	}
	return 0;
}