#include<stdio.h>
//#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#define mp make_pair

using namespace std;

int n;
double a[33333], b[33333], c[33333];
int xs, ys, xf, yf;

pair<double, double> f(double x, double y) {
	for (int i = 1; i <= n; i++) {
		double d = a[i] * x + b[i] * y + c[i];
		x += (-a[i]) * d;
		y += (-b[i]) * d;
//		printf("%.5lf\n", a[i] * x + b[i] * y + c[i]);
	}
	return mp(x, y);
}

double value(double x, double y) {
	pair<double, double> e = f(x, y);
	return (x - e.first) * (x - e.first) + (y - e.second) * (y - e.second);
}

double t(double x, double y) {
	if (ys == yf) {
		return (x - xs) / 1. / (xf - xs);		
	} else {
		return (y - ys) / 1. / (yf - ys);		
	}
}

int main() {
//	freopen("1.in", "r", stdin);
//	freopen("1.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		int x, y, xx, yy;
		scanf("%d%d%d%d", &x, &y, &xx, &yy);
		if (i == 0) {
			xs = x;
			ys = y;
			xf = xx;
			yf = yy;
		}
		a[i] = yy - y;
		b[i] = x - xx;
		double s = sqrt(a[i] * a[i] + b[i] * b[i]);
		a[i] /= s;
		b[i] /= s;
		c[i] = -a[i] * x - b[i] * y;
	}
	a[n] = a[0];
	b[n] = b[0];
	c[n] = c[0];
	double f0 = t(f(xs, ys).first, f(xs, ys).second);
	double f1 = t(f(xf, yf).first, f(xf, yf).second);
//	printf("%.8lf %.8lf\n", f0, f1);

	double d = f1 - f0;
//	printf("%.8lf\n", d);
	if (fabs(d - 1) < 1e-9) {
		if (fabs(f0) < 1e-9) {
			printf("%.8lf %.8lf\n", xs, ys);
		} else {
			puts("-1");
		}
		return 0;
	}
	double tt = f0 / (1 - d);
	double X = xs + tt * (xf - xs);
	double Y = ys + tt * (yf - ys);
	printf("%.8lf %.8lf\n", X, Y);
}