#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <vector>

using namespace std;

#define long long long

int buf[100], bn;

void solve(long n, int k, int sgn) {
	for (int i=0; i<k; i++)
		buf[i] = 0;

	bn = 0;
	long m = n;
	while (m) {
		buf[bn++] = m & 1;
		m >>= 1;
	}

	for (int i=0; i<bn; i++)
		buf[i] *= sgn;

	int i = bn-1;
	for (; i>0; i--)
		if (buf[i] * buf[i-1])
			break;

	if (i != 0) {
		while (buf[i] + buf[i+1])
			i++;

		buf[i] = sgn;

		n &= ((1LL<<i)-1);
		solve((1LL<<i) - n, i, -sgn);
	}
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif
	long n;
	cin >> n;

	solve(n, 100, 1);

	int k = 99;
	while (!buf[k] && k>0)
		k--;

	for (int i=k; i>=0; i--)
		cout << buf[i] << " ";
	cout << endl;

	return 0;
}