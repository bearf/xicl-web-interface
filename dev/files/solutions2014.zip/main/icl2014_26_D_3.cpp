#include<iostream>
#include <deque>
using namespace std;
int main()
{
	int n;
	cin >> n;
	int s = 0;

	if(n == 10){
		cout << 1023456789;
		return 0;
	} else if(n/10 == 0){
		for(int i = 1; i <= n; i++){
			cout << i;
		}
		return 0;
	}
	if(n>10&&n<100)
	{
		int a=n/11;
		for(int i = a;i>=1;i--)
		{
			cout<<i;
		}
		cout<<1023456789;
	}
	if(n>=100&&n<1000)
	{
		int a=n/111;
		for(int i = a;i>=1;i--)
		{
			cout<<i;
		}
		cout<<10234567891023456789;
	}
	if(n>=1000&&n<10000)
	{
		int a=n/1111;
		for(int i = a;i>=1;i--)
		{
			cout<<i;
		}
		cout<<1023456789<<1023456789<<1023456789;
	}
	if(n>=10000&&n<100000)
	{
		int a=n/11111;
		for(int i = a;i>=1;i--)
		{
			cout<<i;
		}
		cout<<1023456789<<1023456789<<1023456789<<1023456789;
	}
	if(n==100000)
	{
		cout<<1023456789<<1023456789<<1023456789<<1023456789<<1023456789;
	}
	return 0;
}
