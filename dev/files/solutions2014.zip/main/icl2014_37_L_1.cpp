#include <iostream>
using namespace std;


int main()
{
	int n;
	cin >> n;
	int a, s = 0, k = 0;
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
		{
			cin >> a;
			s += a;
			if (a == 0)
				k++;
		}
	if (2*k < (n*n))
		cout << s;
	else
		cout << -1;
	return 0;
}