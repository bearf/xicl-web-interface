#ifdef SU2_PROJ
#define _GLIBCXX_DEBUG
#endif

#include <algorithm>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <string>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define forn(i, n) for (int i = 0; i < int(n); i++)
#define forl(i, n) for (int i = 1; i <= int(n); i++)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; i--)
#define fore(i, l, r) for (int i = int(l); i <= int(r); i++)
#define correct(x, y, n, m) (0 <= (x) && (x) < (n) && 0 <= (y) && (y) < (m))
#define pb(a) push_back(a)
#define all(a) (a).begin(), (a).end()
#define mp(x, y) make_pair((x), (y))
#define sz(a) int((a).size())
#define ft first
#define sc second
#define x first
#define y second

using namespace std;

typedef long long li;
typedef long double ld;
typedef pair <int, int> pt;

inline ostream& operator << (ostream& out, const pt& p) { return out << "(" << p.x << ", " << p.y << ")"; }

const int INF = int(1e9);
const li INF64 = li(1e18);
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

const int N = 200 * 1000 + 13;

int n;
int a[N], b[N], szb;
vector <int> pos[N];

inline bool read ()
{
	if (scanf("%d", &n) != 1) return false;
	
	forn(i, n)
	{
		assert(scanf("%d", &a[i]) == 1);
		b[i] = a[i];
	}
	
	szb = n;
	sort(b, b + szb);
	szb = int(unique(b, b + szb) - b);
	
	forn(i, n) a[i] = int(lower_bound(b, b + szb, a[i]) - b);
	
	forn(i, n) pos[a[i]].pb(i);
	
	return true;
}

inline int calc1 ()
{
	int ans = 0;
	
	forn(i, n)
	{
		int val = a[i];
		int id1 = int(lower_bound(all(pos[val]), i) - pos[val].begin());
		int id2 = int(lower_bound(all(pos[val + 1]), i + 1) - pos[val + 1].begin());
		
		int cur = id1 + 1 + sz(pos[val + 1]) - id2;
		
		ans = max(ans, cur);
	}
	
	return ans;
}

inline int getL (int val, int p)
{
	if (val < 0) return 0;
	int idx = int(lower_bound(all(pos[val]), p) - pos[val].begin());
	return idx;
}

inline int getR (int val, int p)
{
	int idx = int(lower_bound(all(pos[val]), p) - pos[val].begin());
	return sz(pos[val]) - idx;
}

inline void solve ()
{
	int ans = calc1();
	
	for (int i = 0; i < szb; )
	{
		int cnt = getL(i - 1, pos[i][0]);
		
		//cerr << cnt << endl;
		
		while (true)
		{
			if (!pos[i + 1].empty() && pos[i].back() < pos[i + 1][0]) cnt += sz(pos[i++]);
			else break;
		}
		
		//cerr << "! " << cnt << endl;
		
		cnt += sz(pos[i]);
		
		//cerr << cnt << endl;
		
		cnt += getR(i + 1, pos[i].back());
		
		//cerr << cnt << endl;
		
		i++;
		
		ans = max(ans, cnt);
	}
	
	cout << n - ans << endl;
}

int main()
{
#ifdef SU2_PROJ
	freopen("input.txt", "rt", stdin);
	//freopen("output.txt", "wt", stdout);
#endif

	cout << setprecision(10) << fixed;
	cerr << setprecision(5) << fixed;
	
	assert(read());
	solve();
	
#ifdef SU2_PROJ
	cerr << "=== Time: " << clock() << " ===" << endl;
#endif

	return 0;
}
