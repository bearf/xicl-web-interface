#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>
using namespace std;

const int N = (int)1e5 + 100;
const int LOG = 18;

vector <int> g[N];
int par[N];
bool exist[N];
bool used[N];
int h[N];
int cntEdge = 0;

void dfs(int v)
{
	used[v] = 1;
	for (int i = 0; i < (int)g[v].size(); i++)
	{
		int to = g[v][i];
		if (!used[to])
		{
			h[to] = h[v] + 1;
			par[to] = v;
			dfs(to);
		}
	}
}

void solve(int x)
{
	int st = x;
	while (!exist[x])
	{
		exist[x] = 1;
		cntEdge++;
		x = par[x];
	}
	printf("%d ", 2 * cntEdge - h[st]);
}

int main()
{
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n - 1; i++)
	{
		int a, b;
		scanf("%d%d", &a, &b);
		g[a].push_back(b);
		g[b].push_back(a);
	}

	dfs(1);
	exist[1] = 1;
	int q;
	scanf("%d", &q);
	for (int i = 0; i < q; i++)
	{
		int x;
		scanf("%d", &x);
		solve(x);
	}

	return 0;
}