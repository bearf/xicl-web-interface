#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <list>

using namespace std;

#define mp make_pair
#define pb push_back

list<int>l1, l2;
int n;
int main()
{
    cin>>n;
    l1.push_back(1); l1.push_back(1);
    l2.push_back(1); l2.push_back(1);
    for (int i=2; i<=n; i++)
    {
        for (list<int>::iterator it=l2.begin(); it!=l2.end(); it++)
        {
            if ( (*it)==i-1 )
            {
                list<int>::iterator ins=it; ++ins;
                l2.insert(ins, i);
                l2.insert(ins, i);
            }
        }
        l2.pop_back();
        for (list<int>::iterator it=l1.begin(); it!=l1.end(); it++)
            l2.push_back(*it);
        l2.push_back(i);
        l1=l2;
    }
    printf("%d\n", l1.size());
    for (list<int>::iterator it=l1.begin(); it!=l1.end(); it++)
        printf("%d ", *it);
    return 0;
}

