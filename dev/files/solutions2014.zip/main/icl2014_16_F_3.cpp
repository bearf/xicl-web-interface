#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cmath>
#include <stack>
#include <map>
#include <algorithm>

using namespace std;
typedef long long ll;

int n;
vector<int> xv;

int main () {
	//freopen("input.txt", "r", stdin);freopen("output.txt", "w", stdout);
	cin >> n;
	xv.reserve(2 << n);
	xv.resize(1);
	xv[0] = 1;
	int ss = 1;
	for(int i = 1; i <= n; i++){
		ss = xv.size();
		xv.resize(ss * 2);
		xv[ss] = i;
		for(int j = 1; j < ss; j++){
			xv[j + ss] = xv[j];
		}
	}
	cout << xv.size() * n << "\n";
	for(int i = 0; i < n; i++){
		for(int j = 0; j < xv.size(); j++){
			xv[j]++;
			if(xv[j] == n + 1){
				xv[j] = 1;
			}
			printf("%d ", xv[j]);
		}
	}
	return 0;
}