#define MAXL 10000
#define INF 1E+9
#define EPS 1E-9 
#define PROB "a"

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <string>
#include <cstring>
#include <cmath>

using namespace std;

int main(){

	int n, ans = 0, k1 = 0, k2;

	cin >> n;

	k2 = n*n;

	for (int i = 0; i < n; ++i)
		for (int j = 0, x; j < n; ++j){
			cin >> x;

			if (x){
				++k1;
				--k2;
				ans += x;
			}

		}

	if (k2 < k1)
		printf("%d", ans);
	else
		printf("-1");

	return 0;
}