#include <iostream>
#include <map>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
using namespace std;

#if LOCAL
	#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
	#define eprintf(...) 42;
#endif

const int X = 1543;
const int MOD = 1000000007;

char s[111111];
char ns[111111];
map <int, int> was;
int main() {
#ifdef LOCAL
	freopen("i.in", "r", stdin);
#endif
	long long T;
	int n;
	cin >> T >> n;
	scanf("%s", s);
	int pp = 0;
	int p;
	for (int it = 0; ; it++) {
		if (T == it) {
			puts(s);
			return 0;
		}
		int h = 0;
		for (int i = 0; i < n; i++) {
			h = (h * 1LL * X + s[i]) % MOD;
		}
		if (was.find(h) != was.end()) {
			pp = was[h];
			p = it - was[h];
			break;
		}
		was[h] = it;
		for (int i = 0; i < n; i++) {
			int val = 0;
			for (int j = -1; j <= 1; j += 2) {
				if (0 <= i + j && i + j < n && s[i + j] == '1') {
					val ^= 1;
				}
			}
			ns[i] = '0' + val;
		}
		for (int i = 0; i < n; i++) {
			s[i] = ns[i];
		}
	}
	T -= pp;
	T %= p;
	for (int it =0 ; it < T; it++) {
		for (int i = 0; i < n; i++) {
			int val = 0;
			for (int j = -1; j <= 1; j += 2) {
				if (0 <= i + j && i + j < n && s[i + j] == '1') {
					val ^= 1;
				}
			}
			ns[i] = '0' + val;
		}
		for (int i = 0; i < n; i++) {
			s[i] = ns[i];
		}
	}
	puts(s);
	return 0;
}