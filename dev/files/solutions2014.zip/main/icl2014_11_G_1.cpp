#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <queue>
#include <deque>
#include <complex>

using namespace std;

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define all(x) (x).begin(), (x).end()
#define fs first
#define sc second
#define y0 yy0
#define y1 yy1
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define prev _prev
#define rank _rank
#define link _link
#define hash _hash
#define next _next
#ifdef LOCAL
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef complex<double> tc;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));
const int LOG = 17;
const int N = int(1e5) + 100;

int ptr;
bool used[N];
int h[N], num[N];
int p[LOG][N];
vi g[N];
set<pii> S;

void dfs(int v, int ch = 0) {
	used[v] = true;
	h[v] = ch;
	for (int i = 0; i < sz(g[v]); ++i) {
		if (!used[g[v][i]]) {
			p[0][g[v][i]] = v;
			dfs(g[v][i], ch + 1);
		}
	}
	num[v] = ptr++;
}

inline int getLCA(int a, int b) {
	if (h[a] > h[b]) {
		swap(a, b);
	}
	for (int i = LOG - 1; i >= 0; --i) {
		if (p[i][b] != -1 && h[p[i][b]] >= h[a]) {
			b = p[i][b];
		}
	}
	if (a == b) {
		return a;
	}
	for (int i = LOG - 1; i >= 0; --i) {
		if (p[i][a] != p[i][b]) {
			a = p[i][a];
			b = p[i][b];
		}
	}
	return p[0][a];
}

inline int getDist(int a, int b) {
	int c = getLCA(a, b);
	return h[a] + h[b] - 2 * h[c];
}

int main() {
#ifdef LOCAL
#define TASK "G"
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n - 1; ++i) {
		int a, b;
		scanf("%d %d", &a, &b);
		--a;
		--b;
		g[a].pb(b);
		g[b].pb(a);
	}
	for (int i = 0; i < LOG; ++i) {
		for (int j = 0; j < n; ++j) {
			p[i][j] = -1;
		}
	}
	ptr = 0;
	dfs(0);
	for (int i = 1; i < LOG; ++i) {
		for (int j = 0; j < n; ++j) {
			if (p[i - 1][j] != -1) {
				p[i][j] = p[i - 1][p[i - 1][j]];
			}
		}
	}
	int m;
	scanf("%d", &m);
	int root, sum = 0;
	for (int i = 0; i < m; ++i) {
		int v;
		scanf("%d", &v);
		--v;
		if (i == 0) {
			root = v;
			S.insert(mp(num[v], v));
			printf("%d ", h[v]);
			continue;
		}
		set<pii>::iterator it = S.lower_bound(mp(num[v], v));
		if (it != S.end()) {
			if (it != S.begin()) {
				set<pii>::iterator prev = it;
				--prev;
				sum -= getDist(prev->sc, it->sc);
			}
			sum += getDist(v, it->sc);
		}
		else {
			set<pii>::iterator end = S.end();
			--end;
			sum -= getDist(S.begin()->sc, end->sc);
			sum += getDist(S.begin()->sc, v);
		}
		if (it != S.begin()) {
			--it;
			sum += getDist(it->sc, v);
		}
		else {
			set<pii>::iterator end = S.end();
			--end;
			sum -= getDist(S.begin()->sc, end->sc);
			sum += getDist(v, end->sc);
		}
		S.insert(mp(num[v], v));
		root = getLCA(root, v);
		printf("%d ", sum - (h[v] - h[root]) + h[root]);
	}
	return 0;
}
