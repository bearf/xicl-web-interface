#pragma comment(linker, "/STACK:268435456")

#include <iostream>
#include <iomanip>

#include <vector>
#include <string>
#include <deque>
#include <queue>
#include <set>
#include <map>

#include <algorithm>

#include <cstdio>
#include <cstdlib>
#include <complex>
#include <ctime>
#include <cstring>
#include <cassert>

using namespace std;

#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define ford(i,n) for (int i = int(n) - 1; i >= 0; --i)

#define pb push_back
#define mp make_pair
#define fs first
#define sc second
#define all(a) (a).begin(), (a).end()
#define sz(a) int((a).size())
#define sqr(a) ((a) * (a))

#ifdef SG
    #define debug(x) cerr << #x << ": " << (x) << endl
#else
    #define debug(x)
#endif

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

const ld pi = 3.1415926535897932384626433832795l;

template <typename T>
ostream & operator << (ostream & out, vector<T> const & a) {
    out << "[";
    for (int i = 0; i < sz(a); ++i) {
        if (i != 0) {
            out << ", ";
        }
        out << a[i];
    }
    out << "]";
    return out;
}

template <typename T1, typename T2>
ostream & operator << (ostream & out, pair<T1, T2> const & p) {
    out << "(" << p.fs << ", " << p.sc << ")";
    return out;
}

typedef pair<int, int> point;
#define x first
#define y second

point operator + (const point &a, const point &b) {
    return point(a.x + b.x, a.y + b.y);
}

point operator - (const point &a, const point &b) {
    return point(a.x - b.x, a.y - b.y);
}

point operator * (const point &a, int b) {
    return point(a.x * b, a.y * b);
}

int operator * (const point &a, const point &b) {
    return a.x * b.x + a.y * b.y;
}

int operator ^ (const point &a, const point &b) {
    return a.x * b.y - a.y * b.x;
}

const int N = 200;

struct Data {
    int n;
    point p[N];
    int r, R;

    bool read () {
        if (!(cin >> n)) {
            return 0;
        }
        forn (i, n) {
            scanf("%d%d", &p[i].x, &p[i].y);
        }
        cin >> r >> R;
        return 1;
    }

    int ans1;
    ld ans2;

    void write () {
        cout.precision(6);
        cout.setf(ios::fixed | ios::showpoint);
        cout << ans1 << endl << ans2 << endl;
    }

    virtual void solve () {}

    virtual void clear () {
        *this = Data();
    }
};

struct Solution: Data {
    void calc (const point &a, const point &b) {
        int sql = (a - b) * (a - b);
        int l = int(sqrtl(sql));
        while (l * l > sql) {
            --l;
        }
        while ((l + 1) * (l + 1) <= sql) {
            ++l;
        }
        int k = (l - 2 * R) / (2 * r);
        if (sqr(k * (2 * r) + 2 * R) != sql) {
            ++k;
        }
        ld alpha = 0, betta;
        if (sqr(k * (2 * r) + 2 * R) == sql) {
            alpha = betta = 0;
        } else if (k & 1) {
            ld x = ld(l) / 2;
            ld s = R + r;
            if (k > 1) {
                x -= R + 2 * r * (k / 2) - r;
                s = 2 * r;
            }
            betta = acosl(x / s);
        } else {
            ld x = ld(l) / 2 - r;
            ld s = R + r;
            if (k > 2) {
                x -= R + 2 * r * ((k - 1) / 2) - r;
                s = 2 * r;
            }
            betta = acosl(x / s);
        }
        if (k < 3) {
            swap(alpha, betta);
        }
        debug(mp(alpha, betta));
        while (betta > alpha) {
            ld d = betta - alpha;
            ld delta = atan2l(r * sinl(d), R + r * cosl(d));
            betta -= 2 * alpha + 2 * delta;
            alpha += 2 * delta;
            debug(mp(alpha, betta));
        }
        ans1 += k;
        ans2 += (k * pi + 2 * alpha) * r - 2 * alpha * R;
    }

    void solve () {
        ans1 = 0;
        ans2 = (n + 2) * pi * R;
        forn (i, n) {
            calc(p[i], p[(i + 1) % n]);
        }
    }

    Solution (Data d = Data()): Data(d) {}

    void clear () {
        *this = Solution();
    }
};

Solution sol;
int main () {
#ifdef SG
    freopen("h.in", "r", stdin);
//    freopen("", "w", stdout);
    while (sol.read()) {
        sol.solve();
        sol.write();
        sol.clear();
    }
#else
//    freopen("", "r", stdin);
//    freopen("", "w", stdout);
    sol.read();
    sol.solve();
    sol.write();    
#endif

    return 0;
}
