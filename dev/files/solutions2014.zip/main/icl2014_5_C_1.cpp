#include <iostream>
using namespace std;
typedef long long ll;

ll x;
int n;
int a[65];
int b[65];

int main()
{
	scanf("%lld", &x);
	n = 0;
	while (x > 0)
	{
		a[n++] = x % 2;
		x /= 2LL;
	}
	for (int i = n - 1; i >= 0; i--)
	{
		if (a[i] == 0)
		{
			b[i] == 0;
		}
		else
		{
			if (b[i + 1] == -1)
			{
				b[i + 1] = 0;
				b[i] = -1;
			}
			else
			{
				if (b[i + 1] == 1)
				{
					b[i + 2] += 1;
					b[i + 1] = 0;
					b[i] = -1;
				}
				else
				{
					b[i] = 1;
				}
			}
		}
	}
	n = 64;
	while (b[n] == 0) n--;
	for (int i = n; i >= 0; i--)
	{
		printf("%d ", b[i]);
	}
//	cin >> n;
	return 0;
}