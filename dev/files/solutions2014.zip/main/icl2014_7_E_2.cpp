#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <vector>

using namespace std;

const int N = 200200;
int a[N], d[N];

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif
	int n;
	cin >> n;
	for (int i=0; i<n; i++)
		cin >> a[i];

	d[0] = a[0];
	int r = 1;
	for (int i=1; i<n; i++) {
		int j = upper_bound(d, d+r, a[i]) - d;
		d[j] = a[i];
		if (j == r)
			r++;
	}

	cout << n - r << endl;

	return 0;
}