#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <math.h>

//#define _DEBUG
#define forn(i,n) for (int i=0;i<n;i++)

using namespace std;

int main()
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	int n;
	cin>>n;
	vector <vector <int> > a(n, vector<int> (n,0));
	int nul=0,sum=0;
	forn(i,n)
		forn(j,n)
	{
		cin>>a[i][j];
		sum+=a[i][j];
		if (a[i][j]==0)
			nul++;
	}
	if (nul>n*n-nul){
		cout<<-1;
	}
	else
	{
		cout<<sum;
	}
}