#pragma comment(linker, "/STACK:256000000")
#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <algorithm>
#include <stack>
#include <map>
using namespace std;
//const int b=1000000009;
typedef long long ll; 

int p[(1<<18)];
int us[(1<<18)];

int main(){
	//freopen("1.txt","r",stdin);
	int n;
	cin>>n;
	memset(p,0,sizeof(p));
	memset(us,0,sizeof(us));

	int v = 0;
	stack<int> s, line;
	s.push(0);
	int h = (1<<n);
	int cnt=0;
	printf("%d\n", h*n);
	for(int i=0;i<h*n;i++)
	{
		int v = s.top();
		int step = 1;
		for(int j=0;j<n;j++){
			int u=v ^ (1<<j);
			if ((p[u] & (1<<j)) == 0 && us[u] == 0){
				p[u] = p[u] | (1<<j);
				us[u] = 1;
				s.push(u);
				line.push(j);
				printf("%d ",j+1);
				cnt++;
				step = 0;
				break;
			}
		}
		if(step){
			int u=s.top();
			s.pop();
			int l =line.top();
			printf("%d ",l+1);
			cnt++;
			line.pop();
			p[u] = p[u] | (1<<l);
			us[v] = 0;
		}
	}
	printf("\n");






}