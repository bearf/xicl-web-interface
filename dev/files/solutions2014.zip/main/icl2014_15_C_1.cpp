#include <iostream>
#include <cstdio>
#include <cstring>


using namespace std;


int a[500];


int main()
{
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
	long long n;
	scanf("%lld", &n);
	int len = 0;
	while(n)
	{
		a[len++] = n % 2;
		n /= 2;
		if(len > 1 && a[len - 1] == 1 && a[len - 2] == 1)
		{
			a[len - 2] = -1;
			a[len - 1] = 0;
			n++;
		}
	}
	for(int i = len - 1; i >= 0; i--)
		printf("%d ", a[i]);
	return 0;
}