#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cmath>
#include <stack>
#include <map>
#include <algorithm>

using namespace std;
typedef long long ll;


int main () {
//	freopen("input.txt", "r", stdin);freopen("output.txt", "w", stdout);
	string s;
	cin >> s;
	if(s.size() > 1 && s[0] == '1' && s[1] == '0') {
		cout << "1023456789";
	}else{
		for(int i = 1; i <= s[0] - '0'; i++) {
			cout << char(i + 48);
		}
		if ((int)s.size() - 2 >= 0) {
			cout << "0123456789";
		}
	}
	for(int i = 0; i < (int)s.size() - 2; i++) {
		cout << "0123456789";
	}
	return 0;
}