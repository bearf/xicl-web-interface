#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>
using namespace std;

typedef long long ll;
const int N = (int)3e5;
char str[N];
char rStr[N];

char part[N], lPart[N];
char nStr[N];
char failStr[N];
char startStr[N];

int getVal(ll pos, int len)
{
	pos %= len;
	if (pos < 0)
		pos += len;
	return part[pos] - '0';
}

int calc(int n, int pos, ll t)
{
	int len = 2 * n + 2;
	int sum = 0;
	int stPos = (pos + t) % 2;

	int allSum = 0;
	for (int i = stPos; i < len; i += 2)
		allSum ^= (part[i] - '0');

	bool isJump = false;
	for (ll i = pos - t; i <= pos + t;)
	{
		if ((i % len == 0 || (i - 1) % len == 0) && !isJump)
		{
			ll p = pos + t - i + 1;
			ll cntBlock = p / len;
			sum ^= (allSum & (cntBlock & 1));
			i += len * cntBlock;
			isJump = true;
		}
		else
		{
			sum ^= getVal(i, len);
			i += 2;
		}
	}
	return sum;
}
void genPart(int n)
{
	for (int i = 0; i < n; i++) rStr[i] = str[i];
	reverse(rStr, rStr + n);
	
	for (int i = 0; i < n; i++)
		part[i] = str[i];
	part[n] = '0';
	for (int i = 0; i < n; i++)
		part[i + n + 1] = rStr[i];
	part[2 * n + 1] = '0';
}

void solve(int n, ll t)
{
	genPart(n);
	if (n == 1)
	{
		str[0] = calc(n, 0, t) + '0';
		return;
	}
	int len = 2 * n + 2;
	int t0 = calc(n, 0, t);
	int t1 = calc(n, 1, t);
	str[0] = t0 + '0';
	str[1] = t1 + '0';
	for (int i = 2; i < n; i++)
	{
		if (i % 2 == 0)
		{
			t0 ^= getVal((i - 2 - t), len) ^ getVal(i + t, len);
			str[i] = t0 + '0';
		}
		else
		{
			t1 ^= getVal((i - 2 - t), len) ^ getVal(i + t, len);
			str[i] = t1 + '0';
		}
	}
}

int getChar(int pos, int n)
{
	if (pos < 0 || pos >= n)
		return 0;
	return startStr[pos] - '0';
}

void go(int n)
{
	for (int i = 0; i < n; i++)
	{
		nStr[i] = (getChar(i - 1, n) ^ getChar(i + 1, n)) + '0';
	}
	for (int i = 0; i < n; i++)
		startStr[i] = nStr[i];
}

void simpleSolve(int n, ll t)
{
	for (int i = 0; i < t; i++)
	{
		go(n);
	}
}

const int IT = 1000;

void genStr(int n)
{
	for (int i = 0; i < n; i++)
		failStr[i] = rand() % 2 + '0';
	failStr[n] = 0;
}

void fastSolution(int n, ll t)
{
	for (ll i = 63; i >= 1;)
	{
		ll pow2 = (1ll << (ll)i) - 1;
		if (pow2 <= t)
		{
			solve(n, pow2);
			t -= pow2;
		}
		else
			i--;
	}
}

int main()
{
	int n;
	ll t;

	scanf("%lld%d", &t, &n);
	scanf(" %s", str);
	fastSolution(n, t);
	for (int i = 0; i < n; i++)
		printf("%c", str[i]);
	return 0;

	while (1)
	{
		genStr(n);
		for (int s = 0; s <= n; s++)
			str[s] = startStr[s] = failStr[s];
//		scanf(" %s", str);

		fastSolution(n, t);		
		simpleSolve(n, t);
		bool ok = true;
		for (int s = 0; s < n; s++)
		{
			if (str[s] != startStr[s])
				ok = false;
		}
		if (!ok)
		{
			cout << failStr << endl;
			cout << str << endl;
			cout << startStr;
			return 0;
		}
	}

	return 0;
}