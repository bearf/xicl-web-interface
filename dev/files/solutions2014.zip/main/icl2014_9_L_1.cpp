#include <iostream>

using namespace std;

int main()
{
	int n, sum(0), cnt(0), temp;
	cin >> n;
	for (int i(0); i < n; ++i)
		for (int j(0); j < n; ++j)
		{
			cin >> temp;
			sum += temp;
			if (temp)
				cnt++;
		}
	cout << (cnt >= n * n - cnt ? sum : -1);
	return 0;
}