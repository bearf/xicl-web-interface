#include <iostream>
#include <cstdio>
using namespace std;

int a[111111];
int main() {
#ifdef LOCAL
	freopen("c.in", "r", stdin);
#endif
	long long n;
	cin >> n;
	int m = 0;
	do {
		a[m++] = n & 1;
		n >>= 1;
	} while (n != 0);
	for (int i = 0; i < m; i++) {
		if (a[i] == 1 && a[i + 1] == 1) {
			a[i] = -1;
			a[i + 1] = 0;
			a[i + 2] = 1;
			if (m < i + 3) {
				m = i + 3;
			}
		}
	}
	for (int i = m - 1; i >= 0; i--) {
		if (i != m - 1) {
			printf(" ");
		}
		printf("%d", a[i]);
	}
	return 0;
}