#include <iostream>
#include<stdio.h>
using namespace std;
void main()
{


	int p=0,z=0, s=0, k=0;
	int d[13][13]={0};

	cin >> k;

	for(int i=0; i<k; i++)
		for(int j=0; j<k; j++)
			cin >> d[i][j];

	for(int i=0; i<k; i++)
	{
		for(int j=0; j<k; j++)
		{
			if(d[i][j]>0)
			{
				z++;
				s+=d[i][j];
			}
			else
			{
				p++;
			}
		}
	}
	if(p>z)
	{ s=-1;}
	cout << s;
}