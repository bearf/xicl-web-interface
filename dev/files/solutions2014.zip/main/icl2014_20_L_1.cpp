#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <set>
#include <map>
#include <vector>

using namespace std;

int n;

int a[20][20];
int emp, nonemp, sum;
int main()
{
    cin>>n;
    for (int i=1; i<=n; i++)
    {
        for (int j=1; j<=n; j++)
        {
            cin>>a[i][j];
            if ( a[i][j]==0 )
                emp++;
            else
                nonemp++, sum+=a[i][j];
        }
    }
    if ( nonemp>=emp )
        cout<<sum;
    else
        cout<<-1;
    return 0;
}
/*
7
0 0 0 1 0 0 0
0 4 0 1 0 0 0
0 0 0 1 0 0 0
1 1 1 1 1 1 1
0 0 0 1 0 0 0
0 0 0 1 0 3 0
0 0 0 1 0 0 0
*/
