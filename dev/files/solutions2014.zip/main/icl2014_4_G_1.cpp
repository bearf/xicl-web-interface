#undef NDEBUG
#ifdef ssu1
#define _GLIBCXX_DEBUG
#endif

#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define fore(i, l, r) for(int i = (l); i < (r); ++i)
#define forn(i, n) fore(i, 0, n)
#define fori(i, l, r) fore(i, l, (r) + 1)
#define X first
#define Y second
#define sz(v) ((int)(v).size())
#define pb push_back
#define mp make_pair
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acosl(-1.0);

const int N = 200500;

int n;
vector<int> g[N];
int pr[N], d[N];
bool used[N];

li ans;

void dfs(int v){
    forn(i, sz(g[v])){
        int u = g[v][i];
        if(u == pr[v])
            continue;
            
        pr[u] = v;
        d[u] = d[v] + 1;

        dfs(u); 
    }
}

int main(){
    #ifdef ssu1
    assert(freopen("__input.txt", "r", stdin));
    #endif
    
    cin >> n;
    
    forn(i, n - 1){
        int v, u;
        scanf("%d %d", &v, &u);
        v--; u--;
        
        g[v].pb(u);
        g[u].pb(v);                      
    }
    
    d[0] = 0;
    pr[0] = 0;
    dfs(0);
    
    used[0] = true;
    
    int m;
    scanf("%d", &m);
    
    ans = 0;
    
    forn(i, m){
        int v;
        scanf("%d", &v);
        v--;
        
        int u = v;
        int len = 0;
        while(!used[u]){
            used[u] = true;
            len++;
            u = pr[u];
        }
        
        ans += 2*len;
        
        if(i != 0)
            printf(" ");    
        printf("%I64d", ans - d[v]);        
    }
    puts("");
    
    return 0;
}






