#include <iostream>
#include <math.h>
using namespace std;


int main()
{
	_int64 n;
	cin >> n;
	int p = (int) (log((double)n) / log(2.0));
	int koef[60];

	_int64 s;

	s = (_int64) pow(2.0, (double)p);
	int lastKoef = 1;
	koef[p] = 1;
	for (int i = p - 1; i >= 0; i--)
	{
		if ((_int64) pow(2.0, (double)i) > abs(s-n) || lastKoef != 0)
		{
			lastKoef = 0;
			koef[i] = 0;
		}
		else
		{
			if (s > n)
			{
				lastKoef = -1;
				s -= (_int64) pow(2.0, (double)i);
				koef[i] = -1;
			}
			else
			{
				lastKoef = 1;
				s += (_int64) pow(2.0, (double)i);
				koef[i] = 1;
			}
		}
	}
	if (s == n)
	{
		for (int i = p; i >= 0; i--)
			cout << koef[i] << " ";
		return 0;
	}

	p++;
	s = (_int64) pow(2.0, (double)p);
	lastKoef = 1;
	koef[p] = 1;
	for (int i = p - 1; i >= 0; i--)
	{
		if ((_int64) pow(2.0, (double)i) > abs(s-n) || lastKoef != 0)
		{
			lastKoef = 0;
			koef[i] = 0;
		}
		else
		{
			if (s > n)
			{
				lastKoef = -1;
				s -= (_int64) pow(2.0, (double)i);
				koef[i] = -1;
			}
			else
			{
				lastKoef = 1;
				s += (_int64) pow(2.0, (double)i);
				koef[i] = 1;
			}
		}
	}
	for (int i = p; i >= 0; i--)
		cout << koef[i] << " ";
	return 0;
}