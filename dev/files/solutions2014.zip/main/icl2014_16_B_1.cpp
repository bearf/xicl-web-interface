#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cmath>
#include <stack>

using namespace std;
typedef long long ll;

long long n, k, dp[1000001][21];
stack<int> st;

bool calc(ll r, ll nk){
	if(r == 0){
		return false;
	}
	if(nk == 1){
		for(int i = 1; i <= r; i++){
			dp[i][1] = 1;
		}
		return true;
	}
	if(calc(r / 2, nk - 1)){
		long long summ = 0, cnt = 0;
		for(int i = 1; i <= (r / 2); i++){
			summ += dp[i][nk - 1];
			if(summ > 1000000009){
				summ %= 1000000009;
			}
			dp[i*2][nk] = dp[i*2+1][nk] = summ;
		}
		return true;
	} else {
		return false;
	}
}

int main () {
	//freopen("input.txt", "r", stdin);freopen("output.txt", "w", stdout);
	cin >> n >> k;
	if(calc(n, k)){
		cout << dp[n][k];
	} else {
		cout << 0;
	}
	return 0;
}