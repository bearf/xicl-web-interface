#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cassert>
#include <ctime>
#include <memory.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <complex>
#include <list>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef complex <ld> point;

#define pb push_back
#define mp make_pair
#define fi first
#define se second

#define INF 1000000001
#define INFL 1000000000000000001ll
#define NAME "e"

pair <int, int> a[300001];
int bd[300001];
int k = 0;

inline int type(int id) {
    return a[bd[id]] == a[bd[id + 1] - 1];
}

int main() {
    #ifdef _GEANY
    assert(freopen(NAME ".in", "r", stdin));
    #endif // _GEANY
    int n;
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cin >> a[i].fi;
        a[i].se = i;
    }
    sort(a, a + n);
    bd[k++] = 0;
    for (int i = 1; i < n; ++i)
        if (a[i].se < a[i - 1].se)
            bd[k++] = i;
    bd[k] = n;
    int res = 0;
    for (int i = 0; i < k; ++i) {
        res = max(res, bd[i + 1] - bd[i]);
    }
    for (int i = 0; i < k - 1; ++i) {
        if (type(i) == 1 && type(i + 1) == 1) {
            int rb = bd[i + 1];
            for (int j = bd[i]; j < bd[i + 1]; ++j) {
                while (rb < bd[i + 2] && a[j].se > a[rb].se)
                    ++rb;
                if (rb == bd[i + 2])
                    break;
                res = max(res, j - bd[i] + 1 + bd[i + 2] - rb);
            }
        } else if (type(i) == type(i + 1)) {
            continue;
        } else if (type(i) == 0) {
            int pos = bd[i + 1];
            while (pos < bd[i + 2] && a[pos].se < a[bd[i + 1] - 1].se)
                ++pos;
            res = max(res, bd[i + 1] - bd[i] + bd[i + 2] - pos);
        } else {
            int pos = bd[i];
            while (pos < bd[i + 1] && a[pos].se < a[bd[i + 1]].se)
                ++pos;
            res = max(res, bd[i + 2] - bd[i + 1] + pos - bd[i]);
        }
    }
    for (int i = 1; i < k - 1; ++i) {
        if (type(i - 1) == 0 || type(i + 1) == 0)
            continue;
        int pos = bd[i + 1];
        while (pos < bd[i + 2] && a[pos].se < a[bd[i + 1] - 1].se)
            ++pos;
        int rb = pos;
        pos = bd[i - 1];
        while (pos < bd[i] && a[pos].se < a[bd[i]].se)
            ++pos;
        int lb = pos;
//        cerr << lb << ' ' << rb << '\n';
        res = max(res, bd[i + 1] - bd[i] + bd[i + 2] - rb + lb - bd[i - 1]);
    }
    cout << n - res << endl;
}
