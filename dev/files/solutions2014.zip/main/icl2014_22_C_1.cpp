#pragma comment(linker, "/STACK:64000000")

#include<iostream>
#include<cstdio>
#include<sstream>

#include<algorithm>
#include<vector>
#include<set>
#include<bitset>
#include<map>
#include<queue>
#include<deque>
#include<stack>

#include<string>
#include<memory.h>
#include<cassert>
#include<time.h>

using namespace std;

#define forn(i, n) for(int i = 0; i < (int)n; i++)
#define forab(i, a, b) for(int i = (int)a; i <= (int)b; i++)
#define fornd(i, n) for(int i = 0; i < (int)n; i--)
#define forabd(i, b, a) for(int i = (int)b; i >= (int)a; i--)
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define _(a, val) memset(a, val, sizeof(a))
#define sz(a) (int)(a).size()

typedef long long lint;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;

const int INF = 1000000000;
const lint LINF = (lint)INF * (lint)INF;
const double eps = 1e-9;

const int nmax = 60;

bool bit(lint msk, int i)
{
	return msk & (1LL << i);
}

struct Vec
{
	int n;
	int a[nmax];

	void init(lint val)
	{
		for (int i = 0; i < nmax; i ++)
		{
			if (bit(val, i))
			{
				a[i] = 1;
				n = i + 1;
			}
		}
	}

	void norm()
	{
		for (int i = 0; i < n; i ++)
		{
			assert(abs(a[i]) <= 2);
			if (a[i] == 2)
			{
				a[i + 1] = 1;
				a[i] = 0;
				n = max(i + 2, n);
			}
			if (a[i] == -2)
			{
				a[i + 1] = 1;
				a[i] = 0;
				n = max(i + 2, n);
			}
		}
		while (n > 1 && a[n - 1] == 0) n--;
	}

	bool check()
	{
		for (int i = n - 1; i > 0; i --)
		{
			if (a[i - 1] == 1 && a[i] == 1)
			{
				a[i - 1] = -1;
				a[i] = 0;
				a[i + 1] += 1;
				return false;
			}
			if (a[i - 1] == -1 && a[i] == 1)
			{
				a[i - 1] = 1;
				a[i] = 0;
				a[i + 1] += 0;
				return false;
			}
			if (a[i - 1] == -1 && a[i] == -1)
			{
				a[i - 1] = 1;
				a[i] = 0;
				a[i + 1] += -1;
				return false;
			}
			if (a[i - 1] == 1 && a[i] == -1)
			{
				a[i - 1] = -1;
				a[i] = 0;
				a[i + 1] += 0;
				return false;
			}
		}
		return true;
	}

	void convert()
	{
		while (!check())
		{
			n++;
			norm();
		}
		norm();
	}

	lint calc()
	{
		lint ret = 0;
		for (int i = 0; i < n; i ++)
		{
			ret += (1LL << i) * a[i];
		}
		return ret;
	}
}v;

lint n;

void read()
{
	cin >> n;
}

void solve()
{
	v.init(n);
	v.convert();
	//assert(v.calc() == n);
	for (int i = v.n - 1; i >= 0; i --)
	{
		if (i != v.n - 1) printf(" ");
		printf("%d", v.a[i]);
	}
	printf("\n");
}

int main()
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	read();
	solve();

	return 0;
}