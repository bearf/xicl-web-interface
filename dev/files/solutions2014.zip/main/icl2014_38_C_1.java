import java.io.*;
import java.util.*;

public class C {

	FastScanner in;
	PrintWriter out;

	void solve() {
		long n = in.nextLong();
		
		int[] a = new int[100];
		for (int i = 0; i < 100; i++) {
			a[i] = (int) n % 2;
			n /= 2;
		}
		
		for (int i = 0; i + 1 < 100; i++) {
			if (a[i] == 1 && a[i + 1] == 1) {
				a[i] = -1;
				a[i + 1] = 0;
				a[i + 2]++;
				
				for (int j = i + 2; j < 100; j++) {
					if (a[j] >= 2) {
						a[j + 1]++;
						a[j] = 0;
					}
				}
			}
		}
		
		int max = 99;
		while (a[max] == 0) {
			max--;
		}
		
		for (int i = max; i >= 0; i--) {
			out.print(a[i] + " ");
		}
	}

	void run() {
		try {
			in = new FastScanner();
			out = new PrintWriter(System.out);
			solve();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	class FastScanner {
		BufferedReader br;
		StringTokenizer st;

		public FastScanner() {
			br = new BufferedReader(new InputStreamReader(System.in));
		}

		String nextToken() {
			while (st == null || !st.hasMoreElements()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return st.nextToken();
		}

		int nextInt() {
			return Integer.parseInt(nextToken());
		}

		long nextLong() {
			return Long.parseLong(nextToken());
		}

		double nextDouble() {
			return Double.parseDouble(nextToken());
		}
	}

	public static void main(String[] args) {
		new C().run();
	}
}
