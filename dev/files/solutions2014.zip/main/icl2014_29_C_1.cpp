#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <cassert>

using namespace std;

#ifdef _WIN32
	#define LLD "%I64d"
#else
	#define LLD "%lld"
#endif

typedef long double ld;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<long long> vll;

#define mp make_pair
#define pb push_back
#define sz(x) ((int)(x).size())
#define EPS (1e-9)
#define INF ((int)1e9)
#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define TASK "text"

const int maxn = 80;

long long solve(int k, int *a) {
	assert(k && a[k - 1]);
	int ans[maxn];
	memset(ans, 0, sizeof(ans));
	for (int r = k - 1; r >= 0;) {
		if (!a[r]) {
			--r;
			continue;
		}

		int i = r;
		while (i > 0) {
			if (!a[i - 1] && (i == 1 || !a[i - 2]))
				break;
			--i;
		}
		
		int j;
		for (j = i - 1; j + 2 <= r + 1 && a[j + 1] == 1 && a[j + 2] == 0; j += 2) ;
		//eprintf("%d %d %d\n", r, j, i);
		for (int t = j; t >= i; --t)
			ans[t] = a[t];
		if (r > j) {
			ans[r + 1] = 1;
			for (int t = r; t > j; --t)
				ans[t] = (a[t] ? 0 : -1);
			ans[j + 1] = -1;
		}
		r = i - 1;
	}

	int n = maxn - 1;
	while (n >= 0 && !ans[n])
		--n;
	long long got = 0;
	for (int i = n; i >= 0; --i) {
		printf("%d%c", ans[i], " \n"[!i]);
		got += ans[i] * (1ll << i);
	}
	return got;
}

int solve() {
	long long n;
	if (scanf(LLD, &n) < 1)
		return 0;
	long long n0 = n;	
	int k = 0;
	int a[maxn];
	memset(a, 0, sizeof(a));
	for (; n; a[k++] = n % 2, n /= 2) ;
	assert(solve(k, a) == n0);
	return 1;
}

int main() {
#ifdef DEBUG
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	
	int n;
	while (1) {
		if (!solve())
			break;
		#ifdef DEBUG
		eprintf("%.18lf\n", (double)clock() / CLOCKS_PER_SEC);		
		#endif
	}
	return 0;
}
