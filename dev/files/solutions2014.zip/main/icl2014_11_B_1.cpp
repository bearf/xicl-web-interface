#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <queue>
#include <deque>
#include <complex>

using namespace std;

#define pb push_back
#define pbk pop_back
#define all(x) (x).begin(), (x).end()
#define fs first
#define sc second
#define y0 yy0
#define y1 yy1
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define prev _prev
#define rank _rank
#define link _link
#define hash _hash
#ifdef LOCAL
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef complex<double> tc;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));
const int N = 1e6 + 100;
const int M = 1e9 + 9;

int k, n;
int dp[2][N];

int getSum(int *a, int l, int r){
	if (l == 0)
		return a[r];
	return (a[r] - a[l - 1] + M) % M;
}

int main() {
#ifdef LOCAL
#define TASK "B"
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	cin >> n >> k;
	dp[0][0] = 1;
	for (int i = 0; i < k; i++){
		fill_n(dp[(i ^ 1) & 1], n + 1, 0);
		for (int j = 1; j <= n; j++)
			dp[i & 1][j] = (dp[i & 1][j] + dp[i & 1][j - 1]) % M;
		for (int j = 1; j <= n; j++)
			dp[(i ^ 1) & 1][j] = dp[i & 1][min(j / 2, j - 1)];
	}
	printf("%d\n", dp[k & 1][n]);
	return 0;
}
