#include <iostream>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
using namespace std;

int a[100005];

int main() {
#ifdef LOCAL
	freopen("c.in", "r", stdin);
#endif
	long long n;
	cin >> n;
	int sz = 0;;
	do {
		a[sz++] = (n & 1);
		n >>= 1;
	} while (n != 0);

	for (int i = 0;i < sz;i++) {
		if (a[i] == 0) continue;
		if (a[i + 1] == 0) continue;

		if (a[i] == 1) {
			a[i + 2]++;
			a[i + 1] = 0;
			a[i] = -1;
			sz = max (sz, i + 3);
		} else {
			a[i] = 1;
		}

		for (int j = i + 1;j <= sz;j++) {
			if (a[j] == 2) {
				a[j] = 0;
				a[j + 1]++;
			}
		}
		if (a[sz] > 0) sz++;
	}

	for (int i = sz - 1;i >= 0; i--) {
		if (i != sz - 1) {
			printf(" ");
		}
		printf("%d", a[i]);
	}
	return 0;
}