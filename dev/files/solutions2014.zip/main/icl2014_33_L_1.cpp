#include<iostream>
using namespace std;
int main()
{
	int n,a[15][15],d=0,b=0;
	cin>>n;
	for(int i=0;i<n; i++)
		for(int j=0; j<n; j++)
		{
			cin>>a[i][j];
			if(a[i][j]==0)
				d++;
			else
				b+=a[i][j];
		}
		if(d > n*n/2)
			cout<<"-1";
		else
			cout<<b;
}