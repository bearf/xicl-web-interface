#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <string>

using namespace std;

#define M 1000100
#define K 20

typedef long long ll;
typedef long long li;

void Solve(void);

int main(){

#ifdef BANANA_MOTEL
	freopen("test.in", "r", stdin);
	freopen("test.out", "w", stdout);
#else
#endif
	Solve();
	return 0;
}

#define INF 1000000000

int a[200100];
int b[200100];
int n;
int l[200100], r[200100];
map<int, int> q;
vector<int> g[2000];
int sz[200100];

inline int suf(int last, int val) {
	return upper_bound(g[val].begin(), g[val].end(), last) - g[val].begin();
}

void Solve()
{
	cin >> n;
	for (int i = 0; i < n; i++){
		cin >> a[i];
		b[i] = a[i];
	}
	sort(b, b + n);
	int cur = 0;
	q[b[0]] = cur;
	for (int i = 1; i < n; i++)
		if (b[i] != b[i - 1]){
			cur++;
			q[b[i]] = cur;
		}
	for (int i = 0; i < n; i++){
		a[i] = q[a[i]];
		b[i] = q[b[i]];
		sz[a[i]]++;
	}

	for (int i = 0; i < n; i++)
		r[a[i]] = i;
	for (int i = n - 1; i >=0; i--)
		l[a[i]] = i;
	for (int i = 0; i < n; i++)
		g[a[i]].push_back(i);

	int res = INF;
	for (int i = 0; i < n; i++){
		res = min(res, n - (suf(i, a[i]) + (sz[a[i] + 1] - suf(i, a[i] + 1))));
	}
	int rt = 0;
	int csz = sz[0];
	for (int lt = 0; lt < n; lt++) {
		if (lt != 0)
			csz -= sz[lt - 1];
		if (lt > rt) {
			rt = lt;
			csz = sz[lt];
		}
		while (true) {
			rt++;
			if (r[rt - 1] > l[rt] || rt == n) {
				rt--;
				break;
			}
			csz += sz[rt];
		}
		int cres = csz;
		if (lt != 0) {
			cres += suf(l[lt] - 1, lt - 1);
		}
		if (sz[rt + 1] != 0) {
			cres += sz[rt + 1] - suf(r[rt], rt + 1);
		}
		res = min(res, n - cres);
	}
	cout << res << endl;
}