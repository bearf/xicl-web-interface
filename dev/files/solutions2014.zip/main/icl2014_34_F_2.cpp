#include <iostream>
#include <algorithm>
#include <vector>
#include<cstdio>
#include <string>
using namespace std;

#pragma comment(linker, "/STACK:160000000")

bool used[262144 + 100][20];
int n, m;
vector<int> ans;

string toBin(int x)
{
	string res;
	for (int i = 0; i < n; i++)
	{
		res += (char)( (x & 1) + '0');
		x >>= 1;
	}
	return res;
}

bool dfs(int mask, int p)
{
	for (int i = 0; i < n; i++)
	{
		int mask2 = (mask ^ (1 << i));
		if (!used[mask2][i])
		{
			used[mask2][i] = 1;
			dfs(mask2, i);
		}
	}

	if (p != -1)
		printf("%d ", p + 1);
	ans.push_back(p + 1);
	//cout << toBin(mask) << endl;

	return 0;
}

bool checkAns(vector<int> v)
{
	int all = (1 << n) - 1;

	int mask = 0, sw = 0;
	for (int i = 1; i < v.size(); i++)
	{
		sw = v[i] - 1;
		mask = (mask ^ (1 << sw));
		used[mask][sw] = 1;
	}

	for (mask = 0; mask <= all; mask++)
		for (sw = 0; sw < n; sw++)
			if (!used[mask][sw])
				return 0;

	return 1;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	
	scanf("%d", &n);
	//n = 1;

	m = (1 << n) * n;
	

	printf("%d\n", m);
	dfs(0, -1);

	/*reverse(ans.begin(), ans.end());
	int all = (1 << n) - 1;
	for (int mask = 0; mask <= all; mask++)
		for (int sw = 0; sw < n; sw++)
			used[mask][sw] = 0;
	cout << endl << checkAns(ans);
	*/
	//for (int i = 0; i <m; i++)
	//	printf("%d ", ans[i]);

}