var  a,i,j,s,p,n :longint ;
f:array[0..10000,0..10000] of integer;
begin
assign(input, 'stdin'); reset(input);
assign(output, 'stdout'); rewrite(output);
read (a);
for i:=1 to a do 
for j:=1 to a do begin
read(f[i,j]);
case f[i,j] of
0: inc(p);
1: inc(s,f[i,j]);
2: inc(s,f[i,j]);
3: inc(s,f[i,j]);
4: inc(s,f[i,j]);
end;
if f[i,j]<>0 then inc(n);
end;
if n<p then writeln(-1) else write(s); 
close(input);
close(output);
end.