#pragma comment(linker, "/STACK:64000000")

#include<iostream>
#include<cstdio>
#include<sstream>

#include<algorithm>
#include<vector>
#include<set>
#include<bitset>
#include<map>
#include<queue>
#include<deque>
#include<stack>

#include<string>
#include<memory.h>
#include<cassert>
#include<time.h>

using namespace std;

#define forn(i, n) for(int i = 0; i < (int)n; i++)
#define forab(i, a, b) for(int i = (int)a; i <= (int)b; i++)
#define fornd(i, n) for(int i = 0; i < (int)n; i--)
#define forabd(i, b, a) for(int i = (int)b; i >= (int)a; i--)
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define _(a, val) memset(a, val, sizeof(a))
#define sz(a) (int)(a).size()

typedef long long lint;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;

const int INF = 1000000000;
const lint LINF = (lint)INF * (lint)INF;
const double eps = 1e-9;

const int nmax = 100005;

struct Tree
{
	int t[nmax * 4];
	int n;

	void build(int N)
	{
		n = N;
	}

	int get(int i, int tl, int tr, int l, int r)
	{
		if (l > r) return 0;
		if (tl == l && tr == r) return t[i];
		int tm = (tl + tr) >> 1;
		return get(i*2, tl, tm, l, min(r, tm)) + 
			get(i*2+1, tm+1, tr, max(tm+1, l), r);
	}

	void mod(int i, int tl, int tr, int pos)
	{
		if (tl == tr)
		{
			t[i] = 1;
			return;
		}
		int tm = (tl + tr) >> 1;
		if (pos <= tm)
			mod(i*2, tl, tm, pos);
		else
			mod(i*2+1, tm+1, tr, pos);
		t[i] = t[i*2] + t[i*2+1];
	}
}T;

const int K = 17;

vector < int > g[nmax];
int n, m;
int tin[nmax], tout[nmax], id[nmax], timer, depth[nmax];
int go[K][nmax];

void read()
{
	scanf("%d",&n);
	for (int i = 1; i < n; i ++)
	{
		int x, y;
		scanf("%d%d",&x,&y);
		x--;
		y--;
		g[x].pb(y);
		g[y].pb(x);
	}
	scanf("%d",&m);
	for (int i = 0; i < m; i ++)
	{
		scanf("%d",&id[i]);
		id[i]--;
	}
}

void dfs(int v, int p = -1, int curdepth = 0)
{
	tin[v] = timer++;
	depth[v] = curdepth;
	go[0][v] = p;
	for (int i = 0; i < sz(g[v]); i ++)
	{
		int to = g[v][i];
		if (to == p)
			continue;
		dfs(to, v, curdepth + 1);
	}
	tout[v] = timer - 1;
}

lint cur = 0;

bool check(int v)
{
	return T.get(1, 0, n - 1, tin[v], tout[v]);
}

bool first = true;

lint calc(int v)
{
	int h = 0;
	if (!check(v))
	{
		int curv = v;
		for (int k = K - 1; k >= 0; k --)
		{
			int to = go[k][curv];
			if (to < 0) continue;
			if (!check(to))
			{
				h += (1 << k);
				curv = go[k][curv];
			}
		}
		if (!first)
			h++;
		first = false;
	}
	T.mod(1, 0, n - 1, tin[v]);
	cur += h;
	return cur * 2 - depth[v];
}

void solve()
{
	dfs(0);
	for (int k = 1; k < K; k ++)
	{
		for (int v = 0; v < n; v ++)
		{
			if (go[k - 1][v] == -1)
				go[k][v] = -1;
			else
				go[k][v] = go[k - 1][go[k - 1][v]];
		}
	}
	T.build(n);
	for (int i = 0; i < m; i ++)
	{
		if (i) printf(" ");
		lint ans = calc(id[i]);
		printf("%lld", ans);
	}
	printf("\n");
}

int main()
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	read();
	solve();

	return 0;
}