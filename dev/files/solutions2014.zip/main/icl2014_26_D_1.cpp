#include<iostream>
#include <deque>
using namespace std;
int main()
{
	int n;
	cin >> n;
	int s = 0;

	if(n == 10){
		cout << 1023456789;
		return 0;
	} else if(n/10 == 0){
		for(int i = 1; i <= n; i++){
			cout << i;
		}
		return 0;
	}

	while(n >= 9){
		n/=10;
		s++;
	}

	for(int i = n; i >= 1; i--){
		cout << i;
	}

	int x = 1;

	for(int i = 0; i <= 9; i++){
		x = 1;
		while(x <= s){
			cout << i;
			x++;
		}
	}

	return 0;
}