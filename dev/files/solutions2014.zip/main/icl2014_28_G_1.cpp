#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <stdio.h>
#include <queue>
#include <deque>
#define USE_MATH_DEFINES
#include <math.h>

#define ll long long
#define ull unsigned ll
#define mp make_pair
#define pb push_back

using namespace std;

const int MOD = 1000000009;
const ll INF = 1000000000000000;

const int base = 1048576;

int h[100005];
int kk[100005];
bool isLeaf[100005];
bool used[100005];
vector <int> g[100005];
int n, k;
int sum = 0;

void dfs (int v, int k = 0) {
	used[v] = 1;
	h[v] = k;

	int l = g[v].size();
	for (int i(0); i < l; i++) {
		if (!used[g[v][i]])
			dfs(g[v][i], k + 1);
	}

	if (l == 1)
		isLeaf[v] = 1;
}

void del(int v) {
	if (isLeaf[v]) {
		int l = g[v].size();
		for (int i(0); i < l; i++) {
			if (!isLeaf[g[v][i]]) {
				kk[g[v][i]]--;
				if (kk[g[v][i]] == 1)
					isLeaf[g[v][i]] = 1;
			}
		}
		sum -= 2;
	}
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	cin >> n;

	for (int i(1); i < n; i++) {
		int a, b;
		scanf("%d%d", &a, &b);
		g[a].push_back(b);
		g[b].push_back(a);
		kk[a]++;
		kk[b]++;
	}

	int k;
	int z[100005];
	set <int> q;
	cin >> k;
	for (int i(0); i < k; i++) {
		scanf("%d", &z[i]);
		q.insert(z[i]);
	}

	dfs(1);

	sum = (n - 1) * 2;

	for (int i(1); i <= n; i++) {
		if (q.find(i) == q.end())
			del(i);
	}

	vector <int> ans;
	for (int i(k - 1); i >= 0; i--) {
		ans.push_back(sum - h[z[i]]);
		del(z[i]);
	}

	reverse(ans.begin(), ans.end());

	for (int i(0); i < ans.size(); i++) {
		cout << ans[i] << ' ';
	}
}