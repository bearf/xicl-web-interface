#pragma comment(linker, "/STACK:256000000")

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <queue>
#include <deque>
#include <complex>

using namespace std;

#define pb push_back
#define pbk pop_back
#define all(x) (x).begin(), (x).end()
#define fs first
#define sc second
#define y0 yy0
#define y1 yy1
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define prev _prev
#define rank _rank
#define link _link
#define hash _hash
#define next _next
#ifdef LOCAL
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef complex<double> tc;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));

const int N = 18;
const int MSK = 1 << N;
int A[MSK + 1];

int n;

/*int rotate(int x, int t)
{
	int a = x & ((1 << t) - 1);
	int b = (x >> t);
	return (a << (n - t)) ^ b;
}*/

int nb(int x)
{
	for (int i = 0; i < n; i++)
		if ((1 << i) == x)
			return i;
	assert(false);
}

int pt[MSK];
vector<int> ans;
void DFS(int x)
{
	while (pt[x] != n)
	{
		int y = pt[x];
		int nx = x ^ (1 << y);
		int r = pt[x]++;
		DFS(nx);
		//ans.push_back(r + 1);
		printf("%d ", r + 1);
	}
}

bool cwas[MSK][N];

void myassert(bool x)
{
	if (!x)
	{
		cerr << "FUCK";
		while (1);
	}
}

void check(vector<int> ans)
{
	int msk = 0;
	for (int i = 0; i < ans.size(); i++)
	{
		msk ^= (1 << (ans[i] - 1));
		myassert(!(cwas[msk][ans[i] - 1]));
		cwas[msk][ans[i] - 1] = true;
	}
	for (int i = 0; i < (1 << n); i++)
		for (int j = 0; j < n; j++)
			myassert(cwas[i][j]);
}

int main() {
#ifdef LOCAL
#define TASK "F"
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	cin >> n;
	cout << n * (1 << n) << endl;
	DFS(0);
	//check(ans);
	return 0;
}

