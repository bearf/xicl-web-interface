#pragma comment(linker, "/STACK:64000000")

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <queue>
#include <deque>
#include <complex>

using namespace std;

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define all(x) (x).begin(), (x).end()
#define fs first
#define sc second
#define y0 yy0
#define y1 yy1
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define prev _prev
#define rank _rank
#define link _link
#define hash _hash
#define next _next
#ifdef LOCAL
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef complex<double> tc;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));

const int N = 100500;
pair<int, int> T[2 * N];

struct mat
{
	int rpt[N];
	int R[N][5];
	int n;
	mat(int _n)
	{
		n = _n;
		for (int i = 0; i < n; i++)
			rpt[i] = 0, R[i][0] = R[i][1] = -1;
	}
	friend mat operator *(mat a, mat b)
	{
		int n = a.n;
		mat c(n);
		assert(a.n == b.n);
		for (int i = 0; i < n; i++)
		{
			for (int j1 = 0; j1 < a.rpt[i]; j1++)
			{
				int j = a.R[i][j1];
				for (int k1 = 0; k1 < b.rpt[j]; k1++)
					c.R[i][c.rpt[i]++] = b.R[j][k1];
			}
		}
		for (int i = 0; i < n; i++)
		{
			assert(c.rpt[i] <= 4);
			sort(c.R[i], c.R[i] + c.rpt[i]);
			int pt = 0;
			for (int j = 0; j < c.rpt[i]; j++)
			{
				if ((j + 1 != c.rpt[i]) && c.R[i][j] == c.R[i][j + 1])
					j++;
				else
					c.R[i][pt++] = c.R[i][j];
			}
			c.rpt[i] = pt;
			assert(pt <= 2);
		}
		return c;
	}

	friend vector<int> operator *(mat a, vector<int> v)
	{
		int n = v.size();
		assert(a.n == n);
		vector<int> res(n);
		for (int i = 0; i < n; i++)
		{
			for (int j = 0; j < a.rpt[i]; j++)
				res[i] ^= v[a.R[i][j]];
		}
		return res;
	}
};

char buf[N];

int main() {
#ifdef LOCAL
#define TASK "I"
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	llong t;
	int n;
	cin >> t >> n;
	/*t = 1000000000LL * 1000000000LL;
	n = 100000;*/
	scanf(" %s", buf);
	/*for (int i = 0; i < n; i++)
		buf[i] = rand() % 2 + '0';
	buf[n] = 0;*/
	vector<int> v(n);
	for (int i = 0; i < n; i++)
		v[i] = buf[i] - '0';
	
	mat a(n);
	for (int i = 0; i < n; i++)
	{
		if (i)
			a.R[i][a.rpt[i]++] = i - 1;
		if (i + 1 != n)
			a.R[i][a.rpt[i]++] = i + 1;
	}
	
	for (int i = 0; i <= 60; i++)
	{
		if ((t >> i) & 1)
			v = a * v;
		eprintf("%d\n", i);
		a = a * a;
	}
	for (int i = 0; i < n; i++)
		printf("%d", v[i]);
	puts("");
	//while(1);
	return 0;
}
