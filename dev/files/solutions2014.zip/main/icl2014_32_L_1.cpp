#include <iostream>
#include <string>
#include <math.h>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;
long long int sum = 0;
int main() {
	int n;
	cin>>n;
	long long int d = 0,m = 0;
	for(int i = 0;i<n;i++)
		for(int j = 0;j<n;j++)
	{
		int q;
		cin>>q;
		sum+=q;
		if(q>0)
			m++;
		else
			d++;
	}
	if(d>m)
		cout<<-1;
	else
		cout<<sum;
	return 0;
}