#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cassert>
#include <ctime>
#include <memory.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <complex>
#include <list>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef complex <ld> point;

#define pb push_back
#define mp make_pair
#define fi first
#define se second

#define INF 1000000001
#define INFL 1000000000000000001ll
#define NAME "a"

typedef vector <pair <int, int> > vii;
typedef vector <vector <int> > vv;
vii v;

vv solve(vii v) {
    char one = 1;
    for (int i = 0; i < (int) v.size(); ++i)
        one &= (v[i].se == 0);
    if (one) {
        vv res(1, vector <int>(0));
        return res;
    }
    vv res(0);
    for (int i = 0; i < (int) v.size(); ++i) {
        if (v[i].se == 0)
            continue;
        v[i].se--;
        vv c = solve(v);
        for (int j = 0; j < (int) c.size(); ++j) {
            for (int k = 0; k < (int) c[j].size(); ++k)
                c[j][k] *= v[i].fi;
            for (int k = 0; k < (v[i].fi - 1) / 2; ++k)
                c[j].pb(1);
            res.pb(c[j]);
        }
        v[i].se++;
    }
    return res;
}

bool cmp(const vector <int> &v1, const vector <int> &v2) {
    for (int i = 0; i < (int) v1.size(); ++i)
        if (v1[i] != v2[i])
            return v1[i] < v2[i];
    return 0;
}

int main() {
    #ifdef _GEANY
    assert(freopen(NAME ".in", "r", stdin));
    #endif // _GEANY
    int n;
    cin >> n;
    int k = 2 * n + 1;
    for (int i = 2; i <= k; ++i) {
        if (k % i == 0) {
            v.pb(mp(i, 0));
            while (k % i == 0) {
                k /= i;
                ++v.back().se;
            }
        }
    }
    assert(k == 1);
    vv res = solve(v);
    cout << res.size() << ' ' << res[0].size() << endl;
    for (int i = 0; i < (int) res.size(); ++i)
        sort(res[i].begin(), res[i].end());
    sort(res.begin(), res.end(), cmp);
    for (int i = 0; i < (int) res.size(); ++i) {
        for (int j = 0; j < (int) res[i].size(); ++j) {
            cout << res[i][j] << ' ';
        }
        cout << '\\n';
    }
}
