#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <math.h>

//#define _DEBUG
#define forn(i,n) for (int i=0;i<n;i++)
#define LL long long

using namespace std;

int main()
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif

	LL n;
	cin>>n;		
	vector <int> a(300,0);

	int p=0;
	while (n>0)
	{
		a[p]=n%2;
		n/=2;
		p++;
	}
	int l=0,r=0;
	while (l<300)
	{
		if (a[l]==0)
		{
			l++;
			continue;
		}

		r=l;
		while (a[r]==1)
			r++;

		if (r-l==1)
		{
			l++;
			continue;
		}

		a[l]=-1;
		for (int i=l+1;i<r;i++)
			a[i]=0;
		a[r]=1;
		l++;
	}

	l=299;
	while (a[l]==0)
		l--;
	while (l>=0)
	{
		cout<<a[l];
		if (l>0)
			cout<<" ";
		l--;
	}
}