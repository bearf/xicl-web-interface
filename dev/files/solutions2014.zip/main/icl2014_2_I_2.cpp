#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cassert>
#include <ctime>
#include <memory.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <complex>
#include <list>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef complex <ld> point;

#define pb push_back
#define mp make_pair
#define fi first
#define se second

#define INF 1000000001
#define INFL 1000000000000000001ll
#define NAME "i"

char s[200001];
char _s[200001];
char S[200001];

int main() {
    #ifdef _GEANY
    assert(freopen(NAME ".in", "r", stdin));
    #endif // _GEANY
    ll t;
    ll _t;
    int n;
    cin >> t >> n;
    _t = t;
    scanf("%s", s);
    for (int i = 0; i < n; ++i)
        s[i] -= '0';
    memcpy(_s, s, sizeof(s));
    ll d = 1;
    while (t) {
        if (t % 2 == 1) {
            memset(S, 0, sizeof(S));
            for (ll i = 0; i < n; ++i) {
                if (!s[i])
                    continue;
                if (i + d < n)
                    S[i + d] ^= 1;
                else if (n - i + n >= d && i + d > n)
                    S[n - (d - (n - i))] ^= 1;
                if (i - d >= 0)
                    S[i - d] ^= 1;
                else if (i + 1 + n >= d && i - d < 0)
                    S[-1 + (d - i - 1)] ^= 1;
            }
            memcpy(s, S, sizeof(s));
        }
        t /= 2;
        d *= 2;
    }
    for (int i = 0; i < n; ++i)
        cout << int(s[i]);
    cout << endl;

//    t = _t;
//    memcpy(s, _s, sizeof(s));
//    d = 1;
//    while (t) {
//        for (ll i = 0; i < n; ++i) {
//            int x1 = (i - d < 0 ? 0 : s[i - d]);
//            int x2 = (i + d >= n ? 0 : s[i + d]);
//            S[i] = char(x1 ^ x2);
//        }
//        memcpy(s, S, sizeof(s));
//        --t;
//    }
//    for (int i = 0; i < n; ++i)
//        cerr << int(s[i]);
//    cerr << endl;
}
