#ifdef SU2_PROJ
#define _GLIBCXX_DEBUG
#endif

#include <algorithm>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <string>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define forn(i, n) for (int i = 0; i < int(n); i++)
#define forl(i, n) for (int i = 1; i <= int(n); i++)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; i--)
#define fore(i, l, r) for (int i = int(l); i <= int(r); i++)
#define correct(x, y, n, m) (0 <= (x) && (x) < (n) && 0 <= (y) && (y) < (m))
#define pb(a) push_back(a)
#define all(a) (a).begin(), (a).end()
#define mp(x, y) make_pair((x), (y))
#define sz(a) int((a).size())
#define ft first
#define sc second
#define x first
#define y second

using namespace std;

typedef long long li;
typedef long double ld;
//typedef pair <int, int> pt;

const int INF = int(1e9);
const li INF64 = li(1e18);
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

template <typename X> inline X sqr(const X& a) { return a * a; }
template <typename X> inline X abs(const X& a) { return a < 0 ? -a: a; }

struct pt
{
	ld x, y;
	pt() {}
	pt(ld x, ld y): x(x), y(y) {}
};

inline pt operator- (const pt& a, const pt& b) { return pt(a.x - b.x, a.y - b.y); }
inline pt operator+ (const pt& a, const pt& b) { return pt(a.x + b.x, a.y + b.y); }

inline pt operator* (const pt& a, const ld& b) { return pt(a.x * b, a.y * b); }

inline ld dist(const pt& a, const pt& b) { return sqrt(sqr(a.x - b.x) + sqr(a.y - b.y)); }

inline pt nextPt()
{
	int x, y;
	assert(scanf("%d%d", &x, &y) == 2);
	return pt(x, y);
}

inline ostream& operator << (ostream& out, const pt& p) { return out << "(" << p.x << ", " << p.y << ")"; }

const int N = 1000 + 3;

int n;
pt a[N], b[N];

inline bool read ()
{
	if (scanf("%d", &n) != 1) return false;
	
	forn(i, n)
	{
		a[i] = nextPt();
		b[i] = nextPt();
	}
	
	return true;
}

inline ld det(const ld& a, const ld& b, const ld& c, const ld& d) { return a * d - b * c; }

inline pt getNext(const pt& cur, int idx)
{
	ld A1 = b[idx].y - a[idx].y, B1 = a[idx].x - b[idx].x, C1 = -(A1 * a[idx].x + B1 * a[idx].y);
	
	ld d = (A1 * cur.x + B1 * cur.y + C1) / sqrt(sqr(A1) + sqr(B1));	
	if (abs(d) < EPS) return cur;
	
	pt a = cur, b = cur + pt(A1, B1);
	ld A2 = b.y - a.y, B2 = a.x - b.x, C2 = -(A2 * a.x + B2 * a.y);
	
	ld dt = det(A1, B1, A2, B2);
	return pt(-det(C1, B1, C2, B2) / dt, -det(A1, C1, A2, C2) / dt);
}

inline ld calc(const ld& par)
{
	pt cur = a[0] + (b[0] - a[0]) * par;
	const pt start = cur;
	
	forn(ii, n)
	{
		int idx = (ii + 1 == n ? 0 : (ii + 1));		
		cur = getNext(cur, idx);
	}
	
	return dist(start, cur);
}

const int M = 50;
const int ITER = 80;

inline void solve ()
{
	const ld LF = -1e5, RG = 1e5;
	const ld H = (RG - LF) / M;
	
	ld ans = 0;
	ld ansVal = 1e100;
	
	forn(i, M)
	{
		ld lf = LF + H * i;
		ld rg = lf + H;
		
		forn(iter, ITER)
		{
			ld lmid = lf + (rg - lf) / 2.1;
			ld rmid = rg - (rg - lf) / 2.1;

			if (calc(lmid) < calc(rmid))
				rg = rmid;
			else
				lf = lmid;
		}
		
		ld mid = (lf + rg) / 2;
		ld curVal = calc(mid);
		
		if (ansVal > curVal)
		{
			ansVal = curVal;
			ans = mid;
		}
	}
	
	//cerr << ans << ' ' << ansVal << endl;
	
	pt res = a[0] + (b[0] - a[0]) * ans;
	printf("%.10lf %.10lf", double(res.x), double(res.y));
	puts("");
}

int main()
{
#ifdef SU2_PROJ
	freopen("input.txt", "rt", stdin);
	//freopen("output.txt", "wt", stdout);
#endif

	cout << setprecision(10) << fixed;
	cerr << setprecision(5) << fixed;
	
	assert(read());
	solve();
	
#ifdef SU2_PROJ
	cerr << "=== Time: " << clock() << " ===" << endl;
#endif

	return 0;
}
