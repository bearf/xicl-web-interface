#include <iostream>
#include <stdio.h>
#include <fstream>

using namespace std;

int main(){
	ifstream  fIn("stdin");
	ofstream fOut("stdout");
	
	
	int n, i, j, t, cnt=0, s=0;

	fIn >> n;
	int field[14][14];

	for (i=0; i<n; i++){
		for (j=0; j<n; j++){
			field[i][j]=0;
			fIn >> t;
			field[i][j]=t;
			if (field[i][j]==0) cnt++;
			s+=field[i][j];
		}
	}

	if (cnt<(n*n/2)) {
		fOut << s;
	} else {
		fOut << "-1";
	}

	return 0;
}