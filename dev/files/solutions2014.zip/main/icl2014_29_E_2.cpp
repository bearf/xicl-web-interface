#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <cassert>

using namespace std;

#ifdef _WIN32
	#define LLD "%I64d"
#else
	#define LLD "%lld"
#endif

typedef long double ld;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<long long> vll;

#define mp make_pair
#define pb push_back
#define sz(x) ((int)(x).size())
#define EPS (1e-9)
#define INF ((int)1e9)
#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define TASK "text"

const int maxn = (int)2e5 + 100;
int a[maxn], cols[maxn];
pair<int, int> ps[maxn];
vector<vector<int> > socks;

int n, m;
int get(int c, int l,  int r) {
	if (c < 0 || c >= m)
		return 0;
	return lower_bound(socks[c].begin(), socks[c].end(), r) - lower_bound(socks[c].begin(), socks[c].end(), l);
}

int solve() {
	if (scanf("%d", &n) < 1)
		return 0;
	for (int i = 0; i < n; ++i) {
		scanf("%d", &a[i]);
		cols[i] = a[i];
	}
	sort(cols, cols + n);
	m = unique(cols, cols + n) - cols;
	for (int i = 0; i < n; ++i)
		a[i] = lower_bound(cols, cols + m, a[i]) - cols;
			
	int ans = 0;
	socks = vector<vector<int> >(m);
	for (int i = 0; i < n; ++i)
		socks[a[i]].pb(i);

	for (int c = 0; c < m; ++c)
		ans = max(ans, sz(socks[c]));
	
	for (int c = 0; c < m - 1; ++c) {
		for (int i = 0, j = 0; i < sz(socks[c]); ++i) {
			while (j < sz(socks[c + 1]) && socks[c + 1][j] < socks[c][i])
				++j;
			ans = max(ans, (i + 1) + (sz(socks[c + 1]) - j));
		}
	}
	

	for (int c = 0; c < m;) {
		int c1 = c;
		int c2 = c1 + 1;
		int cur = sz(socks[c1]);
		while (c2 < m && socks[c2 - 1][sz(socks[c2 - 1]) - 1] < socks[c2][0]) {
			cur += sz(socks[c2]);
			++c2;
		}
		--c1;
		cur += get(c1, 0, socks[c1 + 1][0]);
		cur += get(c2, socks[c2 - 1][sz(socks[c2 - 1]) - 1] + 1, n);
		ans = max(ans, cur);
		c = c2;
	}
	printf("%d\n", n - ans);
	return 1;
}

int main() {
#ifdef DEBUG
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	
	int n;
	while (1) {
		if (!solve())
			break;
		#ifdef DEBUG
		eprintf("%.18lf\n", (double)clock() / CLOCKS_PER_SEC);		
		#endif
	}
	return 0;
}
