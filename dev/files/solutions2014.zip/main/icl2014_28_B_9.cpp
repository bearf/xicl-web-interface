#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <stdio.h>
#include <queue>
#include <deque>
#define USE_MATH_DEFINES
#include <math.h>

#define ll long long
#define ull unsigned ll
#define mp make_pair
#define pb push_back

using namespace std;

const int MOD = 1000000009;
const ll INF = 1000000000000000;

const int base = 1048576;

int t[20][base * 2];
int ans = 0;

inline void push(int v, int k)
{
	if (v < base)
	{
		t[k][v << 1] += t[k][v];
		if (t[k][v << 1] >= MOD)
			t[k][v << 1] -= MOD;
		t[k][(v << 1) + 1] += t[k][v];
		if (t[k][(v << 1) + 1] >= MOD)
			t[k][(v << 1) + 1] -= MOD;
		t[k][v] = 0;
	}
}


void inc(int v, int k, int l, int r, int L, int R, int x)
{
	if (l >= R || r <= L)
		return;
	if (l >= L && r <= R)
	{
		t[k][v] += x;
		if (t[k][v] >= MOD)
			t[k][v] -= MOD;
		return;
	}
	push(v, k);
	int m = (l + r) / 2;
	inc((v << 1), k, l, m, L, R, x);
	inc((v << 1) + 1, k, m, r, L, R, x);
}

int value(int k, int v)
{
	v += base;
	int s = 0;
	while (v > 0)
	{
		s += t[k][v];
		if (s >= MOD)
			s -= MOD;
		v >>= 1;
	}
	return s;
}


int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	int n, k;
	int pow2[25];

	pow2[0] = 1;
	for (int i(1); i < 25; i++) {
		pow2[i] = pow2[i-1] * 2;
	}

	cin >> n >> k;

	inc(1, 0, base, base * 2, base, base + 1, 1);
	for (int j(0); j < k - 1; j++) {
		for (int i(0); i < n; i++) {
			int d = value(j, i);
			if (d != 0) {
				int a;
				if (i == 0)
					a = 1;
				else
					a = i;

				int q = (n - a) / (pow2[k - j - 1] - 1) - i;
				inc(1, j + 1, base, base * 2, i + a + base, i + q + 1 + base, d);
			}
		}
	}
	for (int i = 0; i < n; ++i)
		if (i <= n - i)
		{	
			ans = ans + value(k - 1, i);
			if (ans >= MOD)
				ans -= MOD;
		}
	cout << ans;
}