#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int main(){
	vector <int> socks;
	vector <int> dbsocks;
	vector <int> esocks;
	int n, o = 0, d =1;
	cin>>n;
	socks.resize(n);
	dbsocks.resize(n);
	for(int i=0;i<n;i++){
		cin>>socks[i];
	}
	esocks = socks;
	sort(esocks.begin(),esocks.end());
	if(esocks==socks){
		cout<<o;
		return 0;
	}
	while(esocks!=socks){
		for(int i=0;i<n;i++){
			if(esocks==socks){
				cout<<o;
				return 0;
			}
			if(socks[i]>esocks[i]){
				o++;
				for(int j=0, k=0;k<n;k++,j++){
					if(j==i && d==1){
						j--;
						d++;
						continue;
					}
					dbsocks[j]=socks[k];
				}
				dbsocks[n-1]=socks[i];
				socks=dbsocks;
			} else if(socks[i]<esocks[i]){
				o++;
				for(int j=1, k=0;k<n;k++,j++){
					if(j==i && d ==1 ){
						j--;
						d++;
						continue;
					}
					dbsocks[j]=socks[k];
				}
				dbsocks[0]=socks[i];
				socks=dbsocks;
			}
			d=1;
		}
	}
	cout<<o;
	return 0;
}
