#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cassert>
#include <ctime>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

typedef long long ll;
typedef long long li;

void Solve(void);

int main(){
#ifdef BANANA_MOTEL
	freopen("test.in", "r", stdin);
	freopen("test.out", "w", stdout);
#else
#endif
	cout.precision(8);
	cout<<fixed;
	Solve();
	return 0;
}

#define M 100100

const long double eps=1e-10;

struct point{
	long double x,y;
	void read(void){
		cin>>x>>y;
	}
	long double len(void){
		return sqrt(x*x+y*y);
	}
} a[M],b[M];

struct line{
	long double A,B,C;
	line(){}
	line(point a, point b){
		A=b.y-a.y;
		B=-(b.x-a.x);
		C=-a.x*(b.y-a.y)+a.y*(b.x-a.x);
	}
} l[M];

long double val(const line l, const point x){
	return l.A*x.x+l.B*x.y+l.C;
}

point operator *(const point x, long double c){
	point ans;
	ans.x=x.x*c;
	ans.y=x.y*c;
	return ans;
}

point operator +(const point &x, const point &y){
	point ans;
	ans.x=x.x+y.x;
	ans.y=x.y+y.y;
	return ans;
}

point operator -(const point &x, const point &y){
	point ans;
	ans.x=x.x-y.x;
	ans.y=x.y-y.y;
	return ans;
}

point per(const line l){
	point ans;
	ans.x=l.A;
	ans.y=l.B;
	return ans;
}

point proj(const line l, const point x){
	long double t=-val(l,x)/(l.A*l.A+l.B*l.B);
	return x+(per(l)*t);
}

struct vec{
	point a,b;
	vec(point a, point b):a(a),b(b){}
	vec(){}
};

vec proj(const line l, const vec x){
	vec ans;
	ans.a=proj(l,x.a);
	ans.b=proj(l,x.b);
	return ans;
}

void stress(void){
	point x,y;
	line l;
	for (l.A=-30; l.A<30; ++l.A)
		for (l.B=30; l.B<30; ++l.B)
			for (l.C=-30; l.C<30; ++l.C)
				for (x.x=-30; x.x<30; ++x.x)
					for (x.y=-30; x.y<30; ++x.y)
						if (val(l,proj(l,x))!=0)
							cout<<"FUUUUUUU\n";
}

void Solve()
{
	int n;
	cin>>n;
	for (int i=0; i<n; ++i){
		a[i].read();
		b[i].read();
		l[i]=line(a[i],b[i]);
	}

	a[n]=a[0];
	b[n]=b[0];
	l[n]=l[0];

	point x=a[0],y=b[0];
	point px=x,py=y;

	for (int i=0; i<n; ++i){
		px=proj(l[i+1],px);
		py=proj(l[i+1],py);
	}

	point d=(y-x)-(py-px);
	point de=px-x;

	
	if (d.len()<eps && de.len()>eps){
		cout<<"-1\n";
		return;
	}

	long double t;

	if (d.len()<eps)
		t=0;
	else
		t=de.len()/d.len();

	point ans=x+((y-x)*t);

	cout<<ans.x<<" "<<ans.y<<"\n";


}