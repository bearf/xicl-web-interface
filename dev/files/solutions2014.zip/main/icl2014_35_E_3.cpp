#include <iostream>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
using namespace std;

#if LOCAL
	#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
	#define eprintf(...) 42;
#endif

const int MAXN = 222222;

int n;
int a[MAXN];
int fst[MAXN];
int nxt[MAXN];
int cnt[MAXN];
int cnt2[MAXN];
int cnt3[MAXN];
int lst[MAXN];
int dp[MAXN];
vector <int> all;

inline bool check(int x, int pos) {
	if (x == (int)all.size() - 1) {
		return false;
	}
	if (fst[x + 1] < pos) {
		return false;
	}
	if (x == (int)all.size() - 2) {
		return true;
	}
	return lst[x + 1] < fst[x + 2];
}

int main() {
#ifdef LOCAL
	freopen("e.in", "r", stdin);
#endif
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%d", &a[i]);
		all.push_back(a[i]);
	}
	sort(all.begin(), all.end());
	all.erase(unique(all.begin(), all.end()), all.end());
	for (int i = 0; i < (int)all.size(); i++) {
		lst[i] = -1;
		fst[i] = -1;
	}
	for (int i = 0; i < n; i++) {
		a[i] = lower_bound(all.begin(), all.end(), a[i]) - all.begin();
		cnt2[a[i]]++;
	}
	for (int i = n - 1; i >= 0; i--) {
		nxt[i] = fst[a[i]];
		fst[a[i]] = i;
	}
	for (int i = 0; i < n; i++) {
		lst[a[i]] = i;
	}
	for (int i = 0; i < n; i++) {
		eprintf("%d ", a[i]);
	}
	eprintf("\n");
	int ans = 0;
	for (int i = n - 1; i >= 0; i--) {
		int x = a[i];
		cnt3[i] = cnt[x + 1];
		if (nxt[i] == -1)  {
			// last
			if (x + 1 == (int)all.size()) {
				dp[i] = 1;
			} else {
				if (check(x, i)) {
					eprintf("check ok %d\n", i);
					assert(fst[x + 1] != -1);
					dp[i] = 1 + dp[fst[x + 1]];
				} else {
					dp[i] = cnt[x + 1] + 1;
					if (fst[x + 1] > i) {
						dp[i] = max(dp[i], 1 + cnt[x + 1] + cnt3[lst[x + 1]]);
					}
				}
			}
		} else {
			// not last
			eprintf("!!! %d\n", i);
			dp[i] = max(cnt[x + 1] + 1, 1 + dp[nxt[i]]);
			if (check(x, i)) {
				assert(fst[x + 1] != -1);
				dp[i] = max(dp[i], 1 + dp[fst[x + 1]]);
			}
			if (fst[x + 1] > i) {
				dp[i] = max(dp[i], 1 + cnt[x + 1] + cnt3[lst[x + 1]]);
			}
		}
		cnt[x]++;
		ans = max(ans, dp[i]);
	}
	for (int i = 0; i < n; i++) {
		eprintf("%d ", dp[i]);
	}
	eprintf("\n");
	printf("%d\n", n - ans);
	return 0;
}