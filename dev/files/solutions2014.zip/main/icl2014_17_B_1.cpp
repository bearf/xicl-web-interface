#pragma comment(linker, "/STACK:256000000")
#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <algorithm>
using namespace std;
const int b=1000000009;
int main(){
	//freopen("1.txt","r",stdin);
	int n,k;
	cin>>n>>k;
	//vector<vector<int> > d(k+1,vector<int> (n+1,0));
	vector<vector<int> > s(k+1,vector<int> (n+1,0));
	//d[0][0]=1;
	int d=1;
	for(int i=0;i<=n;i++)
		s[0][i]=1;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=k;j++)
		{
			int h = i/2;
			//d[j][i] = s[j-1][h];
			d = s[j-1][h];
			s[j][i] = (s[j][i-1] + d)%b;
		}
	cout<<d<<endl;
	

}