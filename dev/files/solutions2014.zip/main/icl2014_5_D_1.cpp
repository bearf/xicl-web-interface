#include <iostream>
#include <string>
using namespace std;

string s, q;
int n;

int main()
{
	cin >> s;
	n = s.length();
	if (n == 1)
	{
		int x = (int)(s[0] - '0');
		for (int i = 1; i <= x; i++)
			printf("%d", i);
		return 0;
	}
	int x = (int)(s[0] - '0');
	q = "";
	for (int i = 0; i < n; i++)
		q += s[0];
	bool t = s < q;
	for (int i = 1; i <= x; i++)
		printf("%d", i);
	for (int i = 0; i < 10; i++)
	{
		if (!t || i != x)
			printf("%d", i);
	}
	for (int i = 2; i < n; i++)
		for (int j = 0; j < 10; j++)
			printf("%d", j);
//	cin >> n;
	return 0;
}