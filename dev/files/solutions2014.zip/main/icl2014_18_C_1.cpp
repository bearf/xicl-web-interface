#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#define ll long long
using namespace std;

int main() {
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);

	ll n;
	cin >> n;
	vector<int> ans;
	while (n > 0) {
		ans.push_back(n % 2);
		n /= 2;
	}
	for (int i = ans.size()-1; i >= 0; i--) {
		cout << ans[i] << ' ';
	}
}