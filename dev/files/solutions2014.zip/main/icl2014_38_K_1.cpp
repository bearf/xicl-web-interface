#include<stdio.h>
//#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#define mp make_pair

using namespace std;

int n;
double a[33333], b[33333], c[33333];

pair<double, double> f(double x, double y) {
	for (int i = 1; i <= n; i++) {
		double d = a[i] * x + b[i] * y + c[i];
		x += (-a[i]) * d;
		y += (-b[i]) * d;
//		printf("%.5lf\n", a[i] * x + b[i] * y + c[i]);
	}
	return mp(x, y);
}

double value(double x, double y) {
	pair<double, double> e = f(x, y);
	return (x - e.first) * (x - e.first) + (y - e.second) * (y - e.second);
}

int main() {
//	freopen("1.in", "r", stdin);
//	freopen("1.out", "w", stdout);
	scanf("%d", &n);
	double xs, ys;
	for (int i = 0; i < n; i++) {
		int x, y, xx, yy;
		scanf("%d%d%d%d", &x, &y, &xx, &yy);
		if (i == 0) {
			xs = x;
			ys = y;
		}
		a[i] = yy - y;
		b[i] = x - xx;
		double s = sqrt(a[i] * a[i] + b[i] * b[i]);
		a[i] /= s;
		b[i] /= s;
		c[i] = -a[i] * x - b[i] * y;
	}
	a[n] = a[0];
	b[n] = b[0];
	c[n] = c[0];
	f(0, 0);
	for (int it = 0; it < 600; it++) {
		pair<double, double> e = f(xs, ys);
		double xf = e.first;
		double yf = e.second;

		double xA = (xs + xf) / 2;
		double yA = (ys + yf) / 2;

		double xB = (xs - xf) / 2;
		double yB = (ys - yf) / 2;


		double d1 = value(xA, yA);
		double d2 = value(xB, yB);

		if (d1 < d2) {
			xs = xA;
			ys = yA;
		} else {
			xs = xB;
			ys = yB;
		}
	}
	if (value(xs, ys) > 1e-7) {
		puts("-1");
		return 0;		
	}
	printf("%.8lf %.8lf\n", xs, ys);

}