#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main(){
	string A;
	cin>>A;
	vector<int> a;
	a.resize(10);
	for(int i=0;i<10;i++){
		a[i]=A.length()-1;
	}
	int b;
	b=A[0]-'0';
	for(int i=1;i<b;i++){
		if(b==1){
			break;
		}
		a[i]++;
	}
	int sum=0;
	for(int i=0;i<A.length();i++){
		if(A[i]-'0'==b){
			sum++;
		} else {
			break;
		}
	}
	if(sum>a[b]){
		a[b]=sum;
	}
	a[1]--;
	cout<<1;
	for(int i=0;i<a[0];i++){
		cout<<0;
	}
	for(int i=0;i<a[1];i++){
		cout<<1;
	}
	for(int i=0;i<a[2];i++){
		if(a[2]>=2){
			for(int i=0;i<a[2]-1;i++){
				cout<<"01";
			}
		}
		cout<<2;
	}
	for(int i=0;i<a[3];i++){
		if(a[3]>=2){
			for(int i=0;i<a[3]-1;i++){
				cout<<"012";
			}
		}
		cout<<3;
	}
	for(int i=0;i<a[4];i++){
		if(a[4]>=2){
			for(int i=0;i<a[4]-1;i++){
				cout<<"0123";
			}
		}
		cout<<4;
	}
	for(int i=0;i<a[5];i++){
		if(a[5]>=2){
			for(int i=0;i<a[5]-1;i++){
				cout<<"01234";
			}
		}
		cout<<5;
	}
	for(int i=0;i<a[6];i++){
		if(a[6]>=2){
			for(int i=0;i<a[6]-1;i++){
				cout<<"012345";
			}
		}
		cout<<6;
	}
	for(int i=0;i<a[7];i++){
		if(a[7]>=2){
			for(int i=0;i<a[7]-1;i++){
				cout<<"0123456";
			}
		}
		cout<<7;
	}
	for(int i=0;i<a[8];i++){
		if(a[8]>=2){
			for(int i=0;i<a[8]-1;i++){
				cout<<"01234567";
			}
		}
		cout<<8;
	}
	for(int i=0;i<a[9];i++){
		if(a[9]>=2){
			for(int i=0;i<a[9]-1;i++){
				cout<<"012345678";
			}
		}
		cout<<9;
	}

	return 0;
}