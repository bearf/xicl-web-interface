#undef NDEBUG
#ifdef ssu1
#define _GLIBCXX_DEBUG
#endif

#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define fore(i, l, r) for(int i = (l); i < (r); ++i)
#define forn(i, n) fore(i, 0, n)
#define fori(i, l, r) fore(i, l, (r) + 1)
#define X first
#define Y second
#define sz(v) ((int)(v).size())
#define pb push_back
#define mp make_pair
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acosl(-1.0);

const int N = 200;

int sza;
int a[N];

int main(){
    #ifdef ssu1
    assert(freopen("_input.txt", "r", stdin));
    #endif
    
    li n;
    cin >> n;
    
    sza = 0;
    while(n > 0){
        a[sza++] = (n & 1);
        n = (n >> 1);
    }
    
    int c = 0;
    for(int i = 0; i < sza || c; ++i){    
        sza = max(sza, i + 1);
        
        a[i] += c;
        
        c = 0;
        while(a[i] > 1){
            c++;
            a[i] -= 2;
        }
    
        if(a[i] == 1 && i + 1 < sza && (a[i + 1] + c) % 2 == 1){
            c = (a[i + 1] + c) / 2;
        
            a[i] = -1;
            a[i + 1] = 0;
            
            while(i + 2 >= sza)
                sza++;
            c++;
            i++;                
        }
    }
   
    for(int i = sza - 1; i >= 0; --i){
        if(i + 1 != sza)
            printf(" ");
        printf("%d", a[i]);
    }    
    
    return 0;
}






