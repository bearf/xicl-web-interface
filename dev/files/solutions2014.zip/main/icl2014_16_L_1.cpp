#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cmath>


using namespace std;

int n;
long long sum;
int main () {
//	freopen("input.txt", "r", stdin);freopen("output.txt", "w", stdout);
	cin >> n;
	int num = 0, cnt = 0, cnt2 = 0;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			cin >> num;
			if (num == 0) {
				cnt++;
			} else {
				cnt2++;
				sum += num;
			}
		}
	}
	if (cnt > cnt2) {
		sum =-1;
	}
	cout << sum;
}