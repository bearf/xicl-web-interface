#undef NDEBUG
#ifdef ssu1
#define _GLIBCXX_DEBUG
#endif

#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define fore(i, l, r) for(int i = (l); i < (r); ++i)
#define forn(i, n) fore(i, 0, n)
#define fori(i, l, r) fore(i, l, (r) + 1)
#define X first
#define Y second
#define sz(v) ((int)(v).size())
#define pb push_back
#define mp make_pair
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acosl(-1.0);

int L, n;
vector<vector<int> > res;
vector<int> cur;
void brute(int i, int sum){
    if(sum > n)
        return;
    if(sum == n){
        if(i < L){
            res.clear();
        }
        L = sz(cur);
        res.pb(cur);
        return;
    }
    if(i >= L)
        return;
        
    {
        int val = 2 * sum + 1;
        cur.pb(val);
        brute(i + 1, sum + val);
        cur.pop_back();
    }
    {
        int val = cur.back();
        cur.pb(val);
        brute(i + 1, sum + val);
        cur.pop_back();
    }
}

int main(){
    #ifdef ssu1
    assert(freopen("__input.txt", "r", stdin));
    #endif
    
    L = 500;
    
    cin >> n;
    cur.pb(1);
    brute(1, 1);
    
//    forn(i, sz(res))
//        sort(all(res[i]));
    sort(all(res));
    
    
    printf("%d %d\n", sz(res), L);
    forn(i, sz(res)){
        assert(sz(res[i]) == L);
        forn(j, sz(res[i])){
            if(j)
                printf(" ");
            printf("%d", res[i][j]);
        }
        puts("");
    }
    
    return 0;
}






