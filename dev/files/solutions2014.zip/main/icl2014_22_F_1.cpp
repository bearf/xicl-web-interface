#pragma comment(linker, "/STACK:64000000")

#include<iostream>
#include<cstdio>
#include<sstream>

#include<algorithm>
#include<vector>
#include<set>
#include<bitset>
#include<map>
#include<queue>
#include<deque>
#include<stack>

#include<string>
#include<memory.h>
#include<cassert>
#include<time.h>

using namespace std;

#define forn(i, n) for(int i = 0; i < (int)n; i++)
#define forab(i, a, b) for(int i = (int)a; i <= (int)b; i++)
#define fornd(i, n) for(int i = 0; i < (int)n; i--)
#define forabd(i, b, a) for(int i = (int)b; i >= (int)a; i--)
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define _(a, val) memset(a, val, sizeof(a))
#define sz(a) (int)(a).size()

typedef long long lint;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;

const int INF = 1000000000;
const lint LINF = (lint)INF * (lint)INF;
const double eps = 1e-9;

struct Maska
{
	int bit, msk;
	Maska() {}
	Maska(int b, int m)
	{
		bit = b;
		msk = m;
	}
};

int n;
vector<Maska> a;
bool mem[1 << 18];

void read()
{
	scanf("%d", &n);
}

void addIf(int &cur_msk, int it)
{
	a.pb( Maska(it, cur_msk ^ (1 << it)) );
	if ((cur_msk ^ (1 << it)) == 0)
		return;
	a.pb( Maska(it, cur_msk) );
}

void solve()
{
	a.pb ( Maska(0, 1) );
	a.pb ( Maska(0, 0) );

	for(int it = 1; it < n; it++)
	{
		_(mem, 0);
		mem[0] = true;
		int sizea = sz(a);

		a.pb ( Maska(it, 1 << it) );
		int cur_msk = a[sz(a) - 1].msk;
		for(int i = 0; i < sizea; i++)
		{
			a.pb ( Maska( a[i].bit, a[i].msk | (1 << it) ) );
			cur_msk = a[i].msk | (1 << it);
			if (!mem[a[i].msk])
			{
				addIf( cur_msk, it );
			}
			mem[a[i].msk] = true;
		}
		a.pb (Maska(it, 0) );
	}
}

void write()
{
	printf("%d\n", sz(a));
	forn(i, sz(a))
	{
		printf("%d ", a[i].bit + 1);
	}
}

int main()
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	read();
	solve();
	write();

	return 0;
}
