#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <math.h>
#define re return
#define LL long long
//#define _DEBUG
#define forn(i,n) for (int i=0;i<n;i++)

using namespace std;

const LL nmax=7000000;

int *res;
int *tres,*tmp;

int *pos;
int *tpos;

int npos;
int go(int N){
	if(N==1){
		res[0]=1;
		res[1]=1;
		pos[0]=0;
		npos=1;
		re 2;
	}
	int nres=go(N-1),i;
	int ntres=0;

	/*tres[ntres++]=N;
	for(i=0;i<nres;++i){
		tres[ntres++]=res[i];

		tres[ntres++]=N;
		if(i!=nres-1)
			tres[ntres++]=N;
	}

	for(i=nres-1;i>=0;--i){
		tres[ntres++]=res[i];
	}*/
	int cpos=0,ntpos=0;;
	tpos[ntpos++]=ntres;
	tres[ntres++]=N;
	
	for(i=0;i<nres;++i){
		tres[ntres++]=res[i];

		if(i==pos[cpos]&&cpos<npos){
			cpos++;
			tpos[ntpos++]=ntres;
			tres[ntres++]=N;
			tpos[ntpos++]=ntres;
			tres[ntres++]=N;
		}
	}
	//tpos[cpos++]=ntres;
	tres[ntres++]=N;
	for(i=0;i<nres;++i){
		tres[ntres++]=res[i];
	}

	tmp=res;
	res=tres;
	tres=tmp;

	tmp=pos;
	pos=tpos;
	tpos=tmp;
	npos=ntpos;
	re ntres;
}

int main()
{
#ifdef _DEBUG
	freopen("inF.txt","r",stdin);
	freopen("outF.txt","w",stdout);
#endif
	res=new int[nmax];
	tres=new int[nmax];
	pos=new int[nmax];
	tpos=new int[nmax];
	int i,j,N;
	cin>>N;
	int nres=go(N);
	printf("%d\n",nres);
	for(i=0;i<nres;++i)
		printf("%d ",res[i]);
	return 0;
}