#include <iostream>
using namespace std;

int main()
{
	int a[20][20];
	int n, ans = 0;
	cin >> n;
	int z = 0;
	int f = 0;
	for (int i = 0; i < n; i++){
		for ( int j = 0; j < n; j++){
			cin >> a[i][j];		
		}
	}

	for (int i = 0; i < n; i++){
		for ( int j = 0; j < n; j++){
			if (a[i][j] > 0){
				ans = ans + a[i][j];
				f++;
			}
			else
			{
				z++;
			}
		}
	}
	if (f >=z)
	{
		cout << ans << endl;
	}
	else
	{
		cout << -1 << endl;
	}
	return 0;
}