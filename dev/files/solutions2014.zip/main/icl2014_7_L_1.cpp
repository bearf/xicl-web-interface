#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <vector>

using namespace std;

const int N = 20;

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif
	int n;
	cin >> n;

	int s = 0, z = 0;
	for (int i=0; i<n; i++)
		for (int j=0; j<n; j++) {
			int t;
			cin >> t;
			if (t)
				s += t;
			else
				z++;
		}

	cout << (s < z? -1: s) << endl;

	return 0;
}