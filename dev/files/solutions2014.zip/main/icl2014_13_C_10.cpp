#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
//ifstream cin ("input.txt");
//ofstream cout ("output.txt");
long long n, i, ds, razn = 2e18, ans[90];
int p;
long long pw;

long long powww(long long x, int k){
	long long ans_w = 1;
	for(int i = 0; i < k; i++)
		ans_w *= x;
	return ans_w;
}

int main(){
	cin >> n;
	if (n == 1){
		cout << n;
		return 0;
	}
	long long nt = n;
	while (nt != 1){
		nt /= 2;
		p++;
	}
	ds = powww(2, p);
	razn = abs(n - ds);
	double pt = p;
	ans[int(p)] = 1;
	p -= 2;
		
		while (ds != n && p >= 0){
			if (abs(n - (ds + powww(2, p))) < razn){
				razn = abs(n - (ds + powww(2, p)));
				ds += powww(2, p);
				ans[int(p)] = 1;
				p--;
			}else if (abs(n - (ds - powww(2.0, p))) < razn){
				razn = abs(n - (ds - powww(2.0, p)));
				ds -= powww(2, p);
				ans[int(p)] = -1;
				p--;
			}
			p--;
		}
	if (ds != n){
		for (i = 0; i <= pt + 2; i++) ans[i] = 0;
		p = pt + 1;
		ds = powww(2, p);
		razn = abs(n - ds);
		ans[int(p)] = 1;
		p -= 2;
		while (ds != n && p >= 0){
			if (abs(n - (ds + powww(2.0, p))) < razn){
				razn = abs(n - (ds + powww(2.0, p)));
				ds += powww(2, p);
				ans[int(p)] = 1;
				p--;
			}else if (abs(n - (ds - powww(2.0, p))) < razn){
				razn = abs(n - (ds - powww(2.0, p)));
				ds -= powww(2, p);
				ans[int(p)] = -1;
				p--;
			}
			p--;
		}
	}else{
		for (i = pt; i >= 0; i--) cout << ans[i] << " ";
		return 0;
	}
	for (i = pt + 1; i >= 0; i--) cout << ans[i] << " ";
}