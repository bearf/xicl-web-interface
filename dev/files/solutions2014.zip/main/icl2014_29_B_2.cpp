#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <ctime>

using namespace std;

typedef long double ld;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<long long> vll;

#define mp make_pair
#define pb push_back
#define sz(x) ((int)(x).size())
#define EPS (1e-9)
#define INF ((int)1e9)
#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define TASK "text"
const int md = (int)1e9 + 9;
int dp[21][(int)1e6 + 1];
int s[(int)1e6 + 1];
int solve() {
	int n, k;
	if (scanf("%d %d", &n, &k) < 1)
		return 0;
	for (int i = 0; i <= k; i++) {
		for (int j = 0; j <= n; j++) {
			dp[i][j] = 0;
		}
	}	
	for (int j = 1; j <= n; j++) {
		dp[1][j] = 1;
	}
	for (int i = 2; i <= k; i++) {
		s[0] = 0;
		for (int j = 1; j <= n; j++) {
			s[j] = (s[j - 1] + dp[i - 1][j]) % md;
		}
		for (int j = 1; j <= n; j++) {
			dp[i][j] = (s[j - ((j + 1) / 2)] + md) % md;
		}
	}
	cout<<dp[k][n]<<endl;
	return 1;
}

int main() {
#ifdef DEBUG
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif

	int n;
	while (1) {
		if (!solve())
			break;
		#ifdef DEBUG
		eprintf("%.18lf\n", (double)clock() / CLOCKS_PER_SEC);		
		#endif
	}
	return 0;
}
