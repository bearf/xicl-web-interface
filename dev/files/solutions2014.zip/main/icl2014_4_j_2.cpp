#undef NDEBUG
#ifdef ssu1
#define _GLIBCXX_DEBUG
#endif

#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define fore(i, l, r) for(int i = (l); i < (r); ++i)
#define forn(i, n) fore(i, 0, n)
#define fori(i, l, r) fore(i, l, (r) + 1)
#define X first
#define Y second
#define sz(v) ((int)(v).size())
#define pb push_back
#define mp make_pair
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acosl(-1.0);

struct node{
    node* l;
    node* r;
    node* par;
    int cnt, sum, val, pr, id;
    node(){
        l = r = par = 0;
        cnt = sum = val = pr = 0, id = -1;
    }
};

typedef node* tree;

const int NMAX = 410000;
const int BUF_MAX = 2000000;

node buf[BUF_MAX];
int szbuf;

inline int random(){
    return (rand() << 15) ^ rand();
}

inline tree allocate(int val, int id){
    if(szbuf == BUF_MAX)
        throw;
    tree cur = &buf[szbuf++];
    cur->val = val;
    cur->cnt = 1;
    cur->sum = val;
    cur->pr = random();
    cur->id = id;
    return cur;
}

inline int get_cnt(tree t){
    return !t ? 0 : t->cnt;
}

inline int get_sum(tree t){
    return !t ? 0 : t->sum;
}

void upd(tree t){
    if(t){
        t->par = 0;
        t->cnt = get_cnt(t->l) + 1 + get_cnt(t->r);
        t->sum = get_sum(t->l) + t->val + get_sum(t->r);
        if(t->l)
            t->l->par = t;
        if(t->r)
            t->r->par = t;
    }
}

void split(tree t, int k, tree& l, tree& r){
    if(!t){
        l = r = 0;
        return;
    }
    
    int pos = get_cnt(t->l);
    if(pos < k){
        split(t->r, k - pos - 1, t->r, r);
        l = t;
    }else{
        split(t->l, k, l, t->l);
        r = t;
    }
    upd(l);
    upd(r);
}

tree merge(tree l, tree r){
    if(!l || !r)
        return !l ? r : l;
    tree t;
    if(l->pr > r->pr){
        l->r = merge(l->r, r);
        t = l;
    }else{
        r->l = merge(l, r->l);
        t = r;
    }
    upd(t);
    return t;
}

set<int> values;
tree order;
map<int, tree> lfv, rgv;

int getpos(tree t){
    vector<tree> path;
    while(t){
        path.pb(t);
        t = t->par;
    }
    reverse(all(path));
    int ans = 0;
    forn(i, sz(path) - 1){
        if(path[i]->r == path[i + 1])
            ans += get_cnt(path[i]->l) + 1;
    }
    return ans + get_cnt(path.back()->l);
}

int depth(int v){
    assert(values.count(v));
    int pos = getpos(lfv[v]);
    tree lf, rg;
    split(order, pos, lf, rg);
    int ans = get_sum(lf);
    order = merge(lf, rg);
    return ans;
}

int getpar(int v){
    assert(values.count(v) == 0);
    values.insert(v);
    set<int>::iterator it = values.lower_bound(v);
    int left = -INF, lv = -1;
    int right = -INF, rv = -1; 
    if(it != values.begin()){
        set<int>::iterator nit = it;
        nit--;
        left = depth(*nit);
        lv = *nit;
    }
    it++;
    if(it != values.end()){
        right = depth(*it);
        rv = *it;
    }
    assert(lv != -1 || rv != -1);
    values.erase(v);
    return (left < right ? rv : lv);
}

void add(int v){
    if(values.empty()){
        values.insert(v);
        tree L = allocate(1, v);
        tree R = allocate(-1, v);
        lfv[v] = L, rgv[v] = R;
        order = merge(L, R);
        printf("TRUE %d\n", depth(v) + 1);
    }else{
        if(values.count(v)){
            printf("FALSE %d\n", depth(v) + 1);
        }else{
            int to = getpar(v);
            values.insert(v);
            tree L, R;
            
            if(v < to){
                int pos = getpos(lfv[to]);    
                split(order, pos + 1, L, R);
            }else{
                int pos = getpos(rgv[to]);
                split(order, pos, L, R);
            }
            
            tree nL = allocate(+1, v);
            tree nR = allocate(-1, v);
            lfv[v] = nL, rgv[v] = nR;
            order = merge(L, merge(merge(nL, nR), R));
            printf("TRUE %d\n", depth(v) + 1);
        }
    }
}

void fi(int v){
    if(values.count(v)){
        printf("TRUE %d\n", depth(v) + 1);
    }else{
        if(values.empty()){
            printf("FALSE 1\n");
        }else{
            int to = getpar(v);
            printf("FALSE %d\n", depth(to) + 1);
        }
    }
}

void err(tree& r, tree e){
    int pos = getpos(e);
    tree L, R, M;
    split(r, pos + 1, L, R);
    split(L, pos, L, M);
    assert(get_cnt(M) == 1);
    r = merge(L, R);
}

void rem(int v){
    if(values.count(v)){
        int pd = depth(v);
        
        int lfpos = getpos(lfv[v]);
        int rgpos = getpos(rgv[v]);
        
        tree L, R, MID;
        split(order, rgpos + 1, MID, R);
        split(MID, lfpos, L, MID);
        if(rgpos - lfpos == 1){
            order = merge(L, R);
        }else{
            tree L1, R1;
            split(MID, 1, L1, MID);
            split(MID, get_cnt(MID) - 1, MID, R1);
            
            split(MID, 1, L1, MID);
            split(MID, get_cnt(MID) - 1, MID, R1);
             
            if(L1->id == R1->id){
                order = merge(L, merge(L1, merge(MID, merge(R1, R))));
            }else{
				MID = merge(L1, merge(MID, R1));
                set<int>::iterator it = values.upper_bound(v);
                assert(it != values.end());

				pd += depth(*it) + 1;

                err(MID, lfv[*it]);
                err(MID, rgv[*it]);
                MID = merge(lfv[*it], merge(MID, rgv[*it]));
                order = merge(L, merge(MID, R));
            }
        }
        
		printf("TRUE %d\n", pd + 1);
        values.erase(v);
        lfv.erase(v);
        rgv.erase(v);
    }else{
        if(values.empty()){
            printf("FALSE 1\n");
        }else{
            int to = getpar(v);
            printf("FALSE %d\n", depth(to) + 1);
        }
    }
}

int main(){
    //#ifdef ssu1
    //assert(freopen("__input.txt", "r", stdin));
    //#endif
    
    int q;
    scanf("%d", &q);
    
    char bf[100];
    
    forn(qi, q){
        int v;
        scanf(" %s %d ", bf, &v);
        if(bf[0] == 'A')
            add(v);
        else if(bf[0] == 'F')
            fi(v);
        else if(bf[0] == 'R')
            rem(v);
    }
    
    return 0;
}






