#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

int main ()
{
	long long N;
	cin>>N;
	int l=0;
	long long q =1;
	while (q<=N)
	{
		q*=2;
		l++;
	}
	vector <int> A1 (l+1);
	long long r=q-N;
	A1[0]=1;
	for (int i=1;i<l+1;i++)
	{
		if (A1[i-1]!=0)
		{
			A1[i]=0;
		}
		else
		{
			long long z = pow (2.0, (l-i)*1.0);
			if (abs(abs(r)-z)<abs(r))
			{
					if (r<0)
						{
							r+=z;
							A1[i]=1;
						}
						else
						{
							r-=z;
							A1[i]=-1;
						}
			}
		}
	}
	if (r==0)
	{
		for (int i=0;i<l+1;i++)
		{
			cout<<A1[i]<<" "; 
		}
	}
	else
	{
		vector <int> A2 (l);
		r=(q/2)-N;
		A2[0]=1;
		for (int i=1;i<l;i++)
		{
			long long z = pow (2.0, (l-i-1)*1.0);
			if (A2[i-1]!=0)
			{
				A2[i]=0;
			}
			else
			{
				if (abs(abs(r)-z)<abs(r))
				{
						if (r<0)
						{
							r+=z;
							A1[i]=1;
						}
						else
						{
							r-=z;
							A1[i]=-1;
						}
				}
			}
		}
		for(int i=0;i<A2.size();i++)
		{
			cout<<A2[i]<<" ";
		}
	}
	return 0;
}

