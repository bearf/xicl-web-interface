#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <vector>

using namespace std;

#define long long long

long d[21][1111111];

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif
	int n, k;
	cin >> n >> k;
	for (int i = 1; i <= n; i++) {
		d[1][i] = 1;
	}
	for (int j = 2; j <= k; j++) {
		long t = 0;
		int p = 1;
		for (int i = 1; i <= n; i++) {
			if (2*p <= i) {
				t += d[j-1][p];
				p++;
			}
			d[j][i] = t;
			//cerr << d[j][i] << " ";
		}
		//cerr << endl;
	}
	cout << d[k][n] << endl;
	return 0;
}