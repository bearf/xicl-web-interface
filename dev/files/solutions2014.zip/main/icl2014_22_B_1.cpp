#pragma comment(linker, "/STACK:64000000")

#include<iostream>
#include<cstdio>
#include<sstream>

#include<algorithm>
#include<vector>
#include<set>
#include<bitset>
#include<map>
#include<queue>
#include<deque>
#include<stack>

#include<string>
#include<memory.h>
#include<cassert>
#include<time.h>

using namespace std;

#define forn(i, n) for(int i = 0; i < (int)n; i++)
#define forab(i, a, b) for(int i = (int)a; i <= (int)b; i++)
#define fornd(i, n) for(int i = 0; i < (int)n; i--)
#define forabd(i, b, a) for(int i = (int)b; i >= (int)a; i--)
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define _(a, val) memset(a, val, sizeof(a))
#define sz(a) (int)(a).size()

typedef long long lint;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;

const int INF = 1000000000;
const lint LINF = (lint)INF * (lint)INF;
const double eps = 1e-9;

const int nmax = 1000005;
const int MOD = INF + 9;

int n, k;
int sum[nmax], dp[2][nmax];
int cur, nxt;

int getsum(int l, int r)
{
	return (sum[r] - (l > 0 ? sum[l - 1] : 0) + MOD) % MOD;
}

void read()
{
	scanf("%d%d",&n,&k);
}

void fill(int fid)
{
	for (int i = 0; i <= n; i ++)
		dp[fid][i] = 0;
}

void calcsum()
{
	int cur = 0;
	for (int i = 0; i <= n; i ++)
	{
		cur += dp[cur][i];
		if (cur >= MOD) cur -= MOD;
		sum[i] = cur;
	}
}

void solve()
{
	cur = 0;
	nxt = 1;
	for (int i = 1; i <= n; i ++)
		dp[cur][i] = 1;
	calcsum();
	for (int i = 2; i <= k; i ++)
	{
		fill(nxt);
		for (int j = 1; j <= n; j ++)
		{
			int indx = (j + 1) / 2;
			dp[nxt][j] = getsum(0, j - indx);
		}
		swap(cur, nxt);
		calcsum();
	}
	printf("%d\n", dp[cur][n]);
}

int main()
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	read();
	solve();

	return 0;
}