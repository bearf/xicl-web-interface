#include <cstdio>

int main() {
  int n;
  scanf("%d", &n);
  int s = 0;
  int e = 0;
  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++) {
      int x;
      scanf("%d", &x);
      s += x;
      if (x == 0) ++e;
    }
  if (2 * e <= n * n) {
    printf("%d\n", s);
  } else puts("-1");
}