#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

#define f first
#define s second

const int maxN = 200002;
const int mx = 1e9;

pii a[maxN];
int b[maxN];
int n;
int ans;

int main() {

    cin >> n;
	for (int i = 0; i < n; i++) {
		scanf("%d", &a[i].f);
		a[i].s = i;
	}
	a[n].f = mx + 1;
	a[n].s = n;
	sort(a, a + n + 1);

	b[n] = 0;
	b[n - 1] = 1;
	for (int i = n - 2; i >= 0; i--) {
		if (a[i].s < a[i + 1].s)
			b[i] = b[i + 1] + 1;
		else
			b[i] = 1;
	}

	int ls = n;
	for (int i = n - 1; i >= 0; i--) {
		if (a[i].f != a[i + 1].f) {
			int cur = 0;
			for (int j = i + 1; j < ls; j++)
				if (a[j].s < a[ls].s)
					cur++;
			ans = max(ans, cur + b[ls]);
			ls = i + 1;
		}		
	}
	int cur = 0;
	for (int j = 0; j < ls; j++)
		if (a[j].s < a[ls].s)
			cur++;
	ans = max(ans, cur + b[ls]);

	cout << n - ans << endl;

	return 0;
}
