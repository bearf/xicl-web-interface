#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cassert>
#include <ctime>
#include <memory.h>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <complex>
#include <list>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef complex <ld> point;

#define pb push_back
#define mp make_pair
#define fi first
#define se second

#define INF 1000000001
#define INFL 1000000000000000001ll
#define NAME "f"

int a[1000001];
int b[1000001];

int main() {
    #ifdef _GEANY
    assert(freopen(NAME ".in", "r", stdin));
    #endif // _GEANY
    int n;
    cin >> n;
    for (int i = 0; i < (1 << n); ++i)
        a[i] = i ^ (i >> 1);
    a[(1 << n)] = a[0];
    for (int i = 0; i < (1 << n); ++i)
        for (int j = 0; j < 20; ++j)
            if ((a[i] ^ a[i + 1] ^ (1 << j)) == 0)
                b[i] = j;
    cout << n * (1 << n) << endl;
    for (int rot = 0; rot < n; ++rot) {
        for (int i = 0; i < (1 << n); ++i) {
            cout << (b[i] + rot) % n + 1 << ' ';
        }
    }
}
