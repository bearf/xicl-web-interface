#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <vector>

using namespace std;

int n, m, q[100005], up[100005], dep[100005], tim[100005], mn[100005];

vector <int> g[100005];

void load() {
	cin >> n;

	for (int i = 0, a, b;i < n - 1;i++) {
		scanf ("%d%d", &a, &b);
		a--, b--;

		g[a].push_back (b);
		g[b].push_back (a);
	}

	memset (tim, -1, sizeof (tim));
	cin >> m;
	for (int i = 0;i < m;i++) {
		int a;
		scanf ("%d", &a);
		a--;
		q[i] = a;
		tim[a] = i;
	}
}

void dfs (int v, int p, int h) {
	dep[v] = h;

	mn[v] = tim[v];
	for (int i = 0;i < (int)g[v].size();i++) {
		int u = g[v][i];
		if (u == p) continue;

		dfs (u, v, h + 1);

		if (mn[u] != -1 && (mn[v] == -1 || mn[u] < mn[v])) {
			mn[v] = mn[u];
		}
	}
}

void go (int v, int p, int x, int hx) {
	int mc = 1 << 30;
	for (int i = 0;i < (int)g[v].size();i++) {
		int u = g[v][i];
		if (u == p) continue;

		if (mn[u] != -1 && mn[u] < mc) {
			mc = mn[u];
		}
	}

	if (mc < tim[v]) {
		up[v] = 0;
	} else {
		up[v] = hx;
	}

	for (int i = 0;i < (int)g[v].size();i++) {
		int u = g[v][i];
		if (u == p) continue;

		if (mn[u] == mc) {
			if (tim[v] != -1 && tim[v] < mn[u]) {
				go (u, v, tim[v], 1);
			} else {
				go (u, v, x, hx + 1);
			}
		} else {
			go (u, v, mc, 1);
		}
	}
}

void solve() {
	dfs (0, -1, 0);
	go (0, -1, 0, 0);

	/*for (int i = 0;i < n;i++) {
		cerr << mn[i] << " " << up[i] << endl;
	}*/

	long long ans = 0;
	for (int i = 0;i < m;i++) {
		if (i > 0) {
			cout << " ";
		}
		ans += up[q[i]] * 2;
		cout << ans - dep[q[i]];
	}
	cout << endl;
}

int main () {
	#ifdef LOCAL
		freopen ("a.in", "r", stdin);
	#endif

	load();
	solve();

	return 0;
}
