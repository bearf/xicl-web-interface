#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

const int maxK = (1 << 18) * 20;


int a[maxK], b[maxK];
int c[1 << 18];
int n;

void wr(int x) {
    for (int i = 0; i < x; i++)
        cout << b[i] << ' ';
    cout << endl;

}

int main() {

    cin >> n;
    int ls = 2;
    a[0] = 1;
    a[1] = 1;
    for (int i = 2; i <= n; i++) {
        int cw = 0;
        int ms = 0;
        for (int j = 0; j < (1 << i); j++)
            c[j] = 0;
        bool bl = false;
        for (int j = 0; j < ls; j++) {
            //cout << cw << endl;
            ms ^= (1 << (a[j] - 1));
            //cout << ms << endl;
            b[cw++] = a[j];
            //cout << c[ms] << endl;
            if (c[ms] == 0) {
                b[cw++] = i;
                //if (i == 3)
                //    wr(cw);
                if (!bl) {
                    //cout << ls << endl;
                    for (int t = 0; t < ls; t++)
                        b[cw++] = a[t];
                    bl = true;
                    //if (i == 3)
                    //    wr(cw);
                }
                b[cw++] = i;
                c[ms] = 1;
            }
        }
        //b[cw++] = a[ls - 1];
        /*b[cw++] = i;
        /*for (int j = 0; j < ls; j++)
            b[cw++] = a[j];
        b[cw++] = i;
        */
        ls = cw;
        for (int i = 0; i < ls; i++)
            a[i] = b[i];
    }

    printf("%d\n", ls);
    for (int i = 0; i < ls; i++)
        printf("%d ", a[i]);


	return 0;
}
