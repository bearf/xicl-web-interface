#include<stdio.h>
//#include<iostream>
#include<algorithm>
#include<cstring>
#include<set>
#define F first
#define S second
#define mp make_pair
#define N 888888
#define CC(x) printf("%d\n",x) 

using namespace std;

int n, a[N];
pair<int, int> q[N];
int p1[N], p2[N], u1[N], u2[N];
int mi[N], ans[N];
set<pair<int, int> > S[N];
set<pair<int, int> >::iterator it;

int best(int x, int y) {
	if (x == -1) return y;
	if (y == -1) return x;
	if (a[x] < a[y]) return x;
	if (a[x] > a[y]) return y;
	if (x > y) return x;
	return y;
}

void update(int pos) {
	S[pos].clear();
	S[pos].insert(S[pos + pos].begin(), S[pos + pos].end());
	S[pos].insert(S[pos + pos + 1].begin(), S[pos + pos + 1].end());
	mi[pos] = min(mi[pos + pos], mi[pos + pos + 1]);
	ans[pos] = best(ans[pos + pos], ans[pos + pos + 1]);
	it = S[pos + pos].lower_bound(mp(mi[pos + pos + 1], (int)1e9));
	if (it != S[pos + pos].end()) {
		ans[pos] = best(ans[pos], -(*it).S);
	}
}

void update(int pos, int x) {
	S[pos].erase(mp(a[x], -x));
	mi[pos] = min(mi[pos + pos], mi[pos + pos + 1]);
	ans[pos] = best(ans[pos + pos], ans[pos + pos + 1]);
	it = S[pos + pos].lower_bound(mp(mi[pos + pos + 1], (int)1e9));
	if (it != S[pos + pos].end()) {
		ans[pos] = best(ans[pos], -(*it).S);
	}
}

void init(int pos, int l, int r) {
	if (l == r) {
		S[pos].clear();	
		S[pos].insert(mp(a[l], -l));
		mi[pos] = a[l];
		ans[pos] = - 1;
		return;
	}
	init(pos + pos, l, (l + r) / 2);
	init(pos + pos + 1, (l + r) / 2 + 1, r);
	update(pos);
}

void modif(int pos, int l, int r, int x) {
	if (x < l || x > r) return;
	if (l == r) {
		S[pos].clear();	
		mi[pos] = 1e9;
		ans[pos] = - 1;
		return;
	}
	modif(pos + pos, l, (l + r) / 2, x);
	modif(pos + pos + 1, (l + r) / 2 + 1, r, x);
	update(pos, x);
}

int main() {
//	freopen("1.in", "r", stdin);
//	freopen("1.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 0; i < n; i++) scanf("%d", &a[i]);
	for (int i = 0; i < n; i++) q[i] = mp(a[i], -i);
	sort(q, q + n);
	for (int i = 0; i < n; i++) {
		p1[i] = -q[i].S;
		u1[-q[i].S] = i;
	}
	for (int i = 0; i < n; i++) q[i] = mp(-a[i], i);
	sort(q, q + n);
	for (int i = 0; i < n; i++) {
		p2[i] = q[i].S;
		u2[q[i].S] = i;
	}
	int ret = 1e9;
	init(1, 0, n - 1);
	for (int i = 0; i < n; i++) {
		int x = ans[1];
		if (x == -1) {
			ret = min(ret, i);
		} else {
			ret = min(ret, i + u2[x] + 1);
		}
		modif(1, 0, n - 1, p1[i]);
	}
	printf("%d\n", ret);
	return 0;
}