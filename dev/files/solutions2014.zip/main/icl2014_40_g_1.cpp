#pragma comment(linker, "/STACK:268435456")

#include <iostream>
#include <iomanip>

#include <vector>
#include <string>
#include <deque>
#include <queue>
#include <set>
#include <map>

#include <algorithm>

#include <cstdio>
#include <cstdlib>
#include <complex>
#include <ctime>
#include <cstring>
#include <cassert>

using namespace std;

#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define ford(i,n) for (int i = int(n) - 1; i >= 0; --i)

#define pb push_back
#define mp make_pair
#define fs first
#define sc second
#define all(a) (a).begin(), (a).end()
#define sz(a) int((a).size())

#ifdef SG
    #define debug(x) cerr << #x << ": " << (x) << endl
#else
    #define debug(x)
#endif

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

template <typename T>
ostream & operator << (ostream & out, vector<T> const & a) {
    out << "[";
    for (int i = 0; i < sz(a); ++i) {
        if (i != 0) {
            out << ", ";
        }
        out << a[i];
    }
    out << "]";
    return out;
}

template <typename T1, typename T2>
ostream & operator << (ostream & out, pair<T1, T2> const & p) {
    out << "(" << p.fs << ", " << p.sc << ")";
    return out;
}

struct Data {
    int n;
    vector <int> a[100100];
    int m;
    vector <int> z;
    int ans[100100];

    bool read () {
        if (scanf ("%d", &n) != 1){
            return false;
        }
        forn(i, n - 1){
            int t1, t2;
            scanf ("%d %d", &t1, &t2);
            t1 --;
            t2 --;
            a[t1].pb(t2);
            a[t2].pb(t1);
        }                       
        cin >> m;
        z.resize(m);
        forn(i, m){
            scanf ("%d", &z[i]);
            z[i] --;
        }
        return true;
    }

    void write () {
        forn(i, m){
            cout << ans[i] << ' ';
        }
        cout << endl;
    }

    virtual void solve () {
    }

    virtual void clear () {
        *this = Data();
    }
};

struct Solution: Data {
    int h[100100];
    int p[100100];
    bool use[100100];
    int kol;

    void dfs(int v, int pr, int h1){
        h[v] = h1;
        p[v] = pr;
        forn(i, a[v].size()){
            int to = a[v][i];
            if (to == pr) continue;
            dfs(to, v, h1 + 1);
        }
    }

    int f(int v){
        int kol1 = 0;
        
        while (!use[v]){
            use[v] = 1;
            v = p[v];
            kol1 ++;
        }
        return kol1;
    }

    void solve () {
        memset(use, false, sizeof(use));
        dfs(0, -1, 0);
        use[0] = true;
        kol = 0;
        forn(i, m){
            kol += f(z[i]);
            ans[i] = 2 * kol - h[z[i]];            
        }

    }

    Solution (Data d = Data()): Data(d) {}

    void clear () {
        *this = Solution();
    }
};

Solution sol;
int main () {
#ifdef SG
    freopen("input.txt", "r", stdin);
//    freopen("", "w", stdout);
    while (sol.read()) {
        sol.solve();
        sol.write();
        sol.clear();
    }
#else
//    freopen("", "r", stdin);
//    freopen("", "w", stdout);
    sol.read();
    sol.solve();
    sol.write();    
#endif

    return 0;
}
