#include<iostream>

using namespace std;

int a[1000];

int main()
{
	long long n, f = 2, s = 4;
	int k = 0;
	cin >> n;

	while (n > 1)
	{
		if (n % f == 0)
		{
			a[k] = 0;
			k++;
			n = n / f;
		}
		else
		{
			if (n % s == 1)
			{
				a[k] = 1;
				a[k + 1] = 0;
				n /= s;
			}
			else
			{
				a[k] = -1;
				a[k + 1] = 0;
				n++;
				n /= s;
			}

			k += 2;
		}
	}

	a[k] = 1;

	for (int i = k; i >= 0; i--)
	{
		cout << a[i] << ' ';
	}
	return 0;
}