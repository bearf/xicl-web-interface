#include <cstdio>

int main() {
  int n;
  scanf("%d", &n);
  printf("%d\n", (1 << n) * n);
  for (int j = 0; j < n; j++) {
    for (int i = 0; i < 1 << n; i++) {
      int x = (i ^ (i >> 1));
      int e = (i + 1) % (1 << n);
      x ^= (e ^ (e >> 1));
      int c = 0;
//      printf("\nx = %d\n", x);
      while (x > 0) {
        x /= 2;
        c++;
      }
//      printf("c = %d\n", (c + j) % n);
      printf("%d ", (c + j) % n + 1);
    }
  }
  puts("");
}