#include <iostream>
#include <algorithm>
#include <vector>
#include<cstdio>
using namespace std;

vector<int> build(vector<int> v, int n)
{
	vector<int> res;
	if (n == 1)
	{
		res.push_back(1);
		res.push_back(1);
		return res;
	}

	for (int i = 0; i < v.size(); i++)
	{
		res.push_back(v[i]);
		res.push_back(n);
	}
	for (int i = 0; i < v.size(); i++)
	{
		res.push_back(n);
		res.push_back(v[i]);
	}
	return res;
}

bool used[10000][20];
bool checkAns(vector<int> v, int n)
{
	int all = (1 << n) - 1;

	int mask = 0, sw = 0;
	for (int i = 0; i < v.size(); i++)
	{
		sw = v[i] - 1;
		mask = (mask ^ (1 << sw));
		used[mask][sw] = 1;
	}

	for (mask = 0; mask <= all; mask++)
		for (sw = 0; sw < n; sw++)
			if (!used[mask][sw])
				return 0;

	return 1;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	vector<int> ans;
	int n;
	//scanf("%d", &n);
	n = 15;
	for (int i = 1; i <= n; i++)
		ans = build(ans, i);

	//cout << checkAns(ans, n) << endl;

	int m = ans.size();
	printf("%d\n", m);
	for (int i = 0; i <m; i++)
		printf("%d ", ans[i]);

}