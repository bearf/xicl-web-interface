#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;

const int con = 62;
int n;

int main() {

	cin >> n;
    int s = 0;int k = 0;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n ; j++) {
            int x;
            cin >> x;
            s += x;
            if (x == 0)
                k++;
        }

    if (k > (n * n) / 2)
        cout << -1;
    else
        cout << s;



	return 0;
}
