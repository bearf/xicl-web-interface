#include <stdio.h>

using namespace std;

int main(){
	FILE* fIn;
	FILE *fOut;
	fIn  = fopen("stdin", "r");
	fOut = fopen("stdout", "w");
	
	
	int n, i, j, t, cnt=0, s=0;

	fscanf(fIn, "%d", &n);
	int field[14][14];

	for (i=0; i<n; i++){
		for (j=0; j<n; j++){
			field[i][j]=0;
			fscanf(fIn, "%d", &t);
			field[i][j]=t;
			if (field[i][j]==0) cnt++;
			s+=field[i][j];
		}
	}

	if (cnt<(n*n/2)) {
		fprintf(fOut, "%d", s);
	} else {
		fprintf(fOut, "-1");
	}

	return 0;
}