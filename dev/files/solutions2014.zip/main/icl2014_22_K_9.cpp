#pragma comment(linker, "/STACK:64000000")

#include<iostream>
#include<cstdio>
#include<sstream>

#include<algorithm>
#include<vector>
#include<set>
#include<bitset>
#include<map>
#include<queue>
#include<deque>
#include<stack>

#include<string>
#include<memory.h>
#include<cassert>
#include<time.h>

using namespace std;

#define forn(i, n) for(int i = 0; i < (int)n; i++)
#define forab(i, a, b) for(int i = (int)a; i <= (int)b; i++)
#define fornd(i, n) for(int i = 0; i < (int)n; i--)
#define forabd(i, b, a) for(int i = (int)b; i >= (int)a; i--)
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define _(a, val) memset(a, val, sizeof(a))
#define sz(a) (int)(a).size()

typedef long long lint;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;

const int INF = 1000000000;
const lint LINF = (lint)INF * (lint)INF;
const double eps = 1e-9;

bool eq(double a,double b)
{
	return fabs(a - b) < eps;
}

double sq(double a)
{
	return a * a;
}

struct Vec
{
	double x, y;
	Vec(){}
	Vec(double _x, double _y) { x = _x; y = _y; }
	Vec operator + (Vec oth) { return Vec(x + oth.x, y + oth.y); }
	Vec operator - (Vec oth) { return Vec(x - oth.x, y - oth.y); }
	Vec operator * (double k) { return Vec(x * k, y * k); }
	Vec operator / (double k) { return Vec(x / k, y / k); }
	double length() { return sqrt(sq(x) + sq(y)); }
	void read() { scanf("%lf%lf",&x,&y); }
	Vec norm() { return Vec(x / length(), y / length()); }
	bool operator == (const Vec &oth) const
	{
		return eq(x, oth.x) && eq(y, oth.y);
	}
};

struct Line
{
	Vec from, to;
	double A, B, C;

	void read()
	{
		from.read();
		to.read();
		A = from.y - to.y;
		B = to.x - from.x;
		C = - (A * from.x + B * from.y);

		double zn = sqrt(sq(A) + sq(B));
		A /= zn;
		B /= zn;
		C /= zn;
	}
};

const int nmax = 10005;
Line a[nmax];
int n;

void read()
{
	scanf("%d",&n);
	for (int i = 0; i < n; i ++)
		a[i].read();
	a[n] = a[0];
}

Vec mov(Vec cur, Line l)
{
	double dist = l.A * cur.x + l.B * cur.y + l.C;
	cur = cur - Vec(l.A, l.B) * dist;
	return cur;
}

double fun(Vec p)
{
	Vec cur = p;
	for (int i = 1; i <= n; i ++)
	{
		cur = mov(cur, a[i]);
	}
	return (cur - p).length();
}

void solve()
{
	Vec l, r, m1, m2, O, dir = Vec(-a[0].B, a[0].A);
	if (eq(a[0].B, 0.0))
		O = Vec( -a[0].C / a[0].A, 0.0);
	else
		O = Vec(0, - a[0].C / a[0].B);
	const double magic = 1000000000.0;
	l = O - dir * magic;
	r = O + dir * magic;
	for (int it = 0; it < 1000; it ++)
	{
		m1 = l + (r - l) / 3.;
		m2 = r - (r - l) / 3.;
		if (fun(m1) > fun(m2))
			l = m1;
		else
			r = m2;
	}
	if (!eq(fun(l), 0.0))
		printf("-1\n");
	else
	{
		if (eq(l.x, 0.0)) l.x = 0;
		if (eq(l.x, 0.0)) l.x = 0;
		printf("%.8lf %.8lf\n",	l.x, l.y);
	}
}

int main()
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	read();
	solve();

	return 0;
}