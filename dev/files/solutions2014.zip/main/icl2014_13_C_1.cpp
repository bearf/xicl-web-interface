#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
//ifstream cin ("input.txt");
//ofstream cout ("output.txt");

vector <int> bin;

long long n;

void to_bin(){
	while(n > 0){
		bin.push_back(n % 2);
		n /= 2;
	}
	reverse(bin.begin(), bin.end());
}
int main(){
	cin >> n;
	to_bin();
	for(int i = 0; i < bin.size(); i++){
		cout << bin[i] << ' ';
	}
}