#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <queue>


const int maxn = 100146;
const int infin = 1000000146;


using namespace std;


vector<pair<int, int> > v[maxn];
vector<pair<int, int> > g[maxn];
queue<int> q[maxn];
int n;
int dp[maxn];


void bfs(int s)
{
	for(int i = 0; i <= n; i++)
	{
		dp[i] = infin;
	}
	dp[s] = 0;
	q[0].push(s);
	for(int i = 0; i <= n; i++)
	{
		while(!q[i].empty())
		{
			int cur = q[i].front();
			q[i].pop();
			if(dp[cur] != i)
				continue;
			for(int j = 0; j < v[cur].size(); j++)
			{
				int to = v[cur][j].first;
				int len = v[cur][j].second;
				if(dp[to] > dp[cur] + len)
				{
					dp[to] = dp[cur] + len;
					q[dp[to]].push(to);
				}
			}
		}
	}
}


void addEdge(int from, int to, int cost)
{
	v[from].push_back(make_pair(to, cost));
	g[to].push_back(make_pair(from, cost));
}


bool used[maxn];
vector<vector<int> > paths;
vector<int> cur;


void mark(int s)
{
	used[s] = true;
	for(int i = 0; i < g[s].size(); i++)
	{
		int to = g[s][i].first;
		int cost = g[s][i].second;
		if(!used[to] && dp[to] + cost == dp[s])
		{
			mark(to);
		}
	}
}


void buildPaths(int e, int t)
{
	if(e == t)
	{
		paths.push_back(cur);
		return;
	}
	for(int i = 0; i < v[e].size(); i++)
	{
		int to = v[e][i].first;
		int cost = v[e][i].second;
		if(used[to] && dp[to] == dp[e] + cost)
		{
			for(int j = 0; j < cost; j++)
				cur.push_back(2 * e + 1);
			buildPaths(to, t);
			for(int j = 0; j < cost; j++)
				cur.pop_back();
		}
	}
}


int main()
{
	scanf("%d", &n);
	for(int i = 0; i <= n; i++)
	{
		int step = 2 * i + 1;
		for(int j = 1; i + j * step <= n; j++)
		{
			addEdge(i, i + j * step, j);
		}
		reverse(v[i].begin(), v[i].end());
	}
	/*for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < v[i].size(); j++)
		{
			printf("%d %d: %d\n", i, v[i][j].first, v[i][j].second);
		}
	}*/
	bfs(0);
	mark(n);
	buildPaths(0, n);
	printf("%d %d\n", paths.size(), dp[n]);
	for(int i = 0; i < paths.size(); i++)
	{
		for(int j = 0; j < paths[i].size(); j++)
			printf("%d ", paths[i][j]);
		printf("\n");
	}
}