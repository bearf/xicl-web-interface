#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
using namespace std;

const int MAXN = 200500;
const int SIZE = (1 << 18);
const int INF = (int)1e9;

struct SegmentTree
{
	pair<int, int> maxima[2 * SIZE];

	void build(int a[], int n)
	{
		for (int i = 0; i < n; i++)
			maxima[SIZE + i] = make_pair(a[i], i);
		for (int i = SIZE - 1; i > 0; i--)
			maxima[i] = max(maxima[2 * i], maxima[2 * i + 1]);
	}

	void set_value(int v, int value)
	{
		v += SIZE;
		maxima[v] = make_pair(value, v);

		while (v > 1)
		{
			int p = v / 2;
			maxima[p] = max(maxima[2 * p], maxima[2 * p + 1]);
			v = p;
		}
	}

	int get_first_bigger(int v, int a, int b, int value)
	{
		if (a == b)
		{
			if (value >= maxima[v].first)
				return INF;
			return maxima[v].second;
		}

		int m = (a + b) / 2;
		if (maxima[2 * v].first > value)
			return get_first_bigger(2 * v, a, m, value);
		if (maxima[2 * v + 1].first > value)
			return get_first_bigger(2 * v + 1, m + 1, b, value);
		return INF;
	}

	int get_first_bigger(int value)
	{
		return get_first_bigger(1, 0, SIZE - 1, value);
	}
};

int n;
int a[MAXN];
int right_list[MAXN];
int left_list[MAXN];
int left_less[MAXN];
SegmentTree tree;
map<int, int> value_compress;
vector<int> positions[MAXN];
bool killed_position[MAXN];

bool cmp_right(int x, int y)
{
	if (a[x] == a[y])
		return x < y;
	return a[x] > a[y];
}

bool cmp_left(int x, int y)
{
	if (a[x] == a[y])
		return x > y;
	return a[x] > a[y];
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		scanf("%d", &a[i]);

	tree.build(a, n);

	for (int i = 0; i < n; i++)
	{
		if (value_compress.count(a[i]) == 0)
		{
			int sz = value_compress.size();
			value_compress[a[i]] = sz;
		}
		positions[value_compress[a[i]]].push_back(i);
	}

	for (int i = 0; i < n; i++)
		left_list[i] = right_list[i] = i;
	sort(right_list, right_list + n, cmp_right);
	sort(left_list, left_list + n, cmp_left);

	int cnt_less = 0;
	int cur_pos = n - 1;
	for (int i = n - 1; i >= 0; i--)
	{
		if (a[left_list[i]] != a[left_list[cur_pos]])
		{
			cnt_less += cur_pos - i;
			cur_pos = i;
		}
		left_less[i] = cnt_less;
	}

	int best = INF;
	int left_list_ptr = 0;

	for (int right_taken = 0; right_taken <= n; right_taken++)
	{
		while (left_list_ptr < n)
		{
			int pos = left_list[left_list_ptr];
			if (killed_position[pos])
				left_list_ptr++;
			else if (tree.get_first_bigger(a[pos]) >= pos)
				left_list_ptr++;
			else
				break;
		}

		int left_moving_cost = 0;
		if (left_list_ptr < n)
		{
			int R = left_list[left_list_ptr];
			int L = tree.get_first_bigger(a[R]);
			int pos_ind = value_compress[a[R]];
			int L1 = lower_bound(positions[pos_ind].begin(), positions[pos_ind].end(), L) - positions[pos_ind].begin();
			int R1 = upper_bound(positions[pos_ind].begin(), positions[pos_ind].end(), R) - positions[pos_ind].begin();
			left_moving_cost = R1 - L1 + left_less[left_list_ptr];
		}

		best = min(best, left_moving_cost + right_taken);

		if (right_taken < n)
		{
			tree.set_value(right_list[right_taken], 0);
			killed_position[right_list[right_taken]] = true;
		}
	}

	printf("%d\n", best);

	return 0;
}