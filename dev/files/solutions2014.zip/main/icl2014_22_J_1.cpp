#pragma comment(linker, "/STACK:64000000")

#include<iostream>
#include<cstdio>
#include<sstream>

#include<algorithm>
#include<vector>
#include<set>
#include<bitset>
#include<map>
#include<queue>
#include<deque>
#include<stack>

#include<string>
#include<memory.h>
#include<cassert>
#include<time.h>

using namespace std;

#define forn(i, n) for(int i = 0; i < (int)n; i++)
#define forab(i, a, b) for(int i = (int)a; i <= (int)b; i++)
#define fornd(i, n) for(int i = 0; i < (int)n; i--)
#define forabd(i, b, a) for(int i = (int)b; i >= (int)a; i--)
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define _(a, val) memset(a, val, sizeof(a))
#define sz(a) (int)(a).size()

typedef long long lint;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;

const int INF = 1000000000;
const lint LINF = (lint)INF * (lint)INF;
const double eps = 1e-9;

const int nmax = 100005 * 3;

struct Node
{
	Node * l, * r, * p;
	int val, pr, cnt, sum;
	Node(){}
	Node(int x)
	{
		pr = rand();
		l = r = p = 0;
		val = x;
		cnt = 1;
		sum = val;
	}
};
Node mem[nmax];
int curFree;
typedef Node * tree;

tree allocate(int x)
{
	mem[curFree] = Node(x);
	return &mem[curFree++];
}

struct Tree
{
	tree root;

	int getsum(tree t)
	{
		return t ? t->sum : 0;
	}

	int getcnt(tree t)
	{
		return t ? t->cnt : 0;
	}

	void upd(tree t)
	{
		if (t)
		{
			if (t->l) t->l->p = t;
			if (t->r) t->r->p = t;
			t->cnt = 1 + getcnt(t->l) + getcnt(t->r);
			t->sum = t->val + getsum(t->l) + getsum(t->r);
		}
	}

	tree merge(tree l, tree r)
	{
		upd(l);
		upd(r);
		if (!l || !r) return l ? l : r;
		tree t;
		if (l->pr > r->pr)
			l->r = merge(l->r, r), t = l;
		else
			r->l = merge(l, r->l), t = r;
		upd(t);
		return t;
	}

	void split(tree t, int pos, tree &l, tree &r)
	{
		l = r = 0;
		upd(t);
		if (!t) return;
		t->p = 0;
		if (getcnt(t->l) < pos)
			split(t->r, pos - 1 - getcnt(t->l), t->r, r), l = t;
		else
			split(t->l, pos, l, t->l), r = t;
		upd(l);
		upd(r);
	}

	tree insert(int val, int pos)
	{
		tree t1, t2, nt = allocate(val);
		split(root, pos, t1, t2);
		root = merge(nt, t2);
		root = merge(t1, root);
		return nt;
	}

	void erase(int pos)
	{
		tree t1, t2, t3;
		split(root, pos, t1, t2);
		split(t2, 1, t2, t3);
		root = merge(t1, t3);
	}

	int getindx(tree t)
	{
		int ret = 0;
		while (1)
		{
			ret += getcnt(t->l);
			while (t->p != 0 && t->p->l == t) t = t->p;
			if (t->p == 0) break;
			t = t->p;
			ret++;
		}
		return ret;
	}

	void erase(tree t)
	{
		int indx = getindx(t);
		erase(indx);
	}

	int getsum(int l, int r)
	{
		tree t1, t2, t3;
		split(root, l, t1, t2);
		split(t2, r - l + 1, t2, t3);
		int ret = getsum(t2);
		root = merge(t2, t3);
		root = merge(t1, root);
		return ret;
	}

	void rec(tree t)
	{
		if (!t) return;
		rec(t->l);
		printf("(%d) ", t->val);
		rec(t->r);
	}

	void print()
	{
		rec(root);
		printf("\n");
	}
}T;

set < int > q;
char s[15];
int n;
map < int, tree > x, xl, xr;

int getPredElement(int val)
{
	set < int > ::iterator it = q.upper_bound(val);
	if (it == q.begin()) return -1;
	it--;
	return *it;
}

int getNextElement(int val)
{
	set < int > ::iterator it = q.upper_bound(val);
	if (it == q.end()) return -1;
	return *it;
}

void insert_val(int pos, int val)
{
	q.insert(val);
	tree r = T.insert(-1, pos);
	tree el = T.insert(0, pos);
	tree l = T.insert(+1, pos);

	x[val] = el;
	xl[val] = l;
	xr[val] = r;
}

void kill_val(int val)
{
	T.erase(x[val]);
	T.erase(xl[val]);
	T.erase(xr[val]);

	x.erase(val);
	xl.erase(val);
	xr.erase(val);
	q.erase(val);
}

int get_child(int a, int b)
{
	if (a == -1) return b;
	if (T.getindx(x[a]) + 1 == T.getindx(xr[a]))
		return a;
	return b;
}

int get_depth(int val)
{
	if (val == -1) return 1;
	return T.getsum(0, T.getindx(x[val]));
}

bool is_single_child(int val)
{
	int a = T.getindx(xl[val]);
	int pos = T.getindx(x[val]);
	int b = T.getindx(xr[val]);
	return a + 1 == pos || pos == b - 1;
}

void reassign(int newVal, int oldVal)
{
	kill_val(newVal);

	x[newVal] = x[oldVal];
	xl[newVal] = xl[oldVal];
	xr[newVal] = xr[oldVal];

	x.erase(oldVal);
	xl.erase(oldVal);
	xr.erase(oldVal);
	q.erase(oldVal);

	q.insert(newVal);
}

void solve()
{
	scanf("%d",&n);
	for (int i = 0; i < n; i ++)
	{
		int val;
		scanf("%s%d",s,&val);
		if (s[0] == 'A')
		{
			if (q.count(val))
			{
				printf("FALSE ");
				printf("%d\n", get_depth(val));
			}
			else
			{
				printf("TRUE ");
				int a = getPredElement(val), b = getNextElement(val);
				if (get_child(a, b) == a && a != -1)
				{
					int indx = T.getindx(x[a]);
					insert_val(indx + 1, val);
				}
				else
				if (b != -1)
				{
					int indx = T.getindx(x[b]);
					insert_val(indx, val);
				}
				else
				{
					insert_val(0, val);
				}
				printf("%d\n", get_depth(val));
			}
		}
		else
		if (s[0] == 'F')
		{
			if (q.count(val))
			{
				printf("TRUE ");
				printf("%d\n", get_depth(val));
			}
			else
			{
				printf("FALSE ");
				int a = getPredElement(val), b = getNextElement(val);
				printf("%d\n", get_depth(get_child(a,b)));
			}
		}
		else
		if (s[0] == 'R')
		{
			if (q.count(val))
			{
				printf("TRUE ");
				
				if (is_single_child(val))
				{
					printf("%d\n", get_depth(val));
					kill_val(val);
				}
				else
				{
					int nxt = getNextElement(val);
					printf("%d\n", get_depth(nxt));
					
					reassign(nxt, val);
				}
			}
			else
			{
				printf("FALSE ");
				int a = getPredElement(val), b = getNextElement(val);
				printf("%d\n", get_depth(get_child(a,b)));
			}
		}

		//T.print();
	}
}

int main()
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	solve();

	return 0;
}