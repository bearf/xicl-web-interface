#include <iostream>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
using namespace std;

#if LOCAL
	#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
	#define eprintf(...) 42;
#endif

const int MAXN = 222222;

int n;
int a[MAXN];
int fst[MAXN];
int nxt[MAXN];
int cnt[MAXN];
int cnt2[MAXN];
int lst[MAXN];
int dp[MAXN];

int main() {
#ifdef LOCAL
	freopen("e.in", "r", stdin);
#endif
	scanf("%d", &n);
	vector <int> all;
	for (int i = 0; i < n; i++) {
		scanf("%d", &a[i]);
		all.push_back(a[i]);
	}
	sort(all.begin(), all.end());
	all.erase(unique(all.begin(), all.end()), all.end());
	for (int i = 0; i < (int)all.size(); i++) {
		lst[i] = -1;
	}
	for (int i = 0; i < n; i++) {
		a[i] = lower_bound(all.begin(), all.end(), a[i]) - all.begin();
		cnt2[a[i]]++;
	}
	for (int i = n - 1; i >= 0; i--) {
		nxt[i] = lst[a[i]];
		lst[a[i]] = i;
		fst[a[i]] = i;
	}
	int ans = 0;
	for (int i = n - 1; i >= 0; i--) {
		int x = a[i];
		if (nxt[x] == -1)  {
			// last
			if (cnt[x + 1] == cnt2[x + 1]) {
				dp[i] = 1 + dp[fst[x + 1]];
			} else {
				dp[i] = cnt[x + 1] + 1;
			}
		} else {
			// not last
			dp[i] = 1 + dp[nxt[i]];
		}
		cnt[x]++;
		ans = max(ans, dp[i]);
	}
	printf("%d\n", n - ans);
	return 0;
}