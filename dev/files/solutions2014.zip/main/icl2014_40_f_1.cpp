#pragma comment(linker, "/STACK:268435456")

#include <iostream>
#include <iomanip>

#include <vector>
#include <string>
#include <deque>
#include <queue>
#include <set>
#include <map>

#include <algorithm>

#include <cstdio>
#include <cstdlib>
#include <complex>
#include <ctime>
#include <cstring>
#include <cassert>

using namespace std;

#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define ford(i,n) for (int i = int(n) - 1; i >= 0; --i)

#define pb push_back
#define mp make_pair
#define fs first
#define sc second
#define all(a) (a).begin(), (a).end()
#define sz(a) int((a).size())

#ifdef SG
    #define debug(x) cerr << #x << ": " << (x) << endl
#else
    #define debug(x)
#endif

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

template <typename T>
ostream & operator << (ostream & out, vector<T> const & a) {
    out << "[";
    for (int i = 0; i < sz(a); ++i) {
        if (i != 0) {
            out << ", ";
        }
        out << a[i];
    }
    out << "]";
    return out;
}

template <typename T1, typename T2>
ostream & operator << (ostream & out, pair<T1, T2> const & p) {
    out << "(" << p.fs << ", " << p.sc << ")";
    return out;
}

const int N = 18;

struct Data {
    int n;
    bool read () {
        return cin >> n;
    }

    vector<int> ans;

    void write () {
        cout << ans.size() << endl;
        forn (i, ans.size()) {
            if (i) {
                printf(" ");
            }
            printf("%d", ans[i] + 1);
        }
        puts("");
    }

    virtual void solve () {
    }

    virtual void clear () {
        *this = Data();
    }
};

struct Solution: Data {
    bool u[1 << N][N];
    
    void dfs (int v, int e) {
        forn (i, n) {
            if (!u[v][i]) {
                u[v][i] = 1;
                dfs(v ^ (1 << i), i);
            }
        }
        if (e != -1) {
            ans.pb(e);
        }
    }

    void solve () {
        dfs(0, -1);
        reverse(all(ans));
    }

    Solution (Data d = Data()): Data(d) {
        memset(u, 0, sizeof u);
    }

    void clear () {
        *this = Solution();
    }
};

Solution sol;
int main () {
#ifdef SG
    freopen("f.in", "r", stdin);
//    freopen("", "w", stdout);
    while (sol.read()) {
        sol.solve();
        sol.write();
        sol.clear();
    }
#else
//    freopen("", "r", stdin);
//    freopen("", "w", stdout);
    sol.read();
    sol.solve();
    sol.write();    
#endif

    return 0;
}
