#include <iostream>
#include <algorithm>
#include <vector>
#include<cstdio>
#include <string>
using namespace std;

vector<pair<int, int> > ans; //k, d

int main()
{
//#ifndef ONLINE_JUDGE
//	freopen("input.txt", "r", stdin);
//	freopen("output.txt", "w", stdout);
//#endif

	int n;
	scanf("%d", &n);

	int best = 1e9;
	for (int k = n; k >= 1; k--)
	{
		int d = 2 * k + 1;
		if (n % d != k)
			continue;
		int t = n / d + k;
		
		if (t < best)
		{
			best = t;
			ans.clear();
		}
		if (t == best)
		{
			ans.push_back(make_pair(k, d));
		}
	}

	printf("%d %d\n", ans.size(), best);
	for (int i = 0; i < ans.size(); i++)
	{
		int k = ans[i].first;
		int d = ans[i].second;
		int t = n / d;
		for (int j = 0; j < k; j++)
			printf("1 ");
		for (int j = 0; j < t; j++)
			printf("%d ", d);
		printf("\n");
	}

	//cin >> n;
}