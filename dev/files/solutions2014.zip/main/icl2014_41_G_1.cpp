#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

#define f first
#define s second
#define next lkdsfgj

const int maxN = 200004;
const int mx = 1e9;

int next[maxN], go[maxN], head[maxN], us[maxN], usp[maxN], p[maxN], d[maxN];
int n, kol;

void add(int x, int y) {
	kol++;
	go[kol] = y;
	next[kol] = head[x];
	head[x] = kol;
}

void dfs(int x, int dp) {
	us[x] = 1;
	d[x] = dp;
	
	int cur = head[x];
	while (cur) {
		int y = go[cur];
		if (us[y] == 0) {
			p[y] = x;
			dfs(y, dp + 1);	
		}
		cur = next[cur];
	}
}
	
int main() {

    cin >> n;
	for (int i = 1; i < n; i++) {
		int x, y;
		scanf("%d%d", &x, &y);
		add(x, y);
		add(y, x);
	}

	dfs(1, 0);
	int q;
	cin >> q;
	int ans = 0;
	for (int j = 0; j < q; j++) {
		int x;
		scanf("%d", &x);
		int y = x;
		int cur = 0;
		while (x > 1 && usp[x] == 0) {
			//cout << x << endl;
			cur++;
			usp[x] = 1;
			x = p[x];			
		}
		//cout << cur << endl;
		ans += cur * 2;
		printf("%d ", ans - d[y]);
		
	}

	return 0;
}
