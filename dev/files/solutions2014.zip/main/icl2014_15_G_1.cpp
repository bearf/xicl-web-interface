#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>


#pragma comment(linker,"/STACK:146000000")


const int maxn = 100146;


using namespace std;


vector<int> v[maxn];
int pr[maxn];
int dp[maxn];
bool used[maxn];
int ans = 0;


void dfs(int e, int par, int dep)
{
	pr[e] = par;
	dp[e] = dep;
	for(int i = 0; i < v[e].size(); i++)
		if(v[e][i] != par)
			dfs(v[e][i], e, dep + 1);
}


void recount(int e)
{
	if(e == 0 || used[e])
		return;
	ans += 2;
	used[e] = true;
	recount(pr[e]);
}


int main()
{
	int n;
	scanf("%d", &n);
	for(int i = 0; i < n - 1; i++)
	{
		int a, b;
		scanf("%d%d", &a, &b);
		a--;
		b--;
		v[a].push_back(b);
		v[b].push_back(a);
	}
	dfs(0, -1, 0);
	int m;
	scanf("%d", &m);
	ans = 0;
	for(int i = 0; i < m; i++)
	{
		int x;
		scanf("%d", &x);
		x--;
		recount(x);
		printf("%d ", ans - dp[x]);
	}
}