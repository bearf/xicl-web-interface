#include <iostream>
#include <map>
#include <set>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
using namespace std;

#if LOCAL
	#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
	#define eprintf(...) 42;
#endif

int n;
int best = 1 << 20;
vector < vector <int> > all;
vector <int> tmp;

void go(int x, int sum, int cur) {
	if (cur > best)  {
		return;
	}
	if (sum > n) {
		return;
	}
	if (sum == n) {
		if (cur < best) {
			best = cur;
			all.clear();
		}
		all.push_back(tmp);
		return;
	}
	tmp.push_back(2 * sum + 1);
	go(2 * sum + 1, sum + 2 * sum + 1, cur + 1);
	tmp.pop_back();
	tmp.push_back(x);
	go(x, sum + x, cur + 1);
	tmp.pop_back();
}

int main() {
#ifdef LOCAL
	freopen("a.in", "r", stdin);
#endif
	scanf("%d", &n);
	tmp.push_back(1);
	go(1, 1, 1);
	sort(all.begin(), all.end());
	printf("%d %d\n", (int)all.size(), best);
	for (int i = 0; i < (int)all.size(); i++) {
		for (int j = 0; j < (int)all[i].size(); j++) {
			if (j > 0) {
				printf(" ");
			}
			printf("%d", all[i][j]);
		}
		printf("\n");
	}
	return 0;
}