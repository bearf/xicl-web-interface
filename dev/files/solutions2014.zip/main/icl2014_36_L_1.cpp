#include <iostream>
#include <vector>

using namespace std;

int main ()
{
	int N;
	cin>>N;
	vector <vector <int> > A (N, vector <int> (N));
	int s=0, S=0;
	for (int i=0;i<N;i++)
	{
		for (int j=0;j<N;j++)
		{
			cin>>A[i][j];
			if (A[i][j]!=0)
			{
				s++;
				S+=A[i][j];
			}
		}
	}
	if (s>=N*N-s)
	{
		cout<<S;
	}
	else
	{
		cout<<-1;
	}
	return 0;
}

