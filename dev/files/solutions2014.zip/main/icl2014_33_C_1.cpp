#include<iostream>
using namespace std;
int main()
{
	unsigned __int64 n;
	cin>>n;
	int a[100], i=0;
	while(n>1)
	{
		a[i++]=n%2;
		n/=2;
	}
	a[i]=n;
	for(;i>=0; i--)
		cout<<a[i];

}