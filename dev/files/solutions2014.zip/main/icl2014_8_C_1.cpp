#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include <iostream>

using namespace std;

#define M 1000100
#define K 22
#define p 1000000007

typedef long long ll;
typedef long long li;

ll a[100], n;

int main() {
	cin >> n;
	for (ll i = 0; i < 64; i++)
		a[i] = ((n >> i) & 1ll);
	int last = 0, cur = 0;
	while (last < 70)
	{
		cur = last;
		while (a[cur] == 1) cur++;
		if (cur - last > 1)
		{
			a[cur] = 1;
			a[last] = -1;
			for (int i = last + 1; i < cur; i++)
				a[i] = 0;
			last = cur;
		}
		else last++;
	}
	last = 80;
	while (last > 0 && a[last] == 0) last--;
	while (last >= 0) { cout << a[last] << ' '; last--; }
	return 0;
}