#pragma comment(linker, "/STACK:64000000")

#include<iostream>
#include<cstdio>
#include<sstream>

#include<algorithm>
#include<vector>
#include<set>
#include<bitset>
#include<map>
#include<queue>
#include<deque>
#include<stack>

#include<string>
#include<memory.h>
#include<cassert>
#include<time.h>

using namespace std;

#define forn(i, n) for(int i = 0; i < (int)n; i++)
#define forab(i, a, b) for(int i = (int)a; i <= (int)b; i++)
#define fornd(i, n) for(int i = 0; i < (int)n; i--)
#define forabd(i, b, a) for(int i = (int)b; i >= (int)a; i--)
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define _(a, val) memset(a, val, sizeof(a))
#define sz(a) (int)(a).size()

typedef long long lint;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;

const int INF = 1000000000;
const lint LINF = (lint)INF * (lint)INF;
const double eps = 1e-9;

const int nmax = 2 * 100005 + 16;

pii a[nmax];
int n;

void read()
{
	scanf("%d",&n);
	for (int i = 0; i < n; i ++)
	{
		scanf("%d",&a[i].first);
		a[i].second = i;
	}
}

void solve()
{
	sort(a, a + n);
	int ans = n;
	for (int l = 0, r = 0; l < n; l = r)
	{
		for (r = l + 1; r < n && a[r].second > a[r - 1].second; r ++);
		ans = min(ans, n - (r - l));
	}
	printf("%d\n", ans);
}

int main()
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#endif

	read();
	solve();

	return 0;
}