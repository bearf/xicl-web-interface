#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <queue>
#include <deque>
#include <complex>

using namespace std;

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define all(x) (x).begin(), (x).end()
#define fs first
#define sc second
#define y0 yy0
#define y1 yy1
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define prev _prev
#define rank _rank
#define link _link
#define hash _hash
#define next _next
#ifdef LOCAL
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef complex<double> tc;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));

int main() {
#ifdef LOCAL
#define TASK "A"
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	int n;
	scanf("%d", &n);
	int x = 2 * n + 1;
	vector<int> V;
	for (int t = 3; t * t <= x; t += 2)
	{
		while (x % t == 0)
		{
			V.push_back(t / 2);
			x /= t;
		}
	}
	if (x != 1)
		V.push_back(x / 2);
	int sm = 0;
	for (int i = 0; i < V.size(); i++)
		sm += V[i];
	vector<int> W(V.size());
	vector<vector<int> > ans;
	vector<int> T(sm);
	do
	{
		int sum = 0;
		int pt = 0;
		for (int i = 0; i < V.size(); i++)
		{
			W[i] = 2 * sum + 1;
			sum += W[i] * V[i];
			for (int j = 0; j < V[i]; j++)
				T[pt++] = W[i];
		}
		assert(sum == n);
		ans.push_back(T);
	} while (next_permutation(V.begin(), V.end()));
	sort(ans.begin(), ans.end());
	printf("%d %d", (int)ans.size(), (int)V.size());
	cout << endl;
	for (int i = 0; i < ans.size(); i++)
	{
		for (int j = 0; j < sm; j++)
			printf("%d ", ans[i][j]);
		cout << endl;
	}
	return 0;
}
