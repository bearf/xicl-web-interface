#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;

const int mod = (int)1e9 + 9;
const int pow2 = (1 << 20);
const int K = 30;
const int N = (int)1e6 + 10;

int add(int a, int b)
{
	a += b;
	if (a >= mod)
		a -= mod;
	return a;
}

struct SegmentTree
{
	int tree[pow2 * 2];
	void build()
	{
		for (int i = 0; i < pow2 * 2; i++)
			tree[i] = 0;
	}
	void addVal(int pos, int val, int v = 1, int l = 0, int r = pow2 - 1)
	{
		if (l == r)
		{
			tree[v] = add(tree[v], val);
			return;
		}
		int m = (l + r) / 2;
		if (pos <= m)
			addVal(pos, val, 2 * v, l, m);
		else
			addVal(pos, val, 2 * v + 1, m + 1, r);
		tree[v] = add(tree[2 * v], tree[2 * v + 1]);
	}
	int getSum(int a, int b, int v = 1, int l = 0, int r = pow2 - 1)
	{
		if (l >= a && r <= b)
			return tree[v];
		if (l > b || r < a)
			return 0;
		int m = (l + r) / 2;
		return add(getSum(a, b, 2 * v, l, m), getSum(a, b, 2 * v + 1, m + 1, r));
	}
};
int dp[K][N];
int sum[K][N];

int main()
{
	int n, k;
	scanf("%d%d", &n, &k);
	dp[0][0] = 1;
	for (int i = 0; i <= n; i++)
		sum[0][i] = 1;
	for (int i = 1; i <= k; i++)
	{
		for (int s = 1; s <= n; s++)
		{
			dp[i][s] = sum[i - 1][s / 2];
		}
		sum[i][0] = 0;
		for (int s = 1; s <= n; s++)
			sum[i][s] = add(sum[i][s - 1], dp[i][s]);
	}
	cout << dp[k][n];
	return 0;
}