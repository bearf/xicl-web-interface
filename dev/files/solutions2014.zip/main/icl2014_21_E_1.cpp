#ifdef SU2_PROJ
#define _GLIBCXX_DEBUG
#endif

#include <algorithm>
#include <bitset>
#include <cassert>
#include <climits>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <string>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define forn(i, n) for (int i = 0; i < int(n); i++)
#define forl(i, n) for (int i = 1; i <= int(n); i++)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; i--)
#define fore(i, l, r) for (int i = int(l); i <= int(r); i++)
#define correct(x, y, n, m) (0 <= (x) && (x) < (n) && 0 <= (y) && (y) < (m))
#define pb(a) push_back(a)
#define all(a) (a).begin(), (a).end()
#define mp(x, y) make_pair((x), (y))
#define sz(a) int((a).size())
#define ft first
#define sc second
#define x first
#define y second

using namespace std;

typedef long long li;
typedef long double ld;
typedef pair <int, int> pt;

inline ostream& operator << (ostream& out, const pt& p) { return out << "(" << p.x << ", " << p.y << ")"; }

const int INF = int(1e9);
const li INF64 = li(1e18);
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

const int N = 200 * 1000 + 13;

int n;
int a[N], b[N];
map <int, int> d;

inline bool read ()
{
	if (scanf("%d", &n) != 1) return false;
	
	forn(i, n)
	{
		assert(scanf("%d", &a[i]) == 1);
		b[i] = a[i];
	}
	
	sort(b, b + n);
	
	return true;
}

inline void solve ()
{
	int ans = 0;
	
	forn(i, n)
	{
		int idx = int(lower_bound(b, b + n, a[i]) - b);
		assert(b[idx] == a[i]);
		
		int cur = 0;
		if (idx > 0) cur = max(cur, d[b[idx - 1]]);
		if (idx + 1 < n && b[idx + 1] == b[idx]) cur = max(cur, d[b[idx]]);
		cur++;
		
		ans = max(ans, cur);
		d[a[i]] = max(d[a[i]], cur);		
	}
	
	cout << n - ans << endl;
}

int main()
{
#ifdef SU2_PROJ
	freopen("input.txt", "rt", stdin);
	//freopen("output.txt", "wt", stdout);
#endif

	cout << setprecision(10) << fixed;
	cerr << setprecision(5) << fixed;
	
	assert(read());
	solve();
	
#ifdef SU2_PROJ
	cerr << "=== Time: " << clock() << " ===" << endl;
#endif

	return 0;
}
