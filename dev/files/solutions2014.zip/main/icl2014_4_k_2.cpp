#undef NDEBUG
#ifdef ssu1
#define _GLIBCXX_DEBUG
#endif

#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define fore(i, l, r) for(int i = (l); i < (r); ++i)
#define forn(i, n) fore(i, 0, n)
#define fori(i, l, r) fore(i, l, (r) + 1)
#define X first
#define Y second
#define sz(v) ((int)(v).size())
#define pb push_back
#define mp make_pair
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<ld, ld> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-11;
const ld PI = acosl(-1.0);

pt operator - (const pt& a, const pt& b){
    return pt(a.X - b.X, a.Y - b.Y);
}

struct item{
    ld a, b, c;
    item(){
        a = 0, b = 0, c = 0;
    }
    item(ld _a, ld _b, ld _c) : a(_a), b(_b), c(_c) {}
};

item operator + (const item& o1, const item& o2){
    return item(o1.a + o2.a, o1.b + o2.b, o1.c + o2.c);
}
item operator * (const item& o1, const ld& o2){
    return item(o1.a * o2, o1.b * o2, o1.c * o2);
}

void norm(pt& v, ld nln){
    ld ln = sqrtl(v.X * v.X + v.Y * v.Y);
    v.X *= nln / ln;
    v.Y *= nln / ln;
}

ld readLd(){
    double x;
    assert(scanf("%lf", &x) == 1);
    return x;
}

inline ld dot(const pt& a, const pt& b){
    return a.X * b.X + a.Y * b.Y;
}

inline void process(item& x, item& y, pt a, pt va){
    item t(0, 0, dot(a, va));
    t = t + (( (x * va.X) + (y * va.Y) ) * (-1));
    item nx = x + (t * va.X);
    item ny = y + (t * va.Y);
    x = nx;
    y = ny;
}

void no(){
    puts("-1");
    exit(0);
}

void exist(ld a, ld b, ld c){
    if(abs(a) < EPS && abs(b) < EPS){
        if(abs(c) > EPS)
            no();
        printf("0 0\n");
        throw;
        exit(0);
    }
    if(abs(a) < EPS)
        printf("0 %.10lf\n", double(c / b));
    else
        printf("%.10lf 0\n", double(c / a));
}

void solve(ld a1, ld b1, ld c1, ld a2, ld b2, ld c2){
    if(abs(a1) < EPS && abs(b1) < EPS){
        if(abs(c1) > EPS)
            no();
        exist(a2, b2, c2);
        //printf("%.10lf %.10lf\n", double(x), double(y));
        return;
    }
    if(abs(a2) < EPS && abs(b2) < EPS){
        if(abs(c2) > EPS)
            no();
        exist(a1, b1, c1);
        //printf("%.10lf %.10lf\n", double(x), double(y));
        return;
    }
    
    if(abs(a1) < EPS){
        ld A = a2 - (b2 / b1) * a1;
        if(abs(A) < EPS)
            no();
        ld x = (c2 - (b2 / b1) * c1) / A;
        ld y = (c1 - a1 * x) / b1;
        printf("%.10lf %.10lf\n", double(x), double(y));
        return;
    }
    
    {
        swap(a1, b1);
        swap(a2, b2);
        
        ld A = a2 - (b2 / b1) * a1;
        if(abs(A) < EPS)
            no();
        ld x = (c2 - (b2 / b1) * c1) / A;
        ld y = (c1 - a1 * x) / b1;
        printf("%.10lf %.10lf\n", double(y), double(x));
    }
}

const int NMAX = 15000;
int n;
pt a[NMAX], va[NMAX];

int main(){
    #ifdef ssu1
    assert(freopen("__input.txt", "r", stdin));
    #endif
    
    assert(scanf("%d", &n) == 1);
    forn(i, n){
        a[i].X = readLd();
        a[i].Y = readLd();
        va[i].X = readLd();
        va[i].Y = readLd();
        va[i] = va[i] - a[i];
        norm(va[i], 1);
        va[i] = mp(-va[i].Y, va[i].X);
    }
    
    item x(1, 0, 0), y(0, 1, 0);
    
    fore(i, 1, n){
        process(x, y, a[i], va[i]);
    }
    process(x, y, a[0], va[0]);

    solve(1 - x.a, -x.b, x.c, -y.a, 1 - y.b, y.c); 
    return 0;
}






