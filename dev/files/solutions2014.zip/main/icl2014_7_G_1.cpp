#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <vector>

using namespace std;

const int N = 100100, H = 20;
vector<int> g[N];
int tin[N], tout[N], tcnt;
int d[N][H], h[N];
int ord[2*N], k;
int a[N], b[N];
long long ft[2*N];

void dfs(int u, int p) {
	tin[u] = ++tcnt;
	h[u] = h[p]+1;

	a[u] = k;
	ord[k++] = u;

	d[u][0] = (p==0? u: p);
	for (int i=1; i<H; i++)
		d[u][i] = d[d[u][i-1]][i-1];

	for (int i=0; i<g[u].size(); i++) {
		int v = g[u][i];
		if (v == p)
			continue;
		dfs(v, u);
		ord[k++] = u;
	}

	b[u] = k-1;

	tout[u] = ++tcnt;
}

void upd(int i, int x) {
	for ( ; i<N; i = i | (i+1))
		ft[i] += x;
}

long long sum(int r) {
	long long res = 0;
	for ( ; r>=0; r = (r & (r+1)) - 1)
		res += ft[r];
	return res;
}

long long sum(int l, int r) {
	if (l)
		return sum(r-1) - sum(l-1);
	return sum(r-1);
}

int least_ancestor(int u) {
	for (int i=H-1; i>=0; i--)
		if (!sum(a[d[u][i]], b[d[u][i]]))
			u = d[u][i];
	return d[u][0];
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif
	int n;
	cin >> n;
	for (int i=1; i<n; i++) {
		int u, v;
		cin >> u >> v;
		g[u].push_back(v);
		g[v].push_back(u);
	}
	h[0] = -1;
	dfs(1, 0);

	int m;
	cin >> m;
	long long x = 0;
	for (int i=0; i<m; i++) {
		int u;
		cin >> u;
		if (i==0) {
			cout << h[u] << " ";
			x = 2 * h[u];
			upd(a[u], 1);
			continue;
		}
		if (sum(a[u], b[u])) {
			cout << x - h[u] << " ";
		}
		else {
			int v = least_ancestor(u);
			cout << x + h[u] - 2*h[v] << " ";
			x += 2 * (h[u] - h[v]);
		}
		upd(a[u], 1);
	}
	cout << endl;

	return 0;
}