#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>

using namespace std;

const int mod = 1000000009;

int n, k, dp[1000005][22];

void load() {
	cin >> n >> k;
}

int go (int n, int k) {
	if (k == 0) return n == 0;
	if (n < 0) return 0;

	int &res = dp[n][k];
	if (res != -1) return res;
	res = 0;

	res = (go (n, k - 1) + go (n - (1 << (k - 1)), k)) % mod;

	return res;
}

void solve() {
	memset (dp, -1, sizeof (dp));

	cout << go (n - (1 << (k - 1)), k) << endl;
}

int main () {
	#ifdef LOCAL
		freopen ("a.in", "r", stdin);
	#endif

	load();
	solve();

	return 0;
}
