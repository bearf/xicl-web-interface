#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cmath>
#include <stack>
#include <map>
#include <algorithm>

using namespace std;
typedef long long ll;

int n, m, root = 1, summ;
vector <int> par, h;
vector <vector <int> > ch;
vector <bool> used;

void dfs (int v, int hei, int from) {
	if (used[v]) return;
	used[v] = true;
	h[v] = hei;
	par[v] = from;
	for (int i = 0; i < ch[v].size(); i++) {
		dfs(ch[v][i], hei + 1, v);
	}
}

int main () {
	//freopen("input.txt", "r", stdin);freopen("output.txt", "w", stdout);
	cin >> n;
	used.resize(n + 1);
	par.resize(n + 1);
	h.resize(n + 1);
	ch.resize(n + 1);
	for (int i = 1; i < n; i++) {
		int u, v;
		cin >> u >> v;
		ch[u].push_back(v);
		ch[v].push_back(u);
	}
	dfs(1, 0, 0);
	for (int i = 2; i <= n; i++) {
		used[i] = false;
	}
	cin >> m;
	used[1] = true;
	for(int i = 0; i < m; i++){
		int cur, ncur, count = 0;
		cin >> cur;
		ncur = cur;
		while(!used[ncur]){
			used[ncur] = true;
			count++;
			ncur = par[ncur];
		}
		summ += count * 2;
		cout << (summ - h[cur]) << " ";
	}
	return 0;
}