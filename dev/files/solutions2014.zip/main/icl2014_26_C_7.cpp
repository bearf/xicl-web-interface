#include<iostream>
#include <deque>
#include <vector>
using namespace std;
int main()
{
	_int64 a[65];
	a[0]=1;
	for(int i=1;i<64;i++)
		a[i]=a[i-1]*2;
	_int64 n;
	int j;
	cin>>n;
	for(int i=0;i<64;i++)
		if(a[i]>n)
		{
			j=i;
			break;
		}
	vector<_int64> p(j+1,0);
	p[0]=a[j];
	_int64 q=p[0],r=n;
	for(int i=1;i<p.size();i++)
	{
		_int64 w=q-r;
		{
			for(int k=62;k>=-0;k--)
			{
				if(a[k]<=w)
				{
					p[p.size()-1-k]=-1;
					r=a[k];
					break;
				}
			
			}
			q=w;
		}
	}

	for(int i=0;i<p.size();i++)
	{
		if(p[i]>0)
			p[i]=1;
		cout<<p[i]<<' ';
	}
}