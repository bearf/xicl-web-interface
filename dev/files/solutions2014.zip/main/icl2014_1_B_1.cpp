#include<iostream>

using namespace std;

int a[31][2000001];

int main()
{
	int n, k;
	cin >> n >> k;

	for (int i = 1; i <= n; i++)
	{
		a[1][i] = 1;
	}

	for (int i = 2; i <= k; i++)
	{
		for (int j = 1; j <= n; j++)
		{
			if (j % 2 == 1)
			{
				a[i][j] = a[i][j - 1];
			}
			else
			{
				a[i][j] = a[i][j - 2] + a[i - 1][j / 2];
			}
		}
	}

	cout << a[k][n];
	return 0;
}