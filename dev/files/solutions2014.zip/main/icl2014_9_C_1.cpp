#include <iostream>
#include <vector>

using namespace std;

vector <int> a;

bool check(int &x);

int main()
{
	long long n;
	cin >> n;
	while (n)
	{
		a.push_back(n % 2);
		n /= 2;
	}
	int x;
	while (!check(x))
	{
		a[x++] = -1;
		while ((x < (signed)a.size()) && (a[x] == 1))
			a[x++] = 0;
		if (x < (signed)a.size())
			a[x] = 1;
		else
			a.push_back(1);
	}
	for (int i((signed)a.size() - 1); i >= 0; --i)
		cout << a[i] << ' ';
	return 0;
}

bool check(int &x)
{
	for (int i(0); i < a.size() - 1; ++i)
		if ((a[i] == 1) && (a[i + 1] == 1))
		{
			x = i;
			return false;
		}
	return true;
}