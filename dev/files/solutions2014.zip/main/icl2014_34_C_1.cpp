#include <iostream>
#include <algorithm>
using namespace std;

typedef long long int64;

int64 n;
int res[64];

pair<int64, int64> get_pair(int pos, bool zero)
{
	pos--;
	if (!zero)
		pos--;

	pair<int64, int64> res;
	for (int i = pos; i >= 0; i -= 2)
	{
		res.first -= (1LL << i);
		res.second += (1LL << i);
	}

	return res;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	scanf("%lld", &n);

	int64 sum = 0;
	int i = 63;

	while (i >= 0)
	{
		pair<int64, int64> interval = get_pair(i, false);
		interval.first += sum - (1LL << i);
		interval.second += sum - (1LL << i);
		if (n >= interval.first && n <= interval.second)
		{
			sum -= (1LL << i);
			res[i] = -1;
			i -= 2;
			continue;
		}

		interval = get_pair(i, true);
		interval.first += sum;
		interval.second += sum;
		if (n >= interval.first && n <= interval.second)
		{
			res[i] = 0;
			i--;
			continue;
		}

		interval = get_pair(i, false);
		interval.first += sum + (1LL << i);
		interval.second += sum + (1LL << i);
		if (n >= interval.first && n <= interval.second)
		{
			sum += (1LL << i);
			res[i] = 1;
			i -= 2;
			continue;
		}
	}

	int start_pos = 63;
	while (res[start_pos] == 0)
		start_pos--;

	for (int i = start_pos; i >= 0; i--)
		printf("%d ", res[i]);

	return 0;
}	