#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <math.h>

//#define _DEBUG
#define forn(i,n) for (int i=0;i<n;i++)
#define LL long long

using namespace std;
const LL mod=1000000009;

LL work(int n, int k, vector <vector <LL> > &a){
	if (k==1)
	{
		if (n>0)
			return 1;
		return 0;
	}

	if (a[n][k]!=-1)
		return a[n][k];

	a[n][k]=0;

	int st=n/2+(n%2>0);
	for (int i=st;i<=n;i++)
	{
		a[n][k]=(a[n][k]+work(n-i,k-1,a))%mod;
	}
	return a[n][k];
}
int main()
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif

	int n, k;
	cin>>n>>k;
	vector <vector <LL> > a(n+1, vector <LL>  (k+1,-1));

	cout<<work(n,k,a);
}