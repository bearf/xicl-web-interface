#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cassert>
#include <ctime>

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

typedef long long ll;
typedef long long li;

void Solve(void);

int main(){
#ifdef BANANA_MOTEL
	freopen("test.in", "r", stdin);
	freopen("test.out", "w", stdout);
#else
#endif
	Solve();
	return 0;
}

string ANS, s;

void count()
{
	for (char j = '1'; j <= '9'; j++)
	{
		int res = 0;
		for (int i = 0; i < s.length() - 1; i++)
			if (s[i] < j) { res = -1; break; }
			else if (s[i] > j) { res = 1; break; }
		if (res == -1) break;
		else if (res == 1) ANS.insert(ANS.begin() + ANS.length() - 10, j);
		else if (s[s.length() - 1] >= s[0]) ANS.insert(ANS.begin() + ANS.length() - 10, j);
		else
		{
			ANS.insert(ANS.begin() + ANS.length() - 10, j);
			int cur = ANS.length() - 1;
			while (ANS[cur] != j) cur--, ANS.pop_back();
			ANS.pop_back();
			for (char jj = j + 1; jj <= '9'; jj++)
				ANS += jj;
			break;
		}
	}
	cout << ANS << endl;
}

void Solve()
{
	getline(cin, s);
	if (s.length() == 1)
	{
		for (char c = '1'; c <= s[0]; c++)
			cout << c;
		cout << endl;
		return;
	}
	if (s.length() > 2)
	{
		ANS = "1023456789";
		for (int i = 2; i < s.length(); i++)
			ANS += "0123456789";
	}
	else ANS = "0123456789";
	count();
}