#pragma comment(linker, "/STACK:256000000")
#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <algorithm>
#include <stack>
using namespace std;
//const int b=1000000009;
typedef long long ll; 

vector<int> us;
vector<int> p;
vector<vector<int> >  g;
//stack<int> s;
//vector<int> as(500);
vector<int> path;
//int em=0;
//int bb=317;
//int cnt=0;
//vector<vector<int> >  d;
//vector<int> p1(500),p2(500);
ll circle =0;

void dfs(int v){
//	s.push(v);
	//cnt++;
	//if(cnt == bb){
	//	as[em] = v;
	//	em++;
	//}
//	for(int i=0;i<em;i++)
//		d[v].push_back(as[i]);

	for(int i=0;i<g[v].size();i++){
		int u=g[v][i];
		if(us[u] == 0){
			us[u]=1;
			p[u] = v;
			path[u]= path[v] +1;
			dfs(u);
		}
	}
	//if(cnt == bb){
	//	em--;
	//	cnt = bb - 1;
	//}
}

//ll lcd(int a, int b){
//	ll ress =0 ;
//	int len=min(d[a].size(),d[b].size());
//	int v=0;
//	for(int i=0;i<len;i++)
//		if(d[a][i] == d[b][i]){
//			v =d[a][i];
//		}
//		else
//			break;
//	int i1=0,i2=0;
//	while(a != v){
//		p1[i1] = a;
//		i1++;
//		a = p[a];
//	}
//	while(b != v){
//		p2[i2] = b;
//		i2++;
//		b = p[b];
//	}
//	len = min(i1,i2);
//	for(int i=0;i<len;i++)
//		if (p1 [i1-1-i] == p2[i2-1-i]){
//			ress++;
//		}
//		else
//			break;
//	ll res = i1 + i2 - ress *2;
//	return res;
//
//}

pair<int,ll> neww(int a){
	int w = a;
	ll len = 0;
	while(us[w] == 0){
		us[w] = 1;
		len ++;
		w = p[w];
	}
	return make_pair(w, len);

}
int main(){
	//freopen("1.txt","r",stdin);
	int n;
	cin>>n;
	g.resize(n);
//	d.resize(n);
	us.resize(n);
	path.resize(n);
	for(int i=1;i<n;i++){
		int a,b;
		cin>>a>>b;
		a--;
		b--;
		g[a].push_back(b);
		g[b].push_back(a);
	}
	p.resize(n);	
	p[0] = -1;
	us[0]=1;
	path[0]=0;
	dfs(0);
	int m;
	cin>>m;
	ll ans=0;
	int last =0;
	us.assign(n, 0);
	us[0]=1;
	while(m--){
		int w;
		cin >> w;
		w--;
		pair<int,ll> q;
		q = neww(w);
		//ll res = lcd(last, w);
		//ans += res;
		//last = w;
		cout<< circle - path[q.first] + q.second <<" ";
		circle += q.second *2;
	}
	cout<<endl;
}