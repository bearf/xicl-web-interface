#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <queue>
#include <deque>
#include <complex>

using namespace std;

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define all(x) (x).begin(), (x).end()
#define fs first
#define sc second
#define y0 yy0
#define y1 yy1
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define prev _prev
#define rank _rank
#define link _link
#define hash _hash
#define next _next
#ifdef LOCAL
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef complex<double> tc;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));
const int N = int(1e5) + 100;

struct tr {

	int l, r, val, minVal, add;

};

struct tq {

	int t, x;

};

int maxv, sz;
char cmd[100];
int x[N], lst[N];
tq q[N];
tr rmq[4 * N];

inline void calc(int v) {
	rmq[v].val = max(rmq[v * 2].val, rmq[v * 2 + 1].val);
	rmq[v].minVal = min(rmq[v * 2].minVal, rmq[v * 2 + 1].minVal);
}

inline void push(int v) {
	rmq[v].val += rmq[v].add;
	rmq[v].minVal += rmq[v].add;
	if (v < maxv) {
		rmq[v * 2].add += rmq[v].add;
		rmq[v * 2 + 1].add += rmq[v].add;
	}
	rmq[v].add = 0;
}

int get(int pos, int v = 1) {
	push(v);
	if (v >= maxv) {
		return rmq[v].val;
	}
	if (pos <= rmq[v * 2].r) {
		return get(pos, v * 2);
	}
	return get(pos, v * 2 + 1);
}

void update(int pos, int val, int minVal, int v = 1) {
	push(v);
	if (v >= maxv) {
		rmq[v].val = val;
		rmq[v].minVal = minVal;
		return;
	}
	if (pos <= rmq[v * 2].r) {
		update(pos, val, minVal, v * 2);
	}
	else {
		update(pos, val, minVal, v * 2 + 1);
	}
	calc(v);
}

void dfs(int l, int r, int v = 1) {
	push(v);
	if (rmq[v].l > r || rmq[v].r < l || l > r) {
		return;
	}
	if (rmq[v].l >= l && rmq[v].r <= r) {
		lst[sz++] = v;
		return;
	}
	dfs(l, r, v * 2);
	dfs(l, r, v * 2 + 1);
}

pii findLeft(int v) {
	push(v);
	if (v >= maxv) {
		return mp(v - maxv, rmq[v].val);
	}
	push(v * 2 + 1);
	if (rmq[v * 2 + 1].val > 0) {
		return findLeft(v * 2 + 1);
	}
	return findLeft(v * 2);
}

inline pii findLeft(int l, int r) {
	sz = 0;
	dfs(l, r);
	for (int i = sz - 1; i >= 0; --i) {
		if (rmq[lst[i]].val > 0) {
			return findLeft(lst[i]);
		}
	}
	return mp(-1, -1);
}

pii findRight(int v) {
	push(v);
	if (v >= maxv) {
		return mp(v - maxv, rmq[v].val);
	}
	push(v * 2);
	if (rmq[v * 2].val > 0) {
		return findRight(v * 2);
	}
	return findRight(v * 2 + 1);
}

inline pii findRight(int l, int r) {
	sz = 0;
	dfs(l, r);
	for (int i = 0; i < sz; ++i) {
		if (rmq[lst[i]].val > 0) {
			return findRight(lst[i]);
		}
	}
	return mp(-1, -1);
}

int findLeftLess(int v, int val) {
	push(v);
	if (v >= maxv) {
		return v - maxv;
	}
	push(v * 2 + 1);
	if (rmq[v * 2 + 1].minVal <= val) {
		return findLeftLess(v * 2 + 1, val);
	}
	return findLeftLess(v * 2, val);
}

inline int findLeftLess(int l, int r, int val) {
	sz = 0;
	dfs(l, r);
	for (int i = sz - 1; i >= 0; --i) {
		if (rmq[lst[i]].minVal <= val) {
			return findLeftLess(lst[i], val);
		}
	}
	return -1;
}

int findRightLess(int v, int val) {
	push(v);
	if (v >= maxv) {
		return v - maxv;
	}
	push(v * 2);
	if (rmq[v * 2].minVal <= val) {
		return findRightLess(v * 2, val);
	}
	return findRightLess(v * 2 + 1, val);
}

inline int findRightLess(int l, int r, int val) {
	sz = 0;
	dfs(l, r);
	for (int i = 0; i < sz; ++i) {
		if (rmq[lst[i]].minVal <= val) {
			return findRightLess(lst[i], val);
		}
	}
	return r + 1;
}

void add(int l, int r, int addv, int v = 1) {
	push(v);
	if (rmq[v].l > r || rmq[v].r < l || l > r) {
		return;
	}
	if (rmq[v].l >= l && rmq[v].r <= r) {
		rmq[v].add += addv;
		push(v);
		return;
	}
	add(l, r, addv, v * 2);
	add(l, r, addv, v * 2 + 1);
	calc(v);
}

int main() {
#ifdef LOCAL
#define TASK "J"
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; ++i) {
		scanf("%s %d", cmd, &q[i].x);
		x[i] = q[i].x;
		if (strcmp(cmd, "ADD") == 0) {
			q[i].t = 0;
		}
		if (strcmp(cmd, "FIND") == 0) {
			q[i].t = 1;
		}
		if (strcmp(cmd, "REMOVE") == 0) {
			q[i].t = 2;
		}
	}
	sort(x, x + n);
	int k = unique(x, x + n) - x;
	maxv = 1;
	while (maxv < k) {
		maxv *= 2;
	}
	for (int i = 0; i < maxv; ++i) {
		rmq[i + maxv].l = rmq[i + maxv].r = i;
		rmq[i + maxv].val = -inf;
		rmq[i + maxv].minVal = inf;
	}
	for (int i = maxv - 1; i > 0; --i) {
		rmq[i].l = rmq[i * 2].l;
		rmq[i].r = rmq[i * 2 + 1].r;
		calc(i);
	}
	for (int i = 0; i < n; ++i) {
		int pos = lower_bound(x, x + k, q[i].x) - x, val = get(pos);
		pii left = findLeft(0, pos - 1), right = findRight(pos + 1, k - 1), p;
		if (left.fs != -1 && right.fs != -1) {
			if (left.sc > right.sc) {
				p = left;
			}
			else {
				p = right;
			}
		}
		else {
			if (left.fs != -1) {
				p = left;
			}
			else {
				p = right;
			}
		}
		if (q[i].t == 0) {
			if (val > 0) {
				printf("FALSE %d", val);
				puts("");
				continue;
			}
			if (left.fs == -1 && right.fs == -1) {
				update(pos, 1, 1);
				puts("TRUE 1");
				continue;
			}
			update(pos, p.sc + 1, p.sc + 1);
			printf("TRUE %d", p.sc + 1);
			puts("");
			continue;
		}
		if (q[i].t == 1) {
			if (val > 0) {
				printf("TRUE %d", val);
				puts("");
				continue;
			}
			if (left.fs == -1 && right.fs == -1) {
				puts("FALSE 1");
				continue;
			}
			printf("FALSE %d", p.sc);
			puts("");
			continue;
		}
		if (val <= 0) {
			if (left.fs == -1 && right.fs == -1) {
				puts("FALSE 1");
				continue;
			}
			printf("FALSE %d", p.sc);
			puts("");
			continue;
		}
		update(pos, -inf, inf);
		if (left.fs == -1 && right.fs == -1) {
			printf("TRUE %d", val);
			puts("");
			continue;
		}
		if (left.fs == -1) {
			printf("TRUE %d", val);
			puts("");
			add(pos + 1, findRightLess(pos + 1, k - 1, val) - 1, -1);
			continue;
		}
		if (right.fs == -1) {
			printf("TRUE %d", val);
			puts("");
			add(findLeftLess(0, pos - 1, val) + 1, pos - 1, -1);
			continue;
		}
		printf("TRUE %d\n", right.sc);
		add(right.fs + 1, findRightLess(right.fs + 1, k - 1, right.sc), -1);
		update(right.fs, val, val);
	}
	return 0;
}
