#define MAXN 300000
#define INF 1E+9
#define EPS 1E-9 
#define PROB "a"

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <string>
#include <cstring>
#include <cmath>

using namespace std;

int n, a[MAXN], b[MAXN];
int i, j, k1, k2;

int main(){

	scanf ("%d", &n);
	for (i = 0; i < n; ++i) {
		scanf ("%d", &a[i]);
		b[i] = a[i]; 
	}

	sort (b, b+n);

	i = 0; j = 0; 
	k1 = 0; k2 = 0;

	for (; i < n && j < n; ++i) {
		if (b[j] != a[i]) ++k1;
		else ++j;
	}
	//k1 += n - j;


	i = n-1; j = n-1; 
	for (; i > -1 && j > -1; --i) {
		if (b[j] != a[i]) ++k2;
		else --j;
	}

	//k2 += j + 1;

	printf ("%d", min (k1, k2));

	return 0;
}