#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <math.h>
#define re return
//#define _DEBUG
#define forn(i,n) for (int i=0;i<n;i++)

using namespace std;

char s[1000000];
char res[5000000];int ires;
char res1[500];int ires1;
int main()
{
#ifdef _DEBUG
	freopen("inD.txt","r",stdin);
	freopen("outD.txt","w",stdout);
#endif
	int n;
	scanf("%s",&s);
	//cin>>s;
	int slen=strlen(s);
	if(slen<2){
		for(char i='1';i<=s[0];++i)
			cout<<i;
		re 0;
	}
	int i,j,ires=0;
	for(i=0;i<slen-2;++i){
		for(j=0;j<10;++j)
			res[ires++]='0'+j;
	}
	int ifir=s[0]-'0';
	int isec=s[1]-'0';
	ires1=0;
	for(i=1;i<ifir;++i)res1[ires1++]='0'+i;
	if(isec>=ifir){
		res1[ires1++]='0'+ifir;
		for(j=0;j<10;++j)
			res1[ires1++]='0'+j;
	}
	else{
		res1[ires1++]='0'+ifir;
		for(j=0;j<10;++j)if(j!=ifir)
			res1[ires1++]='0'+j;
	}
	for(i=0;i<ires1;++i)printf("%c",res1[i]);
	for(i=0;i<ires;++i)printf("%c",res[i]);
	return 0;
}