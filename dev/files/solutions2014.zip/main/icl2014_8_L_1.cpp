#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include <iostream>

using namespace std;

int a[100][100];
int n;

int main() {
	cin >> n;
	int cnt = 0, sum = 0;
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++) {
			int b;
			cin >> b;
			if (b != 0)
				cnt++;
			sum += b;
		}
	if (cnt * 2 >= n * n) 
		cout << sum;
	else
		cout << -1;
}