#pragma comment(linker, "/STACK:256000000")
#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <algorithm>
#include <stack>
#include <map>
using namespace std;
//const int b=1000000009;
typedef long long ll; 

map<int,int> ma;
//int base = (1<<18);
vector<vector<int> > g;
//int m[800000];
//
//int get(int a,int b){
//	if (a==b)
//		return m[a];
//	if (b%2 == 0)
//		return max(m[b], get(a/2, (b-1)/2));
//	else
//		return get(a/2, b/2);
//}
//
//void update(int v, int z){
//	v = base + v;
//	m[v] = z;
//	while(v != 0){
//		v >>= 1;
//		m[v] = max(m[v*2], m[v*2+1]);
//	}
//}

int main(){
	//freopen("1.txt","r",stdin);
	int n;
	cin >>n;
	vector<int> a(n);
	vector<int> b(n);
		vector<int> c(n);
	g.resize(n);
	for(int i=0;i<n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	sort(b.begin(),b.end());
	vector<int> p(1, b[0]);
	for(int i=1;i<n;i++)
		if(b[i] != b[i-1])
			p.push_back(b[i]);

	for(int i=0;i<p.size();i++)
		ma[p[i]] = i;
	//memset(m,0,sizeof(m));
	for(int i=0;i<n;i++){
		g[ma[a[i]]].push_back(i);
	}

	//for(int i=0;i<n;i++){
	//	int u= ma[a[i]];
	//	int len = get(base, base + u); 
	//	update(u, len + 1); 
	//}

	//int res = get(base, base + n);
	//cout<<res<<endl;
	//cout<<n-res<<endl;

	int em=0;
	for(int i=0;i<b.size();i++)
		for(int j=0;j<g[i].size();j++)
			c[em++]=b[i];
	int ans = 0;
	em=-1;
	for(int i=0;i<b.size();i++){
		for(int j=0;j<g[i].size();j++){
			em ++;
			int left = 0;
			int l,r,md;
			int cn=0;
			int emi=em;
			int f=i;
			while(em < n){
				
				r = g[f].size()-1;
				l = 0;
				while(r-l>1){
					md = (r+l)>>1;
					if (g[f][md] >= left)
						md = r;
					else
						md = l;
				}
				md =-1;
				if (g[f].size() > r && g[f][r] >= left)
					md =r;
				if (g[f][l] >= left)
					md = l;
				if(md == -1){
					ans =max(ans,cn);
					break;
				}
				else{
					cn ++;
					left = g[f][md] + 1;
					emi++;
					if(emi==n){
					ans =max(ans,cn);
					break;
					}
					if(c[emi] != c[emi-1])
						f ++;
						
				}
			}
			ans =max(ans,cn);
		}
	}

	cout<<n-ans<<endl;


	


}