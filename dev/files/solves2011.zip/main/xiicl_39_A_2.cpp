#define maxn 505
#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <vector>
#include <queue>

using namespace std;

int d[maxn][maxn],a[maxn][maxn];
vector<int> z;
pair<int,int> p[maxn][maxn];
pair<int,int> cur;
int fi,fj,n,m;

int bfs(int si, int sj){
	queue<pair<int,int> > q;
	int vx,vy;

	memset(d,255,sizeof(d));
	
	q.push(make_pair(si,sj)); d[si][sj]=0;
	while (!q.empty()){
		vx=q.front().first; vy=q.front().second; q.pop();	
		if (vx-2>=0 && a[vx-1][vy]==a[vx-2][vy] && d[vx-2][vy]==-1){
			d[vx-2][vy]=d[vx][vy]+1;
			p[vx-2][vy]=make_pair(vx,vy);
			q.push(make_pair(vx-2,vy));
		}
		if (vx+2<n && a[vx+1][vy]==a[vx+2][vy] && d[vx+2][vy]==-1){
			d[vx+2][vy]=d[vx][vy]+1;
			p[vx+2][vy]=make_pair(vx,vy);
			q.push(make_pair(vx+2,vy));
		}
		if (vy-2>=0 && a[vx][vy-1]==a[vx][vy-2] && d[vx][vy-2]==-1){
			d[vx][vy-2]=d[vx][vy]+1;
			p[vx][vy-2]=make_pair(vx,vy);
			q.push(make_pair(vx,vy-2));
		}
		if (vy+2<m && a[vx][vy+1]==a[vx][vy+2] && d[vx][vy+2]==-1){
			d[vx][vy+2]=d[vx][vy]+1;
			p[vx][vy+2]=make_pair(vx,vy);
			q.push(make_pair(vx,vy+2));
		}
	}
	return 0;
}


int main(){
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=0; i<n; i++){
		for (int j=0; j<m; j++) scanf("%d",&a[i][j]);
	}
	scanf("%d%d",&fi,&fj);
	fi--; fj--;
	bfs(0,0);
	if (d[fi][fj]==-1){
		printf("0");
		return 0;
	}
	else{
		printf("%d\n",d[fi][fj]);
		cur=make_pair(fi,fj);
		for (int i=0; i<d[fi][fj]; i++){
			z.push_back(a[cur.first][cur.second]);
			cur=p[cur.first][cur.second];
		}
		for (int i=d[fi][fj]-1; i>=0; i--) printf("%d ",z[i]);
	}
	return 0;
}
