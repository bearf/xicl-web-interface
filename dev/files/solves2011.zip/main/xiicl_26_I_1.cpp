#include <stdio.h>

int count = 0;
char a[54];

void dfs() {
	count++;
	for (int i = 1; i < 51; i++) {
		if (a[i] && a[i-1] == 0) {
			a[i-1]+=2;
			a[i]--;
			dfs();
			a[i]++;
			a[i-2]-=2;
		}
	}
}

int main() {
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long n;
	scanf("%lld",&n);
	int i;
	long long mask=n;
	for(i=0;mask;i++){
		a[i]=mask & 1;
		mask>>=1;
	}
	dfs();
	printf("%d",count);
	return 0;
}
