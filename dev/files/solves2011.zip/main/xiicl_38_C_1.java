import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;

public class Solution implements Runnable {
	
	public void run() {
		long a = nextLong();
		long b = nextLong();
		long x = nextLong();
		long y = nextLong();
		long z = nextLong();
		
		long v1 = x*(x-1)*(b-1)*a/2 + a*x;
		long v2 = a*y + a*y*(y-1)*(b-1)/2 + y*(b-1);
		long v3 = a*z + a*z*(z-1)*(b-1)/2 + z*(b-1);
		long v4 = (a*y-1)*x*a;
		long v5 = (a*x+b*y-y+1-a*z)*(b*z-z+1);
		
		out.println(v1+v2+v3+v4+v5);
		out.flush();
	}
	
	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}
	
	private void loadLine() {
		try{
			stk = new StringTokenizer(br.readLine());
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String nextLine() {
		try {
			return br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private int nextInt() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	private long nextLong() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Long.parseLong(stk.nextToken());
	}

}
