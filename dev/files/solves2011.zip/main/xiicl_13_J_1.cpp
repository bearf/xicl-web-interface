#include <iostream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define X first
#define Y second
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1E9);
const ld PI = acos(-1.0);
const ld EPS = 1E-9;

int n;
vector<int> g[300500];

int go[300500];
int z[3][300500];

int getGo(int v){
    if(sz(g[v]) == 0)
        return -2;
    if(sz(g[v]) == 2)
        return v;
    
    if(go[v] == -1){
        go[v] = getGo(g[v][0]);
    }

    return go[v];
}

int solve(int d, int v){
    if(sz(g[v]) == 0)
        return 0;

    if(z[d][v] == -1){
        if(d == 0 || d == 2){
            if(sz(g[v]) == 1)
                z[d][v] = 0;
            else{
                if(d == 0)
                    z[d][v] = solve(d, g[v][0]) + 1;
                else
                    z[d][v] = solve(d, g[v][1]) + 1;
            }
        }else{
            if(sz(g[v]) == 2)
                z[d][v] = 0;
            else
                z[d][v] = solve(d, g[v][0]) + 1;
        }
    }

    return z[d][v];
}


int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> n;

    forn(i, n){
        int k;
        scanf("%d", &k);

        forn(j, k){
            int x;
            scanf("%d", &x);
            x--;

            g[i].push_back(x);
        }
    }

    memset(go, -1, sizeof(go));
    memset(z, -1, sizeof(z));

    li ans = 0;

    forn(v, n){
        if(sz(g[v]) == 1){
            int u = getGo(v);

            if(u < 0) continue;
            ans += solve(0, u) + solve(2, u);
        }

        if(sz(g[v]) == 2){
            ans += 1 + solve(1, g[v][0]) + solve(1, g[v][1]) + solve(2, g[v][0]) + solve(0, g[v][1]);
        }        
    }

    cout << ans << endl;

    return 0;
}
