import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.TreeSet;


public class Solution implements Runnable {

	private BigInteger a;
	private BigInteger b;

	BigInteger g(BigInteger n) {
		return n.multiply(b.subtract(BigInteger.ONE)).add(BigInteger.ONE);
	}
	
	BigInteger f(BigInteger n) {
		return a.add(b).subtract(BigInteger.ONE).multiply(n).add(a.multiply(n).multiply(n.subtract(BigInteger.ONE)).shiftRight(1));
		
	}
	
	private void solve() throws IOException {
		a = BigInteger.valueOf(nextInt());
		b = BigInteger.valueOf(nextInt());
		BigInteger x = BigInteger.valueOf(nextInt());
		BigInteger y = BigInteger.valueOf(nextInt());
		BigInteger z = BigInteger.valueOf(nextInt());
		
		BigInteger ax = a.multiply(x);
		BigInteger ay = a.multiply(y);
		BigInteger az = a.multiply(z);
		
		
		BigInteger[] S = new BigInteger[6];
		S[0] = BigInteger.ZERO;
		S[1] = ax.multiply(g(x)).subtract(f(x)).add(a.add(b).subtract(BigInteger.ONE).multiply(x));
		S[2] = f(y);
		S[3] = f(z);
		S[4] = (ay.subtract(b)).multiply(ax.max(az.subtract(g(y))));
		
		BigInteger axu = ax.add(g(y));
		
		BigInteger h = axu.subtract(az).abs();
		BigInteger len = BigInteger.ZERO;
		if (axu.compareTo(az) >= 0) {
			len = g(z);
		} else {
			len = g(x);
		}
		S[5] = h.multiply(len);
		
		BigInteger sum = BigInteger.ZERO;
		
//		int pos = 0;
		for (BigInteger i : S) {
//			System.err.println(pos++ + " -> " + i);
			sum = sum.add(i);
		}
		
		out.println(sum);
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		(new Thread(new Solution())).start();
	}

	private BufferedReader br;
	private StringTokenizer st;
	private PrintWriter out;

	@Override
	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			st = new StringTokenizer("");
			if (Boolean.getBoolean("SPbAU")) {
				out = new PrintWriter(System.out);
			} else {
				out = new PrintWriter("output.txt");
			}
			while (hasNext()) {
				solve();
				break;
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}		
	}
	String next() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return null;				
			}
			st = new StringTokenizer(temp);
		}
		return st.nextToken();		
	}
	boolean hasNext() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return false;				
			}
			st = new StringTokenizer(temp);
		}
		return true;		
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
	double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}
	long nextLong() throws IOException {
		return Long.parseLong(next());
	}
	

}
