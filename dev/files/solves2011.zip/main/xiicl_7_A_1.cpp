#include <iostream>
#include <stdio.h>
#include <string>
#include <string.h>
#include<set>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>

using namespace std;
typedef long long li;
typedef pair<int,int> pi;


void solve();
int main(){
#ifdef _DEBUG
	freopen("in.txt","r",stdin);
#else
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	solve();
	return 0;
}
int n,m,a[555][555],x,y;
void solve(){
	
	cin>>n>>m;
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j){
			scanf("%d",&a[i][j]);
		}
	cin>>x>>y;
	if(x%2==0 || y%2==0){
		cout<<0;
		return;
	}
	for(int i=0;i<m+2;++i){
		a[0][i]=-1;
		a[n+1][i]=-1;
	}
	for(int i=0;i<n+2;++i){
		a[i][0]=-1;
		a[i][m+1]=-1;
	}
	vector<int> ans;
	set<pi> was;
	while(x!=1 || y!=1){
		if(was.find(pi(x,y))!=was.end()){
			cout<<0;
			return;
		}
		was.insert(pi(x,y));
		if(a[x][y+1]==a[x][y]){
			
			ans.push_back(a[x][y]);
			y+=2;
			continue;
		}
		if(a[x][y-1]==a[x][y]){
			
			ans.push_back(a[x][y]);
			y-=2;
			continue;
		}
		if(a[x+1][y]==a[x][y]){
			
			ans.push_back(a[x][y]);
			x+=2;
			continue;
		}
		if(a[x-1][y]==a[x][y]){
			ans.push_back(a[x][y]);
			x-=2;
			continue;
		}
	}
	printf("%d\n",ans.size());
	for(int i=ans.size()-1;i>=0;--i){
		printf("%d ",ans[i]);
	}
}