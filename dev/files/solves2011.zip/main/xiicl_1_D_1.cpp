#include <iostream>
#include <string>
using namespace std;

int main()
{
	freopen("input.txt","rt",stdin);
		freopen("output.txt","wt",stdout);
	string s;
	int n;
	scanf("%d\n",&n);
	getline(cin,s);
	int p=0;
	if(s[0]=='a' || s[0]=='e' || s[0]=='i' || s[0]=='o' || s[0]=='u' || s[0]=='y' || s[0]=='A' || s[0]=='E' || s[0]=='I' || s[0]=='O' || s[0]=='U' || s[0]=='Y')
		p=1;
	else
		p=0;
	for(size_t i=1;i<n;i++)
	{
		if(s[i]=='a' || s[i]=='e' || s[i]=='i' || s[i]=='o' || s[i]=='u' || s[i]=='y' || s[i]=='A' || s[i]=='E' || s[i]=='I' || s[i]=='O' || s[i]=='U' || s[i]=='Y')
		{
			if(p==1)
			{
				cout<<"BAD"<<endl;
				return 0;
			}
			p=1;
		}
		else
		{
			if(p==0)
			{
				cout<<"BAD"<<endl;
				return 0;
			}
			p=0;
		}
	}
	cout<<"GOOD"<<endl;
	fclose(stdout);
}
