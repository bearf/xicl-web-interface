#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<climits>
#include<vector>
#include<map>
#include<set>
#include<algorithm>

using namespace std;

#define ws dfgjkhdg
#define y1 sdjghdjg
#define pb push_back
#define mp make_pair
#define fs first
#define sc second

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pi;


bool a[300][300];
vector<int> v,v2;
int n;


void dfs(int u) {
	for (int i=0;i<n;i++) {
		if (!a[u][i]) {
			a[u][i] = true;
			a[i][u] = true;
			dfs(i);
		}
	}
	v2.pb(u);
}


void dfs2(int v) {
	for (int i=0;i<n;i++) {
		if (!a[v][i]) {
			a[v][i] = true;
			a[i][v] = true;
			dfs2(i);
		}
	}
	printf("%d ", v);
}


int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	int x, y;	
	scanf("%d", &n);
	n = 2*n+1;
	x = -1; y = 0;
	while (scanf("%d", &y)==1) {
		v.pb(y);
		if (x!=-1) {
			a[x][y] = true;
			a[y][x] = true;
		}
		x = y;
	}	
	v.pop_back();
	dfs(y);
	reverse(v2.begin(),v2.end());
	for (int i=0;i<(int)v2.size();i++)
		v.pb(v2[i]);
	for (int i=0;i<(int)v.size();i++) {
		dfs2(v[i]);
//		printf("%d ", v[i]);
	}

	printf("\n");
	return 0;
}
