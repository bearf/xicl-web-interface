#include <fstream>
#include <string>
#include <iostream>
#include <map>
#include <queue>
using namespace std;
#define long long long
ifstream in("input.txt");
ofstream out("output.txt");
long ans=0;
long a,b,x,y,z;

int main()
{
	in>>a>>b>>x>>y>>z;
	long bricks =(x+y+z)*(a+b-1);
	long f=(a-1)*x*(b-1)+(b-1)*a*x*(x-1)/2; 
	long s=(a-b)*a*x+a*x*a*(y-1)+(y-1)*y/2*(b-1)*a;

	long h=a*x+(b-1)*(y-1)-(a-b);
	long t=(b-1)*a*z*(z-1)/2;

	long new_h = h - (z-1)*a;
	long wall=0;
	if(new_h>=0)
		wall =(h-(z-1)*a)*((b-1)*z+1);
	else
	{
		wall = -new_h *((b-1)*x+1+(a-b)+(y-1)*a);
	}
	
	//if(wall<0)
	//{
	//	z=h/a;
	//	wall =(h-(z-1)*a)*((b-1)*z+1);
	//}
	ans = f + s + t + wall + bricks;
	out<<ans;
	return 0;
}