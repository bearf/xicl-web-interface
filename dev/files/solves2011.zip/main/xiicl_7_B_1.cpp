#include <iostream>
#include <stdio.h>
#include <string>
#include <string.h>
#include<set>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>

using namespace std;
typedef long long li;
typedef pair<int,int> pi;


void solve();
int main(){
#ifdef _DEBUG
	freopen("in.txt","r",stdin);
#else
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	solve();
	return 0;
}
li fact[300000];
li obr[300000];

const li p=1000000009;
li binpow(li a,li n){
	if(!n)
		return 1;
	if(n&1)
		return (a*binpow(a,n-1))%p;
	return binpow((a*a)%p,n/2);
}
li c(li n,li k){
	return ((fact[n]*obr[k])%p*obr[n-k])%p;
}
void solve(){
	fact[0]=1;
	map<int,int> x;
	for(int i=1;i<250000;++i){
		fact[i]=(fact[i-1]*i)%p;
		//cout<<fact[i]<<endl;
	}
	for(int i=0;i<250000;++i){
		obr[i]=binpow(fact[i],p-2);
	}
	int n,m;
	cin>>n>>m;
	for(int i=0;i<m;++i){
		int a;
		scanf("%d",&a);
		++x[a+1];
	}
	li ans=c(m+n-1,n);
	//cout<<ans<<endl;
	while(true){
		pi cur=*x.begin();
		if(cur.first>n)
			break;
		ans-=(cur.second*c(n-cur.first+m-2,n-cur.first))%p;
		if(ans<0)
			ans+=p;
		x.erase(cur.first);
		x[cur.first+1]+=cur.second;
	}
	cout<<ans;
}