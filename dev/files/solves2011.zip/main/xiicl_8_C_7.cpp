#include<iostream>
#include<fstream>
using namespace std;
int main(){
	ifstream in("input.txt");
	ofstream out("output.txt");
	__int64 a;
	in>>a;
	__int64 b;
	in>>b;
	__int64 x,y,z;
	in>>x>>y>>z;

	__int64 A1=0;
	__int64 h=0;
		A1=a*(x+1)*x*(b-1)/2;
		h=a*x;

	__int64 A2=0;

	A2=(h+1)*a*(y-1)+(b-1)*a*(y-1)*y/2;

	A2+=(h+1)*(a-b)+b-1;
	A2+=(h+1+y*(b-1));

	__int64 A3=0;

	A3=a*(z-1)*z*(b-1)/2+ (b-1)*(z-1);

	A3+=b-1;
	A3+=a*z;

	__int64 A4=0;
	__int64 r1,r2;
	r1=x*a;
	r2=z*a-((y-1)*(b-1)+b);
	if(r1>r2) {
		A4=((z-1)*(b-1)+b)*(r1-r2);
	} else if(r2>r1) {
		A4=(y*a+(x-3)*(b-1)+b+b-2)*(r2-r1);
	}
	out<<A1+A2+A3+A4<<'\n';
	//out<<A1<<' '<<A2<<' '<<A3<<' '<<A4;
	return 0;
}

