#include <cstdio>

long long p[60][60][2];
bool use[60][60][2];

long long calc(int k, int l, int q) {
	if (use[k][l][q])
		return p[k][l][q];
	else 
	{
		use[k][l][q] = 1;
		if (q == 1)
			return p[k][l][1] = calc(k - 1, l, 0) + calc(k - 1, l, 1);
		else
			return p[k][l][0] = calc(k - 1, l, 0);
	}
}

int a[60], c[2];

int main () {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	long long n;
	scanf("%lld", &n);
	int m = 0;
	while (n > 0) {
		a[m] = n & 1;
		n >>= 1;
		m ++;
	}

//	for (int i = 0; i < m; i ++)
//		printf("%d", a[i]);
//	printf("\n");

	for (int i = 0; i < 60; i ++) {
		p[0][i][0] = 1;
		p[0][i][1] = 0;
		p[1][i][0] = i;
		p[1][i][1] = 1;
		use[1][i][0] = 1;
		use[1][i][1] = 1;
		use[0][i][0] = 1;
		use[0][i][1] = 1;
	}

	int stat = 0;
	long long ans[2] = {0, 1};
	long long t[2];
	for (int i = 0; i < m; i ++) {
		if (stat && !a[i]) {
			t[0] = ans[0];
			t[1] = ans[1];
			ans[0] = calc(c[1], c[0], 0) * t[1] + calc(c[1], c[0] + 1, 0) * t[0];
			ans[1] = calc(c[1], c[0], 1) * t[1] + calc(c[1], c[0] + 1, 1) * t[0];
			c[0] = 0;
			c[1] = 0;
		}
		stat = a[i];
		c[stat] ++;
	}

	t[0] = ans[0];
	t[1] = ans[1];
	ans[0] = calc(c[1], c[0], 0) * t[1] + calc(c[1], c[0] + 1, 0) * t[0];
	ans[1] = calc(c[1], c[0], 1) * t[1] + calc(c[1], c[0] + 1, 1) * t[0];

	printf("%lld", ans[0] + ans[1]);
}