import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;

public class Solution implements Runnable {
	
	private void dfs(int v) {
		if (g[v].size() == 0) {
			cnt[v][0] = 0;
			cnt[v][1] = 0;
			cnt[v][2] = 0;
		}
		if (g[v].size() == 1) {
			dfs(g[v].get(0));
			cnt[v][0] = cnt[g[v].get(0)][0] + 1;
			cnt[v][1] = cnt[g[v].get(0)][1];
			cnt[v][2] = cnt[g[v].get(0)][2];
			ans += cnt[v][1]*cnt[v][2];
			
		}
		else if (g[v].size() == 2) {
			dfs(g[v].get(0));
			ans += cnt[g[v].get(0)][0];
			ans += cnt[g[v].get(0)][2];
			
			cnt[v][0] = 0;
			cnt[v][1] = cnt[g[v].get(0)][1] + 1;
			
			dfs(g[v].get(1));
			ans += cnt[g[v].get(1)][0];
			ans += cnt[g[v].get(1)][1];
			cnt[v][2] = cnt[g[v].get(1)][2] + 1;
			ans += 1;
		}
	}
	
	long ans = 0;
	ArrayList<Integer>[] g;
	int n;
	long[][] cnt;
	public void run() {
		n = nextInt();
		cnt = new long[n][3];
		
		g = new ArrayList[n];
		for (int i = 0; i < n; ++i) {
			g[i] = new ArrayList<Integer>();
		}
		
		for (int i = 0; i < n; ++i) {
			int k = nextInt();
			for (int j = 0; j < k; ++j) {
				g[i].add(nextInt()-1);
			}
		}
		
		dfs(0 );
		out.println(ans);
		out.flush();
	}
	
	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}
	
	private void loadLine() {
		try{
			stk = new StringTokenizer(br.readLine());
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String nextLine() {
		try {
			return br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private int nextInt() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	private long nextLong() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Long.parseLong(stk.nextToken());
	}

}
