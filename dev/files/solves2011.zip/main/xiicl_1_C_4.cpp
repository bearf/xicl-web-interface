#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;

	

int main()
{
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	unsigned __int64 a,b,x,y,z,xw,yw,zw,xh,yh,zh;
	cin>>a>>b;
	cin>>x>>y>>z;
	xh=a*x;
	xw=(b-1)*x+1;
	yh=(b-1)*y+1;
	yw=a*y;
	zh=a*z;
	zw=(b-1)*z+1;
	if(xh+yh>=zh)
	{
		unsigned __int64 sl=x*(x-1)/2*a*(b-1)+x*a*b;
		unsigned __int64 sv=y*(y-1)/2*a*(b-1)+(a+b-1)*y;
		unsigned __int64 sr=z*(z-1)/2*a*(b-1)+(a+b-1)*z;
		sr+=(xh+yh-zh)*zw;
		unsigned __int64 ss=(yw-b)*xh;
		unsigned __int64 s=sl+sr+ss+sv;
		cout<<s<<endl;
	}
	else
	{
		unsigned __int64 sl=x*(x-1)/2*a*(b-1)+x*a*b;
		unsigned __int64 sv=y*(y-1)/2*a*(b-1)+(a+b-1)*y;
		unsigned __int64 sr=z*(z-1)/2*a*(b-1)+(a+b-1)*z;
		sl+=(zh-xh-yh)*xw;
		unsigned __int64 ss=(yw-b)*(zh-yh);
		unsigned __int64 s=sl+sr+ss+sv;
		cout<<s<<endl;
	}



	
	


	
	fclose(stdout);
}
