#include <iostream>
#include <cstdio>
#include <string>
using namespace std;


long long n, st[60];
int res;
void pere(int start, long long x)
{
	if(x == 0)
	{
		res++;
		return;
	}
	if(start < 0)	return;
	for(int j = start; j >= 0; j--)
	{
		if(x - st[j + 1] > st[j + 1] - 2)	return;
		if(x >= st[j]  &&  x - st[j] < st[j + 1] - 1) 	pere(j - 1, x - st[j]);
		if(x >= st[j + 1]  &&  x - st[j + 1] < st[j + 1] - 1)	pere(j - 1, x - st[j + 1]);
	}
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> n;
	st[0] = 1;
	for(int i = 1; i < 60; i++)
		st[i] = st[i - 1] * 2;
	pere(58, n);
	cout << res;
	return 0;
}