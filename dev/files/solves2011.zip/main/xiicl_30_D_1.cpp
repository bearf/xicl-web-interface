#include <cstdio>
#include <cstring>
#include <cmath>
#include <set>
#include <map>
#include <algorithm>
#include <vector>
using namespace std;

bool glas(char c){
	return (((c == 'a') || (c == 'e') || (c == 'i') || (c == 'o') || (c == 'u') || (c == 'y')) ||
		((c == 'A') || (c == 'E') || (c == 'I') || (c == 'O') || (c == 'U') || (c == 'Y')));
}

int main(){
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	int n, i;
	char c;
	bool f;
	scanf("%d\n",&n);
	scanf("%c",&c);
	if (glas(c)){
		f = true;
	}else
	{
		f = false;
	}
	for (i = 1;i < n;i++){
		scanf("%c",&c);
		if (f == false){
			if (glas(c)){
				f = true;
			}else
			{
				printf("BAD");
				return 0;
			}
		}else
		{
			if (!glas(c)){
				f = false;
			}else
			{
				printf("BAD");
				return 0;
			}
		}
	}
	printf("GOOD");
	return 0;
}