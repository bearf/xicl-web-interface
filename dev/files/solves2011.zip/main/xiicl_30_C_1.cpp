#include <cstdio>


int main () {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	unsigned long long a, b, x, y, z;

	scanf("%llu%llu%llu%llu%llu", &a, &b, &x, &y, &z);

	unsigned long long s = a * (b - 1) * ((x * (x + 1)) / 2) + y * (a + b - 1) + a * (b - 1) * ((y * (y - 1)) / 2) + (y * a - 1) * x * a + z * (a + b - 1)  + a *  (b - 1) * ((z * (z - 1) / 2));
	long long h;
	if ((h = (a * x + y * (b - 1) + 1 - a * z)) > 0) {
		s += h * (z * (b - 1) + 1);
	}
	else {
		s += -h * (x * (b - 1) + y * a - 1);
	}

	printf("%llu", s);
}