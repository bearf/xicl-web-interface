//#pragma comment("/STACK:64000000")
#include <stdio.h>
#include <string.h>
#include <set>
#include <map>
#include <iostream>
using namespace std;
#define REP(i, a, b) for(int i = (a); i < (b); ++i)
typedef long long ll;

#define MAXN 600

int mm[MAXN][MAXN];
bool used[MAXN * MAXN];
int list[MAXN * MAXN];

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	memset(used, 0, sizeof used);	
	int n, m;
	scanf("%d %d", &n, &m);
	for(int i = 0; i < n; i++) {
		for(int j = 0; j < m; j++) {
			scanf("%d", &mm[i][j]);
		}
	}
	int x, y; scanf("%d %d", &x, &y); x--; y--;
	list[0] = 0;
	while(x != 0 || y != 0) {
		if(x < 0 || x >= n || y < 0 || y >= m) {
			puts("0");
			return 0;
		}
		int t = mm[x][y];
		if(used[t]) {
			puts("0");
			return 0;
		}
		list[++list[0]] = t;
		used[t] = 1;
		if(x && mm[x - 1][y] == mm[x][y]) {
			x -= 2;
		} else if(y && mm[x][y - 1] == mm[x][y]) {
			y -= 2;
		} else if(x < n - 1 && mm[x + 1][y] == mm[x][y]) {
			x += 2;
		} else y += 2;
	}
	printf("%d\n", list[0]);
	for(int i = list[0]; i; i--) {
		printf("%d ", list[i]);
	}
}