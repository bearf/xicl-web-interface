#include <algorithm>
#include <iostream>
#include <string>
#include <cctype>
#include <vector>

#define vv vector
#define mp make_pair
#define px first
#define py second
#define in cin
#define out cout

using namespace std;

bool isVowel(char c)
{
	return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'y' || c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'Y';
}

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int n; string s;
	in >> n >> s;
	for (int i = 0; i < (int) s.length() - 1; ++i) {
		if (isVowel(s[i]) && !isVowel(s[i + 1]) || !isVowel(s[i]) && isVowel(s[i + 1])) {
			continue;
		} else {
			out << "BAD";
			return 0;
		}
	}
	out << "GOOD";
	return 0;
}