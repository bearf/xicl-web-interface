#include <iostream>
#include <cstdio>
#include <string>
using namespace std;


string glas = "aeiouyAEIOUY";

bool check(char h)
{
	for(int i = 0; i < glas.length(); i++)
		if(glas[i] == h)
			return true;
	return false;
}
int n;
string s;


int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> n >> s;
	for(int i = 1; i < s.length(); i++)
		if(check(s[i]) == check(s[i - 1]))
			goto bad;
	cout << "GOOD";
	return 0;
bad:
	cout << "BAD";
	return 0;
}