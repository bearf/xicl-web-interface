#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>

using namespace std;
using std::vector;
using std::string;

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a, b) memset(a, b, sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int,int> pii;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	va_end(args);
	
	fflush(stdout);
#endif
#endif
}


bool doubleEqual(double a, double b)
{
	double eps = 1e-9;
	return fabs(a - b) < eps;
}


double mySqrt(double a)
{
	if(a < 0)
	{
		return 0;
	}
	return sqrt(a);
}


struct Point{

	double x, y;

	void scan()
	{
		scanf("%lf%lf", &x, &y);
	}

	Point(): x(0), y(0) {}

	Point(double x, double y): x(x), y(y) {}

	Point operator+(Point p)
	{
		return Point(x + p.x, y + p.y);
	}

	Point operator-(Point p)
	{
		return Point(x - p.x, y - p.y);
	}

	double operator%(Point p)
	{
		return x * p.x + y * p.y;
	}

	double operator*(Point p)
	{
		return x * p.y - y * p.x;
	}

	double length()
	{
		return mySqrt(*this % *this);
	}

	double distTo(Point p)
	{
		return (*this - p).length();
	}


	Point operator*(double k)
	{
		return Point(x * k, y * k);
	}

	Point operator/(double k)
	{
		return Point(x / k, y / k);
	}

	double distTo(Point A, Point B)
	{
		Point C = *this;
		double s = (A - C) * (B - C);
		double d = A.distTo(B);
		double h = fabs(s) / d;
		return h;
	}

	Point rotate()
	{
		return Point(-y, x);
	}

	Point normalize(double k = 1)
	{
		double len = length();
		if(doubleEqual(len, 0) )
		{
			return Point();
		}
		return *this * k / len;
	}

	void print()
	{
		printf("%.10lf %.10lf\n", x, y);
	}

};


bool getIntersect(Point A, Point B, Point C, Point D, Point & M)
{
	double s1 = (C - A) * (D - A);
	double s2 = (D - B) * (C - B);
	double s = s1 + s2;
	if(doubleEqual(s, 0) )
	{
		return false;
	}                
	Point v = B - A;
	v = v / s;
	v = v * s1;
	M = A + v;
	return true;
}


const int maxN = 110;
Point p[maxN], A, B;
Point v[maxN], u[maxN];
Point L[maxN], R[maxN];
double LL;
int n, len;
pair<int, pair<int, int> > r[maxN];
vector<Point> ans;
bool inv;


int sgn(double a)
{
	if(doubleEqual(a, 0))
	{
		return 0;
	}
	if(a < 0)
	{
		return -1;
	}
	return 1;
}


int intersect(Point A, Point B, Point C, Point D)
{
	return sgn( (B - A) * (C - A) ) * sgn( (B - A) * (D - A) );
}


void addEdge(int i)
{
	double y0 = r[i].first, y1 = r[i].second.first, yr = r[i].second.second;
	Point P = Point(0, y0);
	Point Q = Point(0, y1);
	Point T = Point(LL, yr);
	p[len] = P;
	u[len] = T - P;
	double h = Q.distTo(P, T);
	v[len] = u[len].rotate().normalize(h);	
	if(intersect(P, T, A, B) < 0)
	{
		if(len == 0 && u[len] * (A - p[len]) > 0)
		{
			inv = true;
			swap(A, B);
		}              		
		len++;
	}
}


void addPoint(Point p)
{
	ans.push_back(p);
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	A.scan();
	B.scan();
	scanf("%lf%d", &LL, &n);
	for(int i = 0; i < n; i++)
	{
		scanf("%d%d%d", &r[i].first, &r[i].second.first, &r[i].second.second);
	}
	sort(r, r + n);
	for(int i = 0; i < n; i++)
	{
		addEdge(i);
	}
	dbg("%d\n", len);
	n = len;
	for(int i = n - 1; i >= 0; i--)
	{
		B = B - v[i];
		for(int j = i + 1; j < n; j++)
		{
			p[j] = p[j] - v[i];
		}
	}
	double res = A.distTo(B);
	for(int i = 0; i < n; i++)
	{
		if(!getIntersect(A, B, p[i], p[i] + u[i], L[i]) )
		{
			throw 42;
		}
		res += v[i].length();
	}
	for(int i = 0; i < n; i++)
	{
    	for(int j = i + 1; j < n; j++)
    	{
    		L[j] = L[j] + v[i];
    	}
	}
	for(int i = 0; i < n; i++)
	{
		R[i] = L[i] + v[i];
	}
	printf("%.10lf\n", res);
	for(int i = 0; i < n; i++)
	{
		addPoint(L[i]);
		addPoint(R[i]);
	}
	if(inv)
	{
		reverse(ans.begin(), ans.end());
	}
	for(int i = 0; i < ans.size(); i++)
	{
		ans[i].print();
	}
	return 0;
}