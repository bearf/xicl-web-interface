#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <cmath>

#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include <numeric>

#define ALL(c) (c).begin(), (c).end()
#define sz(c) ((int)(c).size())

#define REP(i, n) for (int i = 0; i < (n); ++i)
#define FOR(i, s, n) for (int i = (s); i < (n); ++i)

#define mp make_pair
#define pb push_back

using namespace std;

typedef long long ll;

const int inf = int(1e+9);
const int magic = 1000;

struct Edge
{
  Edge( int to, int cap, int we )
    : to(to)
    , cf(cap)
    , we(we)
    , bi(-1)
  {}

  int to, cf, we, bi;
};

struct Graph
{
  Graph( int vn ) : edl(vn) {}

  void addEdge( int a, int b, int we )
  {
    //assert(a != b);

    edl[a].pb(Edge(b, 1,  we));
    edl[b].pb(Edge(a, 0, -we));
    edl[a].back().bi = sz(edl[b]) - 1;
    edl[b].back().bi = sz(edl[a]) - 1;
  }

  bool fordBellman( int s, int t )
  {
    fill(ALL(dist), +inf);
    fill(ALL(prev), -1);
    dist[s] = 0;
    for (bool run = true; run; )
    {
      run = false;
      REP(v, sz(edl))
        for (vector<Edge>::iterator e = edl[v].begin(); e != edl[v].end(); ++e)
          if (e->cf != 0)
          {
            int ncost = dist[v] + e->we;
            if (dist[e->to] > ncost)
            {
              dist[e->to] = ncost;
              prev[e->to] = e->bi;
              run = true;
            }
          }
    }

    return dist[t] != +inf;
  }

  void minCost( int s, int t )
  {
    //assert(s != t);

    dist.resize(sz(edl));
    prev.resize(sz(edl));
    while (fordBellman(s, t))
    {
      for (int v = t; prev[v] != -1; )
      {
        Edge& be = edl[v][prev[v]];

        be.cf++;
        edl[be.to][be.bi].cf--;

//		fprintf(stderr, "%d ", v);

        v = be.to;

        //assert(prev[v] != -1 || v == s);
      }

//      fprintf(stderr, "%d\n", s);
    }
//    fprintf(stderr, "\n");
  }

  vector<vector<Edge> > edl;
  vector<int> dist, prev;
};


int main()
{
  freopen("input.txt", "rt", stdin);
  freopen("output.txt", "wt", stdout);

  int n, m, k;
  while (scanf("%d%d%d", &n, &m, &k) == 3)
  {
    int globAns = 0;

    vector<int> weight(n, 0);
    REP(i, k)
    {
      int a;
      scanf("%d", &a), a--;
      if (a == 0)
        globAns++;
      else
        weight[a]++;
    }

    int L = 0;
    int R = n;
    int s = 2 * n;
    int t = 2 * n + 1;
    Graph g(2 * n + 2);

    FOR(i, 1, n)
      g.addEdge(L + i, R + i, -magic * weight[i]);
    REP(iter, m)
    {
      int a, b;
      scanf("%d%d", &a, &b), a--, b--;
      //assert(a != 0 || b != 0);
      //assert(a != b);

      if (a == 0)
      {
        g.addEdge(s, L + b, 0);
        g.addEdge(L + b, t, 0);
      }
      else if (b == 0)
        g.addEdge(R + a, t, 1);
      else
        g.addEdge(R + a, L + b, 0);
    }

    g.minCost(s, t);

    int walks = 0;
    REP(v, sz(g.edl))
      for (vector<Edge>::iterator e = g.edl[v].begin(); e != g.edl[v].end(); ++e)
      {
        if (e->cf == 0 && (R <= v && v < R + n) && e->to == t)
          walks++;
        else if (e->cf == 0 && (L <= v && v < L + n) && (R <= e->to && e->to < R + n))
          globAns += e->we / (-magic);
      }

    printf("%d %d\n", globAns, walks);
  }
  
  return 0;
}
