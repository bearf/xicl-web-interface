import java.io.*;
import java.util.*;

public class Solution implements Runnable {

	HashMap<Long, Long> hm = new HashMap<Long, Long>();

	long get(long n) {
		if (n == 1 || n == 0)
			return 1;
		Long res = hm.get(n);
		if (res != null)
			return res;
		long ret;
		if ((n & 1) == 1)
			ret = get(n >> 1);
		else
			ret = get(n >> 1) + get((n >> 1) - 1);
		hm.put(n, ret);
		return ret;
	}

	void solve() throws IOException {
		long n = nextLong();
		out.println(get(n));
	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			out = new PrintWriter("output.txt");
			st = new StringTokenizer("");
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
