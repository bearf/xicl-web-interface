program JJ_Mybabe;
{$MAXSTACKSIZE $32000000}
{$APPTYPE CONSOLE}
{$O-} {$R+} {$Q+}

uses
  SysUtils,
  Math;

type
  int = longint;
  itneger = int;
  itn64 = int64;
  itenger = int;
  var n, i : integer;
      love, dest : boolean;
      s : string;
  const odd : array[1..12] of char = ('a', 'e', 'i', 'o', 'u', 'y', 'A', 'E', 'I', 'O', 'U', 'Y');
function f(c : char) : boolean;
var i : integer;
begin
  result := false;
  for i := 1 to 12 do
    if c = odd[i] then
      result := true;
end;
procedure pt(s : string);
begin
  writeln(s);
  halt(0);
end;
begin
  Reset(Input, 'input.txt');
 Rewrite(Output, 'output.txt');
  readln(n);
  readln(s);
  for i := 1 to length(S) - 1 do
  begin
    love:=f(s[i]);
    dest:= f(s[i + 1]);
    if dest = love then
      pt('BAD');
  end;
  pt('GOOD');


  Close(Input);
  Close(Output);
end.