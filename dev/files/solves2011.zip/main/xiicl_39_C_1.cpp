#define maxn 
#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <vector>
#include <queue>

using namespace std;

long long a,b,x,y,z;
long long h1,h2,h3,w1,w2,w3,s1,s2,s3,s4,s5;

int main(){
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	cin >> a >> b;
	cin >> x >> y >> z;

	h1=a*x; w1=(b-1)*x+1;
	h2=(b-1)*y+1; w2=a*y;
	h3=a*z; w3=(b-1)*z+1;

	s1=((h1+a)*(w1-1))/2+h1;

	s2=w2+((w2-a+2)*(h2-1))/2;

	s3=h3+((h3-a+2)*(w3-1))/2;

	s4=(w2-b)*max(a*x,a*z-h2);

	if (h3<h1+h2) s5=(h1+h2-h3)*w3;
	else          s5=(h3-h1-h2)*w1;

	cout << s1+s2+s3+s4+s5;
	return 0;
}
