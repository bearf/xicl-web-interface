#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;
struct str
{
	int p[500][500], x, y;
};
struct ans
{
	int count;
	vector <int> k;
};
ans res[500][500];
str s[101];
int n, m, size;
int step[4][2] = {{0, -2}, {0, 2}, {2, 0}, {-2, 0}};


int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> n >> m;
	size = 1;
	for(int i = 0; i < n; i++)
		for(int j = 0; j < m; j++)
		{
			res[i][j].count = -1;
			cin >> s[0].p[i][j];
			if(s[0].p[i][j] == 0)
			{
				res[i][j].count = 0;
				s[0].x = i;
				s[0].y = j;
			}
		}
	for(int u = 0; u != size; u++)
	{
		for(int k = 0; k < 4; k++)
		{
			if(s[u].x + step[k][0] >= 0  &&  s[u].x + step[k][0] < n  &&
				s[u].y + step[k][1] >= 0  &&  s[u].y + step[k][1] < m  &&
				s[u].p[s[u].x + (step[k][0] / 2)][s[u].y + (step[k][1] / 2)] == s[u].p[s[u].x + step[k][0]][s[u].y + step[k][1]]  &&
				res[s[u].x + step[k][0]][s[u].y + step[k][1]].count == -1)
			{
				int tempx = s[u].x + step[k][0], tempy = s[u].y + step[k][1];
				res[tempx][tempy] = res[s[u].x][s[u].y];
				res[tempx][tempy].count++;
				res[tempx][tempy].k.push_back(s[u].p[tempx][tempy]);
				s[size] = s[u];
				size++;
				swap(s[size - 1].p[s[u].x][s[u].y], s[size - 1].p[tempx][tempy]);
				s[size - 1].x = tempx;
				s[size - 1].y = tempy;
				if(size == 101)	size = 0;
			}
		}
	}
	cin >> n >> m;
	n--; m--;
	cout << res[n][m].k.size() << endl;
	for(int j = 0; j < res[n][m].k.size(); j++)
		cout << res[n][m].k[j] << ' ';
	return 0;
}