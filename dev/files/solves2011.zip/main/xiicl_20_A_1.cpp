#include <stdio.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <string.h>
#include <string>
#include <set>
#include <map>
#include <algorithm>
using namespace std;

const int MaxN = 510;

int a[MaxN][MaxN];

struct TQueElm
{
	int x;
	int y;
	int num;
	int step;
	int prev;

	TQueElm( int _x = 0, int _y = 0, int _num = 0, int _step = 0, int _prev = 0 )
	{
		x = _x;
		y = _y;
		num = _num;
		step = _step;
		prev = _prev;
	}
};

struct TQueElm2
{
	int x;
	int y;
	int num;

	TQueElm2( int _x = 0, int _y = 0, int _num = 0 )
	{
		x = _x;
		y = _y;
		num = _num;
	}

	bool operator < (const TQueElm2& elm) const
	{
		if( x < elm.x ) return true;
		if( x > elm.x ) return false;

		if( y < elm.y ) return true;
		if( y > elm.y ) return false;

		if( num < elm.num ) return true;
		if( num > elm.num ) return false;
		return false;
	}
};


int main()
{
	freopen( "input.txt", "r", stdin );
	freopen( "output.txt", "w", stdout );
	int n, m;
	scanf( "%d%d", &n, &m );
	for( int i = 0; i < n; i++ ) {
		for( int j = 0; j < m; j++ ) {
			scanf( "%d", &a[i][j] );
		}
	}
	int fx, fy;
	scanf( "%d%d", &fx, &fy );
	fx--; fy--;

	int qe = 1, qb = 0;
	vector <TQueElm> que;
	set <TQueElm2> hash;
	que.clear();
	hash.clear();

	que.push_back( TQueElm( 0, 0, -1, 0, -1 ) );
	hash.insert( TQueElm2( 0, 0, -1 ) );

	while( qb < qe ) {
		const int Direct[4][2] = { {1, 0}, {0, 1},
		{-1, 0}, {0, -1} };
		for( int i = 0; i < 4; i++ ) {
			int cx = que[qb].x + Direct[i][0];
			int cy = que[qb].y + Direct[i][1];

			if( cx >= 0 && cy >= 0 && cx < n && cy < m &&
				a[cx][cy] != a[que[qb].x][que[qb].y] ) 
			{
				int tx = cx + Direct[i][0];
				int ty = cy + Direct[i][1];
				if( tx >= 0 && ty >= 0 && tx < n && ty < m &&
					a[tx][ty] == a[cx][cy] &&
					hash.count( TQueElm2( tx, ty, a[tx][ty] ) ) == 0 )
				{
					qe++;

					que.push_back( TQueElm( tx, ty, a[tx][ty], 
						que[qb].step +1, qb ) );
					hash.insert( TQueElm2( tx, ty, a[tx][ty] ) );

					if( tx == fx && ty == fy ) 
					{
						vector<int> ans;
						int ptr = que.size() - 1;
						ans.clear();
						while( ptr != 0 ) {
							ans.push_back( que[ptr].num );
							ptr = que[ptr].prev;
						}

						reverse( ans.begin(), ans.end() );
						printf("%d\n", ans.size());
						for( int i = 0; i < ans.size(); i++ ) {
							printf("%d ",ans[i]);
						}
						printf("\n");

						return 0;
					}
				}
			}
		}
		qb++;
	}

	printf("0\n");
	return 0;
}

