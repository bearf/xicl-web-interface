#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<climits>
#include<vector>
#include<map>
#include<set>
#include<algorithm>

using namespace std;

#define ws dfgjkhdg
#define y1 sdjghdjg
#define pb push_back
#define mp make_pair
#define fs first
#define sc second

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pi;
const int md=((int)1e9)+9;
int ppow(int tk,int st){
	if (st==0) return 1;
	ll ans=ppow(tk,st/2);
	ans=(ans*ans)%md;
	if (st%2==1)
		ans=(ans*tk)%md;
	return ans;
}
int obr(int a){
	return ppow(a,md-2);
}
ll f[1000000];
ll o[1000000];

int cnk(int n,int k){
	if (n<0 || k<0 || k>n) return 0;
	return (((f[n]*o[k])%md)*o[n-k])%md;
}
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int n,m,x;
	f[0]=1;
	for (int i=1;i<=201000;i++)
		f[i]=(f[i-1]*i)%md;
	for (int i=0;i<=201000;i++){
		o[i]=obr(f[i]);
	}
	scanf("%d%d",&n,&m);
	ll ans=cnk(m+n-1,m-1);
	for (int i=0;i<m;i++){
		scanf("%d",&x);
		ans=(ans-cnk(m-2+n-x,m-1)+md)%md;
	}
	cout<<ans<<endl;
	return 0;
}
