#include <fstream>
#include <string>
#include <iostream>
#include <map>
#include <queue>
using namespace std;
#define long long long
ifstream in("input.txt");
ofstream out("output.txt");
const int MAX = 502;
int data[MAX][MAX];
int n,m;
int nx, ny;
const int INF = 1000000000;
queue<pair<int, int> > q;
vector<int> d, col;
vector<pair<int, int> >  pr;

int ind(int x, int y)
{
	return y*n+x;
}

int main()
{
	in>>m>>n;
	
	for(int y=0;y<m;y++)
		for(int x=0;x<n;x++)
			in>>data[y][x];
	in>>ny>>nx;
	nx--, ny--;
	q.push(make_pair(0,0));
	d.assign(m*n, INF);
	pr.assign(m*n, make_pair(-1, -1));
	col.resize(m*n);
	d[0] = 0;
	while(!q.empty())
	{
		int x = q.front().first, y = q.front().second;
		if(x==nx && y==ny)
			break;
		q.pop();
		if(y>=2 && data[y-1][x]==data[y-2][x] && d[ind(x, y-2)]>d[ind(x, y)]+1)
		{
			d[ind(x, y-2)]=d[ind(x, y)]+1;
			pr[ind(x, y-2)] = make_pair(x, y);
			col[ind(x,y-2)] = data[y-1][x];
			q.push(make_pair(x, y-2));
		}
		if(y<m-2 && data[y+1][x]==data[y+2][x] && d[ind(x, y+2)]>d[ind(x, y)]+1)
		{
			d[ind(x, y+2)]=d[ind(x, y)]+1;
			pr[ind(x, y+2)] = make_pair(x, y);
			col[ind(x,y+2)] = data[y+1][x];
			q.push(make_pair(x, y+2));
		}

		if(x>=2 && data[y][x-1]==data[y][x-2] && d[ind(x-2, y)]>d[ind(x, y)]+1)
		{
			d[ind(x-2, y)]=d[ind(x, y)]+1;
			pr[ind(x-2, y)] = make_pair(x, y);
			col[ind(x-2,y)] = data[y][x-1];
			q.push(make_pair(x-2, y));
		}
		if(x<n-2 && data[y][x+1]==data[y][x+2] && d[ind(x+2, y)]>d[ind(x, y)]+1)
		{
			d[ind(x+2, y)]=d[ind(x, y)]+1;
			pr[ind(x+2, y)] = make_pair(x, y);
			col[ind(x+2,y)] = data[y][x+1];
			q.push(make_pair(x+2, y));
		}
	}
	int curx=nx, cury=ny;
	if(d[ind(nx, ny)]==INF)
	{
		out<<0;
	}
	else
	{
		vector<int> ccc;
		while(curx!=0 || cury!=0)
		{
			ccc.push_back(col[ind(curx, cury)]);
			int tx=pr[ind(curx,cury)].first;
			int ty=pr[ind(curx,cury)].second;
			curx=tx;
			cury=ty;
		}
		out<<ccc.size()<<endl;
		for(int i=ccc.size()-1; i>=0; i--)
			out<<ccc[i]<<" ";
	}
	return 0;
}