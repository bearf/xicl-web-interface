#include <cstdio>

struct st{
  long long a,b;
};

st gcd(long long x, long long y){
 	st xx,yy;
 	xx.a=yy.b=1;
 	xx.b=yy.a=0;
 	while(true){
 	 	if(x==0)
 	 		return yy;
 	 	if(y==0)
 	 		return xx;
 	 	if(x>y){
 	 		long long g=x/y;
 	 		x-=y*g;
 	 		xx.a-=yy.a*g;
 	 		xx.b-=yy.b*g;
 	 	}else{
 	 		long long g=y/x;
 	 		y-=x*g;
 	 		yy.a-=xx.a*g;
 	 		yy.b-=xx.b*g;
 	 	}
 	}
}

const int inf = 1000000009;

int neg(int n) {
	return ((gcd(n, inf).a % inf) + inf) % inf;
}

int c[200000];

int main () {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int n, m, x;

	scanf("%d%d", &n, &m);
	for (int i = 0; i < m; i ++) {
		scanf("%d", &x);
		c[x + 1] ++;
	}

	int count = 0;
	unsigned long long ans = 1;
	for (int i = 1; i < m; i ++) {
		ans = (((ans * (n + m - i)) % inf) * neg(i)) % inf;
	}

	if (m == 1) {
		for (int i = 1; i < n; i ++) {
			if (c[i - 1]) {
				printf("0");
				return 0;
			}
		}
	}

  unsigned long long C = (((ans * (m - 1)) % inf) * neg(n + m - 1)) % inf;
	for (int i = 1; i <= n; i ++) {
		count += c[i];
		C = (((C * (n - i + 1)) % inf) * neg((n - i + 1) + m - 2)) % inf;
		ans = (ans - (count * C) % inf + inf) % inf;
	}

	printf("%llu", ans);
	
	return 0;
}