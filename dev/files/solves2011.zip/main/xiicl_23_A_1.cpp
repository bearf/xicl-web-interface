#include <fstream>
#include <string>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");

struct Point {
	int x,y;
};
Point pos[130000][2];
int d[130000][4];
Point och[130000];
Point fr[130000][4];
int ans[130000];
int ukR,ukW;
int a[510][510];
int n,m;

int res(int i, int j) {
	if (i < 1 || j < 1 || i > m || j > n) return -1;
	return a[i][j];
}

void InSearch(int k) {
	int num = och[k].x;
	int type = och[k].y;
	int ntype;
	Point emp;
	if (pos[num][0].x == pos[num][1].x) {
		if (type == 0) emp = pos[num][0]; else emp = pos[num][1];
	} else {
		if (type == 1) emp = pos[num][0]; else emp = pos[num][1];
	}
	if (k == 0) {
		emp.x = 1; emp.y = 1;
	}
	if (res(emp.x-1, emp.y) > 0 && res(emp.x-1,emp.y) != num) {
		ntype = -1;
		if ((emp.x == pos[res(emp.x-1, emp.y)][0].x) && (emp.x == pos[res(emp.x-1, emp.y)][1].x)) {
			if (emp.y > pos[res(emp.x-1, emp.y)][0].y) ntype = 0; else ntype = 2;
		}
		if ((emp.y == pos[res(emp.x-1, emp.y)][0].y) && (emp.y == pos[res(emp.x-1, emp.y)][1].y)) {
			if (emp.x > pos[res(emp.x-1, emp.y)][0].x) ntype = 1; else ntype = 3;
		}
		if (ntype != -1 && d[res(emp.x-1, emp.y)][ntype] == 0) {
			d[res(emp.x-1, emp.y)][ntype] = d[num][type]+1;
			fr[res(emp.x-1, emp.y)][ntype].x = num;
			fr[res(emp.x-1, emp.y)][ntype].y = type;
			och[ukW].x = res(emp.x-1, emp.y);
			och[ukW].y = ntype;
			ukW++;
		}
	}
	if (res(emp.x, emp.y-1) > 0 && res(emp.x,emp.y-1) != num) {
		ntype = -1;
		if ((emp.x == pos[res(emp.x, emp.y-1)][0].x) && (emp.x == pos[res(emp.x, emp.y-1)][1].x)) {
			if (emp.y > pos[res(emp.x, emp.y-1)][0].y) ntype = 0; else ntype = 2;
		}
		if ((emp.y == pos[res(emp.x, emp.y-1)][0].y) && (emp.y == pos[res(emp.x, emp.y-1)][1].y)) {
			if (emp.x > pos[res(emp.x, emp.y-1)][0].x) ntype = 1; else ntype = 3;
		}
		if (ntype != -1 && d[res(emp.x, emp.y-1)][ntype] == 0) {
			d[res(emp.x, emp.y-1)][ntype] = d[num][type]+1;
			fr[res(emp.x, emp.y-1)][ntype].x = num;
			fr[res(emp.x, emp.y-1)][ntype].y = type;
			och[ukW].x = res(emp.x, emp.y-1);
			och[ukW].y = ntype;
			ukW++;
		}
	}
	if (res(emp.x+1, emp.y) > 0 && res(emp.x+1,emp.y) != num) {
		ntype = -1;
		if ((emp.x == pos[res(emp.x+1, emp.y)][0].x) && (emp.x == pos[res(emp.x+1, emp.y)][1].x)) {
			if (emp.y > pos[res(emp.x+1, emp.y)][0].y) ntype = 0; else ntype = 2;
		}
		if ((emp.y == pos[res(emp.x+1, emp.y)][0].y) && (emp.y == pos[res(emp.x+1, emp.y)][1].y)) {
			if (emp.x > pos[res(emp.x+1, emp.y)][0].x) ntype = 1; else ntype = 3;
		}
		if (ntype != -1 && d[res(emp.x+1, emp.y)][ntype] == 0) {
			d[res(emp.x+1, emp.y)][ntype] = d[num][type]+1;
			fr[res(emp.x+1, emp.y)][ntype].x = num;
			fr[res(emp.x+1, emp.y)][ntype].y = type;
			och[ukW].x = res(emp.x+1, emp.y);
			och[ukW].y = ntype;
			ukW++;
		}
	}
	if (res(emp.x, emp.y+1) > 0 && res(emp.x,emp.y+1) != num) {
		ntype = -1;
		if ((emp.x == pos[res(emp.x, emp.y+1)][0].x) && (emp.x == pos[res(emp.x, emp.y+1)][1].x)) {
			if (emp.y > pos[res(emp.x, emp.y+1)][0].y) ntype = 0; else ntype = 2;
		}
		if ((emp.y == pos[res(emp.x, emp.y+1)][0].y) && (emp.y == pos[res(emp.x, emp.y+1)][1].y)) {
			if (emp.x > pos[res(emp.x, emp.y+1)][0].x) ntype = 1; else ntype = 3;
		}
		if (ntype != -1 && d[res(emp.x, emp.y+1)][ntype] == 0) {
			d[res(emp.x, emp.y+1)][ntype] = d[num][type]+1;
			fr[res(emp.x, emp.y+1)][ntype].x = num;
			fr[res(emp.x, emp.y+1)][ntype].y = type;
			och[ukW].x = res(emp.x, emp.y+1);
			och[ukW].y = ntype;
			ukW++;
		}
	}
}
int main() {
	int p;
	memset(pos, 0, sizeof(pos));
	memset(d, 0, sizeof(d));
	cin >> m >> n;
	p = 0;
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= n; j++) {
			cin >> a[i][j];
			if (pos[a[i][j]][0].x == 0) {
				pos[a[i][j]][0].x = i;
				pos[a[i][j]][0].y = j;
			} else {
				pos[a[i][j]][1].x = i;
				pos[a[i][j]][1].y = j;
			}
			if (a[i][j] > p) p = a[i][j];
		}
	}
    ukR = 0;
	ukW = 1;
	while (ukR < ukW) {
		InSearch(ukR);
		ukR++;
	}
	int x,y;
	cin >> x >> y;
	int min = -1;
	for (int i = 0; i < 4; i++) {
		if (pos[a[x][y]][0].x == pos[a[x][y]][1].x) {
			if (y == pos[a[x][y]][0].y) {
				min = 0;
			} else {
				min = 2;
			}
		} else {
			if (x == pos[a[x][y]][0].x) {
				min = 1;
			} else {
				min = 3;
			}
		}
	}
	if (d[a[x][y]][min] == 0) min = -1;
	if (min == -1) {
		cout << "0";
		return 0;
	}
	cout << d[a[x][y]][min] << "\n";
	int nx,ny;
	nx = a[x][y]; ny = min;
	p = 0;
	while (nx !=0) {
		ans[p] = nx; p++;
		x = fr[nx][ny].x; y = fr[nx][ny].y;
		nx = x; ny = y;
	}
	for (int i =p-1; i >= 0; i--) cout << ans[i] << " ";
	return 0;
}