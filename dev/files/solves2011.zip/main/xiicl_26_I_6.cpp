#include <stdio.h>

int count = 0;
char a[54];

void dfs(int k, int p) {
	if (k==-1) {
		count++;
		for (int i = p; i > 0; i--) {
			if (a[i]) {
				a[i-1]+=2;
				a[i]--;
				if (a[i-1]>2) {
					dfs(i-1,i-1);
				} else {
					dfs(-1,i-1);
				}
				a[i]++;
				a[i-1]-=2;
			}
		}
	} else {
		if (k == 0 || a[k] > 3) return;
		a[k-1] += 2;
		a[k]--;
		if (a[k-1] > 2) {
			dfs(k-1,k-1);
		} else {
			dfs(-1,k-1);
		}
		a[k]++;
		a[k-1] -= 2;
	}
}

int main() {
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long n;
	scanf("%lld",&n);
	int i;
	long long mask=n;
	for(i=0;mask;i++){
		a[i]=mask & 1;
		mask>>=1;
	}
	dfs(-1,50);
	printf("%d",count);
	return 0;
}
