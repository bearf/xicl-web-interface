import java.io.*;
import java.util.*;

public class Solution implements Runnable {

	int[][] e;
	int[] p;
	int n;
	int[] left, right, down;
	int[] downTo;
	long ans;

	void solve() throws IOException {
		n = nextInt();
		e = new int[n][];
		p = new int[n];
		Arrays.fill(p, -1);
		for (int i = 0; i < n; i++) {
			int cnt = nextInt();
			e[i] = new int[cnt];
			for (int j = 0; j < cnt; j++) {
				int v = nextInt() - 1;
				e[i][j] = v;
				p[v] = i;
			}
		}
		int root = -1;
		for (int i = 0; i < n; i++) {
			if (p[i] == -1) {
				root = i;
			}
		}
		left = new int[n];
		right = new int[n];
		down = new int[n];
		downTo = new int[n];
		ans = 0;
		dfs(root);
		// System.err.println(root);
		// for (int i = 0; i < n; i++) {
		// System.err.println(Arrays.toString(e[i]) + " " + left[i] + " "
		// + right[i] + " " + down[i] + " " + downTo[i]);
		// }
		// System.err.println(Arrays.toString(down));
		out.println(ans);

	}

	void dfs(int u) {
		if (e[u].length == 0) {
			downTo[u] = u;
			return;
		}
		if (e[u].length == 1) {
			int v = e[u][0];
			dfs(v);
			down[u] = down[v] + 1;
			downTo[u] = downTo[v];
			int cnt1 = left[downTo[u]];
			int cnt2 = right[downTo[u]];
			ans += cnt1 + cnt2;
			return;
		}
		int l = e[u][0];
		int r = e[u][1];
		dfs(l);
		dfs(r);
		ans++;
		downTo[u] = u;
		left[u] = left[l] + 1;
		right[u] = right[r] + 1;
		ans += left[r] + down[r];
		ans += right[l] + down[l];
	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			out = new PrintWriter("output.txt");
			st = new StringTokenizer("");
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
