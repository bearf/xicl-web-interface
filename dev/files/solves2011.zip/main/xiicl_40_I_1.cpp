#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <utility>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <cstring>

using namespace std;

long long a[100][2];


int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
  long long n;
  cin >> n;
  
  memset (a, 0, sizeof (a));
  long long res = 0;
  a[0][1] = 1;
  int i=0;
  while (n > 0) {
    i++;
    if (n%2 == 1) {
      a[i][1] = a[i-1][0] + a[i-1][1];
      a[i][0] = a[i-1][0];
    }
    else {
      a[i][1] = 0;
      a[i][0] = a[i-1][0] + a[i-1][1];
    }
    n /= 2;
  }
  cout << a[i][1] + a[i][0];

  return 0;
}