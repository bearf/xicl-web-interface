#include<iostream>
#include<fstream>
using namespace std;
int *getBinary(__int64 a){
	int *b=new int[64];
	int c[64];
	for(int i=0;i<64;i++){
		b[i]=0;
	}
	int count=0;
	while(a!=0){
		c[count]=a%2;
		a=(a-a%2)/2;
		count++;
	}
	for(int i=0;i<count;i++){
		b[63-i]=c[i];
	}
	return b;
}
void rec(int *a,int n,int &c,int i){
	if(i<n-1){
		if(a[i]==1){
			if(a[i+1]==1){
				if(i+2>=n){
					return;
				}
				if(a[i+2]>1){
					return;
				}
				if(a[i+2]==0){
					a[i]=0;
					a[i+1]=2;
					a[i+2]=2;
					c++;
				}
				if(a[i+2]==1){
					if(i+3>n-1){
						return;
					}
					if(a[i+3]!=0){
						return;
					}
					a[i]=0;
					a[i+1]=2;
					a[i+2]=2;
					a[i+3]=2;
				}
			}
			if(a[i+1]==0){
				a[i+1]=2;
				a[i]=0;
				c++;
			}
		}
		if(a[i]==2){
			if(a[i+1]==1){
				if(i+2>=n){
					return;
				}
				if(a[i+2]>1){
					return;
				}
				int *d=new int[n];
				for(int j=0;j<n;j++){
					d[j]=a[j];
				}
				rec(a,n,c,i+1);
				for(int j=0;j<n;j++){
					a[j]=d[j];
				}
				a[i]=1;
				a[i+1]=2;
				a[i+2]=2;
				c++;
			}
			if(a[i+1]==0){
				a[i]=1;
				a[i+1]=2;
				c++;
			}
		}
		rec(a,n,c,i+1);
	}
}
int main(){
	__int64 n;
	int *a;
	int count=64;
	ifstream in("input.txt");
	ofstream out("output.txt");
	in>>n;
	a=getBinary(n);
	int N=0;
	for(int i=0;i<count;i++){
		if(a[i]!=0){
			break;
		}
		N++;
	}
	int *r=new int[count-N];
	int index=N;
	N=count-N;
	for(int i=0;i<N;i++){
		r[i]=a[i+index];
	}
	int *k=new int[N];
	for(int i=0;i<N;i++){
		k[i]=r[i];
	}
	int c=1;
	if(N==1){
		out<<1;
		return 0;
	}
	for(int i=N-2;i>=0;i--){
		rec(k,N,c,i);
		for(int j=0;j<N;j++){
			k[j]=r[j];
		}
	}
	/*for(int j=N-2;j>=0;j--){
		for(int i=j;i<N;i++){
			if(k[i]==1){
				if(k[i+1]==1){
					if(i+2>=N){
						break;
					}
					if(k[i+2]!=0){
						break;
					}
					k[i]=0;
					k[i+1]=2;
					k[i+2]=2;
					c++;
				}
				if(k[i+1]==0){
					k[i+1]=2;
					k[i]=0;
					c++;
				}
			}
			if(k[i]==2){
				if(k[i+1]==1){
					if(i+2>=N){
						break;
					}
					if(k[i+2]!=0){
						break;
					}
					k[i]=1;
					k[i+1]=2;
					k[i+2]=2;
					c++;
				}
				if(k[i+1]==0){
					k[i]=1;
					k[i+1]=2;
					c++;
				}
			}
		}
		for(int t=0;t<N;t++){
			k[t]=r[t];
		}
		//rec(a,n,c,i+1);
	}*/
	out<<c;
	return 0;
}

