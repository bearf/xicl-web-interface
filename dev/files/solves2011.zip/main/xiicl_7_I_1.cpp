#include <iostream>
#include <stdio.h>
#include <string>
#include <string.h>
#include<set>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>

using namespace std;
typedef long long li;
typedef pair<int,int> pi;


void solve();
int main(){
#ifdef _DEBUG
	freopen("in.txt","r",stdin);
#else
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	solve();
	return 0;
}
li d(li n,int r){
	if(!r){
		//cout<<n<<' '<<r<<' '<<(n>=0 && n<3)<<endl;
		return (n>=0 && n<3);
	}
	if(n >(1LL<<(r+2))){
		//cout<<n<<' '<<r<<' '<<0<<endl;
		return 0;
	}
	li ans=0;
	if(n>=(1LL<<(r))){
		ans+=d(n-(1LL<<r),r-1);
		//n-=(1LL<<r);
	}
	if(n>=(1LL<<(r+1))){
		ans+=d(n-(1LL<<(r+1)),r-1);
		//n-=(1LL<<r);
	}
	ans+=d(n,r-1);
	//cout<<n<<' '<<r<<' '<<ans<<endl;
	return ans;
}
void solve(){
	li n;
	cin>>n;
	cout<<d(n,60);
}