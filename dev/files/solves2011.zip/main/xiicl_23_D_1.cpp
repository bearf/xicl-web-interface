#include <fstream>
#include <string>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");
string s;
int n;
bool is_c(char p) {
	if (p >= 'a' && p <= 'z') {
	} else p = p - 'A' + 'a';
	return (p == 'a' || p == 'e' || p == 'i' || p == 'o' || p == 'u' || p == 'y');
}
int main()
{
cin >> n;
getline(cin, s);
getline(cin, s);
for (int i = 0; i < n-1; i++) {
	if ((is_c(s[i]) && is_c(s[i+1])) || (!is_c(s[i]) && !is_c(s[i+1]))) {
		cout << "BAD";
		return 0;
	}
}
cout << "GOOD";
}