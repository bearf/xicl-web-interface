#include <fstream>
#include <string>
#include <set>
#include <algorithm>

using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");

int n;
long long a[100100];
long long ba[100100];
int ans[100100];
long long d[100100];
int k[100100];
int bk[100100];
int uk;
int lasta[100100];
int lastk[100100];

long long geta(int pos, int it) {
	if (lasta[pos] != it) {
		return ba[pos];
	} else {
		return a[pos];
	}
}

void seta(int pos, int it, int d) {
	a[pos] = geta(pos,it) + d;
	lasta[pos] = it;
}

int main() 
{
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> ba[i];
	}
	memset(d,0,sizeof(d));
	memset(bk,0,sizeof(bk));
	memset(lasta, 0, sizeof(lasta));
	for (int i = 2; i <= n; i++) {
		d[i] = (d[i-1] + ba[i-1]) / 2;
	}
	int l = 0;
	for (int i = n; i >= 1; i--) {
		if (ba[i] > 0) {
			bk[l] = i;
			l++;
		}
	}
	bk[l] = 0;
	for (int t = 0; t <= l; t++) {
			k[t] = bk[t];
		}
	int i = 1;
	int j;
	long long p;
	memset(ans, 0, sizeof(ans));
	int maxj = -1;
	while (i < n) {
		/*for (int t = 1; t <= n; t++) {
			a[t] = ba[t];
		}
		for (int t = 0; t <= l; t++) {
			k[t] = bk[t];
		}*/
		uk = 0;
		j = i;
		if (geta(j,i) == 0 && d[j] == 0) {
			if (k[uk] > i) {
				seta(j,i,1);
				seta(k[uk],i,-1);
				if (geta(k[uk],i) == 0) uk++;
			} else {
				i++;
				continue;
			}
		}
		p = d[j] + geta(j,i)-1;
		while (j < n) {
			if (p == 0 && k[uk] > j) {
				p++;
				seta(k[uk],i,-1);
				if (geta(k[uk],i) == 0) uk++;
			}
			if (p > 0) {
				p -= 1;
				p /= 2;
				p += geta(j+1,i);
				j++;
			} else break;
		}
		ans[j] = j-i+1;
		if (maxj == -1) {
			maxj = j;
		} else {
			if (ans[maxj] <= ans[j]) maxj = j;
		}
		if (i == j) i++; else i = j;
	}
	if (maxj == -1) {
		for (int i = n; i >= 1; i--) {
			if (ba[i] > 0) {
				cout << "1 " << i;
				return 0;
			}
		}
	}
cout << ans[maxj] << " ";
if (maxj > n) maxj = n;
cout << maxj;
	return 0;
}