#include <algorithm>
#include <iostream>
#include <string>
#include <cctype>
#include <set>
#include <vector>
#include <queue>

#define vv vector
#define mp make_pair
#define px first
#define py second
#define in cin
#define out cout

using namespace std;

typedef long long ll;

int n;
vv< vv<bool> > e;
vv<int> list;

void euler(int v) {
	for (int u = 0; u <= 2*n; u++) {
		if (e[u][v]) {
			e[u][v] = e[v][u] = false;
			euler(u);
		}
	}
	list.push_back(v);
}

int main() {
	ios_base::sync_with_stdio(false);
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	in >> n;
	e.assign(2 * n + 1, vv<bool>(2 * n + 1, true));
	vv<int> a, ans;
	int x;
	while (in >> x) {
		a.push_back(x);
	}

	for (int i = 0; i < a.size() - 1; i++) {
		e[a[i]][a[i+1]] = e[a[i+1]][a[i]] = false;
	}

	euler(a[0]);
	for (int j = 0; j < list.size(); j++) {
		ans.push_back(list[j]);
	}
	for (int i = 1; i < a.size(); i++) {
		list.clear();
		euler(a[i]);
		for (int j = list.size() - 1; j >= 0; j--) {
			ans.push_back(list[j]);
		}
	}

	for (int i = 0; i < ans.size(); i++) {
		out << ans[i] << ' ';
	}

	return 0;
}