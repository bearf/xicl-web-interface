#include <fstream>
using namespace std;

int main()
{
	ifstream fin("input.txt");
	ofstream fout("output.txt");

	__int64 a, b, x, y, z, Sx, Sy, Sz, S1, S2, hx, hy, hz, wx, wy, wz, d;

	fin >> a >> b >> x >> y >> z;
	Sx = a*b*x+a*(b-1)*x*(x-1)/2;
	Sy = (a+b-1)*y+y*(y-1)/2*(b-1)*a;
	Sz = (a+b-1)*z + z*(z-1)/2*a*(b-1);
	hx = a*x;hz = a*z; hy = (b-1)*y+1;
	d = hx+hy-hz;
	
	if(d>0)
	{
		S2 = (z*(b-1)+1)*d;
		S1 = (y*a-b)*hx;
	}
	else
	{
		S2 = (x*(b-1)+1)*(-d);
		S1 = (y*a-b)*(hx-d);
	}

	fout << (Sx+Sy+Sz+S1+S2);

	return 0;
}