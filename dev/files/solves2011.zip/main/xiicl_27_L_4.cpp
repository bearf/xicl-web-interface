#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:200000000")
#define _SECURE_SCL 0
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace std;


typedef long long int64;

const int INF = (int) 1E9;
const int64 INF64 = (int64) 1E18;
const double EPS = 1E-9;
const double PI = acos((double)0) * 2;

#define forn(i,n)  for (int i=0; i<int(n); ++i)
#define ford(i,n)  for (int i=int(n)-1; i>=0; --i)
#define fore(i,l,n)  for (int i=int(l); i<int(n); ++i)
#define all(a)  a.begin(), a.end()
#define fs  first
#define sc  second
#define pb  push_back
#define mp  make_pair


const int MAXN = 110000;

int n;
int64 a[MAXN], old_a[MAXN], b[MAXN];


bool read() {
	if (! (cin >> n))  return false;
	forn(i,n) {
		int x;
		scanf ("%d", &x);
		a[i] = x;
	}
	return true;
}


bool can (int len, int l) {
	forn(i,n) {
		a[i] = old_a[i];
		b[i] = 0;
	}
	int r = l + len-1;

	if (l == r) {
		fore(i,r,n)
			if (a[i] > 0)
				return true;
		return false;
	}

	int64 have = 0,
		bal = 0;
	ford(i,n) {
		if (i < l)  break;

		int64 need = 0;
		b[i] = 0;
		if (i == l)
			need = 2;
		else if (l < i && i < r)
			need = 1;

		if (a[i] > need) {
			b[i] = a[i] - need;
			bal += b[i];
		}
	}

	int64 used = 0;

	forn(i,r+1) {
		if (used > 0) {
			int64 x = min (used, b[i]);
			used -= x;
			b[i] -= x;
			a[i] -= x;
		}

		a[i] += have;

		bal -= b[i];

		have = a[i]/2;
		if (have == 0 && l <= i && i < r) {
			int64 need = 2 - a[i];
			if (bal < need)
				return false;
			bal -= need;
			used += need;
			have = 1;
		}
	}
	return true;
}


int ans_r;

bool can_len (int len) {
	int l = 0,  r = n-len;
	if (l > r)  return false;
	while (l < r-1) {
		int m = (l + r) / 2;
		if (can (len, m))
			l = m;
		else
			r = m;
	}

	for (int m=r; m>=l; --m)
		if (can (len, m)) {
			ans_r = m;
			return true;
		}
	return false;
}

void solve() {
	forn(i,n)
		old_a[i] = a[i];

	int l = 1,  r = n;
	while (l < r-1) {
		int m = (l + r) / 2;
		if (can_len (m))
			l = m;
		else
			r = m;
	}

	for (int m=r; m>=l; --m)
		if (can_len (m)) {
			printf ("%d %d\n", m, ans_r+m);
			return;
		}
	throw;
}


int main() {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	if (read())
		solve();

}

