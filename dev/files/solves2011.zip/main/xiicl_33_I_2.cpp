#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>



int main() {
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	
	__int64 a[50];
	__int64 t=1,st=0,stt=0,sttt=0;
	__int64 n,c=1;
	int i=0;
	while (i<=49) {
		a[i]=t;
		t=t*2;
		i++;
	}
	
	scanf("%I64d",&n);
	int us[50]={0};
	i=49;
	while (n>0) {
		if (n>=a[i]) {
			n-=a[i];us[i]=1;}
		i--;
	}
	
	i=0;//int st=0;int stt=0;int sttt=0;
	while (us[i]==0) i++;
	sttt=i;stt=i+1;
	i++;
	while (i<50) {
		if (us[i]==0) st++;
		if (us[i]==1) {
			stt=(st+1)*stt;
			sttt=(1)*sttt;
			stt+=sttt;
		}
		i++;
	}
	printf("%lld",stt);
	return 0;
}
