#include <fstream>
#include <string>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");

int a[210][210];
int ans[210 * 210 * 2];
int b[210 * 210 * 2];
int st[210];
int lb = 0;
int l = 0;
int n;

void dfs(int q) {
	for (int i = 0; i < n; i++) {
		if (i != q) {
			if (a[q][i] == 1) {
				a[q][i] = a[i][q] = 0;
				st[q]--;
				st[i]--;
				dfs(i);
			}
		}
	}
	ans[l++] = q;
	if (a[q][q] == 1) {
		a[q][q] = 0;
		st[q]--;
		ans[l++] = q;
	}
}

int main() 
{
	cin >> n;
	for (int i = 0; i <= 2 * n; i++) {
		for (int j = 0; j <= 2 * n; j++) {
			a[i][j] = 1;
		}
		st[i] = 2 * n + 1;
	}
	n = 2 * n + 1;
	int sq;
	cin >> sq;
	int bg = sq;
	b[lb++] = sq;
	while (1) {
		int q;
		cin >> q;
		if (!cin) break;
		b[lb++] = q;
		a[q][sq] = 0;
		a[sq][q] = 0;
		st[q]--;
		if (sq != q) st[sq]--;
		sq = q;
	}
	l = 0;
	dfs(bg);
	for (int i = 0; i < l; i++) {
		cout << ans[i] << " ";
	}
	for (int i = 1; i < lb; i++) {
		cout << b[i] << " ";
		while (st[b[i]] > 0) {
			l = 0;
			dfs(b[i]);
			for (int j = 1; j < l; j++) {
				cout << ans[j] << " ";
			}
		}
	}
}