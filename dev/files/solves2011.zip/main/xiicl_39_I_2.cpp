#define maxn 100
#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <vector>

using namespace std;

long long inp;

long long a[maxn],b[maxn],c[maxn];
int n;

int makec(long long x){
	vector<int> z;

	while (x>1){
		z.push_back(x%2);
		x=x/2;
	}
	z.push_back(int(x));
	n=int(z.size());
	//for (int i=n-1; i>=0; i--) c[n-i-1]=z[i];
	for (int i=0; i<n; i++) c[i]=z[i];
	return 0;
}

int main(){
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);

	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	memset(c,0,sizeof(c));

	cin >> inp;
	makec(inp);

	if (c[0]==0) b[0]=1;
	else         a[0]=1;

	for (int i=1; i<n; i++){
		if (c[i]==0) b[i]=a[i-1]+b[i-1];
		else{
			a[i]=a[i-1]+b[i-1];
			int k=1;
			while (i-k>=0 && c[i-k]==0){
				if (i-k-1>=0) b[i]+=a[i-k-1]+b[i-k-1];
				else          b[i]+=1;
				k++;
			}
			if (i-k-1>=0) b[i]+=b[i-k];
		}
	}
	//printf("%d",a[n-1]+b[n-1]);
	cout << a[n-1]+b[n-1];
	return 0;
}
