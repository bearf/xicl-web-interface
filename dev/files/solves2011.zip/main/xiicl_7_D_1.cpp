#include <iostream>
#include <stdio.h>
#include <string>
#include <string.h>
#include<set>
#include <algorithm>
#include <map>
#include <queue>


using namespace std;
void solve();
int main(){
#ifdef _DEBUG
	freopen("in.txt","r",stdin);
#else
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	solve();
	return 0;
}


bool type(char a){
	if(a=='a' || a=='o' || a=='y' || a=='u' || a=='i' || a=='e' || a=='A' || a=='O' || a=='Y' || a=='U' || a=='I' || a=='E')
		return true;
	else
		return false;
}
char s[111111];
void solve(){
	int n;
	cin>>n;
	scanf("%s",s);
	for(int i=1;i<n;++i){
		if(type(s[i])==type(s[i-1])){
			cout<<"BAD";
			return ;
		}
	}
	cout<<"GOOD";
}