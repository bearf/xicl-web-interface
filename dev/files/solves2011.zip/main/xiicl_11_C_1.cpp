#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

#define fi first
#define se second
#define re return
#define pb push_back
#define mp make_pair
#define sz(x) (int)((x).size ())
#define all(x) (x).begin (), (x).end ()
#define rep(i,n) for (int i = 0; i < n; i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define fill(x,y) memset(x, y, sizeof (x))
#define PI 3.1415926535897932384626433832795 
#define y0 y2341234
#define y1 y2513452

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

int n;
int m;

int main () {
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);

	ll a, b, x, y, z, S;
	cin >> a >> b >> x >> y >> z;
	S = (a + b - 1) * (x + y + z);
	ll Hz, Hx = 0;
	Hz = a * x - 1 + b + (b - 1) * (y - 1) - a * z + 1;
	if (Hz < 0) {
		Hx = - Hz;
		Hz = 0;
	}
	//cerr << Hx << ' ' << Hz << endl;
	S += Hx + (b - 1) * (x * (a - 1 + Hx) + a * (x * (x - 1) / 2));
	S += Hz + (b - 1) * (z * Hz + a * (z * (z - 1) / 2));
	S += (a - b) * (a * x + Hx) + a * ((a * x + Hx) * (y - 1) + (b - 1) * (y * (y - 1) / 2));
	cout << S << endl;
	re 0;
}