#include <fstream>
#include <string>
using namespace std;
ifstream in("input.txt");
ofstream out("output.txt");
string str;
int len;

bool isGl(char c)
{
	return c=='a' || c=='A' || c=='e' || c=='E' || c=='i' || c=='I' || c=='o' || c=='O' || c=='u' || c=='U' || c=='y' || c=='Y';
}

bool isSogl(char c)
{
	return !isGl(c);
}

int nextGl(int pos)
{
	while(pos<len && isSogl(str[pos])) ++pos;
	if(pos<len)
		return pos;
	else
		return -1;
}

int nextSogl(int pos)
{
	while(pos<len && isGl(str[pos])) ++pos;
	if(pos<len)
		return pos;
	else
		return -1;
}

int main()
{
	int n;
	in>>n>>str;
	len=str.length();
	for(int i=0;i<len-1;i++)
	{
		if((isSogl(str[i]) && isSogl(str[i+1])) || (isGl(str[i]) && isGl(str[i+1])) )
		{
			out<<"BAD";
			return 0;
		}
	}
	out<<"GOOD";
	return 0;
}