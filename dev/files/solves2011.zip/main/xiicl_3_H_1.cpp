//#pragma comment("/STACK:64000000")
#include <stdio.h>
#include <string.h>
#include <set>
#include <map>
#include <iostream>
using namespace std;
#define REP(i, a, b) for(int i = (a); i < (b); ++i)
typedef long long ll;

#define MAXN 500
#define MAXE 5000000
#define _(a, b) memset((a), (b), sizeof(a))

int to[MAXE], nxt[MAXE], flow[MAXE], cost[MAXE], capa[MAXE];
int head[MAXN], dist[MAXN], pedge[MAXN], pvert[MAXN];

int e , src, des, node ;

void init(int SRC, int DES, int NODE){
	e = 0;
	src = SRC;
	des = DES;
	node = NODE;
	_(head, 255);
}
void ae(int u, int v, int c, int c1, int cc) {
	to[e] = v, capa[e] = c, flow[e] = 0, cost[e] = cc, nxt[e] = head[u] , head[u] = e ++ ;
	to[e] = u, capa[e] = c1, flow[e] = 0, cost[e] = -cc, nxt[e] = head[v] , head[v] = e ++ ;

	//printf("add %d --> %d\n", u, v);
}
void bellman() {
	REP(i, 0, node) dist[i] = 1000000000;
	dist[src] = 0;
	while (true) {
		bool ch = false;
		for(int i = 0; i < node; ++i) {
			if (dist[i] == 1000000000) continue;
			for(int j = head[i]; j >= 0; j = nxt[j]) {
				if (capa[j] > flow[j] && dist[to[j]] > dist[i] + cost[j]) {
					dist[to[j]] = dist[i] + cost[j];
					pedge[to[j]] = j;
					pvert[to[j]] = i;
					ch = true;
				}
			}
		}
		if (!ch) break;
	}
}
bool isArt[200];
void mincost() {
	
	int sum = 0;
	int art = 0, paths = 0;
	////!!
	int flow = 0;
	while (true) {	
		bellman();
		if (dist[des] == 1000000000) break;
		int cur = des;
		int add = 0;
		for(; cur != src; cur = pvert[cur]) {
			int ed = pedge[cur];
			add += cost[ed] ;
			::flow[ed] ++ ;
			::flow[ed ^ 1] -- ;
		}
		if (add == 0) break;
		sum += add;
		++ flow;
		if ((-sum) > art) {
			art = -sum;
			paths = flow;
		}
	}
	printf("%d %d\n", art + (isArt[0] ? 1 : 0), paths);
}


int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	int n, m, k;
	scanf("%d%d%d", &n, &m, &k);
	init(n + n, n +n + 1, n + n + 2);
	_(isArt, false);
	REP(i, 0, k) {
		int tmp;
		scanf("%d", &tmp);
		isArt[tmp - 1] = true;
	}
	REP(i, 0, m) {
		int u, v;
		scanf("%d%d", &u, &v);
		-- u, -- v;
		if (u == 0) {
			ae(src, v, 1, 0, 0);
		} else if (v == 0) {
			ae(u + n, des, 1, 0, 0);
		} else {
			ae(u + n, v, 1, 0, 0);
		}
	}
	REP(i, 1, n) {
		ae(i, i + n, 1, 0, (isArt[i] ? -1 : 0));
	}
	mincost();
}