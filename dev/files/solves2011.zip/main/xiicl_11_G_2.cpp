#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

#define fi first
#define se second
#define re return
#define pb push_back
#define mp make_pair
#define sz(x) (int)((x).size ())
#define all(x) (x).begin (), (x).end ()
#define rep(i,n) for (int i = 0; i < n; i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define fill(x,y) memset(x, y, sizeof (x))
#define PI 3.1415926535897932384626433832795 
#define y0 y2341234
#define y1 y2513452

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

int n;
int m;
int x[10000];

int main () {
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);

	scanf ("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf ("%d", &x[i]);
		x[i]--;
	}	
	if (n == 3) {
		if (x[0] == 2 && x[1] == 1 && x[2] == 0) {
			printf ("2 2\n");
			re 0;
		}
		printf ("0\n");
		re 0;
	}
	for (int i = 0; i < n; i++) {
		int k = 0;
		for (int j = 0; j < n; j++)
			if (x[j] == i) {
				k = j;
				break;
			}	
		if (k == i) continue;
		if (k == i + 1) {
			if (i == 0) {
				if (n == 4) {
					printf ("2 2\n");
					printf ("3 2\n");
					printf ("2 2\n");
					printf ("2 2\n");
					printf ("3 2\n");
				} else {
					printf ("2 2\n");
					printf ("%d 2\n", n - 2);
					printf ("3 3\n");
					printf ("%d %d\n", n - 2, n - 3);
				}
			} else 
			if (i + 2 == n) {
				if (n == 4) {
					printf ("3 2\n");
					printf ("2 2\n");
					printf ("2 2\n");
					printf ("3 2\n");
					printf ("2 2\n");
				} else {
					printf ("%d %d\n", n - 1, n - 1);
					printf ("%d 3\n", n - 1);
					printf ("%d %d\n", n - 2, n - 2);
					printf ("4 3\n");
				}
			} else 
			if (i == 1) {
				if (n == 4)  {
					printf ("2 2\n");
					printf ("2 2\n");
					printf ("3 2\n");
					printf ("2 2\n");
					printf ("2 2\n");
				} else {
					int a = i + 1;
					int b = n - k;
					printf ("2 2\n");
					printf ("%d %d\n", b, b);
					printf ("4 3\n");
					printf ("%d %d\n", b + 1, b);
				}	
			} else {
				int a = i + 1;
				int b = n - k;
				printf ("%d 2\n", a);
				printf ("%d 2\n", b);
				printf ("%d %d\n", a, a - 1);
				printf ("%d %d\n", b + 1, b);
			}
		} else {
			int a = i + 1;
			int b = n - k;
			printf ("%d %d\n", n - b, a + 1);
			printf ("%d %d\n", n - 1, 2);
			printf ("%d %d\n", n - a, b + 1);
		}
		swap (x[i], x[k]);
	}

	re 0;
}