#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

#define fi first
#define se second
#define re return
#define pb push_back
#define mp make_pair
#define sz(x) (int)((x).size ())
#define all(x) (x).begin (), (x).end ()
#define rep(i,n) for (int i = 0; i < n; i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define fill(x,y) memset(x, y, sizeof (x))
#define PI 3.1415926535897932384626433832795 
#define y0 y2341234
#define y1 y2513452

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

int n;
int m;

int g[200100][2];
int k[200100];
int t[200100], l[200100];
int par[200100][20];
ll ans = 0;
//0 - straight, 1 - left, 2 - right

void dfs(int u, int tp) {
	t[u] = tp;
	for (int i = 1; i < 20; i++) par[u][i] = par[par[u][i - 1]][i - 1];
	if (k[u] == 2) {
		ans++;
		if (tp == 0) {
			l[g[u][0]] = 1;
			l[g[u][1]] = 1;
		} else
		if (tp == 1) {
			l[g[u][0]] = l[u] + 1;
			l[g[u][1]] = 1;
		} else {
			l[g[u][0]] = 1;
			l[g[u][1]] = l[u] + 1;
		}
		par[g[u][0]][0] = par[g[u][1]][0] = u;
		dfs(g[u][0], 1);
		dfs(g[u][1], 2);

	} else 
	if (k[u] == 1) {
		if (tp == 0) l[g[u][0]] = l[u] + 1; else
		l[g[u][0]] = 1;
		par[g[u][0]][0] = u;
		dfs(g[u][0], 0);
	}
}

int up(int u, int k) {
	for (int i = 19; i >= 0; i--) {
		if (k >= (1 << i)) {
			u = par[u][i];
			k -= (1 << i);
		}
	}
	re u;
}

int main () {
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%d", &k[i]);
		for (int j = 0; j < k[i]; j++) {
			scanf("%d", &g[i][j]);
			g[i][j]--;
			//cerr << g[i][j] << ' ';
		}
		//cerr << endl;
	}
	l[0] = 0;
	t[0] = -1;
	memset(par, 0, sizeof(par));
	dfs(0, -1);
//	for (int i = 0; i < n; i++) cerr << l[i] << ' '; cerr << endl;
//	cerr << ans << endl;
	for (int i = 1; i < n; i++) {
		int v = up(i, l[i]);

		if (v != 0) {
			//cerr << i << ' ' << l[i] << ' ' << v << endl;
			if (t[v] == 0) ans += ll(l[v]); else ans++;
		}
	}
	cout << ans << endl;
	re 0;
}
	