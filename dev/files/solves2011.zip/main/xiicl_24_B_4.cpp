#include <stdio.h>
#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <set>
#include <memory.h>
#include <math.h>
#include <algorithm>
using namespace std;
typedef long double ld;
typedef long long li;
typedef vector <int> vi;
#define pb push_back
#define mp make_pair
void solve ();
int main ()
{
#ifdef _DEBUG 
	freopen ("in.txt", "r", stdin);
#else 
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);
#endif
	solve ();
	return 0;
}
#define int li
int n, m;
int modul=1000000009;
int a[100500];
int c[700500];
int pow ( int q, int w )
{
	//cout<<q<<" "<<w<<endl;
	if (w==0)
		return 1;
	if (w%2)
		return (q*pow(q, w-1)+modul)%modul;
	int ans=pow (q, w/2);
	return (ans*ans+modul)%modul;
}
int doing (int cur)
{
	int prev=c[cur-1];
	int razn=cur-m+2;
	return (prev*cur/razn)%modul;
}
int pref[100500];
int cpr=1;
void done ()
{
	int niz=n+m-1, verh=m-1;
	int hr=1;
	for (int i=niz-verh+1; i<=niz; i++)
	{
		hr*=i;
		hr%=modul;
	}
	int zn=1;
	for (int i=1; i<=verh; i++)
	{
		zn*=i;
		zn%=modul;
	}
	//cout<<hr<<" "<<zn<<endl;
	int dob=pow( zn, modul-2 );
	dob*=hr;
	dob%=modul;
	cpr=dob;
	//cout<<cpr<<endl;
}
void solve ()
{
	cin>>n>>m;
	done ();
	for (int i=0; i<m; i++)
		cin>>a[i];
	if ( m==1 )
	{
		if ( n>a[0] )
		{
			cout<<"0";
			return;
		}
		cout<<"1";
		return;
	}
	for ( int i=0; i<=n+m; i++ )
	{
		if ( i<m-2 )
			c[i]=0;
		else 
			if ( i==m-2 )
				c[i]=1;
			else
			{
				c[i]=doing (i);
			}
		//cout<<c[i]<<" ";
	}
	//cout<<endl;
	pref[n+m-2]=c[0];
	for ( int i=n+m-3; i>=0; i-- )
	{
		pref[i]=(pref[i+1]+c[n+m-2-i])%modul;
		//cout<<pref[i]<<" ";
	}
	int ans=cpr;
	for ( int j=0; j<m; j++ )
	{
		ans-=pref[a[j]+1];
		ans=(ans+modul)%modul;
	}
	while (ans<0)
		ans+=modul;
	cout<<ans;
}