#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

#define fi first
#define se second
#define re return
#define pb push_back
#define mp make_pair
#define sz(x) (int)((x).size ())
#define all(x) (x).begin (), (x).end ()
#define rep(i,n) for (int i = 0; i < n; i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define fill(x,y) memset(x, y, sizeof (x))
#define PI 3.1415926535897932384626433832795 
#define y0 y2341234
#define y1 y2513452
#define sqr(x) ((x) * (x))

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

const double eps = 1e-8;

int n;
int m;

typedef pair <double, double> pdd;

double operator * (pdd a, pdd b) {
	re a.fi * b.fi + a.se * b.se;
}

pdd operator + (pdd a, pdd b) {
	a.fi += b.fi;
	a.se += b.se;
	re a;
}

pdd operator - (pdd a, pdd b) {
	a.fi -= b.fi;
	a.se -= b.se;
	re a;
}

pdd operator * (pdd a, double b) {
	a.fi *= b;
	a.se *= b;
	re a;
}

pdd operator / (pdd a, double b) {
	a.fi /= b;
	a.se /= b;
	re a;
}

double operator ^ (pdd a, pdd b) {
	re a.fi * b.se - a.se * b.fi;
}

int sgn(double a) {
	if (a < -eps) re -1;
	if (a > eps) re 1;
	re 0;
}


pdd aa;

bool ml(pdd a, pdd b) {
	re sqr(a - aa) < sqr(b - aa);
}

int main () {
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);
	double xa, ya, xb, yb;
	pair <pair<double, double>, double> y[100];
	pair <double, double> d1[100], d2[100];
	double L;
	cin >> xa >> ya >> xb >> yb >> L >> n;
	aa = mp(xa, ya);
	for (int i = 0; i < n; i++) {
		cin >> y[i].fi.fi >> y[i].fi.se >> y[i].se;
	}
	sort(y, y + n);
	pair <double, double> p[1000];
	int m = 0;
	p[m++] = mp(0.0, -1e6);
	for (int i = 0; i < n; i++) {
		p[m++] = mp(0, y[i].fi.fi);
		p[m++] = mp(0, y[i].fi.se);
	}
	p[m++] = mp(0.0, 1e6);
	p[m++] = mp(L, 1e6);
	for (int i = n - 1; i >= 0; i--) {
		p[m++] = mp(L, y[i].se + (y[i].fi.se - y[i].fi.fi));
		p[m++] = mp(L, y[i].se);
	}
	p[m++] = mp(L, -1e6);
	p[m] = mp(xa, ya);
	p[m + 1] = mp(xb, yb);
	double C[100];
	pdd M[100];
	for (int i = 0; i < n; i++) {
		pair <double, double> N = mp(y[i].se - y[i].fi.fi, -L);
		pdd pp = mp(0.0, y[i].fi.se);
		double q = -(N * mp(0, y[i].fi.fi));
		double t = -(q + (N * pp)) / (N * N);
		pdd v = N * t;
		d2[i] = d2[i] - v;
		y[i].fi.se += v.se;
		M[i] = N;
		C[i] = - (mp(-d1[i].fi, y[i].fi.fi) * N);
		for (int j = i + 1; j < n; j++) {
			d1[i] = d1[i] - v;
			d2[i] = d2[i] - v;
			y[j].fi.fi += v.se;
			y[j].fi.se += v.se;
			y[j].se += v.se;
		}
		for (int j = 0; j <= m + 1; j++) {
			if (N * p[j] + C[i] < -eps) p[j] = p[j] + v;
		}
	}
	double g[1000][1000];
	int par[1000][1000];
	memset(par, 255, sizeof(par));

	for (int i = 0; i <= m + 1; i++) {
		for (int j = 0; j <= m + 1; j++) g[i][j] = 1e20;
		g[i][i] = 0;
	}
	for (int i = 0; i <= m + 1; i++) {
		for (int j = i + 1; j <= m + 1; j++) {
			bool kpyto = true;
			for (int k = 0; k < m; k++) {
				pdd a = p[k], b = p[(k + 1) % m];
				
				if (sgn((b - p[j]) ^ (p[i] - p[j])) * sgn((a - p[j]) ^ (p[i] - p[j])) < 0 &&
				sgn((p[j] - a) ^ (b - a)) * sgn((p[i] - a) ^ (b - a)) < 0) kpyto = false;
			}
			if (kpyto) {
				g[i][j] = g[j][i] = sqrt(sqr(p[i] - p[j]));
				par[i][j] = i;
				par[j][i] = j;
			}
		}
	}
	for (int k = 0; k < m + 2; k++) {
		for (int i = 0; i < m + 2; i++) {
			for (int j = 0; j < m + 2; j++) {
				if (g[i][j] > g[i][k] + g[k][j]) {
					g[i][j] = g[i][k] + g[k][j];
					par[i][j] = (par[k][j] < 0 ? k : par[k][j]);
				}
			}
		}
	}
	/*for (int i = 0; i <= m +1; i++) d[i] = 1e20;
	set <pair <double, int> > s;
	s.insert(mp(0, m));
	while (s.size()) {
		pair <double, int> top = *s.begin();
		s.erase(top);
		
		for (int j = 0; j < (int)g[top.se].size(); j++) {
			double dist = sqrt(sqr(p[top.se] - p[g[top.se][j]]));
			if (d[g[top.se][j]] < top.fi + dist) {
				s.erase(mp(d[g[top.se][j]], g[top.se][j]));
				s.insert(mp(top.fi + dist, g[top.se][j]));
				par[g[top.se][j]] = top.se;
				d[g[top.se][j]] = top.fi + dist;
			}
		}
	}*/
	double len = g[m][m + 1];
	int cur = m + 1;
	vector <pdd> ans;
	while (cur != m) {
		pdd a = p[cur];
		pdd b = p[par[m][cur]];
		for (int j = 0; j < n; j++) {
			//(a + (b - a) * t, M[j]) + C[j] = 0;
			double t = -(C[j] + a * M[j]) / ((b - a) * M[j]);
			if (-eps < t && t < 1 + eps) {
				len += sqrt(sqr(d1[j] - d2[j]));
				pdd q = a + (b - a) * t;
				ans.pb(q + d1[j]);
				ans.pb(q + d2[j]);
			}
		}
		cur = par[m][cur];
	}
	printf("%.10lf\n", len);
	sort(ans.begin(), ans.end(), ml);
	for (int i = 0; i < (int)ans.size(); i++) printf("%.10lf %.10lf\n", ans[i].fi, ans[i].se);
	re 0;
}