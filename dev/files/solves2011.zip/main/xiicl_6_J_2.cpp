#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>

//using namespace std;
using std::vector;
using std::string;

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a, b) memset(a, b, sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int,int> pii;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	va_end(args);
	
	fflush(stdout);
#endif
#endif
}

const int LC = 0;
const int RC = 1;
const int MC = 2;

const int N = 300000;

int cnt[N];
int child[N][2];
int down[N][3];
int up[N][3];

ll ans = 0;

void findDown(int s)
{
	if (cnt[s] == 0)
		return ;

	if (cnt[s] == 1)
	{
		int v = child[s][0];
		findDown(v);
		down[s][MC] = down[v][MC] + 1;

		return ;
	}

	if (cnt[s] == 2)
	{
		int v = child[s][0];

		findDown(v);
		down[s][LC] = down[v][LC] + 1;

		v = child[s][1];

		findDown(v);
		down[s][RC] = down[v][RC] + 1;

		return ;
	}
}

void findUp(int s)
{
	if (cnt[s] == 0)
		return ;

	if (cnt[s] == 1)
	{
		int v = child[s][0];
		up[v][MC] = up[s][MC] + 1;
		up[v][LC] = up[v][RC] = 0;
		findUp(v);
		return ;
	}

	if (cnt[s] == 2)
	{
		int v = child[s][0];
		up[v][MC] = up[v][RC] = 0;
		up[v][LC] = 1;
		findUp(v);

		v = child[s][1];
		up[v][MC] = up[v][LC] = 0;
		up[v][RC] = 1;
		findUp(v);
		return ;
	}
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; ++i)
	{
		scanf("%d", &cnt[i]);
		for (int j = 0; j < cnt[i]; ++j)
		{
			int v;
			scanf("%d", &v);
			child[i][j] = v - 1;
		}
	}

	clr(up);
	clr(down);

	findDown(0);
	findUp(0);

	for (int i = 0; i < n; ++i)
	{
		dbg("up[i] = {");
		for (int j = 0; j < 3; ++j)
			dbg("%d ", up[i][j]);
		dbg("}\n");
	}

	for (int i = 0; i < n; ++i)
	{
		dbg("down[i] = {");
		for (int j = 0; j < 3; ++j)
			dbg("%d ", down[i][j]);
		dbg("}\n");
	}

	ans = 0;
	for (int i = 0; i < n; ++i)
	{
		if (cnt[i] == 2)
			++ans;

		if (up[i][LC] == 1)
			ans += down[i][RC] + down[i][MC];
		else if (up[i][RC] == 1)
			ans += down[i][LC] + down[i][MC];
		else
		{
			if (cnt[i] == 2)
			{
				ans += ll(up[i][MC]) * down[child[i][0]][LC];
				ans += ll(up[i][MC]) * down[child[i][1]][RC];
			}
		}
	}

	printf("%lld\n", ans);

	return 0;
}