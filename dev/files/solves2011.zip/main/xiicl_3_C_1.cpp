//#pragma comment("/STACK:64000000")
#include <stdio.h>
#include <string.h>
#include <set>
#include <map>
#include <iostream>
using namespace std;
#define REP(i, a, b) for(int i = (a); i < (b); ++i)
typedef long long ll;

//#define MAXN 500
//#define MAXE 
//int to[MAXE], nxt[MAXE], flow[MAXE], cost[MAXE], capa[MAXE];
//int head[m
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	ll a,b,x,y,z;
	cin>>a>>b>>x>>y>>z;
	ll res = 0;
	res+=((1+x)*x)/2*(b-1)*a+x*a;
	//printf("%lld\n",((1+x)*x)/2*(b-1)*a+x*a);
	res+=(a-b)*a*x;
	//printf("%lld\n",(a-b)*a*x);
	res+=a*x*a*(y-1);
	//printf("%lld\n",a*x*a*(y-1));
	res+=(a+b-1)*y+((y-1)*y)/2*(b-1)*a;
	//printf("%lld\n",(a+b-1)*y+((y-1)*y)/2*(b-1)*a);
	res+=(a+b-1)*z+((z-1)*z)/2*(b-1)*a;
	//printf("%lld\n",(a+b-1)*z+((z-1)*z)/2*(b-1)*a);
	ll hl = a*x;
	ll hr = a*z;
	ll hmid = b+(y-1)*(b-1);
	if (hl+hmid<hr){
		ll delta = hr-hl-hmid;
		res+=delta*(a*(y-1)+(a-b)+b+(b-1)*(x-1));
		//printf("%lld\n",delta*(a*(y-1)+(a-b)+b+(b-1)*(x-1)));
	}else if (hl+hmid>hr){
		ll delta = hl+hmid-hr;
		res+=delta*(b+(b-1)*(z-1));
		//printf("%lld\n",delta*(b+(b-1)*(z-1)));
	}
	cout<<res;
}