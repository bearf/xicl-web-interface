#include <fstream>
using namespace std;
void main()
{
	long long int q;
	ifstream inp("input.txt");
	inp>>q;
	inp.close();
	long long int l=0;
	struct 
	{
		long long int kol;
		long long int n;
	} str[400]; 
	long long int p=q;
	while (p>0)
	{
	 if ((l==0)||(p%2!=str[l-1].n))
	 {
	  str[l].n=p%2;
	  str[l].kol=1;
	  l++;
	 }
	 else
	 if (p%2==str[l-1].n)
	  str[l-1].kol++;
	 p=p/2;
	}
	p=1;
	long long int i=0;
	while (i<l)
	{
	 if ((str[i].n==0)&&(i>1))
		p*=(2*str[i].kol);
	 if ((str[i].n==1)&&(i>0))
		p*=(str[i].kol+1);	 
     i++;
	}
	ofstream oup("output.txt");
	oup<<p;
	oup.close();
}