#include<iostream>
#include<fstream>
#include<math.h>
#define L long long int
//out << ix2 << " " << jx2 << endl;

using namespace std;

int main()
{
    ifstream in("input.txt");
    ofstream out("output.txt");
    long int a, b;
    in >> a >> b;
    long int x, y, z;
    in >> x >> y >> z;
    L s1 = 0;
    L s2 = 0;
    L a0;
    L h;
    s1+=(x-1)*a*x/2;
    h=x*a;
    a0 = x*a*a+(a+b-1);
    s1+=(2*a0+(y-1)*(a+b-2))*y/2;
    h = x*a + y*(b-1) + 1;
    a0 = h;
    s1+=a0;
    h-=a-1;
    a0 = h;
    s1+=(2*a0-(z-1)*a)*z/2;
    ///////////////////////////
    h = 1;
    a0 = h;
    s2+=(2*a0+(z-1)*a)*z/2;
    h = h + (z-1)*a + (a-1);
    a0 = h;
    s2+=a0;
    a0 = (h-(b-1))*a + (b-1);
    s2+=(2*a0 - (y-1)*(a+b-2))*y/2;
    h-=y*(b-1)+1;
    a0 = h-a;
    s2+=(2*a0+(x-2)*a)*(x-1)/2;
    out << max(s1,s2);
    
    //out << max(s1, s2);
    return 0;
}
