#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <queue>

//using namespace std;
using std::vector;
using std::string;

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a, b) memset(a, b, sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int,int> pii;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	va_end(args);
	
	fflush(stdout);
#endif
#endif
}

int count[200000];


int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int n;
	scanf("%d", &n);
	for(int i = 1; i <= n; i++)
	{
		scanf("%d", &count[i]);
	}
	int ans = 1, lvl = 1;
	int next = 2;
	for(; lvl < n; lvl++)
	{
		if (count[lvl] > 1)
		{
			count[lvl+1] += count[lvl] / 2;
			ans++;
			continue;
		}
		if (count[lvl] == 0)
			continue;
		next = std::max(next, i + 1);
		while(next <= n && count[next] == 0)
			next++;	
		if (count[next] == 0)
			break;
		count[next] --;
		count[lvl+1] ++;
		ans++;
	}
	while(lvl == n && count[lvl] > 1 && ans < n)
	{
		count[lvl] /= 2;
		ans++;
	}
	printf("%d %d\n", ans, lvl);

	return 0;
}