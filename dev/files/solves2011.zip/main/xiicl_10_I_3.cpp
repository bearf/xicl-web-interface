#include <fstream>
using namespace std;

int main()
{
	ifstream fin("input.txt");
	ofstream fout("output.txt");

	__int64 k1, k0;
	__int64 N;
	__int64 K0, K1, L0, L1;
	fin >> N;

	K1 = 1;
	K0 = 0;
	while(N%2 == 1) N /= 2;
	while(N>0)
	{
		k0 = k1 = 0;
		while(N%2 == 0){ N /= 2; k0++; }
		while(N%2 == 1){ N /= 2; k1++; }
		L1 = (k1+k0-1)*K0 + (k1+k0-2)*K1;
		L0 = (k1+k0)*K0 + (k1+k0-1)*K1;
		
		K0 = L0; K1 = L1;
	}
	fout << K0 + K1;

	return 0;
}