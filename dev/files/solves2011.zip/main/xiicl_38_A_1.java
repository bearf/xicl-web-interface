import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;

public class Solution implements Runnable {
	int[] dx = {-1, 0, 0, 1};
	int[] dy = {0, -1, 1, 0};
	int INF = Integer.MAX_VALUE/3;
	public void run() {
		int n = nextInt();
		int m = nextInt();
		
		int[][] f = new int[n][m];
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < m; ++j) {
				f[i][j] = nextInt();
			}
		}
		
		int r = nextInt() - 1;
		int c = nextInt() - 1;
		
		int[][] dist = new int[n][m];
		int[][] prev = new int[n][m];
		for (int i = 0; i < n; ++i) {
			Arrays.fill(dist[i], INF);
			Arrays.fill(prev[i], -1);
		}
		dist[0][0] = 0;
		LinkedList<Integer> q = new LinkedList<Integer>();
		q.add(0);
		while (q.size() > 0) {
			int pos = q.removeFirst();
			int tr = pos/1000;
			int tc = pos%1000;
			
			for (int k = 0; k < 4; ++k) {
				if (tr+2*dx[k] >= 0 && tr+2*dx[k] < n && tc+2*dy[k] >= 0 && tc+2*dy[k] < m) {
					if (f[tr+dx[k]][tc+dy[k]] == f[tr+2*dx[k]][tc+2*dy[k]]) {
						int nr = tr+2*dx[k];
						int nc = tc+2*dy[k];
						if (dist[nr][nc] > dist[tr][tc] + 1) {
							dist[nr][nc] = dist[tr][tc] + 1;
							prev[nr][nc] = k;
							q.addLast(nr*1000+nc);
						}
					}
				}
			}
		}
		
		if (dist[r][c] >= INF) {
			out.println(0);
		}
		else {
			out.println(dist[r][c]);
			ArrayList<Integer> ans = new ArrayList<Integer>();
			
			int pr = r;
			int pc = c;
			while (prev[pr][pc] != -1) {
				ans.add(f[pr][pc]);
				int tr = pr - 2*dx[prev[pr][pc]];
				int tc = pc - 2*dy[prev[pr][pc]];
				pr = tr;
				pc = tc;
			}
			
			for (int i = ans.size() - 1; i >= 0; --i) {
				out.print(ans.get(i) + " ");
			}
			out.println();
		}
		
		out.flush();
	}
	
	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}
	
	private void loadLine() {
		try{
			stk = new StringTokenizer(br.readLine());
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String nextLine() {
		try {
			return br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private int nextInt() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	private long nextLong() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Long.parseLong(stk.nextToken());
	}

}
