#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<climits>
#include<vector>
#include<map>
#include<set>
#include<algorithm>
#include<queue>

using namespace std;

#define ws dfgjkhdg
#define y1 sdjghdjg
#define pb push_back
#define mp make_pair
#define fs first
#define sc second

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pi;
typedef pair<pi, int> pii;

int dx[4] = {0, 0, 1, -1};
int dy[4] = {1, -1, 0, 0};
bool b[600][600];
vector<pii> e[600][600];
queue<pi> q;
pi pr[600][600];
int c[600][600];
int ans[1000000];
int n,m;
int a[600][600];


void dfs(int x, int y) {
	b[x][y] = true;
	int x1,x2,y1,y2;
	for (int i=0;i<4;i++) {
		x1 = x+dx[i];
		y1 = y+dy[i];
		x2 = x1+dx[i];
		y2 = y1+dy[i];
		if (x2<m && x2>=0 && y2<n && y2>=0 && a[x1][y1]==a[x2][y2]) {
   			e[x][y].pb(mp(mp(x2,y2), a[x2][y2]));
   			if (!b[x2][y2]) {
				swap(a[x][y], a[x2][y2]);
				dfs(x2, y2);
				swap(a[x][y], a[x2][y2]);
			}
		}
	}
}
int cnt;


int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf("%d%d", &m, &n);
	for (int i=0;i<m;i++)
		for (int j=0;j<n;j++)
			scanf("%d", &a[i][j]);

	int x,y;
	scanf("%d%d", &x, &y);
	x--; y--;
	dfs(0,0);
	if (!b[x][y]) {
		printf("0\n");
		exit(0);
	}           

	q.push(mp(0,0));
	pi p;
	int xx, yy;
	int x1,y1,l;
	memset(b, 0, sizeof(b));
	b[0][0] = 1;

	while (!q.empty()) {
		p = q.front();
		q.pop();
		xx = p.fs;
		yy = p.sc;
		for (int i=0;i<(int)e[xx][yy].size();i++) {
			x1 = e[xx][yy][i].fs.fs;
			y1 = e[xx][yy][i].fs.sc;
			l = e[xx][yy][i].sc;
			if (!b[x1][y1])	 {
				b[x1][y1] = 1;
				c[x1][y1] = l;
				pr[x1][y1] = mp(xx,yy);
				q.push(mp(x1,y1));
			}
		}

	}
	x1 = x;
	y1 = y;
	cnt = 0;
	while (1) {
		ans[cnt++] = c[x1][y1];
		xx = pr[x1][y1].fs;
		yy = pr[x1][y1].sc;
		x1 = xx;
		y1 = yy;
		if (x1==0 && y1==0) break;
	}

	printf("%d\n", cnt);
	for (int i=cnt-1;i>=0;i--) printf("%d ", ans[i]);
	printf("\n");

	return 0;
}
