#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>

//using namespace std;
using std::vector;
using std::string;

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a, b) memset(a, b, sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int,int> pii;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	va_end(args);
	
	fflush(stdout);
#endif
#endif
}

const char S[] = "aeiouyAEUIOY";

bool find(char ch)
{
	int i = 0;
	while (S[i] != 0 && S[i] != ch)
		++i;

	dbg("%c %d\n", ch, i);

	return (S[i] == 0);
}

char s[200000];

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	int n;
	scanf("%d\n", &n);
	gets(s);

	bool cur = find(s[0]);
	for (int i = 1; i < n; ++i)
	{
		if (cur == find(s[i]))
		{
			printf("BAD\n");
			return 0;
		}
		cur ^= 1;
	}

	printf("GOOD\n");

	return 0;
}