#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:200000000")
#define _SECURE_SCL 0
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace std;


typedef long long int64;

const int INF = (int) 1E9;
const int64 INF64 = (int64) 1E18;
const double EPS = 1E-9;
const double PI = acos((double)0) * 2;

#define forn(i,n)  for (int i=0; i<int(n); ++i)
#define ford(i,n)  for (int i=int(n)-1; i>=0; --i)
#define fore(i,l,n)  for (int i=int(l); i<int(n); ++i)
#define all(a)  a.begin(), a.end()
#define fs  first
#define sc  second
#define pb  push_back
#define mp  make_pair


const int MAXN = 510;
const int dxy[4][2] = { {1,0}, {-1,0}, {0,1}, {0,-1} };


int n, m, a[MAXN][MAXN], x, y;


bool read() {
	if (! (cin >> n >> m))
		return false;
	forn(i,n)
		forn(j,m)
			scanf ("%d", &a[i][j]);
	cin >> x >> y;
	--x, --y;
	return true;
}


bool u[MAXN][MAXN];
pair<int,int> q[MAXN*MAXN];
pair<int,int> par[MAXN][MAXN];
int pwho[MAXN][MAXN];
int qh, qt;

bool inside (int x, int y) {
	return 0<=x && x<n && 0<=y && y<m;
}

void solve() {
	memset (u, 0, sizeof u);
	qh = qt = 0;
	q[qt++] = mp (0, 0);
	while (qh != qt) {
		int cx = q[qh].fs,  cy = q[qh].sc;
		++qh;

		forn(dir,4) {
			if (! inside (cx + 2*dxy[dir][0], cy + 2*dxy[dir][1]))
				continue;
			int id1 = a[cx+dxy[dir][0]][cy+dxy[dir][1]];
			int id2 = a[cx+2*dxy[dir][0]][cy+2*dxy[dir][1]];
			if (id1 == id2) {
				int nx = cx+2*dxy[dir][0],
					ny = cy+2*dxy[dir][1];
				if (!u[nx][ny]) {
					u[nx][ny] = true;
					q[qt++] = mp (nx, ny);
					par[nx][ny] = mp (cx, cy);
					pwho[nx][ny] = id1;
				}
			}
		}
	}

	if (!u[x][y]) {
		puts ("0");
	}
	else {
		vector<int> ans;
		for (int cx=x, cy=y; ; ) {
			ans.pb (pwho[cx][cy]);
			pair<int,int> to = par[cx][cy];
			cx=to.fs;
			cy=to.sc;
			if (to == mp(0,0))  break;
		}
		printf ("%d\n", ans.size());
		ford(i,ans.size())
			printf ("%d ", ans[i]);
		puts("");
	}
}


int main() {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	if (read())
		solve();

}
