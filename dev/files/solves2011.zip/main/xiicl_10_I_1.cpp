#include <fstream>
using namespace std;

int main()
{
	ifstream fin("input.txt");
	ofstream fout("output.txt");

	int k1, k0;
	__int64 N;
	__int64 K = 1;
	fin >> N;

	while(N%2 == 1) N /= 2;
	while(N>0)
	{
		k0 = k1 = 0;
		while(N%2 == 0){ N /= 2; k0++; }
		while(N%2 == 1){ N /= 2; k1++; }
		K *= k1+1;
	}
	fout << K;

	return 0;
}