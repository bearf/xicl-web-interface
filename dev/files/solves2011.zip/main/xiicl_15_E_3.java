import java.io.*;
import java.util.*;

public class Solution implements Runnable {

	void solve() throws IOException {
		int n = nextInt();
		char[][] c = new char[n][n];
		for (int i = 0; i < n; i++) {
			c[i] = nextToken().toCharArray();
		}
		int L = nextInt();
		int m = nextInt();
		int[][] d1 = new int[n][n];
		int[][] d2 = new int[n][n];
		for (int i = 0; i < n; i++) {
			Arrays.fill(d1[i], Integer.MAX_VALUE);
			Arrays.fill(d2[i], Integer.MAX_VALUE);
		}
		Queue<Point> q = new ArrayDeque<Point>();
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (c[i][j] != '.') {
					d1[i][j] = L / 2 - m;
					q.add(new Point(i, j));
				}
			}
		}
		while (!q.isEmpty()) {
			Point p = q.poll();
			if (d1[p.x][p.y] >= L / 2) {
				q.clear();
				break;
			}
			for (int dir = 0; dir < 4; dir++) {
				int x = p.x + DX[dir];
				int y = p.y + DY[dir];
				if (x < 0 || y < 0 || x >= n || y >= n
						|| d1[x][y] <= d1[p.x][p.y] + 1) {
					continue;
				}
				d1[x][y] = d1[p.x][p.y] + 1;
				q.add(new Point(x, y));
			}
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (d1[i][j] == Integer.MAX_VALUE) {
					d2[i][j] = L / 2;
					q.add(new Point(i, j));
				}
			}
		}
		if (q.isEmpty()) {
			q.add(new Point(0, 0));
			q.add(new Point(n - 1, 0));
			q.add(new Point(0, n - 1));
			q.add(new Point(n - 1, n - 1));
			d2[0][0] = m + 1;
			d2[0][n - 1] = m + 1;
			d2[n - 1][0] = m + 1;
			d2[n - 1][n - 1] = m + 1;
		}
		while (!q.isEmpty()) {
			Point p = q.poll();
			if (d2[p.x][p.y] >= L) {
				q.clear();
				break;
			}
			for (int dir = 0; dir < 4; dir++) {
				int x = p.x + DX[dir];
				int y = p.y + DY[dir];
				if (x < 0 || y < 0 || x >= n || y >= n
						|| d2[x][y] <= d2[p.x][p.y] + 1) {
					continue;
				}
				d2[x][y] = d2[p.x][p.y] + 1;
				q.add(new Point(x, y));
			}
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (d2[i][j] == Integer.MAX_VALUE) {
					d1[i][j] = 0;
					q.add(new Point(i, j));
				}
			}
		}
		while (!q.isEmpty()) {
			Point p = q.poll();
			if (d1[p.x][p.y] >= L / 2) {
				q.clear();
				break;
			}
			for (int dir = 0; dir < 4; dir++) {
				int x = p.x + DX[dir];
				int y = p.y + DY[dir];
				if (x < 0 || y < 0 || x >= n || y >= n
						|| d1[x][y] <= d1[p.x][p.y] + 1) {
					continue;
				}
				d1[x][y] = d1[p.x][p.y] + 1;
				q.add(new Point(x, y));
			}
		}
		int[] queue = new int[L * n * n];
		int[] e = new int[L * n * n];
		Arrays.fill(e, Integer.MAX_VALUE);
		int head = 0;
		int tail = 1;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (c[i][j] == 'D') {
					int cur = (L / 2 - m) * n * n + i * n + j;
					queue[0] = cur;
					e[cur] = 0;
				}
			}
		}
		// for (int i = 0; i < n; i++) {
		// System.err.println(Arrays.toString(d1[i]));
		// }
		// for (int i = 0; i < n; i++) {
		// System.err.println(Arrays.toString(d2[i]));
		// }
		while (head < tail) {
			int cur = queue[head++];
			int mod = cur / (n * n);
			int x = cur / n % n;
			int y = cur % n;
			for (int dir = 0; dir < 5; dir++) {
				int xx = x + DX[dir];
				int yy = y + DY[dir];
				if (xx < 0 || yy < 0 || xx >= n || yy >= n) {
					continue;
				}
				int time = e[cur] + 1;
				int newMod = mod + 1;
				if (newMod >= d2[xx][yy]) {
					continue;
				}
				if (newMod == L) {
					newMod = 0;
				}				
				if (newMod < d1[xx][yy]) {
					continue;
				}
				int newState = (newMod * n + xx) * n + yy;
				if (e[newState] > time) {
					e[newState] = time;
					queue[tail++] = newState;
				}
			}
		}
		int min = Integer.MAX_VALUE;
		int finishX = -1;
		int finishY = -1;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (c[i][j] == 'K') {
					finishX = i;
					finishY = j;
				}
			}
		}
		for (int i = 0; i < L; i++) {
			min = Math.min(min, e[i * n * n + finishX * n + finishY]);
		}
		if (min == Integer.MAX_VALUE
				|| d2[finishX][finishY] != Integer.MAX_VALUE
				&& d2[finishX][finishY] - (L / 2 - m) <= min) {
			out.println(-1);
			return;
		}
		out.println(min);
	}

	static final int[] DX = { 1, 0, -1, 0, 0 };
	static final int[] DY = { 0, 1, 0, -1, 0 };

	static class Point {
		int x;
		int y;

		public Point(int x, int y) {
			super();
			this.x = x;
			this.y = y;
		}

	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			out = new PrintWriter("output.txt");
			st = new StringTokenizer("");
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
