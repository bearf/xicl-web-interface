#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

#define fi first
#define se second
#define re return
#define pb push_back
#define mp make_pair
#define sz(x) (int)((x).size ())
#define all(x) (x).begin (), (x).end ()
#define rep(i,n) for (int i = 0; i < n; i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define fill(x,y) memset(x, y, sizeof (x))
#define PI 3.1415926535897932384626433832795 
#define y0 y2341234
#define y1 y2513452

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

const int di[4] = {1, 0, -1, 0};
const int dj[4] = {0, 1, 0, -1};

int n;
int m;
ii q[250000];
int was[500][500], d[500][500], g[500][500];
ii prev[500][500];

int out (int i, int j) {
	if (g[i][j] == 0) re 0;
	out (prev[i][j].fi, prev[i][j].se);
	printf ("%d ", g[i][j]);
	re 0;
}

int main () {
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);

	scanf ("%d%d", &n, &m);
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			scanf ("%d", &g[i][j]);
	int x, y;
	scanf ("%d%d", &x, &y); x--; y--;
	int l = 0, r = 1;
	q[0] = mp (0, 0);
	was[0][0] = 1;
	d[0][0] = 0;
	while (l < r) {
		int i = q[l].fi;
		int j = q[l].se;
		l++;
		if (i == x && j == y) {
			printf ("%d\n", d[i][j]);
			out (i, j);
			printf ("\n");
			re 0;
		}
		for (int t = 0; t < 4; t++) {
			int ni = i + di[t], nj = j + dj[t];
			int mi = ni + di[t], mj = nj + dj[t];
			if (mi >= 0 && mj >= 0 && mi < n && mj < m && g[ni][nj] == g[mi][mj] && !was[mi][mj]) {
				was[mi][mj] = 1;
				d[mi][mj] = d[i][j] + 1;
				prev[mi][mj] = mp (i, j);
				q[r++] = mp (mi, mj);
			}
		}
	}
	printf ("0\n");
	re 0;
}