#include <fstream>
using namespace std;
	struct 
	{
		long long int kol;
		long long int n;
	} str[400]; 
	long long int l=0;
long long work(int p)
{
 if (p==l)
  return 1;
 if ((str[p].n==0)||(p==0))
  return work(p+1);
 long long b=(str[p].kol*str[p-1].kol+1)*work(p+1);
 if (p<l-1)
 {
  str[p].kol--;
  str[p+1].kol++;
  b+=work(p+1);
  str[p].kol++;
  str[p+1].kol--;
 }
 return b;
}
void main()
{
	long long int q;
	ifstream inp("input.txt");
	inp>>q;
	inp.close();
	long long int p=q;
	while (p>0)
	{
	 if ((l==0)||(p%2!=str[l-1].n))
	 {
	  str[l].n=p%2;
	  str[l].kol=1;
	  l++;
	 }
	 else
	 if (p%2==str[l-1].n)
	  str[l-1].kol++;
	 p=p/2;
	}
	p=work(0);
	ofstream oup("output.txt");
	oup<<p;
	oup.close();
}