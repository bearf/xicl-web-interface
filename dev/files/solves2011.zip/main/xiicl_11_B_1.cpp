#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

#define fi first
#define se second
#define re return
#define pb push_back
#define mp make_pair
#define sz(x) (int)((x).size ())
#define all(x) (x).begin (), (x).end ()
#define rep(i,n) for (int i = 0; i < n; i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define fill(x,y) memset(x, y, sizeof (x))
#define PI 3.1415926535897932384626433832795 
#define y0 y2341234
#define y1 y2513452

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

const int mod = 1000000009;

int n;
int m;
int fact[200001];
int rfact[200001];
int s[200001], a[200001];

int power (int a, int b) {
	int c = 1;
	while (b) {
		if (b & 1) c = ((ll)c * a) % mod;
		a = ((ll)a * a) % mod;
		b >>= 1;
	}
	re c;
}

int cnk (int n, int k) {
	if (k < 0 || k > n) re 0;
	ll tmp = fact[n];
	tmp = (tmp * rfact[k]) % mod;
	tmp = (tmp * rfact[n - k]) % mod;
	re tmp;
}

int main () {
	fact[0] = 1;
	rfact[0] = 1;
	for (int i = 1; i <= 200000; i++) {
		fact[i] = ((ll)fact[i - 1] * i) % mod;
		rfact[i] = power (fact[i], mod - 2);
	}
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);

	scanf ("%d%d", &n, &m);
	for (int i = 0; i < m; i++) {
		scanf ("%d", &a[i]);
		a[i] = min (a[i], n);
	}	

	if (m == 1) {
		if (a[0] >= n) printf ("1\n"); else printf ("0\n");
		re 0;
	}

        int ans = cnk (n + m - 1, m - 1);

        s[n + 1] = 0;
	for (int i = n; i >= 0; i--)
		s[i] = (s[i + 1] + cnk ((n - i) + m - 2, m - 2)) % mod;

	for (int i = 0; i < m; i++) ans = (ans - s[a[i] + 1] + mod) % mod;

	printf ("%d\n", ans);
	re 0;
}
