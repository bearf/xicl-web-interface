import java.io.*;
import java.util.*;

public class Solution implements Runnable {

	void solve() throws IOException {
		int n = nextInt();
		int a[] = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = nextInt();
		}
		int zerodiff = ans(a, 0);
		int l = 0;
		int r = a.length;
		while (l + 1 < r) {
			int m = (l + r) / 2;
			if (ans(a, m) - m < zerodiff) {
				r = m;
			} else {
				l = m;
			}
		}
		out.print(zerodiff + 1 + " " + (r + zerodiff));
	}
	
	static int ans(int a[], int start) {
		a = a.clone();
		long have = 0;
		int level;
		int pos;
		levelloop: for (level = start, pos = start; level < a.length; level++) {
			have += a[level];
//			System.err.println("level " + level + " have " + have);
			a[level] = 0;
			while (have < 2) {
				if (pos <= level) {
					pos = level + 1;
				}
				while (pos < a.length && a[pos] == 0) {
					++pos;
				}
				if (pos >= a.length) {
					break levelloop;
				}
				--a[pos];
				++have;
			}
			have /= 2;
		}
		if (level >= a.length) {
			level = a.length - 1;
		}
//		System.err.println("from " + start + ": level=" + level + ", have=" + have);
		return have > 0 ? level : -1;
	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			out = new PrintWriter("output.txt");
			st = new StringTokenizer("");
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
