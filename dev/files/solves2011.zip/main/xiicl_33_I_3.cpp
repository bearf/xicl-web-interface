#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>



int main() {
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	
	__int64 a[50];
	__int64 t=1,st=0,stt=0,sttt=0;
	__int64 n,c=1;
	int i=0;
	while (i<=49) {
		a[i]=t;
		t=t*2;
		i++;
	}
	
	scanf("%I64d",&n);
	int us[50]={0};
	i=49;
	while (n>0) {
		if (n>=a[i]) {
			n-=a[i];us[i]=1;}
		i--;
	}
	
	i=0;//int st=0;int stt=0;int sttt=0;
	while (us[i]==0) {i++;st++;}
	int yes=0;
	sttt=i;stt=i+1;if (st>0) {st=0;yes=1;}
	//while (us[i]==1) i++;
	while (i<50) {
		if (us[i]==0) st++;
		if (us[i]==1) {
			t=stt;
			stt=(st+1)*stt;
			//sttt=(1)*sttt;
			//if (st>0) stt+=1;
			if (st>0 || yes) {stt+=sttt;
			sttt=st*t;}
			//if (st>=1) sttt=1;
			st=0;
		}
		i++;
	}
	printf("%lld",stt);
	return 0;
}
