#include <iostream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define X first
#define Y second
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1E9);
const ld PI = acos(-1.0);
const ld EPS = 1E-9;

struct edge{
    int to, f, c, p, rev;
};

int n, m, k;
vector<edge> g[1000];
bool hasC[1000];


void addEdge(int fr, int to, int c, int p){
    edge a = {to, 0, c, p, sz(g[to])};
    edge b = {fr, 0, 0, -p, sz(g[fr])};

    g[fr].push_back(a);
    g[to].push_back(b);
}

int d[1000], tr[1000], trE[1000];

const int szQ = 1000;
bool inQ[1000];
int q[1000];

int flow, cost;

bool enlarge(int s, int t){
    forn(i, 2*n)
        d[i] = -INF;
    d[s] = 0;
    tr[s] = 0;
    q[0] = s;
    int head = 0, tail = 1;
    
    while(head != tail){
        int v = q[head++];
        if(head == szQ)
            head = 0;
        inQ[v] = false;

        forn(i, sz(g[v])){
            const edge& cur = g[v][i];

            if(cur.c > cur.f && d[cur.to] < d[v] + cur.p){
                d[cur.to] = d[v] + cur.p;
                tr[cur.to] = v;
                trE[cur.to] = i;

                if(!inQ[cur.to]){
                    inQ[cur.to] = true;
                    q[tail++] = cur.to;
                    if(tail == szQ)
                        tail = 0;
                }
            }
        }
    }

    if(d[t] <= 0)
        return false;

    flow++;
    cost += d[t];

    for(int b = t; b != s; b = tr[b]){
        g[tr[b]][trE[b]].f++;
        g[b][ g[tr[b]][trE[b]].rev ].f--;
    }

    return true;
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> n >> m >> k;

    memset(hasC, 0, sizeof(hasC));
     
    forn(i, k){
        int x;
        scanf("%d", &x);
        x--;
        hasC[x] = true;    
    }

    forn(i, m){
        int x, y;
        scanf("%d %d", &x, &y);
        x--; y--;

        addEdge(n + x, y, 1, 0); 
    }

    int s = n, t = 0;

    forn(i, n){
        if(i == 0) continue;
            
        if(hasC[i])
            addEdge(i, i + n, 1, 1);
        else
            addEdge(i, i + n, 1, 0);
    }

    flow = 0;
    cost = ((hasC[0]) ? 1 : 0);

    while(enlarge(s, t));

    cout << cost << " " << flow << endl;

    return 0;
}
