#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <utility>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <cstring>

const int maxn = 430;
const int inf = 100000000;


bool isar[maxn];

int w[maxn][maxn], f[maxn][maxn], c[maxn][maxn], phi[maxn], d[maxn], prev[maxn], m, n;
bool b[maxn];

void Make(int u, int v, int c_, int f_, int w_) {
  w[u][v] = w_;
  f[u][v] = f_;
  c[u][v] = c_;
}

int best_ans = 0;

void GetFlow() {
  memset(b, false, sizeof(b));
  for (int i = 1; i <= 2*n; ++i) {
    phi[i] = inf;
  }
  phi[n+1] = 0;
  for (int k = 1; k <= 2*n; ++k) {
    for (int i = 1; i <= 2*n; ++i) {
      for (int j = 1; j <= 2*n; ++j) {
        if (phi[j] > phi[i] + w[i][j] && c[i][j] > 0) {
          phi[j] = phi[i] + w[i][j];
        }
      }
    }
  }
  int ans = 0;
  for (int k = 1; k <= 2*n; ++k) {
    for (int i = 1; i <= 2*n; ++i) {
      d[i] = inf;
    }
    d[n+1] = 0;
    memset(b, false, sizeof(b));
    for (int i = 1; i <= 2*n; ++i) {
      int mn = 1;
      for (int j = 2; j <= 2*n; ++j) {
        if ((!b[j]) && (b[mn] || d[j] < d[mn])) {
          mn = j;
        }
      }
      b[mn] = true;
      for (int j = 1; j <= 2*n; ++j) {
        if (c[mn][j]-f[mn][j] > 0 && d[j] > d[mn] + phi[mn]-phi[j] + w[mn][j]) {
          d[j] = d[mn] + phi[mn]-phi[j]+w[mn][j];
          prev[j] = mn;
        }
      }
    }
    
    if (d[1] < inf/2) {
      int cur = 1;
      bool flag = false;
      while (cur != n+1) {
        ans -= w[prev[cur]][cur];
        if (prev[cur] == cur-n && isar[prev[cur]]) {
          flag = true;
        }
        ++f[prev[cur]][cur];
        f[cur][prev[cur]] = -f[prev[cur]][cur];
        cur = prev[cur];
      }
      if (ans > best_ans && flag) {
        best_ans = ans;
      }
      if (!flag) {
        return;
      }
    } else {
      return;
    }
   
    for (int i = 1; i <= 2*n; ++i) {
      phi[i] += d[i];
    }
  }
}

int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
  
  int k;
  
  std::memset(isar, 0, sizeof(isar));
  std::cin >> n >> m >> k;
  for (int i = 0; i < k; ++i) {
    int v;
    std::cin >> v;
    isar[v] = true;
  }
  
  for (int i = 1; i <= 2*n; ++i) {
    for (int j = 1; j <= 2*n; ++j) {
      Make(i, j, 0, 0, inf);
    }
  }
  
  for (int i = 0; i < m; ++i) {
    int u, v, w;
    std::cin >> u >> v;
    if (u == 1) {
      Make(n+1, v, 1, 0, -1);
      Make(v, n+1, 0, 0, 1);
    } else {
      Make(n+u, v, 1, 0, 0);
      Make(v, n+u, 0, 0, 0);
    }
  }  
  for (int i = 2; i <= n; ++i) {
    if (isar[i]) {
      Make(i, n+i, 1, 0, -maxn);
      Make(n+i, i, 0, 0, maxn);
    } else {
      Make(i, n+i, 1, 0, 0);
      Make(n+i, i, 0, 0, 0);
    }
  }
  
  GetFlow();
  
  if (isar[1]) {
    best_ans += maxn;
  }
  
  std::cout << best_ans/maxn << " " << best_ans%maxn << std::endl;

  return 0;
}