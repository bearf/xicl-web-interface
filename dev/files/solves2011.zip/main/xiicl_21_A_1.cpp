#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <cmath>

#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include <numeric>

#define ALL(c) (c).begin(), (c).end()
#define sz(c) ((int)(c).size())

#define REP(i, n) for (int i = 0; i < (n); ++i)
#define FOR(i, s, n) for (int i = (s); i < (n); ++i)

#define mp make_pair
#define pb push_back

using namespace std;

typedef long long ll;

const int inf = int(1e+9);

void addEdge( int x, int y, int x1, int y1, int w, vector<vector<int> >& edl )
{
  int a = y * w + x;
  int b = y1 * w + x1;
  edl[a].pb(b);
  edl[b].pb(a);
}

int main()
{
  freopen("input.txt", "rt", stdin);
  freopen("output.txt", "wt", stdout);

  int w, h;
  while (scanf("%d%d", &h, &w) == 2)
  {
    vector<vector<int> > f(h, vector<int>(w) );
    vector<vector<int> > edl(w * h);

    REP(y, h)
      REP(x, w)
        scanf("%d", &f[y][x]);
    int ex, ey;
    scanf("%d%d", &ey, &ex);
    ex--, ey--;

    REP(y, h)
      REP(x, w - 1)
        if (f[y][x] == f[y][x + 1])
        {
          if (x > 0)
            addEdge(x - 1, y, x + 1, y, w, edl);
          if (x + 2 < w)
            addEdge(x, y, x + 2, y, w, edl);
        }

    REP(y, h - 1)
      REP(x, w)
        if (f[y][x] == f[y + 1][x])
        {
          if (y > 0)
            addEdge(x, y - 1, x, y + 1, w, edl);
          if (y + 2 < h)
            addEdge(x, y, x, y + 2, w, edl);
        }

    vector<int> dist(w * h, +inf);
    vector<int> prev(w * h, -1);
    dist[0] = 0;
    vector<int> q;
    q.pb(0);

    for (int st = 0; st < sz(q); ++st)
    {
      int v = q[st];
      for (int ei = 0; ei < sz(edl[v]); ++ei)
      {
        int to = edl[v][ei];
        if (dist[to] == +inf)
        {
          dist[to] = dist[v] + 1;
          prev[to] = v;
		  q.pb(to);
        }
      }
    }

    if (dist[ey * w + ex] == +inf)
    {
      printf("0\n");
    }
    else
    {
      vector<int> ans, seq;

      for (int v = ey * w + ex; v != -1; v = prev[v])
        seq.pb(v);
      reverse(ALL(seq));

      REP(i, sz(seq) - 1)
      {
        int y = seq[i] / w;
        int x = seq[i] % w;
        swap(f[y][x], f[seq[i + 1] / w][seq[i + 1] % w]);
        ans.pb(f[y][x]);
      }

      printf("%d\n", sz(ans));
      REP(i, sz(ans))
        printf("%d%c", ans[i], (i + 1 == w ? '\n' : ' '));
    }
  }

  return 0;
}


