#include <fstream>
using namespace std;
void main()
{
	long long int q;
	ifstream inp("input.txt");
	inp>>q;
	inp.close();
	long long int l=0;
	long long int str[400]={0}; long long int p=q;
	while (p>0)
	{
	 str[l]=p%2;
	 p=p/2;
	 l++;
	}
	p=1;
	long long int j,i=0,s=-1;
	while (i<l)
	{
	 if (str[i]==0)
	 {
	  if (s!=-1) p=p*(s+1);
	  s=0;
	 }
	 else
	 if (s!=-1)
	  s++;
	 i++;
	}
	if (s!=-1)
	 p=p*(s+1);
	ofstream oup("output.txt");
	oup<<p;
	oup.close();
}