#include <stdio.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <string.h>
#include <string>
#include <set>
#include <map>
#include <algorithm>
using namespace std;

const int MaxN = 210;

int n;
int graph[MaxN][MaxN];
bool was[MaxN][MaxN];
int deg[MaxN];

vector <int> ans, inp;

int ptr;

void dfs( int v ) {
	if( ++ptr < inp.size() ) {
		was[v][ inp[ptr] ] = true;
		was[ inp[ptr] ][v] = true;
		dfs( inp[ptr] );
	}

	for( int i = 0; i < n; i++ ) {
		if( graph[v][i] == 1 && !was[v][i] ) {
			was[v][i] = true;
			was[i][v] = true;

			dfs( i );
		}
	}

	ans.push_back( v );
}

int main()
{
	freopen( "input.txt", "r", stdin );
	freopen( "output.txt", "w", stdout );

	scanf( "%d", &n );
	n *= 2;
	n++;

	inp.clear();
	int temp;
	while( scanf( "%d", &temp ) > 0 ) {
		inp.push_back( temp );
	}

	for( int i = 0; i < n; i++ ) {
		deg[i] = n - 1;
	}

	for( int i = 0; i < n; i++ ) {
		for( int j = 0; j < n; j++ ) {
			graph[i][j] = 1;
			was[i][j] = false;
		}
	}

	/*for( int i = 1; i < inp.size(); i++ ) {
		int v1 = inp[i - 1];
		int v2 = inp[i];

		graph[v1][v2] = 2;
		if( v1 != v2 ) {
			graph[v2][v1] = 0;
		}
	}*/

	ans.clear();
	ptr = 0;
	dfs( inp[0] );

	reverse( ans.begin(), ans.end() );
	for( int i = 0; i < ans.size(); i++ ) {
		printf( "%d ", ans[i] );
	}
	printf("\n");
	return 0;
}
