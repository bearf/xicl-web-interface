#include <stdio.h>
#define P 1000000009

int m,n;
int a[131072];
int c[131072];
int d[131072];
long long z=0,p=1;

void gcd(int a,int b,int &x,int &y)
{
	if (!a)
		x=0,y=1;
	else
	{
		int x1,y1;
		gcd(b%a,a,x1,y1);
		x=y1-b/a*x1;
		y=x1;
	}
}

int rev(int a)
{
	int x,y;
	gcd(a,P,x,y);
	return (x+P)%P;
}

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int i;
	long long s=0;
	scanf("%d%d",&n,&m);
	for (i=0;i<m;++i)
		scanf("%d",&a[i]);
	for (i=0;i<m;++i)
		s+=a[i];
	if (s<n)
	{
		printf("0");
		return 0;
	}
	if (m==1)
	{
		printf("1");
		return 0;
	}
	for (i=0;i<n;++i)
		p=p*(m+i)%P;
	for (i=1;i<=n;++i)
		p=p*rev(i)%P;
	z=p;
	c[0]=1;
	for (i=1;i<=n;++i)
		c[i]=c[i-1]*(long long)(m+i-2)%P*rev(i)%P;
	d[0]=c[0];
	for (i=1;i<=n;++i)
		d[i]=(c[i]+d[i-1])%P;
	for (i=0;i<m;++i)
		if (a[i]<n)
			z=(z+P-d[n-a[i]-1])%P;
	printf("%lld",z);
	return 0;
}