#include <algorithm>
#include <iostream>
#include <string>
#include <cctype>
#include <set>
#include <vector>
#include <queue>

#define vv vector
#define mp make_pair
#define px first
#define py second
#define in cin
#define out cout

using namespace std;

typedef unsigned long long ll;

bool get_bit(ll mask, int k) {
	return (mask | (1LL << k)) == mask;
}

ll unset_bit(ll mask, int k) {
	return mask & (~(1LL << k));
}

vv< vv<ll> > C(65, vv<ll>(65));

ll solve(ll mask, int s) {
	int len = 64;
	for (int i = 63; i >= 0; i--) {
		if (get_bit(mask, i)) {
			break;
		} else {
			len--;
		}
	}
	if (s == len) {
		return 0;
	} else {
		return C[len - 1][s] + solve(unset_bit(mask, len - 1), s - 1);
	}
}

int main() {
	ios_base::sync_with_stdio(false);
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	ll n;

	for (int i = 0; i <= 64; i++) {
		C[i][0] = C[i][i] = 1;
	}

	for (int i = 1; i <= 64; i++) {
		for (int j = 1; j <= i; j++) {
			C[i][j] = C[i - 1][j - 1] + C[i - 1][j];
		}
	}

	while (in >> n) {
		ll ans = 1;
		int s = 0;
		for (int i = 0; i < 64; i++) {
			s += get_bit(n, i);
		}
		out << solve(n, s) + 1 << endl;
	}

	return 0;
}