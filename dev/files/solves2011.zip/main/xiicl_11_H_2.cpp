#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

#define fi first
#define se second
#define re return
#define pb push_back
#define mp make_pair
#define sz(x) (int)((x).size ())
#define all(x) (x).begin (), (x).end ()
#define rep(i,n) for (int i = 0; i < n; i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define fill(x,y) memset(x, y, sizeof (x))
#define PI 3.1415926535897932384626433832795 
#define y0 y2341234
#define y1 y2513452

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

int n;
int m, o = 0;
int d[1000], mark[1000], good[1000], prev[1000], pedge[1000], p[1000];
int ea[200000], eb[200000], ec[200000], ef[200000];
vi v[1000];

int addedge (int a, int b, int f, int c) {
	v[a].pb (o);
	ea[o] = a;
	eb[o] = b;
	ec[o] = c;
	ef[o] = f;
	o++;
	v[b].pb (o);
	ea[o] = b;
	eb[o] = a;
	ec[o] = -c;
	ef[o] = 0;
	o++;
	re 0;
}

int fb (int S, int F) {
	for (int i = 0; i < 2 * n; i++) d[i] = 1e8;
	d[S] = 0;
	while (true) {
		int ok = 0;
		for (int j = 0; j < o; j++)
			if (ef[j] > 0 && d[eb[j]] > d[ea[j]] + ec[j]) {
				ok = 1;
				d[eb[j]] = d[ea[j]] + ec[j];
			}	
		if (!ok) break;
	}
	for (int i = 0; i < 2 * n; i++) p[i] = d[i];
	re 0;
}

int go (int S, int F) {
	for (int i = 0; i < 2 * n; i++) { d[i] = 1e8; mark[i] = 0; }
	mark[S] = 1;
	d[S] = 0;
	for (int i = 0; i < 2 * n; i++) {
		int k = -1;
		for (int j = 0; j < 2 * n; j++)
			if (mark[j] == 1 && (k == -1 || d[k] > d[j]))
				k = j;
		if (k == -1) re 0;
		mark[k] = 2;
		if (k == F) break;
		for (int j = 0; j < sz (v[k]); j++) {
			int e = v[k][j];
			int y = eb[e];
			if (ef[e] && d[y] > d[k] + ec[e] + p[k] - p[y]) {
				d[y] = d[k] + ec[e] + p[k] - p[y];
				mark[y] = 1;
				prev[y] = k;
				pedge[y] = e;
			}
		}
	}
	int tmp = d[F] - p[S] + p[F];
	for (int i = 0; i < 2 * n; i++)
		if (mark[i] == 2)
			p[i] += d[i];
		else
			p[i] += d[F];	
	re tmp;
}

int main () {
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);

	int k;
	scanf ("%d%d%d", &n, &m, &k);
	for (int i = 0; i < k; i++) {
		int a;
		scanf ("%d", &a); a--;
		good[a] = 1;
	}

	for (int i = 0; i < m; i++) {
		int a, b;
		scanf ("%d%d", &a, &b); a--; b--;
		addedge (2 * a + 1, 2 * b, 1, 0);
	}
	int ans = good[0];
	for (int i = 1; i < n; i++)
		addedge (2 * i, 2 * i + 1, 1, -good[i]);
	fb (1, 0);
	int tmp = 0, res = 0;
	while ((tmp = go (1, 0)) < 0) { 
		ans -= tmp; 
		res++; 
		int j = 0;
		while (j != 1) {
//			printf ("%d ", j);
			int e = pedge[j];
			ef[e]--;
			ef[e ^ 1]++;
			j = prev[j];
		}
//		printf ("\n");
	}
	printf ("%d %d\n", ans, res);
	re 0;
}