#include <stdio.h>
#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <set>
#include <memory.h>
#include <math.h>
#include <algorithm>
using namespace std;
typedef long double ld;
typedef long long li;
typedef vector <int> vi;
#define pb push_back
#define mp make_pair
void solve ();
int main ()
{
#ifdef _DEBUG 
	freopen ("in.txt", "r", stdin);
#else 
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);
#endif
	solve ();
	return 0;
}
#define int li
int a, b, x, y, z;
int s1,s5=0, s2=0, s3=0, s4,i,k,l,m;
void solve ()
{
	cin>>a>>b>>x>>y>>z;
	s1=a*((b-1)*x*(x+1)/2+x);
	s2=a*(b-1)*y*(y-1)/2+y*(a+b-1);
	s3=a*(b-1)*z*(z-1)/2+z*(a+b-1);
	s4=a*x*(a*y-b);
	if(a*(x-z)+(b-1)*y+1>0)
		s5+=(a*(x-z)+(b-1)*y+1)*((b-1)*z+1);
	if(a*(x-z)+(b-1)*y+1<0)
		s5+=-1*(1+(b-1)*y+a*(x-z))*((b-1)*x+a*y-b+1);
	cout<<(s1+s2+s3+s4+s5);
}