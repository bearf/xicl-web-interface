#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <utility>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <cstring>

using namespace std;

unsigned long long max (unsigned long long a, unsigned long long b){
  return a>b?a:b;
}

int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
  
  unsigned long long a, b, x, y, z;
  
  cin >> a >> b >> x >> y >> z;
  
  unsigned long long s1, s2, s3, sq, h, w;
  
  s1 = (x-1)*x/2 * a * (b-1);
  s2 = (y+1)*y/2 * (b-1) * a - y*(b-1);
  s3 = z*(z+1)/2*a*(b-1)-z*(b-1);
  sq = (x-1)*(b-1)*(y*(b-1)+1);
  
  w = (b-1)*(x-1)+y*a+(b-1)*z+1;
  h = max (z*a, a*x+y*(b-1)+1);

  cout << h*w-s1-s2-s3-sq;
  

  return 0;
}