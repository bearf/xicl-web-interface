#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:200000000")
#define _SECURE_SCL 0
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace std;


typedef long long int64;

const int INF = (int) 1E9;
const int64 INF64 = (int64) 1E18;
const double EPS = 1E-9;
const double PI = acos((double)0) * 2;

#define forn(i,n)  for (int i=0; i<int(n); ++i)
#define ford(i,n)  for (int i=int(n)-1; i>=0; --i)
#define fore(i,l,n)  for (int i=int(l); i<int(n); ++i)
#define all(a)  a.begin(), a.end()
#define fs  first
#define sc  second
#define pb  push_back
#define mp  make_pair


const int MAXN = 210;


int nn, n, g[MAXN][MAXN], x, y;
vector<int> inp;


void read() {
	cin >> nn;

	n = nn*2+1;
	forn(i,n)
		forn(j,n)
			g[i][j] = 1;

	int prev = -1,
		cur;
	for (; scanf("%d",&cur)==1; ) {
		inp.pb (cur);
		if (prev != -1) {
			--g[prev][cur];
			--g[cur][prev];
		}
		else
			x = cur;
		prev = cur;
	}
	y = cur;
}

bool used[MAXN];
vector<int> st;

bool dfs (int v, int start, int prev) {
	used[v] = true;
	st.pb (v);
	forn(to,n)
		if (g[v][to] > 0) {
			if (to == prev)
				continue;
			if (!used[to])
				if (dfs (to, start, v))
					return true;
			if (to == start)
				return true;
		}
	st.pop_back();
	return false;
}


void solve() {
	/*
	if (g[y][x] > 0) {
		--g[y][x];
		--g[x][y];
	}
	*/

	st.clear();
	memset (used, 0, sizeof used);
	if (y != x && dfs (y, x, -1)) {
		st.erase (st.begin());
		inp.insert (inp.end(), all (st));
	}

	forn(i,inp.size()) {
		int v = inp[i];
		for (;;) {
			st.clear();
			memset (used, 0, sizeof used);
			if (!dfs (v, v, -1))
				break;
			inp.insert (inp.begin()+i, all (st));
			forn(j,st.size()) {
				int x = st[j],  y = st[(j+1)%st.size()];
				--g[x][y];
				--g[y][x];
			}
		}
	}
	inp.pb (x);

	forn(i,inp.size())
		printf ("%d ", inp[i]);
	puts("");
}


int main() {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	read();
	solve();

}
