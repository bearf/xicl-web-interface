#include <stdio.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <string.h>
#include <string>
#include <set>
#include <map>
#include <algorithm>
using namespace std;

enum TType { ROOT, L, R, N, HZ };

struct TConfig
{
	TType type;
	int num;

	TConfig( TType _type = HZ, int _num = 0 )
	{
		type = _type;
		num = _num;
	}
};

vector<TConfig> stack;

long long ans = 0;

const int MaxN = 200010;
int num[MaxN];
int g[MaxN][2];

void dfs( int v, int prev, TType type )
{
	TType old = HZ;
	if( stack.size() > 0 ) {
		old = stack[stack.size() - 1].type;
	}

	if(  old == type ) {
		stack[stack.size() - 1].num++;
	} else {
		stack.push_back( TConfig( type, 1 ) );
	}

	//L case
	if( type == L ) {
		int prevInd = stack.size() - 2;
		if( prevInd >= 0 ) {
			if( stack[prevInd].type == R ) {
				ans++;
			}

			if( stack[prevInd].type == N ) {
				ans += (long long) stack[prevInd].num;
			}
		}
	}

	//R case
	if( type == R ) {
		int prevInd = stack.size() - 2;
		if( prevInd >= 0 ) {
			if( stack[prevInd].type == L ) {
				ans++;
			}

			if( stack[prevInd].type == N ) {
				ans += (long long) stack[prevInd].num;
			}
		}
	}

	//N case
	if( type == N ) {
		int prevInd = stack.size() - 2;
		if( prevInd >= 0 ) {
			if( stack[prevInd].type == L ) {
				ans++;
			}

			if( stack[prevInd].type == R ) {
				ans++;
			}
		}
	}

	if( num[v] == 1 ) {
		dfs( g[v][0], v, N );
	}

	if( num[v] == 2 ) {
		dfs( g[v][0], v, L );
		dfs( g[v][1], v, R );
	}

	if(  old == type ) {
		stack[stack.size() - 1].num--;
	} else {
		stack.pop_back();
	}
}

int main()
{
	freopen( "input.txt", "r", stdin );
	freopen( "output.txt", "w", stdout );

	int n;
	ans = 0;
	scanf( "%d", &n );
	for( int i = 0; i < n; i++ ) {
		scanf( "%d", &num[i] );

		if( num[i] == 2 ) {
			ans++;
		}

		for( int j = 0; j < num[i]; j++ ) {
			scanf( "%d", &g[i][j] );
			g[i][j]--;
		}
	}

	stack.clear();
	dfs( 0, -1, ROOT );

	printf( "%lld\n", ans );
	return 0;
}
