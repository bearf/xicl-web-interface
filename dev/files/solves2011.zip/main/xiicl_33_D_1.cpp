#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int isgl(char a) {
	if (a=='a' || a=='i' || a=='o' || a=='u' || a=='y' || a=='e' || a=='A' || a=='I' || a=='O' || a=='U' || a=='Y' || a=='E' ) return 1;
	else return 0;
}

int main() {
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);

	char str[100005];
	int n;
	scanf("%d\n",&n);
	gets(str);
	int t=isgl(str[0]);
	int i=1;
	for (i=1;i<n;i++) {
		if (t) {
			if (isgl(str[i])) {i-=1;break;}
			else t=0;
		} else {
			if (!isgl(str[i])) {i-=1;break;}
			else t=1;
		}
	}

	if (i>=n) 
		puts("GOOD"); 
	else 
		puts("BAD"); 

	return 0;
}
