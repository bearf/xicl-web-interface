import java.io.*;
import java.util.*;

public class Solution implements Runnable {

	static class PointInt {
		final int x, y;

		public PointInt(int a, int b) {
			this.x = a;
			this.y = b;
		}

		double dist(PointInt p) {
			double dx = x - p.x;
			double dy = y - p.y;
			return Math.sqrt(dx * dx + dy * dy);
		}
	}

	static class Line {
		final double a, b, c;

		Line(Point p1, Point p2) {
			a = p2.y - p1.y;
			b = p1.x - p2.x;
			c = -a * p1.x - b * p1.y;
		}

		Point intersect(Line l) {
			double det = a * l.b - b * l.a;
			double det1 = -c * l.b - -l.c * b;
			double det2 = a * -l.c - l.a * -c;
			return new Point(det1 / det, det2 / det);
		}

	}

	static class LineInt {
		final long a, b, c;

		LineInt(PointInt p1, PointInt p2) {
			a = p2.y - p1.y;
			b = p1.x - p2.x;
			c = -a * p1.x - b * p1.y;
		}

		int side(PointInt p) {
			return Long.signum(a * p.x + b * p.y + c);
		}
	}

	static class Point {
		final double x, y;

		public Point(double x, double y) {
			this.x = x;
			this.y = y;
		}

		double dist(Point p) {
			double dx = x - p.x;
			double dy = y - p.y;
			return Math.sqrt(dx * dx + dy * dy);
		}

		double abs() {
			return Math.sqrt(x * x + y * y);
		}

		double smul(Point p) {
			return x * p.x + y * p.y;
		}

		Point norm() {
			double a = abs();
			return new Point(x / a, y / a);
		}

		Point add(Point p) {
			return new Point(x + p.x, y + p.y);
		}

		Point sub(Point p) {
			return new Point(x - p.x, y - p.y);
		}

		public String toString() {
			return String.format(Locale.US, "%.10f %.10f", x, y);
		}
	}

	PointInt a, b;

	static class River implements Comparable<River> {
		int y0, y1, yr;
		Point vector;

		public River(int y0, int y1, int yr) {
			this.y0 = y0;
			this.y1 = y1;
			this.yr = yr;
		}

		Line getBottomLine() {
			Point p1 = new Point(0, y0);
			Point p2 = new Point(L, yr + y0);
			return new Line(p1, p2);
		}

		void getVector() {
			Point p1 = new Point(0, y1 - y0);
			Point p2 = new Point(L, yr);
			p2 = p2.norm();
			// System.err.println(p1 + " " + p2);
			double ok = p1.smul(p2);
			Point add = new Point(p2.x * ok, p2.y * ok);
			// System.err.println(add);
			p1 = p1.sub(add);
			vector = p1;
			// System.err.println("ASDASD " + vector);
		}

		boolean aboveRiver(PointInt p) {
			return (long) (p.y * L) > (long) y0 * L + (long) yr * p.x;
		}

		public boolean divides(PointInt a, PointInt b) {
			PointInt one = new PointInt(0, y0);
			PointInt two = new PointInt(L, y0 + yr);
			LineInt l = new LineInt(one, two);
			int s1 = l.side(a);
			int s2 = l.side(b);
			if (s1 == 0 || s2 == 0)
				throw new AssertionError();
			return s1 * s2 < 0;
		}

		@Override
		public int compareTo(River arg0) {
			return y0 - arg0.y0;
		}
	}

	static int L;

	void solve() throws IOException {
		a = new PointInt(nextInt(), nextInt());
		b = new PointInt(nextInt(), nextInt());
		L = nextInt();
		int n = nextInt();
		ArrayList<River> goodRivers = new ArrayList<Solution.River>();
		for (int i = 0; i < n; i++) {
			int y0 = nextInt(), y1 = nextInt(), yr = nextInt();
			yr -= y0;
			River r = new River(y0, y1, yr);
			if (r.divides(a, b)) {
				goodRivers.add(r);
			}
		}

		if (goodRivers.isEmpty()) {
			double res = a.dist(b);
			out.printf(Locale.US, "%.10f", res);
			return;
		}

		River[] rivers = (River[]) goodRivers.toArray(new River[goodRivers
				.size()]);
		Arrays.sort(rivers);
		boolean reverse = false;
		if (rivers[0].aboveRiver(a)) {
			PointInt tmp = a;
			reverse = true;
			a = b;
			b = tmp;
		}

		n = rivers.length;
		Point allvector = new Point(0, 0);
		for (int i = 0; i < n; i++) {
			rivers[i].getVector();
			// System.err.println(rivers[i].vector);
			allvector = allvector.add(rivers[i].vector);
		}

		Point diff = new Point(b.x - a.x, b.y - a.y);
		diff = diff.sub(allvector);
		double res = diff.abs() + allvector.abs();
		out.printf(Locale.US, "%.10f\n", res);

		Point apoint = new Point(a.x, a.y);
		// System.err.println(apoint);
		// System.err.println(diff);
		ArrayList<Point> ans = new ArrayList<Solution.Point>();
		Point shift = new Point(0, 0);

		for (int i = 0; i < n; i++) {
			Line line = rivers[i].getBottomLine();
			Line line2 = new Line(apoint.add(shift), apoint.add(diff));
			Point p = line.intersect(line2);
			ans.add(p);
			p = p.add(rivers[i].vector);
			ans.add(p);
			shift = shift.add(rivers[i].vector);
		}
		if (reverse)
			Collections.reverse(ans);
		for (Point p : ans) {
			out.println(p);
		}
	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			out = new PrintWriter("output.txt");
			st = new StringTokenizer("");
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
