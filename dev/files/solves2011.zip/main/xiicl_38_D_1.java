import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;

public class Solution implements Runnable {

	public void run() {
		int n = nextInt();
		String s = nextLine().toLowerCase();
		int prev = -1;
		if (s.charAt(0) == 'a' || s.charAt(0) == 'e' || s.charAt(0) == 'i' || 
				s.charAt(0) == 'o' || s.charAt(0) == 'u' || s.charAt(0) == 'y') {
			prev = 0;
		}
		else {
			prev = 1;
		}
		
		boolean bad = false;
		for (int i = 1; i < s.length(); ++i) {
			int cur = -1;
			if (s.charAt(i) == 'a' || s.charAt(i) == 'e' || s.charAt(i) == 'i' || 
					s.charAt(i) == 'o' || s.charAt(i) == 'u' || s.charAt(i) == 'y') {
				cur = 0;
			}
			else {
				cur = 1;
			}
			
			if (prev == cur) {
				bad = true;
				break;
			}
			prev = cur;
		}
		
		if (bad) {
			out.println("BAD");
		}
		else {
			out.println("GOOD");
		}
		out.flush();
	}
	
	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}
	
	private void loadLine() {
		try{
			stk = new StringTokenizer(br.readLine());
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String nextLine() {
		try {
			return br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private int nextInt() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Integer.parseInt(stk.nextToken());
	}

}
