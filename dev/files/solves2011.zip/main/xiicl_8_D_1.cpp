#include<fstream>
using namespace std;
int sog(char a){
	switch(a){
		case 'e':
			return 0;
		case 'y':
			return 0;
		case 'u':
			return 0;
		case 'i':
			return 0;
		case 'o':
			return 0;
		case 'a':
			return 0;
		case 'E':
			return 0;
		case 'Y':
			return 0;
		case 'U':
			return 0;
		case 'I':
			return 0;
		case 'O':
			return 0;
		case 'A':
			return 0;
	}
	return 1;
}
int  main(){
	char a[100005];
	ifstream in("input.txt");
	ofstream out("output.txt");
	int n;
	in>>n;
	in>>a;
	int *c=new int[n];
	for(int i=0;i<n;i++){
		c[i]=sog(a[i]);
	}
	int val=1;
	if(c[0]==1){
		val=1;
	}
	if(c[0]==0){
		val=0;
	}
	for(int i=0;i<n;i++){
		if(c[i]!=val){
			out<<"BAD";
			return 0;
		}
		if(val==0){
			val=1;
		}
		else{
			val=0;
		}
	}
	out<<"GOOD";
	return 0;
}