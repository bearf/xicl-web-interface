#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <map>

//using namespace std;
using std::vector;
using std::string;

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a, b) memset(a, b, sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int,int> pii;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	va_end(args);
	
	fflush(stdout);
#endif
#endif
}

struct Node {
	int next, prev;
};

const int perm[3][4] = {{2, 3, 1, 0}, {3, 2, 0, 1}, {3, 1, 2, 0}};
const int L[3] = {1, 2, 1};
const int R[3] = {1, 2, 2};

const int NNN = 50;
const int N = 20000;

std::map <vector <int> , int> perms;
int a[N];
int d[N];
int par[N];
int parS[N];

int begin[N];
int end[N];

vector <vector <int> > perm2;

int getNumber(const vector <int> & v)
{
	if (perms.find(v) != perms.end())
		return perms[v];
	int num = perms.size();
	perm2.push_back(v);	
	perms[v] = num;
	return num;
}


void dfs(const vector <int>& v, int dd, int pp, int qq)
{
	int s = getNumber(v);
	if (d[s] != -1)
		return ;
/*	for (int i = 0; i < 4; ++i)
/*		dbg("%d ", v[i]);
	dbg(" -> %d, %d\n", s, dd);*/

	d[s] = dd;
	par[s] = pp;
	parS[s] = qq;

	vector <int> v2(4);
	for (int i = 0; i < 3; ++i)
	{
		for (int j = 0; j < 4; ++j)
		{
			v2[j] = v[perm[i][j]];
		}
		dfs(v2, dd + 1, i, s);
	}
}

Node node[N];
int first, last;

void print()
{
	for (int i = first; i != -1; i = node[i].next)
	{
		dbg("%d ", i);
	}
	dbg("\n");
}


void doMove(int l, int r)
{
	printf("%d %d\n", l + 1, r + 1);
	node[last].next = l;
	node[first].prev = r;

	int first1 = node[r].next;
	int last1 = node[l].prev;

	node[r].next = first;
	node[l].prev = last;

	first = first1;
	last = last1;

	node[first].prev = -1;
	node[last].next = -1;

	print();
}

bool isFirst(int p)
{
	return p == first;
}

bool isSecond(int p)
{
	return isFirst(node[p].prev);
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

/*	vector <int> v;
	for (int i = 0; i < 4; ++i)
		v.push_back(i);
	fill(d, 0xFF);
	dfs(v, 0, -1);
	printf("%d\n", (int)perms.size());*/

	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; ++i)
	{
		scanf("%d", &a[i]);
		--a[i];
	}

	if (n == 3)
	{
		if (a[0] == 2 && a[1] == 1 && a[2] == 0)
		{
			printf("2 2\n");
		}
		else
			printf("0\n");

		return 0;	
	}

	for (int i = 0; i < n; ++i)
	{
		node[a[i]].prev = (i == 0) ? -1 : a[i - 1];
		node[a[i]].next = (i == n - 1) ? -1 : a[i + 1];
	}
	first = a[0];
	last = a[n - 1];

	int x;
	for (x = 0; x < n - 4; ++x)
	{
		if (!isFirst(x + 1))
		{
			if (isSecond(x + 1))
				doMove(node[x + 1].prev, x + 1);
			doMove(node[x + 1].prev, node[x + 1].prev);
		}
		doMove(node[x + 1].next, x);
	}

	vector <int> v;
	for (int i = first; i != -1; i = node[i].next)
	{
		if (i == 0 || i > x)
		{
			v.push_back(i);
			dbg("%d\n", i);
		}
	}

	vector <int> v2 = v;
	sort(v2.begin(), v2.end());
	for (int i = 0; i < 4; ++i)
	{
		begin[v2[i]] = v2[i];
		end[v2[i]] = v2[i];
	}
	end[v2[0]] = x;
	fill(d, 0xFF);
	dfs(v2, 0, -1, -1);

//	dbg("%d\n", begin[4]);

	int s = getNumber(v);
	while (s != 0)
	{
		int J = par[s];
		dbg("J = %d\n", J);
		s = parS[s];
		v = perm2[s];
		int LL = v[L[J]];
		int RR = v[R[J]];
		dbg("LL = %d, RR = %d\n", LL, RR);
		doMove(begin[LL], end[RR]);
	}

	for (int i = 0; i < 4; ++i)
		dbg("%d ", v[i]);
	dbg("\n");
	print();

	return 0;
}