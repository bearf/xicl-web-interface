#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:200000000")
#define _SECURE_SCL 0
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace std;


typedef long long int64;

#define double long double
const int INF = (int) 1E9;
const int64 INF64 = (int64) 1E18;
const double EPS = 1E-8;
const double PI = acos((double)0) * 2;

#define forn(i,n)  for (int i=0; i<int(n); ++i)
#define ford(i,n)  for (int i=int(n)-1; i>=0; --i)
#define fore(i,l,n)  for (int i=int(l); i<int(n); ++i)
#define all(a)  a.begin(), a.end()
#define fs  first
#define sc  second
#define pb  push_back
#define mp  make_pair


double L;


int sign (double x) {
	return abs(x)<EPS ? 0 : x>0 ? +1 : -1;
}


struct pt {
	double x, y;

	pt() { }
	pt (double x, double y) : x(x), y(y) { }

	pt norm (double len) const {
		double z = len / sqrt(x*x+y*y);
		return pt (x*z, y*z);
	}

	void operator-= (pt p) {
		x -= p.x;
		y -= p.y;
	}
	void operator+= (pt p) {
		x += p.x;
		y += p.y;
	}
	pt operator- (pt p) const {
		return pt (x-p.x, y-p.y);
	}
	pt operator+ (pt p) const {
		return pt (x+p.x, y+p.y);
	}
	pt operator* (double z) const {
		return pt (x*z, y*z);
	}
};

inline double dist (pt a, pt b) {
	return sqrt ((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y));
}

inline double scalar (pt a, pt b) {
	return a.x*b.x + a.y*b.y;
}

struct line {
	double a, b, c;

	line() { }

	line (pt p, pt q) {
		a = p.y - q.y;
		b = q.x - p.x;
		c = - a * p.x - b * p.y;
		norm();
	}

	void norm() {
		double z = sqrt (a*a+b*b);
		a/=z, b/=z, c/=z;
	}

	double dist (pt p) const {
		return a * p.x + b * p.y + c;
	}

	void inv() {
		a *= -1,  b *= -1,  c *= -1;
	}

	void shift (pt vec) {
		c -= a * vec.x + b * vec.y;
	}
};

inline double dist_seg (pt a, pt p, pt q) {
	if (sign (scalar (a-p, q-p)) >= 0 && sign (scalar (a-q, q-p)) >= 0)
		return abs (line (p, q).dist (a));
	return min (dist (a, p), dist (a, q));
}

#define det(a,b,c,d) (a*d-b*c)

pt intersect (line m, line n) {
	double zn = det (m.a, m.b, n.a, n.b);
	return pt (
		-det (m.c, m.b, n.c, n.b) / zn,
		-det (m.a, m.c, n.a, n.c) / zn
	);
}


pt a, b;


struct river {
	double y[3], dy, h;
	line l[2];

	pt vec;

	void get_lines() {
		dy = y[1] - y[0];

		l[0] = line (pt (0, y[0]), pt (L, y[2]));
		l[1] = line (pt (0, y[1]), pt (L, y[2]+dy));
	}

	double dist (pt p) const {
		return min (
			dist_seg (p, pt(0,y[0]), pt(L,y[2])),
			dist_seg (p, pt(0,y[1]), pt(L,y[2]+dy))
		);
	}

	bool operator< (const river & r) const {
		return dist (a) < r.dist (a) - EPS;
	}
};


int n;
vector<river> riv;


bool read() {
	if (! (cin >> a.x >> a.y >> b.x >> b.y >> L >> n))
		return false;
	riv.resize (n);
	forn(i,n)
		forn(j,3)
			cin >> riv[i].y[j];
	return true;
}


void solve() {
	forn(i,n) {
		riv[i].get_lines();
		if (abs (riv[i].l[0].dist (a)) > abs (riv[i].l[1].dist (a)))
			swap (riv[i].l[0], riv[i].l[1]);
	}

	vector<river> nriv;
	forn(i,n) {
		line l = riv[i].l[0];
		if (sign (l.dist (a)) != sign (l.dist (b)))
			nriv.pb (riv[i]);
	}
	riv = nriv;
	sort (all (riv));
	n = (int) riv.size();

	forn(i,n)
		if (sign (riv[i].l[0].dist (a)) != 1) {
			riv[i].l[0].inv();
			riv[i].l[1].inv();
		}

	forn(i,n) {
		riv[i].h = abs (riv[i].l[0].c - riv[i].l[1].c);
		riv[i].vec = pt (riv[i].l[0].a, riv[i].l[0].b).norm (- riv[i].h);
	}

	pt new_b = b;
	ford(i,n) {
		new_b -= riv[i].vec;
		fore(j,i+1,n)
			riv[j].l[0].shift (pt(0,0) - riv[i].vec);
	}

	line main_line (a, new_b);

	vector<pt> ans (n);
	forn(i,n)
		ans[i] = intersect (main_line, riv[i].l[0]);
	
	pt shift (0,0);
	forn(i,n) {
		ans[i] += shift;
		shift += riv[i].vec;
	}

	vector<pt> ans2 (n);
	forn(i,n)
		ans2[i] = ans[i] + riv[i].vec;

	forn(i,n) {
		pt vec = riv[i].vec;
		swap (vec.x, vec.y);
		vec.x *= -1;

		double lt = min (ans[i].x, ans2[i].x);
		if (lt < 0) {
			double coeff = -lt / vec.x;
			ans[i] += vec * coeff;
			ans2[i] += vec * coeff;
		}

		double rt = max (ans[i].x, ans2[i].x);
		if (rt > L) {
			double coeff = (rt-L) / vec.x;
			ans[i] -= vec * coeff;
			ans2[i] -= vec * coeff;
		}
	}

	double ans_len = 0;
	if (n == 0)
		ans_len = dist (a, b);
	else {
		forn(i,n)
			ans_len += dist (ans[i], ans2[i]);
		forn(i,n-1)
			ans_len += dist (ans2[i], ans[i+1]);
		ans_len += dist (a, ans[0]);
		ans_len += dist (ans2[n-1], b);
	}

	cout.precision (20);
	cout.setf (ios::fixed);
	cout << ans_len << endl;
	forn(i,n) {
		cout << ans[i].x << ' ' << ans[i].y << endl;
		cout << ans2[i].x << ' ' << ans2[i].y << endl;
	}
}


int main() {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	while (read())
		solve();

}
