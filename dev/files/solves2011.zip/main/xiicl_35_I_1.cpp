#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<climits>
#include<vector>
#include<map>
#include<set>
#include<algorithm>

using namespace std;

#define ws dfgjkhdg
#define y1 sdjghdjg
#define pb push_back
#define mp make_pair
#define fs first
#define sc second

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pi;

ll dp[100][100];
int a[100];
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	ll n;
	cin>>n;
	int kr=1;
	while (n>0){
		a[kr]=n&1;
		n/=2;
		kr++;
	}
	dp[0][0]=1;
	for (int i=1;i<kr;i++){
		for (int j=0;j<=1;j++){
			for (int k=0;k<=2;k++)
				if ((j+k)%2==a[i]){
					dp[i][(j+k-a[i])/2]+=dp[i-1][j];
				}
			}
	}
	cout<<dp[kr-1][0]<<endl;
	return 0;
}
