#include <stdio.h>

int a[64];
long long b[64][64];

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long n;
	scanf("%lld",&n);
	int i,j,k;
	long long z=0;
	for (i=0;n;++i)
	{
		a[i]=n&1;
		n>>=1;
	}
	n=i;
	if (a[0])
		b[0][0]=1;
	else
		b[0][1]=1;
	for (i=1;i<n;++i)
		if (a[i])
		{
			for (j=0;j<64;++j)
				b[i][0]+=b[i-1][j];
			for (j=1;j<64;++j)
				b[i][1]+=j*b[i-1][j];
		}
		else
			for (j=1;j<64;++j)
				b[i][j]=b[i-1][j-1];
	for (j=0;j<64;++j)
		z+=b[n-1][j];
	printf("%lld",z);
	return 0;
}