#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<climits>
#include<vector>
#include<map>
#include<set>
#include<algorithm>

using namespace std;

#define ws dfgjkhdg
#define y1 sdjghdjg
#define pb push_back
#define mp make_pair
#define fs first
#define sc second

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pi;

int a[100010];
int d[100010];
int n;

int f(int x){
	for(int i=0;i<n;i++) d[i]=a[i];
	int y=x;
	for(int i=x;i<n && d[i]==0;i++) y++;
	if(y==n) return 0;
	d[y]--;
	d[x]++;
	int l=1;
	int j=x;
	for(int i=x;i<n-1;i++){
		if(i==j) j++;
		if(d[i]>1){
			d[i+1]+=d[i]/2;
		}
		if(d[i]==1){
			for(;j<n && d[j]==0;j++);
			if(j==n) return l;
			else{
				d[j]--;
				d[i+1]++;
			}
		}
		l++;
	}
	return l;
}
			
			
				
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf("%d", &n);
	for(int i=0;i<n;i++) scanf("%d", a+i);
	int res1=f(0);
	int l=0, r=n-1;
	int m;
	while(l<r){
		//cerr<<l<<" "<<r<<endl;
		m=(l+r+1)/2;
		if(f(m)==res1) l=m;
		else r=m-1;
	}
	printf("%d %d", res1, l+res1);
	return 0;
}
