#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <utility>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <cstring>

using namespace std;

int G (char c) {
  if (c >= 'A' && c <= 'Z') c = 'a' + (c - 'A');
  if (c=='a' || c=='e' || c=='i' || c=='o' || c=='u' || c=='y') return 1;
  else return 0;
}

char s[200000];
int n;

int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
  
  cin >> n;
  cin >> s;
  
  bool good = true;
  for (int i=1; i<n-1; i++) {
    good &= (G (s[i]) != G (s[i-1])) && (G (s[i]) != G (s[i+1]));
  }
  
  if (good) cout << "GOOD";
  else cout << "BAD";

  return 0;
}