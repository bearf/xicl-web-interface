import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.StringTokenizer;


public class Solution implements Runnable {
	BufferedReader in;
	PrintWriter out;
	StringTokenizer st;
	String nextToken() throws Exception {
		if (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(in.readLine());
		return st.nextToken();
	}
	int nextInt() throws Exception {
		return Integer.parseInt(nextToken());
	}
	
	public static void main(String[] args) {
		(new Thread(new Solution())).start();
	}
	
	int n;
	int[] k;
	int[] l;
	int[] r;
	long ans = 0;
	long[] ll, rr, pp;
	int[] pk;
	
	void dfs(int q) {
		if (k[q] == 0) {
			ll[q] = rr[q] = pp[q] = 0;
			pk[q] = q;
		}
		if (k[q] == 1) {
			dfs(l[q]);
			ll[q] = rr[q] = 0;
			pp[q] = pp[l[q]] + 1;
			pk[q] = pk[l[q]];
			ans += ll[pk[q]] + rr[pk[q]];
		}
		if (k[q] == 2) {
			dfs(l[q]);
			dfs(r[q]);
			pp[q] = 0;
			pk[q] = q;
			ll[q] = ll[l[q]] + 1;
			rr[q] = rr[r[q]] + 1;
			ans += rr[l[q]] + pp[l[q]] + ll[r[q]] + pp[r[q]];
		}
	}
	
	void solve() throws Exception {
		n = nextInt();
		k = new int[n + 1];
		l = new int[n + 1];
		r = new int[n + 1];
		ll = new long[n + 1];
		rr = new long[n + 1];
		pp = new long[n + 1];
		pk = new int[n + 1];
		ans = 0;
		for (int i = 1; i <= n; i++) {
			k[i] = nextInt();
			if (k[i] > 0) l[i] = nextInt();
			if (k[i] > 1) r[i] = nextInt();
			if (k[i] == 2) ans++;
		}
		dfs(1);
		out.println(ans);
	}

	public void run() {
		try {
			in = new BufferedReader(new FileReader(new File("input.txt")));
			out = new PrintWriter(new File("output.txt"));
			st = null;
			solve();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		} finally {
			out.flush();
		}
	}
	
}
