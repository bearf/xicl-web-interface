program qwe;

{$APPTYPE CONSOLE}

uses
  SysUtils;

function okok(c:char):boolean;
begin
 if (upcase(c)='A')or(upcase(c)='E')or(upcase(c)='I')or(upcase(c)='O')or(upcase(c)='U')or(upcase(c)='Y') then result:=true else
 result:=false;
end;

var
 i,n:integer;
 s:string;
 b:boolean;

begin
 assign(input,'input.txt');
 reset(input);
 assign(output,'output.txt');
 rewrite(output);
 readln(n);
 readln(s);
 b:=true;
 if n=1 then writeln('GOOD') else
 begin
  for i:=1 to n-1 do
  if not(okok(s[i]) xor okok(s[i+1])) then b:=false;
  if b then writeln('GOOD') else writeln('BAD');
 end;
 close(input);
 close(output);
end.