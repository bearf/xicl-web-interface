//#pragma comment("/STACK:64000000")
#include <stdio.h>
#include <string.h>
#include <set>
#include <map>
#include <cassert>
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
#define REP(i, a, b) for(int i = (a); i < (b); ++i)
typedef long long ll;
#define _(a, b) memset((a), (b), sizeof(a))

bool g[300][300];
vector<int> order ;
int n;

void dfs(int cur) {
	for(int i = 0; i <= 2 * n; ++i) {
		if (g[cur][i]) {
			g[cur][i] = g[i][cur] = false;
			dfs(i);
		}
	}
	order.push_back(cur);
}
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	_(g, true);	
	vector<int> path;
	int a , b;
	cin >> n;
	cin >> a;
	path.push_back(a);
	while (cin >> b) {
		path.push_back(b);
		g[a][b] = false;
		g[b][a] = false;
		a = b;
	}
	
	printf("%d ",b);
	dfs(b);
	order.pop_back();
	reverse(order.begin(), order.end());
	path.erase(path.begin());
	REP(i, 0, (int)order.size()) {
		printf("%d ", order[i]);
	}
	REP(i, 0, (int)path.size()) {
		order.clear();
		dfs(path[i]);
		order.pop_back();
		reverse(order.begin(), order.end());
		printf("%d ", path[i]);
		REP(j, 0, (int)order.size()) {
			printf("%d ", order[j]);
		}
	}
	

	

}