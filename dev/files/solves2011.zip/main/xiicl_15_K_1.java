import java.io.*;
import java.util.*;

public class Solution implements Runnable {

	int n;
	int[][] m;

	void solve() throws IOException {
		n = nextInt();
		int k = 2 * n + 1;
		m = new int[k][k];
		for (int i = 0; i < k; i++) {
			for (int j = 0; j < k; j++) {
				m[i][j] = 1;
			}
		}
		ArrayList<Integer> path = new ArrayList<Integer>();
		while (true) {
			int a = nextInt();
			if (eof)
				break;
			path.add(a);
		}
		ArrayList<Integer> stack = new ArrayList<Integer>();
		for (int i = 0; i < path.size() - 1; i++) {
			int u = path.get(i);
			int v = path.get(i + 1);
			m[u][v]--;
			if (u != v)
				m[v][u]--;
		}
		for (int i : path) {
			stack.add(i);
		}
		// for (int i = 0; i < k; i++) {
		// System.err.println(Arrays.toString(m[i]));
		// }
		ArrayList<Integer> ans = new ArrayList<Integer>();
		while (!stack.isEmpty()) {
			int u = stack.get(stack.size() - 1);
			int v = -1;
			for (int i = 0; i < k; i++) {
				if (m[u][i] > 0) {
					v = i;
					break;
				}
			}
			if (v == -1) {
				ans.add(u);
				stack.remove(stack.size() - 1);
			} else {
				stack.add(v);
				m[u][v]--;
				if (v != u)
					m[v][u]--;
			}
		}
		// for (int i = 0; i < k; i++) {
		// System.err.println(Arrays.toString(m[i]));
		// }
		Collections.reverse(ans);
		for (int i : ans) {
			out.print(i + " ");
		}
		out.println();

	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			out = new PrintWriter("output.txt");
			st = new StringTokenizer("");
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
