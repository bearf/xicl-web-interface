#include <fstream>
#include <string>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");

typedef unsigned long long int uint64;
typedef long long int int64;

int main() 
{
	int64 a,b,x,y,z;
	cin>>a>>b>>x>>y>>z;
	uint64 A=a*(b-1)*(x*(x+1)/2)+a*x;
	uint64 B=(y*(y-1)/2)*a*(b-1)+a*y+(b-1)*y;
	uint64 C=(z*(z-1)/2)*a*(b-1)+a*z+(b-1)*z;
	int64 diff=a*(x-z)+(b-1)*y+1;
	uint64 D,E;
	if(diff>0)
	{
		D=(a*y-b)*a*x;
		E=diff*((b-1)*z+1);
	}
	else
	{
		D=(a*y-b)*((int64)(a*x)-diff);
		E=((b-1)*x+1)*(-diff);
	}
	cout<<A+B+C+D+E;
}