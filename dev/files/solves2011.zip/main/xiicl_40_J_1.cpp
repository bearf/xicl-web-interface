#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <utility>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <cstring>

using namespace std;

long long b[300000][6];
int s[300000][2];

long long dfs (int x) {
  long long res = 0;
  if (s[x][1]>0) {
    b[s[x][0]][0] = b[x][0]+1;
    res += dfs (s[x][0]);
    b[x][3] = b[s[x][0]][3]+1;
  }
  if (s[x][1]>0) {
    b[s[x][1]][2] = b[x][2]+1;
    res += dfs (s[x][1]);
    b[x][5] = b[s[x][1]][5]+1;
  }
  if (s[x][0]>0 && s[x][1] == 0) {
    b[s[x][0]][1] = b[x][1]+1;
    res += dfs (s[x][0]);
    b[x][4] = b[s[x][0]][4] + 1;
  }
  if (b[x][0] > 0 && b[x][5] > 0) res++;
  if (b[x][3] > 0 && b[x][5] > 0) res++;
  if (b[x][2] > 0 && b[x][3] > 0) res++;
  res += b[x][1] * (b[x][3] + b[x][5]);
  if (b[x][0] > 0) res += b[x][4];
  if (b[x][2] > 0) res += b[x][4];
  
  return res;
}

int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
  int n;
  scanf ("%d", &n);
  memset (s, 0, sizeof (s));
  for (int i=0; i<n; i++) {
    int k;
    scanf ("%d", &k);
    for (int j=0; j<k; j++) {
      scanf ("%d", &(s[i][j]));
      s[i][j]--;
    }
  }
  memset (b,0,sizeof (b));
  cout << dfs (0);
  return 0;
}