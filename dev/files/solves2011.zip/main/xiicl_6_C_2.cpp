#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>

//using namespace std;
using std::vector;
using std::string;

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a, b) memset(a, b, sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int,int> pii;

#define DBG2 0

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	va_end(args);
	
	fflush(stdout);
#endif
#endif
}

ll sum(ll a0, ll d, ll n)
{
	return (a0 + a0 + d * (n - 1)) * n / 2;
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	ll a, b, x, y, z;
	scanf("%lld%lld%lld%lld%lld", &a, &b, &x, &y, &z);

	ll d1, d2, d3;
	d1 = d2 = d3 = a * (b - 1);

	ll s01, s02, s03;
	s01 = (a - 1) * (b - 1);
	s02 = 0;
	s03 = 0;

	ll w1, h1, w2, h2, w3, h3;

	w1 = 1 + (b - 1) * x;
	h1 = a * x;

	w2 = a * y - (a - 1);
	h2 = 1 + (b - 1) * y;

	w3 = 1 + (b - 1) * z;
	h3 = a * z;

	ll H = std::max(h1 + h2, h3);

	dbg("H = %lld\n", H);

	ll dh1 = H - h2 - h1;
	ll dh2 = H - h2;
	ll dh3 = H - h3;

	dbg("dh1 = %lld, dh2 = %lld, dh3 = %lld\n", dh1, dh2, dh3);

	ll s1 = sum(s01, d1, x) + dh1 * w1;
	ll s2 = sum(s02, d2, y) + dh2 * w2;
	ll s3 = sum(s03, d3, z) + dh3 * w3;

	dbg("s1 = %lld s2 = %lld s3 = %lld\n", s1, s2, s3);

	ll s0 = (a + b - 1) * (x + y + z);

	printf("%lld\n", s0 + s1 + s2 + s3);

	return 0;
}