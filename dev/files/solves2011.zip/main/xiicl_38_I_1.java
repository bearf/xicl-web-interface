import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;

public class Solution implements Runnable {
	
	private long rec(int num, int cur) {
		if (num == 0) {
			return 1;
		}
		else if (num < 0 || cur < 0) {
			return 0;
		}
		else {
			int ans = 0;
			ans += rec(num - (1<<cur), cur-1);
			ans += rec(num - (1<<cur) - (1<<cur), cur-1);
			ans += rec(num, cur-1);
			return ans;
		}
	}

	public void run() {
		long num = nextLong();
		char[] c = Long.toBinaryString(num).toCharArray();
		int sz = c.length;
		
		
		//for (int i = 1; i < 50; ++i) {
		//	out.println(rec(i, 10));
		//}
		//out.println(rec(50, 10));
		
		long[][] dp = new long[sz+1][2];
		dp[sz][0] = 1;
		for (int i = sz-1; i >= 0; --i) {
			for (int k = 0; k < 2; ++k) {
				if (c[i] == '1') {
					if (k == 0) {
						dp[i][k] += dp[i+1][0] + dp[i+1][1];
					}
					else {
						dp[i][k] += dp[i+1][1];
					}
				}
				else {
					if (k == 0) {
						dp[i][k] += dp[i+1][0];
					}
					else {
						dp[i][k] += dp[i+1][1] + dp[i+1][0];
					}
				}
			}
		}
		out.println(dp[0][0]);
		out.flush();
	}
	
	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}
	
	private void loadLine() {
		try{
			stk = new StringTokenizer(br.readLine());
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String nextLine() {
		try {
			return br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private int nextInt() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	private long nextLong() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Long.parseLong(stk.nextToken());
	}

}
