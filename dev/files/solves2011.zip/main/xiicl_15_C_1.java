import java.io.*;
import java.util.*;

public class Solution implements Runnable {

	void solve() throws IOException {
		long a = nextLong();
		long b = nextLong();
		long x = nextLong();
		long y = nextLong();
		long z = nextLong();
		long s1 = ((x - 1) * a + ((x - 2) * (x - 1) / 2 * a)) * (b - 1);
		long d = x * a + 1;
		y++;
		long s2 = (d * y + (y * (y - 1) / 2) * (b - 1)) * a - d
				- (d + (y - 1) * (b - 1));
		long e = d + (y - 1) * (b - 1) - (a - 1);
		long s3 = (b - 1) * (e * z + (z * (z - 1) / 2) * (-a));
		long f = e - (z - 1) * a - 1;
		long ans = s1 + s2 + s3;
		if (f < 0) {
			f = -f;
			ans += (x + a * (y - 1) + z - (b - 1) + 1) * f;
		}
		out.println(ans);
	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			out = new PrintWriter("output.txt");
			st = new StringTokenizer("");
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
