#include <iostream>
#include <stdio.h>
#include <string>
#include <string.h>
#include<set>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>

using namespace std;
typedef long long li;
typedef pair<int,int> pi;


void solve();
int main(){
#ifdef _DEBUG
	freopen("in.txt","r",stdin);
#else
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	solve();
	return 0;
}
int b[50000];
void solve(){
	bool a[300][300];
	int n;
	bool ne=0;
	cin>>n;
	for(int i=0; i<=2*n; i++)
		for(int j=0; j<=2*n; j++)
			a[i][j]=0;
	vector<int> v;
	int z;
	while(cin>>z){
		v.push_back(z);
	}
	n=2*n+1;
	int m=v.size();
	int qwe[500];
	int nol=0;
	for(int i=0; i<n; i++)
		qwe[i]=0;
	for(int i=0; i<m-1; i++)
		a[v[i]][v[i+1]]=a[v[i+1]][v[i]]=1, qwe[v[i]]++, qwe[v[i+1]]++;
	int q=v[m-1];
	for(int i=0; i<m; i++)
		b[i]=v[i];
	int b1=m;
	for(int i=0; i<n; i++)
		if(a[i]==0)
			nol++;
	int kol=0;
	for(int i=0; ne==0;)
	{
		for(int j=0; j<n; j++)
		{
			if(qwe[j]==0)
			{
				a[q][j]=a[j][q]=1;
				b[b1]=j;
				qwe[j]++;
				qwe[q]++;
				nol--;
				b1++;
				q=j;
				if(nol==0)
					ne=1;
				break;
			}
			if(j==n-1)
				ne=1;
		}
	}
	ne=0;
	while(ne==0)
	{
		for(int j=0; j<n; j++)
		{
			if(a[q][j]==0)
			{
				a[q][j]=a[j][q]=1;
				b[b1]=j;
				qwe[j]++;
				qwe[q]++;
				b1++;
				q=j;
				break;
			}
			if(j==n-1)
				ne=1;
		}
	}
	for(int i=0; i<n; i++)
		if(qwe[i]==n+1)
			kol++;
	ne=0;
	int was=0;
	int nado=n*(n-1)/2+n+1;
	if(kol!=n)
	{
		for(int i=0; i<b1; i++)
		{
			cout<<b[i]<<' ';
			was++;
			if(was==nado)
				return;
			if(qwe[b[i]]<n+1)
			{
				q=b[i];
				while(ne==0)
				{
					for(int j=0; j<n; j++)
					{
						if(a[q][j]==0)
						{
							a[q][j]=a[j][q]=1;
							b[b1]=j;
							qwe[j]++;
							qwe[q]++;
							b1++;
							q=j;
							printf("%d ",j);
							was++;
							if(was==nado)
								return;
							break;
						}
						if(j==n-1)
							ne=1;
					}
				}
			}
			ne=0;
		}
		return ;
	}
	for(int i=0; i<b1; i++)
		cout<<b[i]<<' ';
}