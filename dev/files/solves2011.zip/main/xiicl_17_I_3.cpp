#include <algorithm>
#include <iostream>
#include <string>
#include <cctype>
#include <set>
#include <vector>
#include <queue>

#define vv vector
#define mp make_pair
#define px first
#define py second
#define in cin
#define out cout

using namespace std;

typedef unsigned long long ll;

bool get_bit(ll mask, int k) {
	return (mask | (1LL << k)) == mask;
}

int main() {
	ios_base::sync_with_stdio(false);
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	ll n;
	while (in >> n) {
		ll ans = 1;

		vv<vv<ll> > dp(64, vv<ll> (64, 0));
		dp[0][1] = get_bit(n, 0) ? 0 : 1;
		for(int i = 0; i < 64; ++i)dp[i][0] = 1;
		for(int i = 1; i < 64; ++i)
		{
			for(int j = 1; j < 64; ++j)
			{
				if(get_bit(n, i))
				{
					for(int k = j; k <= i; ++k)
						dp[i][j] += dp[i - 1][k];
				}
				else
				{
					if(j > 1)dp[i][j] = dp[i - 1][j - 1];
					else dp[i][j] = get_bit(n, i - 1) ? 1 : 0;
				}
			}
		}

		for (int i = 1; i < 64; i++) {
			if (get_bit(n, i)) {
				for(int j = 1; j < 64; ++j)
					ans += dp[i - 1][j] * (ll) j;
			}
		}

		out << ans << endl;
	}

	return 0;
}