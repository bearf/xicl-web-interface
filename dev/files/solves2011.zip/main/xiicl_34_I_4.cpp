#include <iostream>
#include <string>
#include <algorithm>
#include <set>
#include <vector>
#include <cmath>
using namespace std;
__int64 f(__int64 n)
{
	while (n & 1)
		n >>= 1;
	if (n == 0)
		return 1;
	else
		return f(n+1) + f(n-1);
}
int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	__int64 n;
	cin >> n;
	cout << f(n);
	return 0;
}