#include <stdio.h>
#include <string.h>

int n;
long long a[131072];
long long b[131072];
long long c[64];

int main()
{
	freopen( "input.txt", "r", stdin );
	freopen( "output.txt", "w", stdout );
	int i,j,n,q;
	scanf("%d",&n);
	for (i=0;i<n;++i)
		scanf("%lld",&a[i]);
	memcpy(b,a,sizeof a);
	if (!a[0])
	{
		for (i=0;!a[i];++i)
			;
		--a[i];
		++a[0];
	}
	j=0;
	for (i=0;i<n;++i)
		if (a[i]>1)
			a[i+1]+=a[i]>>1;
		else
		{
			if (j<=i)
				j=i+1;
			for (;j<n && !a[j];++j);
			if (j==n)
				break;
			--a[j];
			++a[i+1];
		}
	q=i;
	if (q>=n-1)
	{
		printf("%d %d",n,n);
		return 0;
	}
	long long t=0;
	for (int l=n-q;l>=0;--l)
	{
		b[l+q-1]+=b[l+q];
		t=0;
		memcpy(c,b+l,sizeof c);
		if (!c[0])
		{
			for (i=0;i<q && !c[i];++i);
			if (i==q)
				continue;
			--c[i];
			++c[0];
		}
		j=0;
		for (i=0;i<n;++i)
			if (c[i]>1)
				c[i+1]+=c[i]>>1;
			else
			{
				if (j<=i)
					j=i+1;
				for (;j<q && !c[j];++j);
				if (j==q)
					break;
				--c[j];
				++c[i+1];
			}
		if (!c[q])
			continue;
		printf("%d %d",q+1,l+q+1);
		return 0;
	}
	return 0;
}