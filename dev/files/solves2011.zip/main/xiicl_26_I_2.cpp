#include <stdio.h>

int count = 0;
long a[54];

void dfs(int k, int p) {
	if (k==-1) {
		count++;
		for (int i = p; i > 0; i--) {
			if (a[i]) {
				a[i-1]+=2;
				a[i]--;
				if (a[i-1]>2) {
					dfs(i-1,i);
				} else {
					dfs(-1,i);
				}
				a[i]++;
				a[i-1]-=2;
			}
		}
	} else {
		if (k == 0) return;
		long q = a[k] - 2;
		a[k-1] += (2*q);
		a[k]-=q;
		if (a[k] > 2) {
			dfs(k,k);
		} else 
		if (a[k-1] > 2) {
			dfs(k-1,k);
		} else {
			dfs(-1,k);
		}
		a[k] += q;
		a[k-1] -= (2*q);
	}
}

int main() {
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long n;
	scanf("%lld",&n);
	int i;
	long long mask=n;
	for(i=0;mask;i++){
		a[i]=mask & 1;
		mask>>=1;
	}
	dfs(-1,50);
	printf("%d",count);
	return 0;
}
