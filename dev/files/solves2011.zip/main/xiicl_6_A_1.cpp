#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>

//using namespace std;
using std::vector;
using std::string;

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a, b) memset(a, b, sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int,int> pii;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	va_end(args);
	
	fflush(stdout);
#endif
#endif
}

const int dx[] = {-1, 0, 0, 1};
const int dy[] = {0, -1, 1, 0};
const int N = 600;


int n, m;
bool isCase(int x, int y)
{
	return (0 <= x && x < n) && (0 <= y && y < m);
}

int a[N][N];
int d[N][N];
int par[N][N];

void bfs(int x, int y, int dd, int pp)
{
	if (!isCase(x, y))
		return ;
	if (d[x][y] != -1)
		return ;
	d[x][y] = dd;
	par[x][y] = pp;
	for (int i = 0; i < 4; ++i)
	{
		int x1 = x + dx[i];
		int y1 = y + dy[i];
		if (isCase(x1, y1) && a[x1][y1] == a[x][y])
			bfs(x + 2 * dx[i], y + 2 * dy[i], dd + 1, i);
	}
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	scanf("%d%d", &n, &m);
	int x0, y0;
	for (int i = 0; i < n; ++i)
		for (int j = 0; j < m; ++j)
		{
			scanf("%d", &a[i][j]);

			if (a[i][j] == 0)
			{
				x0 = i;
				y0 = j;
			}
		}

	fill(d, 0xFF);
	int xf, yf;
	scanf("%d%d", &xf, &yf);
	--xf, --yf;
	bfs(xf, yf, 0, -1);

	if (d[x0][y0] == -1)
	{
		printf("0\n");
		return 0;
	}

	printf("%d\n", d[x0][y0]);
	while (x0 != xf || y0 != yf)
	{
		int i = par[x0][y0];
		x0 -= 2 * dx[i];
		y0 -= 2 * dy[i];
		printf("%d ", a[x0][y0]);
	}

	return 0;
}