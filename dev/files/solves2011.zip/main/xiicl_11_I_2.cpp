#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

#define fi first
#define se second
#define re return
#define pb push_back
#define mp make_pair
#define sz(x) (int)((x).size ())
#define all(x) (x).begin (), (x).end ()
#define rep(i,n) for (int i = 0; i < n; i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define fill(x,y) memset(x, y, sizeof (x))
#define PI 3.1415926535897932384626433832795 
#define y0 y2341234
#define y1 y2513452

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

ll n;
int m;
int was[100][4];
int a[100];
ll res[100][4];

ll go (int i, int j) {
	if (i == -1) re int (j == 0);
	if (was[i][j]) re res[i][j];
	was[i][j] = 1;
	res[i][j] = 0;
	if (j + a[i] < 3) res[i][j] += go (i - 1, 0);
	if (j + a[i] > 0) res[i][j] += go (i - 1, 2);
	re res[i][j];
}

int main () {
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);
	cin >> n;

	while (n) { a[m++] = n & 1; n /= 2; }

	cout << go (m - 1, 0) << endl;

	re 0;
}