#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:200000000")
#define _SECURE_SCL 0
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace std;


typedef long long int64;

const int INF = (int) 1E9;
const int64 INF64 = (int64) 1E18;
const double EPS = 1E-9;
const double PI = acos((double)0) * 2;

#define forn(i,n)  for (int i=0; i<int(n); ++i)
#define ford(i,n)  for (int i=int(n)-1; i>=0; --i)
#define fore(i,l,n)  for (int i=int(l); i<int(n); ++i)
#define all(a)  a.begin(), a.end()
#define fs  first
#define sc  second
#define pb  push_back
#define mp  make_pair


int64 a, b, x, y, z;

bool read() {
	return !! (cin >> a >> b >> x >> y >> z);
}


void solve() {
	int64 v1 = a*x + 1 + (b-1)*y;
	int64 v2 = z*a;
	int64 hl = max (v2-v1, 0ll);
	int64 hm = hl + z * a;
	int64 hr = max (v1-v2, 0ll);

	int64 sl = (b-1) * ((x-1) * hl + a*((x-1)*x/2));
	int64 sr = (b-1) * ((hr+1) * z + a * (z*(z-1)/2)) + z*a + hr;
	int64 sm = a*hm*y + a*(b-1)*(y*(y+1)/2) + y*(b-1);
	cout << sl+sr+sm << endl;
}


int main() {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	if (read())
		solve();

}
