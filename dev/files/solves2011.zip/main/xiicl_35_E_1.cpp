#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<climits>
#include<vector>
#include<map>
#include<set>
#include<algorithm>
#include<queue>

using namespace std;

#define ws dfgjkhdg
#define y1 sdjghdjg
#define pb push_back
#define mp make_pair
#define fs first
#define sc second

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pi;
typedef pair<int,pi> pii;
char a[550][550];
char b[550][550];
int w[50][550][550];
vector<pii> e[50][550][550];

int dx[5] = {0, 0, 1, -1, 0};
int dy[5] = {1, -1, 0, 0, 0};

int n, l, m, tt, x, y, x1, y1, x2, y2, nt;


bool fr(int x, int y) {
	return (x>=0 && x<n && y>=0 && y<n && a[x][y]=='X');
}

bool wat(int x, int y) {
	return (x>=0 && x<n && y>=0 && y<n && a[x][y]=='.');
}

bool fr2(int x, int y) {
	return (x>=0 && x<n && y>=0 && y<n && b[x][y]=='X');
}

bool wat2(int x, int y) {
	return (x>=0 && x<n && y>=0 && y<n && b[x][y]=='.');
}



void freez() {
	for (int i=0;i<n;i++) {
		for (int j=0;j<n;j++) {
			b[i][j] = a[i][j];
			if (a[i][j]=='.') {
				for (int k=0; k<4; k++)
					if (fr(i+dx[k],j+dy[k])) b[i][j] = 'X';
			}
		}
	}
}

void unfreez() {
	bool ok = false;
	for (int i=0;i<n;i++) {
		for (int j=0;j<n;j++) {
			b[i][j] = a[i][j];
			if (a[i][j]=='.') ok = true;
			if (a[i][j]=='X') {
				for (int k=0; k<4; k++)
					if (wat(i+dx[k],j+dy[k])) b[i][j] = '.';
			}
		}
	}
	if (!ok) {
		b[0][0] = '.';
		b[0][n-1] = '.';
		b[n-1][0] = '.';
		b[n-1][n-1] = '.';
	}
}

void cc() {
	for (int i=0;i<n;i++)
		for (int j=0;j<n;j++)
			a[i][j] = b[i][j];
}

queue<pii> q;


int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf("%d\n", &n);
	for (int i=0;i<n;i++) {
		for (int j=0;j<n;j++) {
			scanf("%c", &a[i][j]);
			if (a[i][j]=='K') {
				x2 = i; y2= j;
				a[i][j]='X';
			}
			if (a[i][j]=='D') {
				x1 = i; y1= j;
				a[i][j]='X';
			}
		}
		scanf("\n");
	}
	scanf("%d", &l);
	scanf("%d", &m);

	int cur = m;
	int cf = 0;
	tt = -1;

	while (cf<l) {
		nt = cur - 1;
		if (nt==0) nt = l;
		if (cur<l/2) {
			unfreez();
		} else {
			freez();
		}
		for (int i=0;i<n;i++)
			for (int j=0;j<n;j++) 
				if (a[i][j]=='X') {
					for (int k=0;k<5;k++) {
						if (fr2(i+dx[k], j+dy[k])) e[cur][i][j].pb(mp(nt,mp(i+dx[k], j+dy[k])));
					}                                                 
				}
		/*
		for (int i=0;i<n;i++) {
			for (int j=0;j<n;j++) cerr << b[i][j];
			cerr << endl;
		}
		cerr<<endl;
		*/		
		cc();
		if (b[x2][y2] == '.') tt = cf;
		cur = nt;
		cf++;
	}

	memset(w, -1, sizeof(w));
	w[m][x1][y1] = 0;
	q.push(mp(m, mp(x1,y1)));
	pii p, pp;
	int xx, yy;
	int t;

	while (!q.empty()) {
		p = q.front();
		q.pop();
		t = p.fs;
		x = p.sc.fs;
		y = p.sc.sc;
		//cerr << t << " " << x << " " << y << endl;
		if (x==x2 && y==y2) {
			if (tt!=-1 && w[t][x][y]>tt) cout << "-1" << endl; else cout << w[t][x][y] << endl;
			return 0;
		}
		for (int i=0;i<(int)e[t][x][y].size();i++) {
			pp = e[t][x][y][i];
			nt = pp.fs;
			xx = pp.sc.fs;
			yy = pp.sc.sc;
			if (w[nt][xx][yy]==-1) {
				w[nt][xx][yy] = w[t][x][y]+1;
				q.push(pp);
			}
		}
	}
	cout << -1 << endl;
	return 0;
}
