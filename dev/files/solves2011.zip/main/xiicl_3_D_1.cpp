#include <stdio.h>
#include <string.h>
#include <set>

using namespace std;
char s[100001];
#define REP(i, a, b) for(int i = (a); i < (b); ++i)
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int n;
	scanf("%d\n", &n);
	gets(s);
	bool ok = true;
	set<char> q;
	char str[] = {'a', 'e', 'i', 'o', 'u', 'y'};
	REP(i, 0, 6) {
		q.insert(str[i]);
		q.insert(str[i] - 'a' + 'A');
	}
	REP(i, 0, n - 1)  {
		bool a = q.find(s[i]) == q.end();
		bool b = q.find(s[i + 1]) == q.end();
	//	printf("%d %d\n", a, b);
		if (a == b) ok = false;
	}
	if (ok) printf("GOOD");
	else printf("BAD");
}