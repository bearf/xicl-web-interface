import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;

public class Solution implements Runnable {
	
	public void run() {
		long a = nextLong();
		long b = nextLong();
		long x = nextLong();
		long y = nextLong();
		long z = nextLong();
		
		BigInteger aa = BigInteger.valueOf(a);
		BigInteger bb = BigInteger.valueOf(b);
		BigInteger xx = BigInteger.valueOf(x);
		BigInteger yy = BigInteger.valueOf(y);
		BigInteger zz = BigInteger.valueOf(z);
		
		long H = a*x + (b*y-y+1);
		long W = (b*x-x+1) + a*y + (b*z-z+1)-b;
		long ans = W*H;
		ans -= (x-1)*(b-1)*H - x*(x-1)*(b-1)*a /2;
		ans -= (z+1)*z*(b-1)*a/2 - z*(b-1);
		ans -= (y+1)*y*(b-1)*a/2 - y*(b-1);
		out.println(ans);
		out.flush();
	}
	
	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}
	
	private void loadLine() {
		try{
			stk = new StringTokenizer(br.readLine());
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String nextLine() {
		try {
			return br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private int nextInt() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	private long nextLong() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Long.parseLong(stk.nextToken());
	}

}
