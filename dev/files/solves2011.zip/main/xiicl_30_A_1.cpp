#include <cstdio>
#include <cstring>
#include <cmath>
#include <set>
#include <map>
#include <algorithm>
#include <vector>
using namespace std;

const int xgo[4] = {1,0,-1,0};
const int ygo[4] = {0,-1,0,1};

int gv[505][505], ans[250005], x[250005], y[250005];
pair < int, int > pred[505][505];
bool f[505][505];
int n, m, xs, ys, xf, yf;

bool cango(int xcur, int ycur, int i){
	if (((xcur + 2 * xgo[i] < 0) || (xcur + 2 * xgo[i] > n - 1)) || ((ycur + 2 * ygo[i] < 0) || (ycur + 2 * ygo[i] > m - 1))){
		return false;
	}
	return (gv[xcur + xgo[i]][ycur + ygo[i]] == gv[xcur + 2 * xgo[i]][ycur + 2 * ygo[i]]);
}

void bfs(){
	int i;
	x[0] = xs;
	y[0] = ys;
	f[xs][ys] = true;
	int cur = 0, sh = 1;
	while (cur < sh){
		for (i = 0;i < 4;i++){
			if ((cango(x[cur], y[cur], i)) && (!f[x[cur] + 2 * xgo[i]][y[cur] + 2 * ygo[i]])){
				f[x[cur] + 2 * xgo[i]][y[cur] + 2 * ygo[i]] = true;
				x[sh] = x[cur] + 2 * xgo[i];
				y[sh] = y[cur] + 2 * ygo[i];
				pred[x[cur] + 2 * xgo[i]][y[cur] + 2 * ygo[i]] = make_pair(x[cur] + 1, y[cur] + 1);
				sh++;
			}
		}
		cur++;
	}
}

int main(){
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	int i, j, xcur, ycur;
	scanf("%d%d",&n,&m);
	for (i = 0;i < n;i++){
		for (j = 0;j < m;j++){
			scanf("%d",&gv[i][j]);
			if (gv[i][j] == 0){
				xs = i;
				ys = j;
			}
		}
	}
	scanf("%d%d",&xf,&yf);
	xf--;yf--;
	bfs();
	if (!f[xf][yf]){
		printf("0");
		return 0;
	}
	xcur = xf, ycur = yf;
	int kol = 0;
	int vsp;
	while ((xcur != -1) && (ycur != -1)){
		ans[kol] = gv[xcur][ycur];
		vsp = pred[xcur][ycur].first;
		ycur = pred[xcur][ycur].second - 1;
		xcur = vsp - 1;
		kol++;
	}
	kol--;
	printf("%d",kol);
	if (kol != 0){
		printf("\n%d",ans[kol - 1]);
	}
	for (i = kol - 2;i > -1;i--){
		printf(" %d",ans[i]);
	}
	return 0;
}