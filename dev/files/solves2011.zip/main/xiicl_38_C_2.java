import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;

public class Solution implements Runnable {
	
	public void run() {
		long a = nextLong();
		long b = nextLong();
		long x = nextLong();
		long y = nextLong();
		long z = nextLong();
		
		BigInteger aa = BigInteger.valueOf(a);
		BigInteger bb = BigInteger.valueOf(b);
		BigInteger xx = BigInteger.valueOf(x);
		BigInteger yy = BigInteger.valueOf(y);
		BigInteger zz = BigInteger.valueOf(z);
		
		BigInteger two = new BigInteger("2");
		
		BigInteger v1 = xx.multiply(xx.subtract(BigInteger.ONE)).multiply(bb.subtract(BigInteger.ONE));
		v1 = v1.multiply(aa).divide(two);
		v1 = v1.add(aa.multiply(xx));
		
		BigInteger v2 = aa.multiply(yy).multiply(yy.subtract(BigInteger.ONE)).multiply(bb.subtract(BigInteger.ONE));
		v2 = v2.divide(two);
		v2 = v2.add(aa.multiply(yy));
		v2 = v2.add(yy.multiply(bb.subtract(BigInteger.ONE)));
		
		BigInteger v3 = aa.multiply(zz).multiply(zz.subtract(BigInteger.ONE)).multiply(bb.subtract(BigInteger.ONE));
		v3 = v3.divide(two);
		v3 = v3.add(aa.multiply(zz));
		v3 = v3.add(zz.multiply(bb.subtract(BigInteger.ONE)));
		
		BigInteger v4 = (aa.multiply(yy)).subtract(BigInteger.ONE);
		v4 = v4.multiply(xx).multiply(aa);
		
		BigInteger v5 = aa.multiply(xx);
		v5 = v5.add(bb.multiply(yy));
		v5 = v5.subtract(yy).add(BigInteger.ONE);
		v5 = v5.subtract(aa.multiply(zz));
		v5 = v5.multiply(bb.multiply(zz).subtract(xx).add(BigInteger.ONE));
		
		/*long v1 = x*(x-1)*(b-1)*a/2 + a*x;
		long v2 = a*y + a*y*(y-1)*(b-1)/2 + y*(b-1);
		long v3 = a*z + a*z*(z-1)*(b-1)/2 + z*(b-1);
		long v4 = (a*y-1)*x*a;
		long v5 = (a*x+b*y-y+1-a*z)*(b*z-z+1);*/
		
		//out.println(v1+v2+v3+v4+v5);
		v1 = v1.add(v2.add(v3.add(v4.add(v5))));
		out.println(v1);
		out.flush();
	}
	
	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}
	
	private void loadLine() {
		try{
			stk = new StringTokenizer(br.readLine());
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String nextLine() {
		try {
			return br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private int nextInt() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	private long nextLong() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Long.parseLong(stk.nextToken());
	}

}
