//#pragma comment("/STACK:64000000")
#include <stdio.h>
#include <string.h>
#include <set>
#include <map>
#include <cassert>
#include <iostream>
using namespace std;
#define REP(i, a, b) for(int i = (a); i < (b); ++i)
typedef long long ll;

#define MAXN 500
#define MAXE 5000000
#define _(a, b) memset((a), (b), sizeof(a))

#define MAXN 300000

int head[MAXN], to[MAXN], nxt[MAXE];
int deg[MAXN];

int e =0 ;
void init() {
	_(head , 255);
	e = 0;
	_(deg, 0);
}
void ae(int u, int v) {
	to[e] = v, nxt[e] = head[u], head[u] = e ++;
	deg[u] ++ ;
}

int cnt[MAXN][3];
// 0 - left, 1 - right, 2 - down

void dfs(int cur) {
	if (deg[cur] == 0) {
		_(cnt[cur], 0);
	} else {
		if (deg[cur] == 1) {
			int son = to[head[cur]];
			dfs(son);
			cnt[cur][0] = 0;
			cnt[cur][1] = 0;
			cnt[cur][2] = cnt[son][2] + 1;
		} else {
			int son0 = to[head[cur]];
			int son1 = to[nxt[head[cur]]];
			dfs(son0);
			dfs(son1);
			cnt[cur][0] = cnt[son0][0] + 1;
			cnt[cur][1] = cnt[son1][1] + 1;
			cnt[cur][2] = 0;
		}
	}
}
ll res = 0;

void dfs0(int cur) {
	if (deg[cur] == 0) {
		return ;
	} else if (deg[cur] == 1) {
		ll l = 0;
		int tmp = cur;
		while (deg[tmp] == 1) {
			++ l;
			tmp = to[head[tmp]];
		}
		if (deg[tmp] == 0) {
		} else {
			res += l * (ll)(cnt[tmp][0] + cnt[tmp][1]);
			dfs0(tmp);
		}
	} else {
		res ++ ;
		int sun0 = to[head[cur]];
		int sun1 = to[nxt[head[cur]]];
		ll l = 0;
		if (deg[sun0] == 1) {
			l += cnt[sun0][2];
		} else if (deg[sun0] == 2) {
			l += cnt[sun0][1];
		}
		if (deg[sun1] == 1) {
			l += cnt[sun1][2];
		} else if (deg[sun1] == 2) {
			l += cnt[sun1][0];
		}
		res += l ;

		dfs0(sun0);
		dfs0(sun1);
	}
}
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	
	int n, k;
	scanf("%d", &n);
	init();
	REP(i, 0, n) {
		scanf("%d", &k);
		if (k == 1) {
			int u ;
			scanf("%d", &u);
			ae(i, u - 1);
		} else if (k == 2) {
			int u, v;
			scanf("%d%d", &u, &v);
			ae(i,v -1);
			ae(i, u-1);
			
		}
	}
	dfs(0);
	dfs0(0);
	cout << res;
	
}