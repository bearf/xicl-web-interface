import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.TreeSet;


public class Solution implements Runnable {

	private void solve() throws IOException {
		int n = nextInt();
		String name = next().toLowerCase();
		int[] mp = new int[256];
		mp['a'] = mp['e'] = mp['o'] = mp['u'] = mp['i'] = 1;
		for (int i = 0; i < name.length() - 1; ++i) {
			if (mp[name.charAt(i)] == mp[name.charAt(i + 1)]) {
				out.println("BAD");
				return;
			}
		}
		out.println("GOOD");
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		(new Thread(new Solution())).start();
	}

	private BufferedReader br;
	private StringTokenizer st;
	private PrintWriter out;

	@Override
	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			st = new StringTokenizer("");
			if (Boolean.getBoolean("SPbAU")) {
				out = new PrintWriter(System.out);
			} else {
				out = new PrintWriter("output.txt");
			}
			while (hasNext()) {
				solve();
				break;
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}		
	}
	String next() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return null;				
			}
			st = new StringTokenizer(temp);
		}
		return st.nextToken();		
	}
	boolean hasNext() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return false;				
			}
			st = new StringTokenizer(temp);
		}
		return true;		
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
	double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}
	long nextLong() throws IOException {
		return Long.parseLong(next());
	}
	

}
