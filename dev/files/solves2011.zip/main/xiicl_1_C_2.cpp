#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;

	

int main()
{
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	unsigned __int64 a,b,x,y,z,xw,yw,zw,xh,yh,zh;
	cin>>a>>b;
	cin>>x>>y>>z;
	xh=a*x;
	xw=x+b-1;
	yh=y+b-1;
	yw=a*y;
	zh=a*z;
	zw=z+b-1;
	if(xh+yh>=zh)
	{
		unsigned __int64 sl=(2*xw-(x-1))/2*a*x;
		unsigned __int64 sv=y*(a+b-1)+y*(y-1)/2*a;
		unsigned __int64 sr=z*(a+b-1)+z*(z-1)/2*a;
		sr+=(xh+yh-zh)*zw;
		unsigned __int64 ss=(yw-b)*xh;
		unsigned __int64 s=sl+sr+ss+sv;
		cout<<s<<endl;
	}
	else
	{
		unsigned __int64 sl=(2*xw-(x-1))/2*a*x;
		unsigned __int64 sv=y*(a+b-1)+y*(y-1)/2*a;
		unsigned __int64 sr=z*(a+b-1)+z*(z-1)/2*a;
		sl+=(zh-xh-yh)*xw;
		unsigned __int64 ss=(yw-b)*(zh-yh);
		unsigned __int64 s=sl+sr+ss+sv;
		cout<<s<<endl;
	}



	
	


	
	fclose(stdout);
}
