#include <fstream>
using namespace std;
void main()
{
 ifstream inp("input.txt");
 int n,m,xd,yd;
 inp>>m>>n;
 unsigned a[500][500];
 for (int i=0;i<m;i++)
  for (int j=0;j<n;j++)
   inp>>a[j][i];
 inp>>xd>>yd;
 inp.close();
 ofstream oup("output.txt");
 if ((xd%2==0)||(yd%2==0))
  oup<<0;
 else
 {
  unsigned st[62501];
  unsigned l=0;
  int x=xd-1,y=yd-1;
  while ((x!=0)||(y!=0))
  {
   st[l]=a[x][y];
   l++;
   if ((x>0)&&(a[x][y]==a[x-1][y]))
    x-=2;
   else
   if ((y>0)&&(a[x][y]==a[x][y-1]))
    y-=2;
   else
   if ((x<n-1)&&(a[x][y]==a[x+1][y]))
    x+=2;
   else
   if ((y<m-1)&&(a[x][y]==a[x][y+1]))
    y+=2;   
  }
  oup<<l<<endl;
  for (long i=l-1;i>=0;i--)
   oup<<st[i]<<' ';
 }
 oup.close();
}