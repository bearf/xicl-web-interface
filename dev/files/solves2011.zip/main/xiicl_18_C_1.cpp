#include <fstream>
#include <string>
#include <iostream>
#include <map>
#include <queue>
using namespace std;
#define long long long
ifstream in("input.txt");
ofstream out("output.txt");
long ans=0;
long a,b,x,y,z;

int main()
{
	in>>a>>b>>x>>y>>z;
	long f=(a-1)*x*(b-1)+(b-1)*a*x*(x-1)/2; 
	long s=(a-b)*a*x+a*x*a*(y-1)+(y-1)*y/2*(b-1)*a;

	long h=a*x+(b-1)*(y-1)-(a-b);
	long t=(b-1)*a*z*(z-1)/2;

	long wall =(h-(z-1)*a)*((b-1)*z+1);
	if(wall<0)
		return 1;
	long bricks =(x+y+z)*(a+b-1);
	ans = f + s + t + wall + bricks;
	out<<ans;
	return 0;
}