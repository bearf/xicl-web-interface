#include <stdio.h>
#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <set>
#include <memory.h>
#include <math.h>
#include <algorithm>
using namespace std;
typedef long double ld;
typedef long long li;
typedef vector <int> vi;
#define pb push_back
#define mp make_pair
void solve ();
int main ()
{
#ifdef _DEBUG 
	freopen ("in.txt", "r", stdin);
#else 
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);
#endif
	solve ();
	return 0;
}
#define int li
int n;
int rec (int cur)
{
	if (cur==1)
		return 1;
	if (cur==2)
		return 2;
	if ( cur%2 )
		return rec ((cur-1)/2);
	return rec ( cur/2 )+ rec ((cur-2)/2);
}
void solve ()
{
	cin>>n;
	cout<<rec (n);
}