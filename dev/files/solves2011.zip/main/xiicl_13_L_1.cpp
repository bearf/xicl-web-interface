#include <iostream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define X first
#define Y second
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1E9);
const ld PI = acos(-1.0);
const ld EPS = 1E-9;

int n;
li cnt[100500];

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> n;

    li st = -1;

    forn(i, n){
		int x;
		scanf("%d", &x);
		cnt[i] = x;
    }
    if(n > 1){
        cnt[n - 2] += cnt[n - 1];
        cnt[n - 1] = 0;
    }

    forn(i, n)
        if(cnt[i] != 0){
            st = i;
            break;
        }
    assert(st != -1);

    li cur = st;
    li c = cnt[st] - 1;
    li rg = st + 1;

    while(true){
        if(cur == n - 1)
            break;

        while(rg < n && cnt[rg] == 0)  
            ++rg;

        if(c == 0){
            if(rg == n)
                break;
            cnt[rg]--;
            c++;
        }
        
        cur++;
        c--;
        c = (c >> 1);
        c += cnt[cur];
		cnt[cur] = 0;
    }

    cout << cur - st + 1 << " " << cur + 1 << endl;

    return 0;
}
