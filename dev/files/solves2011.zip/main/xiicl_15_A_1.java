import java.io.*;
import java.util.*;

public class Solution implements Runnable {

	final int[] dx = { 0, 0, 1, -1 };
	final int[] dy = { 1, -1, 0, 0 };

	void solve() throws IOException {
		int n = nextInt(), m = nextInt();
		int[][] a = new int[n][m];
		int cnt = n * m / 2;
		int[] first = new int[cnt];
		Arrays.fill(first, -1);
		int[][] number = new int[n][m];

		int startPos = -1;
		int colorStart = -1;
		int colorFinish = -1;

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				int x = nextInt() - 1;
				number[i][j] = x;
				if (x == -1) {
					startPos = i * m + j;
					a[i][j] = -1;
					colorStart = i + j & 1;
					continue;
				}
				if (first[x] == -1) {
					first[x] = i * m + j;
				} else {
					a[i][j] = first[x];
					int i1 = first[x] / m;
					int j1 = first[x] % m;
					a[i1][j1] = i * m + j;
				}
			}
		}
		// for (int i = 0; i < n; i++) {
		// for (int j = 0; j < m; j++) {
		// System.err.print(number[i][j] + " ");
		// }
		// System.err.println();
		// }

		int x = nextInt() - 1, y = nextInt() - 1;
		// System.err.println(x + " " + y);
		colorFinish = x + y & 1;
		if (colorFinish != colorStart) {
			out.println(0);
			return;
		}
		int finishPos = x * m + y;

		Queue<Integer> q = new ArrayDeque<Integer>();
		q.add(startPos);
		int[] d = new int[n * m];
		Arrays.fill(d, -1);
		d[startPos] = 0;
		int[] p = new int[n * m];
		p[startPos] = -1;
		int[] p2 = new int[n * m];
		bfs: while (!q.isEmpty()) {
			int u = q.poll();
			int i0 = u / m, j0 = u % m;

			for (int it = 0; it < dx.length; it++) {
				int i = i0 + dx[it];
				int j = j0 + dy[it];
				if (i < 0 || i >= n || j < 0 || j >= m) {
					continue;
				}
				int match = a[i][j];
				int i1 = match / m, j1 = match % m;
				int dx = i1 - i, dy = j1 - j;
				if (i - dx != i0 || j - dy != j0)
					continue;

				if (i1 < 0 || i1 >= n || j1 < 0 || j1 >= m) {
					continue;
				}
				int other = i1 * m + j1;
				if (d[other] == -1) {
					d[other] = d[u] + 1;
					q.add(other);
					p[other] = u;
					p2[other] = number[i1][j1];
					if (other == finishPos)
						break bfs;
				}
			}
		}
		if (d[finishPos] == -1) {
			out.println(0);
			return;
		}
		out.println(d[finishPos]);
		ArrayList<Integer> ans = new ArrayList<Integer>();
		for (int i = finishPos; i != startPos; i = p[i]) {
			ans.add(p2[i] + 1);
		}
		Collections.reverse(ans);
		for (int i : ans) {
			out.print(i + " ");
		}
		out.println();
	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			out = new PrintWriter("output.txt");
			st = new StringTokenizer("");
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
