#include <stdio.h>
#include <stdlib.h>

#define PODGON 500
#define up 0
#define down 1
#define left 2
#define right 3

int x,y,n,m,x0,y0;
int a[502][502];
int st[PODGON+5];
int c=0;

void dfs(int k, int p) {
	if (k > PODGON) {
		return;
	}
	if (x == x0 && y == y0) {
		printf("%d\n",c);
		for (int i = 0; i < c; i++) {
			printf("%d ",st[i]);
		}
		exit(0);
	}
	//������� ������
	if (p != left && x >= 2) {
		if (a[x-1][y] == a[x-2][y]) {
			a[x][y] = a[x-1][y];
			a[x-2][y] = 0;
			x -= 2;
			st[c++] = a[x+1][y];
			dfs(k+1,right);
			c--;
			x += 2;
			a[x-2][y] = a[x-1][y];
			a[x][y] = 0;
		}
	}
	//������� ����
	if (p != up && y >= 2) {
		if (a[x][y-1] == a[x][y-2]) {
			a[x][y] = a[x][y-1];
			a[x][y-2] = 0;
			y -= 2;
			st[c++] = a[x][y+1];
			dfs(k+1,down);
			c--;
			y += 2;
			a[x][y-2] = a[x][y-1];
			a[x][y] = 0;
		}
	}
	//������� �����
	if (p != right && n > x+2) {
		if (a[x+1][y] == a[x+2][y]) {
			a[x][y] = a[x+1][y];
			a[x+2][y] = 0;
			x += 2;
			st[c++] = a[x-1][y];
			dfs(k+1,left);
			c--;
			x -= 2;
			a[x+2][y] = a[x+1][y];
			a[x][y] = 0;
		}
	}
	//������� �����
	if (p != down && m > y+2) {
		if (a[x][y+1] == a[x][y+2]) {
			a[x][y] = a[x][y+2];
			a[x][y+2] = 0;
			y += 2;
			st[c++] = a[x][y-1];
			dfs(k+1,up);
			c--;
			y -= 2;
			a[x][y+2] = a[x][y+1];
			a[x][y] = 0;
		}
	}
}

int main() {
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	int i,j;
	scanf("%d%d",&m,&n);
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			scanf("%d",&a[j][i]);
		}
	}
	scanf("%d%d",&y0,&x0);
	x0--; y0--;
	x = 0;
	y = 0;
	if (x%2 == 1 || y%2 == 1) {
		printf("0");
		return 0;
	}
	dfs(0,4);
	printf("0");
	return 0;
}