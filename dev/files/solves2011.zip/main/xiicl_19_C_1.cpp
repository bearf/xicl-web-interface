#include<iostream>
#include<fstream>
#include<math.h>
#define vect s+=v(ix1, jx1, ix2, jx2)
#define L long long int
//out << ix2 << " " << jx2 << endl;

using namespace std;

L v(long int ax, long int ay, long int bx, long int by)
{
       return (ax*by-bx*ay);
}

int main()
{
    ifstream in("input.txt");
    ofstream out("output.txt");
    long int a, b;
    in >> a >> b;
    long int x, y, z;
    in >> x >> y >> z;
    L s = 0;
    L ix1, jx1;
    ix1 = 0; jx1 = 0;
    L ix2, jx2;
    long int i, j;
    for (i = 0; i < x-1; i++)
    {
        ix2 = ix1;
        jx2 = jx1+a;
        vect;
        ix1 = ix2; jx1 = jx2;
        ix2 = ix1+(b-1);
        jx2 = jx1;
        vect;
        ix1 = ix2; jx1 = jx2;
    }
    ix2 = ix1;
    jx2 = jx1+a;
    vect;
    ix1 = ix2; jx1 = jx2;
    //out << "---------------\n";
    //ix1 = ix2; jx1 = jx2;
    ix2 = ix1;
    jx2 = jx1+1;
    vect;
    ix1 = ix2; jx1 = jx2;
    //out << "---------------\n";
    for (i = 0; i < y; i++)
    {
        ix2 = ix1+(a-1);
        jx2 = jx1;
        vect;
        ix1 = ix2; jx1 = jx2;
        ix2 = ix1;
        jx2 = jx1+(b-1);
        vect;
        ix1 = ix2; jx1 = jx2;
        ix2 = ix1+1;
        jx2 = jx1;
        vect;
        ix1 = ix2; jx1 = jx2;
    }
    //out << "---------------\n";
    //ix1 = ix2; jx1 = jx2;
    ix2 = ix1+1;
    jx2 = jx1;
    vect;
    ix1 = ix2; jx1 = jx2;
    //out << "---------------\n";
    for (i = 0; i < z; i++)
    {
        ix2 = ix1;
        jx2 = jx1-(a-1);
        vect;
        ix1 = ix2; jx1 = jx2;
        ix2 = ix1+(b-1);
        jx2 = jx1;
        vect;
        ix1 = ix2; jx1 = jx2;
        ix2 = ix1;
        jx2 = jx1-1;
        vect;
        ix1 = ix2; jx1 = jx2;
    }
    //out << "---------------\n";
    //ix1 = ix2; jx1 = jx2;
    if (jx1 >= 0)
    {
            ix2 = ix1;
            jx2 = 0;
            vect;
            ix1 = ix2; jx1 = jx2;
            ix2 = 0; jx2 = 0;
            vect;
    }
    else
    {
        ix2 = 0;
        jx2 = jx1;
        vect;
        ix1 = ix2; jx1 = jx2;
        ix2 = 0; jx2 = 0;
        vect;
    }
    //out << "---------------\n";
    out << abs(s/2);
    return 0;
}