//#pragma comment("/STACK:64000000")
#include <stdio.h>
#include <string.h>
#include <set>
#include <map>
#include <iostream>
using namespace std;
#define REP(i, a, b) for(int i = (a); i < (b); ++i)
typedef long long ll;

ll f[200001];
ll ifa[200001];
const ll mod = 1000000000 + 9;

ll bp(ll a, ll n) {
	ll r = 1;
	for(; n; n >>= 1, a=(a*a)%mod)if(n&1)r=(r*a)%mod;
	return r;
} 
ll inverse(ll a) {
	return bp(a, mod - 2);
}
void calc() {
	f[0] = 1;
	REP(i, 1, 200001) f[i] = f[i - 1] * i % mod;
	REP(i, 0, 200001) ifa[i] = inverse(f[i]);
}
ll cnk(ll n, ll m) {
	return (f[n] * ifa[m] % mod) * ifa[n - m] % mod;
}
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	
	calc();
	int n, m ;
	scanf("%d%d", &n, &m);
	ll total = cnk(n + m - 1, m - 1);
	REP(i, 0, m) {
		int x;
		scanf("%d", &x);
		if (x < n) {
			if (n - x - 2 + m < 0) continue;
			total = total - cnk(n - x - 2 + m, m - 1);
			total %= mod;
		}
	}
	total = (total % mod + mod) % mod;
	cout << total;
}