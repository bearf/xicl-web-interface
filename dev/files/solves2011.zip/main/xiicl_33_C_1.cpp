#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

__int64 sum(__int64 a1,__int64 an,__int64 n) {
	if ((a1+an)%2==1) {
		return ((a1+an)/2)*(n)+(n)/2;
	} else {
		return ((a1+an)/2)*(n);
	}
}

int main() {
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	
	unsigned __int64 s,s1,s2,s3,s4,s5;
	unsigned __int64 a,b,x,y,z,h1,h2;
	
	scanf("%I64d %I64d %I64d %I64d %I64d",&a,&b,&x,&y,&z);
	
	h1=a*x;
	h2=a*z-((b-1)*y+1);
	if (h1>h2) {
		s=h1*(a*(y-1)+(a-b));
		s5=((b-1)*z+1)*(h1-h2);
	}
	else {
		s=h2*(a*(y-1)+(a-b));
		s5=((b-1)*x+1)*(h2-h1);
	}
	//s=(a*x)*(a*(y-1)+(a-b));
	s2=sum((a-1)*(b-1),(a-1)*(b-1)*x+(b-1)*(x-1),x);
	s3=sum(a*(b-1),a*(b-1)*(y-1),y-1);
	s4=sum(a*(b-1),a*(b-1)*(z-1),z-1);

	s+=s2+s3+s4+s5+(x+y+z)*(a+b-1);
	printf("%I64d",s);
	return 0;
}
