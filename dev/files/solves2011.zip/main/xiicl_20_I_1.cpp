#include <stdio.h>

int a[128];

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	long long n;
	scanf("%lld",&n);
	int i;
	long long z=1;
	for (i=0;n;++i)
	{
		a[i]=n&1;
		n>>=1;
	}
	n=i;
	int j,k;
	for (i=0;a[i];++i);
	for (;i<n;)
	{
		for (j=0;!a[i];++i,++j);
		for (k=0;a[i];++i,++k);
		z*=k*j+1;
	}
	printf("%lld",z);
	return 0;
}