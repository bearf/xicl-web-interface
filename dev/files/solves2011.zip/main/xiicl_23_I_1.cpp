#include <fstream>
#include <string>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");
int main() {
	long long n;
	cin >> n;
	int a[70];
	int l = 0;
	while (n > 0) {
		a[l++] = n % 2;
		n /= 2;
	}
	long long d[70][70];
	memset(d, 0, sizeof(d));
	d[0][0] = 1;
	for (int i = 1; i <= l; i++) {
		int q = a[i - 1];
		long long sum = 0;
		for (int j = 0; j < 70; j++) {
			sum += d[i - 1][j];
			if (d[i - 1][j] != 0) {
				if (q == 0) {
					d[i][j + 1] += d[i - 1][j];
				} else {
					d[i][1] += d[i - 1][j] * j;
				}
			}
		}
		if (q == 1) d[i][0] = sum;
	}
	long long sum = 0;
	for (int i = 0; i < 70; i++) {
		sum += d[l][i];
	}
	cout << sum;
	return 0;
}