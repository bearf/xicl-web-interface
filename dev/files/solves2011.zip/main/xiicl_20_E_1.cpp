#include <iostream>
using namespace std;

const int MAXN = 510;
const int MAXT = 51;

int stx, sty, fix, fiy;
int n;
int T;
char states[MAXT][MAXN][MAXN];
char a[MAXN ][ MAXN ];
int qX[ MAXN * MAXN * MAXT ];
int qY[ MAXN * MAXN * MAXT ];
int qT[ MAXN * MAXN * MAXT ];
bool was[ MAXN ][ MAXN ][ MAXT ];



const int dx[5] = { 0, 0, 1, -1, 0 };
const int dy[5] = { 1, -1, 0, 0, 0 };

inline bool Ok( int x, int y )
{
	return x >= 0 && y >= 0 && x < n && y < n;
}

bool Angle( int x, int y ) 
{
	if( x == 0 && y == 0 ) return true;
	if( x == n-1 && y == 0 ) return true;
	if( x == 0 && y == n-1 ) return true;
	if( x == n-1 && y == n-1 ) return true;
	return false;
}

char day(int t , int x , int y ) 
{
	for( int i = 0; i < 4; i++ ) {
		int cx = x + dx[i];
		int cy = y + dy[i];

		if( Ok( cx, cy ) && states[t][cx][cy] == '.' )
			return '.';
	}

	if( ( Angle( x, y ) ) /*&& ( t != 0 )*/ ) {
		return '.';
	} else {
		return states[t][x][y];
	}
}

char night(int t , int x , int y ) 
{
	for( int i = 0; i < 4; i++ ) {
		int cx = x + dx[i];
		int cy = y + dy[i];

		if( Ok( cx, cy ) && states[t][cx][cy] == 'X' )
			return 'X';
	}

	return states[t][x][y];
}

int main()
{
	int h;
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);

	scanf("%d\n", &n);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++)  {
			scanf("%c", &a[i][j]);
		}
		scanf("\n");
	}
	scanf("%d", &T);
	scanf("%d", &h);
	int curTime = T/2 - h;
	
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++) {
			states[curTime][i][j] = a[i][j];
			if (states[curTime][i][j] == 'D') {
				states[curTime][i][j] = 'X';
				stx = i;
				sty = j;
			}
			if (states[curTime][i][j] == 'K') {
				states[curTime][i][j] = 'X';
				fix = i;
				fiy = j;
			}
		}

	int last = curTime;
	bool flag = false;
	for (int i = 1; i < T; i++) {
		int tt = (curTime + i) % T;

		for (int ii = 0; ii < n; ii++) 
			for (int jj = 0; jj < n; jj++) { 
				if (last < T/2) 
					states[tt][ii][jj] = day(last, ii, jj);
				else
					states[tt][ii][jj] = night(last, ii, jj);
			}

		if( states[tt][fix][fiy] == '.' ) {
			flag = true;
		}

		if( flag ) {
			states[tt][fix][fiy] = '.';
		}
		
		last = tt;
	}

/*	for (int i = 0; i < T; i++) { 
		for (int j = 0; j < n; j++){
			for (int z = 0; z < n; z++) 
				printf("%c", states[i][j][z]);
			printf("\n");}
	printf("\n");
	}*/

	int head,tail;
	head = tail = 0;

	qX[head] = stx;
	qY[head] = sty;
	qT[head] = curTime;
	
	for (int i = 0; i < n; i++) 
		for (int j = 0; j < n; j++)
			for (int t = 0; t < T; t++)
				was[i][j][T] = false;

	while (head <= tail) {
		
		int cx = qX[head];
		int cy = qY[head];
		int ct = qT[head];

		for (int i = 0; i < 5; i++) {
			int nx = cx + dx[i];
			int ny = cy + dy[i];
			int nt = ct + 1;

			if (Ok(nx, ny) && states[nt % T][nx][ny] == 'X' && !was[ nx ][ ny ][ nt % T ]) {
				tail++;
				qX[ tail ] = nx;
				qY[ tail ] = ny;
				qT[ tail ] = nt;
				was[ nx ][ ny ][ nt % T ] = true;

				if( nx == fix && ny == fiy ) {
					printf("%d\n", nt - curTime);
					return 0;
				}
			}
		}
		head++;
	}
	printf("-1\n");
	return 0;
}