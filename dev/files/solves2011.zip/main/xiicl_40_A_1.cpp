#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <utility>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <cstring>

using namespace std;

int x,y,n,m;
vector<int> ans; 
bool b[600][600];
int a[600][600];

void dfs (int px, int py) {
  if (b[px][py]) return;
  b[px][py] = true;
  if (px == x && py == y) {
    cout << ans.size() << endl;
    for (int i=0; i<ans.size(); i++)
      printf ("%d ", ans[i]);
    exit(0);
  }
  if (px>1)
    if (a[px-2][py] == a[px-1][py]) {
      a[px][py] = a[px-2][py];
      a[px-2][py] = 0;
      ans.push_back (a[px][py]);
      dfs (px-2,py);
      ans.pop_back();
    }
  if (py>1)
    if (a[px][py-2] == a[px][py-1]) {
      a[px][py] = a[px][py-2];
      a[px][py-2] = 0;
      ans.push_back (a[px][py]);
      dfs (px,py-2);
      ans.pop_back();
    }
  if (px<m-2)
    if (a[px+2][py] == a[px+1][py]) {
      a[px][py] = a[px+2][py];
      a[px+2][py] = 0;
      ans.push_back (a[px][py]);
      dfs (px+2,py);
      ans.pop_back();
    }
  if (py<n-2)
    if (a[px][py+2] == a[px][py+1]) {
      a[px][py] = a[px][py+2];
      a[px][py+2] = 0;
      ans.push_back (a[px][py]);
      dfs (px,py+2);
      ans.pop_back();
    }
}

int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
  int px,py;
  cin >> m >> n;
  for (int i=0; i<m; i++)
    for (int j=0; j<n; j++) {
      scanf ("%d", &(a[i][j]));
      if (a[i][j] == 0) {
        px = i;
        py = j;
      }
    }
  cin >> x >> y;
  x--; y--;
  memset (b, false, sizeof (b));
  dfs (px, py);
  cout << 0;
  return 0;
}