program d;

{$APPTYPE CONSOLE}

uses
  SysUtils;

var a:array[0..255] of Boolean;
s:string;
i,j,k,n:integer;
begin
 assign(input,'input.txt');reset(input);
 assign(output,'output.txt');rewrite(output);
 a[Ord('a')] := true;
 a[ord('A')] :=true;
 a[ord('E')] :=true;
 a[ord('e')] :=true;
 a[ord('Y')] :=true;
 a[ord('y')] :=true;
 a[ord('U')] :=true;
 a[ord('u')] :=true;
 a[ord('I')] :=true;
 a[ord('i')] :=true;
 a[ord('O')] :=true;
 a[ord('o')] :=true;
 readln(n);
 readln(s);
 s:=' '+s+' ';
for i:=2 to n-1 do
  if (a[ord(s[i])]) and ((not a[ord(s[i-1])]) or (s[i-1]=' '))
  and ((not a[ord(s[i+1])])or (s[i+1]=' '))
  then inc(k) else
  if (not a[ord(s[i])]) and ((a[ord(s[i-1])] or (s[i-1]=' '))) and ((a[ord(s[i+1])] or (s[i+1]=' '))) then  inc(k) else begin
    write('BAD');exit;
  end;
  write('GOOD');


end.