#include <stdio.h>
#include <math.h>

int K[200000];
int A[200000];
int L[200000];
int R[200000];

const int mod = 1000000009;

int main()
{
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);

	int n, m, k, N, M;
	scanf("%d %d", &N, &M);
	for(m=0; m<M; m++)
		scanf("%d", A+m);

	R[0] = A[0];
	for(int m=1; m<M; m++) {R[m] = R[m-1]+A[m]; if(R[m] > N) R[m] = N; }
	L[M-1] = R[M-1];
	for(int m=M-2; m>=0; m--){ L[m] = L[m+1] - A[m+1]; if(L[m] < 0) L[m] = 0; }

	for(n=L[0]; n<=R[0]; n++)
		K[n] = 1;

	for(m=1; m<M; m++)
	{
		for(n=R[m]; n>=L[m]; n--)
		{
			for(k=n-1; k>=n-A[m] && k>=0; k--)
				K[n] = (K[n] + K[k])%mod;
		}

	}

	printf("%d", K[N]);

	return 0;
}