#include <stdio.h>
#include <math.h>

__int64 K[200000];
__int64 A[200000];


const __int64 mod = 1000000009;

int main()
{
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);

	int n, m, k, N, M;
	scanf("%d %d", &N, &M);
	for(m=0; m<M; m++)
		scanf("%I64d", A+m);

	int L = A[0];
	for(n=0; n<=L; n++)
		K[n] = 1;


	for(m=1; m<M; m++)
	{
		L += A[m];
		for(n=L; n>=0; n--)
		{
			for(k=n-1; k>=n-A[m] && k>=0; k--)
				K[n] = (K[n] + K[k])%mod;
		}

	}

	printf("%I64d", K[N]);

	return 0;
}