import java.io.*;
import java.util.*;

public class Solution implements Runnable {

	int n, m;
	int[] a;
	final int MOD = 1000000000 + 9;

	int[] fact;
	int[] inv_fact;

	int modPow(int a, int pow) {
		int res = 1;
		while (pow > 0) {
			if ((pow & 1) == 1) {
				res = (int) ((long) res * a % MOD);
			}
			a = (int) ((long) a * a % MOD);
			pow >>= 1;
		}
		return res;
	}

	int modInverse(int a) {
		return modPow(a, MOD - 2);
	}

	void precalc() {
		fact = new int[n + m + 1];
		inv_fact = new int[n + m + 1];
		fact[0] = 1;
		inv_fact[0] = 1;
		for (int i = 1; i < fact.length; i++) {
			fact[i] = (int) ((long) fact[i - 1] * i % MOD);
			inv_fact[i] = modInverse(fact[i]);
		}
	}

	int c(int n, int k) {
		long res = fact[n];
		res = res * inv_fact[k] % MOD;
		res = res * inv_fact[n - k] % MOD;
		return (int) res;
	}

	int fat(int n, int k) {
		return c(n + k - 1, k - 1);
	}

	void solve() throws IOException {
		n = nextInt();
		m = nextInt();
		int[] a = new int[m];
		for (int i = 0; i < m; i++) {
			a[i] = nextInt();
		}
		precalc();
		long res = fat(n, m);
		for (int i = 0; i < m; i++) {
			if (a[i] + 1 > n)
				continue;
			res -= fat(n - a[i] - 1, m);
		}
		res %= MOD;
		res += MOD;
		res %= MOD;
		out.println(res);
	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			out = new PrintWriter("output.txt");
			st = new StringTokenizer("");
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
