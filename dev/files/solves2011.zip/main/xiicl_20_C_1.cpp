#include <stdio.h>

unsigned long long x,y,z,a,b,s;

int main()
{
	freopen( "input.txt", "r", stdin );
	freopen( "output.txt", "w", stdout );
	scanf("%llu%llu%llu%llu%llu",&a,&b,&x,&y,&z);
	s=(a+b-1)*z+z*(z-1)/2*a*(b-1)+
		(a+b-1)*y+y*(y-1)/2*a*(b-1)+
		a*b*x+x*(x-1)/2*a*(b-1)+
		(a*y-b)*(a*x);
	if (a*x+(b-1)*y+1>=a*z)
		s+=(a*x+(b-1)*y+1-a*z)*(z*(b-1)+1);
	else
		s+=(a*z-a*x-(b-1)*y-1)*(a*y+(b-1)*(x-1));
	printf("%llu",s);
	return 0;
}