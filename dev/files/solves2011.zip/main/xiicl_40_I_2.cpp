#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <utility>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <cstring>

using namespace std;

vector <int> ch;

long long ans[200][200];

int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
  
  long long n;
  cin >> n;
  
  while (n > 0) {
    ch.push_back(n%2);
    n /= 2;
  }
  
  int sz = ch.size();
  
  ans[0][0] = 1;
  
  for (int i = 0; i < sz; i++){
    int a = ch[sz-1-i];
    for (int k = 0; k < 100; k++){
      for (int j = 0; j <= 2; j++){
        if (k >= j){
          ans[i+1][2*(k-j)+a] += ans[i][k];
        }
      }
    }
  } 
  
  long long res = ans[sz][0]+ans[sz][1]+ans[sz][2];
  
 
  cout << res;

  return 0;
}