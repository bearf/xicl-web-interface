#include <iostream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define X first
#define Y second
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1E9);
const ld PI = acos(-1.0);
const ld EPS = 1E-9;

int n;
vector<int> g[300];
bool a[300][300];

int cnt;
int c[300];
int d[300];
int st[300], fn[300];
bool hasC[300], hasP[300];

void dfs(int v){
    forn(i, sz(g[v])){
        int u = g[v][i];

        if(c[u] == -1){
            c[u] = c[v];
            dfs(u);
        }
    }
}

vector<int> path;
vector<pt> res, ans;

void fleury(int v){
    while(sz(g[v]) > 0){
        int u = g[v].back();
        g[v].pop_back();

        if(!a[v][u])
            continue;

        a[v][u] = a[u][v] = false;

        fleury(u);
        res.push_back(pt(u, v));        
    }
}
                  

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> n;
    n *= 2;
    ++n;

    memset(a, 1, sizeof(a));
    {
        int x;
        while(scanf("%d", &x) == 1){
            if(!path.empty())
                a[path.back()][x] = a[x][path.back()] = false;

            path.push_back(x);
        }        
    }

    forn(i, n){
        d[i] = 0;
        forn(j, n){
            if(a[i][j]){
                g[i].push_back(j);
                if(i != j)
                    d[i]++;
            }
        }
    }

    cnt = 0;
    memset(c, -1, sizeof(c));

    forn(i, n){
        if(c[i] == -1){
            c[i] = cnt++;
            dfs(i);
        }
    }

    memset(st, -1, sizeof(st));
    memset(fn, -1, sizeof(fn));

    forn(i, n){
        if(d[i] & 1){
            if(st[c[i]] == -2)
                continue;

            if(st[c[i]] == -1){
                st[c[i]] = i;
            }else{
                if(fn[c[i]] == -1){
                    fn[c[i]] = i;
                }else{
                    st[c[i]] = -2;
                }
            }
        }
    }

    forn(i, cnt){
        if(st[i] == -1){
            hasC[i] = true;
            hasP[i] = true;
        }else{
            if(st[i] == -2){
                hasC[i] = hasP[i] = false;
            }else{
                hasC[i] = false;
                hasP[i] = true;
            }
        }
    }

    forn(i, sz(path)){
        int v = path[i];

        if(hasC[c[v]]){
            res.clear();
            fleury(v);    
            ans.insert(ans.end(), all(res));            

            hasC[c[v]] = hasP[c[v]] = false;
        }

        if((i == 0 && hasP[c[v]]) && (st[c[v]] == v || fn[c[v]] == v)){
            res.clear();
            fleury(v);
            ans.insert(ans.end(), all(res));
        
            hasP[c[v]] = false;
        }

        if((i == sz(path) - 1 && hasP[c[v]]) && (st[c[v]] == v || fn[c[v]] == v)){
            res.clear();
            fleury(v);
            reverse(all(res));
            ans.insert(ans.end(), all(res));
        
            hasP[c[v]] = false;            
        }

        if(i + 1 < sz(path))
            ans.push_back(pt(path[i], path[i + 1]));
    }

    forn(i, n)
        if(sz(g[i]) != 0)
            throw;

    printf("%d ", ans[0].X);
    forn(i, sz(ans))
        printf("%d ", ans[i].Y);
    puts("");

    /*forn(i, sz(ans)){
        cerr << ans[i].X << " " << ans[i].Y << " - ";
    }
    cerr << endl;*/
    
    return 0;
}
