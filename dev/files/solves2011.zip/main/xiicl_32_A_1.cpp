#include <fstream>
using namespace std;
void main()
{
 ifstream inp("input.txt");
 int n,m;
 inp>>m>>n;
 int a[500][500];
 short int pred[250][250];
 for (int i=0;i<m;i++)
  for (int j=0;j<n;j++)
  {
   inp>>a[j][i];
   pred[j/2][i/2]=0;
  }
 int xd,yd;
 inp>>xd>>yd;
 inp.close();
 xd--;
 yd--;
 ofstream oup("output.txt");
 if ((xd%2!=0)||(yd%2!=0))
  oup<<0;
 else
 {
	 struct
	 {
	  int x,y;
	 } sto[10000],stn[10000];
	 int s=1,f=0;
	 sto[0].x=0;
	 sto[0].y=0;
	 while (s>0&&(pred[xd/2][yd/2]==0))
	 {
	  f=0;
	  for (int i=0;(i<s)&&(pred[xd/2][yd/2]==0);i++)
	  {
       if ((sto[i].x>0)&&(a[sto[i].x-1][sto[i].y]==a[sto[i].x-2][sto[i].y])&&(pred[sto[i].x/2-1][sto[i].y/2]==0))
	   {
	    pred[sto[i].x/2-1][sto[i].y/2]=2;
	    stn[f].x=sto[i].x-2;
	    stn[f].y=sto[i].y;
	    f++;
	   }
       if ((sto[i].y>0)&&(a[sto[i].x][sto[i].y-1]==a[sto[i].x][sto[i].y-2])&&(pred[sto[i].x/2][sto[i].y/2-1]==0))
	   {
	    pred[sto[i].x/2][sto[i].y/2-1]=1;
	    stn[f].x=sto[i].x;
 	    stn[f].y=sto[i].y-2;
	    f++;
	   }
       if ((sto[i].x<n-1)&&(a[sto[i].x+1][sto[i].y]==a[sto[i].x+2][sto[i].y])&&(pred[sto[i].x/2+1][sto[i].y/2]==0))
	   {
	    pred[sto[i].x/2+1][sto[i].y/2]=4;
	    stn[f].x=sto[i].x+2;
	    stn[f].y=sto[i].y;
	    f++;
	   }
       if ((sto[i].y<m-1)&&(a[sto[i].x][sto[i].y+1]==a[sto[i].x][sto[i].y+2])&&(pred[sto[i].x/2][sto[i].y/2+1]==0))
	   {
	    pred[sto[i].x/2][sto[i].y/2+1]=3;
	    stn[f].x=sto[i].x;
 	    stn[f].y=sto[i].y+2;
	    f++;
	   }
	  }
	  s=f;
	  for (int i=0;i<s;i++)
	   sto[i]=stn[i];
	 }
	 if (pred[xd/2][yd/2]==0)
		 oup<<0;
	 else
	 {
		 int x=xd,y=yd;
 		 f=0;
		 while ((x!=0)||(y!=0))
		 {
		  sto[f].x=a[x][y];
		  if (pred[x/2][y/2]==3)
		   y-=2;
		  else
		  if (pred[x/2][y/2]==4)
		   x-=2;
		  else
		  if (pred[x/2][y/2]==1)
		   y+=2;
		  else
		  if (pred[x/2][y/2]==2)
		   x+=2;
	      f++;
		 }
		 oup<<f<<endl;
		 for (int i=f-1;i>=0;i--)
		  oup<<sto[i].x<<' ';
	 }
 }
 oup.close();
}