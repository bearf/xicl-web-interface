#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:200000000")
#define _SECURE_SCL 0
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace std;


typedef long long int64;

const int INF = (int) 1E9;
const int64 INF64 = (int64) 1E18;
const double EPS = 1E-9;
const double PI = acos((double)0) * 2;

#define forn(i,n)  for (int i=0; i<int(n); ++i)
#define ford(i,n)  for (int i=int(n)-1; i>=0; --i)
#define fore(i,l,n)  for (int i=int(l); i<int(n); ++i)
#define all(a)  a.begin(), a.end()
#define fs  first
#define sc  second
#define pb  push_back
#define mp  make_pair


const int MAXN = 110*1000;
const int MOD = INF+9;


int n, m, a[MAXN], cnt[MAXN];
int64 fact[MAXN];


bool read() {
	if (! (cin >> n >> m))  return false;
	forn(i,m)
		scanf ("%d", &a[i]);
	return true;
}


int64 powmod (int64 a, int64 b) {
	int64 res = 1;
	while (b)
		if (b & 1) {
			res = res * a % MOD;
			--b;
		}
		else {
			a = a * a % MOD;
			b >>= 1;
		}
	return res;
}

int64 inv (int64 a) {
	return powmod (a, MOD-2);
}

int64 get_c (int n, int k) {
	if (k < 0 || k > n)  return 0;
	return fact[n] * inv (fact[k] * fact[n-k] % MOD) % MOD;
}


void solve() {
	if (m == 1) {
		if (n <= a[0])
			puts ("1");
		else
			puts ("0");
		return;
	}

	memset (cnt, 0, sizeof cnt);
	forn(i,m)
		++cnt[a[i]+1];
	fore(i,1,n+1)
		cnt[i] += cnt[i-1];

	int64 ans = get_c (n+m-1, m-1);
	forn(i,n+1) {
		int cc = cnt[i];
		int64 cur = get_c (n-i+m-2, m-2) * cc % MOD;
		ans = (ans - cur + MOD) % MOD;
	}
	cout << ans << endl;
}


int main() {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	fact[0] = 1;
	fore(i,1,MAXN)
		fact[i] = fact[i-1] * i % MOD;

	if (read())
		solve();

}
