#include <iostream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define X first
#define Y second
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1E9);
const ld PI = acos(-1.0);
const ld EPS = 1E-9;

const int mod = 1000000000+9;
const int NMAX = 400*1000;
int modpow(int a, int b){
    int ans = 1%mod;
    while(b > 0){
        if(b&1)
            ans = (ans * 1LL * a) % mod;
        a = (a * 1LL * a) % mod;
        b >>= 1;
    }
    return ans;
}

int rev(int a){
    return modpow(a,mod-2);
}

int f[NMAX], d[NMAX], n, m;
int C(int n, int k){
    if(n < k || n < 0) return 0;
    if(n == k || k == 0) return 1 % mod;
    if(k == 1) return n % mod;

    int ans = (((f[n] * 1LL * rev(f[n-k])) % mod) * 1LL * rev(f[k])) % mod;
	
    return ans;
}
inline int D(int n, int k){
	if(k == 0 && n == 0) return 1;
	
    return C(n+k-1, k-1);
}


void init(){
    f[0] = 1%mod;
    fore(i, 1, NMAX)
        f[i] = (f[i-1] * 1LL * i) % mod;
    forn(i, 100*1100){
        d[i] = D(i, m-1);
        if(i > 0)
            d[i] = (d[i] + d[i-1]) % mod;
    }
}


int sum(int lf, int rg){
    if(lf > rg) return 0;
    int ans = (d[rg] - (lf == 0 ? 0 : d[lf-1]) + mod) % mod;
    return ans;
}

int a[NMAX];

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    cin >> n >> m;
    forn(i, m){
        scanf("%d", &a[i]);
        a[i] = min(a[i], n);
		//a[i] = n;
    }
    init();
	//cerr << "+" << endl;

    int ans = D(n, m), sub = 0;

    forn(i, m){
        sub = (sub + sum(0, n-a[i]-1)) % mod;
    }

    ans = (ans - sub + mod) % mod; 

    cout << ans << endl;
	//cerr << clock() << endl;
    return 0;
}
