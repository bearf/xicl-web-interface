import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class Solution implements Runnable {
	HashMap<Long, Long> ans = new HashMap<Long, Long>();

	long ans(long x) {
		if (!ans.containsKey(x)) {
			long beg = (x >> 1);
			long last = x & 1;
			long ret;
			if (beg == 0) {
				ret = 1;
			} else if (last == 1) {
				ret = ans(beg);
			} else {
				ret = ans(beg) + ans(beg - 1);
			}
			ans.put(x, ret);
		} 
		return ans.get(x);
	}

	private void solve() throws IOException {
		long n = nextLong();
		out.println(ans(n));
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		(new Thread(new Solution())).start();
	}

	private BufferedReader br;
	private StringTokenizer st;
	private PrintWriter out;

	@Override
	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			st = new StringTokenizer("");
			if (Boolean.getBoolean("SPbAU")) {
				out = new PrintWriter(System.out);
			} else {
				out = new PrintWriter("output.txt");
			}
			while (hasNext()) {
				solve();
				// break;
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}

	String next() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return null;
			}
			st = new StringTokenizer(temp);
		}
		return st.nextToken();
	}

	boolean hasNext() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return false;
			}
			st = new StringTokenizer(temp);
		}
		return true;
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}

	long nextLong() throws IOException {
		return Long.parseLong(next());
	}

}
