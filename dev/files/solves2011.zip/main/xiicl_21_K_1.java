import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.TreeSet;


public class Solution implements Runnable {

	ArrayList<Integer> path = new ArrayList<Integer>();
	
	
	int V;
	boolean[][] was;
	int[] cursor;
	int pos = 1;


	private ArrayList<Integer> first;
	
	void dfs(int v, int from) {
		if (pos != first.size()) {
			was[v][first.get(pos)] = true;
			was[first.get(pos)][v] = true;
			dfs(first.get(pos++), from);			
		}
		int i;
		for (; cursor[v] < was.length; ++cursor[v]) {
			i = cursor[v];
			if (!was[v][i]) {
				was[v][i] = true;
				was[i][v] = true;
				dfs(i, from);
			}
		}
		path.add(v);
	}
	
	
	
	private void solve() throws IOException {
		int n = nextInt();
		V = 2 * n + 1;
		
		was = new boolean[V][V];
		cursor = new int[V];
		first = new ArrayList<Integer>();
		
		
		for (int i = 0; hasNext(); ++i) {
			first.add(nextInt());
		}
		dfs(first.get(0), first.get(0));
		Collections.reverse(path);
		for (Integer v : path) {
			out.print(v + " ");
		}
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		(new Thread(new Solution())).start();
	}

	private BufferedReader br;
	private StringTokenizer st;
	private PrintWriter out;

	@Override
	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			st = new StringTokenizer("");
			if (Boolean.getBoolean("SPbAU")) {
				out = new PrintWriter(System.out);
			} else {
				out = new PrintWriter("output.txt");
			}
			while (hasNext()) {
				solve();
				break;
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}		
	}
	String next() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return null;				
			}
			st = new StringTokenizer(temp);
		}
		return st.nextToken();		
	}
	
	String nextLine() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return null;				
			}
			st = new StringTokenizer(temp);
		}
		return st.nextToken("_");
	}
	boolean hasNext() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return false;				
			}
			st = new StringTokenizer(temp);
		}
		return true;		
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
	double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}
	long nextLong() throws IOException {
		return Long.parseLong(next());
	}
	

}
