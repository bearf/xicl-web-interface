#include <iostream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define X first
#define Y second
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1E9);
const ld PI = acos(-1.0);
const ld EPS = 1E-9;

const int dx[] = {0, 0, 1, -1, 0};
const int dy[] = {1, -1, 0, 0, 0};

int n, m, k;
int d[50][510][510];
char a[50][510][510];
pt st, fn;

bool good(int x, int y){
    return 0 <= x && x < n && 0 <= y && y < n;
}

void rep(int idx, char x, char y){
    bool was = false;

    int prev = idx - 1;
    if(prev < 0)
        prev += k;

    forn(i, n)
        forn(j, n)
            a[idx][i][j] = a[prev][i][j];

    forn(i, n)
        forn(j, n){
            if(a[prev][i][j] == y){
                was = true;
                forn(k, 4){
                    int ni = i + dx[k], nj = j + dy[k];

                    if(good(ni, nj) && a[prev][ni][nj] == x){
                        a[idx][ni][nj] = y;
                    }
                }
            }
        }

    if(!was){
        a[idx][0][0] = a[idx][0][n - 1] = a[idx][n - 1][0] = a[idx][n - 1][n - 1] = y;
    }
}

struct state{
    int t, x, y;

	state(int ct = 0, int cx = 0, int cy = 0) : t(ct), x(cx), y(cy){}
};

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> n;

    forn(i, n){
        scanf(" %s", a[0][i]);
        forn(j, n){
            if(a[0][i][j] == 'K'){
                fn = pt(i, j);
                a[0][i][j] = 'X';
            }
            if(a[0][i][j] == 'D'){
                st = pt(i, j);
                a[0][i][j] = 'X';                
            }
        }
    }

    cin >> k >> m;
    m = (k >> 1) - m;

    forn(i, n)
        forn(j, n)
            a[m][i][j] = a[0][i][j];

    for(int i = m + 1; i != m;){
        if(0 < i && i <= (k >> 1)){
            rep(i, 'X', '.');
        }else{
            rep(i, '.', 'X');
        }

        int j = ((i == k - 1) ? (0) : (i + 1));           
        i = j;
    }
    
    memset(d, -1, sizeof(d));
    queue<state> q;
    q.push(state(m, st.X, st.Y));
	d[m][st.X][st.Y] = 0;

    int ans = INF;

    while(!q.empty()){
        state v = q.front();
        q.pop();

        if(v.x == fn.X && v.y == fn.Y){
            ans = min(ans, d[v.t][v.x][v.y]);
        }

        if(a[v.t][fn.X][fn.Y] == '.'){
            continue;
        }

        forn(i, 5){
            state u(v.t + 1, v.x + dx[i], v.y + dy[i]);
            if(u.t == k)
                u.t = 0;

            if(good(u.x, u.y) && a[u.t][u.x][u.y] == 'X' && d[u.t][u.x][u.y] == -1){
                d[u.t][u.x][u.y] = d[v.t][v.x][v.y] + 1;
                q.push(u);
            }
        }
    }

    if(ans > INF / 2)
        cout << -1 << endl;
    else
        cout << ans << endl;

    return 0;
}
