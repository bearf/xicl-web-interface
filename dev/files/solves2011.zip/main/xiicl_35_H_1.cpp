#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<climits>
#include<vector>
#include<map>
#include<set>
#include<algorithm>

using namespace std;

#define ws dfgjkhdg
#define y1 sdjghdjg
#define pb push_back
#define mp make_pair
#define fs first
#define sc second

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pi;
int kl=1;
int head[1000000];
int next[1000000];
int e[1000000];
int f[1000000];
int c[1000000];
int cs[1000000];
int d[1000000];
int pd[1000000];
int q[1000000];
int z[1000000];
int bc[1000000];
int s[1000000];
const int inf=1000000;
void add(int x,int y,int z,int w){
	kl++;
	e[kl]=y;
	s[kl]=x;
	next[kl]=head[x];
	head[x]=kl;
	cs[kl]=w;
	c[kl]=z;
	f[kl]=0;
}             
int n;
void bct(int v){
	if (v==1+n)return;
	bct(s[bc[v]]);
	f[bc[v]]++;
	f[bc[v]^1]--;
}       
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int m,k,x,y;
	scanf("%d%d%d",&n,&m,&k);
	int ansp=0;
	int ansx=0;
	for (int i=0;i<k;i++){
		scanf("%d",&x);
		pd[x]++;
		if (x==1)
			ansp++;
	}
	for (int i=2;i<=n;i++){
		add(i,n+i,1,pd[i]);
		add(n+i,i,0,-pd[i]);
	}
	for (int i=0;i<m;i++){
		scanf("%d%d",&x,&y);
		add(x+n,y,1,0);
	}
	while (1){
		for (int i=1;i<=2*n;i++){
			d[i]=-inf;
			z[i]=0;
		}
		z[1+n]=1;
		int st=0;
		int en=1;
		q[0]=1+n;
		d[1+n]=0;
		while (st<en){
			for (int bb=head[q[st]];bb;bb=next[bb]){
				if (c[bb]-f[bb]>0 && d[e[bb]]<d[q[st]]+cs[bb]){
					d[e[bb]]=d[q[st]]+cs[bb];
					bc[e[bb]]=bb;
					if (z[e[bb]]==0){
						q[en++]=e[bb];
						z[e[bb]]++;
					}
				}
			}
			z[q[st]]--;
			st++;
		}
		if (d[1]<=0){
			break;
		}
		ansp+=d[1];
		ansx++;
		bct(1);
	}
	cout<<ansp<<" "<<ansx<<endl;
	return 0;
}
