#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

#define fi first
#define se second
#define re return
#define pb push_back
#define mp make_pair
#define sz(x) (int)((x).size ())
#define all(x) (x).begin (), (x).end ()
#define rep(i,n) for (int i = 0; i < n; i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define fill(x,y) memset(x, y, sizeof (x))
#define PI 3.1415926535897932384626433832795 
#define y0 y2341234
#define y1 y2513452

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

int n;
int m;

ll col[200020];
ll sum[200020];

int check(int l, int r) {
	ll bonus = sum[r];
	if (l == r)
		re bonus > 0;
	ll need = 1;
	for (int p = r - 1; p >= l; p--) {
		if (need > 1e15)
			re 0;
		ll x = col[p];
		if (p == l)
			re x + bonus >= 2 * need;
		ll sneed = need;
		need = max(1ll, 2 * sneed - x - bonus);
		bonus = need + x + bonus - 2 * sneed;	
	}	 	
	re 0;
}

int main () {
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);

	cin >> n;
	rep(i, n) {
		int x;
		scanf("%d", &x);
		col[i] = x;
	}

	sum[n] = 0;
	repn(i, n)
		sum[i] = sum[i + 1] + col[i];

	ii bans = mp(-1, -1);

	int lc = 0, rc = n - 1;
	while (lc <= rc) {
		int c = (lc + rc) / 2;
		int lx = c, rx = n - 1, ansx = -1;
		while (lx <= rx) {
			int cx = (lx + rx) / 2;
			if (check(cx - c, cx)) {
				ansx = cx;
				lx = cx + 1;
			}
			else
				rx = cx - 1;
		}
		if (ansx == -1)
			rc = c - 1;
		else {
			bans = max(bans, mp(c, ansx));
			lc = c + 1;
		}			
	}	

	cout << bans.fi + 1 << ' ' << bans.se + 1 << endl;

	re 0;
}