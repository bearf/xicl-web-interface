#include <cstdio>
#include <cstring>
#include <cmath>
#include <set>
#include <map>
#include <algorithm>
#include <vector>
using namespace std;

set <int> g[205];
set <int> ::iterator it;
vector <int> eul[205];
int m[100000];
bool f[205], fe[205], feq[205];
int n, sh, st, fin, waysh, globcur;
bool fway;

void dfs(int cur){
	if (cur == st){
		fway = true;
		return ;
	}
	int i;
	f[cur] = true;
	for (i = 0;i < n;i++){
		if ((!f[i]) && (g[cur].find(i) == g[cur].end()) && ((i == st) || (((g[i].size() % 2 == 0) && (feq[i] == false)) || ((g[i].size() % 2 == 1) && (feq[i] == true))))){
			dfs(i);
			if (fway){
				m[sh + waysh] = cur;
				waysh++;
				return ;
			}
		}
	}
}

void euler(int k) {
	for (int i = 0; i < n; i ++) {
		if (g[k].find(i) == g[k].end()) {
			g[k].insert(i);
			g[i].insert(k);
			euler(i);
		}
	}
	eul[globcur].push_back(k);
	//printf("%d", k);
}

int main(){
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	int i, j, ch;
	scanf("%d",&n);
	n *= 2;
	n++;
	sh = 0;
	while (scanf("%d",&ch) == 1){
		m[sh] = ch;
		sh++;
	}
	for (i = 0;i < sh - 1;i++){
		g[m[i]].insert(m[i + 1]);
		g[m[i + 1]].insert(m[i]);
	}
	st = m[sh - 1];
	fin = m[0];
	waysh = 0;
	fway = false;
	dfs(fin);
	for (i = sh - 1;i < sh + waysh;i++){
		g[m[i]].insert(m[i + 1]);
		g[m[i + 1]].insert(m[i]);
		if (m[i] == m[i + 1]){
			feq[m[i]] = true;
		}
	}
	g[m[sh + waysh - 1]].insert(m[0]);
	g[m[0]].insert(m[sh + waysh - 1]);
	sh += waysh - 1;
	for (i = 0;i < sh;i++){
		if (!fe[m[i]]){
			fe[m[i]] = true;
			globcur = m[i];
			euler(m[i]);
		}
	}
	memset(fe, false, sizeof(fe));
	int vsp;
	for (i = 0;i < sh;i++){
		if (!fe[m[i]]){
			vsp = eul[m[i]].size();
			if (vsp == 1){
				for (j = 0;j < vsp;j++){
					printf("%d ",eul[m[i]][j]);
				}
			}else
			{
				for (j = 0;j < vsp;j++){
					printf("%d ",eul[m[i]][j]);
				}
			}
		}else
		{
			printf("%d ",m[i]);
		}
	}
	printf("%d",m[0]);
	return 0;
}