#include <iostream>
#include <string>
#include <algorithm>
#include <set>
using namespace std;

set<char> gl;
bool isGl(char a)
{
	return gl.find(a) != gl.end();
}

int main()
{

	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	gl.insert('e');
	gl.insert('u');
	gl.insert('i');
	gl.insert('o');
	gl.insert('a');
	gl.insert('y');
	gl.insert('E');
	gl.insert('U');
	gl.insert('I');
	gl.insert('O');
	gl.insert('A');
	gl.insert('Y');
	int n;
	string s;
	cin >> n >> s;
	for (int i = 1; i < n; ++i)
	{
		if ((isGl(s[i-1]) && isGl(s[i])) || (!isGl(s[i-1]) && !isGl(s[i])))
		{
			cout << "BAD";
			return 0;
		}
	}
	cout << "GOOD";
	return 0;
}