import java.io.*;
import java.util.*;

public class Solution implements Runnable {

	final static int INF = 10000000;

	static class Assignments {
		int n;
		int[][] a;
		boolean[] vx;
		boolean[] vy;
		int[] xy;
		int[] yx;

		int[] row, col;

		public Assignments(int[][] a) {
			this.n = a.length;
			this.a = a;
			vx = new boolean[n];
			vy = new boolean[n];
			xy = new int[n];
			yx = new int[n];
			row = new int[n];
			col = new int[n];
		}

		boolean dfs(int u) {
			if (vx[u])
				return false;
			vx[u] = true;
			for (int v = 0; v < n; v++) {
				if (a[u][v] - row[u] - col[v] == 0) {
					vy[v] = true;
					if (yx[v] == -1 || dfs(yx[v])) {
						xy[u] = v;
						yx[v] = u;
						return true;
					}
				}
			}
			return false;
		}

		long work() {
			Arrays.fill(row, Integer.MAX_VALUE);
			Arrays.fill(col, Integer.MAX_VALUE);

			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					row[i] = Math.min(row[i], a[i][j]);
				}
			}
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					col[j] = Math.min(col[j], a[i][j] - row[i]);
				}
			}

			Arrays.fill(xy, -1);
			Arrays.fill(yx, -1);
			int c = 0;
			while (c < n) {
				Arrays.fill(vx, false);
				Arrays.fill(vy, false);
				int k = 0;
				for (int i = 0; i < n; i++) {
					if (xy[i] == -1 && dfs(i))
						k++;
				}
				if (k > 0) {
					c += k;
					continue;
				}
				int d = Integer.MAX_VALUE;
				for (int i = 0; i < n; i++) {
					if (vx[i]) {
						for (int j = 0; j < n; j++) {
							if (!vy[j]) {
								d = Math.min(d, a[i][j] - row[i] - col[j]);
							}
						}
					}
				}
				for (int i = 0; i < n; i++) {
					if (vx[i]) {
						row[i] += d;
					}
					if (vy[i]) {
						col[i] -= d;
					}
				}
			}

			int res = 0;
			for (int i = 0; i < n; i++) {
				res += a[i][xy[i]];
			}
			return res;
		}

		boolean[] matched;
		long cur;
		long best;

		void go(int i) {
			if (i == n) {
				best = Math.min(best, cur);
				return;
			}
			for (int j = 0; j < n; j++) {
				if (!matched[j]) {
					matched[j] = true;
					cur += a[i][j];
					go(i + 1);
					cur -= a[i][j];
					matched[j] = false;
				}
			}
		}

		long workStupid() {
			matched = new boolean[n];
			best = Long.MAX_VALUE;
			cur = 0;
			go(0);
			return best;
		}
	}

	void stressAssignments() {
		Random rand = new Random();
		int n = 5;
		int[][] a = new int[n][n];
		int max = INF + 1000;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				a[i][j] = rand.nextInt(max) - max / 2;
			}
		}
		Assignments ok = new Assignments(a);
		long got = ok.work();
		long stupid = ok.workStupid();
		if (got != stupid) {
			for (int i = 0; i < n; i++) {
				System.err.println(Arrays.toString(a[i]));
			}
			throw new AssertionError();
		}
		System.err.println("GOOD");
	}

	int solve() throws IOException {
		// while (true) {
		// stressAssignments();
		// if (false)
		// break;
		// }
		int n = nextInt();
		int edges = nextInt();
		int art = nextInt();
		int[] artcnt = new int[n];
		int[] arts = new int[art];
		for (int i = 0; i < art; i++) {
			arts[i] = nextInt() - 1;
			artcnt[arts[i]]++;
		}
		boolean[][] e = new boolean[n][n];
		for (int i = 0; i < edges; i++) {
			int u = nextInt() - 1, v = nextInt() - 1;
			e[u][v] = true;
		}

		int out1 = 0, in1 = 0;
		for (int i = 0; i < n; i++) {
			if (e[0][i])
				out1++;
			if (e[i][0])
				in1++;
		}
		int multiply = Math.min(in1, out1);

		int m = n + multiply - 1;

		int[][] a = new int[m][m];
		for (int i = 0; i < m; i++) {
			int u = i < n ? i : 0;
			for (int j = 0; j < m; j++) {
				int v = j < n ? j : 0;
				if (e[u][v]) {
					if (v != 0) {
						a[i][j] = -1000 * artcnt[v];
					} else {
						a[i][j] = 0;
					}
				} else {
					a[i][j] = INF;
				}
			}
			a[i][i] = i < n && i > 0 ? 0 : -1;
		}
		Assignments ok = new Assignments(a);
		long res = ok.work();
		// System.err.println(res);
		res = -res;
		int ans1 = (int) (res / 1000);
		ans1 += artcnt[0];
		int ans2 = (int) (multiply - res % 1000);
		out.println(ans1 + " " + ans2);
		return ans1;
	}

	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			out = new PrintWriter("output.txt");
			st = new StringTokenizer("");
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
