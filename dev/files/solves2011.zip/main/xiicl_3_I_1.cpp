//#pragma comment("/STACK:64000000")
#include <stdio.h>
#include <string.h>
#include <set>
#include <map>
#include <iostream>
using namespace std;
#define REP(i, a, b) for(int i = (a); i < (b); ++i)
typedef long long ll;

map<ll, ll> mp;

ll rec(ll x) {
	if (x == 0LL) return 1LL;
	if (mp.count(x)) return mp[x];
	ll res = 0LL;
	if (x & 1LL) res = rec(x >> 1LL);
	else {
		res = rec(x >> 1LL) + rec((x >> 1LL) - 1LL);
	}
	//return res;
	return mp[x] = res;
}
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	
	ll n;
	cin >> n;
	cout << rec(n) ;
	
}