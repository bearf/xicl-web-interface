#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<climits>
#include<vector>
#include<map>
#include<set>
#include<algorithm>

using namespace std;

#define ws dfgjkhdg
#define y1 sdjghdjg
#define pb push_back
#define mp make_pair
#define fs first
#define sc second

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pi;

ll ans;
int p[1000000][2];
int c[1000000];
int n;
      

void bct(int v, int h, bool r, int t) {
	int tt, hh;
//	cerr << v << " " << h << endl;
	if (t==1 || t==2) {
//		cerr << v << " " << h << endl;
		ans+=h;		
	}
	if (t==0 && r) {
//		cerr << v << endl;
		ans+=1;	
	}
	if (c[v]==2) {
//		cerr << v << " !" << endl;
		ans++;
		tt = 1;
		if (tt==t || t==0 || t==-1) hh = h; else hh = 1;
		bct(p[v][0], hh, true, tt);

		tt = 2;
		if (tt==t || t==0 || t==-1) hh = h; else hh = 1;
		bct(p[v][1], hh, true, tt);
	} else if (c[v]==1) {
		if (t==0) hh = h+1; else hh = 1;
		bct(p[v][0], hh, r, 0);
	}
}

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf("%d", &n);
	for (int i=1;i<=n;i++) {
		scanf("%d", &c[i]);
		for (int j=0;j<c[i];j++)
			scanf("%d", &p[i][j]);
	}
	bct(1, 0, false, -1);
	cout << ans << endl;
	return 0;
}
