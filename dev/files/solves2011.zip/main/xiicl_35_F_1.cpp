#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<climits>
#include<vector>
#include<map>
#include<set>
#include<algorithm>

using namespace std;

#define ws dfgjkhdg
#define y1 sdjghdjg
#define pb push_back
#define mp make_pair
#define fs first
#define sc second

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pi;

struct pnt{
	ld x,y;
	pnt(){
	}
	pnt(ld _x,ld _y){
		x=_x;
		y=_y;
	}
};			
struct line{
	ld a,b,c;
	line(){
	}
	line(ld _x,ld _y,ld _z){
		a=_x;
		b=_y;
		c=_z;
	}
};			

pnt operator -(pnt a,pnt b){
	return pnt(a.x-b.x,a.y-b.y);
}
pnt operator +(pnt a,pnt b){
	return pnt(a.x+b.x,a.y+b.y);
}
pnt operator *(pnt a,ld c){
	return pnt(a.x*c,a.y*c);
}
ld sp(pnt a,pnt b){
	return a.x*b.x+a.y*b.y;
}
ld vp(pnt a,pnt b){
	return a.x*b.y-a.y*b.x;
}

ld dst(pnt a,pnt b){
	return sqrt(sp(b-a,b-a));
}
void readp(pnt& a){
	int x,y;
	scanf("%d%d",&x,&y);
	a=pnt(x,y);
}
line p2l(pnt a,pnt v){
	return line(-v.y,v.x,-(-v.y*a.x+a.y*v.x));
}
pnt intr(line a,line b){
	ld dd=a.a*b.b-a.b*b.a;
	ld dx=a.c*b.b-a.b*b.c;
	ld dy=a.a*b.c-a.c*b.a;
	return pnt(-dx/dd,-dy/dd);
}
pair<pi,int> pp[1000000];
pnt vv[1000000];				
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	pnt a,b;
	readp(a);
	readp(b);
	int L,n;
	scanf("%d%d",&L,&n);
	for (int i=0;i<n;i++){
		scanf("%d%d%d",&pp[i].fs.fs,&pp[i].fs.sc,&pp[i].sc);
	}
	pp[n]=mp(mp(-1000000,-1000000),-1000000);
	pp[n+1]=mp(mp(1000000,1000000),1000000);
	n+=2;
	sort(pp,pp+n);
	int na=0;
	int nb=0;
	for (int i=0;i<n-1;i++){                             
		if (vp(pnt(L,pp[i].sc-pp[i].fs.fs),pnt(a.x,a.y-pp[i].fs.fs))>0){
			na=i;
		}
		if (vp(pnt(L,pp[i].sc-pp[i].fs.fs),pnt(b.x,b.y-pp[i].fs.fs))>0){
			nb=i;
		}	
	}	
	bool bol=false;
    if (na>nb){
    	swap(na,nb);
    	swap(a,b);
    	bol=true;
    }
    ld ans=0;
    pnt a0=a,v1,v2,v3;
    ld dd;
    for (int i=na+1;i<=nb;i++){
   		v2=pnt(L,pp[i].sc-pp[i].fs.fs);
   		v1=pnt(0,pp[i].fs.sc-pp[i].fs.fs);
   		v3=pnt(-v2.y,v2.x);
   		dd=sqrt(sp(v3,v3));
   		v3.x/=dd;
   		v3.y/=dd;
   		dd=sp(v3,v1);
		v3.x*=dd;
		v3.y*=dd;
		vv[i]=v3;
		a=a+v3;
		ans+=dd;
    }
    ans+=dst(a,b);
    printf("%.18lf\n",(double)ans);
    pnt pd;
    vector<pnt> an;
    for (int i=nb;i>na;i--){
    	pd=intr(p2l(pnt(0,pp[i].fs.sc),pnt(L,pp[i].sc-pp[i].fs.fs)),
    			p2l(a,b-a));
    		an.pb(pd);
	    	an.pb(pd-vv[i]);
      	a=a-vv[i];
    }
    if (!bol)
    reverse(an.begin(),an.end());
    for (int i=0;i<(int)an.size();i++){
       	printf("%.18lf %.18lf\n",(double)an[i].x,(double)an[i].y);
    }
    return 0;
}
