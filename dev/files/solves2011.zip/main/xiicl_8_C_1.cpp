#include<iostream>
#include<fstream>
using namespace std;
int main(){
	ifstream in("input.txt");
	ofstream out("output.txt");
	int a;
	in>>a;
	int b;
	in>>b;
	int x,y,z;
	in>>x>>y>>z;

	int A1=0;
	int h=0;
	for(int i=0; i<x; i++) {
		A1+=a*(i+1)*(b-1);
		h=a*(i+1);
	}

	int A2=0;
	for(int i=0; i<y-1; i++) {
		A2+=((h+1)+(i+1)*(b-1))*a;
	}
	A2+=(h+1)*(a-2)+1;
	A2+=(h+1+y*(b-1));

	int A3=0;
	for(int i=0; i<z-1; i++) {
		A3+=(a*(i+1)+1)*(b-1);
	}
	A3+=b-1;
	A3+=a*z;

	int A4=0;
	int r1,r2;
	r1=x*a;
	r2=z*a-((y-1)*(b-1)+b);
	if(r1>r2) {
		A4=((z-1)*(b-1)+b)*(r1-r2);
	} else if(r2>r1) {
		A4=(y*a+(x-2)*(b-1)+b+b-2)*(r2-r1);
	}
	out<<A1+A2+A3+A4;
	return 0;
}

