#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>

//using namespace std;
using std::vector;
using std::string;

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a, b) memset(a, b, sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int,int> pii;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	va_end(args);
	
	fflush(stdout);
#endif
#endif
}

int d[500];
int p[500];
int f[500][500];
int c[500][500];

int s, t;
const int infty = 1e6;
int n;

void adv(int x)
{
	if (x == s)
		return;
	f[p[x]][x] --;
	f[x][p[x]] ++;
	adv(p[x]);
	dbg("%d ", x);
}

void ford()
{
	bool fl = true;
	while(fl)
	{
		fl = false;
		for(int i = 0; i < n; i++)
			for(int j = 0; j < n; j++)
				if (f[i][j] && d[j] < d[i] + c[i][j])
				{
					p[j] = i;
					d[j] = d[i] + c[i][j];
					fl = true;
				}
	}
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int n,m, k;
	scanf("%d%d%d", &n, &m, &k);
	::n = 2 * n;
	for(int i = 0; i < k; i++)
	{
		int a;
		scanf("%d", &a);
		a--;
		c[2*a][2*a+1] ++;
		c[2*a+1][2*a] --;
	}
	for(int i = 1; i < n; i++)
		f[2*i][2*i+1] = 1;
	for(int i = 0; i < m; i++)
	{
		int a,b;
		scanf("%d%d", &a, &b);
		a--; b--;
		f[2*a+1][2*b] = 1;
	}
	s = 1; t = 0;
	int ans = c[0][1], anspos = 0;
	for(int f = 1; ; f++)
	{   		
		for(int i = 0; i < 2*n; i++)
			d[i] = -infty;
		d[s] = 0;
		ford();
		if (d[t] == -infty)
			break;
		adv(t);
		dbg("\n");
		for(int i = 0; i < 2*n; i++)
		{
			for(int j = 0; j < 2*n; j++)
				dbg("(%d, %d), ", c[i][j], ::f[i][j]);
			dbg("\n");
		}

		if (d[t] > 0)
		{
			ans += d[t];
			anspos = f;
		}			
	}
	printf("%d %d\n", ans, anspos);


	


	return 0;
}