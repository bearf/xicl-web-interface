import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.StringTokenizer;


public class Solution implements Runnable {
	BufferedReader in;
	PrintWriter out;
	StringTokenizer st;
	String nextToken() throws Exception {
		if (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(in.readLine());
		return st.nextToken();
	}
	int nextInt() throws Exception {
		return Integer.parseInt(nextToken());
	}
	
	public static void main(String[] args) {
		(new Thread(new Solution())).start();
	}
	
	long modd = 1000000009;
	
	void solve() throws Exception {
		int n = nextInt();
		int m = nextInt();
		int[] a = new int[m];
		for (int i = 0; i < m; i++) {
			a[i] = nextInt();
		}
		if (m == 1) {
			if (a[0] < n) out.println(0); else out.println(1);
			return;
		}
		long cc = 1;
		for (int i = 2; i <= n + m - 1; i++) {
			cc = (cc * i) % modd;
		}
		long dd = 1;
		for (int i = 2; i <= m - 1; i++) {
			dd = (dd * i) % modd;
		}
		cc = (cc * BigInteger.valueOf(dd).modInverse(BigInteger.valueOf(modd)).longValue()) % modd;
		dd = 1;
		for (int i = 2; i <= n; i++) {
			dd = (dd * i) % modd;
		}
		cc = (cc * BigInteger.valueOf(dd).modInverse(BigInteger.valueOf(modd)).longValue()) % modd;
		long[] d = new long[n + 1];
		d[0] = 1;
		for (int i = 1; i <= n; i++) {
			d[i] = (d[i - 1] * (i + m - 2)) % modd;
			d[i] = (d[i] * BigInteger.valueOf(i).modInverse(BigInteger.valueOf(modd)).longValue()) % modd;
		}
		long[] sum = new long[n + 1];
		sum[0] = 1;
		for (int i = 1; i <= n; i++) sum[i] = (sum[i - 1] + d[i]) % modd;
		for (int i = 0; i < m; i++) {
			if (n - a[i] - 1 >= 0) cc = (cc + modd - sum[n - a[i] - 1]) % modd;
		}
		out.println(cc);
	}

	public void run() {
		try {
			in = new BufferedReader(new FileReader(new File("input.txt")));
			out = new PrintWriter(new File("output.txt"));
			st = null;
			solve();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		} finally {
			out.flush();
		}
	}
	
}
