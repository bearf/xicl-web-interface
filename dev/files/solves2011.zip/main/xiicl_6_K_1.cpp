#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>

//using namespace std;
using std::vector;
using std::string;

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a, b) memset(a, b, sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int,int> pii;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	va_end(args);
	
	fflush(stdout);
#endif
#endif
}

const int N = 210;
const int NN = 2 * N * N;

int k, n;
int a[NN];
int m[N][N];
vector <int> ans;

void del(int u, int v)
{
	m[u][v] = m[v][u] = 0;
}

void dfs(int s, int curK)
{
	dbg("dfs(%d, %d)\n", s, curK);
	if (curK < k)
	{
		int newS = a[curK];
		del(s, newS);
		dfs(newS, curK + 1);
	}

	for (int i = 0; i < n; ++i)
		if (m[s][i] == 1)
		{
			del(s, i);
			dfs(i, curK + 1);
		}

	ans.push_back(s);
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	scanf("%d", &n);
	n = 2 * n + 1;
	k = 0;
	while (scanf("%d", &a[k]) == 1)
	{
		++k;
	}

	for (int i = 0; i < n; ++i)
		for (int j = 0; j < n; ++j)
			m[i][j] = 1;

	dfs(a[0], 1);

	for (int i = int(ans.size()) - 1; i >= 0; --i)
		printf("%d ", ans[i]);

	return 0;
}