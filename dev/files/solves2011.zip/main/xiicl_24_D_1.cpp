#include <stdio.h>
#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <set>
#include <memory.h>
#include <math.h>
#include <algorithm>
using namespace std;
void solve ();
int main ()
{
#ifdef _DEBUG 
	freopen ("in.txt", "r", stdin);
#else 
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);
#endif
	solve ();
	return 0;
}
bool glas ( char c )
{
	if ( c=='A' || c=='E' || c=='I' || c=='O' || c=='U' || c=='Y' || c=='a' || c=='e' || c=='i' || c=='o' || c=='u' || c=='y' )
		return 1;
	return 0;
}
void solve ()
{
	string s;
	int n;
	cin>>n;
	cin>>s;
	bool gl=false;
	if ( glas ( s[0] ) )
		gl=true;
	for (int i=1; i<n; i++)
	{
		if ( glas(s[i]) && gl)
		{
			cout<<"BAD";
			return;
		}
		if ( !glas(s[i]) && !gl )
		{
			cout<<"BAD";
			return;
		}
		gl=!gl;
	}
	cout<<"GOOD";
}