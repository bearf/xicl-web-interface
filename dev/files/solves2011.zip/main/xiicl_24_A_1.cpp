#include <stdio.h>
#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <set>
#include <memory.h>
#include <queue>
#include <math.h>
#include <algorithm>
using namespace std;
typedef long double ld;
typedef long long li;
typedef pair <int, int> pi;
typedef vector <int> vi;
#define pb push_back
#define mp make_pair
void solve ();
int main ()
{
#ifdef _DEBUG 
	freopen ("in.txt", "r", stdin);
#else 
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);
#endif
	solve ();
	return 0;
}
//#define int li
int n, m;
int x, y;
int matrix[550][550];
int dist[550][550];
int pred[550][550];
pi predok[550][550];
bool be[550][550];
queue < pair <int, int> > q;
pi right ( pi cur )
{
	if ( cur.second<n-2 && matrix[cur.first][cur.second+1]==matrix[cur.first][cur.second+2])
		return mp ( cur.first, cur.second+2 );
	return mp (-1, -1);
}
pi left ( pi cur )
{
	if ( cur.second>1 && matrix[cur.first][cur.second-1]==matrix[cur.first][cur.second-2])
		return mp ( cur.first, cur.second-2 );
	return mp (-1, -1);
}
pi up ( pi cur )
{
	if ( cur.first>1 && matrix[cur.first-1][cur.second]==matrix[cur.first-2][cur.second])
		return mp ( cur.first-2, cur.second );
	return mp (-1, -1);
}
pi down ( pi cur )
{
	if ( cur.first<m-2 && matrix[cur.first+1][cur.second]==matrix[cur.first+2][cur.second])
		return mp ( cur.first+2, cur.second );
	return mp (-1, -1);
}
void writedist ( pi cur, int d ) { dist[cur.first][cur.second]=d; }
void writepred (pi cur, pi next) 
{ 
	predok[next.first][next.second]=cur;
	if ( cur.first==next.first )
		pred[next.first][next.second]=matrix[cur.first][min ( cur.second, next.second )+1];
	else 
		pred[next.first][next.second]=matrix[min (cur.first, next.first)+1][cur.second];
}
bool was (pi cur)  { return be[cur.first][cur.second];}
void solve ()
{
	cin>>m>>n;
	for ( int i=0; i<m; i++ )
		for (int j=0; j<n; j++)
			cin>>matrix[i][j];
	cin>>x>>y;
	x--; y--;
	q.push( mp (0,0) );
	be[0][0]=true;
	dist[0][0]=0;
	while ( !q.empty() )
	{
		pi next;
		pi cur=q.front();
		q.pop();
		int curdist=dist[cur.first][cur.second];
		if ( left(cur)!=mp (-1, -1) )
		{
			next=left(cur);
			if ( !was(next) )
			{
				writepred ( cur, next );
				writedist ( next, curdist+1 );
				be[next.first][next.second]=true;
				q.push(next);
			}
		}
		if ( right(cur)!=mp (-1, -1) )
		{
			next=right(cur);
			if ( !was(next) )
			{
				writepred ( cur, next );
				writedist ( next, curdist+1 );
				be[next.first][next.second]=true;
				q.push(next);
			}
		}
		if ( up(cur)!=mp (-1, -1) )
		{
			next=up(cur);
			if ( !was(next) )
			{
				writepred ( cur, next );
				writedist ( next, curdist+1 );
				be[next.first][next.second]=true;
				q.push(next);
			}
		}
		if ( down(cur)!=mp (-1, -1) )
		{
			next=down(cur);
			if ( !was(next) )
			{
				writepred ( cur, next );
				writedist ( next, curdist+1 );
				be[next.first][next.second]=true;
				q.push(next);
			}
		}
	}
	if ( !was(mp (x, y)) )
	{
		cout<<"0";
		return;
	}
	int answer=dist[x][y];
	cout<<answer<<endl;
	pi cur=mp (x, y);
	vector <int> ans;
	while ( cur!=mp (0, 0) )
	{
		ans.pb (pred[cur.first][cur.second]);
		cur=predok[cur.first][cur.second];
	}
	for (int i=ans.size()-1; i>=0; i--)
		cout<<ans[i]<<" ";
}