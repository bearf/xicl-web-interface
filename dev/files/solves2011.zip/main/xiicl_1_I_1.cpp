#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;
//vector<__int64> m;
//vector<__int64> s;
//map<pair<int,int>,int> h;
//__int64 f(__int64 n, int u)
//{
//	if(n==0) return 1;
//	if(u==-1) return 0;
//	
//	__int64 res=0;
//	//if(m[u]>n) return f(n,u-1);
//	//if(m[u]*2<=n) res=f(n-2*m[u],u-1);
//	//return (res+f(n-m[u],u-1));
//	__int64 a=0;
//	if(h[make_pair(n,u-1)]==0)
//		a=f(n,u-1);
//	else
//		a=h[make_pair(n,u-1)];
//	__int64 b=0;
//	if(n-2*m[u]>=0)
//	{
//		if(h[make_pair(n-2*m[u],u-1)]==0)
//			b=f(n-2*m[u],u-1);
//		else
//			b=h[make_pair(n,u-1)];
//	}
//	__int64 c=0;
//	if(n-m[u]>=0)
//	{
//		if(h[make_pair(n-m[u],u-1)]==0)
//			c=f(n-m[u],u-1);
//		else
//			c=h[make_pair(n-m[u],u-1)];
//	}
//	h[make_pair(n,u)]=a+b+c;
//	return a+b+c;
//}

__int64 fi(__int64 n)
{
	if(n==0) return 1;
	if(n&1)
		return fi(n>>1);
	else
	{
		return (fi(n>>1)+fi((n-2)>>1));
	}
}

int main()
{
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	__int64 n;
	n=1;
	//m.push_back(1);
	//s.push_back(2);
	//for(int i=1;i<=52;i++)
	//{
	//	m.push_back(m[i-1]*2);
	//	s.push_back(s[i-1]+m[i]*2);
	//}
	
	scanf("%I64d",&n);
	cout<<fi(n)<<endl;

	
	fclose(stdout);
}
