#include <fstream>
#include <string>
#include <iostream>
#include <map>
using namespace std;
#define long long long
ifstream in("input.txt");
ofstream out("output.txt");
const int MAX = 60;
long n;
/*long p[MAX];
map<pair<long, int> , int> h;
map<pair<long, int> , int>::iterator it;
long solve(long a, int m)
{
	if(a==1 && m>=0)
		return 1;
	if(a==0)
		return 1;
	if(m<0)
		return 0;
	if((it=h.find(make_pair(a,m))) != h.end())
		return it->second;
	long ans=0;
	ans = solve(a, m-1);
	if(a-p[m]>=0)
		ans += solve(a-p[m], m-1);
	if(m<MAX && a-p[m+1]>=0)
		ans += solve(a-p[m+1], m-1);
	h[make_pair(a,m)] = ans;
	return ans;
}*/

int bit[MAX];
long cnt[MAX][2];
int main()
{
	in>>n;
	if(n % 2 == 0){
		cnt[0][0] = 1;
		cnt[0][1] = 1;
	}else{
		cnt[0][0] = 1;
		cnt[0][1] = 0;
	}
	n /= 2;
	int i = 1;
	for(; n > 0; ++i, n /= 2){
		bit[i] = n % 2;
		for(int val = 0; val < 3; ++val)
			for(int carry = 0; carry < 2; ++carry)
				if((carry + val) % 2 == bit[i])
					cnt[i][(carry + val) / 2] += cnt[i - 1][carry];
		//cout << bit[i] << " " << cnt[i][0] << " " << cnt[i][1] << endl;
	}
	out << cnt[i - 1][0];
	return 0;
}