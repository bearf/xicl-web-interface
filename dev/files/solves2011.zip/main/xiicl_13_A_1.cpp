#include <iostream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define X first
#define Y second
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1E9);
const ld PI = acos(-1.0);
const ld EPS = 1E-9;

const int dx[] = {0, 0, 1, -1};
const int dy[] = {1, -1, 0, 0};

int n, m;
bool used[510][510];
int a[510][510];

inline bool good(pt a){
    return 0 <= a.X && a.X < n && 0 <= a.Y && a.Y < m;
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> n >> m;

    forn(i, n)
        forn(j, m)
            scanf("%d", &a[i][j]);

    pt st;
    cin >> st.X >> st.Y;
    st.X--; st.Y--;

    vector<int> ans;

    while(true){
        if(used[st.X][st.Y]){
            puts("0");
            return 0;
        }
        used[st.X][st.Y] = true;

        if(a[st.X][st.Y] == 0){
            break;
        }

        ans.push_back(a[st.X][st.Y]);
        bool br = true;

        forn(i, 4){
            pt nx(st.X + dx[i], st.Y + dy[i]);

            if(good(nx) && a[nx.X][nx.Y] == a[st.X][st.Y]){
                br = false;
                st.X = nx.X + dx[i];
                st.Y = nx.Y + dy[i];
                break;
            }
        }
        
        if(br || !good(st)){
            puts("0");
            return 0;
        }
    }

    cout << sz(ans) << endl;

    ford(i, sz(ans)){
        printf("%d ", ans[i]);
        //if(i + 1 == sz(ans))
        //    puts("");
        //else
        //    printf(" ");
    }
    puts("");


    return 0;
}
