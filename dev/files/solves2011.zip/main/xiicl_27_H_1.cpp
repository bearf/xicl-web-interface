#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:200000000")
#define _SECURE_SCL 0
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace std;


typedef long long int64;

const int INF = (int) 1E9;
const int64 INF64 = (int64) 1E18;
const double EPS = 1E-9;
const double PI = acos((double)0) * 2;

#define forn(i,n)  for (int i=0; i<int(n); ++i)
#define ford(i,n)  for (int i=int(n)-1; i>=0; --i)
#define fore(i,l,n)  for (int i=int(l); i<int(n); ++i)
#define all(a)  a.begin(), a.end()
#define fs  first
#define sc  second
#define pb  push_back
#define mp  make_pair


const int MAXN = 500;


int nn, m, k, cnt[MAXN], cnt0;


bool read() {
	if (! (cin >> nn >> m >> k))  return false;
	cnt0 = 0;
	memset (cnt, 0, sizeof cnt);
	forn(i,k) {
		int cc;
		cin >> cc;
		--cc;
		if (cc == 0)
			++cnt0;
		else
			++cnt[cc];
	}
	return true;
}


#define in(a)  ((a)*2)
#define out(a)  ((a)*2+1)


struct edge {
	int a, b, cap, cost, flow;
};


int n, flow, cost, d[MAXN], par[MAXN], s, t;
bool in_q[MAXN];
vector<int> g[MAXN];
vector<edge> e;

void add_edge (int a, int b, int cap, int cost) {
	edge e1 = { a, b, cap, cost, 0 };
	g[a].pb ((int)e.size());
	e.pb (e1);
	edge e2 = { b, a, 0, -cost, 0 };
	g[b].pb ((int)e.size());
	e.pb (e2);
}


bool enlarge() {
	forn(i,n) {
		d[i] = INF;
		in_q[i] = false;
	}
	d[s] = 0;
	deque<int> q;
	q.pb (s);

	while (!q.empty()) {
		int v = q.front();
		q.pop_front();
		in_q[v] = false;

		forn(i,g[v].size()) {
			int id = g[v][i],
				to = e[id].b;
			if (e[id].flow < e[id].cap)
				if (d[v] + e[id].cost < d[to]) {
					if (d[to] == INF)
						q.pb (to);
					else if (!in_q[to])
						q.push_front (to);
					d[to] = d[v] + e[id].cost;
					in_q[to] = true;
					par[to] = id;
				}
		}
	}

	if (d[t] >= 0)  return false;

	for (int v=t; v!=s; ) {
		int id = par[v];
		++e[id].flow,  --e[id^1].flow;
		cost += e[id].cost;
		v = e[id].a;
	}
	return true;
}


void solve() {
	forn(i,MAXN)
		g[i].clear();
	e.clear();

	s = out(0),  t = in(0);
	forn(i,m) {
		int a, b;
		scanf ("%d%d", &a, &b);
		--a, --b;
		add_edge (out(a), in(b), 1, 0);
	}
	fore(i,1,nn)
		add_edge (in(i), out(i), 1, -cnt[i]);

	n = 2 * nn;
	flow = cost = 0;
	while (enlarge())
		++flow;
	int ans = cnt0 - cost;
	cout << ans << ' ' << flow << endl;
}


int main() {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	if (read())
		solve();

}
