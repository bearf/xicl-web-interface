#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <queue>

//using namespace std;
using std::vector;
using std::string;

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a, b) memset(a, b, sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int,int> pii;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	va_end(args);
	
	fflush(stdout);
#endif
#endif
}

int count[200000];
int c[200000];

pii solve(int start)
{
	int ans = 1, lvl = start;
	int next = 2;
	for(; lvl < n; lvl++)
	{
		if (count[lvl] > 1)
		{
			count[lvl+1] += count[lvl] / 2;
			ans++;
			continue;
		}
		while(count[lvl] < 2)
		{
			next = std::max(next, lvl + 1);
			while(next <= n && count[next] == 0)
				next++;	
			if (count[next] == 0)
				break;
			count[next] --;
		}
		if (count[lvl] < 2)
			return pii(ans, lvl);
		count[lvl+1] ++;
		ans++;
	}
	return pii(ans, lvl);
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int n;
	scanf("%d", &n);
	for(int i = 1; i <= n; i++)
	{
		scanf("%d", &count[i]);
	}
	int l = 1, r = 1;
	while(count[r] == 0)
		r++;
	r--;               
   	pii best = solve(r);
	while(l < r)
	{
		int m = (l + r) / 2;
		pii cur = solve(m);
		if (cur.first < best.first)
			l = m + 1;
		else
		{
			r = m;
			best = cur;
		}
	}
	

	printf("%d %d\n", best.first, best.second);

	return 0;
}