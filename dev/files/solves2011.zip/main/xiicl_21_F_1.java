import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.TreeSet;


public class Solution implements Runnable {

	public class Point {
		double x;
		double y;
		
		Point norm() {
			return new Point(x / len(), y / len());
		}
		
		Point(double x, double y) {
			this.x = x;
			this.y = y;			
		}	
		Point sub(Point v) {
			return new Point(this.x - v.x, this.y - v.y);
		}
		Point add(Point v) {
			return new Point(this.x + v.x, this.y + v.y);
		}
		Point mult(double a) {
			return new Point(x * a, y * a);
		}
		double len() {
			return Math.sqrt(x * x + y * y);
		}
		Point negate() {
			return new Point(-x, -y);
		}
		Point perp() {
			return new Point(-y, x);
		}
		double scal(Point v) {
			return x * v.x + y * v.y;
		}
		double vec(Point v) {
			return x * v.y - y * v.x;
		}
		public String toString() {
			return x + " " + y;
		}
		
	}
	
	double L;
	
	class River {
		double y0, y1, yr;
		Point L1;
		Point L2;
		Point perp;
		
		double ro(Point a) {
			return Math.abs(perp.scal(a.sub(L1)) / perp.len());
		}
		
		double d(Point a) {
			Point P = L2.sub(L1).perp();
			return P.scal(a.sub(L1)) / P.len();
		}
		void init() {
			L1 = new Point(0, y0);
			L2 = new Point(L, yr);
		}
		
		boolean check(Point a, Point b) {			
			return L2.sub(L1).vec(a.sub(L1)) * L2.sub(L1).vec(b.sub(L1)) < 0;  			
		}
		Point per(Point a, Point b) {
			if (perp == null) {
				Point res = L2.sub(L1).perp();			
				res = res.mult(L * (y1 - y0) / res.len() / res.len());
				if (b.sub(a).scal(res) < 0) { 
					perp =  res.negate();
				}
				perp = res;
			}
			return perp;
		}
	}
	
	Point nextPoint() throws IOException {
		double x = nextDouble(); 
		double y = nextDouble();
		return new Point(x, y);		
	}
	
		
	
	private void solve() throws IOException {
		Point a = nextPoint();
		Point b = nextPoint();
		
		boolean rev = false;
		
		L = nextDouble();
		int n = nextInt();
		ArrayList<River> lst = new ArrayList<River>();
		for (int i = 0; i < n; ++i) {
			River r = new River();			
			r.y0 = nextDouble();
			r.y1 = nextDouble();
			r.yr = nextDouble();
			r.init();
			if (r.check(a, b)) {
				lst.add(r);
				if (r.d(a) > 0) {
					Point tmp = a;
					a = b;
					b = tmp;
					rev = true;
				}
			}
		}
		Point sum = new Point(0, 0);
		double len = 0;
		for (int i = 0; i < lst.size(); ++i) {
			Point vi = lst.get(i).per(a, b);
			sum = sum.add(vi);
			len += vi.len();
		}			
		b = b.sub(sum);
//		System.err.println(b);
		len += b.sub(a).len();		
		out.println(len);
//		System.err.println(a);
		ArrayList<Point> ansp = new ArrayList<Point>();
		while (lst.size() != 0) {
			int pos = findBest(lst, a);
			River rp = lst.get(pos);			
			
			Point v = b.sub(a);
			
			a = a.add(v.mult(rp.ro(a) / Math.abs(v.norm().scal(rp.perp.norm())) / v.len()));
//			System.err.println(a);
			ansp.add(a);
//			out.println(a);
			a = a.add(rp.perp);
//			System.err.println(a);
			b = b.add(rp.perp);
			ansp.add(a);
//			out.println(a);
			
			lst.remove(pos);
		}
		if (rev) {
			Collections.reverse(ansp);
		}
		for (Point i : ansp) {
			out.println(i);
		}
			
//		out.println();
	}

	
	private int findBest(ArrayList<River> lst, Point a) {
		int ans = 0;
		double min = lst.get(ans).ro(a);
		for (int i = 0; i < lst.size(); ++i) {
			double t = lst.get(i).ro(a);
			if (t < min) {
				min = t;
				ans = i;
			}
		}
		return ans;
	}



	/**
	 * @param args
	 */
	public static void main(String[] args) {
		(new Thread(new Solution())).start();
	}

	private BufferedReader br;
	private StringTokenizer st;
	private PrintWriter out;

	@Override
	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			st = new StringTokenizer("");
			if (Boolean.getBoolean("SPbAU")) {
				out = new PrintWriter(System.out);
			} else {
				out = new PrintWriter("output.txt");
			}
			while (hasNext()) {
				solve();
				//break;
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}		
	}
	String next() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return null;				
			}
			st = new StringTokenizer(temp);
		}
		return st.nextToken();		
	}
	boolean hasNext() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return false;				
			}
			st = new StringTokenizer(temp);
		}
		return true;		
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
	public double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}
	long nextLong() throws IOException {
		return Long.parseLong(next());
	}
	

}
