#pragma comment (linker,"/STACK:16000000")
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int ochx[125000];
int ochy[125000];
int ochn[125000];
int ochp[125000];
int resh[125000];
int a[501][501];
int n,m,xf,yf,xs,ys;
int f,l;

void check(int xxx,int yyy,int xp,int yp) {
	if (xxx<0 || xxx>=n || yyy<0 || yyy>=m) return;
	if (a[yyy][xxx]==a[yyy-yp][xxx-xp]) {
		l++;
		ochx[l]=xxx;
		ochy[l]=yyy;
		ochn[l]=a[yyy][xxx];
		ochp[l]=f;
	}
}

int main() {
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	
	
	
	
	scanf("%d %d",&m,&n);
	
	for (int i=0;i<m;i++) {
		for (int j=0;j<n;j++) {
			scanf("%d",&a[i][j]);
			if (a[i][j]==0) {xs=j;ys=i;}
		}
	}
	scanf("%d %d",&yf,&xf);
	xf--;yf--;
	ochx[0]=xs;ochy[0]=ys;ochn[0]=0;ochp[0]=-1;
	f=0;l=0;
	int xx,yy;
	while (f<=l) {
		xx=ochx[f];
		yy=ochy[f];
		if (xx==xf && yy==yf) break;
		check(xx-2,yy,-1,0);
		check(xx+2,yy,1,0);
		check(xx,yy-2,0,-1);
		check(xx,yy+2,0,1);
		f++;	
	}
	if (f>l) {puts("0");return 0;}
	int c=0;
	while (ochp[f]!=-1) {
		resh[c]=ochn[f];
		f=ochp[f];
		c++;
	}
	printf("%d \n",c);
	for (int i=c-1;i>=0;i--)
		printf("%d ",resh[i]);

	return 0;
}
