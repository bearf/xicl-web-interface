#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;
struct str
{
	int x, y;
	vector <int> k;
};
struct ans
{
	int count;
};
ans res[500][500];
str s[50000];
int a[500][500];
int n, m, size, x1, y1;
int step[4][2] = {{0, -2}, {0, 2}, {2, 0}, {-2, 0}};


int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> n >> m;
	size = 1;
	for(int i = 0; i < n; i++)
		for(int j = 0; j < m; j++)
		{
			res[i][j].count = -1;
			cin >> a[i][j];
			if(a[i][j] == 0)
			{
				res[i][j].count = 0;
				s[0].x = i;
				s[0].y = j;
			}
		}
	cin >> x1 >> y1;
	x1--;
	y1--;
	for(int u = 0; u != size; u++)
	{
		for(int k = 0; k < 4; k++)
		{
			if(s[u].x + step[k][0] >= 0  &&  s[u].x + step[k][0] < n  &&
				s[u].y + step[k][1] >= 0  &&  s[u].y + step[k][1] < m  &&
				a[s[u].x + (step[k][0] / 2)][s[u].y + (step[k][1] / 2)] == a[s[u].x + step[k][0]][s[u].y + step[k][1]]  &&
				res[s[u].x + step[k][0]][s[u].y + step[k][1]].count == -1)
			{
				int tempx = s[u].x + step[k][0], tempy = s[u].y + step[k][1];
				res[tempx][tempy] = res[s[u].x][s[u].y];
				res[tempx][tempy].count++;
				size++;
				s[size - 1] = s[u];
				s[size - 1].x = tempx;
				s[size - 1].y = tempy;
				s[size - 1].k.push_back(a[tempx][tempy]);
				if(s[size - 1].x == x1  &&  s[size - 1].y == y1)
				{
					size--;
					goto found;
				}
				if(size == 50000)	size = 0;
			}
		}
	}
	cout << 0;
	return 0;
found:
	cout << s[size].k.size() << endl;
	for(int i = 0; i < s[size].k.size(); i++)	cout << s[size].k[i] << ' ';
}