#include <algorithm>
#include <iostream>
#include <string>
#include <cctype>
#include <set>
#include <vector>
#include <queue>

#define vv vector
#define mp make_pair
#define px first
#define py second
#define in cin
#define out cout

using namespace std;

typedef long long ll;

bool get_bit(ll mask, int k) {
	return (mask | (1LL << k)) == mask;
}

int main() {
	ios_base::sync_with_stdio(false);
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	ll n;
	in >> n;
	ll ans = 1;
	
	for (int i = 1; i < 64; i++) {
		if (get_bit(n, i)) {
			int c = 1;
			for (int j = i - 1; j >= 0; j--) {
				if (get_bit(n, j)) {
					break;
				}
				c++;
			}
			ans *= c;
		}
	}

	out << ans + 1;

	return 0;
}