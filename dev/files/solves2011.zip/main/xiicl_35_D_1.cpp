#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<climits>
#include<vector>
#include<map>
#include<set>
#include<algorithm>

using namespace std;

#define ws dfgjkhdg
#define y1 sdjghdjg
#define pb push_back
#define mp make_pair
#define fs first
#define sc second

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pi;

char s[1000000];
char kk[13];
bool gl[1000000];             
int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int n;
	scanf("%d",&n);
	scanf("%s",s);
	int k=12;
	kk[0]='a';
	kk[1]='e';
	kk[2]='i';
	kk[3]='o';
	kk[4]='u';
	kk[5]='y';
	kk[6]='A';
	kk[7]='E';
	kk[8]='I';
	kk[9]='O';
	kk[10]='U';
	kk[11]='Y';
	


	for (int i=0;i<n;i++){
		gl[i]=false;
		for (int j=0;j<k;j++) if (s[i]==kk[j]){
			gl[i]=true;
		}
	}	
	bool ans=true;
	for (int i=0;i<n-1;i++) if ((gl[i] && gl[i+1])||(!gl[i] && !gl[i+1]))
		ans=false;
	if (ans) printf("GOOD\n");
		else printf("BAD\n");
	return 0;
}
