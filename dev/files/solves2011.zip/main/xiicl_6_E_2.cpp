#include <cstdio>
#include <cstring>
#include <string>
#include <cstdarg>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>

using namespace std;
using std::vector;
using std::string;

#define clr(a) memset(a, 0, sizeof(a))
#define fill(a, b) memset(a, b, sizeof(a))

typedef long long ll;
typedef unsigned long long ull;
typedef std::pair<int,int> pii;

#define DBG2 1

void dbg(const char * fmt, ...)
{
#ifdef DBG1
#if DBG2
	va_list args;
	va_start(args, fmt);
	vfprintf(stdout, fmt, args);
	va_end(args);
	
	fflush(stdout);
#endif
#endif
}


const int maxN = 510;
const int maxL = 100;
int M, L, cur, n;
char m[maxL][maxN][maxN];
int mark[maxL][maxN][maxN];
int kx, ky, dx, dy;
int si[] = {-1, 0, 0, 1, 0};
int sj[] = { 0,-1, 1, 0, 0};



bool isIn(int x, int y)
{
	return x >= 0 && y >= 0 && x < n && y < n;
}


void genNext(int num)
{
	int nxt = (num + 1) % (2 * L);
	char X = 'X';
	char P = '.';
	if(num < L)
	{
		swap(X, P);
	}
	bool existGenerator = false;
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			if(m[num][i][j] == X)
			{
				existGenerator = true;
				goto zzz;
			}
		}
	}
zzz:
	if(!existGenerator)
	{
		memcpy(m[nxt], m[num], sizeof(m[num]) );
		m[nxt][0    ][0    ] = X;
		m[nxt][n - 1][0    ] = X;
		m[nxt][0    ][n - 1] = X;
		m[nxt][n - 1][n - 1] = X;
		return;
	}
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			existGenerator = false;
			for(int t = 0; t <= 4; t++)
			{
				int nx = i + si[t];
				int ny = j + sj[t];
				if(!isIn(nx, ny) ) continue;
                if(m[num][nx][ny] == X)
                {
                	existGenerator = true;
                	break;
                }
			}
			m[nxt][i][j] = existGenerator ? X : P;
		}
	}	
}


struct Point{
	int x, y, z;
};


vector<Point> q;


int & getMark(Point p)
{
	return mark[p.x][p.y][p.z];	
}


void add(Point p, Point prev)
{
	int mm = getMark(prev);
	getMark(p) = mm + 1;
//	dbg("!!!");
//	dbg("%d\n", getMark(prev));
	q.push_back(p);
}

void add(Point p)
{
	getMark(p) = 1;
	q.push_back(p);
}


bool isIn(Point p)
{
	return isIn(p.y, p.z);
}


bool isIce(Point p)
{
	return m[p.x][p.y][p.z] == 'X';
}

                   
bool good(Point p)
{
	return isIn(p) && getMark(p) == 0 && isIce(p);
}


int bfs(int x1, int y1, int z1, int y2, int z2)
{
	Point p1 = {x1, y1, z1};
	add(p1);
	for(int i = 0; i < q.size(); i++)
	{
		Point p = q[i];
		for(int t = 0; t <= 4; t++)
		{
			Point np = p;
			np.x++;
			if(np.x == 2 * L)
			{
				np.x = 0;
			}
			np.y += si[t];
			np.z += sj[t];
            if(!good(np) ) continue;
            add(np, p);
            if(np.y == y2 && np.z == z2)
            {
//            	dbg("%d %d %d\n", np.x, np.y, np.z);
            	return getMark(p);
            }
		}
	}
	dbg("!!!");
	return -1;
}


int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf("%d", &n);
	for(int i = 0; i < n; i++)
	{
		scanf("%s", m[0][i]);
		for(int j = 0; j < n; j++)
		{
			if(m[0][i][j] == 'D')
			{
				dx = i;
				dy = j;
				m[0][i][j] = 'X';
			}
			if(m[0][i][j] == 'K')
			{
				kx = i;
				ky = j;
				m[0][i][j] = 'X';
			}
		}
	}
	scanf("%d%d", &L, &M);
	L /= 2;
	cur = L - M;
	memcpy(m[cur], m[0], sizeof ( m[0] ) );
	for(int i = 0; i < 2 * L; i++)
	{
		int I = (i + cur) % (2 * L);
		genNext(I);
	}
/*	for(int i = 0; i < 2 * L; i++)
	{
		for(int x = 0; x < n; x++)
		{
			dbg("%s\n", m[i][x]);
		}
		dbg("\n");
	}*/
	int timeOfDeath = 1e9;
	for(int i = cur; i < cur + 4 * L; i++)
	{
		int I = i % (2 * L);
		if(m[I][kx][ky] == '.')
		{
			timeOfDeath = i - cur;
			break;
		}
	}
	int res = bfs(cur, kx, ky, dx, dy);
/*	for(int i = 0; i < 2 * L; i++)
	{
		for(int x = 0; x < n; x++)
		{
			for(int y = 0; y < n; y++)
			{
				dbg("%d ", mark[i][x][y]);
			}
			dbg("\n");
		}
		dbg("\n\n");
	}*/
	if(res > timeOfDeath)
	{
		dbg("tod : %d\n", timeOfDeath);
		res = -1;
	}
	if(res == timeOfDeath)
	{
		throw 42;
	}
	printf("%d\n", res);
	return 0;
}