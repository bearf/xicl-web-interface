#include <iostream>
#include <map>

using namespace std;

long long n, ans;
map <long long, long long> m;

long long f(long long x) {
	long long res = 0;
	if (m.find(x) != m.end())
		return m[x];
  if (x <= 0)
    return 0;
  else
    if (x == 1)
      return 1;
    else
      if (x == 2) 
        return 2;
      else
		  if ((x & 1) == 0) {
			res = f((x >> 1)) + f((x >> 1) - 1);
		  }	
			else
				res = f((x >> 1));
  m[x] = res;	
  return res;
};


int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
  cin >> n;
  ans = f(n);
  cout << ans;
}
