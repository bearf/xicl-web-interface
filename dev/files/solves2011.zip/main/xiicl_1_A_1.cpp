#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;
int a,b;
	int n,m;
	vector<int> h;
int f(vector<vector<int>> &d,int x,int y,int count,int k)
{
	if(x==a && y==b)
	{
		printf("%d\n",count);
		return 1;
	}
	if(x-2>0)
	{
		if(d[x-2][y]==d[x-1][y] && d[x-1][y]!=k)
		{
			/*int yes=1;
			for(size_t i=0;i<k.size();i++)
				if(k[i]==d[x-1][y]) yes=0;
			if(yes)
			{*/
				d[x][y]=d[x-2][y];
				d[x-2][y]=0;
				if(f(d,x-2,y,count+1,d[x][y]))
				{
					h.push_back(d[x][y]);
					
							return 1;
			}
					d[x-2][y]=d[x][y];
					d[x][y]=0;
				
			
		}
	}
	if(x+2<=m)
	{
		if(d[x+2][y]==d[x+1][y] && d[x+1][y]!=k)
		{
			/*int yes=1;
			for(size_t i=0;i<k.size();i++)
				if(k[i]==d[x+1][y]) yes=0;
			if(yes)
			{*/
			d[x][y]=d[x+2][y];
			d[x+2][y]=0;
			if(f(d,x+2,y,count+1,d[x][y]))
			{
			
				h.push_back(d[x][y]);
				return 1;
			}
				d[x+2][y]=d[x][y];
				d[x][y]=0;
			
		}
		
		
	}


	if(y+2<=n)
	{
		if(d[x][y+2]==d[x][y+1] && d[x][y+1]!=k)
		{
				
		/*	int yes=1;
			for(size_t i=0;i<k.size();i++)
				if(k[i]==d[x][y+1]) yes=0;
			if(yes)
			{*/
			d[x][y]=d[x][y+2];
			d[x][y+2]=0;
			if(f(d,x,y+2,count+1,d[x][y]))
			{
				h.push_back(d[x][y]);
					return 1;
			}
				d[x][y+2]=d[x][y];
				d[x][y]=0;
			
		}
		
	}
	if(y-2>0)
	{
		if(d[x][y-2]==d[x][y-1] && d[x][y-1]!=k)
			{
			/*int yes=1;
			for(size_t i=0;i<k.size();i++)
				if(k[i]==d[x][y-1]) yes=0;
			if(yes)
			{*/
			d[x][y]=d[x][y-2];
			d[x][y-2]=0;
			if(f(d,x,y-2,count+1,d[x][y]))
			{
				h.push_back(d[x][y]);
						return 1;
			}
				d[x][y-2]=d[x][y];
				d[x][y]=0;
			
		}
		
		
	}
	return 0;
}
int main()
{
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);

	scanf("%d%d",&m,&n);
	vector<vector<int>> d(m+1);
	
	for(int i=1;i<=m;i++)
	{
		d[i].push_back(0);
		for(int j=1;j<=n;j++)
		{
			scanf("%d",&a);
			d[i].push_back(a);
		}
	}
	
	scanf("%d%d",&a,&b);
	vector<int> u;
	u.push_back(0);
	if(!f(d,1,1,0,0))
		printf("0\n");
	{
		for(int i=int(h.size())-1; i>=0;i--)
			if(i==0)
				printf("%d\n",h[i]);
			else
				printf("%d ",h[i]);
	}







	
	fclose(stdout);
}
