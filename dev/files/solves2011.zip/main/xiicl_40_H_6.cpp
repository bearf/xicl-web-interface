#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <utility>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <cstring>

const int maxn = 430;
const int inf = 1000000;

struct Edge {
  int v, c, f, w, back;
  Edge(int v_, int c_, int f_, int w_, int back_): v(v_), c(c_), f(f_), w(w_), back(back_) {}
};


bool isar[maxn];

int phi[maxn], d[maxn], prev[maxn], m, n, prev2[maxn];
bool b[maxn];
std::vector<Edge> edges[maxn];

int best_ans = 0;

void GetFlow() {
  memset(b, false, sizeof(b));
  for (int i = 1; i <= 2*n; ++i) {
    phi[i] = inf;
  }
  phi[n+1] = 0;
  for (int k = 1; k <= 2*n; ++k) {
    for (int i = 1; i <= 2*n; ++i) {
      for (int j = 0; j < edges[i].size(); ++j) {
        if (edges[i][j].c > 0 && phi[edges[i][j].v] > phi[i] + edges[i][j].w) {
          phi[edges[i][j].v] = phi[i] + edges[i][j].w;
        }
      }
    }
  }
  int ans = 0;
  for (int k = 1; k <= 2*n; ++k) {
    for (int i = 1; i <= 2*n; ++i) {
      d[i] = inf;
    }
    d[n+1] = 0;
    memset(b, false, sizeof(b));
    for (int i = 1; i <= 2*n; ++i) {
      int mn = 1;
      for (int j = 2; j <= 2*n; ++j) {
        if ((!b[j]) && (b[mn] || d[j] < d[mn])) {
          mn = j;
        }
      }
      b[mn] = true;
     
      for (int j = 0; j < edges[mn].size(); ++j) {
        if (edges[mn][j].c-edges[mn][j].f > 0 && d[edges[mn][j].v] > d[mn] + phi[mn]-phi[edges[mn][j].v] + edges[mn][j].w) {
          d[edges[mn][j].v] = d[mn] + phi[mn]-phi[edges[mn][j].v] + edges[mn][j].w;
          prev[edges[mn][j].v] = mn;
          prev2[edges[mn][j].v] = j;
        } 
      }
    }
    
    if (d[1] < inf/2) {
      int cur = 1;
      while (cur != n+1) {
        int pp = prev[cur];
        int pp2 = prev2[cur];
        ans -= edges[pp][pp2].w;
        ++edges[pp][pp2].f;
        edges[cur][edges[pp][pp2].back].f = -edges[pp][pp2].f;
        cur = prev[cur];
      }
      if (ans > best_ans) {
        best_ans = ans;
      }
    } else {
      return;
    }
   
    for (int i = 1; i <= 2*n; ++i) {
      phi[i] += d[i];
    }
  }
}

int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
  
  int k;
  
  std::memset(isar, 0, sizeof(isar));
  std::cin >> n >> m >> k;
  for (int i = 0; i < k; ++i) {
    int v;
    std::cin >> v;
    isar[v] = true;
  }
  
  for (int i = 0; i < m; ++i) {
    int u, v, w;
    std::cin >> u >> v;
    if (u == 1) {
      edges[n+1].push_back(Edge(v, 1, 0, 1, edges[v].size()));
      edges[v].push_back(Edge(n+1, 0, 0, -1, edges[n+1].size()-1));
    } else {
      edges[n+u].push_back(Edge(v, 1, 0, 0, edges[v].size()));
      edges[v].push_back(Edge(n+u, 0, 0, 0, edges[n+u].size()-1));
    }
  }  
  for (int i = 2; i <= n; ++i) {
    if (isar[i]) {
      edges[i].push_back(Edge(n+i, 1, 0, -maxn, edges[n+i].size()));
      edges[n+i].push_back(Edge(i, 0, 0, maxn, edges[i].size()-1));
    } else {
      edges[i].push_back(Edge(n+i, 1, 0, 0, edges[n+i].size()));
      edges[n+i].push_back(Edge(i, 0, 0, 0, edges[i].size()-1));
    }
  }
  
  GetFlow();
  
  if (isar[1]) {
    best_ans += maxn;
  }
  

  std::cout << (best_ans+maxn-1)/maxn << " " << ((maxn-best_ans%maxn)%maxn) << std::endl;

  return 0;
}