import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;

public class Solution implements Runnable {
	private long pow(long num, long p, long mod) {
		if (p == 0) {
			return 1;
		}
		if ((p&1) == 1) {
			return (num*pow(num,p-1,mod))%mod;
		}
		else {
			long ans = pow(num,p>>1,mod);
			return (ans*ans)%mod;
		}
	}
	
	private long ff(int n, int m) {
		long ans = 1;
		if (n+m-1 >= 0)
			ans = f[n+m-1];
		long inv1 = 1;
		if (n > 0)
			inv1 = f[n];
		long inv2 = 1;
		if (m-1 > 0) {
			inv2 = (inv2 * f[m-1])%MOD;
		}
		long inv = (inv1*inv2)%MOD;
		long ii = pow(inv, MOD-2, MOD);
		
		if ((ii*inv)%MOD != 1) {
			System.err.print("FFFU!");
		}
		return (ans*ii)%MOD;
	}
	
	long[] f;
	long MOD = 1000000009;
	public void run() {
		int n = nextInt();
		int m = nextInt();
		int[] arr = new int[m];
		for (int i = 0; i < m; ++i) {
			arr[i] = nextInt();
		}
		Arrays.sort(arr);
		
	//	out.println(pow(2, 10, 1000000));
		
		f = new long[200000];
		f[0] = 1;
		for (int i = 1; i < 200000; ++i) {
			f[i] = (f[i-1]*i)%MOD;
		}
		
		long ans = ff(n, m);
		int c = 0;
		
		int pos = m-1;
		for (int j = n; j >= 0; --j) {
			while (pos >= 0 && arr[pos] >= j) {
				--pos;
			}
			
			int cnt = (pos+1);
			long add = (1L*cnt*ff(n-j, m-1))%MOD;
			ans = (ans - add + MOD)%MOD;
		}
		out.println(ans);
		out.flush();
	}
	
	public static BufferedReader br;
	public static PrintWriter out;
	public static StringTokenizer stk;
	public static void main(String[] args) throws IOException {
		br = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter("output.txt");
		(new Thread(new Solution())).run();
	}
	
	private void loadLine() {
		try{
			stk = new StringTokenizer(br.readLine());
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String nextLine() {
		try {
			return br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private int nextInt() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Integer.parseInt(stk.nextToken());
	}
	
	private long nextLong() {
		while(stk==null || !stk.hasMoreElements()) loadLine();
		return Long.parseLong(stk.nextToken());
	}

}
