#include <fstream>
using namespace std;
bool glas(char c)
{
	if ((c=='a')||(c=='A')||(c=='e')||(c=='E')||(c=='i')||(c=='I')||
		(c=='O')||(c=='o')||(c=='u')||(c=='U')||(c=='y')||(c=='Y'))
		return true;
	return false;
}
void main()
{
	char str[100001]={0};
	int N;
	ifstream inp("input.txt");
	inp>>N;
	for (long int i=0;i<N;i++)
	 inp>>str[i];
	inp.close();
	bool f=false;
	for (long int i=0;!f&&(i<strlen(str)-1);i++)
	{
		if (glas(str[i])==glas(str[i+1]))
			f=true;
	}
	ofstream oup("output.txt");
	if (f)
		oup<<"BAD";
	else
		oup<<"GOOD";
	oup.close();
}