#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <utility>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <cstring>

const int maxn = 220;

int a[maxn][maxn], n, st[maxn];
std::vector<int> was, ans, e;

void dfs(int v) {
  for (int i = 0; i <= 2*n; ++i) {
    if (a[v][i]) {
      --a[v][i];
      if (v != i) {
        --a[i][v];
      }
      --st[v];
      if (i != v) {
        --st[i];
      }
      dfs(i);
    }
  }
  ans.push_back(v);
}

int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
  
  std::cin >> n;
  
  for (int i = 0; i <= 2*n; ++i) {
    for (int j = 0; j <= 2*n; ++j) {
      ++a[i][j];
    }
    st[i] = 2*n+1;
  }
  int u, v;
  std::cin >> u;
  was.push_back(u);
  while (std::cin >> v) {
    --st[u];
    if (u != v) {
      --st[v];
    }
    --a[u][v];
    if (u != v) {
      --a[v][u];
    }
    was.push_back(v);
    u = v;
  }
  if (st[was[0]]) {
    dfs(was[0]);
  }
  
  for (int i = 1; i < ans.size(); ++i) {
    was.push_back(ans[i]);
  }  
  
  for (int i = 0; i < was.size(); ++i){
    if (st[was[i]] > 0) {
      ans.clear();
      dfs(was[i]);
      for (int j = 0; j+1 < ans.size(); ++j) {
        e.push_back(ans[j]);
      }
    }
    e.push_back(was[i]);
  }
  
  for (int i = 0; i < e.size(); ++i) {
    std::cout << e[i] << " ";
  }
  std::cout << std::endl;

  return 0;
}