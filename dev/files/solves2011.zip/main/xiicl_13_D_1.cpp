#include <iostream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <list>
#include <bitset>
#include <sstream>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define X first
#define Y second
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1E9);
const ld PI = acos(-1.0);
const ld EPS = 1E-9;

const string v = "aeiouy";

bool isG(char c){
    c = tolower(c);
    return find(all(v), c) != v.end();
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int n;
    string s;
    cin >> n;
    cin >> s;

    vector<int> a, b;
    forn(i, n){
        if(isG(s[i]))
            a.pb(i);
        else
            b.pb(i);
    }

    bool bad = false;
    forn(i, sz(a)-1){
        if(a[i]+1 == a[i+1])
            bad = true;            
    }
    forn(i, sz(b)-1)
        if(b[i]+1 == b[i+1])
            bad = true;

    if(bad)
        puts("BAD");
    else
        puts("GOOD");


    return 0;
}
