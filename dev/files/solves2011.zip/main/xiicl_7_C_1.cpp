#include <iostream>
#include <stdio.h>
#include <string>
#include <string.h>
#include<set>
#include <algorithm>
#include <map>
#include <queue>
typedef long long li;

using namespace std;
void solve();
int main(){
#ifdef _DEBUG
	freopen("in.txt","r",stdin);
#else
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	solve();
	return 0;
}
li fact[30000];
void solve(){
	li a,b,x,y,z;
	cin>>a>>b>>x>>y>>z;
	li s=0;
	s-=(b*x)*(a-1);
	s+=(b-1)+(a-1)*z+1;
	s+=(a-1)*b*x*(x+1)/2;
	s+=b*b*x*y;
	s+=b*(y-1+(y-1)*y/2*(a-1));
	//s+=b*x+(a-1)*y+1;
	s+=b*((z-1)+(z-1)*z/2*(a-1))+(b-1)+(a-1)*y+1;
	if(b*x+(a-1)*y+1>=b*z)
		s+=(b*x+(a-1)*y+1-b*z)*((a-1)*z+1);
	else{
		s+=(x*(a-1)+b*y)*(z*b-(b*x+(a-1)*y+1));
	}
	cout<<s;

}