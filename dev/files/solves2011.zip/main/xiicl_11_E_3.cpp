#include <cstdio>
#include <cstring>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <algorithm>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

#define fi first
#define se second
#define re return
#define pb push_back
#define mp make_pair
#define sz(x) (int)((x).size ())
#define all(x) (x).begin (), (x).end ()
#define rep(i,n) for (int i = 0; i < n; i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define fill(x,y) memset(x, y, sizeof (x))
#define PI 3.1415926535897932384626433832795 
#define y0 y2341234
#define y1 y2513452

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

const int di[5] = {1, 0, -1, 0, 0};
const int dj[5] = {0, 1, 0, -1, 0};

int n;
int m, l, t;
char w[501][501];
char g[41][501][501];
char was[41][501][501];
int d[41][501][501];
short qi[501 * 501 * 41], qj[501 * 501 * 41];
char qt[501 * 501 * 41];
int si, sj, fi, fj;

int main () {
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);

	scanf ("%d", &n);
	gets (w[0]);
	for (int i = 0; i < n; i++) gets (w[i]);
	scanf ("%d%d", &l, &t); l /= 2;
	t = l - t;
	for (int i = 0; i < n; i++) 
		for (int j = 0; j < n; j++) {
			if (w[i][j] == 'D') {
				w[i][j] = 'X';
				si = i;
				sj = j;
			}
			if (w[i][j] == 'K') {
				w[i][j] = 'X';
				fi = i;
				fj = j;
			}
			g[t][i][j] = int (w[i][j] == 'X');
		}	
	for (int k = 0; k + 1 < 2 * l; k++) {
		int ct = (t + k) % (2 * l);
		int nt = (t + k + 1) % (2 * l);
/*		printf ("%d:\n", ct);
		for (int i = 0; i < n; i++){
			for (int j = 0; j < n; j++)
				printf ("%d", g[ct][i][j]);
			printf ("\n");
		}*/
		if (ct < l) {
			int bad = 1;
			for (int i = 0; i < n; i++)
				for (int j = 0; j < n; j++) {
					int ok = int (g[ct][i][j] == 0);
					for (int d = 0; d < 4; d++) {
						int ni = i + di[d];
						int nj = j + dj[d];
						if (ni >= 0 && nj >= 0 && ni < n && nj < n && !g[ct][ni][nj])
							ok = 1;
					}
					if (ok) {
						g[nt][i][j] = 0;
						bad = 0;
					} else g[nt][i][j] = 1;
				}
			if (bad) {
				g[nt][0][0] = g[nt][n - 1][0] = g[nt][0][n - 1] = g[nt][n - 1][n - 1] = 0;
			}
		} else {
			for (int i = 0; i < n; i++)
				for (int j = 0; j < n; j++) {
					int ok = int (g[ct][i][j] == 1);
					for (int d = 0; d < 4; d++) {
						int ni = i + di[d];
						int nj = j + dj[d];
						if (ni >= 0 && nj >= 0 && ni < n && nj < n && g[ct][ni][nj])
							ok = 1;
					}
					g[nt][i][j] = ok;
				}
		}
	}
	int l = 0, r = 1;
	qi[0] = si;
	qj[0] = sj;
	qt[0] = t;
	was[t][si][sj] = 1;
	d[t][si][sj] = 0;
	while (l < r) {
		int i = qi[l];
		int j = qj[l];
		int t = qt[l];
//		printf ("%d %d %d = %d %d\n", i, j, t, d[t][i][j], g[t][fi][fj]);
		int nt = t + 1;
		if (nt == 2 * (::l)) nt = 0;
		l++;
		if (!g[t][fi][fj]) continue;// || !g[nt][fi][fj]) continue;
		if (i == fi && j == fj) {
			printf ("%d\n", d[t][i][j]);
			re 0;
		}
		for (int dt = 0; dt < 5; dt++) {
			int ni = i + di[dt];
			int nj = j + dj[dt];
			if (ni >= 0 && nj >= 0 && ni < n && nj < n && g[nt][ni][nj] && !was[nt][ni][nj]) {
				was[nt][ni][nj] = 1;
				d[nt][ni][nj] = d[t][i][j] + 1;
				qi[r] = ni;
				qj[r] = nj;
				qt[r] = nt;
				r++;
			}
		}
	}
	printf ("-1\n");
	re 0;
}