#include <fstream>
using namespace std;
void main()
{
 ifstream inp("input.txt");
 long long a,b,x,y,z;
 inp>>a>>b>>x>>y>>z;
 inp.close();
 long long sl,sp,sv,l,h,ll,lp,hl,hp;
 sl=(2*a*b+(x-1)*a)*x/2;
 sp=((a+b-1)*2+(z-1)*a)*z/2;
 sv=((a+b-1)*2+(y-1)*a)*y/2;
 l=(a-b)+a*(y-1);
 h=b+(b-1)*(y-1);
 hl=(b-1)*x+1;
 hp=(b-1)*z+1;
 ll=a*x;
 lp=a*z;
 long long s=sl+sp+sv;
 if (ll+h>lp)
	 s+=(ll+h-lp)*hp+l*ll;
 else
 if (ll+h<lp)
	 s+=(lp-ll-h)*hl+l*(lp-h);
 else
	 s+=ll*l;
 ofstream oup("output.txt");
 oup<<s;
 oup.close();
}