#include<iostream>
#include<fstream>
#include<math.h>
#define L long long int
//out << ix2 << " " << jx2 << endl;

using namespace std;

int main()
{
    ifstream in("input.txt");
    ofstream out("output.txt");
    long int a, b;
    in >> a >> b;
    long int x, y, z;
    in >> x >> y >> z;
    L jk = 0;
    /*jk+=(x-1)*a;
    jk+=y*(b-1)+1;
    jk-=z*a;
    L h = 0;
    if (jk < 0)
    {
           h = abs(jk);
    }*/
    L a0;
    //out << h << endl;;
    L s1 = 0;
    s1+=((x-1)*a)*x/2;
    //out << s << "s" << endl;
    a0 = (x*a)*3 + 4;
    //out << a0 << "a0" << endl;
    s1+=(2*a0 + (y-1)*(a+b-2))*y/2;
    //out << s << "s" << endl;
    a0 = x*a+y*(b-1)+1;
    //out << a0 << "a0" << endl;
    s1+=a0;
    //out << s << "s" << endl;
    a0-=a-1;
    //out << a0 << "a0" << endl;
    s1+=(2*a0+(z-1)*(-1)*a)*z/2;
    //out << s << "s" << endl;
    //out << s;
    a0 = 0;
    L s2 = 0;
    s2+=(2+(z-1)*a)*z/2;
    a0 = 1+(z-1)*a +(a-1);
    s2+=a0;
    a0 = (a0-1)*3+1;
    s2+=(2*a0+(y-1)*(-3))*y/2;
    a0 = (z-1)*a + 3 - y*(b-1)-1-3;
    s2+=(2*a0 + (x-2)*(-1)*a)*(x-1)/2;
    out << max(s1, s2);
    return 0;
}
