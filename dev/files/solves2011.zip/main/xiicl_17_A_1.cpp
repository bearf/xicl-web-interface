#include <algorithm>
#include <iostream>
#include <string>
#include <cctype>
#include <set>
#include <vector>
#include <queue>

#define vv vector
#define mp make_pair
#define px first
#define py second
#define in cin
#define out cout

using namespace std;

typedef long long ll;

int n, m, ex, ey;

const int dx[] = {0, 0, -2, +2};
const int dy[] = {-2, +2, 0, 0};

bool valid(pair<int, int> &v) {
	return v.px >= 0 && v.px < n && v.py >= 0 && v.py < m;
}

int main() {
	ios_base::sync_with_stdio(false);
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	in >> n >> m;
	vv< vv<int> > a(n, vv<int>(m));
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			in >> a[i][j];
		}
	}
	in >> ex >> ey;
	ex--, ey--;

	queue< pair<int, int> > q;
	vv< vv<int> > d(n, vv<int>(m, -1));
	vv< vv< pair<int, int> > > from(n, vv< pair<int, int> >(m, mp(-1, -1)));
	q.push(mp(0, 0));
	d[0][0] = 0;

	while (!q.empty()) {
		pair<int, int> v = q.front();
		q.pop();
		for (int dir = 0; dir < 4; dir++) {
			pair<int, int> u = mp(v.px + dx[dir], v.py + dy[dir]);
			pair<int, int> m = mp(v.px + dx[dir] / 2, v.py + dy[dir] / 2);
			if (valid(u) && d[u.px][u.py] == -1 && a[u.px][u.py] == a[m.px][m.py]) {
				d[u.px][u.py] = d[v.px][v.py] + 1;
				from[u.px][u.py] = v;
				q.push(u);
			}
		}
	}

	if (d[ex][ey] == -1) {
		out << 0;
	} else {
		out << d[ex][ey] << endl;
		vv<int> path;
		for (pair<int, int> v = mp(ex, ey); v != mp(-1, -1); v = from[v.px][v.py]) {
			path.push_back(a[v.px][v.py]);
		}
		for (int i = path.size() - 2; i >= 0; i--) {
			out << path[i] << ' ';
		}
	}

	return 0;
}