#define DEBUG

#include <algorithm>
#include <iostream>
#include <string>
#include <cctype>
#include <set>
#include <vector>
#include <queue>

#define vv vector
#define mp make_pair
#define px first
#define py second
#define in cin
#define out cout

using namespace std;

typedef unsigned long long ll;

int main() {
	ios_base::sync_with_stdio(false);
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	ll a, b, x, y, z;
	in >> a >> b >> x >> y >> z;
	ll s;

	ll hl = x * a;
	ll wl = x * (b - 1) + 1;
	ll sl = wl * hl - x * a * (x - 1) * (b - 1) / 2;

	ll wu = a * y;
	ll hu = y * (b - 1) + 1;
	ll su = wu * hu - y * (b - 1) * (a + y * (a - 1) + y - 2) / 2;

	ll wr = z * (b - 1) + 1;
	ll hr = a * z;
	ll sr = wr * hr - z * (b - 1) * (a + z * (a - 1) + z - 2) / 2;
	
	ll sc = (wu - b) * max(hl, hr - hu);
	ll sa = 0;
	if (hl + hu > hr) {
		sa = wr * (hl + hu - hr);
	} else {
		sa = wl * (hr - hl - hu);
	}
	s = sa + sl + sr + su + sc;
	out << s << endl;
	return 0;
}