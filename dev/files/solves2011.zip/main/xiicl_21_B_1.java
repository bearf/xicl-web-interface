import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.TreeSet;


public class Solution implements Runnable {

	long mod = (int)1e9 + 9;
	
	long[] fact = new long[200010];
	
	long pow(long v, long p) {
		long res = 1;
		long mul = v;
		while (p != 0) {
			if (p % 2 == 1) {
				res *= mul;
			}
			mul *= mul;
			res %= mod;
			mul %= mod;
			p /= 2;
		}
		return res;
	}
	
	long inv(long v) {
		return pow(v, mod - 2);
	}
	long div(long a, long b) {
		return (a * inv(b)) % mod;
	}
	long sub(long a, long b) {
		return ((a - b) % mod + mod) % mod;
	}
	
	void prep() {
		fact[0] = 1;
		for (int i = 1; i < fact.length; ++i) {
			fact[i] = (fact[i - 1] * i) % mod;
		}
	}
	
	long F(int m, int n) {
		if (m == 0 && n == 0) {
			return 1;
		}
		if (m == 0) {
			return 0;
		}
		return div(div(fact[m + n - 1], fact[m - 1]), fact[n]);
	}	
	
	int[] howMany;
		
		
	
	private void solve() throws IOException {	
		//System.err.println(F(0,2));
		int n = nextInt();
		int m = nextInt();
		int[] a = new int[m];
		long ans = F(m, n);
		for (int i = 0; i < m; ++i) {
			a[i] = Math.min(nextInt(), n);
		}
		Arrays.sort(a);
		howMany = new int[n + 1];
		int cur = 0;
		for (int i = 0; i <= n; ++i) {
			for (; cur < a.length && a[cur] < i ; ++cur)
				;
			howMany[i] = cur;
		}
		for (int i = (n + 1) / 2; i <= n; ++i) {
			ans = sub(ans, howMany[i] * F(m - 1, n - i));
		}
		out.println(ans);
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		(new Thread(new Solution())).start();
	}

	private BufferedReader br;
	private StringTokenizer st;
	private PrintWriter out;

	@Override
	public void run() {
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			st = new StringTokenizer("");
			if (Boolean.getBoolean("SPbAU")) {
				out = new PrintWriter(System.out);
			} else {
				out = new PrintWriter("output.txt");
			}
			prep();
			while (hasNext()) {
				solve();
				break;
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(-1);
		}		
	}
	String next() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return null;				
			}
			st = new StringTokenizer(temp);
		}
		return st.nextToken();		
	}
	boolean hasNext() throws IOException {
		while (!st.hasMoreTokens()) {
			String temp = br.readLine();
			if (temp == null) {
				return false;				
			}
			st = new StringTokenizer(temp);
		}
		return true;		
	}

	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
	double nextDouble() throws IOException {
		return Double.parseDouble(next());
	}
	long nextLong() throws IOException {
		return Long.parseLong(next());
	}
	

}
