#include <stdio.h>

char str[200000];

bool isA(char c)
{
	return c=='a' || c=='e' || c=='i' || c=='o' || c=='u' || c=='y';
}
int main()
{
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);

	char c;
	int i, N, s;
	scanf("%d", &N);
	scanf("%s", str);

	s = -1;
	bool b = true;
	for(i=0; b && i<N; i++)
	{
		c = str[i];
		if('A' <= c && c <= 'Z') c += 'a' - 'A';
		if(s == -1)
			if(isA(c)) s = 0;
			else s = 1;
		else if(s == 0)
			if(isA(c)) b = false;
			else s = 1;
		else
			if(isA(c)) s = 0;
			else b = false;
	}

	if(b) printf("GOOD");
	else printf("BAD");

	return 0;
}