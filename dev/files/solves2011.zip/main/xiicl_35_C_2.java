import java.io.*;
import java.util.*;
import java.math.*;

public class Solution{
	public static void main(String args[])throws Exception{
		Scanner in=new Scanner(new File("input.txt"));
		PrintWriter out=new PrintWriter("output.txt");
		long a, b, x, y, z;
		a=in.nextInt();
		b=in.nextInt();
		x=in.nextInt();
		y=in.nextInt();
		z=in.nextInt();
		long res=0;
		long h=0;
		res+=(b-1)*a*((x*(x-1))/2);
		h=a*x+1;
		res-=h;
		res+=a*(y*h+(b-1)*(((y-1)*y)/2));
		h+=y*(b-1);
		res+=2*h;
		h-=a-1;
		res+=(b-1)*(h*z-a*(((z-1)*z)/2));
		//System.out.println(res);
		//System.out.println(h);
		h-=(z-1)*a;
		//System.out.println(h);
		if(h<=1){
			res+=(1-h)*(x*(b-1)+y*a+z*(b-1)+1);
		}
		out.println(res);
		out.close();
	}
}