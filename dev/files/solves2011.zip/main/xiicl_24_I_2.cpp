#include <stdio.h>
#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <set>
#include <memory.h>
#include <math.h>
#include <algorithm>
using namespace std;
typedef long double ld;
typedef long long li;
typedef vector <int> vi;
#define pb push_back
#define mp make_pair
void solve ();
int main ()
{
#ifdef _DEBUG 
	freopen ("in.txt", "r", stdin);
#else 
	freopen ("input.txt", "r", stdin);
	freopen ("output.txt", "w", stdout);
#endif
	solve ();
	return 0;
}
#define int li
int n;
int answer[100500];
int rec (int cur)
{
	if (cur<100000 && answer[cur]>0 )
		return answer[cur];
	if (cur==1)
		return 1;
	if ( cur%2 )
	{
		if ( cur<100000 )
		{
		answer[cur]=rec ( (cur-1)/2 );
		return answer[cur];
		}
		return rec ( (cur-1)/2 );
	}
	if (cur<100000)
	{
	answer[cur]=rec ( cur/2 )+ rec ((cur-2)/2);
	return answer[cur];
	}
	return rec ( cur/2 )+ rec ((cur-2)/2);
}
void solve ()
{
	cin>>n;
	answer[0]=1;
	answer[1]=1;
	for (int i=1; i<=10000; i++)
		answer[i]=rec(i);
	cout<<rec (n);
}