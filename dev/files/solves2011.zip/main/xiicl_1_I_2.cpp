#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;
//vector<__int64> m;
//vector<__int64> s;
map<__int64,__int64> h;


__int64 fi(__int64 n)
{
	if(n==0) return 1;
	if(n&1)
	{
		n>>=1;
		__int64 a=0; 
		if(h[n]==0)
		{
			a=fi(n);
			h[n]=a;
			return a;
		}
		else
			return h[n];
	}
	else
	{
		__int64 a=0; 
		if(h[n>>1]==0)
		{
			a=fi(n>>1);
			h[n>>1]=a;
		}
		else
			a=h[n>>1];
		__int64 b=0; 
		if(h[(n-2)>>1]==0)
		{
			b=fi((n-2)>>1);
			h[(n-2)>>1]=b;
		}
		else
			b=h[(n-2)>>1];
		return a+b;
	}
}

int main()
{
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	__int64 n;
	n=1;
	scanf("%I64d",&n);

	cout<<fi(n)<<endl;

	
	fclose(stdout);
}
