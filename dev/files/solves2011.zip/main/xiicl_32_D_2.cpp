#include <fstream>
using namespace std;
bool glas(char c)
{
	if ((c=='a')||(c=='A')||(c=='e')||(c=='E')||(c=='i')||(c=='I')||
		(c=='O')||(c=='o')||(c=='u')||(c=='U')||(c=='y')||(c=='Y'))
		return true;
	return false;
}
void main()
{
	char str[100001]={0};
	int N;
	ifstream inp("input.txt");
	inp>>N;
	inp>>str[0];
    bool f=false;
	for (long int i=1;(i<N)&&(!f);i++)
	{
	 inp>>str[i];
	 if (glas(str[i])==glas(str[i-1]))
		f=true;
	}
	inp.close();
	ofstream oup("output.txt");
	if (f)
		oup<<"BAD";
	else
		oup<<"GOOD";
	oup.close();
}