#include <fstream>
//#include <iostream>
using namespace std;

int pol[510][510];
int path[510][510];

struct pt
{
	pt(int x_, int y_): x(x_), y(y_) {}
	int x;
	int y;
};

int obrpath[250001];

int stx[250001];
int sty[250001];
int sti = 0;

int main()
{
	ifstream fi("input.txt");
	ofstream fo("output.txt");

	int M, N;
	int tX, tY;
	fi >> M >> N;
	for (int i = 0; i < M; ++i)
		for (int j = 0; j < N; ++j)
		{
			fi >> pol[i][j];
			path[i][j] = 0;
		}
	fi >> tY >> tX;
	tX--;
	tY--;

	
	int x = 0, y = 0;
	path[0][0] = 1;
	int pathi = 2;


	
/*	for(int i = 0;i < M;++i)
	{
		for(int j = 0;j < N;++j)
			cout << pol[i][j] << ' ';
		cout << endl;
	}
*/
	
	bool found = false;

	while(true)
	{
		int dn = 0;
		int gooddd;

//		cout << x << ' ' << y << ' ' << st.size() << endl;

		if (x < N - 2 && pol[y][x+1] == pol[y][x+2] && path[y][x+2] == 0) {++dn;gooddd = 1;}
		if (x >= 2 && pol[y][x-1] == pol[y][x-2] && path[y][x-2] == 0)    {++dn;gooddd = 3;}
		if (y < M -2  && pol[y+1][x] == pol[y+2][x] && path[y+2][x] == 0) {++dn;gooddd = 2;}
		if (y >= 2  && pol[y-1][x] == pol[y-2][x] && path[y-2][x] == 0)   {++dn;gooddd = 0;}


		if(dn > 1)
		{
			stx[sti] = x;
			sty[sti] = y;
			++sti;
		}

		if(dn == 0)
		{
			if(sti > 0)
			{
				x = stx[sti-1];
				y = sty[sti-1];
				--sti;
				continue;
			}
			else
			{
				break;
			}
		}

		if(gooddd == 0) y -= 2;
		if(gooddd == 1) x += 2;
		if(gooddd == 2) y += 2;
		if(gooddd == 3) x -= 2;

		path[y][x] = pathi++;

		if(x == tX && y == tY)
		{
			found = true;
			break;
		}
	}

/*	for(int i = 0;i < M;++i)
	{
		for(int j = 0;j < N;++j)
			cout << path[i][j] << ' ';
		cout << endl;
	}
*/
	int opi = 0;
	if(found)
	{
		while(!(x == 0 && y == 0))
		{
			obrpath[opi++] = pol[y][x];

//			cout << x << ' '<<y<<endl;

			int mini = 260000;
			int gooddd;
			if (x < N - 2 && pol[y][x] == pol[y][x+1] && path[y][x+2] > 0)
			{
				int v =	path[y][x+2];
				if (v < mini)
				{
					mini = v;
					gooddd = 1;
				}
			}
			if (x >= 2 && pol[y][x] == pol[y][x-1] && path[y][x-2] > 0)
			{
				int v =	path[y][x-2];
				if (v < mini)
				{
					mini = v;
					gooddd = 3;
				}
			}
			if (y < M - 2 && pol[y][x] == pol[y+1][x] && path[y+2][x] > 0)
			{
				int v =	path[y+2][x];
				if (v < mini)
				{
					mini = v;
					gooddd = 2;
				}
			}
			if (y >= 2 && pol[y][x] == pol[y-1][x] && path[y-2][x] > 0)
			{
				int v =	path[y-2][x];
				if (v < mini)
				{
					mini = v;
					gooddd = 0;
				}
			}
			
			if(gooddd == 0) y -= 2;
			if(gooddd == 1) x += 2;
			if(gooddd == 2) y += 2;
			if(gooddd == 3) x -= 2;
		}

		fo << opi << endl;
		for(int i = opi - 1; i >=0; --i)
			fo << obrpath[i] << ' ';
	}
	else
		fo << 0;

	return 0;
}