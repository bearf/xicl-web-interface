#include<stdio.h>
const bool gl[]={1, 0, 0, 0, 1, 0, 0, 0, 1, 
0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 
1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0,
0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0};
int main(){
	char a[100002];
	int n,i;
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	scanf("%d\n",&n);
	gets(a);
	bool p=1;
	for(i=1;i<n && p;i++){
		p=gl[a[i-1]-'A']^gl[a[i]-'A'];
	}

	if(p)
		puts("GOOD");
	else 	puts("BAD");
return 0;
}

	