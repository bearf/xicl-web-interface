#define _CRT_SECURE_NO_DEPRECATE
#pragma comment (linker, "/STACK:200000000")
#define _SECURE_SCL 0
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace std;


typedef long long int64;

const int INF = (int) 1E9;
const int64 INF64 = (int64) 1E18;
const double EPS = 1E-9;
const double PI = acos((double)0) * 2;

#define forn(i,n)  for (int i=0; i<int(n); ++i)
#define ford(i,n)  for (int i=int(n)-1; i>=0; --i)
#define fore(i,l,n)  for (int i=int(l); i<int(n); ++i)
#define all(a)  a.begin(), a.end()
#define fs  first
#define sc  second
#define pb  push_back
#define mp  make_pair


const int MAXN = 300000;

int n;
vector<int> g[MAXN];
int64 ans;


bool read() {
	if (! (cin >> n))  return false;
	forn(i,n) {
		int c;
		scanf ("%d", &c);
		g[i].resize (c);
		forn(j,c) {
			scanf ("%d", &g[i][j]);
			--g[i][j];
		}
	}
	return true;
}


typedef pair<int,int> pi;

vector<pi> add (pi a, vector<pi> b) {
	if (b.empty())  return vector<pi> (1, a);
	if (b[0].fs == a.fs) {
		b[0].sc += a.sc;
		return b;
	}
	b.insert (b.begin(), a);
	if (b.size() > 2)
		b.pop_back();
	return b;
}

pair < vector<pi>, vector<pi> > dfs (int v) {
	if (g[v].empty())
		return mp (vector<pi>(), vector<pi>());

	if (g[v].size() == 1) {
		pair < vector<pi>, vector<pi> > to = dfs (g[v][0]);
		vector<pi> nfs = add (mp(1,1), to.fs);
		vector<pi> nsc = add (mp(1,1), to.sc);

		if (nfs.size() == 2)
			ans += nfs[1].sc;
		if (nsc.size() == 2)
			ans += nsc[1].sc;

		return mp (nfs, nsc);
	}

	++ans;

	pair < vector<pi>, vector<pi> > left = dfs (g[v][0]);
	pair < vector<pi>, vector<pi> > right = dfs (g[v][1]);
	left.fs = add (mp(0,1), left.fs);
	left.sc = add (mp(0,1), left.sc);
	right.fs = add (mp(2,1), right.fs);
	right.sc = add (mp(2,1), right.sc);

	if (left.sc.size() == 2)
		ans += left.sc[1].sc;
	if (right.fs.size() == 2)
		ans += right.fs[1].sc;
	
	return mp (left.fs, right.sc);
}

void solve() {
	ans = 0;
	dfs (0);
	cout << ans << endl;
}


int main() {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	if (read())
		solve();

}
