#include <stdio.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <string.h>
#include <string>
#include <set>
#include <map>
#include <algorithm>
using namespace std;

struct TEdge
{
	int dest;
	int next;
	int c;
	int f;
	int cost;
	int rev;

	TEdge( int _dest = 0, int  _next = 0, int _c = 0, int _f = 0,  int _cost = 0, int _rev = 0 )
	{
		dest = _dest;
		next = _next;
		c = _c;
		f = _f;
		cost = _cost;
		rev = _rev;
	}
};

const int MaxN = 210;

int startE[MaxN * 2];

TEdge e[MaxN * MaxN * 15];
int eSize;

void addEdge( int x, int y, int c, int f, int cost, int rev )
{
	e[eSize++] = TEdge( y, startE[x], c, f, cost, rev );
	startE[x] = eSize - 1;
}

int dist[MaxN * 2], prevV[MaxN * 2], prevE[MaxN * 2], n;

int list1[MaxN * 2], list2[MaxN * 2];
int list1Size, list2Size;

bool inList[MaxN * 2];

const int Small = -1;

bool IsFindPath()
{
	dist[0] = 0;
	for( int i = 1; i < 2*n; i++ ) {
		dist[i] = Small;
	}
	list2Size = 0;
	list2[list2Size++] = 0;
	for( int i = 0; i < 2*n; i++ ) {
		inList[i] = false;
	}

	while( list2Size > 0 ) {
		list1Size = list2Size;
		for( int i = 0; i < list1Size; i++ ) {
			list1[i] = list2[i];
		}

		list2Size = 0;
		for( int i = 0; i < list1Size; i++ ) {
			inList[ list1[i] ] = false;
		}
		
		for( int i = 0; i < list1Size; i++ ) {
			int ptr = startE[ list1[i] ];
			while( ptr != -1 ) {
				if( e[ptr].c - e[ptr].f > 0 &&
					dist[e[ptr].dest] < dist[ list1[i] ] + e[ptr].cost )
				{
					dist[e[ptr].dest] = dist[ list1[i] ] + e[ptr].cost;
					prevV[ e[ptr].dest ] = list1[i];
					prevE[ e[ptr].dest ] = ptr;

					if( !inList[ e[ptr].dest ] )
					{
						inList[ e[ptr].dest ] = true;
						list2[list2Size++] = e[ptr].dest;
					}
				}

				ptr = e[ptr].next;
			}
		}
	}

	if( dist[n] != Small )
	{
		int ptr = n;
		while( ptr != 0 ) {
			int numE = prevE[ptr];

			e[numE].f++;
			e[ e[numE].rev ].f--;

			ptr = prevV[ptr];
		}
	}
	return dist[n] != Small;
}

int main()
{
	freopen( "input.txt", "r", stdin );
	freopen( "output.txt", "w", stdout );
	int m, k, addToAns = 0;
	scanf( "%d%d%d", &n, &m, &k );

	bool isArt[MaxN];
	for( int i = 0; i < n; i++ ) {
		isArt[i] = false;
	}
	for( int i = 0; i < k; i++ ) {
		int num;
		scanf( "%d", &num );
		num--;
		if( num != 0 ) {
			isArt[num] = true;
		} else {
			addToAns++;
		}
	}

	//build graph
	eSize = 0;
	for( int i = 0; i < 2 * n; i++ ) {
		startE[i] = -1;
	}

	for( int i = 1; i < n; i++ ) {
		int cost = 0;
		if( isArt[i] ) {
			cost = 1;
		}

		addEdge( i, i + n, 1, 0, cost, eSize + 1  );
		addEdge( i + n, i, 0, 0, -cost, eSize - 1 );
	}

	for( int i = 0; i < m; i++ ) {
		int x, y;
		scanf( "%d%d", &x, &y );
		x--; y--;

		if( x != 0 && y != 0 ) {
			addEdge( x + n, y, 1, 0, 0, eSize + 1 );
			addEdge( y, x + n, 0, 0, 0, eSize - 1);
		} else {
			if( x == 0 ) {
				addEdge( 0, y, 1, 0, 0, eSize + 1 );
				addEdge( y, 0, 0, 0, 0, eSize - 1 );
			} else {
				if( y == 0 ) {
					addEdge( x + n, n, 1, 0, 0, eSize + 1 );
					addEdge( n, x + n, 0, 0, 0, eSize - 1 );
				}
			}
		}
	}

	//count flow + find answer
	int ans1 = 0, ans2 = 0, cur1 = 0, cur2 = 0;
	while( IsFindPath() ) {
		//path
		if( dist[n] <= 0 ) {
			break;
		}
		cur1 += dist[n];
		cur2 += 1;

		//check
		if( cur1 > ans1 || 
			( cur1 == ans1 && cur2 < ans2 ) )
		{
			ans1 = cur1;
			ans2 = cur2;
		}
	}


	//output
	printf( "%d %d\n", ans1 + addToAns, ans2 );
	return 0;
}
