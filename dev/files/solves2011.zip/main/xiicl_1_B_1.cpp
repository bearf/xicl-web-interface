#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <memory>
using namespace std;

	

int main()
{
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	vector<int> d(n+1,0);
	int a;
	scanf("%d",&a);
	for(int i=0;i<=n && i<=a;i++)
		d[i]=1;
	for(int i=2;i<=m;i++)
	{
		vector<int> g(n+1,0);
		scanf("%d",&a);
		for(int j=0;j<=n;j++)
		{
			int b=0;
			if(j>a) b=j-a;
			for(int k=b;k<=j;k++)
				g[j]+=d[k];
		}
		d=g;
	}
	printf("%d\n",d[n]);




	
	fclose(stdout);
}
