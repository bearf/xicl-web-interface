import java.io.File;
import java.io.PrintWriter;
import java.math.*;
import java.util.*;

public class Solution {
	public static void main(String[] args) throws Exception{
		new Solution().run();
	}
	
	BigInteger a, b, x, y, z;
	
	BigInteger Sum(BigInteger a0, BigInteger d, BigInteger n){
		if(n.signum() == 0) return BigInteger.ZERO;
		return ((a0.add(a0.add((n.subtract(BigInteger.ONE)).multiply(d)))).multiply(n)).divide(BigInteger.valueOf(2));
	}
	
	BigInteger solve(){
		BigInteger ans = BigInteger.ZERO;
		BigInteger S = a.add(b).subtract(BigInteger.ONE);
		BigInteger b1 = (b.subtract(BigInteger.ONE));
		{
			ans = ans.add(b1.multiply(Sum(a,a,z.subtract(BigInteger.ONE))));
			ans = ans.add(S.multiply(z));
		}
		
		{
			ans = ans.add(b1.multiply(Sum(a.subtract(BigInteger.ONE), a, x)));
			ans = ans.add(S.multiply(x));
			ans = ans.add(b1.multiply(Sum(a,a,y.subtract(BigInteger.ONE))));
			ans = ans.add(S.multiply(y));
			ans = ans.add(((y.multiply(a)).subtract(b)).multiply(x.multiply(a)));
		}
		
		BigInteger lf = (x.multiply(a)).add(y.multiply(b1)).add(BigInteger.ONE);
		BigInteger rg = z.multiply(a);
		BigInteger h = (lf.subtract(rg)).abs();
		
		if(rg.compareTo(lf) < 0){
			ans = ans.add(((z.multiply(b1)).add(BigInteger.ONE)).multiply(h));
		}else
			ans = ans.add((((x.multiply(b1)).add(BigInteger.ONE)).add((y.multiply(a)).subtract(b))).multiply(h));
		
		return ans;
	}
	
	public void run() throws Exception{
		Scanner scan = new Scanner(new File("input.txt"));
		PrintWriter out = new PrintWriter(new File("output.txt"));
		
		a = scan.nextBigInteger();
		b = scan.nextBigInteger();
		
		x = scan.nextBigInteger();
		y = scan.nextBigInteger();
		z = scan.nextBigInteger();
		
		out.write(solve() + "\n");
		
		out.close();
		scan.close();
	}
}
