#include <stdio.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

int IsGlasn( char ch )
{
	if( ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'y' || 
		ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' || ch == 'Y')
		return 1;
	else return 0;
}

int main()
{
	freopen( "input.txt", "r", stdin );
	freopen( "output.txt", "w", stdout );

	int n;
	string s;
	cin >> n;
	cin >> s;

	int cur = -1, prev = -1, len = s.size();
	bool ans = true;
	for( int i = 0; i < len; i++ ) {
		prev =  cur;

		cur = IsGlasn( s[i] );

		if( cur == prev ) {
			ans = false;
			break;
		}
	}

	if( ans ) {
		cout << "GOOD" << endl;
	} else  {
		cout << "BAD" << endl;
	}
	return 0;
}
