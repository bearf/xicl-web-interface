#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <queue>

const int maxn = 503;

using namespace std;

struct par {
	int x, y;
};
struct rebro {
	int v, c;
};

int m, n, x, y, a[maxn][maxn], f;
vector<rebro> c[maxn * maxn];
rebro pred[maxn * maxn];
bool used[maxn * maxn];


void stop() {
	cout << 0;
	exit(0);
}
int trans(par t) {
	return (t.x - 1) / 2 * (m + 1) / 2 + (t.y + 1) / 2;
}
void bfs() {
	int u, v, len;
	queue<int> q;
	q.push(1);
	used[1] = 1;
	while (!q.empty()) {
		u = q.front();
		q.pop();
		len = c[u].size();
		for (int i = 0; i < len; i++) {
			v = c[u][i].v;
			if (!used[v]) {
				pred[v].v = u;
				pred[v].c = c[u][i].c;
				q.push(v);
				used[v] = 1;
			}
		}
	}
}

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			cin >> a[i][j];
	cin >> x >> y;
	if ((x % 2 == 0) || (y % 2 == 0))
		stop();

	par t1, t2;
	rebro tt;
	for (int i = 1; i <= n; i += 2)
		for (int j = 1; j <= m - 2; j += 2)
			if ( (a[i][j] == a[i][j + 1]) ||
				 (a[i][j + 2] == a[i][j + 1]) ) {

				t1.x = i;
				t1.y = j;
				t2.x = i;
				t2.y = j + 2;
				tt.c = a[i][j + 1];
				tt.v = trans(t2);
				c[trans(t1)].push_back(tt);
				tt.v = trans(t1);
				c[trans(t2)].push_back(tt);
			}
	for (int i = 1; i <= n - 1; i += 2)
		for (int j = 1; j <= m; j += 2)
			if ( (a[i][j] == a[i + 1][j]) ||
				 (a[i + 2][j] == a[i + 1][j]) ) {

				t1.x = i;
				t1.y = j;
				t2.x = i + 2;
				t2.y = j;
				tt.c = a[i + 1][j];
				tt.v = trans(t2);
				c[trans(t1)].push_back(tt);
				tt.v = trans(t1);
				c[trans(t2)].push_back(tt);
			}
	t1.x = x;
	t1.y = y;
	f = trans(t1);
	bfs();
	if (!used[f])
		stop();
	
	int rez[maxn], len = 0, s;
	while (f != 1) {
		s = c[f].size();
		rez[len++] = pred[f].c;
		f = pred[f].v;
	}
	cout << len << endl;
	for (int i = len - 1; i >= 0; i--)
		cout << rez[i] << " ";
	
	return 0;
}