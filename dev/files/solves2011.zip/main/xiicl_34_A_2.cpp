#include <iostream>
#include <string>
#include <algorithm>
#include <set>
#include <vector>
#include <queue>
using namespace std;

int a[500][500];
int best[500][500];

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int m, n;
	cin >> n >> m;
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < m; ++j)
		{
			cin >> a[i][j];
			best[i][j] = 999999999;
		}
	}
	int x, y;
	cin >> x >> y;
	pair<int, int> finish = make_pair(x-1, y-1);
	best[0][0] = 0;
	queue< pair<int, int> > q;
	q.push(make_pair(0, 0));
	while (!q.empty())
	{
		pair<int, int> p = q.front();
		q.pop();
		if ((p.first + 2 < n) && (best[p.first+2][p.second] == 999999999) && (a[p.first+1][p.second] == a[p.first+2][p.second]))
		{
			best[p.first+2][p.second] = best[p.first][p.second] + 1;
			q.push(make_pair(p.first+2, p.second));
		}
		if (p.first - 2 >= 0 && (best[p.first-2][p.second] == 999999999) && (a[p.first-1][p.second] == a[p.first-2][p.second]))
		{
			best[p.first-2][p.second] = best[p.first][p.second] + 1;
			q.push(make_pair(p.first-2, p.second));
		}		
		if (p.second + 2 < m && (best[p.first][p.second+2] == 999999999) && (a[p.first][p.second+1] == a[p.first][p.second+2]))
		{
			best[p.first][p.second+2] = best[p.first][p.second] + 1;
			q.push(make_pair(p.first, p.second+2));
		}		
		if (p.second - 2 >= 0&& (best[p.first][p.second-2] == 999999999)  && (a[p.first][p.second+1] == a[p.first][p.second+2]))
		{
			best[p.first][p.second-2] = best[p.first][p.second] + 1;
			q.push(make_pair(p.first, p.second+2));
		}
	}
	if (best[finish.first][finish.second] == 999999999)
	{
		cout << 0;
		return 0;
	}
	else
	{
		cout << best[finish.first][finish.second] << endl;
		vector<int> path;
		path.push_back(a[finish.first][finish.second]);
		pair<int, int> point = finish;
		while (point != make_pair(0, 0))
		{
			pair<int, int> minp = point;
			if (point.first + 2 < n && (a[point.first+1][point.second] == a[point.first][point.second]))
			{
				if (best[minp.first][minp.second] - 1 == best[point.first+2][point.second])
					minp = make_pair(point.first+2, point.second);
			}
			if (point.first - 2 >= 0 && (a[point.first-1][point.second] == a[point.first][point.second]))
			{
				if (best[minp.first][minp.second] - 1 == best[point.first-2][point.second])
					minp = make_pair(point.first-2, point.second);
			}		
			if (point.second + 2 < m && (a[point.first][point.second+1] == a[point.first][point.second]))
			{
				if (best[minp.first][minp.second] - 1 == best[point.first][point.second+2])
					minp = make_pair(point.first, point.second+2);
			}		
			if (point.second - 2 >= 0&& (a[point.first][point.second-1] == a[point.first][point.second]))
			{
				if (best[minp.first][minp.second] - 1 == best[point.first][point.second-2])
					minp = make_pair(point.first, point.second-2);
			}
			path.push_back(a[minp.first][minp.second]);
			if (path.size() > best[finish.first][finish.second])
				break;
			point = minp;
		}
		for (int i = path.size() -2; i >= 0; --i)
		{
			cout << path[i] << " ";
		}
	}
	return 0;
}