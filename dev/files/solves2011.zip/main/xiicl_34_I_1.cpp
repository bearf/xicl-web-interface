#include <iostream>
#include <string>
#include <algorithm>
#include <set>
#include <vector>
using namespace std;

bool bit(__int64 n, int i)
{
	return (n & (1 << i));
}

int main()
{

	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	__int64 n;
	cin >> n;
	vector<bool> bin;
	while (n > 0)
	{
		bin.push_back(n % 2);
		n /= 2;
	}
	int sz = bin.size();
	int i;
	for (i = 0; i < sz; ++i)
	{
		if (!bin[i])
			break;
	}
	if (i == sz)
		cout << 1;
	else
		cout << sz - i;
	return 0;
}