#include <iostream>
#include <stdio.h>
#include <string>
#include <string.h>
#include<set>
#include <algorithm>
#include <map>
#include <queue>
#include <vector>

using namespace std;
typedef long long li;
typedef pair<int,int> pi;


void solve();
int main(){
#ifdef _DEBUG
	freopen("in.txt","r",stdin);
#else
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	solve();
	return 0;
}
li dp[70][5];
void solve(){
	li n;
	cin>>n;
	int cnt=0;
	int ch[70];
	while(n){
		ch[cnt++]=n%2;
		n/=2;
	}
	dp[cnt-1][ch[cnt-1]]=1;
	for(int i=cnt-2;i>=0;--i){
		if(ch[i]==0){
			dp[i][0]=dp[i+1][0]+dp[i+1][1]+dp[i+1][2];
			dp[i][2]=dp[i+1][1]+dp[i+1][2]+dp[i+1][3];
		}
		else{
			dp[i][1]=dp[i+1][0]+dp[i+1][1]+dp[i+1][2];
			dp[i][3]=dp[i+1][1]+dp[i+1][2]+dp[i+1][3];
		}
	}
	cout<<dp[0][0]+dp[0][1]+dp[0][2];
}