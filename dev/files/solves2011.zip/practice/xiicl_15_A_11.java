import java.util.*;
import java.io.*;

public class Solution {

	void solve() throws IOException {
		out.println(nextLong() + nextLong());
		int n = 700;
		int[][] d = new int[n][n];
		int max = 100000;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				d[i][j] = rand.nextInt(max);
			}
		}
		for (int k = 0; k < n; k++) {
			int[] fatrat2 = d[k];
			for (int i = 0; i < n; i++) {
				int c = d[i][k];
				int[] fatrat1 = d[i];
				for (int j = 0; j < n; j++) {
					int a = fatrat1[j];
					int b = c + fatrat2[j];
					if (a <= b)
						fatrat1[j] = a;
					else
						fatrat1[j] = b;
					// fatrat1[j] = (a <= b) ? a : b;
				}
			}
		}
	}

	static final Random rand = new Random("not fatrat".hashCode());
	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	void run() {
		try {
			boolean io = System.getProperty("ONLINE_JUDGE") != null;
			br = new BufferedReader(new FileReader(io ? "input.txt"
					: "A.in".toLowerCase()));
			st = new StringTokenizer("");
			out = new PrintWriter(io ? "output.txt" : "A.out".toLowerCase());
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
