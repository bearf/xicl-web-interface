import java.util.*;
import java.util.Map.Entry;
import java.io.*;

public class Solution {

	int n, m;
	HashMap<Integer, Integer> hm;

	void add(int col) {
		Integer x = hm.get(col);
		if (x == null)
			x = 0;
		hm.put(col, x + 1);
	}

	HashMap<Integer, int[]> list;

	void solve() throws IOException {
		n = nextInt();
		m = nextInt();
		hm = new HashMap<Integer, Integer>();
		int[][] c = new int[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				c[i][j] = nextInt();
				add(c[i][j]);
			}
		}
		int[][] want = new int[n][m];
		int x = 0, y = 0;
		list = new HashMap<Integer, int[]>(hm.size());
		HashMap<Integer, Integer> cnt = new HashMap<Integer, Integer>();
		for (Entry<Integer, Integer> ent : hm.entrySet()) {
			int col = ent.getKey();
			for (int i = 0; i < ent.getValue(); i++) {
				want[x][y] = col;
				if ((x & 1) == 0) {
					y++;
					if (y == m) {
						++x;
						y = m - 1;
					}
				} else {
					--y;
					if (y < 0) {
						y = 0;
						++x;
					}
				}
			}
			list.put(col, new int[ent.getValue()]);
			cnt.put(col, 0);
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				int col = c[i][j];
				int[] ok = list.get(col);
				int count = cnt.get(col);
				ok[count++] = i * m + j;
				cnt.put(col, count);
			}
		}
		for (Entry<Integer, Integer> ent : cnt.entrySet()) {
			ent.setValue(0);
		}
		int[] havePermutation = new int[n * m];
		int[] pos = new int[n * m];
		for (int i = 0; i < havePermutation.length; i++) {
			havePermutation[i] = i;
			pos[i] = i;
		}
		int[] wantPermutation = new int[n * m];

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				int w = want[i][j];
				int xx = cnt.get(w);
				int p = list.get(w)[xx++];
				cnt.put(w, xx);
				wantPermutation[i * m + j] = p;
			}
		}
		// System.err.println(Arrays.toString(wantPermutation));

		ArrayList<int[]> answer = new ArrayList<int[]>();

		for (int i = 0; i < wantPermutation.length; i++) {
			int p = pos[wantPermutation[i]];
			if (p == i)
				continue;
			answer.add(new int[] { p, i });
			int t = havePermutation[i];
			havePermutation[i] = wantPermutation[i];
			havePermutation[p] = t;
			pos[t] = p;
			pos[wantPermutation[i]] = i;
		}
		out.println(answer.size());
		for (int[] ans : answer) {
			// System.err.println(Arrays.toString(ans));
			int x1 = ans[0] / m + 1;
			int y1 = ans[0] % m + 1;
			int x2 = ans[1] / m + 1;
			int y2 = ans[1] % m + 1;
			out.println(x1 + " " + y1 + " " + x2 + " " + y2);
		}
	}

	static final Random rand = new Random("not fatrat".hashCode());
	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	void run() {
		try {
			boolean io = System.getProperty("ONLINE_JUDGE") != null;
			br = new BufferedReader(new FileReader(io ? "input.txt"
					: "D.in".toLowerCase()));
			st = new StringTokenizer("");
			out = new PrintWriter(io ? "output.txt" : "D.out".toLowerCase());
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
