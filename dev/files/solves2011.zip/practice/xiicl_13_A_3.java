import java.util.*;
import java.io.*;
import java.math.*;

public class Solution {
	public static void main(String[] args) throws Exception{
		new Solution().run();
	}
	
	final int MAGIC = 1000*1000;
	
	void run() throws Exception{
		Scanner scan = new Scanner(new File("input.txt"));
		PrintWriter out = new PrintWriter(new File("output.txt"));
		BigInteger a = scan.nextBigInteger(), b = scan.nextBigInteger();
		out.print(a.add(b));
		
		for(int i = 0; i < MAGIC; ++i){
			a = a.add(b);
		}
		
		out.close();
		scan.close();
	}
}
