#include<iostream>
#include<vector>
#include<cstdio>
#include<algorithm>
#define vv vector
#define fr(i, a, b) for(int i = (a); i < (b); ++i)
#define out cout
#define in cin
#define px first
#define py second
#define mp make_pair
using namespace std;

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int n, m;
	in >> n >> m;
	vv<pair<int, pair<int, int> > > snake(n * m);
	vv<vv<pair<int, int> > > cur(n, vector<pair<int, int> > (m)), mem(n, vector<pair<int, int> > (m));
	fr(i, 0, n * m)
	{
		in >> snake[i].px;
		snake[i].py = mp(i / m, i % m);
		mem[i / m][i % m] = cur[i / m][i % m] = mp(i / m, i % m);
	}
	sort(snake.begin(), snake.end());
	int k = 0;
	out << n * m << endl;
	fr(i, 0, n)
	{
		if(!(i & 1))
		{
			fr(j, 0, m)
			{
				pair<int, int> t = mem[snake[k].py.px][snake[k].py.py];
				mem[snake[k].py.px][snake[k].py.py] = mp(i, j);
				mem[cur[i][j].px][cur[i][j].py] = t;
				swap(cur[i][j], cur[t.px][t.py]);
				out << i + 1 << ' ' << j + 1 << ' ' << t.px + 1 << ' ' << t.py + 1 << endl;
				++k;
			}
		}
		else
		{
			for(int j = m - 1; j >= 0; --j)
			{
				pair<int, int> t = mem[snake[k].py.px][snake[k].py.py];
				mem[snake[k].py.px][snake[k].py.py] = mp(i, j);
				mem[cur[i][j].px][cur[i][j].py] = t;
				swap(cur[i][j], cur[t.px][t.py]);
				out << i + 1 << ' ' << j + 1 << ' ' << t.px + 1 << ' ' << t.py + 1 << endl;
				++k;
			}
		}
	}
	return 0;
}