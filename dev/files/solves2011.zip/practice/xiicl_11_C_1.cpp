#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>

using namespace std;

#define sz(x) (int)((x).size ())
#define sqr(x) ((x) * (x))
#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define rep(i,n) for (int i = 0; i < (n); i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define re return
#define all(x) (x).begin (), (x).end ()
#define PI 3.1415926535897932384626433832795
#define fill(x,y) memset (x, y, sizeof (x))

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

#define filename ""

int n;
int m;

int was[10000], res[10000];
vi v[10000];

int go (int x, int y) {
	was[x] = 1;
	res[x] = y;
	for (int i = 0; i < sz (v[x]); i++) {
		int z = v[x][i];
		if (was[z] && res[z] == y) re 1;
		if (!was[z] && go (z, 1 - y)) re 1;
	}
	re 0;
}

int main () {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	scanf ("%d", &n);
	for (int i = 0; i < n; i++) {
		int a, b;
		scanf ("%d%d", &a, &b); a--; b--;
		v[i].pb (a);
		v[i].pb (b);
	}

	memset (was, 0, sizeof (was));
	for (int i = 0; i < n; i++)
		if (!was[i])
			if (go (i, 0)) {
				printf ("0\n");
				re 0;
			}
	for (int i = 0; i < n; i++)
		if (res[i])
			printf ("%d ", i + 1);
	printf ("\n");
	for (int i = 0; i < n; i++)
		if (!res[i])
			printf ("%d ", i + 1);
	printf ("\n");
	re 0;
}