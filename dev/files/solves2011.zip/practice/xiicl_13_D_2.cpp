#include <iostream>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <cassert>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define sz(s) (int((s).size()))

typedef pair<int, int> pt;
#define X first
#define Y second

int n, m;
vector< vector<int> > a;
vector< vector<int> > b;
map<int, int > cnt;
map<int, set<pt> > mp;

void getNext(pt& a){
    if(a.X & 1)
        a.Y--;
    else
        a.Y++;

    if(a.Y < 0){
        a.X++;
        a.Y = 0;
    } 
    if(a.Y >= m){
        a.X++;
        a.Y = m - 1;
    }       
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> n >> m;
    a.resize(n);
	b.resize(n);

    forn(i, n){
        a[i].resize(m);
		b[i].resize(m);

        forn(j, m){
            scanf("%d", &a[i][j]);
            cnt[a[i][j]]++;
        }
    }

    map<int, int>::iterator it = cnt.begin();
    int c = 0;
    pt cur(0, 0);
    forn(i, n)
        forn(j, m){
            if(c == it->second){
                it++;
                c = 0;
            }
            c++;

            b[cur.X][cur.Y] = it->first;
            if(a[cur.X][cur.Y] != b[cur.X][cur.Y])
                mp[a[cur.X][cur.Y]].insert(cur);

            getNext(cur);
        }

    vector< pair<pt, pt> > ans;
    cur = pt(0, 0);

    forn(i, n)
        forn(j, m){
            if(a[cur.X][cur.Y] != b[cur.X][cur.Y]){
                assert(!mp[b[cur.X][cur.Y]].empty());

                pt sw = (*mp[b[cur.X][cur.Y]].begin());
                mp[b[cur.X][cur.Y]].erase(sw);

                ans.push_back(make_pair(cur, sw));
                
                mp[a[cur.X][cur.Y]].erase(cur);
                a[sw.X][sw.Y] = a[cur.X][cur.Y];
                if(a[sw.X][sw.Y] != b[sw.X][sw.Y])
                    mp[a[sw.X][sw.Y]].insert(sw);

                a[cur.X][cur.Y] = b[cur.X][cur.Y];
            }

			getNext(cur);
        }

    cout << sz(ans) << endl;

    forn(i, sz(ans))
        cout << ans[i].X.X + 1 << " " << ans[i].X.Y + 1 << " " << ans[i].Y.X + 1 << " " << ans[i].Y.Y + 1 << endl;

    return 0;
}