#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <vector>
#include <string>
#include <map>
#include <set>

#define vv vector
#define mp make_pair
#define px first
#define py second
#define in cin
#define out cout

using namespace std;

typedef long long ll;

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	ll a, b;
	in >> a >> b;
	out << a + b;

	/*
	int n; in >> n;
	vv<string> a(n);
	for (int i = 0; i < n; i++) {
		in >> a[i];
	}
	for (int i = n - 1; i >= 0; i--) {
		out << a[i];
	}
	*/

	return 0;
}