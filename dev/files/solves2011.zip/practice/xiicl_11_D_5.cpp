#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>

using namespace std;

#define sz(x) (int)((x).size ())
#define sqr(x) ((x) * (x))
#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define rep(i,n) for (int i = 0; i < (n); i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define re return
#define all(x) (x).begin (), (x).end ()
#define PI 3.1415926535897932384626433832795
#define fill(x,y) memset (x, y, sizeof (x))

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

#define filename ""

int n;
int m;
int r = 0;
vii w;
vector<pair<ii, ii> > ans;
set<pair<int, ii> > s;

vi g[200000];

int main () {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	scanf ("%d%d", &n, &m);
	for (int i = 0; i < n; i++) g[i].resize (m);
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++) {
			int x;
			scanf ("%d", &x);
			g[i][j] = x;
			s.insert(mp(x, mp(i, j)));
		}

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			if (i & 1) w.pb (mp (i, m - j - 1)); else w.pb (mp (i, j));

	rep(i, sz(w)) {
		int x = w[i].fi;
		int y = w[i].se;
		pair<int, ii> cur = mp(g[x][y], mp(x, y));
		pair<int, ii> tmp = *s.begin();
//		cout << cur.fi << ' ' << tmp.fi << ' ' << cur.se.fi << ' ' << cur.se.se << ' ' << tmp.se.fi << ' ' << tmp.se.se << endl;
		s.erase(tmp);
		if (tmp != cur) {
			ans.pb(mp(tmp.se, cur.se));
			s.erase(cur);
			s.insert(mp(g[x][y], tmp.se));
			swap(g[x][y], g[tmp.se.fi][tmp.se.se]);
		}
	}

	printf ("%d\n", sz (ans));	
	for (int i = 0;i < sz (ans); i++)
		printf ("%d %d %d %d\n", ans[i].fi.fi + 1, ans[i].fi.se + 1, ans[i].se.fi + 1, ans[i].se.se + 1);
	re 0;
}