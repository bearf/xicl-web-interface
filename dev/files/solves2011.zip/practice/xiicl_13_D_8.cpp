#include <iostream>
#include <ctime>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <cassert>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define sz(s) (int((s).size()))

typedef pair<int, int> pt;
#define X first
#define Y second

int n, m;
vector< vector<int> > a;
vector< vector<int> > b;
map<int, int > cnt;
map<int, set<pt> > mp;

void getNext(pt& a){
    if(a.X & 1)
        a.Y--;
    else
        a.Y++;

    if(a.Y < 0){
        a.X++;
        a.Y = 0;
    } 
    if(a.Y >= m){
        a.X++;
        a.Y = m - 1;
    }       
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    {
        string s;
        forn(i, 35000000){
            s += 'a' + rand() % 26;
            if(i > 1000000)
                s.erase(sz(s) - 1);
                
        }
        int n = strlen(s.c_str());

        if(n & 1)
            cout << n << endl;
    }



    cerr << clock() << endl;

    return 0;
}
