#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int a, b;
    cin >> a >> b;

    cout << a+b << endl;

    return 0;
}