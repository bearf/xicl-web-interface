#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <vector>
#include <string>
#include <map>
#include <set>

#define vv vector
#define mp make_pair
#define px first
#define py second
#define in cin
#define out cout

using namespace std;

typedef long long ll;

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	string s, t;
	char c = '\0';
	int j = 0;
	in >> s;
	for (size_t i = 0; i < s.length(); i++) {
		if (s[i] != c) {
			if (j >= 1) {
				out << j + 1;
				j = 0;
			}
			out << s[i];
			c = s[i];
		} else {
			j++;
		}
	}
	if (j >= 1) {
		out << j + 1;
	}
	return 0;
}