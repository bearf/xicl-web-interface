#include <iostream>
#include <vector>
#include <cstring>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define sz(s) (int((s).size()))

int n;
vector<int> g[100500];

int p[100500];
bool dfs(int v){
	forn(i, sz(g[v])){
		int u = g[v][i];

		if(p[u] == -1){
			p[u] = 1 - p[v];
			if(dfs(u))
				return true;
		}else{
			if(p[u] == p[v])
				return true;
		}
	}

	return false;
}

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);

	cin >> n;
	forn(i, n){
		int x, y;
		scanf("%d %d", &x, &y);
		x--; y--;

		g[i].push_back(x);
		g[i].push_back(y);
	}

	memset(p, -1, sizeof(p));

	forn(i, n){
		if(p[i] == -1){
			p[i] = 0;
			if(dfs(i)){
				puts("0");
				return 0;
			}
		}
	}

	vector<int> fs, sc;
	forn(i, n)
		if(p[i] == 0)
			fs.push_back(i);
		else
			sc.push_back(i);

	forn(i, sz(fs))
		printf("%d ", fs[i] + 1);
	puts("");
	forn(i, sz(sc))
		printf("%d ", sc[i] + 1);
	puts("");
	return 0;
}