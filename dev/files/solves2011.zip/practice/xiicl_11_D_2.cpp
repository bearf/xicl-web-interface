#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>

using namespace std;

#define sz(x) (int)((x).size ())
#define sqr(x) ((x) * (x))
#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define rep(i,n) for (int i = 0; i < (n); i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define re return
#define all(x) (x).begin (), (x).end ()
#define PI 3.1415926535897932384626433832795
#define fill(x,y) memset (x, y, sizeof (x))

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

#define filename ""

int n;
int m;
int r = 0;
map<int, int> all;
vi g[100000];

vii v, w;
vector<pair<ii, ii> > ans;

map <int, set <ii> > a;

int main () {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	scanf ("%d%d", &n, &m);
	for (int i = 0; i < n; i++) g[i].resize (m);
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++) {
			scanf ("%d", &g[i][j]);
			a[g[i][j]].insert(mp(i, j));
		}
	map <int, set<ii> > :: iterator cur = a.begin();
	for (int i = 0; i < n; i++) {
		int st, d, en;
		st = (i % 2 ? m - 1 : 0);
		d = (i % 2 ? -1 : 1);
		en = (i % 2 ? -1 : m);
		for (int j = st; j != en; j += d) {
			int col = g[i][j];
			ii p = *a[cur->fi].begin();
			ans.pb(mp(mp(i, j), p));
			a[cur->fi].erase(a[cur->fi].begin());
			if (a[cur->fi].size() == 0) cur++;
			a[col].insert(p);
			a[col].erase(mp(i, j));
			g[p.fi][p.se] = col;
		}
	}
	printf("%d\n", ans.size());
	for (int i = 0;i < sz (ans); i++)
		printf ("%d %d %d %d\n", ans[i].fi.fi + 1, ans[i].fi.se + 1, ans[i].se.fi + 1, ans[i].se.se + 1);
	re 0;
}                        