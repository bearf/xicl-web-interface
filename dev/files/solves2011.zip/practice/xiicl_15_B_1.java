import java.util.*;
import java.io.*;

public class Solution {

	void solve() throws IOException {
		String s = nextToken();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < s.length();) {
			int j = i;
			while (j < s.length() && s.charAt(i) == s.charAt(j)) {
				j++;
			}
			sb.append(s.charAt(i));
			if (j - i > 1) {
				sb.append(j - i);
			}
			i = j;
		}
		out.println(sb);
	}

	static final Random rand = new Random("not fatrat".hashCode());
	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	void run() {
		try {
			boolean io = System.getProperty("ONLINE_JUDGE") != null;
			br = new BufferedReader(new FileReader(io ? "input.txt"
					: "B.in".toLowerCase()));
			st = new StringTokenizer("");
			out = new PrintWriter(io ? "output.txt" : "B.out".toLowerCase());
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
