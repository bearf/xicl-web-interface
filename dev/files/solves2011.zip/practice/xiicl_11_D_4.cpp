#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <functional>
#include <numeric>
#include <cmath>
#include <ctime>

using namespace std;

#define sz(x) (int)((x).size ())
#define sqr(x) ((x) * (x))
#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define rep(i,n) for (int i = 0; i < (n); i++)
#define repn(i,n) for (int i = (n) - 1; i >= 0; i--)
#define re return
#define all(x) (x).begin (), (x).end ()
#define PI 3.1415926535897932384626433832795
#define fill(x,y) memset (x, y, sizeof (x))

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<string> vs;

template<class T> T abs (T x) { re x > 0 ? x : -x; }

#define filename ""

int n;
int m;
int r = 0;
map<int, int> all;
vii v[200000], w;
vi g[200000];
vector<pair<ii, ii> > ans;
map<ii, int> pos;

int get (int x) {
	if (all.count (x)) re all[x];
	all[x] = r;
	r++;
	re r - 1;
}

int main () {
	freopen ("input.txt", "rt", stdin);
	freopen ("output.txt", "wt", stdout);

	scanf ("%d%d", &n, &m);
	for (int i = 0; i < n; i++) g[i].resize (m);
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++) {
			int x;
			scanf ("%d", &x);
			x = get (x);
			g[i][j] = x;
			v[x].pb (mp (i, j));
			pos[mp (i, j)] = sz (v[x]) - 1;
		}
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			if (i & 1) w.pb (mp (i, m - j - 1)); else w.pb (mp (i, j));
	int f = 0;
	for (int i = 0; i < r; i++)
		for (int j = 0; j < sz (v[i]); j++) {
			ii x = v[i][j];
			ii y = w[f];
			cerr << x.fi << " " << x.se << " " << y.fi << " " << y.se << endl;
//			if (g[x.fi][x.se] != g[y.fi][y.se]) {
				int k = pos[y];
//				cerr << g[w[f].fi][w[f].se] << " " << sz (v[g[w[f].fi][w[f].se]]) << " " << k << endl;
				ans.pb (mp (x, y));
				pos[x] = k;
				v[g[y.fi][y.se]][k] = x;
				swap (g[x.fi][x.se], g[y.fi][y.se]);
//				cerr << g[w[f].fi][w[f].se] << " " << sz (v[g[w[f].fi][w[f].se]]) << " " << k << endl;
//			}
			f++;
		}

	vector<pair<ii, ii> > zlo;
	rep(i, sz(ans))
	if (ans[i].fi != ans[i].se)
	zlo.pb(ans[i]);	

	ans = zlo;

	printf ("%d\n", sz (ans));	
	for (int i = 0;i < sz (ans); i++)
		printf ("%d %d %d %d\n", ans[i].fi.fi + 1, ans[i].fi.se + 1, ans[i].se.fi + 1, ans[i].se.se + 1);
	re 0;
}