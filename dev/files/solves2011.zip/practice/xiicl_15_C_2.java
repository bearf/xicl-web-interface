import java.util.*;
import java.io.*;

public class Solution implements Runnable {

	int n;
	ArrayList<Integer> e[];
	int[] color;

	void solve() throws IOException {
		n = nextInt();
		e = new ArrayList[n];
		for (int i = 0; i < n; i++) {
			e[i] = new ArrayList<Integer>();
		}
		for (int i = 0; i < n; i++) {
			e[i].add(nextInt() - 1);
			e[i].add(nextInt() - 1);
		}
		color = new int[n];
		Arrays.fill(color, -1);
		for (int i = 0; i < n; i++) {
			if (color[i] == -1) {
				color[i] = 0;
				dfs(i);
			}
		}
		for (int i = 0; i < n; i++) {
			if (color[i] == 0) {
				out.print((i + 1) + " ");
			}
		}
		out.println();
		for (int i = 0; i < n; i++) {
			if (color[i] == 1) {
				out.print((i + 1) + " ");
			}
		}
		out.println();
	}

	void dfs(int u) {
		for (int v : e[u]) {
			if (color[v] == -1) {
				color[v] = color[u] ^ 1;
				dfs(v);
			}
		}
	}

	static final Random rand = new Random("not fatrat".hashCode());
	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	public void run() {
		try {
			boolean io = System.getProperty("ONLINE_JUDGE") != null;
			br = new BufferedReader(new FileReader(io ? "input.txt"
					: "C.in".toLowerCase()));
			st = new StringTokenizer("");
			out = new PrintWriter(io ? "output.txt" : "C.out".toLowerCase());
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	public static void main(String[] args) {
		new Thread(null, new Solution(), "fatrat", 1 << 23).start();
	}
}
