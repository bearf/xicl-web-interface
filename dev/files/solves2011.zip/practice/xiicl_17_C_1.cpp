#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <vector>
#include <string>
#include <map>
#include <set>

#define vv vector
#define mp make_pair
#define pb push_back
#define px first
#define py second
#define in cin
#define out cout

using namespace std;

typedef long long ll;

int n, comp = 0;
vv<int> a[2];
vv<vv<int> > g;
vv<bool> used;
int cur;

void dfs(int v) {
	used[v] = true;
	a[cur].push_back(v + 1);
	cur = 1 - cur;
	for (size_t i = 0; i < g[v].size(); i++) {
		if (!used[g[v][i]]) {
			dfs(g[v][i]);
		}
	}
}

int main() {
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	in >> n;
	g.resize(n);
	cur = 0;
	for (int i = 0; i < n; i++) {
		int x, y;
		in >> x >> y;
		x--, y--;
		g[i].pb(x);
		g[y].pb(i);
	}
	used.assign(n, false);
	for (int i = 0; i < n; i++) {
		if (!used[i]) {
			dfs(i);
		}
	}
	for (size_t i = 0; i < a[0].size(); ++i) {
		out << a[0][i] << ' ';
	}
	out << endl;
	for (size_t i = 0; i < a[1].size(); ++i) {
		out << a[1][i] << ' ';
	}
	out << endl;
	return 0;
}