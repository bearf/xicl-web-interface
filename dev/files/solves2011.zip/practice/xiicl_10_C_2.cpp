#include <stdio.h>
#include <set>
#include <queue>

using namespace std;

struct P
{
	int x, y;
};

P p[20000];

int main()
{
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);

	int N;
	scanf("%d", &N);

	deque<int> deq;
	set<int> S1, S2;

	for(int i=0; i<N; i++)
	{
		int x, y;
		scanf("%d %d", &x, &y);
		p[i].x = x-1;
		p[i].y = y-1;
		deq.push_back(i);
	}
	bool b = true;
	S1.insert(deq.front());
	deq.pop_front();
	int last = 0;
	while(b && !deq.empty())
	{
		int z = deq.front();
		deq.pop_front();
		int k1 = S1.count(p[z].x) + S1.count(p[z].y);
		int k2 = S2.count(p[z].x) + S2.count(p[z].y);
		if(k1 + k2 == 0)
		{
			if(last < deq.size())
			{
				deq.push_back(z);
				last++;
			}
			else
			{
				S1.insert(z);
				last = 0;
			}
		}
		else if(k1==0)
		{
			S1.insert(z);
			last = 0;
		}
		else if(k2==0)
		{
			S2.insert(z);
			last = 0;
		}
		else
		{
			b = false;
		}
	}
	if(b)
	{
		for(set<int>::iterator i=S1.begin(); i!=S1.end(); i++)
			printf("%d ", (*i)+1);
		printf("\n");
		for(set<int>::iterator i=S2.begin(); i!=S2.end(); i++)
			printf("%d ", (*i)+1);
		printf("\n");
	}
	else
		printf("0\n");

	return 0;
}