#include <fstream>
using namespace std;
 ifstream cin("input.txt"); ofstream cout("output.txt"); int main(void) { int a, b; cin >> a >> b; cout << a+b; return 0; }