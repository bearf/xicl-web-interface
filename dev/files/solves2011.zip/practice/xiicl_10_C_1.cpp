#include <stdio.h>
#include <set>

using namespace std;

int main()
{
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);

	int N;
	scanf("%d", &N);

	set<int> S1, S2;

	bool b = true;
	for(int i=1; i<=N; i++)
	{
		int x, y;
		scanf("%d %d", &x, &y);

		if(S1.count(x) == 0 && S1.count(y) == 0)
			S1.insert(i);
		else if(S2.count(x) == 0 && S2.count(y) == 0)
			S2.insert(i);
		else
			b = false;
	}
	if(b)
	{
		for(set<int>::iterator i=S1.begin(); i!=S1.end(); i++)
			printf("%d ", *i);
		printf("\n");
		for(set<int>::iterator i=S2.begin(); i!=S2.end(); i++)
			printf("%d ", *i);
		printf("\n");
	}
	else
		printf("0\n");

	return 0;
}