#include <fstream>
using namespace std;

int main()
{
	ifstream in("input.txt");
	ofstream out("output.txt");
	
	char last;
	in >> last;
	int nn = 1;
	
	char cur;
	while(in >> cur)
	{
		if (cur != last)
		{
			out << last << nn;
			nn = 1;
			last = cur;
		}
		else
			++nn;
	}
	
	out << last << nn;
		
	return 0;
}