#include <iostream>
#include <vector>
#include <cstring>
#include <map>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define sz(s) (int((s).size()))

typedef pair<int, int> pt;
#define X first
#define Y second

int n, m;
vector< vector<int> > a;
map<int, vector<pt> > mp;

void getNext(pt& a){
    if(a.X & 1)
        a.Y--;
    else
        a.Y++;

    if(a.Y < 0){
        a.X++;
        a.Y = 0;
    } 
    if(a.Y >= m){
        a.X++;
        a.Y = m - 1;
    }       
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> n >> m;
    a.resize(n);

    forn(i, n){
        a[i].resize(m);

        forn(j, m){
            scanf("%d", &a[i][j]);
            mp[a[i][j]].push_back(pt(i, j));
        }
    }

    vector< pair<pt, pt> > ans;
    pt cur(0, 0);

    for(map<int, vector<pt> >::iterator it = mp.begin(); it != mp.end(); ++it){
        vector<pt>& b = it->second;

        forn(i, sz(b)){
            ans.push_back(make_pair(cur, b[i]));
            getNext(cur);
        }
    }


    cout << sz(ans) << endl;

    forn(i, sz(ans))
        cout << ans[i].X.X + 1 << " " << ans[i].X.Y + 1 << " " << ans[i].Y.X + 1 << " " << ans[i].Y.Y + 1 << endl;

    return 0;
}