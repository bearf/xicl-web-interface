#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <sstream>

using namespace std;

#define sz(s) (int((s).size()))

string s, z;

string getString(int a){
    stringstream v;
    v << a;
    string res;
    v >> res;
    return res;
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> s;
    z = "";

    for(int i = 0; i < sz(s);){
        int j = i;
        while(j < sz(s) && s[i] == s[j])
            ++j;

        z.push_back(s[i]);
        if(j - i > 1)
            z += getString(j - i);

        i = j;
    }

    cout << z << endl;


    return 0;
}