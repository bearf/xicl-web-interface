import java.util.*;
import java.io.*;

public class Solution {

	void solve() throws IOException {
		out.println(nextLong() + nextLong());
	}

	static final Random rand = new Random("not fatrat".hashCode());
	BufferedReader br;
	StringTokenizer st;
	PrintWriter out;
	boolean eof;

	void run() {
		try {
			boolean io = System.getProperty("ONLINE_JUDGE") != null;
			br = new BufferedReader(new FileReader(io ? "input.txt"
					: "A.in".toLowerCase()));
			st = new StringTokenizer("");
			out = new PrintWriter(io ? "output.txt" : "A.out".toLowerCase());
			solve();
			br.close();
			out.close();
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(239);
		}
	}

	String nextToken() throws IOException {
		while (!st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) {
				eof = true;
				s = "0";
			}
			st = new StringTokenizer(s);
		}
		return st.nextToken();
	}

	int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	public static void main(String[] args) {
		new Solution().run();
	}
}
