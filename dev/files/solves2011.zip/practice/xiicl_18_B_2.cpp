#include <iostream>
#include <fstream>
#include <string>
using namespace std;
ifstream in("input.txt");
ofstream out("output.txt");
int main()
{
	string s;
	in>>s;
	char lc=s[0];
	int cnt=1, pos=1;
	if(s.size()==1)
		out<<s;
	else while(pos<s.size())
	{
		while(pos<s.size() && lc == s[pos]) pos++, cnt++;
		if(cnt==1)
			out<<lc;
		else
			out<<lc<<cnt;
		lc=s[pos];
		cnt=0;
	}
	return 0;
}
