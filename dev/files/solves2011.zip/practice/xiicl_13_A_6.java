import java.util.*;
import java.io.*;
import java.math.*;

public class Solution {
	public static void main(String[] args) throws Exception{
		new Solution().run();
	}
	
	long a[] = new long[10000000];
	final int MAGIC = (100000*2000)/4;
	
	void run() throws Exception{
		Scanner scan = new Scanner(new File("input.txt"));
		PrintWriter out = new PrintWriter(new File("output.txt"));
		BigInteger a = scan.nextBigInteger(), b = scan.nextBigInteger();
		out.print(a.add(b));
		
		long startTime = System.currentTimeMillis();
		
		for(int i = 0; i < MAGIC; ++i){
			a = a.add(b);
		}
		
		System.err.println(System.currentTimeMillis() - startTime);
		
		out.close();
		scan.close();
	}
}
