#include <iostream>
#include <fstream>
using namespace std;
ifstream in("input.txt");
ofstream out("output.txt");
#define long long long
int main()
{
	long a,b;
	in>>a>>b;
	out<<a+b<<endl;
	return 0;
}
