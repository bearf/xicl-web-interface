import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Solution {

	/**
	 * @param args
	 * @throws Exception
	 */
	static int color[];
	static boolean g[][];

	public static void main(String[] args) throws Exception {
		Scanner in = new Scanner(new FileReader("input.txt"));
		int n = in.nextInt();
		color = new int[n];
		Arrays.fill(color, -1);
		g = new boolean[n][n];
		for (int i = 0; i < n; ++i) {
			int tmp = in.nextInt();
			g[i][tmp - 1] = true;
			tmp = in.nextInt();
			g[i][tmp - 1] = true;
		}

		for (int i = 0; i < n; ++i)
			if (color[i] == -1)
				bfs(i);

		PrintWriter out = new PrintWriter("output.txt");

		HashSet<Integer> a1 = new HashSet<Integer>();
		HashSet<Integer> a2 = new HashSet<Integer>();
		for (int i = 0; i < n; ++i)
			if (color[i] == 1)
				a1.add(i + 1);
			else
				a2.add(i + 1);

		for (int i : a1)
			out.print(i + " ");
		out.println();
		for (int i : a2)
			out.print(i + " ");
		out.close();
	}

	private static void bfs(int st) {
		color[st] = 1;
		Queue<Integer> q = new LinkedList<Integer>();
		q.add(st);
		while (!q.isEmpty()) {
			int curr = q.poll();
			for (int j = 0; j < g[curr].length; ++j)
				if (g[curr][j] && color[j] == -1) {
					color[j] = not(color[curr]);
					q.add(j);
				}
		}
	}

	private static int not(int i) {
		if(i == 0)
			return 1;
		return 0;
	}
}
