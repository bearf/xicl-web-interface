#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define F first
#define S second

// -- MAIN PART

set<pair<int, int> > se;
set<pair<int, int> >::iterator it, it2;


set<pair<int, int> >::iterator get(int x) {
	set<pair<int, int> >::iterator q = se.lower_bound(mp(x, (int) 1e9 + 5));

	if (q != se.begin()) {
		q--;
		if ((q -> F) <= x && x <= (q -> S)) return q;
		q++;
	}
	return q;
}

int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	int n;
	cin >> n;
	se.insert(mp(0, (int)1e9 + 1));

	while (n--) {
		int x, p;
		scanf("%d", &x);
		if (x > 0) {
			scanf("%d", &p);

			it = get(x);

			int a = it -> F;
			int b = it -> S;

			int st = max(x, a);

			p = min(p, b - st + 1);

			printf("%d %d\n", st, st + p - 1);

			se.erase(it);

			if (a < st) se.insert(mp(a, st - 1));
			if (st + p <= b) se.insert(mp(st + p, b));
		} else {
			x = -x;
			it = get(x);
			if ((it -> F) <= x && x <= (it -> S)) continue;

			se.insert(mp(x, x));

			it = get(x);

			if (it != se.begin()) {
				it2 = it;
				it2--;
				if ((it2 -> S) + 1 == (it -> F)) {
					int a = it2 -> F;
					int b = it -> S;
					se.erase(it);
					se.erase(it2);
					se.insert(mp(a, b));
				}
			}
			it = get(x);
			it2 = it;
			it2++;
			if (it2 != se.end()) {
				if ((it -> S) + 1 == (it2 -> F)) {
					int a = it -> F;
					int b = it2 -> S;
					se.erase(it);
					se.erase(it2);
					se.insert(mp(a, b));
				}
			}
		}
	}


	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
