#include <bits/stdc++.h>
using namespace std;


typedef pair<int, int> pii;

set<pii> in;
int n;

void brisi(int x) {
    set<pii>::iterator it = in.upper_bound(make_pair(x, 500000005));
    if (in.empty())
        return;
    if (it == in.begin())
        return;

    --it;

    if (it->second < x)
        return;

    int b = it->first, e = it->second;
    in.erase(it);
    if (x > b)
        in.insert(make_pair(b, x - 1));
    if (x < e)
        in.insert(make_pair(x + 1, e));

}

void boji(int x, int len) {
    set<pii>::iterator it = in.upper_bound(make_pair(x, 500000005));

    if (in.empty()) {
        in.insert(make_pair(x, x + len - 1));
        printf("%d %d\n", x, x + len - 1);
        return;
    }
    if (it == in.begin()) {
        int e = it->first - 1;
        e = min(e, x + len - 1);
        in.insert(make_pair(x, e));
        printf("%d %d\n", x, e);
        return;
    }

    --it;
    if (it->second < x) {
        ++it;
        int e = it->first - 1;
        e = min(e, x + len - 1);
        in.insert(make_pair(x, e));
        printf("%d %d\n", x, e);
        return;
    }

    int b = it->second + 1;
    ++it;
    while (it != in.end() && !(b < it->first)) {
        b = it->second + 1;
        ++it;
    }

    int e = b + len - 1;
    if (it != in.end())
        e = min(e, it->first - 1);
    in.insert(make_pair(b, e));
    printf("%d %d\n", b, e);
}

int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; ++i) {
        int x, p;
        scanf("%d", &x);

        if (x < 0) {
            brisi(-x);
        } else {
            scanf("%d", &p);
            boji(x, p);
        }
    }
    return 0;
}
