#define _CRT_SECURE_NO_WARNINGS
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <ctime>
#include <string>

using namespace std;

void solution();

int main()
{
	ios_base::sync_with_stdio(false);
#ifdef HOME
	freopen("input.txt", "rt", stdin);
	clock_t start = clock();
#endif
	solution();
#ifdef HOME
	cerr.precision(3);
	cerr << endl << "Total time: " << fixed << double(clock() - start) / double(CLOCKS_PER_SEC) << endl;
#endif
	return 0;
}

typedef long long ll;
#define int ll

int gcd(int a, int b)
{
	while (b)
		swap(b, a %= b);
	return a;
}

int lcm(int x, int y)
{
	return x * y / gcd(x, y);
}


#define pow powpow
#define MOD 1000000009ll
#define N 200000
#define MP(x, y) make_pair(x, y)
bool pr[N + 1];
int k, d, m;
int p[N], pc = 0, c[N];

int dp[64][64], e[64][64];

int pow(int a, int n)
{
	if (n == 0)
		return 1;
	else if (n == 1)
		return a;
	if (n % 2 == 0)
	{
		int res = pow(a, n / 2);
		return (res * res) % MOD;
	}
	else
	{
		return (a * pow(a, n - 1)) % MOD;
	}
}

int cnk(int n, int k)
{
	if (k == 0)
		return 1;
	if (k == n)
		return 1;
	return ((n * cnk(n - 1, k - 1)) % MOD * pow(k, MOD - 2)) % MOD;
}

int f(int c, int k)
{
	if (c == k)
		return 1;
	if (e[c][k])
		return dp[c][k];
	int res = 0;
	for (int i = 1; i <= c - k; ++i)
	{
		res += cnk(k, i) * f(c - k, i);
		res %= MOD;
	}
	dp[c][k] = res;
	e[c][k] = 1;
	return res;
}

int solve(int c, int k)
{
	int res = 0;
	for (int i = 1; i <= min(c, k); ++i)
	{
		res += cnk(k, i) * f(c, i);
		res %= MOD;
	}
	return res;
}

void solution()
{
	for (int i = 2; i <= N; ++i)
		pr[i] = true;
	for (int i = 2; i <= N; ++i)
		if (pr[i])
			for (int j = i + i; j <= N; j += i)
				pr[j] = false;
	for (int i = 2; i <= N; ++i)
		if (pr[i])
			p[pc++] = i;
	for (; cin >> k >> d >> m;)
	{
		if (m % d != 0)
		{
			cout << 0 << endl;
			continue;
		}
		int u = m / d;
		for (int i = 0; i < N; ++i)
			c[i] = 0;
		for (int i = 0; i < pc; ++i)
			while (u % p[i] == 0)
			{
				++c[i];
				u /= p[i];
			}
		ll ans = 1;
		for (int i = 0; i < pc; ++i)
		{
			if (!c[i]) continue;
			int s = pow(c[i] + 1, k) - (2ll * pow(c[i], k)) % MOD;
			if (s < 0)
				s += MOD;
			s = (s + pow(c[i] - 1, k)) % MOD;
			ans *= s;
			ans %= MOD;
		}
		cout << ans << endl;
	}
}
