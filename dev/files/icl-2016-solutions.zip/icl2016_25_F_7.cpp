#include <cstdio>
#include <algorithm>
#include <iostream>
#include <set>
#include <map>
#include <vector>
#include <cstring>
#include <string>
#include <cmath>

#pragma warning (disable : 4996)

#define put push_back
#define mapa make_pair

using namespace std;


long long gcd(long long a, long long b) {
	while (a > 0 && b > 0) {
		if (a < b) {
			swap(a, b);
		}
		a = a % b;
	}
	return a + b;
}

long long x, a, b;

map < long long, long long > u1, u2;

map < long long, bool > p;

long long mod = 1000000009;

long long pow(long long x, long long y, long long mod) {
	if (y == 0)
		return 1;
	if (y == 1)
		return x;
	if (y % 2 == 1)
		return (x * pow(x * x, (y - 1) / 2) , mod) % mod;
	else
		return pow(x * x, y / 2 , mod) % mod;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
#ifndef _DEBUG
	//freopen("kek.in", "r", stdin);
	//freopen("kek.out", "w", stdout);
#endif
	cin >> x;
	cin >> a >> b;

	long long A, B;
	A = a;
	B = b;

	for (long long i = 2; i * i <= a; i++) {
		while (A % i == 0) {
			A /= i;
			u1[i]++;
		}
	}
	if (A != 1)
		u1[A]++;

	for (long long i = 2; i * i <= b; i++) {
		while (B % i == 0) {
			B /= i;
			u2[i]++;
		}
	}
	if (B != 1)
		u2[B]++;

	for (auto i = u2.begin(); i != u2.end(); i++) {
		if (u1[i->first] == 0)
			u1[i->first] = 0;
	}

	long long ans = 1;
	for (auto i = u1.begin(); i != u1.end(); i++) {
		long long o = u2[i->first] - i->second;
		if (o < 0) { 
			cout << 0;
			return 0;
		}
		if (o == 0)
			continue;
		ans *= (((pow(o, x - 2, mod) * x) % mod) * (x - 1)) % mod;
	}

	cout << ans % mod;

	return 0;
}