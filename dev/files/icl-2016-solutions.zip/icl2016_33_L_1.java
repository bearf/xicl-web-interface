import java.io.*;
import java.util.*;
import java.math.*;

public class L {
	public static void main(String[] args) {
		new L().run();
	}

	Scanner in;
	PrintWriter out;

	void run() {
		in = new Scanner(System.in);
		out = new PrintWriter(System.out);
		solve();
		out.flush();
	}

	boolean flag = false;

	void solve() {
		int a = in.nextInt();
		int b = in.nextInt();
		int c = in.nextInt();
		int d = in.nextInt();

		if (a == b) {
			if (c != d) {
				out.println(0);
				return;
			}

			List<Integer> res = new ArrayList<>();

			while (a != 1) {
				if (a % 2 == 1) {
					res.add(1);
					res.add(a);
					a++;
				} else {
					res.add(2);
					res.add(a);
					a /= 2;
				}
			}

			while (a < c) {
				res.add(1);
				res.add(a);
				a++;
			}

			out.println(res.size() / 2);

			for (int i = 0; i < res.size(); i += 2) {
				out.println(res.get(i) + " " + res.get(i + 1) + " " + res.get(i + 1));
			}

			return;
		}

		if (a > b) {
			flag = true;
			int tmp = a;
			a = b;
			b = tmp;

			tmp = c;
			c = d;
			d = tmp;
		}

		if (c >= d) {
			out.println(0);
			return;
		}

		int diff = b - a;
		while (diff % 2 == 0) {
			diff /= 2;
		}

		if ((d - c) % diff != 0) {
			out.println(0);
			return;
		}

		List<int[]> res = new ArrayList<>();

		while ((b - a) % 2 == 0) {
			if (a % 2 == 1) {
				res.add(new int[] { 1, a, b });
				a++;
				b++;
			} else {
				res.add(new int[] { 2, a, b });
				a /= 2;
				b /= 2;
			}
		}

		while (a != 1) {
			if (a % 2 == 1) {
				res.add(new int[] { 1, a, b });
				a++;
				b++;
				continue;
			}

			int initA = a;
			int initB = b;
			while (a != initB) {
				res.add(new int[] { 1, a, b });
				a++;
				b++;
			}

			res.add(new int[] { 3, initA, initB, a, b });
			res.add(new int[] { 2, initA, b });

			a = initA / 2;
			b = b / 2;
		}

		while (b != d) {
			res.add(new int[] { 1, a, b });
			a++;
			b++;
		}

		int q = c + diff;

		while (q != d) {
			res.add(new int[] { 3, c, q, q, q + diff });
			q += diff;
		}

		out.println(res.size());
		for (int[] x : res) {
			out.print(x[0] + " ");
			if (x[0] < 3) {
				if (flag) {
					out.println(x[2] + " " + x[1]);
				} else {
					out.println(x[1] + " " + x[2]);
				}
			} else {
				if (flag) {
					out.println(x[4] + " " + x[3] + " " + x[2] + " " + x[1]);
				} else {
					out.println(x[1] + " " + x[2] + " " + x[3] + " " + x[4]);
				}
			}
		}

		if (res.size() > 15000) {
			while (true)
				;
		}
	}
}