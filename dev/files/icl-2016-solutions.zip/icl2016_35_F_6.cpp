#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;

int main()
{
    long long k, a, b;
    cin >> k >> a >> b;
    if (b % a != 0)
    {
        cout << 0;
        return 0;
    }
    long long c = b / a;
    long long ans_new = 0;
    for (int i = 1; i <= (int)c / 2 + 1; i++)
    {
        if (c % i == 0)
            ans_new ++;
    }
    ans_new += 1;
    //cout << ans_new << endl;
    long long ans_very_new = 1;
    int fl = 0;
    k--;
    if (ans_new - k + 1 >= 1)
    for (long long i = ans_new - k + 1; i <= ans_new; i++)
    {
        fl = 1;
        if (ans_very_new == 0) break;
        ans_very_new = (ans_very_new * i) % (int)(1e9 + 9);
    }
    //ans_very_new *= fl;
    if (ans_new - k + 1 >= 1)
    for (long long i = 1; i <= k; i++)
    {
        if (ans_very_new == 0) break;
        ans_very_new = (ans_very_new / i) % (int)(1e9 + 9);
    }
    cout << ans_very_new;
    //cin  >> k;
    return 0;
}
