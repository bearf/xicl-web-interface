#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

ll a[10], b[10];

ll gcd(ll x, ll y)
{
	return y == 0 ? x : gcd(y, x % y);
}

ll lcm(ll x, ll y)
{
	return x / gcd(x, y) * y;
}


int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		cin >> a[i] >> b[i];
	}
	ll A = a[0], B = b[0];
	for (int i = 1; i < n; i++)
	{
		A = lcm(A, a[i]);
		B = gcd(B, b[i]);
	}
	cout << A << " " << B << endl;

	return 0;
}