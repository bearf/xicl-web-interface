#define _CRT_SECURE_NO_WARNINGS
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <ctime>
#include <string>

using namespace std;

void solution();

int main()
{
	ios_base::sync_with_stdio(false);
#ifdef HOME
	freopen("input.txt", "rt", stdin);
	clock_t start = clock();
#endif
	solution();
#ifdef HOME
	cerr.precision(3);
	cerr << endl << "Total time: " << fixed << double(clock() - start) / double(CLOCKS_PER_SEC) << endl;
#endif
	return 0;
}

typedef long long ll;
//#define int ll

int gcd(int a, int b)
{
	while (b)
		swap(b, a %= b);
	return a;
}

int lcm(int x, int y)
{
	return x * y / gcd(x, y);
}


#define pow powpow
#define MOD 1000000009ll
#define MP(x, y) make_pair(x, y)

int pow(int a, int n)
{
	if (n == 0)
		return 1;
	else if (n == 1)
		return a;
	if (n % 2 == 0)
	{
		int res = pow(a, n / 2);
		return (res * res) % MOD;
	}
	else
	{
		return (a * pow(a, n - 1)) % MOD;
	}
}

int cnk(int n, int k)
{
	if (k == 0)
		return 1;
	if (k == n)
		return 1;
	return ((n * cnk(n - 1, k - 1)) % MOD * pow(k, MOD - 2)) % MOD;
}

#define N 100000
int n, t;
int x[N][4], xc = 0, e[N], p[4];

void solution()
{
	scanf("%d", &n);
	for (int i = 0; i < n; ++i)
	{
		scanf("%d", &t);
		scanf("%d%d%d%d", &p[0], &p[1], &p[2], &p[3]);
		if (t == 1)
		{
			for (int j = 0; j < 4; ++j)
				x[xc][j] = p[j];
			e[xc] = 1;
			++xc;
		}
		else if (t == 2)
		{
			for (int j = 0; j < xc; ++j)
			{
				bool fnd = true;
				for (int k = 0; k < 4; ++k)
					if (p[k] != x[j][k])
						fnd = false;
				if (fnd)
				{
					e[j] = 0;
					break;
				}
			}
		}
		else
		{
			int ans = 0;
			for (int j = 0; j < xc; ++j)
				ans = max(ans, abs(p[0] - x[j][0]) + abs(p[1] - x[j][1]) + abs(p[2] - x[j][2]) + abs(p[3] - x[j][3])) * e[j];
			printf("%d\n", ans);
		}
	}

}
