/*
ICL 2016
Team: Mathematical Grammar School, Belgrade
*/
#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MOD=1000000009ll;
ll fastpow(ll a,ll b,ll mod)
{
    if(b==0) return 1;
    ll poww=fastpow(a,b/2,mod);
    poww*=poww;
    poww%=mod;
    if(b&1) poww*=a;
    poww%=mod;
    return poww;
}
vector<pair<int,int> >factorize(int k)
{
    vector<pair<int,int> >ret;
    int sqrtk=(int)sqrt(k);
    for(int i=2;i<=sqrtk+1;i++)
    {
        int cnt=0;
        while(k%i==0)
        {
            cnt++;
            k/=i;
        }
        if(cnt>0) ret.push_back(make_pair(i,cnt));
    }
    if(k>1) ret.push_back(make_pair(k,1));
    return ret;
}
int main() {

    ll k;
    int lcm,gcd;
    scanf("%lld%d%d",&k,&gcd,&lcm);
    if(lcm%gcd!=0) {puts("0\n");return 0;}
    int s=lcm/gcd;
  //  printf("%d\n",s);
    vector<pair<int,int> > f=factorize(s);
    ll sol=1;
    for(int i=0;i<f.size();i++)
    {
        ll brojputa=f[i].second;
        ll svi=fastpow(brojputa+1,k,MOD);
        ll bezminmax=fastpow(brojputa,k-1,MOD);
        if(k<1) bezminmax=0;
        ll bezminmaxx=fastpow(brojputa-1,k-2,MOD);
        if(brojputa==1) bezminmaxx=0;
        if(k<2) bezminmaxx=0;
        sol*=svi-2*bezminmax+bezminmaxx;
        //ll cur=svi-2*bezminmax+bezminmaxx;
        //printf("%lld\n",cur);
        sol%=MOD;
        sol+=MOD*MOD;
        sol%=MOD;
    }
    printf("%lld\n",sol);
    return 0;

}
