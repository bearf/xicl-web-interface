#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <map>

#pragma warning(disable:4996)

using namespace std;

#define x1 first
#define y1 second
#define mp make_pair
#define pb push_back
#define For(i,n) for(int i=0;i<(n);++i)
#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define all(v) (v).bagin(),(v).end()

typedef long long ll;

int n,m[10007];

void solve() {
	int i, j,x;
	for (i = 0; i < 10007; i++)m[i] = 0;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d", &x);
		m[x]++;
	}
	int mx = 0;
	for (i = 0; i < 10007; i++) {
		mx = max(mx, m[i]);
	}
	printf("%d", mx);
}

int main() {
#pragma comment(linker,"/STACK:268435456")
#ifdef _DEBUG
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#endif
	solve();
	return 0;
}