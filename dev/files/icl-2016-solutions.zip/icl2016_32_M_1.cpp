#include <bits/stdc++.h>

#define fr first
#define sc second
#define all(x) x.begin(), x.end()
#define int long long

using namespace std;

const int MAXN = 1e5;

main()
{
    int n;
    cin >> n;
    int a[6], b[6], aa[6];
    int db = b[0], da = a[0];
    for (int i = 0; i < n; i++) {
        cin >> a[i] >> b[i];
        aa[i] = a[i];
        db = __gcd(db, b[i]), da = __gcd(da, a[i]);
    }
    int kb = b[0], ka = a[0];
    for (int i = 1; i < n; i++) {
        kb *= (b[i] / db);
        ka *= (a[i] / da);
    }
//    int k[6];
//    for (int i = 0; i < n; i++) {
//        a[i] *= kb / b[i];
//    }
//    for (int i = 0; i < n; i++) {
//        k[i] = ka / a[i];
//    }
//    int sa = 0, sb = 0;
//    for (int i = 0; i < n; i++) {
//        sa += b[i];
//        sb += aa[i] * k[i];
//    }
    //cout << sb << " " << sa << endl;
    cout << ka << " " << db;
}
