#define _CRT_SECURE_NO_WARNINGS
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <ctime>
#include <string>

using namespace std;

void solution();

int main()
{
	ios_base::sync_with_stdio(false);
#ifdef HOME
	freopen("input.txt", "rt", stdin);
	clock_t start = clock();
#endif
	solution();
#ifdef HOME
	cerr.precision(3);
	cerr << endl << "Total time: " << fixed << double(clock() - start) / double(CLOCKS_PER_SEC) << endl;
#endif
	return 0;
}

void solution()
{
	int n;
	cin >> n;
	vector<int> a(n), e(n);
	for (int i = 0; i < n; ++i)
		cin >> a[i];
	sort(a.rbegin(), a.rend());
	int cnt = 0;
	while (true)
	{
		int prev = -1;
		for (int i = 0; i < n; ++i)
			if (!e[i])
			{
				prev = i;
				break;
			}
		if (prev == -1)
			break;
		e[prev] = 1;
		for (int i = prev + 1; i < n; ++i)
		{
			if (!e[i] && a[prev] > a[i])
			{
				prev = i;
				e[i] = 1;
			}
		}
		++cnt;
	}

	cout << cnt << endl;
}