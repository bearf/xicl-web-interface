#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

const int maxn = 6;
int n;
int a[maxn], b[maxn];

long long gcd(long long a, long long b) {
  for (; b; a %= b, swap(a, b)) ;
  return a;
}

int read() {
  if (scanf("%d", &n) < 1) {
    return 0;
  }
  for (int i = 0; i < n; ++i) {
    scanf("%d%d", a + i, b + i);
    int d = gcd(a[i], b[i]);
    a[i] /= d, b[i] /= d;
  }
  return 1;
}

void solve() {
  long long x = 1;
  for (int i = 0; i < n; ++i) {
    x = x * a[i] / gcd(x, a[i]);
  }
  long long y = 0;
  for (int i = 0; i < n; ++i) {
    y = gcd(y, b[i] / gcd(b[i], x / a[i]));
  }
  printf("%I64d %I64d\n", x, y);
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
