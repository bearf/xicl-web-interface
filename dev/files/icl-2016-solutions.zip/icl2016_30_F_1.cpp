#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#define ull long long
# define uull unsigned long long
using namespace std;

ull gcd(ull a, ull b) {
	while (b) {
		a %= b;
		swap(a, b);
	}
	return a;
}

ull nok(ull a, ull b) {
	return a / gcd(a, b)*b;
}


int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ull k, d, m;
	cin >> k >> d >> m;
	if (d == m) {
		cout << 1;
		return 0;
	}
	ull q = gcd(d, m);
	ull r = 0;
	if (q == d)
		r++;
	if (k != 1) {
		ull step = 2;
		while (m % (k*step) == 0) {
			if (gcd(m / (step*k), d*step*k) == d) {
				r++;
			}
			step++;
		}
	}
	cout << r * k;
	return 0;
}