#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <bitset>
#include <complex>
using namespace std;

typedef long double ldouble;

ldouble read_ld()
{
	double x;
	scanf("%lf", &x);
	return x;
}

const ldouble EPS = 1e-7;
const ldouble PI = acosl(-1);
const int MAGIC = 100;

bool eq(ldouble a, ldouble b)
{
	return abs(a - b) < EPS;
}

bool ls(ldouble a, ldouble b)
{
	return a < b && !eq(a, b);
}

bool ls_eq(ldouble a, ldouble b)
{
	return a < b || eq(a, b);
}

bool gr(ldouble a, ldouble b)
{
	return a > b && !eq(a, b);
}

ldouble my_sqrt(ldouble a)
{
	if (ls(a, 0))
		throw;
	if (a < 0)
		a = 0;
	return sqrtl(a);
}

struct Point
{
	ldouble x, y;

	Point() : x(), y() {}

	Point(ldouble _x, ldouble _y) : x(_x), y(_y) {}

	Point operator+(Point p)
	{
		return Point(x + p.x, y + p.y);
	}

	Point operator-(Point p)
	{
		return Point(x - p.x, y - p.y);
	}

	Point operator*(ldouble k)
	{
		return Point(x * k, y * k);
	}

	Point operator/(ldouble k)
	{
		return Point(x / k, y / k);
	}

	ldouble operator%(Point p)
	{
		return x * p.x + y * p.y;
	}

	ldouble operator*(Point p)
	{
		return x * p.y - y * p.x;
	}

	ldouble length()
	{
		return my_sqrt(*this % *this);
	}

	ldouble length2()
	{
		return *this % *this;
	}

	ldouble dist_to(Point p)
	{
		return (*this - p).length();
	}

	Point height(Point A, Point B)
	{
		Point C = *this;
		ldouble coef = (B - A) % (C - A) / (B - A).length2();
		return A + (B - A) * coef;
	}

	Point ort()
	{
		return Point(-y, x);
	}

	Point rotate(ldouble cosa, ldouble sina)
	{
		return *this * cosa + ort() * sina;
	}

	Point rotate(ldouble angle)
	{
		return rotate(cos(angle), sin(angle));
	}

	ldouble get_angle_with(Point p)
	{
		ldouble angle = atan2l(*this * p, *this % p);
		if (angle < 0)
			angle += 2 * PI;
		return angle;
	}

	ldouble get_std_angle()
	{
		return Point(1, 0).get_angle_with(*this);
	}

	bool on_segment(Point A, Point B)
	{
		ldouble mul = (A - *this) % (B - *this);
		return ls_eq(mul, 0);
	}

	ldouble dist_to_seg(Point A, Point B)
	{
		Point O = *this;
		Point H = O.height(A, B);
		if (H.on_segment(A, B))
			return O.dist_to(H);
		return min(O.dist_to(A), O.dist_to(B));
	}

	Point with_length(ldouble k)
	{
		ldouble len = length();
		if (eq(len, 0))
		{
			if (eq(k, 0))
				return Point();
			throw;
		}
		return *this / len * k;
	}

	void scan()
	{
		x = read_ld();
		y = read_ld();
	}
};

void get_tangent(Point A, Point O, ldouble r, Point &P1, Point &P2)
{
	ldouble d = A.dist_to(O);
	ldouble sina = r / d;
	ldouble cosa = my_sqrt(1 - sina * sina);
	ldouble len = my_sqrt(d * d - r * r);
	Point v = (O - A).with_length(len);
	P1 = A + v.rotate(cosa, sina);
	P2 = A + v.rotate(cosa, -sina);
}

ldouble get_circle_dist(Point A, Point B, Point O, ldouble r)
{
	ldouble x = (A - O).get_std_angle();
	ldouble y = (B - O).get_std_angle();
	ldouble angle = min(abs(x - y), 2 * PI - abs(x - y));
	return angle * r;
}

Point A, B, O;
Point C;
ldouble r;

void solve1()
{
	Point P1, P2;
	get_tangent(A, O, r, P1, P2);
	vector<Point> pts_a = { P1, P2 };
	get_tangent(B, O, r, P1, P2);
	vector<Point> pts_b = { P1, P2 };

	ldouble best = 1e20;
	for (Point P : pts_a)
		for (Point Q : pts_b)
		{
			ldouble cur = A.dist_to(P) + get_circle_dist(P, Q, O, r) + Q.dist_to(B);
			best = min(best, cur);
		}

	printf("%.10lf\n", (double)best);
}

ldouble eval_result(ldouble coef1, ldouble coef2)
{
	Point P = C + (A - C) * coef1 + (B - C) * coef2;
	return A.dist_to(P) + B.dist_to(P) + C.dist_to(P);
}

ldouble eval_deeper(ldouble coef1)
{
	ldouble l = 0, r = 1;
	for (int i = 0; i < MAGIC; i++)
	{
		ldouble m1 = l + (r - l) / 3;
		ldouble m2 = r - (r - l) / 3;
		if (eval_result(coef1, m1) < eval_result(coef1, m2))
			r = m2;
		else
			l = m1;
	}
	return eval_result(coef1, (l + r) / 2);
}

ldouble eval(ldouble angle)
{
	C = O + Point(r, 0).rotate(angle);
	ldouble l = 0, r = 1;
	for (int i = 0; i < MAGIC; i++)
	{
		ldouble m1 = l + (r - l) / 3;
		ldouble m2 = r - (r - l) / 3;
		if (eval_deeper(m1) < eval_deeper(m2))
			r = m2;
		else
			l = m1;
	}
	return eval_deeper((l + r) / 2);
}

pair<ldouble, ldouble> get_seg(Point P, int type)
{
	Point P1, P2;
	get_tangent(P, O, r, P1, P2);
	ldouble angle1 = (P1 - O).get_std_angle();
	ldouble angle2 = (P2 - O).get_std_angle();
	if (angle1 > angle2)
	{
		if (type == 0)
			angle1 = 0;
		else
			angle2 = 2 * PI;
	}
	return make_pair(angle1, angle2);
}

pair<ldouble, ldouble> inter_seg(pair<ldouble, ldouble> a, pair<ldouble, ldouble> b)
{
	return make_pair(max(a.first, b.first), min(a.second, b.second));
}

ldouble solve2(ldouble l, ldouble r, int type)
{
	pair<ldouble, ldouble> seg(l, r);
	pair<ldouble, ldouble> seg_a = get_seg(A, type);
	pair<ldouble, ldouble> seg_b = get_seg(B, type);
	seg = inter_seg(seg, inter_seg(seg_a, seg_b));

	if (seg.first > seg.second)
		return 1e20;

	l = seg.first;
	r = seg.second;
	for (int it = 0; it < MAGIC; it++)
	{
		ldouble m1 = l + (r - l) / 3;
		ldouble m2 = r - (r - l) / 3;
		if (eval(m1) < eval(m2))
			r = m2;
		else
			l = m1;
	}

	return eval((l + r) / 2);
}

void solve2()
{
	ldouble res = min(solve2(0, PI, 0), solve2(PI, 2 * PI, 1));
	printf("%.10lf\n", (double)res);
}

void solve()
{
	A.scan();
	B.scan();
	O.scan();
	r = read_ld();

	ldouble dist = O.dist_to_seg(A, B);
	if (ls(dist, r))
		solve1();
	else
		solve2();
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	solve();

	return 0;
}