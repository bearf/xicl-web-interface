#define _CRT_SECURE_NO_WARNINGS

#include <vector>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

char a[20];
char s[20];
char p[20];
int n;
double ans = 1;

double solve(char* s, char c1, char c2)
{
	int x = 0, y = 0;
	for (int i = 0; i < 6; i++)
	{
		if (s[i] != c1) continue;
		y += 2;
		if (s[i] == c2 || s[i ^ 1] == c2)
		{
			x += 2;
			continue;
		}
		for (int z = 0; z < 6; z += 2)
		{
			if (z == i || z == (i ^ 1)) continue;
			if (s[z] == c2 || s[z ^ 1] == c2)
				x++;
		}
	}
	if (y == 0) throw;
	return (double)x / (double)y;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	scanf("%s", s);
	scanf("%s", p);
	n = strlen(s);
	for (int i = 0; i < n; i++)
	{
		scanf("%s", a);
		swap(a[1], a[5]);
		swap(a[3], a[4]);
		ans *= solve(a, s[i], p[i]);
	}
	printf("%.12lf\n", ans);

	return 0;
}