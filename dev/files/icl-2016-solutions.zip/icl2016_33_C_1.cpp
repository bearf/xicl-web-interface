#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <bitset>
#include <complex>
using namespace std;

const int N = 15;
const int ORB[6][2][4] =
{
	{{0, 1, 2, 3}, {0, 1, 4, 5}},
	{{0, 1, 2, 3}, {0, 1, 4, 5}},
	{{0, 1, 2, 3}, {2, 3, 4, 5}},
	{{0, 1, 2, 3}, {2, 3, 4, 5}},
	{{2, 3, 4, 5}, {0, 1, 4, 5}},
	{{2, 3, 4, 5}, {0, 1, 4, 5}}
};

int n;
char from[N], to[N];
char buf[7];
char face[N][6];

void solve()
{
	scanf("%s%s", from, to);
	n = strlen(from);

	for (int i = 0; i < n; i++)
	{
		scanf("%s", buf);
		face[i][0] = buf[0];
		face[i][4] = buf[1];
		face[i][2] = buf[2];
		face[i][5] = buf[3];
		face[i][3] = buf[4];
		face[i][1] = buf[5];
	}

	double res = 1;

	for (int i = 0; i < n; i++)
	{
		char oldc = from[i];
		char newc = to[i];
		double sum = 0;

		double oldc_cnt = 0;
		for (int j = 0; j < 6; j++)
			if (face[i][j] == oldc)
				oldc_cnt++;

		for (int j = 0; j < 6; j++)
			if (face[i][j] == oldc)
			{
				for (int orb = 0; orb < 2; orb++)
				{
					bool has = false;
					for (int k = 0; k < 4; k++)
						if (face[i][ORB[j][orb][k]] == newc)
							has = true;
					if (has)
						sum += 0.5 / oldc_cnt;
				}
			}

		res *= sum;
	}

	printf("%.10lf\n", res);
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	solve();

	return 0;
}