#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <string>
#include <assert.h>
#include <time.h>

using namespace std;

#define mp make_pair
#define pb emplace_back
#define all(a) (a).begin(), (a).end()

typedef long long li;
typedef long double ld;

void solve();

int main() {
#ifdef ICL
	clock_t start = clock();
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	cout.precision(20);
	cout << fixed;
	int t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
#ifdef ICL
	cout << endl << (clock() - start) / 1.0 / CLOCKS_PER_SEC << endl;
#endif
}

#define int li

const int mod = 1000000009;

int binpow(int q, int w) {
	if (!w) {
		return 1;
	}
	if (w & 1) {
		return q * binpow(q, w - 1) % mod;
	}
	return binpow(q * q % mod, w / 2);
}

void mmod(int& cur) {
	if (cur >= mod) {
		cur -= mod;
	}
}

const int L = 62;

typedef vector<vector<int>> Matrix;

Matrix mult(const Matrix& q, const Matrix& w) {
	vector<vector<int>> res(q.size(), vector<int>(q.size(), 0));
	for (int i = 0; i < q.size(); ++i) {
		for (int k = 0; k < q.size(); ++k) {
			for (int j = 0; j < q.size(); ++j) {
				res[i][j] += q[i][k] * w[k][j];
				res[i][j] %= mod;
			}
		}
	}
	return res;
}

void solve() {
	int n;
	int m;
	vector<int> col;
	cin >> n >> m;
	col.resize(m + 1);
	for (int i = 1; i <= m; ++i) {
		cin >> col[i];
		col[i] %= mod;
	}
	vector<vector<int>> trans(m * m, vector<int>(m * m, 0));
	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < m; ++j) {
			vector<vector<int>> dp(2 * m + 1, vector<int>(2 * m + 1, 0));
			dp[i][j] = 1;
			for (int fs = i; fs < 2 * m; ++fs) {
				for (int sc = j; sc < 2 * m; ++sc) {
					if (fs == sc && fs >= m - 1 && m >= 2) {
						dp[fs + 1][sc + 1] += dp[fs][sc] * col[2];
						dp[fs + 1][sc + 1] %= mod;
					}

					if (sc < fs) {
						for (int cur = 1; cur <= m; ++cur) {
							int last = sc + cur;
							if (last > 2 * m) {
								break;
							}
							if (last < m) {
								continue;
							}
							dp[fs][last] += dp[fs][sc] * col[cur];
							dp[fs][last] %= mod;
						}
					}
					else {
						for (int cur = 1; cur <= m; ++cur) {
							int last = fs + cur;
							if (last > 2 * m) {
								break;
							}
							if (last < m) {
								continue;
							}
							dp[last][sc] += dp[fs][sc] * col[cur];
							dp[last][sc] %= mod;
						}
					}
				}
			}

			for (int fs = m; fs < 2 * m; ++fs) {
				for (int sc = m; sc < 2 * m; ++sc) {
					trans[i * m + j][(fs - m) * m + (sc - m)] = dp[fs][sc];
				}
			}
		}
	}

	vector<vector<vector<int>>> pows(L);
	pows[0] = trans;
	for (int i = 1; i < L; ++i) {
		pows[i] = mult(pows[i - 1], pows[i - 1]);
	}

	int step = (n - 1) / m + 1;
	vector<vector<int>> res(m * m, vector<int>(m * m, 0));
	for (int i = 0; i < res.size(); ++i) {
		res[i][i] = 1;
	}
	for (int i = 0; i < L; ++i) {
		if (step & 1) {
			res = mult(res, pows[i]);
		}
		step >>= 1;
	}

	int rest = n % m;
	if (rest == 0) {
		rest = m;
	}
	--rest;
	int ans = res.back()[rest * m + rest];

	ans %= mod;
	if (ans < 0) {
		ans += mod;
	}

	cout << ans << "\n";
}
