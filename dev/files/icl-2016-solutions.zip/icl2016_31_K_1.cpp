#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

string st1, st2;
string k1, k2;

vector<pair<int, int> > answer;

int main() {
    cin >> st1 >> st2;

    k1 = st1;
    k2 = st2;

    sort(k1.begin(), k1.end());
    sort(k2.begin(), k2.end());

    if (k1 == k2)
    {
        for (int i = 0; i < st2.size(); ++i)
        {
            if (st1[i] != st2[i])
            {
                for (int j = i + 1; j < st1.size(); ++j)
                {
                    if (st1[j] == st2[i])
                    {
                        answer.push_back(make_pair(i + 1, j + 1));
                        reverse(st1.begin() + i, st1.begin() + j + 1);
                        break;
                    }
                }
            }
        }

        cout << "YES\n";
        cout << answer.size() << "\n";
        for (int i = 0; i < answer.size(); ++i)
        {
            printf("%d %d\n", answer[i].first, answer[i].second);
        }
    }
    else
    {
        cout << "NO";
    }

    return 0;
}
