#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

const int mod = (int)1e9 + 9;

int add(int a, int b)
{
	a += b;
	if (a < 0)
		return a + mod;
	if (a < mod)
		return a;
	return a - mod;
}

int mult(int a, int b)
{
	return (1LL * a * b) % mod;
}

int myPow(int a, int k)
{
	if (k == 0)
		return 1;
	if (k & 1)
		return mult(a, myPow(a, k - 1));
	int t = myPow(a, k / 2);
	return mult(t, t);
}

int getValue(int cnt, int k)
{
	return add(myPow(cnt + 1, k), add(-mult(2, myPow(cnt, k)), myPow(cnt - 1, k)));
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int d, m, k;
	scanf("%d%d%d", &k, &d, &m);
	if (m % d != 0)
	{
		puts("0");
		return 0;
	}
	m /= d;
	int ans = 1;
	for (int i = 2; i * i <= m; i++)
	{
		if (m % i == 0)
		{
			int cnt = 0;
			while (m % i == 0)
			{
				cnt++;
				m /= i;
			}
			ans = mult(ans, getValue(cnt, k));
		}
	}
	if (m != 1)
		ans = mult(ans, getValue(1, k));
	cout << ans << endl;
	return 0;
}