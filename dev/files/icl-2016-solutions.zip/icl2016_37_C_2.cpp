#include <bits/stdc++.h>

using namespace std;

typedef double dbl;

const dbl EPS = 1e-9;
const int FRONT = 0, UP = 1, RIGHT = 2, DOWN = 3, LEFT = 4, BACK = 5;

int main() {
	cout << fixed << setprecision(10);

	string a, b;
	cin >> a >> b;

	vector<string> cubes(a.size());

	for (int i = 0; i < (int)a.size(); i++) {
		cin >> cubes[i];
	}

	dbl ans = 1;

	for (int i = 0; i < (int)a.size(); i++) {
		if (a[i] != b[i]) {
			dbl now = 0;
			int cnt = 0;

			for (int j = 0; j < 6; j++) {
				if (cubes[i][j] == a[i]) cnt++;
			}

			if (cubes[i][FRONT] == a[i]) {
				if (cubes[i][BACK] == b[i] || (cubes[i][UP] == b[i] && cubes[i][RIGHT] == b[i]) || (cubes[i][RIGHT] == b[i] && cubes[i][DOWN] == b[i]) ||
						(cubes[i][DOWN] == b[i] && cubes[i][LEFT]) || (cubes[i][LEFT] == b[i] && cubes[i][UP] == b[i])) {
					now += (1.0 / (dbl)cnt);
				} else if (cubes[i][UP] == b[i] || cubes[i][RIGHT] == b[i] || cubes[i][DOWN] == b[i] || cubes[i][LEFT] == b[i]) {
					now += (1.0 / (dbl)cnt) * 0.5;
				}
			}

			if (cubes[i][UP] == a[i]) {
				if (cubes[i][DOWN] == b[i] || (cubes[i][BACK] == b[i] && cubes[i][RIGHT] == b[i]) || (cubes[i][RIGHT] == b[i] && cubes[i][FRONT] == b[i]) ||
						(cubes[i][FRONT] == b[i] && cubes[i][LEFT]) || (cubes[i][LEFT] == b[i] && cubes[i][BACK] == b[i])) {
					now += (1.0 / (dbl)cnt);
				} else if (cubes[i][BACK] == b[i] || cubes[i][RIGHT] == b[i] || cubes[i][FRONT] == b[i] || cubes[i][LEFT] == b[i]) {
					now += (1.0 / (dbl)cnt) * 0.5;
				}
			}

			if (cubes[i][RIGHT] == a[i]) {
				if (cubes[i][LEFT] == b[i] || (cubes[i][FRONT] == b[i] && cubes[i][UP] == b[i]) || (cubes[i][UP] == b[i] && cubes[i][BACK] == b[i]) ||
						(cubes[i][BACK] == b[i] && cubes[i][DOWN]) || (cubes[i][DOWN] == b[i] && cubes[i][FRONT] == b[i])) {
					now += (1.0 / (dbl)cnt);
				} else if (cubes[i][FRONT] == b[i] || cubes[i][UP] == b[i] || cubes[i][BACK] == b[i] || cubes[i][DOWN] == b[i]) {
					now += (1.0 / (dbl)cnt) * 0.5;
				}
			}

			if (cubes[i][DOWN] == a[i]) {
				if (cubes[i][UP] == b[i] || (cubes[i][BACK] == b[i] && cubes[i][RIGHT] == b[i]) || (cubes[i][RIGHT] == b[i] && cubes[i][FRONT] == b[i]) ||
						(cubes[i][FRONT] == b[i] && cubes[i][LEFT]) || (cubes[i][LEFT] == b[i] && cubes[i][BACK] == b[i])) {
					now += (1.0 / (dbl)cnt);
				} else if (cubes[i][BACK] == b[i] || cubes[i][RIGHT] == b[i] || cubes[i][FRONT] == b[i] || cubes[i][LEFT] == b[i]) {
					now += (1.0 / (dbl)cnt) * 0.5;
				}
			}

			if (cubes[i][BACK] == a[i]) {
				if (cubes[i][FRONT] == b[i] || (cubes[i][UP] == b[i] && cubes[i][RIGHT] == b[i]) || (cubes[i][RIGHT] == b[i] && cubes[i][DOWN] == b[i]) ||
						(cubes[i][DOWN] == b[i] && cubes[i][LEFT]) || (cubes[i][LEFT] == b[i] && cubes[i][UP] == b[i])) {
					now += (1.0 / (dbl)cnt);
				} else if (cubes[i][UP] == b[i] || cubes[i][RIGHT] == b[i] || cubes[i][DOWN] == b[i] || cubes[i][LEFT] == b[i]) {
					now += (1.0 / (dbl)cnt) * 0.5;
				}
			}

			if (cubes[i][LEFT] == a[i]) {
				if (cubes[i][RIGHT] == b[i] || (cubes[i][FRONT] == b[i] && cubes[i][UP] == b[i]) || (cubes[i][UP] == b[i] && cubes[i][BACK] == b[i]) ||
						(cubes[i][BACK] == b[i] && cubes[i][DOWN]) || (cubes[i][DOWN] == b[i] && cubes[i][FRONT] == b[i])) {
					now += (1.0 / (dbl)cnt);
				} else if (cubes[i][FRONT] == b[i] || cubes[i][UP] == b[i] || cubes[i][BACK] == b[i] || cubes[i][DOWN] == b[i]) {
					now += (1.0 / (dbl)cnt) * 0.5;
				}
			}

			ans *= min(1.0, now + EPS);
		}
	}

	cout << ans << "\n";

	#ifdef KEK
	system("pause");
	#endif
	return 0;
}
