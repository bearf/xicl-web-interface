#define _CRT_SECURE_NO_WARNINGS

#include <vector>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

set <string> usedStrings;

int dfs(string str)
{
	usedStrings.insert(str);
	int sz = 1;
	for (int l = 0; l < (int)str.length(); l++)
	{
		int cnt1 = 0;
		for (int s = l; s < (int)str.length(); s++)
		{
			if (str[s] == '1')
				cnt1++;
			if (cnt1 % 2 == 0)
			{
				string nStr = str;
				reverse(nStr.begin() + l, nStr.begin() + s + 1);
				if (usedStrings.count(nStr) == 0)
				{
					sz += dfs(nStr);
				}
			}
		}
	}
	return sz;
}

void brute(int len)
{
	usedStrings.clear();
	int sum = 0;
	for (int l = 0; l < len; l++)
		for (int p = l; p < len; p++)
		{
			string cur = string(l, '1') + string(p - l, '0') + "1" + string(len - p - 1, '0');
//			cerr << cur << endl;
			if (usedStrings.count(cur) != 0)
			{
				cerr << "Bad length and string: " << cur << endl;
				while (true) {}
				return;
			}
			sum += dfs(cur);
//			cerr << dfs(cur) << " ";
		}
	cerr << "Ok " << sum << endl;

}

void stress()
{
	for (int i = 1; i <= 30; i++)
	{
		cerr << "i = " << i << endl;
		brute(i);
	}
	while (true) {}
}

const int N = (int) 2e5 + 100;
int a[N], szA;
int b[N], szB;
int listA[2][N], szListA;
int listB[2][N], szListB;

char str[N];

void readS(int *x, int &sz)
{
	scanf("%s", str);
	int len = strlen(str);
	for (int i = 0; i < len; i++)
		if (str[i] == '1')
			x[sz++] = i;
}

void normalize(int *x, int &sz, int ans[2][N], int &ansSz)
{
	if (sz == 1) return;
	int ptr = 0;
	for (int pos = 0; pos < x[sz - 2]; pos++)
	{
		if (pos != x[ptr])
		{
			int a = x[ptr];
			int b = x[ptr + 1];
			x[ptr] = b - (b - pos);
			x[ptr + 1] = b - (a - pos);
			ans[0][ansSz] = pos;
			ans[1][ansSz] = b;
			ansSz++;
		}
		ptr++;
	}
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

//	stress();

	readS(a, szA);
	readS(b, szB);

	normalize(a, szA, listA, szListA);
	normalize(b, szB, listB, szListB);

	bool eq = true;
	if (szA != szB) eq = false;
	for (int i = 0; i < szA; i++)
		if (a[i] != b[i])
			eq = false;
	if (!eq)
	{
		printf("NO\n");
		return 0;
	}
	printf("YES\n%d\n", szListA + szListB);
	for (int i = 0; i < szListA; i++)
		printf("%d %d\n", listA[0][i] + 1, listA[1][i] + 1);
	for (int i = szListB - 1; i >= 0; i--)
		printf("%d %d\n", listB[0][i] + 1, listB[1][i] + 1);

	return 0;
}
