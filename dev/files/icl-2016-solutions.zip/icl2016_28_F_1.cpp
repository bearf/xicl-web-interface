#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <string>

using namespace std;

#define mp make_pair
#define pb emplace_back
#define all(a) (a).begin(), (a).end()

typedef long long li;
typedef long double ld;

void solve();

int main() {
#ifdef ICL
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	int t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
}

#define int li

const int mod = 1000000009;

int gcd(int a, int b) {
	while (a) {
		b %= a;
		swap(a, b);
	}
	return b;
}

int lcm(int a, int b) {
	return a / gcd(a, b) * b;
}

void mmod(int& cur) {
	if (cur >= mod) {
		cur -= mod;
	}
}

int binpow(int q, int w) {
	if (!w) {
		return 1;
	}
	if (w & 1) {
		return q * binpow(q, w - 1) % mod;
	}
	return binpow(q * q % mod, w / 2);
}

int c[5000][5000];

void solve() {
	for (int i = 0; i < 5000; ++i) {
		c[i][i] = c[i][0] = 1;
		for (int j = 1; j < i; ++j) {
			c[i][j] = (c[i - 1][j - 1] + c[i - 1][j]) % mod;
		}
	}

	int k, d, m;
	cin >> k >> d >> m;
	if (m % d) {
		cout << "0\n";
		return;
	}
	m /= d;
	vector<int> del;
	for (int cur = 1; cur * cur <= m; ++cur) {
		if (m % cur == 0) {
			del.push_back(cur);
			if (cur * cur != m) {
				del.push_back(m / cur);
			}
		}
	}
	sort(all(del));
	vector<vector<vector<int>>> dp(2, vector<vector<int>>(del.size(), vector<int>(del.size() + 1)));
	int par = 0;
	dp[0][0][0] = 1;
	for (int i = 0; i < del.size(); ++i) {
		dp[par ^ 1] = dp[par];
		for (int curd = 0; curd < del.size(); ++curd) {
			int nex_nok = lcm(del[curd], del[i]);
			int nex_id = lower_bound(all(del), nex_nok) - del.begin();
			for (int num = 0; num < del.size(); ++num) {
				/*dp[i + 1][curd][num] += dp[i][curd][num];
				mmod(dp[i + 1][curd][num]);*/
				dp[par ^ 1][nex_id][num + 1] += dp[par][curd][num];
				mmod(dp[par ^ 1][nex_id][num + 1]);
			}
		}
		par ^= 1;
	}

	vector<int> ans(del.size());

	vector<int> degs(del.size() + 1);
	for (int i = 0; i <= del.size(); ++i) {
		degs[i] = binpow(i, k);
	}

	vector<int> cur_dom(del.size() + 1);
	for (int i = 0; i <= del.size(); ++i) {
		for (int j = 0; j <= i; ++j) {
			int cur = c[i][j] * degs[i - j];
			if (j & 1) {
				cur_dom[i] -= cur;
			}
			else {
				cur_dom[i] += cur;
			}
			cur_dom[i] %= mod;
		}
	}

	for (int curd = 0; curd < del.size(); ++curd) {
		for (int num = 1; num <= del.size() && num <= k; ++num) {
			int cur_res = dp[par][curd][num] * cur_dom[num];
			ans[curd] += cur_res;
			ans[curd] %= mod;
		}
	}

	for (int curd = 0; curd < del.size(); ++curd) {
		for (int prev = 0; prev < curd; ++prev) {
			if (del[curd] % del[prev] == 0) {
				ans[curd] -= ans[prev];
				ans[curd] %= mod;
			}
		}
	}

	int result = ans.back();
	if (result < 0) {
		result += mod;
	}
	cout << result << "\n";
}
