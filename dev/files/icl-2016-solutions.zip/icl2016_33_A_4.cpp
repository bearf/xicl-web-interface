#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <bitset>
#include <complex>
using namespace std;

typedef long long int int64;

typedef long double ldouble;

const ldouble pi = acosl(-1.0);

bool eq(ldouble a, ldouble b, ldouble eps = 1e-10)
{
	return fabsl(a - b) < eps;
}

bool ls(ldouble a, ldouble b)
{
	return a < b && !eq(a, b);
}

bool ls_eq(ldouble a, ldouble b)
{
	return a < b || eq(a, b);
}

bool gr(ldouble a, ldouble b)
{
	return a > b && !eq(a, b);
}

bool gr_eq(ldouble a, ldouble b)
{
	return a > b || eq(a, b);
}

ldouble sqr(ldouble a)
{
	return a * a;
}

ldouble my_sqrt(ldouble a)
{
	if (ls(a, 0))
		throw;
	if (a < 0)
		a = 0;
	return sqrtl(a);
}

struct Point
{
	ldouble x, y;

	void scan()
	{
		double a, b;
		scanf("%lf%lf", &a, &b);
		x = a;
		y = b;
	}

	Point() : x(), y() {}
	Point(ldouble x, ldouble y) : x(x), y(y) {}

	bool operator == (Point p) const
	{
		return eq(x, p.x) && eq(y, p.y);
	}

	Point operator + (Point p)
	{
		return Point(x + p.x, y + p.y);
	}

	Point operator - (Point p)
	{
		return Point(x - p.x, y - p.y);
	}

	Point operator * (ldouble k)
	{
		return Point(x * k, y * k);
	}

	Point operator / (ldouble k)
	{
		return Point(x / k, y / k);
	}

	ldouble operator % (Point p)
	{
		return x * p.x + y * p.y;
	}

	ldouble length()
	{
		return my_sqrt(*this % *this);
	}

	ldouble dist_to(Point p)
	{
		return (*this - p).length();
	}

	ldouble operator * (Point p)
	{
		return x * p.y - y * p.x;
	}

	Point rotate()
	{
		return Point(-y, x);
	}

	Point rotate(ldouble angle)
	{
		Point v = *this;
		Point u = v.rotate();
		return v * cosl(angle) + u * sinl(angle);
	}

	Point normalize(ldouble k)
	{
		if (eq(length(), 0))
		{
			if (eq(k, 0))
				return *this;
			throw;
		}
		return *this / length() * k;
	}
};

bool intersect(Point A, Point B, Point C, Point D, Point &M)
{
	ldouble s1 = (C - A) * (D - A);
	ldouble s2 = (D - B) * (C - B);
	ldouble s = s1 + s2;
	if (eq(s, 0))
		return false;

	Point v = B - A;
	M = A + v / s * s1;

	return true;
}

void get_serper(Point A, Point B, Point &P1, Point &P2)
{
	P1 = (A + B) / 2;
	P2 = P1 + (B - A).rotate();
}

Point M1, M2, M3;
ldouble angle1, angle2;

ldouble read_angle()
{
	ldouble a;
	double _a;
	scanf("%lf", &_a);
	a = _a;
	return a / 180 * pi;
}

void get_D(Point A, Point B, ldouble angle, Point &D1, Point &D2)
{
	ldouble d = A.dist_to(B);
	ldouble h = (d / 2) / tan(angle / 2);
	Point C = (A + B) / 2;
	Point v = (B - A).normalize(h);

	D1 = C + v.rotate(pi / 2);
	D2 = C + v.rotate(-pi / 2);
}

void get_circle(Point A, Point B, Point C, Point &O, ldouble &r)
{
	Point P1, P2;
	get_serper(A, B, P1, P2);

	Point K1, K2;
	get_serper(B, C, K1, K2);

	assert(intersect(P1, P2, K1, K2, O));
	r = O.dist_to(A);
}

bool check(Point D, Point A, Point B, ldouble angle)
{
	Point v = A - D;
	Point u = B - D;
	ldouble cur_angle = fabsl(atan2l(v * u, v % u));
	return eq(cur_angle, angle);
}

bool try_print(Point K)
{
	if (!check(K, M1, M2, angle1))
		return false;
	if (!check(K, M2, M3, angle2))
		return false;
	printf("%.10lf %.10lf\n", (double)K.x, (double)K.y);
	return true;
}

bool try_solve(Point O1, ldouble r1, Point O2, ldouble r2)
{
	ldouble dist = O1.dist_to(O2);

	if (gr(dist, r1 + r2))
		return false;

	if (O1 == O2)
	{
		if (!eq(r1, r2))
			return false;

		for (int it = 0; it < 8; it++)
		{
			ldouble cur_angle = 2 * pi / 8 * it;
			Point K = O1 + Point(r1, 0).rotate(cur_angle);
			if (try_print(K))
				return true;
		}
	
		assert(false);
	}
	
	ldouble cosa = (sqr(r1) + sqr(dist) - sqr(r2)) / (2 * r1 * dist);
	ldouble alpha = acosl(cosa);

	Point v = (O2 - O1).normalize(r1);
	Point K1 = O1 + v.rotate(alpha);
	Point K2 = O1 + v.rotate(-alpha);

	if (try_print(K1))
		return true;

	if (try_print(K2))
		return true;

	return false;
}

void solve()
{
	M1.scan();
	M2.scan();
	M3.scan();
	angle1 = read_angle();
	angle2 = read_angle();

	Point D1, D2;
	get_D(M1, M2, angle1, D1, D2);
	vector<Point> list1 = { D1, D2 };

	Point K1, K2;
	get_D(M2, M3, angle2, K1, K2);
	vector<Point> list2 = { K1, K2 };

	for (Point P1 : list1)
	{
		for (Point P2 : list2)
		{
			Point O1;
			ldouble r1;
			get_circle(M1, M2, P1, O1, r1);

			Point O2;
			ldouble r2;
			get_circle(M2, M3, P2, O2, r2);

			if (try_solve(O1, r1, O2, r2))
				return;
		}
	}

	assert(false);
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int q;
	scanf("%d", &q);
	for (int i = 0; i < q; i++)
		solve();

	return 0;
}