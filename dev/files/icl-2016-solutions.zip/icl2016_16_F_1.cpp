#include <bits/stdc++.h>
#define mp make_pair
#define endl "\n"
#define F first
#define S second
#define int long long

const double eps = 0.0000000001;
typedef long long ll;
using namespace std;

const ll MOD = 1e9 + 9;

ll n, d, m;
ll ans = 0;
vector <ll> hooy;

inline ll get_ans(ll k) {
    ll res = 1;

    for (ll i = 0; i < k; ++i) {
        res *= (n - i);
        res %= MOD;
    }

    return res;
}

inline void perebor(ll k, ll z) {
    if (k == hooy.size()) {
        ans += get_ans(z);
        ans %= MOD;
        return;
    }

    for (int i = k + 1; i <= hooy.size(); ++i) {
        perebor(i, z + 1);
    }
}

main() {
    cin >> n >> d >> m;

    if (m % d != 0) {
        cout << 0;
        return 0;
    }

    m /= d;

    ll k = 2, z = m;

    while (k * k <= m) {
        if (z % k == 0) {
            hooy.push_back(k);
        }

        while (z % k == 0) {
            z /= k;
        }
        k++;
    }

    if (hooy.size() == 0) {
        cout << n;
        return 0;
    }

    perebor(-1, 0);

    cout << ans % MOD;

    //sokratit
}
