#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e3 + 5;
int a[NMAX];

int main(){
    ios_base::sync_with_stdio(false);
    //freopen("input.txt" , "r" , stdin); freopen("output.txt" , "w" , stdout);
    int n;
    cin >> n;
    if (n == 1){
        cout << 1;
        return 0;
    }

    for (int i = 0; i < n; i++)
        cin >> a[i];

    sort(a, a+n);

    int ans = 0;
    int st = a[n-1];

    for (int i = n-2; i >= 0; i--){
        if (a[i] < st){
            st = a[i];
        }
        else{
            ans++;
            st = a[i];
        }
    }

    cout << ans << endl;
    return 0;
}
