#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define F first
#define S second

// -- MAIN PART


int a, b, c, d;
vector<string> ans;
set<pair<int, int> > have;
int sw = 0;


void make(int type, int x, int y) {
	int xx, yy;
	if (type == 1) {
		xx = x + 1;
		yy = y + 1;
	} else {
		xx = x / 2;
		yy = y / 2;
	}
	if (have.find(mp(xx, yy)) != have.end()) return;
	have.insert(mp(xx, yy));

	stringstream q;
	if (sw) swap(x, y);
	q << type << " " << x << " " << y;

	ans.push_back(q.str());
}

void make3(int x, int y, int xx, int yy) {
	if (have.find(mp(x, yy)) != have.end()) return;
	have.insert(mp(x, yy));

	stringstream q;
	if (sw) {
		swap(x, y);
		swap(xx, yy);
	}
	q << 3 << " " << x << " " << y << " " << xx << " " << yy;

	ans.push_back(q.str());
}



int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif

	cin >> a >> b >> c >> d;

	if ((a == b) && (c == d)) {
		while ((b - a) % 2 == 0 && a > 1) {
			if (a % 2) {
				make(1, a, b);
				a++;
				b++;
			}
			make(2, a, b);
			a /= 2;
			b /= 2;
		}
		while (a < c) {
			make(1, a, b);
			a++;
			b++;
		}
	cout << ans.size() << endl;
	for (int i = 0; i < ans.size(); i++) cout << ans[i] << endl;
	return 0;
		
	}

	if ((a == b) != (c == d)) {
		puts("0");
		return 0;
	}

	if (a > b) {
		swap(a, b);
		swap(c, d);
		sw = 1;
	}

	while ((b - a) % 2 == 0) {
		if (a % 2) {
			make(1, a, b);
			a++;
			b++;
		}
		make(2, a, b);
		a /= 2;
		b /= 2;
	}
	int l = b - a;
	if (c >= d || (d - c) % l > 0 || c < a) {
		puts("0");
		return 0;
	}
	for (int i = a; i < d - l; i++) make(1, i, i + l);

	for (int i = c + l; i < d; i += l) make3(c, i, i, i + l);


	cout << ans.size() << endl;
	for (int i = 0; i < ans.size(); i++) cout << ans[i] << endl;




	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
