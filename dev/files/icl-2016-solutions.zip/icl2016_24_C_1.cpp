#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdint.h>
#include <string>
#include <cassert>
#define sz(s) int(s.size())
#define forn(i, n) for (int i = 0; i < n; i++)
using namespace std;

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
#ifdef AWWW
	assert(freopen("input.txt", "r", stdin) != nullptr);
#endif

	ld ans = 1.00000000000;
	string s, s2, s3, s4;
	int p[6][6] = { {0, 1, 2, 3, 4, 5}, {1, 5, 2, 0, 4, 3}, {2, 1, 5, 3, 0, 4}, {3, 0, 2, 5, 4, 1}, {4, 1, 0, 3, 5, 2}, {5, 3, 2, 1, 4, 0}};
	cin >> s >> s2;
	forn(i, sz(s)) {
		cin >> s3;
		int k = 0, p1 = 0;
		forn (j, 6) {
			if (s3[j] == s[i]) {
				s4 = "";
				forn(k, 6) s4 += s3[p[j][k]];
				k += 4;
				forn(o, 4) {
					if (s4[0] == s2[i] || s4[2] == s2[i] || s4[4] == s2[i] || s4[5] == s2[i]) p1++;
					swap(s4[1], s4[2]);
					swap(s4[2], s4[3]);
					swap(s4[3], s4[4]);
				}
			}
		}
		ans = (ans * ld(p1) / ld(k));
	}

	cout.precision(30);
	cout << ans;
#ifdef AWWW
	while (true) {}
#endif
}