#include <cstdio>
#include <algorithm>
#include <iostream>
#include <set>
#include <map>
#include <vector>
#include <cstring>
#include <string>
#include <cmath>

#pragma warning (disable : 4996)

#define put push_back
#define mapa make_pair

using namespace std;

int x;
int a[1010];

bool p[1010];
bool u[1010];

void dfs(int v) {
	u[v] = true;
	for (int i = v - 1; i >= 0; i--) {
		if (a[v] > a[i] && !u[i]) {
			dfs(i);
			break;
		}
	}
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
#ifndef _DEBUG
	//freopen("kek.in", "r", stdin);
	//freopen("kek.out", "w", stdout);
#endif

	cin >> x;
	for (int i = 0; i < x; i++) {
		cin >> a[i];
	}
	sort(a, a + x);
	for (int i = x - 1; i >= 0; i--) {
		if (!u[i]) {
			p[i] = true;
			dfs(i);
		}
	}
	int ans = 0;
	for (int i = 0; i < x; i++) {
		if (p[i])
			ans++;
	}
	cout << ans;
	return 0;
}