#include <bits/stdc++.h>

using namespace std;

typedef double dbl; 

const dbl eps = 1e-9;

struct Point {
	dbl x, y;
	dbl len(Point b) {
		return hypot(x - b.x, y - b.y);
	}
};

struct Vector {
	dbl x, y;
	Vector() {}
	Vector(dbl _a, dbl _b) {
		x = _a;
		y = _b;
	}
	Vector(Point a, Point b) {
		x = b.x - a.x;
		y = b.y - a.y;
	}
	void ortoganal() {
		swap(x, y);
		x *= -1;
	}
	dbl len() {
		return hypot(x, y);
	}
	void norm() {
		dbl ln = this->len();
		x /= ln;
		y /= ln;
	}
	void multiply(dbl k) {
		x *= k;
		y *= k;
	}
};

struct Line {
	dbl a, b, c;
	Line(Point p1, Point p2) {
		a = p2.y - p1.y;
		b = p1.x - p2.x;
		c = -a * p1.x - b * p1.y;
	}
	dbl dist(Point p) {
		return fabs((a * p.x + b * p.y + c) / sqrt(a * a + b * b));
	}
};

dbl cross_product(Vector a, Vector b) {
	return a.x * b.y - a.y * b.x;
}

dbl dot_product(Vector a, Vector b) {
	return a.x * b.x + a.y * b.y;
}

int main() {
	cout << fixed << setprecision(9);
	Point a, b, c;
	dbl r;
	cin >> a.x >> a.y >> b.x >> b.y;
	cin >> c.x >> c.y >> r;
	Line ab = Line(a, b);
	dbl toline = ab.dist(c);
	dbl tl = 0, tr = a.len(b);
	Vector vab1 = Vector(a, b), vab2 = Vector(a, b);
	Point pm1, pm2;
	for (int i = 0; i < 100; i++) {
		dbl m1 = tl + (tr - tl) / 3, m2 = tr - (tr - tl) / 3;
		vab1.norm();
		vab1.multiply(m1);
		vab2.norm();
		vab2.multiply(m2);
		pm1 = {a.x + vab1.x, a.y + vab1.y}, pm2 = {a.x + vab2.x, a.y + vab2.y};
		if (pm1.len(c) < pm2.len(c)) {
			tr = m2;
		} else {
			tl = m1;
		}
	}
	vab1.norm();
	vab1.multiply(tl);
	pm1 = {a.x + vab1.x, a.y + vab1.y};
	if (pm1.len(c) > r) {
		dbl totlen1 = 0, totlen2 = 0;
		totlen1 += a.len(b) + min(c.len(a), c.len(b)) - r;
		Vector ca = Vector(c, a), cb = Vector(c, b);
		ca.norm();
		cb.norm();
		ca.multiply(r);
		cb.multiply(r);
		dbl angle = fabs(atan2(cross_product(ca, cb), dot_product(ca, cb)));
		totlen2 += c.len(a) + c.len(b) - 2 * r + angle * r;
		cout << min(totlen1, totlen2) << '\n';
	} else {
		dbl totlen = 0, dst = ab.dist(c), x = sqrt(r * r - dst * dst);
		Vector cl = Vector(ab.a, ab.b);
		cl.norm();
		cl.multiply(dst);
		Point p1 = {c.x + cl.x, c.y + cl.y}, p2 = {c.x - cl.x, c.y - cl.y}, p;
		if (ab.dist(p1) < ab.dist(p2)) {
			p = p1;
		} else {
			p = p2;
		}
		cl.ortoganal();
		cl.norm();
		cl.multiply(x);
		Point pa = {p.x + cl.x, p.y + cl.y}, pb = {p.x - cl.x, p.y - cl.y};
		Vector cpa = Vector(c, pa), cpb = Vector(c, pb);
		dbl angle = fabs(atan2(cross_product(cpa, cpb), dot_product(cpa, cpb)));
		totlen += min(a.len(pa), a.len(pb)) + min(b.len(pa), b.len(pb)) + angle * r;
		cout << totlen << '\n';
	}
	//system("pause");
	return 0;
}
