#define _CRT_SECURE_NO_WARNINGS
#include <fstream>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
#include <iostream>
typedef long long ll;
typedef long double ld;
using namespace std;

ll gcd(ll a, ll b)
{
	if (b == 0)
		return a;
	return gcd(b, a%b);
}
ll lcm(ll a, ll b)
{
	return a / gcd(a, b)*b;
}
ll a[6], b[6];
int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
		cin >> a[i] >> b[i];
	ll g = b[0], l = a[0];
	for (int i = 1; i < n; i++)
	{
		l = lcm(l, a[i]);
		g = gcd(g, b[i]);
	}
	cout << l << " " << g;
	return 0;
}