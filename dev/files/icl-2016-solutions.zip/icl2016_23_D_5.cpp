#pragma once
#pragma once
#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <math.h>
//#include <conio.h>

#define long long ll
#define unsigned long long ull

using namespace std;

int main() {

	int L, N, K, F, p, O;

	scanf("%d%d%d", &L, &N, &K);
	
	for (int i = 0; i < L; ++i) {
		if (K >= N && L <= K) {
			printf("%d", N-L);
			return 0;
		}

		F = (N / K);
		O = N%K;
		if (O >= 2) {
			++F;
		}
		else {
			N -= O;
		}
		if (F == 0) {
			printf("0");
			//_getch();
			return 0;
		}
		p = ((F - 1) << 1) + 1;
		N = N - p;
		if (N <= 0) {
			printf("0");
			//_getch();
			return 0;
		}
	}

	printf("%d", N);

	//_getch();

	return 0;

}