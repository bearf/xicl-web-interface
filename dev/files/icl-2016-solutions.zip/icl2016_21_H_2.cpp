#include <bits/stdc++.h>

using namespace std;

const int NMAX = 2e5 + 5;
char a[NMAX];

int main(){
    ios_base::sync_with_stdio(false);
    //freopen("input.txt" , "r" , stdin); freopen("output.txt" , "w" , stdout);
    string s;
    cin >> s;
    int n;
    cin >> n;
    
    for (int i = 0; i < s.length(); i++){
        a[i] = s[i];
    }

    for (int i = 0; i < n; i++){
        int x;
        cin >> x;
        reverse(a, a + x);
        reverse(a + x, a + s.length());
    }

    for (int i = 0; i < s.length(); i++)
        cout << a[i];
    return 0;
}
