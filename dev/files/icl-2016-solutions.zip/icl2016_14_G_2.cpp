/*
ICL 2016
Team: Mathematical Grammar School, Belgrade
*/
#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const int MAXN=10010;
int cnt[MAXN];
    vector<int> vx;

int main()
{
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++) {int foo;
    scanf("%d",&foo);
    cnt[foo]++;
   }
    for(int i=1;i<=10000;i++) if(cnt[i]>0)
    {
        vx.push_back(cnt[i]);
        //printf("%d %d\n",cnt[i],vx[vx.size()-1]);
    }
    int ans=0;
  ///  for(int i=0;i<vx.size();i++)printf("%d ",vx[i]);
  //  printf("\n");
    int into=0;
    for(int i=0;i<vx.size();i++)
    {
        into=max(into-vx[i],0);
        into+=vx[i];

        //ans+=max(0,vx[i]-vx[i+1]);
    }
    //ans+=vx[vx.size()-1];
    printf("%d\n",into);
    return 0;
}
