#include <bits/stdc++.h>

#define fr first
#define sc second
#define all(x) x.begin(), x.end()
#define int long long

using namespace std;

const int MAXN = 1e5;

main()
{
    int n;
    cin >> n;
    int a[6], b[6];
    cin >> a[0] >> b[0];
    int db = b[0], da = a[0];
    for (int i = 1; i < n; i++) {
        cin >> a[i] >> b[i];
        db = __gcd(db, b[i]), da = __gcd(da, a[i]);
    }
    int ka = a[0];
    for (int i = 1; i < n; i++) {
        ka *= (a[i] / da);
    }
    cout << ka << " " << db;
}
