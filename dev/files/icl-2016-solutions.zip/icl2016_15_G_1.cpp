#include <iostream>
#include <algorithm>
#include<vector>
using namespace std;

int main()
{
	ios_base::sync_with_stdio(false);
	int n;
	cin >> n;
	vector <int> a(n);
	for (int i = 0; i < n; i++)
		cin >> a[i];

	sort(a.begin(), a.end());
	reverse(a.begin(), a.end());
	vector<int> used(n, 0);

	int u = 1;
	int cnt = 0;
	used[0] = 1;
	vector<int> b(n);
	
	while (n != 0)
	{
		cnt++;
		int j = 0;
		for (int i = 1; i < n; i++)
		{
			if (a[i] == a[i - 1])
				b[j++] = a[i];
		}
		n = j;
		a = b;
	}
	cout << cnt;
	return 0;
}
