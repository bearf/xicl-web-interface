#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

ll a[10], b[10];

ll gcd(ll x, ll y)
{
	return y == 0 ? x : gcd(y, x % y);
}

ll lcm(ll x, ll y)
{
	return x / gcd(x, y) * y;
}

const int C = (int)1e5;
int cnt[C];

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		int x;
		scanf("%d", &x);
		cnt[x]++;
	}
	int ans = 0;
	for (int i = 0; i < C; i++)
		ans = max(ans, cnt[i]);
	cout << ans << endl;
	return 0;
}