#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

#define mp make_pair

typedef pair<int, int> pii;

set<pii> s;

int main() {
#ifdef LOCAL
    assert(freopen("j.in", "r", stdin));
#endif
    s.emplace(-1, 0);
    s.emplace(2e9, 2e9);
    int n;
    cin >> n;
    forn (i, n) {
        //cerr << "s:\n";
        //for (auto x: s)
            //cerr << x.first << ' ' << x.second << '\n';
        //cerr << "end\n";
        int x;
        cin >> x;
        if (x < 0) {
            x = -x;
            auto it = prev(s.upper_bound(mp(x, 2e9)));
            if (it->first <= x && x < it->second) {
                int L = it->first, R = it->second;
                s.erase(it);
                if (L < x)
                    s.emplace(L, x);
                if (x + 1 < R)
                    s.emplace(x + 1, R);
            }
            continue;
        }
        int len;
        cin >> len;
        auto it = prev(s.upper_bound(mp(x, 2e9)));
        if (it->first <= x && x < it->second)
            x = it->second;
        int to = x + len;
        auto nx = next(it);
        if (to > nx->first)
            to = nx->first;
        cout << x << ' ' << to - 1 << '\n';
        if (it->second == x) {
            x = it->first;
            s.erase(it);
        }
        if (nx->first == to) {
            to = nx->second;
            s.erase(nx);
        }
        s.emplace(x, to);
    }
}
