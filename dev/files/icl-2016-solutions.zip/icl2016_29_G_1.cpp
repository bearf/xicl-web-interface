#include <iostream>
#include <map>
#include <algorithm>

using namespace std;

map <int, int> mp;
int n, q, ans = 1;

int main() {
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> q;
		mp[q]++;
		ans = max(mp[q], ans);
	}
	cout << ans;
}
