#include <bits/stdc++.h>

using namespace std;


int main()
{
    int n;
    cin >> n;
    int nok, nod_a, nod_b;
    int a, b;
    cin >> a >> b;
    nod_a = a;
    nok = a;
    nod_b = b;
    for (int i = 1; i < n; i++){
        int a, b;
        cin >> a >> b;
        nod_a = __gcd(nod_a, a);
        nok *= a;
        nod_b = __gcd(nod_b, b);
    }
    nok /= nod_a;
    cout << nok << ' ' << nod_b;



    return 0;
}
