
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <math.h>
#include <string>


#define re return

typedef long long ll;
typedef unsigned long long ull;

using namespace std;

int mas[6][2][3] = { {{2,5,4},{1,5,3}}, {{2,3,4},{5,3,0}}, {{0,4,5},{1,4,3}}, {{0,1,5},{2,1,4}}, {{0,2,5},{1,2,3}}, {{1,0,3},{2,0,4}} };

int main() {
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);

	string a, b;
	cin >> a >> b;
	int n = a.size();

	double ans = 1;

	for (int i = 0; i < n; ++i) {
		string s;
		cin >> s;
		if (a[i] == b[i]) continue;

		double tmp = 0;
		int k = 0;

		for (int j = 0; j < 6; ++j) {
			if (s[j] == a[i]) {
				double x = 0;
				k++;
				for (int w = 0; w < 3; ++w)
					if (s[mas[j][0][w]] == b[i]) {
						x += 0.5;
						//cout << "ooo" << w;
						break;
					}
				for (int w = 0; w < 3; ++w)
					if (s[mas[j][1][w]] == b[i]) {
						x += 0.5;
						//cout << "bbb" << w;
						break;
					}
				tmp += x;
			}
		}
		ans *= (tmp / k);
		//cout << i << " " << (tmp / k) << endl;
	}

	cout << ans;



	re 0;
}
