#include <bits/stdc++.h>
#define fi first
#define se second
using namespace std;

typedef long long ll;

int main() {
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);

    string s1, s2;
    cin >> s1 >> s2;

    int n = (int)s1.length();

    double ans = 1.0;
    for (int i = 0; i < n; i++) {
        string t;
        cin >> t;

        if (t.find(s1[i]) == string::npos) {
            ans = 0;
            continue;
        }
        if (t.find(s2[i]) == string::npos) {
            ans = 0;
            continue;
        }

        if (s1[i] == s2[i]) continue;

        for (int j = 0; j < 6; j++) {
            if (t[j] == s1[i]) {
                if (j == 0) {
                    bool ok1 = false, ok2 = false;
                    if (t[5] == s2[i]) {
                        ans *= 1.0;
                    } else {
                        if (t[2] == s2[i] || t[4] == s2[i]) {
                            ok1 = true;
                        }
                        if (t[1] == s2[i] || t[3] == s2[i]) {
                            ok2 = true;
                        }
                        if (ok1 + ok2 == 2) {
                            ans *= 1.0;
                        } else if (ok1 + ok2 == 1) {
                            ans *= 0.5;
                        } else assert(false);
                    }
                }
                if (j == 1) {
                    bool ok1 = false, ok2 = false;
                    if (t[3] == s2[i]) {
                        ans *= 1.0;
                    } else {
                        if (t[2] == s2[i] || t[4] == s2[i]) {
                            ok1 = true;
                        }
                        if (t[0] == s2[i] || t[5] == s2[i]) {
                            ok2 = true;
                        }
                        if (ok1 + ok2 == 2) {
                            ans *= 1.0;
                        } else if (ok1 + ok2 == 1) {
                            ans *= 0.5;
                        } else assert(false);
                    }
                }
                if (j == 2) {
                    bool ok1 = false, ok2 = false;
                    if (t[4] == s2[i]) {
                        ans *= 1.0;
                    } else {
                        if (t[0] == s2[i] || t[5] == s2[i]) {
                            ok1 = true;
                        }
                        if (t[1] == s2[i] || t[3] == s2[i]) {
                            ok2 = true;
                        }
                        if (ok1 + ok2 == 2) {
                            ans *= 1.0;
                        } else if (ok1 + ok2 == 1) {
                            ans *= 0.5;
                        } else assert(false);
                    }
                }
                if (j == 3) {
                    bool ok1 = false, ok2 = false;
                    if (t[1] == s2[i]) {
                        ans *= 1.0;
                    } else {
                        if (t[2] == s2[i] || t[4] == s2[i]) {
                            ok1 = true;
                        }
                        if (t[5] == s2[i] || t[0] == s2[i]) {
                            ok2 = true;
                        }
                        if (ok1 + ok2 == 2) {
                            ans *= 1.0;
                        } else if (ok1 + ok2 == 1) {
                            ans *= 0.5;
                        } else assert(false);
                    }
                }
                if (j == 4) {
                    bool ok1 = false, ok2 = false;
                    if (t[2] == s2[i]) {
                        ans *= 1.0;
                    } else {
                        if (t[1] == s2[i] || t[3] == s2[i]) {
                            ok1 = true;
                        }
                        if (t[5] == s2[i] || t[0] == s2[i]) {
                            ok2 = true;
                        }
                        if (ok1 + ok2 == 2) {
                            ans *= 1.0;
                        } else if (ok1 + ok2 == 1) {
                            ans *= 0.5;
                        } else assert(false);
                    }
                }
                if (j == 5) {
                    bool ok1 = false, ok2 = false;
                    if (t[0] == s2[i]) {
                        ans *= 1.0;
                    } else {
                        if (t[2] == s2[i] || t[4] == s2[i]) {
                            ok1 = true;
                        }
                        if (t[1] == s2[i] || t[3] == s2[i]) {
                            ok2 = true;
                        }
                        if (ok1 + ok2 == 2) {
                            ans *= 1.0;
                        } else if (ok1 + ok2 == 1) {
                            ans *= 0.5;
                        } else assert(false);
                    }
                }
            }
        }
    }

    printf("%.10f\n", ans);
}
