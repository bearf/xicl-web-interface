#include <bits/stdc++.h>
#define fi first
#define se second
#define MP make_pair
using namespace std;

typedef long long ll;
typedef pair <int, int> pi;

string a, b;

bool check (char x, char y, int i) {
    if (a[i] == x && b[i] == y)
        return true;
    if (a[i] == y && b[i] == x)
        return true;
    return false;
}


int main() {
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
    cin >> a >> b;
    int n = a.length();
    double ans = 1;
    for (int i = 0; i < n; i++) {
        string s;
        cin >> s;
        if (a[i] == b[i])
            continue;
        if (check(s[0], s[1], i) || check(s[0], s[2], i) || check(s[0], s[3], i) || check(s[0], s[4], i) || check(s[1], s[2], i) || check(s[1], s[4], i) || check(s[1], s[5], i) || check(s[2], s[3], i) || check(s[2], s[5], i) || check(s[4], s[5], i)){
            ans /= 2;
        } else {
            if (check(s[0], s[5], i) || check(s[1], s[3], i) || check(s[2], s[4], i))
                ans /= 4;
        }
    }
    cout << ans;
}
 