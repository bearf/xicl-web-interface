#define _CRT_SECURE_NO_WARNINGS
#include <fstream>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
#include <iostream>
typedef long long ll;
typedef long double ld;
using namespace std;

ll gcd(ll a, ll b)
{
	if (b == 0)
		return a;
	return gcd(b, a%b);
}
ll lcm(ll a, ll b)
{
	return a / gcd(a, b)*b;
}
map <ll, ll> mp;
ll ss[10005] = { 0 };
int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		ll a;
		cin >> a;
		ss[a]++;
	}
	ll ans = 0;
	for (int i = 0; i < 10005; i++)
		ans = max(ans, ss[i]);
	cout << ans;
	return 0;
}