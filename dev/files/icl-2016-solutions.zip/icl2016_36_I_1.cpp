#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const ll inf = 1e9;

multiset<ll> s[16];

int main(){
    //ifstream cin("a.in");
    //ofstream cout("a.out");
    ios::sync_with_stdio(0);
    int zap;
    cin >> zap;
    for (int it = 0; it < zap; it++){
        int t;
        ll q[4];
        cin >> t >> q[0] >> q[1] >> q[2] >> q[3];
        if (t == 1){
            for (int mask = 0; mask < (1 << 4); mask++){
                ll sum = 0;
                for (int i = 0; i < 4; i++){
                    sum += abs(q[i] - inf * ((mask & (1 << i)) == 0 ? 1 : -1));
                }
                s[mask].insert(-sum);
            }
        }
        if (t == 2){
            for (int mask = 0; mask < (1 << 4); mask++){
                ll sum = 0;
                for (int i = 0; i < 4; i++){
                    sum += abs(q[i] - inf * ((mask & (1 << i)) == 0 ? 1 : -1));
                }
                s[mask].erase(s[mask].find(-sum));
            }
        }
        if (t == 3){
            ll ret = 0;
            for (int mask = 0; mask < (1 << 4); mask++){
                ll sum = 0;
                for (int i = 0; i < 4; i++){
                    sum += abs(q[i] - inf * ((mask & (1 << i)) == 0 ? 1 : -1));
                }
                if (!s[mask].empty())
                ret = max(ret, -(*s[mask].begin()) - sum);
            }
            cout << ret << '\n';
        }
    }
}
