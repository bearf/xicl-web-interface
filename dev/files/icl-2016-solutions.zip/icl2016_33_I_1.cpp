#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <bitset>
#include <complex>
using namespace std;

typedef long long int int64;

const int N = (int)2e5;
const int MASK = 16;

map<vector<int>, int> to_id;
vector<int> points[N];
set<pair<int, int> > best_p[MASK];

bool bit(int mask, int pos)
{
	return (mask & (1 << pos)) != 0;
}

int get_dist(const vector<int> &first, const vector<int> &second)
{
	int ans = 0;
	for (int i = 0; i < 4; i++)
		ans += abs(first[i] - second[i]);
	return ans;
}

int get_id(const vector<int> &v)
{
	auto it = to_id.find(v);
	if (it != to_id.end())
		return it->second;
	int new_id = (int)to_id.size();
	to_id[v] = new_id;
	return new_id;
}

int get_val(int id, int mask)
{
	int ans = 0;
	for (int i = 0; i < 4; i++)
	{
		int sign = 1;
		if (bit(mask, i))
			sign = -1;
		ans += points[id][i] * sign;
	}
	return ans;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int q;
	scanf("%d", &q);
	for (int i = 0; i < q; i++)
	{
		int type;
		scanf("%d", &type);
		vector<int> p(4);
		for (int j = 0; j < 4; j++)
			scanf("%d", &p[j]);

		if (type == 1)
		{
			int id = get_id(p);
			points[id] = p;
			for (int mask = 0; mask < MASK; mask++)
			{
				int v = get_val(id, mask);
				best_p[mask].insert(make_pair(v, id));
			}
		}
		else if (type == 2)
		{
			int id = get_id(p);
			points[id] = p;
			for (int mask = 0; mask < MASK; mask++)
			{
				int v = get_val(id, mask);
				best_p[mask].erase(make_pair(v, id));
			}
		}
		else
		{
			int ans = 0;
			for (int mask = 0; mask < MASK; mask++)
			{
				int cand = best_p[mask].rbegin()->second;
				int cur = get_dist(p, points[cand]);
				ans = max(ans, cur);
			}
			printf("%d\n", ans);
		}
	}
	

	return 0;
}