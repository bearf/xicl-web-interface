#include <bits/stdc++.h>

using namespace std;


int main()
{
    string s;
    cin >> s;

    int n;
    cin >> n;

    bool reversed = false;

    for (int i = 0; i < n; i++){
        int booth;
        cin >> booth;

        if (reversed){
            s = s.substr(s.length() - booth, s.length()) + s.substr(0, s.length() - booth);
            reversed = false;
        }

        else{
            s = s.substr(booth, s.length()) + s.substr(0, booth);
            reversed = true;
        }
    }

    if (reversed){
        for (int i = s.length() - 1; i > -1; i--){
            cout << s[i];
        }
    }
    else{
        for (int i = 0; i < s.length(); i++){
            cout << s[i];
        }
    }

    return 0;
}