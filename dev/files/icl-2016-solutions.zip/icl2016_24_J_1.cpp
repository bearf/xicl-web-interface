#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdint.h>
#include <string>
#include <cassert>
using namespace std;

typedef long long ll;
typedef double ld;

const int INF = 1000 * 1000 * 1000;

set<pair<int, int>> s;
pair<bool, set<pair<int, int>>::iterator> get_seg(int x)
{
	set<pair<int, int>>::iterator it = s.lower_bound({ x + 1, -INF });
	set<pair<int, int>>::iterator jt = it;
	--jt;
	return{ jt->first <= x && x <= jt->second, it };
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
#ifdef AWWW
	assert(freopen("input.txt", "r", stdin) != nullptr);
#endif

	int n;
	cin >> n;

	s.insert({ -INF, -INF });
	s.insert({ INF, INF });

	for (int i = 0; i < n; ++i)
	{
		int x;
		cin >> x;

		if (x < 0)
		{
			x = -x;
			auto p = get_seg(x);
			if (p.first)
			{
				--p.second;
				if (x > p.second->first)
				{
					s.insert({ p.second->first, x - 1 });
				}
				if (p.second->second > x)
				{
					s.insert({ x + 1, p.second->second });
				}
				s.erase(p.second);
			}
		}
		else
		{
			int y;
			cin >> y;
			auto p = get_seg(x);
			if (p.first)
			{
				auto it = p.second;
				--it;
				x = it->second + 1;
			}
			int ax = x;
			auto it = p.second;
			--it;
			int rr = x + y - 1;
			int ay = min(rr, p.second->first - 1);

			if (rr + 1 >= p.second->first)
			{
				rr = p.second->second;
				s.erase(p.second);
			}
			int ll = x;
			if (it->second == x - 1)
			{
				ll = it->first;
				s.erase(it);
			}
			s.insert({ ll, rr });
			cout << ax << " " << ay << endl;
		}
	}

#ifdef AWWW
	while (true) {}
#endif
}