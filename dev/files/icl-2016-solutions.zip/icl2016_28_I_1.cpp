#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <string>

using namespace std;

#define mp make_pair
#define pb emplace_back
#define all(a) (a).begin(), (a).end()

typedef long long li;
typedef long double ld;

void solve();

int main() {
#ifdef ICL
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	int t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
}

#define int li

multiset < pair<int, vector<int>>> points[16];

vector<int> scan() {
	vector<int> res(4);
	for (int i = 0; i < 4; ++i) {
		cin >> res[i];
	}
	return res;
}

int get_val(int mask, const vector<int>& v) {
	int res = 0;
	for (int i = 0; i < 4; ++i) {
		if (mask & (1 << i)) {
			res += v[i];
		}
		else {
			res -= v[i];
		}
	}
	return res;
}

void insert(int mask, const vector<int>& v) {
	points[mask].insert(mp(get_val(mask, v), v));
}

void erase(int mask, const vector<int>& v) {
	points[mask].erase(mp(get_val(mask, v), v));
}

int dist(int mask, const vector<int>& v) {
	int cur_val = get_val(mask, v);
	int res = 0;
	res = max(res, abs(cur_val - points[mask].begin()->first));
	res = max(res, abs(cur_val - points[mask].rbegin()->first));
	return res;
}

void solve() {
	int n;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		int type;
		cin >> type;
		auto v = scan();
		if (type == 1) {
			for (int mask = 0; mask < 16; ++mask) {
				insert(mask, v);
			}
		}
		else if (type == 3) {
			int res = 0;
			for (int mask = 0; mask < 16; ++mask) {
				res = max(res, dist(mask, v));
			}
			cout << res << "\n";
		}
		else {
			for (int mask = 0; mask < 16; ++mask) {
				erase(mask, v);
			}
		}
	}
}
