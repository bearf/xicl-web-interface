#define _CRT_SECURE_NO_WARNINGS
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <ctime>
#include <string>

using namespace std;

void solution();

int main()
{
	ios_base::sync_with_stdio(false);
#ifdef HOME
	freopen("input.txt", "rt", stdin);
	clock_t start = clock();
#endif
	solution();
#ifdef HOME
	cerr.precision(3);
	cerr << endl << "Total time: " << fixed << double(clock() - start) / double(CLOCKS_PER_SEC) << endl;
#endif
	return 0;
}

typedef long long ll;
#define int ll

int gcd(int a, int b)
{
	while (b)
		swap(b, a %= b);
	return a;
}

int lcm(int x, int y)
{
	return x * y / gcd(x, y);
}

int pow(int a, int n)
{
	if (n == 0)
		return 1;
	else if (n == 1)
		return a;
	if (n % 2 == 0)
	{
		int res = pow(a, n / 2);
		return res * res;
	}
	else
	{
		return a * pow(a, n - 1);
	}
}

int pow_check(int a, int n, int m, bool& fnd)
{
	if (fnd)
		return 1;
	if (n == 0)
		return 1;
	else if (n == 1)
		return a;
	int res = 1;
	if (n % 2 == 0)
	{
		res = pow_check(a, n / 2, m, fnd);
		res *= res;
	}
	else
	{
		res = a * pow_check(a, n - 1, m, fnd);
	}
	if (res > m)
	{
		fnd = true;
	}
	return res;
}

#define N 200000
#define MP(x, y) make_pair(x, y)
bool pr[N + 1];
int k, d, m;
int p[N], pc = 0;

void solution2()
{
	for (int i = 2; i <= N; ++i)
		pr[i] = true;
	for (int i = 2; i <= N; ++i)
		if (pr[i])
			for (int j = i + i; j <= N; j += i)
				pr[j] = false;
	for (int i = 2; i <= N; ++i)
		if (pr[i])
			p[pc++] = i;
	for (; cin >> k >> d >> m;)
	{
		bool fnd = false;
		pow_check(d, k - 1, m, fnd);
		if (fnd)
		{
			cout << 0 << endl;
			continue;
		}
		int u = m / pow(d, k - 1);
		cout << u << endl;
	}
}

void solution()
{
	int inv[6] = {5, 3, 4, 1, 2, 0};
	string s[2];
	cin >> s[0] >> s[1];
	double p = 1;
	for (int i = 0; i < s[0].size(); i++)
	{
		string c;
		cin >> c;
		if (s[0][i] != s[1][i])
		{
			int k = 0;
			double sum = 0;
			for (int j = 0; j < 6; j++)
				if (c[j] == s[0][i])
				{
					k++;
					if (c[inv[j]] == s[1][i])
						sum+= 1;
					else
					{
						vector <int> n;
						for (int l = 0; l < 6; l++)
							if ((j != l) && (inv[j] != l))
								if (c[l] == s[1][i])
									n.push_back(l);
						if (n.size() > 2)
							sum += 1;
						else
						{
							if (n.size() == 2)
							{
								if (n[0] == inv[n[1]])
									sum += 0.5;
								else
									sum += 1;
							}
							else
								if (n.size() == 1)
									sum += 0.5;
						}
					}
				}
			if (k)
				p *= (sum / k);
			else
				p = 0;
		}
	}
	cout.precision(9);
	cout << fixed << p;
}