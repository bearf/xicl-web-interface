import java.io.*;
import java.util.*;
import java.math.*;

public class M {
	public static void main(String[] args) {
		new M().run();
	}
	
	Scanner in;
	PrintWriter out;
	
	void run() {
		in = new Scanner(System.in);
		out = new PrintWriter(System.out);
		solve();
		out.flush();
	}
	
	BigInteger lcm(BigInteger a, BigInteger b) {
		return a.divide(a.gcd(b)).multiply(b);
	}
	
	void solve() {
		int n = in.nextInt();
		BigInteger a = in.nextBigInteger();
		BigInteger b = in.nextBigInteger();
		
		for (int i = 0; i < n - 1; i++) {
			BigInteger c = in.nextBigInteger();
			BigInteger d = in.nextBigInteger();
			
			BigInteger up = lcm(a.multiply(d), c.multiply(b));
			BigInteger down = b.multiply(d);
			
			BigInteger g = up.gcd(down);
			a = up.divide(g);
			b = down.divide(g);
		}
		
		out.println(a + " " + b);
	}
}