#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <string>
using namespace std;
int main() {
	
	string s;
	getline(cin, s);
	int n;
	int c = s.size();
	cin >> n;
	int a=1,b;
	for (int i = 0; i < n; i++) {
		cin >> b;
		if (a > b) {
			a = (a - b);
			int b1 = b;
			b = c - b;
			a = b - a +1+ b1;
		}
		else
			a = b - a + 1;

	}
	if (n % 2 == 1) {
		for (int i = a - 1; i >= 0; i--) {
			cout << s[i];
		}
		for (int i = c - 1; i >a-1; i--) {
			cout << s[i];
		}
	}
	else {
		for (int i = c - a+1; i <c; i++) {
			cout << s[i];
		}
		for (int i = 0; i <= c - a; i++) {
			cout << s[i];
		}
	}

		

}
