#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main(){ 
	int n;
	cin >> n;
	vector<int> r(n);
	for(int i = 0; i < n; i++) {
		cin >> r[i];
	}
	sort(r.rbegin()_, r.rend());
	
	int x = 1;
	int mx = 1;
	int cur = r[0];
	for(int i = 1; i < n; i++) {
		if(cur == r[i]) {
			x++;
			mx = max(mx, x);
		} else {
			x = 1;
			cur = r[i];
		}
	}
	cout << mx << endl;
}