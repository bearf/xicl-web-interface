#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

const int N = 200200;
string s;
int n, q;
int p, z;

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	cin.tie(0);
	getline(cin, s);
	n = s.length();
	scanf("%d", &q);
	p = 0;
	z = 0;
	while (q--)
	{
		int x;
		scanf("%d", &x);
		eprintf("%d\n", x);
		p = (n - p) % n;
		p = (p - x + n) % n;
		z ^= 1;
	}
	if (z)
	{
		reverse(s.begin(), s.end());
	}
	for (int i = p; i < n; i++)
		printf("%c", s[i]);
	for (int i = 0; i < p; i++)
		printf("%c", s[i]);

	return 0;
}