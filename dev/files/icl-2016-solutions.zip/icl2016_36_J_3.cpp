#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const ll inf = 1e18;

set<pair<ll, ll> > q;

set<pair<ll, ll> > :: iterator it, i, j;

int main()
{
    //ifstream cin("a.in");
    //ofstream cout("a.out");
    ios::sync_with_stdio(0);
    int zap;
    cin >> zap;
    for (int iter = 0; iter < zap; iter++){
        ll x;
        cin >> x;
        if (x < 0){
            x = -x;
            it = q.upper_bound(make_pair(x, inf));
            if (it != q.end())
                it--;
            if (it != q.end() && it->first <= x && it->second >= x){
                ll l = it->first;
                ll r = it->second;
                q.erase(it);
                if (l < x)
                    q.insert(make_pair(l, x - 1));
                if (r > x)
                    q.insert(make_pair(x + 1, r));
            }
        }
        else{
            ll p;
            cin >> p;
            if (q.empty()){
                q.insert(make_pair(x, x + p - 1));
                cout << x << ' ' << x + p - 1 << '\n';
                continue;
            }
            it = q.upper_bound(make_pair(x, inf));
            i = it;
            it--;
            ll l = it->first, r = it->second, a = i->first, b = i->second;
            if (it != q.end() && l <= x && r >= x){
                if (i != q.end() && r + p >= a - 1)
                    cout << r + 1 << ' ' << a - 1 << '\n', q.erase(make_pair(a, b)), q.erase(make_pair(l, r)), q.insert(make_pair(l, b));
                else
                    cout << r + 1 << ' ' << r + p << '\n', q.erase(make_pair(l, r)), q.insert(make_pair(l, r + p));
            }
            else{
                if (i != q.end() && x + p - 1 >= a - 1)
                    cout << x << ' ' << a - 1 << '\n', q.erase(make_pair(a, b)), q.insert(make_pair(x, b));
                else
                    cout << x << ' ' << x + p - 1 << '\n', q.insert(make_pair(x, x + p - 1));
            }
            i = q.lower_bound(make_pair(x, 0));
            it = i;
            i--;
            l = it->first, r = it->second, a = i->first, b = i->second;
            if (it != q.end() && i != q.end() && l == x && b == x - 1)
                q.erase(make_pair(l, r)), q.erase(make_pair(a, b)), q.insert(make_pair(a, r));
        }
    }
}
