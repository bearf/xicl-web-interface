#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int maxn = 6;

int n;

pair<ll, ll> q[maxn];

int main()
{
    ios::sync_with_stdio(0);
    cin >> n;
    if (n == 1){
        int x, y;
        cin >> x >> y;
        int d = __gcd(x, y);
        x /= d;
        y /= d;
        cout << y << ' ' << x;
        return 0;
    }
    for (int i = 0; i < n; i++){
        cin >> q[i].second >> q[i].first;
        ll d = __gcd(q[i].first, q[i].second);
        q[i].first /= d;
        q[i].second /= d;
    }
    ll gcd = q[0].first;
    for (int i = 1; i < n; i++)
        gcd = __gcd(gcd, q[i].first);
    ll f = q[0].second;
    ll ch = 1;
    for (int i = 1; i < n; i++)
        ch = ch * q[i].second / __gcd(ch, q[i].second);
    ll g1 = __gcd(ch, gcd);
    ch /= g1;
    gcd /= g1;
    cout << ch << ' ' << gcd;
}
