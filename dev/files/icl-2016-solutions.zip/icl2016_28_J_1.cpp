#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <string>
#include <assert.h>

using namespace std;

#define mp make_pair
#define pb emplace_back
#define all(a) (a).begin(), (a).end()

typedef long long li;
typedef long double ld;

void solve();

int main() {
#ifdef ICL
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	cout.precision(20);
	cout << fixed;
	int t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
}

struct segm {
	int l, r;

	segm(int nl, int nr): l(nl), r(nr) {}

	bool operator < (const segm &s) const {
		return l < s.l;
	}
};

void solve() {
	int n;
	cin >> n;
	set<segm> segs;
	for (int i = 0; i < n; ++i) {
		int x, p;
		cin >> x;
		if (x > 0) {
			cin >> p;
			auto it = segs.upper_bound(segm(x, x));
			int start = x;
			if (it != segs.begin()) {
				--it;
				if (it->r >= x) start = it->r + 1;
			}
			it = segs.lower_bound(segm(start, start));
			int end = start + p - 1;
			if (it != segs.end()) {
				end = min(end, it->l - 1);
			}
			cout << start << " " << end << "\n";
			
			it = segs.lower_bound(segm(start, start));
			if (it != segs.begin()) {
				--it;
				if (it->r + 1 == start) {
					start = it->l;
					segs.erase(it);
				}
			}

			it = segs.upper_bound(segm(end, end));
			if (it != segs.end()) {
				if (end + 1 == it->l) {
					end = it->r;
					segs.erase(it);
				}
			}
			segs.insert(segm(start, end));
		}
		else {
			x = -x;
			auto it = segs.upper_bound(segm(x, x));
			if (it == segs.begin()) continue;
			--it;
			segm s = *it;
			segs.erase(it);
			if (s.l == s.r) continue;
			if (s.l == x) {
				segs.insert(segm(s.l + 1, s.r));
				continue;
			}
			if (s.r == x) {
				segs.insert(segm(s.l, s.r - 1));
				continue;
			}
			segs.insert(segm(s.l, x - 1));
			segs.insert(segm(x + 1, s.r));
		}
	}
}
