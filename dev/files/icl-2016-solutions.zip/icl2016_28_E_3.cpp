#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <string>
#include <assert.h>

using namespace std;

#define mp make_pair
#define pb emplace_back
#define all(a) (a).begin(), (a).end()

typedef long long li;
typedef long double ld;

void solve();

int main() {
#ifdef ICL
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	cout.precision(20);
	cout << fixed;
	int t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
}

ld PI = acosl(-1.0);
ld eps = 1e-9;

struct Point {
	ld x, y;
	Point() {}
	Point(ld x, ld y) :x(x), y(y) {}
	Point operator - (const Point& ot) const {
		return Point(x - ot.x, y - ot.y);
	}
	Point operator + (const Point& ot) const {
		return Point(x + ot.x, y + ot.y);
	}
	Point operator * (ld c) const {
		return Point(x * c, y * c);
	}
	ld operator % (const Point &p) const {
		return x * p.y - y * p.x;
	}
	ld operator * (const Point &p) const {
		return x * p.x + y * p.y;
	}
	Point rotate(ld alpha) const {
		return Point(x * cos(alpha) - y * sin(alpha), x * sin(alpha) + y * cos(alpha));
	}
	void scan() {
		cin >> x >> y;
	}
	ld sqrDist() const {
		return x * x + y * y;
	}
	ld dist() const {
		return hypotl(x, y);
	}
	Point normalized() const {
		return Point(x / dist(), y / dist());
	}
	bool operator == (const Point& ot) const {
		return fabs(x - ot.x) < eps && fabs(y - ot.y) < eps;
	}
};

ld sqr(ld x) {
	return x * x;
}

bool inter(const Point &a, const Point &b, const Point &c, ld R) {
	ld A = sqr(b.x - a.x) + sqr(b.y - a.y);
	ld B = 2 * (b.x - a.x) * (a.x - c.x) + (b.y - a.y) * (a.y - c.y);
	ld C = sqr(a.x - c.x) + sqr(a.y - c.y) - sqr(R);
	if (B * B - 4 * A * C < -eps) return false;
	if (!(-1 - eps <= B / (2 * A) && B / (2 * A) <= eps)) return false;
	return (C >= -eps && A + B + C >= -eps);
}

ld oncirc(const Point &a, const Point &b, const Point &c) {
	ld a1 = atan2l((a - c).y, (a - c).x);
	ld a2 = atan2l((b - c).y, (b - c).x);
	ld R = (a - c).dist();
	return R * min(fabsl(a1 - a2), 2 * PI - fabsl(a1 - a2));
}

Point steiner(const Point &a, const Point &b, const Point &c) {
	ld ab = (a - b).dist(), bc = (b - c).dist(), ac = (a - c).dist();
	ld alpha = acosl((sqr(ac) + sqr(ab) - sqr(bc)) / (2.0 * ac * ab));
	ld beta = acosl((sqr(ab) + sqr(bc) - sqr(ac)) / (2.0 * ab * bc));
	ld gamma = acosl((sqr(ac) + sqr(bc) - sqr(ab)) / (2.0 * ac * bc));
	if (alpha >= 2 * PI / 3) {
		return a;
	}
	if (beta >= 2 * PI / 3) {
		return b;
	}
	if (gamma >= 2 * PI / 3) {
		return c;
	}
	ld k1 = bc / sin(alpha + PI / 3);
	ld k2 = ac / sin(beta + PI / 3);
	ld k3 = ab / sin(gamma + PI / 3);
	ld s = k1 + k2 + k3;
	return (a * k1 + b * k2 + c * k3) * (1.0 / s);
}

ld getd(const Point &a, const Point &b, ld ang, ld R, bool hui = false) {
	Point c(R * cosl(ang), R * sinl(ang));
	Point s = steiner(a, b, c);
	return (s - a).dist() + (s - b).dist() + (s - c).dist();
}

void solve() {
	cout.precision(10);
	cout << fixed;
	Point a, b, c;
	ld R;
	cin >> a.x >> a.y >> b.x >> b.y >> c.x >> c.y >> R;
	if ((a - b).dist() < 0.01) {
		cout << (a - c).dist() - R << endl;
		return;
	}

	ld r1 = hypotl(a.x - c.x, a.y - c.y);
	ld r2 = hypotl(b.x - c.x, b.y - c.y);
	if (inter(a, b, c, R)) {
		ld alpha = acosl(R / r1);
		Point p1 = c + ((a - c).normalized() * R).rotate(alpha);
		Point p2 = c + ((a - c).normalized() * R).rotate(-alpha);

		ld beta = acosl(R / r2);
		Point q1 = c + ((b - c).normalized() * R).rotate(beta);
		Point q2 = c + ((b - c).normalized() * R).rotate(-beta);

		ld ans = (p1 - a).dist() + (q1 - b).dist();
		ans += min(
			min(oncirc(p1, q1, c), oncirc(p1, q2, c)), 
			min(oncirc(p2, q1, c), oncirc(p2, q2, c))
		);
		cout << ans << endl;
		return;
	}
	ld ang = fmodl(fabsl(atan2l((a - c) % (b - c), (a - c) * (b - c))), PI);
	ld l = 0, r = PI;
	a = Point(r1, 0);
	b = Point(r2 * cosl(ang), r2 * sinl(ang));
	for (int it = 0; it < 200; ++it) {
		ld m1 = (2 * l + r) / 3.0;
		ld m2 = (l + 2 * r) / 3.0;
		if (getd(a, b, m1, R) < getd(a, b, m2, R)) {
			r = m2;
		}
		else {
			l = m1;
		}
	}
	cout << getd(a, b, (l + r) / 2.0, R) << endl;
}
