#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int n;
    cin >> n;
    long long ans = 1, ans2 = 1;
    for (int i = 0; i < n; i++)
    {
        long long x, y;
        cin >> x >> y;
        if (i == 0) {
            ans = y;
        }
        else{
            ans = __gcd(ans, y);
        }

        ans2 = (ans2 * x) / __gcd(ans2, x);

    }
    cout << ans2 << ' ' << ans;
    return 0;
}
