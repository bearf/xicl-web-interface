#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)

// -- MAIN PART

const int M = 1e9 + 9;
long long ans = 1;
long long k;

long long pv(int x, long long k) {
	if (k == 0) return 1;
	long long r = pv(x, k / 2);
	r = r * r % M;
	if (k % 2) r = r * x % M;
	return r;
}

void solve(int x) {
	long long h = pv(x + 1, k) - 2ll * pv(x, k) + pv(x - 1, k);
	h %= M;
	if (h < 0) h += M;
	ans = (ans * h) % M;
}


int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	int a, b;
	cin >> k >> a >> b;
	if (b % a != 0) {
		puts("0");
		return 0;
	}
	b /= a;
	for (int i = 2; i * i <= b; i++) if (b % i == 0) {
		int t = 0;
		while (b % i == 0) {
			t++;
			b /= i;
		}
		solve(t);
	}
	if (b > 1) solve(1);
	cout << ans << endl;


	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
