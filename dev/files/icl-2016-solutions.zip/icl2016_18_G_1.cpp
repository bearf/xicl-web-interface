#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <functional>

using namespace std;

const int MAXN = 1000 + 10;
set<int> used;
vector<int> a;

int main() {
	int n;
	cin >> n;

	for (int i = 0; i < n; i++) {
		int v;
		cin >> v;
		a.push_back(v);
	}
	sort(begin(a),end(a), greater<int>());

	int res = 0;
	while (used.size() < n) {
		int j = -1;
		bool insert = false;
		for (int i = 0; i < n; i++) {
			if (j == -1 && used.find(i) == used.end())
				j = i;

			if (j != -1 && used.find(i) == used.end() && a[i] < a[j]) {
				used.insert(j);
				used.insert(i);
				j = i;
				insert = true;
			}
		}
		if (!insert) {
			used.insert(j);
		}
		res++;
	}
	cout << res;

	return 0;
}