#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

ll gcd(ll a, ll b) {
    return b ? gcd(b, a % b) : a;
}

ll lcm(ll a, ll b) {
    return a * b / gcd(a, b);
}

int main() {
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);

    int n;
    scanf("%d", &n);

    ll x = 1, y = 0;
    for (int i = 0; i < n; i++) {
        ll a, b;
        scanf("%lld%lld", &a, &b);
        x = lcm(x, a);
        y = gcd(y, b);
    }

    ll g = gcd(x, y);
    x /= g;
    y /= g;

    printf("%lld %lld\n", x, y);
}
