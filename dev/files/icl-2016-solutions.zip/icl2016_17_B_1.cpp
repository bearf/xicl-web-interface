#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

const int mod = 1e9 + 9;
const int M = 122;

int mul(ll x, ll y) {
    return x * y % mod;
}

int add(int x, int y) {
    return (x + y) % mod;
}

int sub(int x, int y) {
    return add(x, mod - y);
}

struct Matrix {
    int a[M][M];

    int* operator[](int x) {
        return a[x];
    }

    Matrix() {
        for (int i = 0; i < M; ++i)
            fill(a[i], a[i] + M, 0);
    }

    Matrix operator*(Matrix &to) {
        Matrix ans;
        for (int i = 0; i < M; ++i)
            for (int k = 0; k < M; ++k)
                for (int j = 0; j < M; ++j)
                    ans[i][j] = add(ans[i][j], mul(a[i][k], to[k][j]));
        return ans;
    }
} ONE, A;

Matrix bin(Matrix A, ll a) {
    Matrix B = ONE;
    while (a) {
        if (a & 1)
            B = B * A;
        A = A * A;
        a >>= 1;
    }
    return B;
}

ll n;
int m, c[M];

void ini() {
    for (int i = 0; i < M; ++i)
        ONE[i][i] = 1;
}

void read() {
    cin >> n;
    cin >> m;
    for (int i = 1; i <= m; ++i)
        cin >> c[i];
}

int get(int i, int j) {
    assert(0 <= i && i <= m);
    assert(0 <= j && j <= m);
    return i + (m + 1) * j;
}

void add(int ix, int jx, int iy, int jy, int cnt) {
    A[get(ix, jx)][get(iy, jy)] = add(A[get(ix, jx)][get(iy, jy)], cnt);
}

void build() {
    add(0, 0, 0, 0, c[2]); // 2 x 1

    for (int i = 1; i <= m; ++i)
        for (int j = 1; j <= m; ++j)
            add(0, 0, i - 1, j - 1, mul(c[i], c[j]));

    for (int i = 1; i <= m; ++i)
        for (int j = 1; j <= m; ++j)
            add(i, j, i - 1, j - 1, 1);

    for (int i = 1; i <= m; ++i) {
        for (int k = 1; k <= m; ++k) {
            int ti = i - 1;
            int tk = k - 1;
            add(i, 0, ti, tk, c[k]);
            add(0, i, tk, ti, c[k]);
        }
    }
}

int main() {
#ifdef LOCAL
    assert(freopen("b.in", "r", stdin));
#endif
    ini();
    read();
    build();
    Matrix B = bin(A, n);
    cout << B[0][0] << endl;
}
