#include <bits/stdc++.h>

using namespace std;

int q[1000], v[1000], n;

int main()
{
    cin >> n;
    for (int i = 0; i < n; i++)
        cin >> q[i], v[i] = 1;
    sort(q, q + n);
    int ans = 0;
    for (int i = n - 1; i >= 0; i--)
        if (v[i]){
            ans++;
            int d = q[i];
            v[i] = 0;
            for (int j = i - 1; j >= 0; j--)
                if (v[j] && q[j] < d)
                    d = q[j], v[j] = 0;
        }
    cout << ans;
}
