#include <iostream>
#include <utility>
#include <cmath>

#define PI 3.1415926535897932384626433832795

using namespace std;


bool inside;
typedef struct circle{
    double x,y,r;
};

bool is_inside(pair<double,double> p, circle c)
{
    double dx = c.x - p.first;
    double dy = c.y - p.second;
    double d = sqrt(dx*dx+dy*dy);
    return d <= c.r;
}

double dist(pair<double,double> p1, pair<double,double> p2)
{
    double dx = p1.first - p2.first;
    double dy = p1.second - p2.second;
    double d = sqrt(dx*dx+dy*dy);
    return d;
}

pair<double,double> bsearch(pair<double,double> s1,pair<double,double> s2, circle c, int direction)
{
    inside = false;
    pair<double,double> m;
    pair<double,double> pivot1 , pivot2;
    pivot1 = s1;
    pivot2 = s2;

    for(int i=0;i<200;i++)
    {
        m.first = (s1.first+s2.first)/2;
        m.second = (s1.second+s2.second)/2;
        //cout<<m.first<<" "<<m.second<<endl;
        if(is_inside(m,c))
        {
            //cout<<"inside"<<endl;
            if(direction == 0)
                s2 = m;
            else
                s1 = m;
            continue;
        }
        double d1 = dist(pivot1,make_pair(c.x,c.y));
        double d2 = dist(pivot1,m);
        //cout<<d1<<" "<<d2<<endl;
        if(d1<d2)
            s2 = m;
        else
            s1 = m;

    }

    //cout<<m.first<<" "<<m.second<<endl;
    return m;
}

int main()
{
    pair<double,double> s1,s2,p1,p2, i1,i2;
    circle c;
    cin>>s1.first>>s1.second>>s2.first>>s2.second;
    cin>>c.x>>c.y>>c.r;

    //Search 2 points
    i1 = bsearch(s1,s2,c,0);
    i2 = bsearch(s1,s2,c,1);

    double B = dist(i1,i2);

    double alpha;
    if(-(B/(2*c.r))<(-1))
        alpha = acos(-1);
    else if(-(B/(2*c.r))>1)
        alpha = acos(1);
    else
        alpha = acos((-(B/(2*c.r))));

    //cout<<(-(B/(2*c.r))<(-1))<<" "<<alpha<<endl;
    //cout<<B<<" "<<c.r<<endl;
    double beta = PI - 2*alpha;
    double C = 2*PI*c.r;
    double q = abs(C * (beta/(2*PI)));

    double total = dist(s1,i1)+abs(q)+dist(i2,s2);
    //cout<<C<<" "<<beta<<" "<<abs(q)<<endl;
    //cout<<dist(s1,i1)<<" "<<dist(i2,s2)<<" "<<q<<" "<<total<<endl;

    cout.precision(7);
    cout<<total;
    char w;
    //cin>>q;
    return 0;
}
