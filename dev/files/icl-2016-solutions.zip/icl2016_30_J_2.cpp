#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <set>	
#define ll long long
# define ull unsigned long long
using namespace std;

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ll n;
	cin >> n;
	vector <short> v(5 * 100000000 + 10001, 0);
	vector < tuple<ll, ll> > steps;
	for (ll i = 0; i < n; i++) {
		ll a, b;
		cin >> a;
		if (a > 0) {
			cin >> b;
			while (v[a] != 0)
				a++;
			ll k = a;
			while (b > 0 && v[a] == 0) {
				b--;
				v[a] = steps.size() + 1;
				a++;
			}
			steps.push_back(make_tuple(k, a-1));
			cout << k << " " << a - 1 << endl;
		}
		else {
			a = abs(a);
			ll step = v[a],
				l = get<0>(steps[step - 1]),
				r = get<1>(steps[step - 1]);
			for (ll i = l; i <= r; i++)
				v[i] = 0;
		}
	}
	return 0;
}