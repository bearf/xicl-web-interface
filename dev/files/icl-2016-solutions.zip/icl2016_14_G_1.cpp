/*
ICL 2016
Team: Mathematical Grammar School, Belgrade
*/
#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const int MAXN=10010;
int cnt[MAXN];
int main()
{
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++) {int foo;
    scanf("%d",&foo);
    cnt[foo]++;}
    vector<int> vx;
    for(int i=1;i<=10000;i++) if(cnt[i]>0) vx.push_back(cnt[i]);
    int ans=0;
    for(int i=0;i<vx.size()-1;i++)
    {
        ans+=max(0,vx[i]-vx[i+1]);
    }
    ans+=vx[vx.size()-1];
    printf("%d\n",ans);
    return 0;
}
