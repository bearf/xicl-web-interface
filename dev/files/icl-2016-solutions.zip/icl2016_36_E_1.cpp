#include <bits/stdc++.h>

using namespace std;

struct point{
    double x, y;
};

point make_point(double x, double y){
    point ret;
    ret.x = x;
    ret.y = y;
    return ret;
}

double cp(point a, point b){
    return a.x * b.y - a.y * b.x;
}

double dp(point a, point b){
    return a.x * b.x + a.y * b.y;
}

double get_angle(point a, point b, point c){
    point aa = make_point(a.x - c.x, a.y - c.y);
    point bb = make_point(b.x - c.x, b.y - c.y);
    return atan2(fabs(cp(aa, bb)), dp(aa, bb));
}

double r;
point o;

double dist(point a, point b){
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

double duglen(point a, point b){
    return r * r * min(get_angle(a, b, o), atan2(0, -1) - get_angle(a, b, o));
}


int main()
{
    point a, b;
    cin >> a.x >> a.y >> b.x >> b.y;
    point o;
    cin >> o.x >> o.y >> r;

    point af, as, bf, bs;
    cout << fixed << setprecision(10);
    point oo = make_point(o.x - a.x, o.y - a.y);
    point bb = make_point(b.x - a.x, b.y - a.y);
    point aa = make_point(a.x - b.x, a.y - b.y);
    point ooo = make_point(o.x - b.x, o.y - b.y);
    double dista;
    if (dp(oo, bb) < 0 || dp(ooo, aa) < 0){
        dista = min(dist(o, a), dist(o, b));
    }
    else{
        double A = a.y - b.y;
        double B = b.x - a.x;
        double C = -A * b.x - B * b.y;

        dista = fabs((A * o.x + B * o.y + C) / sqrt(A * A + B * B));
    }

    if (dista >= r){
        cout << dist(a, b);
        return 0;
    }
    else{
        point oa = make_point(o.x - a.x, o.y - a.y);
        double d = dist(a, o);
        double len = sqrt(d * d - r * r);
        double x = r * r / d;
        double y = sqrt(r * r - x * x);
        point per = make_point(oa.x / d * x, oa.y / d * x);
        af = make_point(-oa.y / d * y, oa.x / d * y);
        as = make_point(-af.x, -af.y);

        oa = make_point(o.x - b.x, o.y - b.y);
        d = dist(b, o);
        len = sqrt(d * d - r * r);
        x = r * r / d;
        y = sqrt(r * r - x * x);
        per = make_point(oa.x / d * x, oa.y / d * x);
        bf = make_point(-oa.y / d * y, oa.x / d * y);
        bs = make_point(-bf.x, -bf.y);

        double ans = 1e18;
        ans = min(ans, dist(a, af) + duglen(af, bf) + dist(bf, b));
        ans = min(ans, dist(a, af) + duglen(af, bs) + dist(bs, b));
        ans = min(ans, dist(a, as) + duglen(as, bf) + dist(bf, b));
        ans = min(ans, dist(a, as) + duglen(as, bs) + dist(bs, b));

        cout << ans;
    }
}
