#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)

// -- MAIN PART

int d[] = {5, 3, 4, 1, 2, 0}; 

int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif

	string s, t;
	cin >> s >> t;
	int n = s.size();
	double ans = 1;
	for (int i = 0; i < n; i++) {
		string c;
		cin >> c;
		int cnt = 0;
		double cur = 0;
	    int x = 0;
	    for (int j = 0; j < 3; j++) {
	    	if (c[j] == t[i] || (c[d[j]] == t[i])) {
	    		x++;
	    	}	
	    }
		for (int j = 0; j < 6; j++) {
			if (c[j] == s[i]) {
				cnt++;
				if (c[j] == t[i] || (c[d[j]] == t[i])) {
					cur += 1;
				} else {
					cur += 0.5 * x;
				}
			}
		}
		cur /= cnt;
		ans *= cur;
	}
	cout << ans;


	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
