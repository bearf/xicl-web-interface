#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <string>
using namespace std;
int main() {
	string s;
	getline(cin, s);
	int c = s.size();
	vector<char> v(c);
	int n; int pr = 0;
	cin >> n;
	int a, b;
	cin >> a;
	for (int i = 0; i < n-1; i++) {
		cin >> b;
		if (a == b) {
			cin >> a; 
			i++;
			pr++;
			if (i == n - 2)
				pr = 0;
			continue;
		}
		else {
			reverse(s.begin(), s.begin() + a);
			reverse(s.begin() + a, s.end());
			a = b;
			pr = 0;

	
		}
	}
	if (pr == 0) {
		reverse(s.begin(), s.begin() + a);
		reverse(s.begin() + a, s.end());
	}
	cout << s;

}