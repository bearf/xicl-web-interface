#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

const ld eps = 1e-9;

bool eq(ld a, ld b) {
    return fabsl(a - b) < eps;
}

struct pt {
    ld x, y;

    pt operator-(const pt &p) const {
        return pt{x - p.x, y - p.y};
    }

    pt operator+(const pt &p) const {
        return pt{x + p.x, y + p.y};
    }

    ld operator*(const pt &p) const {
        return x * p.x + y * p.y;
    }

    ld operator%(const pt &p) const {
        return x * p.y - y * p.x;
    }

    pt operator*(const ld &a) const {
        return pt{x * a, y * a};
    }

    bool operator==(const pt &p) const {
        return eq(x, p.x) && eq(y, p.y);
    }

    ld abs() const {
        return hypotl(x, y);
    }

    ld abs2() const {
        return x * x + y * y;
    }

    pt rrot() const {
        return pt{y, -x};
    }

    pt rot() const {
        return pt{-y, x};
    }
};

istream &operator>>(istream &in, pt &p) {
    return in >> p.x >> p.y;
}

ostream &operator<<(ostream &out, pt p) {
    return out << p.x << ' ' << p.y << '\n';
}

const ld maxc = 45000;

pt a, b, c;
ld r;

pt Tx(pt a, pt b, pt c, ld x) {
    ld L = -maxc, R = maxc;
    forn (iter, 100) {
        const ld C1 = 6, C2 = 5;
        ld xl = (L * C1 + R * C2) / (C1 + C2);
        ld xr = (L * C2 + R * C1) / (C1 + C2);
        pt pl = pt{x, L};
        pt pr = pt{x, R};
        ld dl = (a - pl).abs() + (b - pl).abs() + (c - pl).abs();
        ld dr = (a - pr).abs() + (b - pr).abs() + (c - pr).abs();
        if (dl < dr)
            R = xr;
        else
            L = xl;
    }
    return pt{x, L};
}

pt T(pt a, pt b, pt c) {
    ld L = -maxc, R = maxc;
    forn (iter, 100) {
        const ld C1 = 6, C2 = 5;
        ld xl = (L * C1 + R * C2) / (C1 + C2);
        ld xr = (L * C2 + R * C1) / (C1 + C2);
        pt pl = Tx(a, b, c, xl);
        pt pr = Tx(a, b, c, xr);
        ld dl = (a - pl).abs() + (b - pl).abs() + (c - pl).abs();
        ld dr = (a - pr).abs() + (b - pr).abs() + (c - pr).abs();
        if (dl < dr)
            R = xr;
        else
            L = xl;
    }
    return Tx(a, b, c, L);
}

const ld SEP = 40000;
const ld PI = acosl(-1);

ld res = 1e18;

ld forAng(ld al) {
    pt pl = pt{cosl(al), sinl(al)};
    pl = pl * r;
    return (a - pl).abs() + (b - pl).abs();
}

ld dist(pt p, pt a, pt b) {
    ld res = min((a - p).abs(), (b - p).abs());
    if ((p - a) * (b - a) >= 0 && (p - b) * (a - b) >= 0) {
        res = fabsl((b - a) % (p - a)) / (a - b).abs();
    }
    return res;
}

vector<pt> tangent(pt a) {
    pt h = (a - c);
    h = h * ((r * r) / h.abs2());
    h = h + c;
    ld d = sqrtl(max(ld(0), r * r - h.abs2()));
    pt v = (a - c).rot();
    v = v * (d / v.abs());
    return {h + v, h - v};
}

ld circleDist(pt a, pt b) {
    ld ang1 = atan2l(a.y, a.x);
    ld ang2 = atan2l(b.y, b.x);
    if (ang1 > ang2)
        swap(ang1, ang2);
    return r * min(ang2 - ang1, 2 * PI + ang1 - ang2);
}

void solveHard() {
    //cerr << "slozhno\n";
    auto va = tangent(a);
    auto vb = tangent(b);
    for (auto p: va) {
        assert(eq((p - c).abs(), r));
        assert(eq((a - p) * (c - p), 0));
    }
    for (auto p: vb) {
        assert(eq((p - c).abs(), r));
        assert(eq((b - p) * (c - p), 0));
    }
    for (auto pa: va)
        for (auto pb: vb) {
            ld cres = circleDist(pa, pb) + (pa - a).abs() + (pb - b).abs();
            res = min(res, cres);
        }
    cout << res << '\n';
}

bool lt(ld a, ld b) {
    return b - a > eps;
}

void solve() {
    if (lt(dist(c, a, b), r)) {
        solveHard();
        return;
    }
    forn (iter, SEP + 1) {
        ld L = iter * (2 * PI) / SEP;
        ld R = (iter + 1) * (2 * PI) / SEP;
        forn (qwer, 100) {
            const ld C1 = 6, C2 = 5;
            ld al = (L * C1 + R * C2) / (C1 + C2);
            ld ar = (L * C2 + R * C1) / (C1 + C2);

            ld ldist = forAng(al);
            ld rdist = forAng(ar);
            if (ldist < rdist)
                R = ar;
            else
                L = al;
        }
        res = min(res, forAng(L));
    }
    pt t = T(a, b, c);
    if ((t - c).abs() >= r) {
        ld cres = (t - a).abs() + (t - b).abs() + (t - c).abs() - r;
        res = min(res, cres);
    }

    cout << res << '\n';
}

int main() {
    cout.precision(10);
    cout.setf(ios::fixed);
#ifdef LOCAL
    assert(freopen("e.in", "r", stdin));
#endif
    //cerr << T(pt{0, 0}, pt{0, 10}, pt{10, 0}) << endl;
    //return 0;
    cin >> a >> b >> c >> r;
    a = a - c;
    b = b - c;
    c = c - c;
    solve();
}
