#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())



int main() {
#ifdef LOCAL
    assert(freopen("g.in", "r", stdin));
#endif
    map<int, int> cnt;
    int n;
    cin >> n;
    while (n--) {
        int x;
        cin >> x;
        cnt[x]++;
    }
    int ans = 0;
    for (auto p : cnt)
        ans = max(ans, p.second);
    cout << ans << endl;
}
