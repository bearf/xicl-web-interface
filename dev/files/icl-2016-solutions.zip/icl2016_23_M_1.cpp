#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <math.h>

#define re return

typedef long long ll;
typedef unsigned long long ull;

using namespace std;

ll nod(ll a, ll b) {
	if (b == 0)
		re a;
	else re nod(b, a % b);
}

ll nok(ll a, ll b) {
	re(a*b) / nod(a, b);
}


int main() {
	int n;
	cin >> n;
	ll a;
	cin >> a;
	ll b;
	cin >> b;
	for (int i = 1; i < n; ++i) {
		ll x, y;
		cin >> x >> y;
		a = nok(a, x);
		b = nod(b, y);
	}

	ll k = nod(a, b);
	a /= k;
	b /= k;

	cout << a << " " << b;
	re 0;
}
