#include <bits/stdc++.h>
#define mp make_pair
#define endl "\n"
#define F first
#define S second
#define int long long

const double eps = 0.0000000001;
typedef long long ll;
using namespace std;

int gcd(int a, int b){
    while (b != 0){
        a = (a%b);
        swap(a,b);
    }
    return a;
}


int pow(int a, int b) {
    if (b == 0) {
        return 1;
    }

    if (b % 2 == 0) {
        int res = pow(a, b / 2);

        return res *res;
    }
    else {
        return a * pow(a, b - 1);
    }
}

main() {
    #ifdef _HOME_
        freopen("input.txt", "r", stdin);
    #endif // _HOME_
    int n;
    cin >> n;
    vector <pair<int, int> > arr(n);
    for (int i =0; i < n; i++){
        cin >> arr[i].F >> arr[i].S;
    }
    int zn = arr[0].S;
    for (int i = 1; i < n; i++){
        zn = gcd(zn, arr[i].S);
    }

    map <int, int> d;
    map <int, int> lol;

    ll ch = 1;

    for (int i = 0; i < n; ++i) {
        int x = 2;
        lol.clear();

        while (arr[i].F != 1) {
            while (arr[i].F % x == 0) {
                lol[x]++;
                arr[i].F /= x;
            }
            x++;
        }

        for (auto in : lol) {
            d[in.F] = max(d[in.F], in.S);
        }
    }
    for (auto in : d) {
        ch *= pow(in.F, in.S);
    }

    int k = gcd(ch, zn);
    zn /= k;
    ch /= k;

    cout << ch << " " << zn;

    //sokratit
}
