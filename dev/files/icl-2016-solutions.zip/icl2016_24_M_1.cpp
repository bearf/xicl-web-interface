#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;
typedef long long ll;


ll gcd(ll a, ll b)
{
	while (b)
	{
		a %= b;
		swap(a, b);
	}

	return a;
}


int main()
{
	ll n;
	ll a[7];
	ll b[7];

	long long _;
	cin >> _;
	n = _;

	for (int i = 0; i < n; i++)
	{
		cin >> b[i] >> a[i];
		ll g = gcd(a[i], b[i]);
		b[i] /= g;
		a[i] /= g;
	}

	ll e = 1;

	for (int i = 0; i < n; i++)
	{
		e *= b[i] / gcd(e, b[i]);
	}
	
	ll f = e * a[0] / b[0];

	for (int i = 0; i < n; i++)
	{
		f = gcd(f, a[i] * e / b[i]);
	}


	cout << (ll)e << ' ' << (ll)f << endl;

#ifdef AWWW
	system("pause");
#endif
}