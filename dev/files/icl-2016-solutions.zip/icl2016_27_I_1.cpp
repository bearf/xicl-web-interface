#include <bits/stdc++.h>
#define fi first
#define se second
#define MP make_pair
using namespace std;

typedef long long ll;
typedef pair <int, int> pi;

struct CH {
    ll a[4];
    void read() {
        for (int i = 0; i < 4; i++)
            scanf("%lld", &a[i]);
    }
};
inline bool operator < (const CH & b, const CH & c) {
    for (int i = 0; i < 4; i++) {
        if (b.a[i] == c.a[i]) continue;
        return b.a[i] < c.a[i];
    }
    return false;
}

ll dist(CH z1, CH z2) {
    ll ans = 0;
    for (int i = 0; i < 4; i++)
        ans += abs(z1.a[i] - z2.a[i]);
    return ans;
}

int cnt = 0;
set <pair <ll, int> > q[16];
map <ll, CH> num;
map <CH, int> revnum;
void add(CH z) {
    num[cnt++] = z;
    revnum[z] = cnt - 1;
    for (int mask = 0; mask < 16; mask++) {
        ll cursum = 0;
        for (int i = 0; i < 4; i++) {
            if ((mask >> i) & 1) cursum += z.a[i];
            else cursum -= z.a[i];
        }
        q[mask].insert(MP(cursum, cnt - 1));
    }
}

void del(CH z) {
    int curnum = revnum[z];
    for (int mask = 0; mask < 16; mask++) {
        ll cursum = 0;
        for (int i = 0; i < 4; i++) {
            if ((mask >> i) & 1) cursum += z.a[i];
            else cursum -= z.a[i];
        }
        q[mask].erase(MP(cursum, curnum));
    }
}

ll ans(CH z) {
    int tmp;
    ll ret = -1;
    for (int i = 0; i < 16; i++) {
        tmp = q[i].begin()->se;
        ret = max(ret, dist(z, num[tmp]));
        tmp = q[i].rbegin()->se;
        ret = max(ret, dist(z, num[tmp]));
    }
    return ret;
}

int main() {
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
    int n, type;
    scanf("%d", &n);
    CH cur;

    while (n--) {
        scanf("%d", &type);
        cur.read();
        if (type == 1) add(cur);
        if (type == 2) del(cur);
        if (type == 3) printf("%lld\n", ans(cur));
    }
}
