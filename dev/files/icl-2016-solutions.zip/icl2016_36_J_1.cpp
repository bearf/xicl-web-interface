#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const ll inf = 1e18;

set<pair<ll, ll> > q;

set<pair<ll, ll> > :: iterator it, i, j;

int main()
{
    //ifstream cin("a.in");
    //ofstream cout("a.out");
    ios::sync_with_stdio(0);
    int zap;
    cin >> zap;
    for (int iter = 0; iter < zap; iter++){
        ll x;
        cin >> x;
        if (x < 0){
            x = -x;
            it = q.upper_bound(make_pair(x, inf));
            it--;
            if (it != q.end() && it->first <= x && it->second >= x){
                int l = it->first;
                int r = it->second;
                q.erase(it);
                if (l < x)
                    q.insert(make_pair(l, x - 1));
                if (r > x)
                    q.insert(make_pair(x + 1, r));
            }
        }
        else{
            ll p;
            cin >> p;
            if (q.empty()){
                q.insert(make_pair(x, x + p - 1));
                cout << x << ' ' << x + p - 1 << '\n';
                continue;
            }
            it = q.upper_bound(make_pair(x, inf));
            i = it;
            it--;
            if (it != q.end() && it->first <= x && it->second >= x){
                if (i != q.end() && it->second + p >= i->first - 1)
                    cout << it->second + 1 << ' ' << i->first - 1 << '\n', q.erase(i), q.erase(it), q.insert(make_pair(it->first, i->second));
                else
                    cout << it->second + 1 << ' ' << it->second + p << '\n', q.erase(it), q.insert(make_pair(it->first, it->second + p));
            }
            else{
                if (i != q.end() && x + p - 1 >= i->first - 1)
                    cout << x << ' ' << i->first - 1 << '\n', q.erase(i), q.insert(make_pair(x, i->second));
                else
                    cout << x << ' ' << x + p - 1 << '\n', q.insert(make_pair(x, x + p - 1));
            }
        }
    }
}
