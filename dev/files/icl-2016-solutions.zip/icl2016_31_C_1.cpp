#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < n; i++)

typedef long long ll;
typedef long double ld;

const int INF = 2e9;
const ll INF64 = 9e18;
const int N = 200100;

int n;
ld ans = 1;
string s1, s2, s;

bool get(string s, char x, char y)
{
    int xx = 0 , yy = 0;
    forn(i, s.size())
        {
            if (s[i] == x)
                xx++;
            if (s[i] == y)
                yy++;
        }
    return (xx && yy);
}

bool ch(string s, char x, char y)
{
    int xx = 0 , yy = 0;
    forn(i, s.size())
        {
            if (s[i] == x)
                xx++;
        }
    return (xx);
}



int main()
{
    cin >> s1 >> s2;
    n = s1.size();
    forn(i, n)
    {
        cin >> s;
        s = " " + s;
        if (s1[i] != s2[i])
        {
            int k = 0, kk = 0;
            string ss = "";
            ss = ss + s[5] + s[1] + s[3] + s[6];
            if (ch(ss, s1[i], s2[i]))
            {
            if (get(ss, s1[i], s2[i]))
                k++;
                kk++;
            }
            ss = "";
            ss = ss + s[5] + s[2] + s[3] + s[4];
            if (ch(ss, s1[i], s2[i]))
            {
             if (get(ss, s1[i], s2[i]))
                k++;
            kk++;

            }
            ss = "";

            ss = ss + s[2] + s[1] + s[4] + s[6];
            if (ch(ss, s1[i], s2[i]))
            {
             if (get(ss, s1[i], s2[i]))
                k++;
            kk++;
            }
            if (k != 0)
            ans = (ans * ((ld(1) / ld(kk) * ld(k))));
            else
                ans = 0;
        }
    }


    cout << setprecision(16) << fixed << ans;
    return 0;
}

/*

HALLW
HELLO
XABCDH
XAECDe
AbcdeL
AbcdeL
ABOWCD

*/

