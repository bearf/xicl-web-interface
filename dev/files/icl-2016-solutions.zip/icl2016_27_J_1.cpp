#include <bits/stdc++.h>
#define fi first
#define se second
using namespace std;

typedef long long ll;

const ll INF = 2e15;

int main() {
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);

    int n;
    scanf("%d", &n);

    set< pair<ll, ll> > q;
    for (int i = 0; i < n; i++) {
        ll x;
        scanf("%lld", &x);

        if (x < 0) {
            x = -x;
            auto it = q.upper_bound({x, INF});
            if (it != q.begin()) {
                it--;
                ll l = it->fi, r = it->se;
                if (l <= x && x <= r) {
                    q.erase(it);
                    if (l <= x - 1) {
                        q.insert({l, x - 1});
                    }
                    if (x + 1 <= r) {
                        q.insert({x + 1, r});
                    }
                }
            }
        } else {
            ll y;
            scanf("%lld", &y);

            auto it = q.upper_bound({x, INF});

            ll ansl, ansr;
            if (it != q.begin()) {
                it--;
                ll l1 = it->fi, r1 = it->se;
                it++;
                if (it != q.end()) {
                    ll l2 = it->fi, r2 = it->se;
                    if (x <= r1) {
                        ansl = r1 + 1;
                    } else {
                        ansl = x;
                    }
                    if (l2 <= ansl + y - 1) {
                        ansr = l2 - 1;
                    } else {
                        ansr = ansl + y - 1;
                    }

                    if (r1 + 1 == ansl && ansr + 1 == l2) {
                        q.erase({l1, r1});
                        q.erase({l2, r2});
                        q.insert({l1, r2});
                    } else if (r1 + 1 == ansl) {
                        q.erase({l1, r1});
                        q.insert({l1, ansr});
                    } else if (ansr + 1 == l2) {
                        q.erase({l2, r2});
                        q.insert({ansl, r2});
                    } else {
                        q.insert({ansl, ansr});
                    }
                } else {
                    if (x <= r1) {
                        ansl = r1 + 1;
                    }
                    ansr = ansl + y - 1;
                    if (r1 + 1 == ansl) {
                        q.erase({l1, r1});
                        q.insert({l1, ansr});
                    } else {
                        q.insert({ansl, ansr});
                    }
                }
            } else if (it != q.end()) {
                ll l2 = it->fi, r2 = it->se;
                ansl = x;
                if (ansl + y - 1 >= l2) {
                    ansr = l2 - 1;
                } else {
                    ansr = ansl + y - 1;
                }
                if (ansr + 1 == l2) {
                    q.erase({l2, r2});
                    q.insert({ansl, r2});
                } else {
                    q.insert({ansl, ansr});
                }
            } else {
                ansl = x, ansr = x + y - 1;
                q.insert({ansl, ansr});
            }

            printf("%lld %lld\n", ansl, ansr);
            /*
            cout << "SET" << endl;
            for (auto x : q) {
                cout << x.fi << ' ' << x.se << endl;
            }
            cout << "------" << endl;*/
        }
    }
}
