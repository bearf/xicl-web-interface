#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdint.h>
#include <string>
using namespace std;
typedef long long ll;

struct gavno
{
	int a[4];

	gavno(int b[4])
	{
		a[0] = b[0];
		a[1] = b[1];
		a[2] = b[2];
		a[3] = b[3];
	}

	gavno()
	{
		a[0] = a[1] = a[2] = a[3] = 0;
	}
};

int msk;

int g(const gavno &a)
{
	int ans = 0;
	for (int i = 0; i < 4; ++i)
	{
		if ((msk >> i) & 1)
		{
			ans += a.a[i];
		}
		else
		{
			ans -= a.a[i];
		}
	}
	return ans;
}

inline int f(const gavno &a, const gavno &b)
{
	int ans = 0;
	for (int i = 0; i < 4; ++i)
		ans += abs(a.a[i] - b.a[i]);
	return ans;
}

struct cmp
{
	bool operator()(const gavno &a, const gavno &b)
	{
		return g(a) < g(b);
	}
};

set<gavno, cmp> s[16];

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
#ifdef AWWW
	freopen("input.txt", "r", stdin);
#endif
	


	int n;
	cin >> n;

	for (int i = 0; i < n; ++i)
	{
		int a[4];
		int t;
		cin >> t >> a[0] >> a[1] >> a[2] >> a[3];

		if (t == 1)
		{
			for (int j = 0; j < (1 << 4); ++j)
			{
				msk = j;
				s[j].insert(gavno(a));
			}
		}
		else if (t == 2)
		{
			for (int j = 0; j < (1 << 4); ++j)
			{
				msk = j;
				s[j].erase(gavno(a));
			}
		}
		else
		{
			int ans = 0;
			for (int j = 0; j < (1 << 4); ++j)
			{
				int k = 0;
				for (auto it = s[j].begin(); it != s[j].end() && k < 5; ++k)
				{
					ans = max(ans, f(gavno(a), *it));
				}
			}
			cout << ans << endl;
		}
	}

#ifdef AWWW
	while (true) {}
#endif
}