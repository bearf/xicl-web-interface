#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;

int main()
{
	int n;
	cin >> n;

	vector<int> a(n);
	for (int i = 0; i < n; ++i)
		cin >> a[i];

	sort(a.begin(), a.end());
	multiset<int> s;
	s.insert(a[0]);

	for (int i = 1; i < n; ++i)
	{
		auto it = s.lower_bound(a[i]);
		if (it == s.begin())
		{
			s.insert(a[i]);
		}
		else
		{
			--it;
			s.erase(it);
			s.insert(a[i]);
		}
	}

	cout << s.size() << endl;
#ifdef AWWW
	system("pause");
#endif
}