#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <string>
#include <map>
#include <queue>
#include<iostream>
#define ll long long int
#define d double
#define mp make_pair
using namespace std;
const ll mod=1e9+9;
double pi=3.1415926535897932384626433832795;
#pragma warning(disable:4996)



pair<double,double> goodluck(d a,d b,d c) {
	d disc=b*b-4*a*c;
	d x1=(-b+sqrt(disc))/(2.0*a);
	d x2=(-b-sqrt(disc))/(2.0*a);
	return mp(x1,x2);
}

vector<double> f(double a2,double b2,d a3,d b3,d r1,d r3) {
	if(a3==a2) {
		d t=(r1*r1-r3*r3-b2*b2+b3*b3)/(2*b3-2*b2);
		vector<d> v;
		pair<d,d> z=goodluck(1,-2*a2,a2*a2+(t-b2)*(t-b2)-r1*r1);
		v.push_back(z.first);
		v.push_back(t);
		v.push_back(z.second);
		v.push_back(t);
		return v;
	}
	d p=(2*b2-2*b3)/(2*a3-2*a2);
	d q=(-a2*a2-b2*b2+a3*a3+b3*b3+r1*r1-r3*r3)/(2*a3-2*a2);
	d a=p*p+1;
	d b=2.0*p*q-2.0*a2*p-2.0*b2;
	d c=a2*a2+b2*b2-r1*r1+q*q-2.0*a2*q;
	pair<d,d> t=goodluck(a,b,c);
	vector<d> v;
	v.push_back(t.first*p+q);
	v.push_back(t.first);
	v.push_back(t.second*p+q);
	v.push_back(t.second);
	return v;
}

double a1,b1,a2,b2,a3,b3,alfa,beta;

bool check(d x,d y) {
	d A=(a3-a2)*(a3-a2)+(b3-b2)*(b3-b2);
	d B=(a3-x)*(a3-x)+(b3-y)*(b3-y);
	d C=(a2-x)*(a2-x)+(b2-y)*(b2-y);
	d D=(a2-a1)*(a2-a1)+(b2-b1)*(b2-b1);
	d E=(x-a1)*(x-a1)+(y-b1)*(y-b1);
	if(abs(A-(B+C-2*sqrt(C*B)*cos(beta)))<1e-8&&abs(D-(E+C-2*sqrt(C*E)*cos(alfa)))<1e-8&&(abs(x-a2)>1e-8||abs(y-b2)>1e-8)&&(abs(x-a3)>1e-8||abs(y-b3)>1e-8)&&(abs(x-a1)>1e-8||abs(y-b1)>1e-8)) return true;
	return false;
}


int main() {
#ifdef _DEBUG
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
#endif
	int n,i,j;

	scanf("%d",&n);

	for(i=0;i<n;i++) {
		scanf("%lf%lf%lf%lf%lf%lf%lf%lf",&a1,&b1,&a2,&b2,&a3,&b3,&alfa,&beta);
		alfa=(alfa/180)*pi;
		beta=(beta/180)*pi;
		double r1=(sqrt((a1-a2)*(a1-a2)+(b1-b2)*(b1-b2))/sin(alfa))/2;
		double r3=(sqrt((a3-a2)*(a3-a2)+(b3-b2)*(b3-b2))/sin(beta))/2;
		vector<d> v1,v3,v;
		v1=f(a1,b1,a2,b2,r1,r1);
		v3=f(a2,b2,a3,b3,r3,r3);
		v=f(v1[0],v1[1],v3[0],v3[1],r1,r3);
		if(check(v[0],v[1])) {
			printf("%.10lf %.10lf\n",v[0],v[1]);
			continue;
		}
		if(check(v[2],v[3])) {
			printf("%.10lf %.10lf\n",v[2],v[3]);
			continue;
		}
		v=f(v1[0],v1[1],v3[2],v3[3],r1,r3);
		if(check(v[0],v[1])) {
			printf("%.10lf %.10lf\n",v[0],v[1]);
			continue;
		}
		if(check(v[2],v[3])) {
			printf("%.10lf %.10lf\n",v[2],v[3]);
			continue;
		}
		v=f(v1[2],v1[3],v3[2],v3[3],r1,r3);
		if(check(v[0],v[1])) {
			printf("%.10lf %.10lf\n",v[0],v[1]);
			continue;
		}
		if(check(v[2],v[3])) {
			printf("%.10lf %.10lf\n",v[2],v[3]);
			continue;
		}
		v=f(v1[2],v1[3],v3[0],v3[1],r1,r3);
		if(check(v[0],v[1])) {
			printf("%.10lf %.10lf\n",v[0],v[1]);
			continue;
		}
		if(check(v[2],v[3])) {
			printf("%.10lf %.10lf\n",v[2],v[3]);
			continue;
		}
	}



	return 0;
}