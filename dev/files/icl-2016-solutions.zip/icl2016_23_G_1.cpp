#pragma once
#pragma once
#pragma once
#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <math.h>

#define long long ll
#define unsigned long long ull

using namespace std;

int main() {

	int n;
	map<int, int> m;
	vector<int> a;
	cin >> n;
	int mmax = -1;
	int tmp = 0;
	for (int i = 0; i < n; i++) {
		cin >> tmp;
		if (m.find(tmp) == m.end())
			m[tmp] = 1;
		else
			m[tmp]++;
	}
	int val = 0;
	for (auto ii = m.begin(); ii != m.end(); ii++) {
		if (ii->second > mmax) {
			val = ii->first;
			mmax = ii->second;
		}

	}

	cout << mmax;

	return 0;

}