program d;

{$APPTYPE CONSOLE}

uses
  SysUtils;

var z,x,c,n,sum,i,l,k:int64;
begin
  { TODO -oUser -cConsole Main : Insert code here }
  read(l,n,k);
  if (l>n) or (n=1) or (k=1) then begin
                             writeln(0);
                             readln;readln;
                             exit;
  end;
  if n=k then begin
        writeln(n-l);
        readln;readln;
        exit;
  end;
       i:=0;
            while(i<>l) do begin
              sum:=0;
              x:=n div k;
              z:=n mod k;
                if z<3 then begin
                     if x>0 then begin
                          n:=n-z;
                          c:=n div (2*x);
                          i:=i+c;
                          sum:=sum+(n-(c*2*x));
                     n:=sum;
                     end
                     else begin
                         writeln(0);
                         exit;
                     end;
                end
                else begin
                     c:=z div (2*x+1);
                     i:=i+c;
                     sum:=sum+(n-(c*(2*x+1)));
                     n:=sum;
                end;
                if sum=0 then begin
                     writeln(0);
                     exit;
                end;
            end;
            writeln(sum);
            readln;readln;
end.