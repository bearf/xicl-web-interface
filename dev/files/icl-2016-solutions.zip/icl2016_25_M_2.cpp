#include <cstdio>
#include <algorithm>
#include <iostream>
#include <set>
#include <map>
#include <vector>
#include <cstring>
#include <string>
#include <cmath>

#pragma warning (disable : 4996)

#define put push_back
#define mapa make_pair

using namespace std;

int n, a, b, nod, nok;

long long gcd(long long a, long long b) {
	while (a > 0 && b > 0) {
		if (a < b) {
			swap(a, b);
		}
		a = a % b;
	}
	return a + b;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
#ifndef _DEBUG
	//freopen("kek.in", "r", stdin);
	//freopen("kek.out", "w", stdout);
#endif
	cin >> n;
	cin >> a >> b;
	nok = a;
	nod = b;
	for (int i = 1; i < n; i++) {
		cin >> a >> b;
		nok = nok * a / gcd(nok, a);
		nod = gcd(nod, b);
	}
	cout << nok / gcd(nok, nod) << " " << nod / gcd(nok, nod);
	return 0;
}