#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <string>

using namespace std;

#define mp make_pair
#define pb emplace_back
#define all(a) (a).begin(), (a).end()

typedef long long li;
typedef long double ld;

void solve();

int main() {
#ifdef ICL
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	int t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
}

typedef struct node* pnode;

struct node {
	pnode left, right;
	int prior, sz;
	bool rev;
	char c;

	node(char nc) {
		left = right = nullptr;
		prior = rand();
		sz = 1;
		rev = false;
		c = nc;
	}
};

inline int getsz(pnode v) {
	return v ? v->sz : 0;
}

inline void update(pnode v) {
	if (!v) return;
	v->sz = getsz(v->left) + getsz(v->right) + 1;
}

inline void push(pnode v) {
	if (!v || !v->rev) return;
	if (v->left) v->left->rev ^= true;
	if (v->right) v->right->rev ^= true;
	swap(v->left, v->right);
	v->rev = false;
}

void split(pnode v, pnode &l, pnode &r, int k) {
	push(v);
	if (!v) {
		l = r = nullptr;
		return;
	}
	int vkey = getsz(v->left);
	if (vkey < k) {
		split(v->right, v->right, r, k - vkey - 1);
		l = v;
	}
	else {
		split(v->left, l, v->left, k);
		r = v;
	}
	update(v);
}

void merge(pnode &v, pnode l, pnode r) {
	push(l);
	push(r);
	if (!l || !r) {
		v = l ? l : r;
		return;
	}
	if (l->prior < r->prior) {
		merge(l->right, l->right, r);
		v = l;
	}
	else {
		merge(r->left, l, r->left);
		v = r;
	}
	update(v);
}

void print(pnode v) {
	push(v);
	if (!v) return;
	print(v->left);
	putchar(v->c);
	print(v->right);
}

void solve() {
	cin.sync_with_stdio(false);
	string s;
	int n;
	cin >> s >> n;
	int l = s.length();
	pnode root = nullptr;
	for (int j = 0; j < l; ++j) {
		merge(root, root, new node(s[j]));
	}
	for (int i = 0; i < n; ++i) {
		int x;
		cin >> x;
		pnode l = nullptr, r = nullptr;
		split(root, l, r, x);
		if (l) l->rev ^= true;
		if (r) r->rev ^= true;
		merge(root, l, r);
	}
	print(root);
	putchar('\n');
}
