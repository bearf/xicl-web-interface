#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

const int maxn = 100400;

int n;
int x[maxn][4];
int eval(int i, int m) {
    int s = 0;
    forn(j, 4) {
        if (m&(1<<j)) s += x[i][j];
        else s -= x[i][j];
    }
    return s;
}

struct cmp {
    bool operator()(int i, int j) const {
        int x = eval(i/16, i%16);
        int y = eval(j/16, j%16);
        if (x != y) return x < y;
        return i < j;
    }
};

set<int, cmp> q[16];

map<tuple<int, int, int, int>, int> idx;

void add(int a, int b, int c, int d) {
    x[n][0] = a; 
    x[n][1] = b; 
    x[n][2] = c; 
    x[n][3] = d; 
    idx[make_tuple(a,b,c,d)] = n;
    forn(i, 8) q[i].insert(n*16 + i);
    ++n;
}

void del(int a, int b, int c, int d) {
    auto it = idx.find(make_tuple(a,b,c,d));
    assert(it != idx.end());
    int k = it->second;
    idx.erase(it);
    forn(i, 8) q[i].erase(k*16 + i);
}

int get(int a, int b, int c, int d) {
    int mx = 0;
    forn(i, 8) {
        {
        int k = *q[i].begin() / 16;
        mx = max(mx,
                abs(a - x[k][0]) +
                abs(b - x[k][1]) +
                abs(c - x[k][2]) +
                abs(d - x[k][3]));
        }
        {
        int k = *q[i].rbegin() / 16;
        mx = max(mx,
                abs(a - x[k][0]) +
                abs(b - x[k][1]) +
                abs(c - x[k][2]) +
                abs(d - x[k][3]));
        }
    }
    return mx;
}

int main() {
#ifdef LOCAL
    assert(freopen("i.in", "r", stdin));
#endif

    ios::sync_with_stdio(false);

    int m;
    cin >> m;
    forn(i, m) {
        int t, a, b, c, d;
        cin >> t >> a >> b >> c >> d;
        if (t == 1) {
            add(a, b, c, d);
        } else if (t == 2) {
            del(a, b, c, d);
        } else {
            cout << get(a, b, c, d) << "\n";
        }
    }

    return 0;
}
