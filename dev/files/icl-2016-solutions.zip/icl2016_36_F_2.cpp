#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int maxn = 1000;
const int MOD = 1e9 + 9;

int sz = 0;

pair<ll, ll> q[maxn];

ll k, gcd, nok;

ll pows(ll a, ll b)
{
    if (b == 0)
        return 1;
    if (b % 2 == 1)
        return (a * pows(a, b - 1)) % MOD;
    ll safe = pows(a, b / 2);
    return (safe * safe) % MOD;
}

int main()
{
    cin >> k >> gcd >> nok;
    if (nok % gcd != 0){
        cout << 0;
        return 0;
    }
    for (int i = 2; i <= sqrt(nok); i++)
        if (nok % i == 0){
            while (nok % i == 0)
                q[sz].second++, nok /= i;
            while (gcd % i == 0)
                q[sz].first++, gcd /= i;
            sz++;
        }
    if (nok > 1)
        if (gcd > 1)
            q[sz] = make_pair(1, 1), sz++;
        else
            q[sz] = make_pair(0, 1), sz++;
    ll ans = 1;
    for (int i = 0; i < sz; i++)
    {
        int a = q[i].first, b = q[i].second;
        ans *= ((pows((b - a + 1), k) - 2 * pows((b - a), k) + pows((b > a ? (b - a - 1) : 0), k)) % MOD + MOD) % MOD;
    }
    cout << ans;
}
