#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <string>
using namespace std;
int main() {
	string s;
	getline(cin, s);
	int c = s.size();
	vector<char> v(c);
	for (int i = 0; i < s.size(); i++) {
		v[i] = s[i];
	}
	int n;
	int b = -1;
	cin >> n;
	for (int i = 0; i < n; i++) {
		int a;
		cin >> a;
		if (a == b) {
			continue;
		}
		reverse(v.begin(), v.begin() + a);
		reverse(v.begin() + a, v.end());
		b = a;
	}
	for (int i = 0; i < c; i++) {
		cout << v[i];
	}

}