#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

ll gcd(ll a, ll b)
{
    return (!b) ? a:gcd(b, a % b);
}

int main() {

    int n;
    ll a, b;

    ll a1, a2;

    a1 = 1;
    a2 = 1;

    ll gc1, gc2;
    ll ans1;
        cin >> n;
    cin >> gc1 >> gc2;
    ans1 = gc1;

    for (int i = 1; i < n; ++i)
    {
        cin >> a1 >> a2;
        gc1 = gcd(ans1, a1);
        gc2 = gcd(gc2, a2);
        ans1 *= a1;
        ans1 /= gc1;
    }

    ll g = gcd(ans1, gc2);

    cout << ans1/g << " " << gc2/g;

    return 0;
}
