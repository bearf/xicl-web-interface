#include <iostream>
#include <set>
#include <algorithm>

using namespace std;

long long n;

struct p1 {
	long long a, b, c, d;
	p1() {};
	p1(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p1 &x) const {
		return (a < x.a) || (a == x.a && b < x.b) || (a == x.a && b == x.b && c < x.c) || (a == x.a && b == x.b && c == x.c && d < x.d);
	};
};

struct p2 {
	long long a, b, c, d;
	p2() {};
	p2(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p2 &x) const {
		return (a < x.a) || (a == x.a && b < x.b) || (a == x.a && b == x.b && c < x.c) || (a == x.a && b == x.b && c == x.c && d > x.d);
	};
};

struct p3 {
	long long a, b, c, d;
	p3() {};
	p3(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p3 &x) const {
		return (a < x.a) || (a == x.a && b < x.b) || (a == x.a && b == x.b && c > x.c) || (a == x.a && b == x.b && c == x.c && d < x.d);
	};
};

struct p4 {
	long long a, b, c, d;
	p4() {};
	p4(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p4 &x) const {
		return (a < x.a) || (a == x.a && b < x.b) || (a == x.a && b == x.b && c > x.c) || (a == x.a && b == x.b && c == x.c && d > x.d);
	};
};

struct p5 {
	long long a, b, c, d;
	p5() {};
	p5(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p5 &x) const {
		return (a < x.a) || (a == x.a && b > x.b) || (a == x.a && b == x.b && c < x.c) || (a == x.a && b == x.b && c == x.c && d < x.d);
	};
};

struct p6 {
	long long a, b, c, d;
	p6() {};
	p6(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p6 &x) const {
		return (a < x.a) || (a == x.a && b > x.b) || (a == x.a && b == x.b && c < x.c) || (a == x.a && b == x.b && c == x.c && d > x.d);
	};
};

struct p7 {
	long long a, b, c, d;
	p7() {};
	p7(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p7 &x) const {
		return (a < x.a) || (a == x.a && b > x.b) || (a == x.a && b == x.b && c > x.c) || (a == x.a && b == x.b && c == x.c && d < x.d);
	};
};

struct p8 {
	long long a, b, c, d;
	p8() {};
	p8(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p8 &x) const {
		return (a < x.a) || (a == x.a && b > x.b) || (a == x.a && b == x.b && c > x.c) || (a == x.a && b == x.b && c == x.c && d > x.d);
	};
};

struct p9 {
	long long a, b, c, d;
	p9() {};
	p9(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p9 &x) const {
		return (a > x.a) || (a == x.a && b < x.b) || (a == x.a && b == x.b && c < x.c) || (a == x.a && b == x.b && c == x.c && d < x.d);
	};
};

struct p10 {
	long long a, b, c, d;
	p10() {};
	p10(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p10 &x) const {
		return (a > x.a) || (a == x.a && b < x.b) || (a == x.a && b == x.b && c < x.c) || (a == x.a && b == x.b && c == x.c && d > x.d);
	};
};

struct p11 {
	long long a, b, c, d;
	p11() {};
	p11(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p11 &x) const {
		return (a > x.a) || (a == x.a && b < x.b) || (a == x.a && b == x.b && c > x.c) || (a == x.a && b == x.b && c == x.c && d < x.d);
	};
};

struct p12 {
	long long a, b, c, d;
	p12() {};
	p12(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p12 &x) const {
		return (a > x.a) || (a == x.a && b < x.b) || (a == x.a && b == x.b && c > x.c) || (a == x.a && b == x.b && c == x.c && d > x.d);
	};
};

struct p13 {
	long long a, b, c, d;
	p13() {};
	p13(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p13 &x) const {
		return (a > x.a) || (a == x.a && b > x.b) || (a == x.a && b == x.b && c < x.c) || (a == x.a && b == x.b && c == x.c && d < x.d);
	};
};

struct p14 {
	long long a, b, c, d;
	p14() {};
	p14(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p14 &x) const {
		return (a > x.a) || (a == x.a && b > x.b) || (a == x.a && b == x.b && c < x.c) || (a == x.a && b == x.b && c == x.c && d > x.d);
	};
};

struct p15 {
	long long a, b, c, d;
	p15() {};
	p15(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p15 &x) const {
		return (a > x.a) || (a == x.a && b > x.b) || (a == x.a && b == x.b && c > x.c) || (a == x.a && b == x.b && c == x.c && d < x.d);
	};
};

struct p16 {
	long long a, b, c, d;
	p16() {};
	p16(long long x, long long y, long long z, long long k) {
		a = x;
		b = y;
		c = z;
		d = k;
	};
	bool operator < (const p16 &x) const {
		return (a > x.a) || (a == x.a && b > x.b) || (a == x.a && b == x.b && c > x.c) || (a == x.a && b == x.b && c == x.c && d > x.d);
	};
};

set <p1> s1;
set <p2> s2;
set <p3> s3;
set <p4> s4;
set <p5> s5;
set <p6> s6;
set <p7> s7;
set <p8> s8;
set <p9> s9;
set <p10> s10;
set <p11> s11;
set <p12> s12;
set <p13> s13;
set <p14> s14;
set <p15> s15;
set <p16> s16;

int main() {
	cin >> n;
	for (long long i = 0; i < n; i++) {
		long long t, x1, x2, x3, x4;
		cin >> t;
		cin >> x1 >> x2 >> x3 >> x4;
		//x1 += 100000000;
		//x2 += 100000000;
		//x3 += 100000000;
		//x4 += 100000000;
		if (t == 1) {
			s1.insert(p1(x1, x2, x3, x4));
			s2.insert(p2(x1, x2, x3, x4));
			s3.insert(p3(x1, x2, x3, x4));
			s4.insert(p4(x1, x2, x3, x4));
			s5.insert(p5(x1, x2, x3, x4));
			s6.insert(p6(x1, x2, x3, x4));
			s7.insert(p7(x1, x2, x3, x4));
			s8.insert(p8(x1, x2, x3, x4));
			s9.insert(p9(x1, x2, x3, x4));
			s10.insert(p10(x1, x2, x3, x4));
			s11.insert(p11(x1, x2, x3, x4));
			s12.insert(p12(x1, x2, x3, x4));
			s13.insert(p13(x1, x2, x3, x4));
			s14.insert(p14(x1, x2, x3, x4));
			s15.insert(p15(x1, x2, x3, x4));
			s16.insert(p16(x1, x2, x3, x4));
			/*cout << s1.size() << '\n';
			cout << s2.size() << '\n';
			cout << s3.size() << '\n';
			cout << s4.size() << '\n';
			cout << s5.size() << '\n';
			cout << s6.size() << '\n';
			cout << s7.size() << '\n';
			cout << s8.size() << '\n';
			cout << s9.size() << '\n';
			cout << s10.size() << '\n';
			cout << s11.size() << '\n';
			cout << s12.size() << '\n';
			cout << s13.size() << '\n';
			cout << s14.size() << '\n';
			cout << s15.size() << '\n';
			cout << s16.size() << '\n';
			cout << x1 << ' ' << x2 << ' ' << x3 << ' ' << x4 << '\n';*/
		}
		if (t == 2) {
			s1.erase(p1(x1, x2, x3, x4));
			s2.erase(p2(x1, x2, x3, x4));
			s3.erase(p3(x1, x2, x3, x4));
			s4.erase(p4(x1, x2, x3, x4));
			s5.erase(p5(x1, x2, x3, x4));
			s6.erase(p6(x1, x2, x3, x4));
			s7.erase(p7(x1, x2, x3, x4));
			s8.erase(p8(x1, x2, x3, x4));
			s9.erase(p9(x1, x2, x3, x4));
			s10.erase(p10(x1, x2, x3, x4));
			s11.erase(p11(x1, x2, x3, x4));
			s12.erase(p12(x1, x2, x3, x4));
			s13.erase(p13(x1, x2, x3, x4));
			s14.erase(p14(x1, x2, x3, x4));
			s15.erase(p15(x1, x2, x3, x4));
			s16.erase(p16(x1, x2, x3, x4));
			/*cout << s1.size() << '\n';
			cout << s2.size() << '\n';
			cout << s3.size() << '\n';
			cout << s4.size() << '\n';
			cout << s5.size() << '\n';
			cout << s6.size() << '\n';
			cout << s7.size() << '\n';
			cout << s8.size() << '\n';
			cout << s9.size() << '\n';
			cout << s10.size() << '\n';
			cout << s11.size() << '\n';
			cout << s12.size() << '\n';
			cout << s13.size() << '\n';
			cout << s14.size() << '\n';
			cout << s15.size() << '\n';
			cout << s16.size() << '\n';*/
		}
		if (t == 3) {
			p1 k1 = (*s1.begin());
			p2 k2 = (*s2.begin());
			p3 k3 = (*s3.begin());
			p4 k4 = (*s4.begin());
			p5 k5 = (*s5.begin());
			p6 k6 = (*s6.begin());
			p7 k7 = (*s7.begin());
			p8 k8 = (*s8.begin());
			p9 k9 = (*s9.begin());
			p10 k10 = (*s10.begin());
			p11 k11 = (*s11.begin());
			p12 k12 = (*s12.begin());
			p13 k13 = (*s13.begin());
			p14 k14 = (*s14.begin());
			p15 k15 = (*s15.begin());
			p16 k16 = (*s16.begin());
			long long mx[16];
			mx[0] = abs(x1 - k1.a) + abs(x2 - k1.b) + abs(x3 - k1.c) + abs(x4 - k1.d);
			mx[1] = abs(x1 - k2.a) + abs(x2 - k2.b) + abs(x3 - k2.c) + abs(x4 - k2.d);
			mx[2] = abs(x1 - k3.a) + abs(x2 - k3.b) + abs(x3 - k3.c) + abs(x4 - k3.d);
			mx[3] = abs(x1 - k4.a) + abs(x2 - k4.b) + abs(x3 - k4.c) + abs(x4 - k4.d);
			mx[4] = abs(x1 - k5.a) + abs(x2 - k5.b) + abs(x3 - k5.c) + abs(x4 - k5.d);
			mx[5] = abs(x1 - k6.a) + abs(x2 - k6.b) + abs(x3 - k6.c) + abs(x4 - k6.d);
			mx[6] = abs(x1 - k7.a) + abs(x2 - k7.b) + abs(x3 - k7.c) + abs(x4 - k7.d);
			mx[7] = abs(x1 - k8.a) + abs(x2 - k8.b) + abs(x3 - k8.c) + abs(x4 - k8.d);
			mx[8] = abs(x1 - k9.a) + abs(x2 - k9.b) + abs(x3 - k9.c) + abs(x4 - k9.d);
			mx[9] = abs(x1 - k10.a) + abs(x2 - k10.b) + abs(x3 - k10.c) + abs(x4 - k10.d);
			mx[10] = abs(x1 - k11.a) + abs(x2 - k11.b) + abs(x3 - k11.c) + abs(x4 - k11.d);
			mx[11] = abs(x1 - k12.a) + abs(x2 - k12.b) + abs(x3 - k12.c) + abs(x4 - k12.d);
			mx[12] = abs(x1 - k13.a) + abs(x2 - k13.b) + abs(x3 - k13.c) + abs(x4 - k13.d);
			mx[13] = abs(x1 - k14.a) + abs(x2 - k14.b) + abs(x3 - k14.c) + abs(x4 - k14.d);
			mx[14] = abs(x1 - k15.a) + abs(x2 - k15.b) + abs(x3 - k15.c) + abs(x4 - k15.d);
			mx[15] = abs(x1 - k16.a) + abs(x2 - k16.b) + abs(x3 - k16.c) + abs(x4 - k16.d);
			long long mxx = -2000000000;
			/*cout << s1.size() << '\n';
			cout << s2.size() << '\n'; 
			cout << s3.size() << '\n';
			cout << s4.size() << '\n';
			cout << s5.size() << '\n';
			cout << s6.size() << '\n';
			cout << s7.size() << '\n';
			cout << s8.size() << '\n';
			cout << s9.size() << '\n';
			cout << s10.size() << '\n';
			cout << s11.size() << '\n';
			cout << s12.size() << '\n';
			cout << s13.size() << '\n';
			cout << s14.size() << '\n';
			cout << s15.size() << '\n';
			cout << s16.size() << '\n';*/
			for (long long j = 0; j < 16; j++) {
				//cout << mx[j] << '\n';
				mxx = max(mxx, mx[j]);
			}
			cout << mxx << '\n';
		}
	}
	//system("pause");
	return 0;
}
