#include <bits/stdc++.h>
#define mp make_pair
#define endl "\n"
#define F first
#define S second

const double eps = 0.0000000001;
typedef long long ll;
using namespace std;
struct Treap{
    int pr, sz;
    char key;
    bool rev;
    Treap *l, *r;
    Treap(char x){
        key = x;
        pr = rand();
        l = NULL;
        r = NULL;
        rev = false;
        sz = 1;
    }
};

Treap *root;
void push(Treap *t){
    if (t == NULL)
        return;
    if (t->rev){
        if (t->l != NULL)
            t->l->rev ^= true;
        if (t->r != NULL)
            t->r->rev ^= true;
        swap(t->l, t->r);
        t->rev = false;
    }
}

void recalc(Treap *t){
    if (t == NULL)
        return;
    t->sz = (t->l != NULL ? t->l->sz : 0) + (t->r != NULL ? t->r->sz : 0) + 1;
}

Treap* merge(Treap *l, Treap *r){
    push(l);
    push(r);
    if (l == NULL)
        return r;
    if (r == NULL)
        return l;

    if (l->pr >= r->pr){
        l->r = merge(l->r, r);
        recalc(l);
        return l;
    }
    else{
        r->l = merge(l, r->l);
        recalc(r);
        return r;
    }
}

pair <Treap*, Treap*> split(Treap *t, int x, int invis){
    push(t);
    if (t == NULL)
        return {NULL, NULL};

    int key = invis;
    if (t->l != NULL)
        key += t->l->sz;

    if (key >= x){
        auto tmp = split(t->l, x, invis);
        t->l = tmp.second;
        recalc(t);
        return {tmp.first, t};
    }
    else{
        auto tmp = split(t->r, x, key + 1);
        t->r = tmp.first;
        recalc(t);
        return {t, tmp.second};
    }
}

void ins(char c){
    Treap* t = new Treap(c);
    root = merge(root, t);
}

void print(Treap *t){
    if (t == NULL)
        return;
    push(t);
    print(t->l);
    cout << t->key;
    print(t->r);
}

void rever(int l, int r){
    auto tmp = split(root, r, 0);
    auto tmp1 = split(tmp.first, l, 0);
    if (tmp1.second != NULL)
        tmp1.second->rev ^= true;
    root = merge(merge(tmp1.first, tmp1.second), tmp.second);
}

int main() {
    srand(time(NULL));
    #ifdef _HOME_
        freopen("input.txt", "r", stdin);
    #endif // _HOME_

    string s;
    cin >> s;

    for (int i = 0; i < (int)s.size(); i++){
        ins(s[i]);
    }

    int n;
    cin >> n;

    for (int i = 0; i < n; i++){
        int x;
        cin >> x;
        if (x == 0){
            rever(x, (int)s.size());
            continue;
        }
        if (x == 5){
            rever(0, x);
            continue;
        }
        rever(0, x);
        rever(x, (int)s.size());
    }

    print(root);
}
