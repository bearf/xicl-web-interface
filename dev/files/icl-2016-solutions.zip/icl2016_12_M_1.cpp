#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <string>
#include <map>
#include <queue>
#include<iostream>
#define ll long long int
using namespace std;
const int mod=1e9+7;
#pragma warning(disable:4996)

ll f(ll a,ll b) {
	ll c;
	if(b>a) {
		c=a;
		a=b;
		b=c;
	}
	if(b==0) {
		return 0;
	}
	while(b>0) {
		c=a%b;
		a=b;
		b=c;
	}
	return a;
}

int main(){
#ifdef _DEBUG
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
#endif
	ll a[10],b[10],n,i,j,t,x,y;
	scanf("%I64d",&n);
	for(i=0;i<n;i++) {
		scanf("%I64d%I64d",&a[i],&b[i]);
	}
	if(n==1) {
		printf("%I64d %I64d",a[0],b[0]);
		return 0;
	}
	t=f(b[0],b[1]);
	for(i=2;i<n;i++) {
		t=f(t,b[i]);
	}
	x=f(a[0],a[1]);
	for(i=2;i<n;i++) {
		x=f(x,a[i]);
	}
	y=a[0];
	for(i=1;i<n;i++) {
		y*=a[i];
	}
	x=y/x;
	y=f(x,t);
	printf("%I64d %I64d",x/y,t/y);
	return 0;
}