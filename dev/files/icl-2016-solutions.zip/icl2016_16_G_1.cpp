#include <bits/stdc++.h>
#define mp make_pair
#define endl "\n"
#define F first
#define S second

const double eps = 0.0000000001;
const int INF = 1e9;
typedef long long ll;
using namespace std;


int main() {
    #ifdef _HOME_
        freopen("input.txt", "r", stdin);
    #endif // _HOME_


    int n, p;
    cin >> n;

    multiset <int> d;

    for (int i = 0; i < n; i++){
        cin >> p;
        d.insert(p);
    }

    int cur = 0;


    while (!d.empty()){
        p = *d.begin();
        auto it = d.begin();

        cur++;

        while (true){
            auto tmp = upper_bound(d.begin(), d.end(), p);
            if (tmp != d.end()){
                d.erase(it);
                p = *tmp;
                it = tmp;
            }
            else
                break;
        }
        d.erase(it);
    }
    cout << cur;
}
