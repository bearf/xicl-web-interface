#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <bitset>
#include <complex>
using namespace std;

typedef long long int int64;

const int64 INF = (int64)1e16;

set<pair<int64, int64> > s;

bool is_in_seg(int64 x, pair<int64, int64> seg)
{
	return seg.first <= x && x <= seg.second;
}

bool get_first(int64 x, pair<int64, int64> &res)
{
	auto it = s.lower_bound(make_pair(x, x));
	if (it != s.begin())
	{
		auto it2 = it;
		it2--;
		if (it2->second >= x)
			it = it2;
	}
	res = *it;
	s.erase(it);
	return true;
}

bool get_prev(int64 x, pair<int64, int64> &res)
{
	auto it = s.upper_bound(make_pair(x, x));
	if (it == s.begin())
		return false;
	it--;
	res = *it;
	s.erase(it);
	return true;
}

int64 get_len(pair<int64, int64> seg)
{
	return seg.second - seg.first + 1;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	s.insert(make_pair(1, INF));

	int q;
	scanf("%d", &q);
	for (int it = 0; it < q; it++)
	{
		int64 x;
		scanf("%lld", &x);
		if (x > 0)
		{
			int64 p;
			scanf("%lld", &p);
			pair<int64, int64> seg;
			assert(get_first(x, seg));
			x = max(x, seg.first);
			int cur = min(p, seg.second - x + 1);
			
			printf("%lld %lld\n", x, x + cur - 1);
			
			pair<int64, int64> l = make_pair(seg.first, x - 1);
			pair<int64, int64> r = make_pair(x + cur, seg.second);

			if (l.first <= l.second)
				s.insert(l);
			if (r.first <= r.second)
				s.insert(r);
		}
		else
		{
			x *= -1;
			pair<int64, int64> p;
			pair<int64, int64> in_seg = make_pair(x, x);

			get_first(x, p);
			s.insert(p);
			if (is_in_seg(x, p))
				continue;
			
			if (get_first(x, p))
			{
				if (p.first == in_seg.second + 1)
					in_seg.second = p.second;
				else
					s.insert(p);
			}

			if (get_prev(x, p))
			{
				if (p.second == in_seg.first - 1)
					in_seg.first = p.first;
				else
					s.insert(p);
			}

			s.insert(in_seg);
		}
	}

	return 0;
}