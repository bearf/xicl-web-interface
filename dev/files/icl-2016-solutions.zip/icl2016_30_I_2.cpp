#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <set>	
#define ull long long
# define uull unsigned long long
using namespace std;

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	set <tuple <int, int, int, int> > s;
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		int x1, x2, x3, x4, k;
		cin >> k >> x1 >> x2 >> x3 >> x4;
		tuple <int, int, int, int> a = make_tuple(x1, x2, x3, x4);
		if (k == 1) {
			s.insert(a);
		}
		if (k == 2) {
			s.erase(a);
		}
		if (k == 3) {
			int max = 0;
			for (const auto& e : s) {
					int q = abs(get<0>(e) - x1) + abs(get<1>(e) - x2) + abs(get<2>(e) - x3) + abs(get<3>(e) - x4);
					if (q > max)
						max = q;
			}
			cout << max << endl;
		}
	}
	return 0;
}