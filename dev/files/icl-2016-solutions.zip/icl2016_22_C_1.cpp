#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

const int maxn = 50;
int n;
char s1[maxn], s2[maxn];
char s[maxn];

int perm[6] = {0, 5, 1, 3, 2, 4};

int read() {
  if (scanf("%s %s", s1, s2) < 2) {
    return 0;
  }
  n = strlen(s1);
  return 1;
}

void solve() {
  double ans = 1;
  for (int r = 0; r < n; r++) {
    scanf("%s", s);
    char str[6];
    for (int i = 0; i < 6; i++) {
      str[i] = s[perm[i]];
    }
    vector<int> have(3);
    for (int i = 0; i < 6; i++) {
      if (str[i] == s2[r]) {
        have[i / 2] = 1;
      }
    }
    int cnt = 0;
    double prob = 0;
    for (int i = 0; i < 6; i++) {
      if (s1[r] != str[i]) {
        continue;
      }
      cnt++;
      if (have[i / 2]) {
        prob += 1;
      } else {
        for (int j = 0; j < 3; j++) {
          if (have[j] && j != i / 2) {
            prob += 0.5;
          }
        }
      }
    }
    ans *= prob / cnt;
  }
  printf("%.18f\n", ans);
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
