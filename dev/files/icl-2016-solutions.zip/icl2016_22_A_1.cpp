#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

struct pnt {
  ld x, y;
  
  pnt(): x(), y() {}
  pnt(ld x, ld y): x(x), y(y) {}
  
  pnt operator -(const pnt & p) const {
    return pnt(x - p.x, y - p.y);
  }
  
  pnt operator +(const pnt & p) const {
    return pnt(x + p.x, y + p.y);
  }
  
  ld operator *(const pnt & p) const {
    return x * p.x + y * p.y;
  }
  
  ld operator ^(const pnt & p) const {
    return x * p.y - y * p.x;
  }
  
  ld len() const {
    return sqrt(x * x + y * y);
  }
  
  pnt norm() const {
    ld l = len();
    if (l < EPS) {
      return *this;
    }
    return pnt(x / l, y / l);
  }
  
  pnt operator *(const ld & m) const {
    return pnt(x * m, y * m);
  }
  
  pnt rot90() const {
    return pnt(-y, x);
  }
  
  pnt rot(const ld & f) const {
    return pnt(x * cos(f) - y * sin(f), x * sin(f) + y * cos(f));
  }
  
  bool read() {
    int _x, _y;
    if (scanf("%d%d", &_x, &_y) < 2) {
      return false;
    }
    x = _x, y = _y;
    return true;
  }
};

typedef pair<pnt, ld> circle;

int n;

int read() {
  if (scanf("%d", &n) < 1) {
    return 0;
  }
  return 1;
}

pnt m1, m2, m3;
ld al1, al2;
bool fnd;
pnt ans;

ld getAngle(const pnt & a, const pnt & b) {
  return abs(atan2(a ^ b, a * b));
}

pair<circle, circle> getS(const pnt & m1, const pnt & m2, ld alp) {
  if (alp > PI / 2.0L + EPS) {
    alp = PI - alp;
  }
  ld l = (m1 - m2).len();
  ld d = ((abs(alp - PI / 2.0L) < EPS) ? 0.0L : (l / abs(tan(alp))));
  
  pnt n = (m1 - m2).norm().rot90();
  
  pair<circle, circle> res;
  for (int it = -1; it <= 1; it += 2) {
    pnt p = m1 + ((n * d) * it);
    pnt o = (m2 + p) * 0.5L;
    ld r = (o - m2).len();
    
    if (it == -1) {
      res.first = mp(o, r);
    } else {
      res.second = mp(o, r);
    }
    
    assert(abs((o - m1).len() - r) < EPS && abs((o - m2).len() - r) < EPS);
    assert(abs(getAngle(m1 - o, m2 - o) / 2.0L - alp) < EPS);
  }
  
  return res;
}

void check(const pnt & p) {
  eprintf("%.2f %.2f\n", (double) p.x, (double) p.y);
  if (fnd) {
    return;
  }
  
  eprintf("angles: %.2f %.2f\n", (double) getAngle(m1 - p, m2 - p), (double) getAngle(m2 - p, m3 - p));
  
  if (abs(getAngle(m1 - p, m2 - p) - al1) > EPS) {
    return;
  }
  if (abs(getAngle(m2 - p, m3 - p) - al2) > EPS) {
    return;
  }
  
  fnd = true;
  ans = p;
}

void intersect(circle c1, circle c2) {
  if (fnd) {
    return;
  }
  
  pnt o1 = c1.first, o2 = c2.first;
  ld r1 = c1.second, r2 = c2.second;
  
  ld d = (o2 - o1).len();
  
  if (d > r1 + r2 + EPS || d < abs(r1 - r2) - EPS) {
    return;
  }
  
  if (d < EPS) {
    
    for (int it = -1; it < 2; it += 2) {
      pnt p = o1 + (m1 - o1).rot(it * (1e-4));
      
      check(p);
    }
  
    return;
  }
  
  ld cs = (r1 * r1 + d * d - r2 * r2) / (2.0L * r1 * d);
  ld sn = sqrt(max(0.0L, 1.0L - cs * cs));
  
  ld h = r1 * sn;
  ld d1 = r1 * cs;
  
  pnt v = (o2 - o1).norm();
  
  for (int it = -1; it < 2; it += 2) {
    pnt p = o1 + (v * d1) + (v.rot90() * (h * it));
    
    assert(abs((p - o1).len() - r1) < EPS && abs((p - o2).len() - r2) < EPS);
    
    check(p);
  }
}

void solve() {
  for (int it = 0; it < n; ++it) {
    assert(m1.read());
    assert(m2.read());
    assert(m3.read());
    int a1, a2;
    scanf("%d%d", &a1, &a2);
    al1 = a1 / 180.0L * PI, al2 = a2 / 180.0L * PI;
    
    auto s1 = getS(m1, m2, al1);
    auto s2 = getS(m2, m3, al2);
    
    fnd = false;
    for (int it1 = 0; it1 < 2; ++it1) {
      for (int it2 = 0; it2 < 2; ++it2) {
        intersect(it1 ? s1.second : s1.first, it2 ? s2.second : s2.first);
      }
    }
    
    assert(fnd);
    
    printf("%.18f %.18f\n", (double) ans.x, (double) ans.y);
  }
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
