#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

const int MOD = (int) 1e9 + 9;
int n;

int add(int a, int b) {
  int ans = a + b;
  if (ans >= MOD) {
    ans -= MOD;
  }
  return ans;
}

int mult(int a, int b) {
  return (ll) a * b % MOD;
}

int power(int a, ll p) {
  int ans = 1;
  while (p) {
    if (p & 1) {
      ans = mult(ans, a);
    }
    a = mult(a, a);
    p >>= 1;
  }
  return ans;
}

ll k;
int d, m;

int read() {
  if (scanf("%I64d%d%d", &k, &d, &m) < 3) {
    return 0;
  }
  return 1;
}

void solve() {
  set<int> primes;
  map<int, int> p1, p2;
  for (int i = 2; i < 5e4; i++) {
    while (d % i == 0) {
      primes.insert(i);
      p1[i]++;
      d /= i;
    }
    while (m % i == 0) {
      primes.insert(i);
      p2[i]++;
      m /= i;
    }
  }
  if (d > 1) {
    primes.insert(d);
    p1[d]++;
  }
  if (m > 1) {
    primes.insert(m);
    p2[m]++;
  }
  int ans = 1;
  for (auto p : primes) {
    if (p1[p] > p2[p]) {
      ans = 0;
    }
    int cur = add(power(p2[p] - p1[p] + 1, k), MOD - mult(2, power(p2[p] - p1[p], k)));
    if (p1[p] < p2[p]) {
      cur = add(cur, power(p2[p] - p1[p] - 1, k));
    }
    ans = mult(ans, cur);
  }
  printf("%d\n", ans);
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
