#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

const int mod = 1e9 + 9;

ll mul(ll x, ll y) {
    return x * y % mod;
}

ll add(ll x, ll y) {
    return (x + y) % mod;
}

ll sub(ll x, ll y) {
    return add(x, mod - y);
}

ll bin(ll x, ll a) {
    ll y = 1;
    while (a) {
        if (a & 1)
            y = mul(y, x);
        x = mul(x, x);
        a >>= 1;
    }
    return y;
}

ll fun(ll t, ll k) {
    ll ans = 0;
    ans = add(ans, bin(t + 1, k));
    ans = sub(ans, mul(2, bin(t, k)));
    ans = add(ans, bin(t - 1, k));
    return ans;
}

int main() {
#ifdef LOCAL
    assert(freopen("f.in", "r", stdin));
#endif
    ll ans = 1;
    ll k, d, m;
    cin >> k >> d >> m;
    if (m % d != 0) {
        cout << "0\n";
        return 0;
    }
    m /= d;

    for (ll i = 2; i * i <= m; ++i)
        if (m % i == 0) {
            ll t = 0;
            while (m % i == 0)
                m /= i, ++t;
            ans = mul(ans, fun(t, k));
        }
    if (m > 1)
        ans = mul(ans, fun(1, k));

    cout << ans << endl;
}
