


#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

struct Node {
    Node *l, *r;
    int w, y;
    char c;
    bool rev;

    Node() {}
    Node(char c) : l(nullptr), r(nullptr), w(1), y((rand() << 16) | rand()), c(c), rev(false) {};
};

void reverse(Node *node) {
    if (!node) return;
    node->rev ^= 1;
}

void update(Node *node) {
    if (!node) return;
    if (node->rev) {
        swap(node->l, node->r);
        reverse(node->l);
        reverse(node->r);
        node->rev = false;
    }
}

int getSz(Node *node) {
    if (!node) return 0;
    return node->w;
}

void relax(Node *node) {
    if (!node) return;
    node->w = 1 + getSz(node->l) + getSz(node->r);
}

Node *merge(Node *left, Node *right) {
    update(left);
    update(right);
    if (!left) return right;
    if (!right) return left;

    if (left->y > right->y) {
        left->r = merge(left->r, right);
        update(left);
        relax(left);
        return left;
    } else {
        right->l = merge(left, right->l);
        update(right);
        relax(right);
        return right;
    }
}

void split(Node *node, int k, Node *&left, Node *&right) {
    if (!node) {
        left = right = nullptr;
        return;
    }

    update(node);
    if (getSz(node->l) + 1 <= k) {
        split(node->r, k - getSz(node->l) - 1, node->r, right);
        left = node;
        relax(left);
    } else {
        split(node->l, k, left, node->l);
        right = node;
        relax(right);
    }
}

void insert(Node *&root, Node *node) {
    root = merge(root, node);
}

void print(Node *node) {
    if (!node) return;
    update(node);
    print(node->l);
    printf("%c", node->c);
    print(node->r);
}

void query(Node *&root, int k) {
    Node *A, *B;
    split(root, k, A, B);
    reverse(A);
    reverse(B);
    root = merge(A, B);
}

int main() {
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);

    srand(time(NULL));

    string s;
    getline(cin, s);

    Node *root = nullptr;
    for (int i = 0; i < (int)s.length(); i++) {
        Node *node = new Node(s[i]);
        insert(root, node);
    }

    int n;
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        int x;
        scanf("%d", &x);
        query(root, x);
    }

    print(root);
}
