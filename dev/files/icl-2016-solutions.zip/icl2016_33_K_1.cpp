#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <bitset>
#include <complex>
using namespace std;

typedef long long int int64;

const int64 INF = (int64)1e16;

vector<string> all;
set<string> used;
vector<string> list;

void dfs(string v)
{
	used.insert(v);
	list.push_back(v);

	for (int i = 0; i < (int)v.length(); i++)
	{
		for (int j = i; j < (int)v.length(); j++)
		{
			int cnt = 0;
			for (int x = i; x <= j; x++)
				if (v[x] == '1')
					cnt++;
			if (cnt % 2 != 0)
				continue;

			reverse(v.begin() + i, v.begin() + j + 1);
			if (used.count(v) == 0)
				dfs(v);
			reverse(v.begin() + i, v.begin() + j + 1);
		}
	}
}

bool bit(int mask, int pos)
{
	return (mask & (1 << pos)) != 0;
}

void gen(int len)
{
	printf("\nfor len = %d\n", len);

	used.clear();
	all.clear();
	int max_mask = (1 << len);
	for (int mask = 0; mask < max_mask; mask++)
	{
		string cur;
		for (int i = 0; i < len; i++)
			cur.push_back((char)('0' + bit(mask, i)));
		all.push_back(cur);
	}

	for (auto v : all)
	{
		if (used.count(v) == 1)
			continue;
		list.clear();
		dfs(v);
		printf("new class\n");
		for (auto u : list)
			printf("%s\n", u.c_str());
		printf("\n");
	}
}

int rev(int x, int l, int r)
{
	return r - (x - l);
}

string normalize(string str, vector<pair<int, int> > &list)
{
	int n = (int)str.length();
	set<int> one_pos;
	for (int i = 0; i < n; i++)
		if (str[i] == '1')
			one_pos.insert(i);

	for (int pref = 0; pref < n; pref++)
	{
		auto it1 = one_pos.lower_bound(pref);
		if (it1 == one_pos.end())
			break;
		auto it2 = it1;
		it2++;
		if (it2 == one_pos.end())
			break;

		int p1 = *it1;
		int p2 = *it2;

		if (p1 == pref)
			continue;

		int new_p1 = rev(p1, pref, p2);
		int new_p2 = rev(p2, pref, p2);
		
		one_pos.erase(p1);
		one_pos.erase(p2);
		one_pos.insert(new_p1);
		one_pos.insert(new_p2);
		list.emplace_back(pref, p2);
	}

	string res = string(n, '0');
	for (int p : one_pos)
		res[p] = '1';
	return res;
}

void solve()
{
	string str1, str2;
	cin >> str1 >> str2;
	vector<pair<int, int> > list1, list2;

	string new_str1 = normalize(str1, list1);
	string new_str2 = normalize(str2, list2);

	if (new_str1 != new_str2)
	{
		printf("NO\n");
		return;
	}

	reverse(list2.begin(), list2.end());
	printf("YES\n");
	printf("%d\n", (int)list1.size() + (int)list2.size());
	for (auto p : list1)
		printf("%d %d\n", p.first + 1, p.second + 1);
	for (auto p : list2)
		printf("%d %d\n", p.first + 1, p.second + 1);
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	solve();

	//for (int len = 7; len <= 7; len++)
	//	gen(len);

	return 0;
}