#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <vector>
#include <valarray>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

struct Point
{
	vector <int> c;
	Point() :c() {}
	void scan()
	{
		c = vector<int>(4);
		for (int i = 0; i < 4; i++)
			scanf("%d", &c[i]);
	}
	int getX(int i)
	{
		int ans = 0;
		for (int s = 0; s < 4; s++)
		{
			if (i & (1 << s))
				ans -= c[s];
			else
				ans += c[s];
		}
		return ans;
	}
};


multiset <int> directions[1 << 4];

void addPoint(Point p)
{
	for (int i = 0; i < (1 << 4); i++)
	{
		directions[i].insert(p.getX(i) );
	}
}

void delPoint(Point p)
{
	for (int i = 0; i < (1 << 4); i++)
	{
		directions[i].erase(directions[i].find(p.getX(i) ) );
	}
}

int getDist(Point p)
{
	int ans = 0;
	for (int i = 0; i < (1 << 4); i++)
	{
		ans = max(ans, p.getX(i) - *directions[i].begin() );
	}
	return ans;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		int t;
		scanf("%d", &t);
		Point p;
		p.scan();
		if (t == 1)
			addPoint(p);
		else if (t == 2)
			delPoint(p);
		else
		{
			printf("%d\n", getDist(p));
		}
	}
	return 0;
}