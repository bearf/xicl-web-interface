#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <functional>

using namespace std;

typedef long long ll;

const int MAXN = 10;
ll a[MAXN];
ll b[MAXN];

ll NOD(ll a, ll b) {
	while (b != 0) {
		ll c = a;
		a = b;
		b = c % b;
	}
	return a;
}

ll NOK(ll a, ll b) {
	ll res = a*b / NOD(a, b);
	return res;
}

int main() {
	
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> a[i] >> b[i];
	}

	if (n == 1) {
		cout << a[0] << " " << b[0];
	}
	else {
		ll nod = NOK(a[0], a[1]);
		ll nok = NOD(b[0], b[1]);
		for (int i = 2; i < n; i++) {
			nod = NOK(nod, a[i]);
			nok = NOD(nok, b[i]);
		}

		ll nnod = NOD(nod, nok);
		cout << nod/nnod << " " << nok/nnod;
	}

	return 0;
}