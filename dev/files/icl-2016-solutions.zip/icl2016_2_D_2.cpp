#define _CRT_SECURE_NO_WARNINGS

#include <vector>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

int L, n, k;

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	scanf("%d%d%d", &L, &n, &k);

	if (k == 1)
	{
		printf("0\n");
		return 0;
	}

	while (L > 0 && n > 0)
	{
		if (n <= k)
		{
			printf("%d\n", max(0, n - L));
			return 0;
		}
		int s = (n + k - 2) / k;
		if ((n + k - 1) / k > s)
		{
			n -= 2 * s;
			L--;
			continue;
		}
		int l = 0, r = L;
		while (r - l > 1)
		{
			int m = (l + r) / 2;
			ll nn = n - (ll)m * (2 * s - 1);
			if (nn < 0)
			{
				r = m;
				continue;
			}
			int ns = (nn + k - 2) / k;
			if (ns == s)
				l = m;
			else
				r = m;
		}
		L -= r;
		n -= (2 * s - 1) * r;
	}
	printf("%d\n", n);

	return 0;
}