#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
using namespace std;
int main() {
	int n;
	cin >> n;
	int m = 0;
	vector<int> v(n);
	vector<int> p(10001);
	for (int i = 0; i < n; i++) {
		cin >> v[i];
		p[v[i]]++;
		if (p[v[i]]>m)
			m = p[v[i]];
	}
	cout << m;
	
}