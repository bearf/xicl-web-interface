#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define F first
#define S second

// -- MAIN PART


const int N = 1e4 + 10;

char s[N];
char t[N];

pair<int, int> r[N];
int rc = 0;

int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	scanf("%s%s", s, t);
	int n = strlen(s);
	int cnt = 0;
	forn(i, n) if (s[i] == '1') cnt++;
	forn(i, n) if (t[i] == '1') cnt--;

	if (cnt != 0) return 0 * printf("NO\n");

	forn(i, n) if (s[i] != t[i])
	{
		if (t[i] == '1')
		{
			int j = i;
			cnt = 0;
			while (j < n && cnt != 2)
			{
				if (s[j] == '1') cnt++;
				j++;
			}
			if (cnt == 2)
			{
				reverse(s + i, s + j);
				r[rc++] = mp(i + 1, j);
			}
			else return 0 * printf("NO\n");
		}
		else
		{
			cnt = 0;
			int j = i;
			while (j < n && (cnt % 2 != 0 || cnt == 0 || s[j - 1] != '0'))
			{
				if (s[j] == '1') cnt++;
				j++;
			}
			if (cnt % 2 == 0 && s[j - 1] == '0')
			{
				reverse(s + i, s + j);
				r[rc++] = mp(i + 1, j);
			}
			else return 0 * printf("NO\n");
		}
	}
	printf("YES\n");
	printf("%d\n", rc);
	forn(i, rc) printf("%d %d\n", r[i].F, r[i].S);


	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
