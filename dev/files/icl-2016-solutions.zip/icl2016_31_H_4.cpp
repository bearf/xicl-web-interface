#include <bits/stdc++.h>

#define nullptr NULL
#define forn(i, n) for (int i = 0; i < n; i++)

using namespace std;
typedef long long ll;

struct node
{
    int y;
    char value;
    int sz;
    bool rev;

    node *l;
    node *r;

    node(char _value)
    {
        y = (rand() << 15) ^(rand());
        value = _value;
        l = nullptr;
        r = nullptr;
        sz = 1;
        rev = 0;
    }
};

int get_sz(node *t)
{
    if (t == nullptr)
        return 0;
    else
        return t -> sz;
}

void calc(node *t)
{
    if (t != nullptr)
    {
        t -> sz = get_sz(t -> l) + get_sz(t -> r) + 1;
    }
}

void push(node *t)
{
    if (t -> rev)
    {
        t -> rev = false;

        swap(t -> l, t -> r);

        if (t -> l)
            t -> l -> rev ^= 1;
        if (t -> r)
            t -> r -> rev ^= 1;
    }
}

node* merge(node *t1, node *t2)
{
    if (t1 == nullptr)
        return t2;
    if (t2 == nullptr)
        return t1;
    push(t1);
    push(t2);
    if (t1 -> y > t2 -> y)
    {
        t1 -> r = merge(t1 -> r, t2);
        calc(t1);
        return t1;
    }
    else
    {
        t2 -> l = merge(t1, t2 -> l);
        calc(t2);
        return t2;
    }
}

void split(node *t, node* &t1, node* &t2, int x)
{
    if (t == nullptr)
    {
        t1 = nullptr;
        t2 = nullptr;
    }
    else
    {
        push(t);
        int sz_l = get_sz(t -> l);
        if (sz_l >= x)
        {
            split(t->l, t1, t -> l, x);
            t2 = t;
            calc(t2);
        }
        else
        {
            split(t -> r, t ->r, t2, x - sz_l - 1);
            t1 = t;
            calc(t1);
        }
    }
}

string ans;

void print(node *t)
{
    if (t)
    {
        push(t);
        print(t -> l);
        cout << t -> value;
        print(t -> r);
    }
}

int n;
string st;
node *tree = nullptr;

int main()
{
    cin >> st;
    cin >> n;
    /*
    forn(i, n)
    {
        int v;
        cin >> v;
        reverse(st.begin(), st.begin() + v);
        reverse(st.begin() + v, st.end());
    }
    cout << st;
    return 0;
    */
    for (int i = 0; i < st.size(); ++i)
    {
        tree = merge(tree, new node(st[i]));
    }
    int nn = st.size();
    int v;
    node *t1, *t2;
    for (int i = 0; i < n; ++i)
    {
        cin >> v;


        split(tree, t1, t2, v);
        if (t1)
            t1 -> rev ^= 1;
        if (t2)
            t2 -> rev ^= 1;
        tree = merge(t1, t2);




        //print(tree);
       // cout << endl;
    }

    print(tree);
    return 0;
}


/*
abcde
5
2
3
5
3
1

*/
