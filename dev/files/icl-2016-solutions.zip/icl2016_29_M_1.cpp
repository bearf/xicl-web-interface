#include <iostream>
#include <map>
#include <algorithm>

using namespace std;

map <int, int> mp;
int n, q, ans = 1;


int gcd(int a, int b) {
	if (a < b)
		swap(a, b);
	if (b == 0)
		return a;
	return (gcd(a % b, b));
}


int main() {
	cin >> n;
	int a = 1, b = 1, c, d;
	for (int i = 0; i < n; i++) {
		cin >> c>> d;
		if (!i)
			a = c, b = d;
		a = a*c/gcd(a, c);
		b = gcd(b, d);
	}
	c = gcd(a, b);
	a /= c;
	b /= c;
	cout << a << ' ' << b;
}