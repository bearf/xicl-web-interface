#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define F first
#define S second
#define pw(x) (1ll << (x))

// -- MAIN PART

const int M = 1e9 + 9;
long long n;

int u[101][101];
long long a[101][101];
int r[101][101];

int m;
int c[111];

int k;


int gid(int x, int y) {
	return x * 9 + y;
}

void oo1() {
	for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) u[i][j] = 0;

	for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) for (int l = 0; l < k; l++) u[i][j] = (u[i][j] + r[i][l] * 1ll * a[l][j]) % M;

	for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) r[i][j] = u[i][j];
}

void oo2() {
	for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) u[i][j] = 0;

	for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) for (int l = 0; l < k; l++) u[i][j] = (u[i][j] + a[i][l] * 1ll * a[l][j]) % M;

	for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) a[i][j] = u[i][j];
}


int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	cin >> n >> m;
	for (int i = 1; i <= m; i++) cin >> c[i];

	k = 9 * 9;
	for (int x = 0; x <= 8; x++) for (int y = 0; y <= 8; y++) {
		if (x > 0 && y > 0) a[gid(x, y)][gid(x - 1, y - 1)]++;

		if (x == 0 && y == 0) {
			for (int i = 1; i <= m; i++) for (int j = 1; j <= m; j++) a[gid(x, y)][gid(i - 1, j - 1)] += c[i] *1ll* c[j] % M;
			a[gid(x, y)][gid(0, 0)] += c[2];
		}

		if (x == 0 && y > 0) for (int i = 1; i <= m; i++) a[gid(x, y)][gid(i - 1, y - 1)] += c[i];
		if (x > 0 && y == 0) for (int i = 1; i <= m; i++) a[gid(x, y)][gid(x - 1, i - 1)] += c[i];
	}
	for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) a[i][j] %= M;
//	for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) if (a[i][j] > 0) cout << i << " " << j << " " << a[i][j] << endl;

	for (int i = 0; i < k; i++) for (int j = 0; j < k; j++) r[i][j] = 0;
	for (int i = 0; i < k; i++) r[i][i] = 1;

	for (int i = 0; i < 62; i++) {
		if (n & pw(i)) oo1();
		oo2();
	}

	cout << r[0][0] << endl;


	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
