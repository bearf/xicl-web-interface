#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <map>
#include <string>
#include <complex>

#pragma warning(disable:4996)

using namespace std;

#define x1 first
#define y1 second
#define mlp make_pair
#define pb push_back
#define For(i,n) for(int i=0;i<(n);++i)
#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define all(v) (v).begin(),(v).end()

typedef long long ll;
typedef pair<double, double> point;

const int mod = 1e9 + 9;
const int INF = 2e9;
const ll LONGINF = 4e18;
const double PI = 3.1415926535897932384626433832795;
const double eps = 1e-9;

struct node;

typedef node* pnode;

struct node {
	pnode l, r;
	int c, sub, pr;
	char sym;
	bool toreverse;
	node() {
		pr = rand();
		l = r = NULL;
		toreverse = false;
		sym = 'a';
		c = 0;
		sub = 1;
	}
	node(char s) {
		pr = rand();
		l = r = NULL;
		toreverse = false;
		sym = s;
		c = 0;
		sub = 1;
	}
};

void update(pnode v) {
	if (v == NULL) return;
	v->sub = 1;
	if (v->l != NULL) v->c = v->l->sub, v->sub += v->l->sub;
	else v->c = 0;
	if (v->r != NULL) v->sub += v->r->sub;
}

void reverse(pnode v) {
	if (v == NULL) return;
	if (v->toreverse) {
		swap(v->l, v->r);
		if (v->l != NULL) v->l->toreverse ^= true;
		if (v->r != NULL) v->r->toreverse ^= true;
		v->toreverse = false;
	}
	update(v);
}

void split(pnode v, int c, pnode &dl, pnode &dr) {
	reverse(v);
	if (c == v->sub) {
		dl = v;
		dr = NULL;
		return;
	}
	if (c == 0) {
		dr = v;
		dl = NULL;
		return;
	}
	if (c <= v->c) {
		split(v->l, c, dl, v->l);
		dr = v;
	}
	if (c > v->c) {
		split(v->r, c - v->c - 1, v->r, dr);
		dl = v;
	}
	update(v);
	update(dl);
	update(dr);
}

void merge(pnode l, pnode r, pnode &d) {
	if (l == NULL) {
		d = r;
		return;
	}
	if (r == NULL) {
		d = l;
		return;
	}
	reverse(l);
	reverse(r);
	if (l->pr < r->pr) {
		merge(l->r, r, l->r);
		d = l;
	}
	else {
		merge(l, r->l, r->l);
		d = r;
	}
	update(d);
}

void print(pnode v) {
	if (v == NULL) return;
	reverse(v);
	print(v->l);
	printf("%c", v->sym);
	print(v->r);
}

void rev(pnode &v, int l) {
	pnode a, b;
	split(v, l, a, b);
	if(a!=NULL) a->toreverse ^= 1;
	if(b!=NULL) b->toreverse ^= 1;
	merge(a, b, v);
}

pnode root = NULL;

void solve() {
	char c;
	while (isalpha(c = getchar())) {
		merge(root, new node(c), root);
	}
	int n;
	scanf("%d", &n);
	For(i, n) {
		int a;
		scanf("%d", &a);
		rev(root, a);
	}
	print(root);

}

int main() {
#pragma comment(linker,"/STACK:268435456")
#ifdef _DEBUG
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#endif
	//int t;
	//scanf("%d", &t);
	//For(i, t)
	solve();
	return 0;
}