#define _CRT_SECURE_NO_WARNINGS
#include <fstream>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
#include <string>
#include <iostream>
#include <iomanip>
#include <ctime>
#define mp(x,y,z,t) make_pair(x,make_pair(y,make_pair(z,t)))
typedef long long ll;
typedef long double ld;

using namespace std;

ll gcd(ll a, ll b)
{
	if (b == 0)
		return a;
	return gcd(b, a%b);
}
ll lcm(ll a, ll b)
{
	return a / gcd(a, b)*b;
}

string ss[12];
int len;
ld go(char a, char b, int k) {
	int xa = 0, xb = 0, ya = 0, yb = 0, za = 0, zb = 0;
	xa = ((ss[k][0] == a) + (ss[k][5] == a));
	ya = ((ss[k][1] == a) + (ss[k][3] == a));
	za = ((ss[k][2] == a) + (ss[k][4] == a));
	xb = (ss[k][0] == b || ss[k][5] == b);
	yb = (ss[k][1] == b || ss[k][3] == b);
	zb = (ss[k][2] == b || ss[k][4] == b);
	ld kol = xa + ya + za;
	ld ver = 0;
	if (xa&&xb)
		ver += (1 / kol);
	else
		if ((xa&&yb) || (xa&&zb))
			ver += (xa / (2 * kol));
	if (ya&&yb)
		ver += (1 / kol);
	else
		if ((ya&&xb) || (ya&&zb))
			ver += (ya / (2 * kol));
	if (za&&zb)
		ver += (1 / kol);
	else
		if ((za&&yb) || (za&&xb))
			ver += (za / (2 * kol));
	return ver;
}
int main()
{
//	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	string s, s1;
	cin >> s >> s1;
	for (int i = 0; i < s.length(); i++)
	{
		cin >> ss[i];
	}
	ld ver = 1;
	len = s.length();
	for (int i = 0; i < s.length(); i++)
	{
		if (s[i] != s1[i])
			ver *= go(s[i], s1[i], i);
	}
	cout << fixed << setprecision(8) << ver;
	return 0;
}


/*
set <pair<ll,pair<ll,pair<ll,ll> > > > s1234,
s1324,
s1342,
s1243,
s1423,
s1432,
s2134,
s2314,
s2341,
s2431,
s2413,
s2143,
s3124,
s3214,
s3241,
s3142,
s3412,
s3421,
s4123,
s4213,
s4132,
s4231,
s4321,
s4312;
ll ans = 0;
ll f(ll  x1, ll  x2, ll x3, ll x4, set <pair<ll, pair<ll, pair<ll, ll> > > >::iterator it)
{
	return abs(x1 - (*it).first) + abs(x2 - (*it).second.first) + abs(x3 - (*it).second.second.first) + abs(x4 - (*it).second.second.second);
}

void ff(ll x1, ll x2, ll x3, ll x4, set <pair<ll, pair<ll, pair<ll, ll> > > > s)
{
	set <pair<ll, pair<ll, pair<ll, ll> > > >::iterator it;
	it = s.begin();
	ll oldsum = f(x1, x2, x3, x4, it);
	ans = max(oldsum, ans);
	srand(time(0));
	int i = rand()%100;
	if (s.size() > 1)
	{
		it++;
		ll sum = f(x1, x2, x3, x4, it);
		while (it != s.end() && (sum >= oldsum || i<10))
		{
			ans = max(ans, sum);
			oldsum = sum;
			sum = f(x1, x2, x3, x4, it);
			it++;
			i++;
		}
	}
	it = s.end();
	it--;
	oldsum = f(x1, x2, x3, x4, it);
	ans = max(ans, oldsum);
	it--;
	i = rand() % 100;
	if (s.size() > 1)
	{
		ll sum = f(x1, x2, x3, x4, it);
		do
		{
			ans = max(ans, sum);
			oldsum = sum;
			sum = f(x1, x2, x3, x4, it);
			it--;
			i++;

		}
		while (it != s.end() && (sum >= oldsum||i<10));
	}

}
int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		ll t, x1, x2, x3, x4;
		cin >> t >> x1 >> x2 >> x3 >> x4;
		if (t == 1)
		{
			s1234.insert(mp(x1, x2, x3, x4));
			s1324.insert(mp(x1, x3, x2, x4));
			s1342.insert(mp(x1, x3, x4, x2));
			s1243.insert(mp(x1, x2, x4, x3));
			s1423.insert(mp(x1, x4, x2, x3));
			s1432.insert(mp(x1, x4, x3, x2));
			s2134.insert(mp(x2, x1, x3, x4));
			s2314.insert(mp(x2, x3, x1, x4));
			s2341.insert(mp(x2, x3, x4, x1));
			s2431.insert(mp(x2, x4, x3, x1));
			s2413.insert(mp(x2, x4, x1, x3));
			s2143.insert(mp(x2, x1, x4, x3));
			s3124.insert(mp(x3, x1, x2, x4));
			s3214.insert(mp(x3, x2, x1, x4));
			s3241.insert(mp(x3, x2, x4, x1));
			s3142.insert(mp(x3, x1, x4, x2));
			s3412.insert(mp(x3, x4, x1, x2));
			s3421.insert(mp(x3, x4, x2, x1));
			s4123.insert(mp(x4, x1, x2, x3));
			s4213.insert(mp(x4, x2, x1, x3));
			s4132.insert(mp(x4, x1, x3, x2));
			s4231.insert(mp(x4, x2, x3, x1));
			s4321.insert(mp(x4, x3, x2, x1));
			s4312.insert(mp(x4, x3, x1, x2));
		}
		else
		if (t == 2)
		{
			s1234.erase(mp(x1, x2, x3, x4));
			s1324.erase(mp(x1, x3, x2, x4));
			s1342.erase(mp(x1, x3, x4, x2));
			s1243.erase(mp(x1, x2, x4, x3));
			s1423.erase(mp(x1, x4, x2, x3));
			s1432.erase(mp(x1, x4, x3, x2));
			s2134.erase(mp(x2, x1, x3, x4));
			s2314.erase(mp(x2, x3, x1, x4));
			s2341.erase(mp(x2, x3, x4, x1));
			s2431.erase(mp(x2, x4, x3, x1));
			s2413.erase(mp(x2, x4, x1, x3));
			s2143.erase(mp(x2, x1, x4, x3));
			s3124.erase(mp(x3, x1, x2, x4));
			s3214.erase(mp(x3, x2, x1, x4));
			s3241.erase(mp(x3, x2, x4, x1));
			s3142.erase(mp(x3, x1, x4, x2));
			s3412.erase(mp(x3, x4, x1, x2));
			s3421.erase(mp(x3, x4, x2, x1));
			s4123.erase(mp(x4, x1, x2, x3));
			s4213.erase(mp(x4, x2, x1, x3));
			s4132.erase(mp(x4, x1, x3, x2));
			s4231.erase(mp(x4, x2, x3, x1));
			s4321.erase(mp(x4, x3, x2, x1));
			s4312.erase(mp(x4, x3, x1, x2));
		}
		else
			if (t == 3)
			{
				ans = 0;

				ff(x1, x2, x3, x4, s1234);
				ff(x1, x3, x2, x4, s1324);
				ff(x1, x3, x4, x2, s1342);
				ff(x1, x2, x4, x3, s1243);
				ff(x1, x4, x2, x3, s1423);
				ff(x1, x4, x3, x2, s1432);
				ff(x2, x1, x3, x4, s2134);
				ff(x2, x3, x1, x4, s2314);
				ff(x2, x3, x4, x1, s2341);
				ff(x2, x4, x3, x1, s2431);
				ff(x2, x4, x1, x3, s2413);
				ff(x2, x1, x4, x3, s2143);
				ff(x3, x1, x2, x4, s3124);
				ff(x3, x2, x1, x4, s3214);
				ff(x3, x2, x4, x1, s3241);
				ff(x3, x1, x4, x2, s3142);
				ff(x3, x4, x1, x2, s3412);
				ff(x3, x4, x2, x1, s3421);
				ff(x4, x1, x2, x3, s4123);
				ff(x4, x2, x1, x3, s4213);
				ff(x4, x1, x3, x2, s4132);
				ff(x4, x2, x3, x1, s4231);
				ff(x4, x3, x2, x1, s4321);
				ff(x4, x3, x1, x2, s4312);
				cout << ans << endl;
			}
	}
	return 0;
}*/