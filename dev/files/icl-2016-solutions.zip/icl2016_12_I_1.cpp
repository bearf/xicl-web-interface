#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <string>
#include <map>
#include <queue>
#include<iostream>
#define ll long long int
using namespace std;
const int mod=1e9+7;
#pragma warning(disable:4996)

int a[100005][5],st[100005],n;

int main(){
#ifdef _DEBUG
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
#endif
	int i,j,t,k=0,x[5],q,e,sum,ans;
	scanf("%d",&n);
	for(i=0;i<n;++i) {
		scanf("%d",&t);
		if(t==1) {
			for(j=0;j<4;++j) {
				scanf("%d",&a[k][j]);
			}
			k++;
		} else{
			if(t==2) {
				for(j=0;j<4;++j) {
					scanf("%d",&x[j]);
				}
				for(j=0;j<k;++j) {
					e=1;
					for(q=0;q<4;++q) {
						if(a[j][q]!=x[q]) {
							e=0;
						}
					}
					if(e==1) {
						st[j]=1;
						j=1e9;
					}
				}
			} else{
				for(j=0;j<4;++j) {
					scanf("%d",&x[j]);
				}
				ans=0;
				for(j=0;j<k;++j) {
					if(st[j]==0) {
						sum=0;
						for(q=0;q<4;++q) {
							sum+=abs(a[j][q]-x[q]);
						}
						ans=max(ans,sum);
					}
				}
				printf("%d\n",ans);
			}
		}
	}
	return 0;
}