#include <cstdio>
#include <algorithm>
#include <iostream>
#include <set>
#include <map>
#include <vector>
#include <cstring>
#include <string>
#include <cmath>

#pragma warning (disable : 4996)

#define put push_back
#define mapa make_pair

using namespace std;


long long gcd(long long a, long long b) {
	while (a > 0 && b > 0) {
		if (a < b) {
			swap(a, b);
		}
		a = a % b;
	}
	return a + b;
}

int x, a, b;

map < int, int > u1, u2;

map < int, bool > p;

long long mod = 1000000009;

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
#ifndef _DEBUG
	//freopen("kek.in", "r", stdin);
	//freopen("kek.out", "w", stdout);
#endif
	cin >> x;
	cin >> a >> b;
	
	int A, B;
	A = a;
	B = b;

	for (int i = 2; i * i <= a; i++) {
		while (A % i == 0) {
			A /= i;
			u1[i]++;
		}
	}
	if (A != 1)
		u1[A]++;

	for (int i = 2; i * i <= b; i++) {
		while (B % i == 0) {
			B /= i;
			u2[i]++;
		}
	}
	if (B != 1)
		u2[B]++;

	long long ans = 1;
	for (auto i = u1.begin(); i != u1.end(); i++) {
		if (u2[i->first] < i->second) {
			cout << 0;
			return 0;
		}
		else {
			p[i->first] = true;
			ans *= min(u2[i->first] - i->second + 1 , x);
			ans %= mod;
		}
	}

	for (auto i = u2.begin(); i != u2.end(); i++) {
		if (!p[i->first]) {
			ans *= min(i->second + 1 , x);
			ans %= mod;
		}
	}

	cout << ans % mod;

	return 0;
}