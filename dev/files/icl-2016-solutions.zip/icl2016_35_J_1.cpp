#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

using namespace std;

struct segm{
    int a;
    int b;

    segm(int a, int b): a(a), b(b){}

    bool operator<(segm o) const {
        return a < o.a && b < o.b;
    }

};

set<segm> s;
typedef set<segm>::iterator it;


void take(int x) {
    it p = s.find(segm(x, x + 1));
    int a = p->a;
    int b = p->b;
    s.erase(p);
    if(a != x) {
        s.insert(segm(a, x));
    }
    if(x + 1 != b) {
        s.insert(segm(x + 1, b));
    }
}

void print_set() {
    cout << endl << "----" << endl;
    for(it i = s.begin(); i != s.end(); i++) {
        cout << i->a << " " << i->b << endl;
    }
    cout << "~~~~~" << endl << endl;
}

void put(int x, int h) {
    it p = s.find(segm(x, x + 1));
    int b = x;
    if(p != s.end()) {
        it po = p;
        x = po->b;
    }

    b = x;
    h--;
    while(true) {
            it p = s.find(segm(b, b + 1));
            if(p != s.end()) {
                int xx = p->b;
                s.erase(p);
                s.insert(segm(x, xx));
                cout << x << " " << b - 1 << endl;
                return;
            }
            if(h <= 0) {
                it p = s.find(segm(b, b));
                if(p != s.end()) {
                    s.insert(segm(x, p->b));
                    s.erase(p);
                    cout << x << " " << b << endl;
                    return;
                } else {
                    s.insert(segm(x, b + 1));
                    cout << x << " " << b << endl;
                    return;
                }
            }
            b++;
            h--;
        }
}

int main(){
    int n;
    cin >> n;
    for(int i = 0; i < n; i++) {

        int x;
        cin >> x;
        if(x < 0) {
            take(-x);
        } else {
            int y;
            cin >> y;
            put(x, y);
        }
    //print_set();
    }
    cin >> n;
}
