#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

struct treap{
    int sz, y;
    char v;
    bool rev;
    treap *l, *r;
};

typedef treap * ptr;

ll X = 2283221, Y = 1337, A = 13, B = 17, C = 19, MOD = 1e9 + 993;

ll myrand(){
    ll ret = (X * A + Y * B + C) % MOD;
    X = Y;
    Y = ret;
    return ret;
}

ptr create(char v){
    ptr t = new treap;
    t->l = nullptr;
    t->r = nullptr;
    t->v = v;
    t->sz = 1;
    t->y = rand();
    t->rev = 0;
    return t;
}

int sz(ptr t){
    return t == nullptr ? 0 : t->sz;
}

void push(ptr &t){
    if (t != nullptr){
        t->rev ^= 1;
    }
}

void upd(ptr &t){
    if (t != nullptr){
        t->sz = sz(t->l) + sz(t->r) + 1;
        if (t->rev)
            swap(t->l, t->r), t->rev = 0, push(t->l), push(t->r);
    }
}

void split(ptr t, ptr &l, ptr &r, int key, int add){
    if (t == nullptr){
        l = nullptr;
        r = nullptr;
        return;
    }
    upd(t);
    int cur = sz(t->l) + add;
    if (cur <= key)
        split(t->r, t->r, r, key, cur + 1), l = t;
    else
        split(t->l, l, t->l, key, add), r = t;
    upd(l);
    upd(r);
}

void merge(ptr &t, ptr l, ptr r){
    upd(l);
    upd(r);
    if (l == nullptr){
        t = r;
        return;
    }
    if (r == nullptr){
        t = l;
        return;
    }
    if (l->y <= r->y)
        merge(l->r, l->r, r), t = l;
    else
        merge(r->l, l, r->l), t = r;
    upd(t);
}

string s;

ptr root = nullptr;

string ret1;

void ans(ptr t){
    if (t == nullptr)
        return;
    upd(t);
    ans(t->l);
    ret1.push_back(t->v);
    ans(t->r);
}

string ret;

string lng(vector<int> q){
    ret = s;
    for (int i = 0; i < q.size(); i++){
        int x = q[i];
        string a, b;
        a.clear();
        b.clear();
        for (int j = 0; j < x; j++)
            a.push_back(ret[j]);
        for (int j = x; j < s.length(); j++)
            b.push_back(ret[j]);
        for (int j = 0; j < a.length() / 2; j++)
            swap(a[j], a[a.length() - 1 - j]);
        for (int j = 0; j < b.length() / 2; j++)
            swap(b[j], b[b.length() - 1 - j]);
        ret = a + b;
        //for (int j = 0; j < x / 2; j++)
        //    swap(ret[j], ret[x - j]);
        //for (int j = 0; j < (s.length() - x) / 2; j++)
        //    swap(ret[x + 1 + j], ret[s.length() - j - 1]);
    }
    return ret;
}

string fst(vector<int> q)
{
    root = nullptr;
    int n = s.length(), m;
    for (int i = 0; i < n; i++){
        merge(root, root, create(s[i]));
    }
    for (int i = 0; i < q.size(); i++){
        int x;
        x = q[i];
        ptr t1, t2;
        split(root, t1, t2, x - 1, 0);
        if (t1 != nullptr)
            t1->rev ^= 1, upd(t1);
        if (t2 != nullptr)
            t2->rev ^= 1, upd(t2);
        merge(root, t1, t2);
    }
    ret1 = "";
    ans(root);
    return ret1;
}

void init(){
    cout << "OK!" << endl;
    vector<int> p(rand() % 10);
    for (int i = 0; i < p.size(); i++)
        p[i] = rand() % 6;
    if (fst(p) != lng(p)){
        cout << s << '\n' << p.size() << '\n';
        for (int i = 0; i < p.size(); i++)
            cout << p[i] << '\n';
        exit(0);
    }
}

int main(){
    vector<int> p;
    getline(cin, s);
    int siz;
    cin >> siz;
    for (int i = 0; i < siz; i++){
        int x;
        cin >> x;
        p.push_back(x);
    }
    cout << fst(p);
}
