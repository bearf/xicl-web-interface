#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

i64 gcd(i64 a, i64 b) {
    while (b) {
        a %= b;
        swap(a, b);
    }
    return a;
}
i64 lcm(i64 a, i64 b) {
    return a / gcd(a, b) * b;
}

int main() {
#ifdef LOCAL
    assert(freopen("m.in", "r", stdin));
#endif

    int n;
    cin >> n;
    i64 x = 1, y = 0;
    forn(i, n) {
        i64 a, b;
        cin >> a >> b;
        x = lcm(x, a);
        y = gcd(y, b);
    }
    cout << x << " " << y << endl;
}
