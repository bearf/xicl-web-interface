#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <string>
#include <map>
#include <queue>
#define ll long long int
using namespace std;
const int mod=1e9+7;
#pragma warning(disable:4996)

int c[11111];

int main(){
#ifdef _DEBUG
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
#endif
	int n,i,j,s;
	scanf("%d",&n);
	for(i=0;i<11111;i++){
		c[i]=0;
	}
	for(i=0;i<n;i++){
		scanf("%d",&j);
		c[j]++;
	}
	s=0;
	for(i=0;i<11111;i++){
		s=max(s,c[i]);
	}
	printf("%d",s);


	return 0;
}