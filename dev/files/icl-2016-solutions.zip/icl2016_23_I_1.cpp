#pragma once
#pragma once
#pragma once
#include <iostream>
#include <map>
#include <set>
#include <algorithm>
#include <vector>
#include <math.h>


typedef  long long ll ;
typedef unsigned long long ull ;

struct point {
	int x1, x2, x3, x4;
	bool friend  point::operator <(const point p1, const point p2);
};

bool operator <(const point p1, const point p2) {
	if (p1.x1 != p2.x1) {
		return p1.x1 < p2.x1;
	}
	else if (p1.x2 != p2.x2) {
		return p1.x2 < p2.x2;
	}
	else if (p1.x3 != p2.x3) {
		return p1.x3 < p2.x3;
	}
	else if (p1.x4 != p2.x4) {
		return p1.x4 < p2.x4;
	}
}

using namespace std;

ull dist(point p1, point p2) {
	return (abs(p1.x1-p2.x1) + abs(p1.x2 - p2.x2) + abs(p1.x3 - p2.x3) + abs(p1.x4 - p2.x4));
}

int main() {

	int n;
	cin >> n;
	map<int, set <point> > arr;
	int t = 0;
	point p;
	point nul;
	ull y = 0;
	ull dis = 0;
	nul.x1 = 0; nul.x2 = 0; nul.x3 = 0; nul.x4 = 0;
	for (int i = 0; i < n; i++) {
		cin >> t;
		cin >> p.x1 >> p.x2 >> p.x3 >> p.x4;
		switch (t) {
		case 1:
			y = dist(p, nul);
			arr[y].insert(p);
			break;
		case 2:
			y = dist(p, nul);
			arr[y].erase(p);
			if (arr[y].size() == 0)
				arr.erase(y);
			break;
		case 3:
			dis = dist(p, nul);

			if (abs((long)dis - (long)(arr.begin()->first)) >  abs((long)dis - (long)((--arr.end())->first))) {
				cout << dist(p, *(arr.begin()->second.begin())) << endl;
			}

			if (abs((long)dis - (long)(arr.begin()->first)) <=  abs((long)dis - (long)((--arr.end())->first))) {
				cout << dist(p, *(--((--arr.end())->second.end()))) << endl;
			}
			break;
		}
	}

	return 0;

}

/*
5
1 0 0 0 0
1 -10 2 6 -9
3 -8 0 9 -5
2 0 0 0 0
3 -8 0 9 -5


*/