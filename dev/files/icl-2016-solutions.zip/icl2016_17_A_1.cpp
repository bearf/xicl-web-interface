#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

const ld eps = 1e-9;

bool eq(ld a, ld b) {
    return fabsl(a - b) < eps;
}

struct pt {
    ld x, y;

    pt operator-(const pt &p) const {
        return pt{x - p.x, y - p.y};
    }

    pt operator+(const pt &p) const {
        return pt{x + p.x, y + p.y};
    }

    ld operator*(const pt &p) const {
        return x * p.x + y * p.y;
    }

    ld operator%(const pt &p) const {
        return x * p.y - y * p.x;
    }

    pt operator*(const ld &a) const {
        return pt{x * a, y * a};
    }

    bool operator==(const pt &p) const {
        return eq(x, p.x) && eq(y, p.y);
    }

    ld abs() const {
        return hypotl(x, y);
    }

    ld abs2() const {
        return x * x + y * y;
    }

    pt rrot() const {
        return pt{y, -x};
    }

    pt rot() const {
        return pt{-y, x};
    }
};

istream &operator>>(istream &in, pt &p) {
    return in >> p.x >> p.y;
}

ld getR(pt a, pt b, ld alpha) {
    ld d = (a - b).abs();
    ld R = d / (2 * sinl(alpha));
    return R;
}

pair<pt, pt> getCenter(pt a, pt b, ld alpha) {
    ld d = (a - b).abs();
    ld R = getR(a, b, alpha);
    ld x = sqrtl(max(ld(0), R * R - d * d / 4));
    pt mid = (a + b) * 0.5;
    pt v = (b - a).rot();
    v = v * (1 / v.abs());
    return make_pair(mid + v * x, mid - v * x);
}

const ld PI = acosl(-1);

pt m1, m2, m3;
ld alpha1, alpha2;

vector<pt> intersect(pt a, pt b, ld r1, ld r2) {
    if (a == b) {
        //cerr << "equal\n";
        vector<pt> res;
        pt v;

        v = ((m1 + m2) * 0.5) - a;
        v = v * (r1 / v.abs());
        res.push_back(a + v);
        res.push_back(a - v);

        v = ((m1 + m3) * 0.5) - a;
        v = v * (r1 / v.abs());
        res.push_back(a + v);
        res.push_back(a - v);

        v = ((m3 + m2) * 0.5) - a;
        v = v * (r1 / v.abs());
        res.push_back(a + v);
        res.push_back(a - v);

        v = (m1 - a).rot() + a;
        res.push_back(v);
        v = (m2 - a).rot() + a;
        res.push_back(v);
        v = (m3 - a).rot() + a;
        res.push_back(v);
        v = (m1 - a).rrot() + a;
        res.push_back(v);
        v = (m2 - a).rrot() + a;
        res.push_back(v);
        v = (m3 - a).rrot() + a;
        res.push_back(v);

        //for (auto p: res)
            //cerr << p.x << ' ' << p.y << endl;
        return res;
    }
    ld d = (a - b).abs();
    ld cosa = (d * d + r1 * r1 - r2 * r2) / (2 * r1 * d);
    ld sina = sqrtl(max(ld(0), 1 - cosa * cosa));
    pt v = (b - a);
    v = v * (1 / v.abs());
    pt H = a + (v * (r1 * cosa));
    v = v.rot() * (r1 * sina);
    return {H + v, H - v};
}

bool check(pt p) {
    //cerr << "check " << p.x << ' ' << p.y << '\n';
    if (p == m2)
        return false;
    if (p == m1)
        return false;
    if (p == m3)
        return false;
    pt v1 = m1 - p;
    pt v2 = m2 - p;
    pt v3 = m3 - p;
    ld cosang1 = (v1 * v2) / (v1.abs() * v2.abs());
    ld cosang2 = (v3 * v2) / (v3.abs() * v2.abs());
    //cerr << cosang1 << ' ' << cosl(alpha1) << '\n';
    if (!eq(cosang1, cosl(alpha1)))
        return false;
    if (!eq(cosang2, cosl(alpha2)))
        return false;
    return true;
}

void solve() {
    cin >> m1 >> m2 >> m3 >> alpha1 >> alpha2;
    alpha1 *= PI / 180, alpha2 *= PI / 180;
    ld R1 = getR(m1, m2, alpha1);
    ld R2 = getR(m2, m3, alpha2);
    auto c1 = getCenter(m1, m2, alpha1);
    auto c2 = getCenter(m2, m3, alpha2);

    vector<pt> v;
    v = intersect(c1.first, c2.first, R1, R2);
    for (auto p: v)
        if (check(p)) {
            cout << p.x << ' ' << p.y << '\n';
            return;
        }
    v = intersect(c1.first, c2.second, R1, R2);
    for (auto p: v)
        if (check(p)) {
            cout << p.x << ' ' << p.y << '\n';
            return;
        }
    v = intersect(c1.second, c2.first, R1, R2);
    for (auto p: v)
        if (check(p)) {
            cout << p.x << ' ' << p.y << '\n';
            return;
        }
    v = intersect(c1.second, c2.second, R1, R2);
    for (auto p: v)
        if (check(p)) {
            cout << p.x << ' ' << p.y << '\n';
            return;
        }
    assert(false);
}

int main() {
    cout.setf(ios::fixed);
    cout.precision(10);
#ifdef LOCAL
    assert(freopen("a.in", "r", stdin));
#endif
    int n;
    cin >> n;
    forn (i, n)
        solve();
}
