#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <string>
#include <assert.h>

using namespace std;

#define mp make_pair
#define pb emplace_back
#define all(a) (a).begin(), (a).end()
#define x first
#define y second

typedef long long li;
typedef long double ld;

void solve();

int main() {
#ifdef ICL
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	cout.precision(20);
	cout << fixed;
	int t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
}

void add(vector<pair<int, int>>& v, int x, int y) {
	if (x == y)
		return;
	v.pb(x + 1, y + 1);
}

vector<pair<int, int>> f(string s) {
	vector<pair<int, int>> ans;

	int cur = 0;
	int n = s.length();
	int cnt = 0;
	for (int i = 0; i < n; i++) {
		if (s[i] == '1')
			cur ^= 1;
		else {
			if (cur == 0) {
				cnt++;
			}
		}
	}
	cur = 0;
	for (int i = 0; i < n && cnt; i++) {
		if (s[i] == '1') {
			cur ^= 1;
		}
		else {
			if (cur == 1) {
				int j = i + 1;
				int tmp = 0;
				while (s[j] == '1' || !tmp) {
					if (s[j] == '1')
						tmp ^= 1;
					j++;
				}
				add(ans, i - 1, j);
				reverse(s.begin() + i - 1, s.begin() + j + 1);
				j--;
				cur ^= 1;
			}
			cnt--;
		}
	}
	int i = 0, j = 0;
	int pr = 0;
	cur = 0;
	while (j < n) {
		if (s[j] == '1')
			cur ^= 1;
		else {
			if (cur != pr) {
				i++;
			}
			add(ans, i, j);
			i++;

			pr = cur;
		}
		j++;
	}
	return ans;
}

void solve() {
	string s, t;
	cin >> s >> t;
	vector<int> a, b;
	int cur = 0;
	int n = s.length();
	for (int i = 0; i < n; i++) {
		if (s[i] == '1')
			cur ^= 1;
		else
			a.push_back(cur);
	}
	cur = 0;
	for (int i = 0; i < n; i++) {
		if (t[i] == '1')
			cur ^= 1;
		else
			b.push_back(cur);
	}
	sort(all(a));
	sort(all(b));
	if (a != b) {
		puts("NO");
		return;
	}

	auto v1 = f(s);
	auto v2 = f(t);
	cout.sync_with_stdio(0);
	cout << "YES" << "\n";
	cout << (int)v1.size() + (int)v2.size() << "\n";
	for (auto p : v1)
		cout << p.x << " " << p.y << "\n";
	reverse(all(v2));
	for (auto p : v2)
		cout << p.x << " " << p.y << "\n";
}
