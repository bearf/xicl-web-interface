#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <map>

#pragma warning(disable:4996)

using namespace std;

#define x1 first
#define y1 second
#define mp make_pair
#define pb push_back
#define For(i,n) for(int i=0;i<(n);++i)
#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define all(v) (v).bagin(),(v).end()

typedef long long ll;

ll gcd(ll a, ll b) {
	while (a > 0 && b > 0) {
		if (a > b) a %= b;
		else b %= a;
	}
	return a | b;
}

void solve() {
	ll n, a, b, c = 1, d = 0, t = 0;
	scanf("%I64d", &n);
	For(i, n) {
		scanf("%I64d%I64d", &a, &b);
		c = c*a / gcd(c, a);
		d = gcd(d, b);
	}
	printf("%I64d %I64d", c, d);
}

int main() {
#pragma comment(linker,"/STACK:268435456")
#ifdef _DEBUG
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#endif
	solve();
	return 0;
}