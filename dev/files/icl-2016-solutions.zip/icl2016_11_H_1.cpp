#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define F first
#define S second

// -- MAIN PART

typedef long long ll;

struct T
{
	char x;
	int cnt, rev;
	ll y;
	T *l, *r;

	T(){}
	T(char xx)
	{
		x = xx;
		cnt = 1;
		rev = 0;
		l = NULL;
		r = NULL;
		y = rand() * (1LL << 15) + rand();
	}
};

const int N = 2e5 + 10;

T all[N];
int Last = 0;

T* newV(char x)
{
	all[Last] = T(x);
	return all + Last++;
}

inline void relax(T *t)
{
	if (!t) return;
	if (t->rev)
	{
		swap(t->l, t->r);
		if (t->l) t->l->rev ^= 1;
		if (t->r) t->r->rev ^= 1;
		t->rev = 0;
	}
}

inline void upd(T *t)
{
	t->cnt = 1;
	if (t->l) t->cnt += t->l->cnt;
	if (t->r) t->cnt += t->r->cnt;
}

pair<T*, T*> Split(T* t, int c)
{
	if (!t) return mp((T*)NULL, (T*)NULL);
	relax(t);
	int cntleft = 0;
	if (t->l) cntleft = t->l->cnt;
	pair<T*, T*> res;
	if (cntleft >= c)
	{
		res = Split(t->l, c);
		t->l = res.S;
		res.S = t;
	}
	else
	{
		res = Split(t->r, c - cntleft - 1);
		t->r = res.F;
		res.F = t;
	}
	upd(t);
	return res;
}


T* Merge(T* l, T* r)
{
	if (!l) return r;
	if (!r) return l;
	relax(l);
	relax(r);
	if (l->y > r->y)
	{
		l->r = Merge(l->r, r);
		upd(l);
		return l;
	}
	else
	{
		r->l = Merge(l, r->l);
		upd(r);
		return r;
	}
}

void out(T *t, int NL = 1)
{
	if (!t) return;
	relax(t);
	out(t->l, 0);
	printf("%c", t->x);
	out(t->r, 0);
	if (NL) printf("\n");
}			


char s[N];


int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	scanf("%s", s);
	int n = strlen(s);
	T* t = NULL;
	forn(i, n) t = Merge(t, newV(s[i]));
	int q;
	scanf("%d", &q);
	forn(i, q)
	{
		int x;
		scanf("%d", &x);
		pair<T*, T*> r = Split(t, x);
		if (r.F) r.F->rev ^= 1;
		if (r.S) r.S->rev ^= 1;
		t = Merge(r.F, r.S);

//		out(t);
	}
	out(t);
		

	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
