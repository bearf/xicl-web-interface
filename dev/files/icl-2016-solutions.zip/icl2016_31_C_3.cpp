#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < n; i++)

typedef long long ll;
typedef double ld;

const int INF = 2e9;
const ll INF64 = 9e18;
const int N = 200100;

int n;
ld ans = 1;
string s1, s2, s;

int get(string s, char x)
{
    int xx = 0;
    forn(i, s.size())
        {
            if (s[i] == x)
                xx++;
        }
    return (xx);
}

int ch(string s, char x)
{
    int xx = 0;
    forn(i, s.size())
        {
            if (s[i] == x)
                xx++;
        }
    return (xx);
}

string have, need;

int main()
{
    cin >> have >> need;
    n = need.size();
    ld ans = 1;

    forn(i, n)
    {
        cin >> s;

        s = " " + s;

        string s1, s2, s3;

        s1 = s1 + s[3] + s[6] + s[5] + s[1];
        s2 = s2 + s[2] + s[3] + s[4] + s[5];
        s3 = s3 + s[1] + s[2] + s[6] + s[4];
        int x = get(s1, have[i]), y = get(s2, have[i]), z = get(s3, have[i]);

        int kk = 0;
        int zz = 0;
        ld q = 0, qq = ld(1) / ld(x + y + z);

        if (get(s1, have[i]))
        {
            if (get(s1, need[i]))
                q += qq * x;
        }
        if (get(s2, have[i]))
        {
            ++kk;
            if (get(s2, need[i]))
                q += qq * y;
        }
        if (get(s3, have[i]))
        {
            ++kk;
            if (get(s3, need[i]))
                q += qq * z;
        }

        ans *= q;

    }


    cout << setprecision(20) << fixed << ans;
    return 0;
}

/*

HALLW
HELLO
XABCDH
XAECDe
AbcdeL
AbcdeL
ABOWCD

*/

