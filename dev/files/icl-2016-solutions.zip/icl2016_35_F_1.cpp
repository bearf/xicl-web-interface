#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    long long k, a, b;
    cin >> k >> a >> b;
    if (b % a != 0)
    {
        cout << 0;
        return 0;
    }
    double ans = pow((double)b/(double)a, ((double)1 / (double)k));

    long long ans_new = (long long) ans;
    for (long long i = 1; i <= k; i++)
    {
        if (ans_new == 0) break;
        ans_new = (ans_new * i) % (int)(1e9 + 9);
    }
    cout << ans_new;
    cin  >> k;
    return 0;
}
