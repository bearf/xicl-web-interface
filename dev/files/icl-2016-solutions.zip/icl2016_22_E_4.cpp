#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"
#define assert ;

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

bool readDouble(ld & a) {
  double tmp;
  if (scanf("%lf", &tmp) < 1) {
    return false;
  }
  a = tmp;
  return true;
}

const int K = 100;

struct point {
  ld x, y;
  
  point (ld x = 0, ld y = 0) : x(x), y(y) { }
  
  bool read() {
    if (!readDouble(x)) {
      return false;
    }
    assert(readDouble(y));
    return true;
  }
  
  void print() {
    eprintf("%.18f %.18f\n", (double) x, (double) y);
  }
  
  point operator+(const point & b) const {
    return point(x + b.x, y + b.y);
  }
  
  point operator-(const point & b) const {
    return point(x - b.x, y - b.y);
  }
  
  ld operator^(const point & b) const {
    return x * b.y - y * b.x;
  }
  
  ld operator*(const point & b) const {
    return x * b.x + y * b.y;
  }
  
  point operator*(const ld & b) const {
    return point(x * b, y * b);
  }
  
  ld len2() const {
    return x * x + y * y;
  }
  
  ld len() const {
    return sqrt(max(0.0L, len2()));
  }
  
  point norm() const {
    ld l = len();
    assert(l > EPS);
    return point(x / l, y / l);
  }
  
  ld ang(const point & b) const {
    return abs(atan2(*this ^ b, *this * b));
  }
  
  point rotate(const ld & cs, const ld & sn) const {
    return point(cs * x - sn * y, cs * y + sn * x);
  }
  
  point operator-() const {
    return point(-x, -y);
  }
};

point a, b, o;
ld r;

int read() {
  if (!a.read() || !b.read() || !o.read() || !readDouble(r)) {
    return 0;
  }
  return 1;
}

bool inside(const point & a, const point & b, const point & c) {
  return abs((a - c) ^ (b - c)) <= EPS && (a - c) * (b - c) <= EPS;
}

bool check(point l, point r) {
  ld dist = INF;
  dist = min(dist, (l - o).len());
  dist = min(dist, (r - o).len());
  if ((l - r).len() > EPS) {
    point norm = (l - r).norm();
    norm = point(-norm.y, norm.x);
    point proj = norm * (norm * l);
    if (inside(l, r, proj)) {
      dist = min(dist, (proj - o).len());
    }
  }
  return dist >= ::r - EPS;
}

vector<point> tangent(point a) {
  assert(a.len() >= r - EPS);
  if (a.len() <= r + EPS) {
    return vector<point> (1, a);
  }
  vector<point> ans;
  ld sn = max(0.0L, r / a.len());
  ld cs = sqrt(max(0.0L, 1 - sn * sn));
  ans.pb(a + (-a).rotate(cs, sn) * cs);
  ans.pb(a + (-a).rotate(cs, -sn) * cs);
#ifdef DEBUG
  for (auto p : ans) {
    assert(abs(p.len() - r) < EPS);
  }
#endif
  return ans;
}

ld solve(point x, point y) {
  ld le = atan2(x.y, x.x);
  ld ri = atan2(y.y, y.x);
  while (ri < le - EPS) {
    ri += 2 * PI;
  }
  for (int i = 0; i < K; i++) {
    ld mid1 = (2 * le + ri) / 3, mid2 = (le + 2 * ri) / 3;
    point cen1 = point(cos(mid1), sin(mid1)) * r;
    point cen2 = point(cos(mid2), sin(mid2)) * r;
    ld value1 = (a - cen1).ang(o - cen1) - (b - cen1).ang(o - cen1);
    ld value2 = (a - cen2).ang(o - cen2) - (b - cen2).ang(o - cen2);
    if (abs(value1) < abs(value2)) {
      ri = mid2;
    } else {
      le = mid1;
    }
  }
  
  point cen = point(cos(le), sin(le)) * r;
  //eprintf("cen: %.3f %.3f\n", (double) cen.x, (double) cen.y);
  if (!check(cen, a) || !check(cen, b)) {
    return 1e18;
  }
  return (cen - a).len() + (cen - b).len();
}

void solve() {
  a = a - o, b = b - o;
  o = point(0, 0);
  ld lx = -INF, rx = INF;
  ld ly, ry;
  for (int i = 0; i < K; i++) {
    ld a[2] = {(2 * lx + rx) / 3, (lx + 2 * rx) / 3};
    ld ans[2];
    for (int j = 0; j < 2; j++) {
      ly = -INF, ry = INF;
      for (int k = 0; k < K; k++) {
        ld midl = (2 * ly + ry) / 3, midr = (ly + 2 * ry) / 3;
        point l = point(a[j], midl), r = point(a[j], midr);
        ld ansl = (l - ::a).len() + (l - b).len() + (l - o).len();
        ld ansr = (r - ::a).len() + (r - b).len() + (r - o).len();
        if (ansl < ansr) {
          ry = midr;
        } else {
          ly = midl;
        }
      }
      point cur = point(a[j], ly);
      ans[j] = (cur - ::a).len() + (cur - b).len() + (cur - o).len();
    }
    if (ans[0] < ans[1]) {
      rx = a[1];
    } else {
      lx = a[0];
    }
  }
  //eprintf("%.19f\n", (double) (rx - lx));
  point tor(lx, ly);
  //eprintf("%.3f %.3f\n", (double) tor.x, (double) tor.y);
  
  if (check(tor, a) && check(tor, b)) {
    printf("%.18f\n", (double) ((tor - a).len() + (tor - b).len() + tor.len() - r));
    return;
  }
  vector<point> t1 = tangent(a), t2 = tangent(b);
  ld ans = INF;
  for (auto p1 : t1) {
    for (auto p2 : t2) {
      ans = min(ans, (a - p1).len() + (b - p2).len() + r * p1.ang(p2));
    }
  }
  if (!check(a, b)) {
    printf("%.18f\n", (double) ans);
    return;
  }
  if (abs(a.len() - r) < EPS || abs(b.len() - r) < EPS) {
    printf("%.18f\n", (double) ((a - b).len()));
    return;
  }
  for (auto p1 : t1) {
    for (auto p2 : t2) {
      ans = min(ans, solve(p1, p2));
      ans = min(ans, solve(p2, p1));
    }
  }
  printf("%.18f\n", (double) ans);
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
