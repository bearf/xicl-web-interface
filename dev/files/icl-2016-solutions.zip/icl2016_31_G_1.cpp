#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

int n, a[10010];
bool mark[1010];

int main()
{
    cin >> n;
    for (int i = 0; i < n; i++)
        cin >> a[i];
    sort(a, a + n);
    reverse(a, a + n);
    int sum = 0;
    for (int i = 0; i < n; i++)
        if (!mark[i])
        {
            mark[i] = 1;
            sum++;
            int s = a[i];
            for (int u = i + 1; u < n; u++)
                if (!mark[u] && s > a[u])
            {
                mark[u] = 1;
                s = a[u];

            }
        }


    cout << sum;
    return 0;
}
