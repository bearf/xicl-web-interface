#define _CRT_SECURE_NO_WARNINGS

#include <cmath>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdint.h>
#include <string>
#include <cassert>
using namespace std;

typedef long long ll;
typedef double ld;

const ld EPS = 1e-9;
const ld PI = acos(-1.);

inline bool eq(ld a, ld b)
{
	return abs(a - b) < EPS;
}

inline bool ls(ld a, ld b)
{
	return a < b - EPS;
}

inline bool gr(ld a, ld b)
{
	return ls(b, a);
}

inline bool lseq(ld a, ld b)
{
	return a < b + EPS;
}

inline bool greq(ld a, ld b)
{
	return lseq(b, a);
}

struct Point
{
	ld x, y;

	Point() {}

	Point(ld _x, ld _y) : x(_x), y(_y) {}

	void Scan()
	{
		int _x, _y;
		cin >> _x >> _y;
		x = _x;
		y = _y;
	}

	Point operator + (Point b)
	{
		return Point(x + b.x, y + b.y);
	}

	Point operator - (Point b)
	{
		return Point(x - b.x, y - b.y);
	}

	Point operator * (ld k)
	{
		return Point(x * k, y * k);
	}

	Point operator / (ld k)
	{
		if (eq(k, 0.))
			throw;
		return Point(x / k, y / k);
	}

	ld operator * (Point b)
	{
		return x * b.y - y * b.x;
	}

	ld operator % (Point b)
	{
		return x * b.x + y * b.y;
	}

	ld sqlen()
	{
		return *this % *this;
	}

	ld len()
	{
		return sqrt(sqlen());
	}

	Point norm(ld k)
	{
		if (eq(len(), 0.))
			throw;
		return *this / len() * k;
	}
	Point rotate()
	{
		return Point(-y, x);
	}

	void Print()
	{
		cout << x << ' ' << y << '\n';
	}
};

Point projec(Point A, Point B, Point C)
{
	return A + (B - A) * ((B - A) % (C - A) / (B - A).sqlen());
}

bool seg(Point A, Point B, Point C)
{
	return lseq((A - C) % (B - C), 0.);
}

bool inter(Point A, Point B, Point O, ld r, Point &M1, Point &M2)
{
	Point H = projec(A, B, O);

	ld d = (O - H).len();

	if (greq(d, r))
		return false;

	ld len = sqrt(r * r - d * d);

	Point a = (B - A).norm(len);

	M1 = H + a;
	M2 = H - a;

	return seg(A, B, M1) && seg(A, B, M2);
}

ld oncir(Point O, Point A, Point B)
{
	ld ang = atan2((A - O) * (B - O), (A - O) % (B - O));
	ang = abs(ang);

	return min(ang, 2 * acos(-1.) - ang);
}

bool intercir(Point O1, ld r1, Point O2, ld r2, Point &M1, Point &M2)
{

	ld d = (O1 - O2).len();

	if (eq(d, 0.))
	{
		if (eq(r1, r2))
		{
			M1 = O1 + Point(0, r1);
			M2 = O1 - Point(0, r1);
			return true;
		}
		return false;
	}
	ld d1 = (r1 * r1 + d * d - r2 * r2) / (2. * d);
	
	if (greq(r1, d1))
	{
		ld h = sqrt(r1 * r1 - d1 * d1);
		Point a = (O2 - O1).norm(h).rotate();
		Point H = (O2 - O1).norm(d1) + O1;
		M1 = H + a;
		M2 = H - a;
		return true;
	}
	else
		return false;
}


ld getang(Point A, Point B, Point C)
{
	return atan2((A - C) * (B - C), (A - C) % (B - C));
}

bool fin(Point A, Point B, Point C, ld ang1, ld ang2, Point M)
{
	return eq(getang(A, B, M), ang1) && eq(getang(B, C, M), ang2);
}

bool check(Point A, Point B, Point C, Point O1, Point O2, ld ang1, ld ang2)
{
	Point M1, M2;

	if (eq((O2 - O1).len(), 0.))
	{
		Point a = (O1 - (A + B) / 2.).norm((O1 - B).len());

		Point X = O1 + a;

		if (fin(A, B, C, ang1, ang2, X))
		{
			X.Print();
			return true;
		}

		X = O1 + a;

		if (fin(A, B, C, ang1, ang2, X))
		{
			X.Print();
			return true;
		}

		return false;
	}

	if (intercir(O1, (O1 - B).len(), O2, (O2 - B).len(), M1, M2))
	{
		
		if (fin(A, B, C, ang1, ang2, M1))
		{
			M1.Print();
			return true;
		}
		if (fin(A, B, C, ang1, ang2, M2))
		{
			M2.Print();
			return true;
		}
	}
	return false;
}


Point getvec(Point A, Point B, ld ang)
{
	Point H = (A + B) / 2.;
	ld len = (B - A).len() / 2.;

	return (B - A).norm(tan(PI / 2 - ang) * len).rotate();
}


int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
#ifdef AWWW
	assert(freopen("input.txt", "r", stdin) != nullptr);
#endif

	int n;

	cin >> n;
	cout.precision(20);

	while (n--)
	{
		Point A, B, C;
		A.Scan();
		B.Scan();
		C.Scan();
		int an1, an2;
		cin >> an1 >> an2;
		ld ang1, ang2;
		ang1 = an1;
		ang2 = an2;
		ang1 = ang1 / 180. * PI;
		ang2 = ang2 / 180. * PI;

		Point H1 = (A + B) / 2.;
		Point H2 = (C + B) / 2.;
		Point a1 = getvec(A, B, ang1);
		Point a2 = getvec(C, B, ang2);

		if (check(A, B, C, H1 + a1, H2 + a2, ang1, ang2))
			continue;

		if (check(A, B, C, H1 - a1, H2 + a2, ang1, ang2))
			continue;

		if (check(A, B, C, H1 + a1, H2 - a2, ang1, ang2))
			continue;

		if (check(A, B, C, H1 - a1, H2 - a2, ang1, ang2))
			continue;
		throw;
	}


#ifdef AWWW
	while (true) {}
#endif
}