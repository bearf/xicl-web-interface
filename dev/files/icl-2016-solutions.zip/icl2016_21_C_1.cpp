#include <bits/stdc++.h>

using namespace std;

double solve (string s, char need, char start){ //����� �������� �� start -> need
    /*pair <char, char> topbot;
    pair <char, char> rightleft;
    pair <char, char> frontend;

    topbot = make_pair(s[1], s[3]);
    rightleft = make_pair(s[2], s[4]);
    frontend = make_pair(s[0], s[5]);*/

    if (start == s[0]){
        if (need == s[5])
            return 1.0;
        else
            return 0.5;
    }
    if (start == s[1]){
        if (need == s[3])
            return 1.0;
        else
            return 0.5;
    }
    if (start == s[2]){
        if (need == s[4])
            return 1.0;
        else
            return 0.5;
    }
    if (start == s[3]){
        if (need == s[1])
            return 1.0;
        else
            return 0.5;
    }
    if (start == s[4]){
        if (need == s[2])
            return 1.0;
        else
            return 0.5;
    }
    if (start == s[5]){
        if (need == s[0])
            return 1.0;
        else
            return 0.5;
    }
}

int main(){
    ios_base::sync_with_stdio(false);
    //freopen("input.txt" , "r" , stdin); freopen("output.txt" , "w" , stdout);
    int n;
    double ans = 1.0;
    string st, ed;
    cin >> st >> ed;
    n = st.length();
    vector <string> vec;
    for (int i = 0; i < n; i++){
        string a;
        cin >> a;
        vec.push_back(a);
    }

    for (int i = 0; i < n; i++){
        if (st[i] != ed[i])
            ans *= solve(vec[i], st[i], ed[i]);
    }

    cout << setprecision(20) << ans << endl;
    return 0;
}
