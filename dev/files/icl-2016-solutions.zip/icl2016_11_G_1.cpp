#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)

// -- MAIN PART


int a[1111], d[1111];

int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) cin >> a[i];
	sort(a, a + n);

	int ans = 0;

	for (int it = 0; it < n; it++) {
		int ma =  1e9 + 1;
		for (int i = n - 1; i >= 0; i--) if (!d[i] && a[i] < ma) {
			d[i] = 1;
			ma = a[i];
		}
		if (ma > 1e9) break;
		ans++;
	}
	cout << ans << endl;


	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
