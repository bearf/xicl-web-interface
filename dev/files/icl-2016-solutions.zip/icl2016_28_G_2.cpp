#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>

using namespace std;

void solve();

int main() {
#ifdef ICL
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	int t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
}

void solve() {
	int n;
	cin >> n;
	map<int, int> m;
	for (int i = 0; i < n; ++i) {
		int cur;
		cin >> cur;
		++m[cur];
	}
	int ans = 0;
	for (auto item : m) {
		ans = max(ans, item.second);
	}
	cout << ans << "\n";
}
