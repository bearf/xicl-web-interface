#define _CRT_SECURE_NO_WARNINGS

#include <vector>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>
#include <cassert>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

const double eps = 1e-8;
const double pi = atan(1.) * 4;

bool Eq(double a, double b)
{
	return fabs(a - b) < eps;
}

bool Ls(double a, double b)
{
	return a < b && !Eq(a, b);
}

bool LsEq(double a, double b)
{
	return a < b || Eq(a, b);
}

bool Gr(double a, double b)
{
	return a > b && !Eq(a, b);
}

bool GrEq(double a, double b)
{
	return a > b || Eq(a, b);
}

double sqr(double a)
{
	return a * a;
}

double mySqrt(double a)
{
	if (a < 0)
		return 0;
	return sqrt(a);
}

struct Point
{
	double x, y;
	Point() : x(), y() {}
	Point(double _x, double _y) : x(_x), y(_y) {}
	Point operator + (const Point &a) const
	{
		return Point(x + a.x, y + a.y);
	}
	Point operator - (const Point &a) const
	{
		return Point(x - a.x, y - a.y);
	}
	Point operator * (double k) const
	{
		return Point(x * k, y * k);
	}
	Point operator / (double k) const
	{
		return Point(x / k, y / k);
	}
	double operator % (const Point &a) const
	{
		return x * a.x + y * a.y;
	}
	double operator * (const Point &a) const
	{
		return x * a.y - y * a.x;
	}
	double length()
	{
		return mySqrt(x * x + y * y);
	}
	double sqrLen()
	{
		return x * x + y * y;
	}
	Point norm()
	{
		return *this / length();
	}
	Point rotate(double a)
	{
		return rotate(sin(a), cos(a));
	}
	Point rotate(double sina, double cosa)
	{
		return Point(x * cosa - y * sina, x * sina + y * cosa);
	}
	Point ort()
	{
		return Point(-y, x);
	}
	bool operator == (const Point &a) const
	{
		return Eq(x, a.x) && Eq(y, a.y);
	}
	void scan()
	{
		scanf("%lf%lf", &x, &y);
	}
	void print()
	{
		printf("%.7lf %.7lf\n", x, y);
	}
};

bool intersectLines(Point A, Point v, Point B, Point u, Point &P)
{
	if (Eq(v * u, 0))
		return false;
	double k = (A * v - B * v) / (u * v);
	P = B + u * k;
	return true;
}

bool intersectCircles(Point O1, double R1, Point O2, double R2, Point &I1, Point &I2)
{
	Point v = O2 - O1;
	double d = v.length();
	if (Ls(R1 + R2, d) || Ls(d, fabs(R1 - R2)))
		return false;
	double l = (sqr(R1) + sqr(d) - sqr(R2)) / (2 * d);
	double h = mySqrt(sqr(R1) - sqr(l));
	Point dir = v.norm() * l;
	Point u = v.norm().ort() * h;
	I1 = O1 + dir + u;
	I2 = O1 + dir - u;
	return true;
}

vector <Point> getCenters(Point A, Point B, double angle)
{
	angle = pi / 2 - angle;
	Point v = B - A;
	Point M = (A + B) / 2;
	Point u = v.ort();

	vector <Point> res = {};
	Point I;

	assert(intersectLines(M, u, A, v.rotate(angle), I));
	res.push_back(I);
	assert(intersectLines(M, u, A, v.rotate(-angle), I));
	res.push_back(I);
	return res;
}

double scanAngle()
{
	double angle;
	scanf("%lf", &angle);
	angle = angle / 180 * pi;
	return angle;
}

double getAngle(Point P, Point A, Point B)
{
	double angle = atan2((A - P) * (B - P), (A - P) % (B - P));
	return (angle);
}

bool checkPoint(Point A, Point B, Point C, double a, double b, Point Res)
{
	if (A == Res || B == Res || C == Res)
		return false;
	double aRes = fabs(getAngle(Res, A, B));
	double bRes = fabs(getAngle(Res, B, C));
	return Eq(aRes, a) && Eq(bRes, b);
}

Point getMiddle(Point O, Point A, Point B)
{
	double angle = getAngle(O, A, B);
	if (angle < 0)
		angle += 2 * pi;
	angle /= 2;
	return O + (A - O).rotate(angle);
}

Point tmp[4];
bool solveSpec(Point A, Point B, Point C, double a, double b, Point O)
{
	tmp[0] = A, tmp[1] = B, tmp[2] = C;
	for (int i = 0; i < 3; i++)
		for (int s = 0; s < 3; s++)
		{
			if (i == s)
				continue;
			Point M = getMiddle(O, tmp[i], tmp[s]);
			if (checkPoint(A, B, C, a, b, M))
			{
				M.print();
				return true;
			}
		}
	return false;
}

void solve()
{
	Point A, B, C;
	A.scan();
	B.scan();
	C.scan();
	double a = scanAngle();
	double b = scanAngle();

	for (Point C1 : getCenters(A, B, a))
	{
		for (Point C2 : getCenters(B, C, b))
		{
			if (C1 == C2)
			{
				if (solveSpec(A, B, C, a, b, C1))
					return;
				continue;
			}
			double R1 = (C1 - B).length();
			double R2 = (C2 - B).length();
			Point I1, I2;
			if (intersectCircles(C1, R1, C2, R2, I1, I2))
			{
				if (checkPoint(A, B, C, a, b, I1))
				{
					I1.print();
					return;
				}
				if (checkPoint(A, B, C, a, b, I2))
				{
					I2.print();
					return;
				}
			}
		}
	}
	assert(1 == 0);
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	
	assert(1 == 0);
	return 0;
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		solve();
	}

	return 0;
}