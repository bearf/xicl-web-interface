#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <bitset>
#include <complex>
using namespace std;

#pragma comment(linker, "/STACK:16000000")

typedef long long ll;
const int N = 10;
const int SZ = 100;
const int MOD = (int)1e9 + 9;

void add_to(int &a, int b)
{
	a += b;
	if (a >= MOD)
		a -= MOD;
}

int mul(int a, int b)
{
	return (ll)a * b % MOD;
}

struct Matrix
{
	int a[SZ][SZ];

	Matrix() : a() {}

	Matrix(int e)
	{
		clear(e);
	}

	void clear(int e)
	{
		memset(a, 0, sizeof(a));
		for (int i = 0; i < SZ; i++)
			a[i][i] = e;
	}

	int *operator[](int p)
	{
		return a[p];
	}

	const int *operator[](int p) const
	{
		return a[p];
	}

	Matrix operator*(const Matrix &b) const
	{
		Matrix res(0);
		for (int i = 0; i < SZ; i++)
			for (int j = 0; j < SZ; j++)
				for (int k = 0; k < SZ; k++)
					add_to(res[i][j], mul(a[i][k], b[k][j]));
		return res;
	}
};

ll n;
int m;
int colors[N];
Matrix mat, step, vec;

Matrix bin_pow(Matrix a, ll b)
{
	Matrix res(1);
	while (b > 0)
	{
		if (b % 2 == 1)
			res = res * a;
		a = a * a;
		b /= 2;
	}
	return res;
}

int get_id(int pref, int sh)
{
	assert(0 <= pref && pref < N && 0 <= sh && sh < N);
	return pref * N + sh;
}

void solve()
{
	scanf("%lld%d", &n, &m);
	for (int i = 1; i <= m; i++)
		scanf("%d", &colors[i]);

	mat.clear(1);
	for (int sh = 0; sh < N; sh++)
	{
		int delta = (sh == N - 1 ? 1 : 0);
		int me = get_id(0, sh);
		step.clear(0);
		for (int pref = 0; pref < N; pref++)
		{
			int from = (pref == 0 ? sh + 1 : 0);
			for (int x = from; x < N; x++)
				step[get_id(pref, x)][get_id(pref - delta, x)] = 1;
		}
		for (int k = 1; k <= m; k++)
		{
			int to = get_id(min(sh, k) - delta, abs(sh - k));
			add_to(step[me][to], colors[k]);
		}
		if (m >= 2 && sh == 0)
		{
			int to = get_id(1, 0);
			add_to(step[me][to], colors[2]);
		}
		mat = mat * step;
	}

	vec[0][get_id(0, 0)] = 1;
	mat = bin_pow(mat, n);
	vec = vec * mat;

	printf("%d\n", vec[0][get_id(0, 0)]);
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	solve();

	return 0;
}