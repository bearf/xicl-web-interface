#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <bitset>
#include <complex>
using namespace std;

const int N = 200500;

struct Node
{
	char key;
	int pr, cnt;
	bool rev;
	Node *l, *r;

	Node() : key(), pr(), cnt(), rev(), l(), r() {}

	Node(char _key) : key(_key), pr(rand()), cnt(1), rev(), l(), r() {}
};

typedef Node* pNode;

int cnt(pNode v)
{
	if (v == nullptr)
		return 0;
	return v->cnt;
}

void update(pNode v)
{
	if (v == nullptr)
		return;
	v->cnt = cnt(v->l) + cnt(v->r) + 1;
}

void push(pNode v)
{
	if (v == nullptr)
		return;
	if (v->rev)
	{
		if (v->l != nullptr)
			v->l->rev ^= true;
		if (v->r != nullptr)
			v->r->rev ^= true;
		swap(v->l, v->r);
		v->rev = false;
	}
}

void split(pNode v, int k, pNode &t1, pNode &t2)
{
	if (v == nullptr)
	{
		t1 = t2 = nullptr;
		return;
	}
	push(v);
	int my = cnt(v->l);
	if (my <= k)
	{
		split(v->r, k - my - 1, v->r, t2);
		t1 = v;
	}
	else
	{
		split(v->l, k, t1, v->l);
		t2 = v;
	}
	update(v);
}

pNode merge(pNode t1, pNode t2)
{
	if (t1 == nullptr)
		return t2;
	if (t2 == nullptr)
		return t1;
	if (t1->pr > t2->pr)
	{
		push(t1);
		t1->r = merge(t1->r, t2);
		update(t1);
		return t1;
	}
	push(t2);
	t2->l = merge(t1, t2->l);
	update(t2);
	return t2;
}

void modify(pNode &root, int x)
{
	pNode t1, t2;
	split(root, x - 1, t1, t2);
	if (t1 != nullptr)
		t1->rev ^= true;
	if (t2 != nullptr)
		t2->rev ^= true;
	root = merge(t1, t2);
}

int n, q;
char buf[N];
int buf_sz;
pNode root;

void dfs_print(pNode v)
{
	if (v == nullptr)
		return;
	push(v);
	dfs_print(v->l);
	buf[buf_sz++] = v->key;
	dfs_print(v->r);
}

void solve()
{
	scanf("%s", buf);
	n = strlen(buf);

	for (int i = 0; i < n; i++)
		root = merge(root, new Node(buf[i]));

	scanf("%d", &q);
	for (int i = 0; i < q; i++)
	{
		int x;
		scanf("%d", &x);
		modify(root, x);
	}

	dfs_print(root);
	puts(buf);
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	srand(31415);
	solve();

	return 0;
}