#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)

typedef long long ll;

// -- MAIN PART

int a[6], b[6];

int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	int n;
	scanf("%d", &n);
	forn(i, n) scanf("%d%d", a + i, b + i);
	ll x = 1, y = b[0];
	forn(i, n)
	{
		x = x / __gcd(x, (ll)a[i]) * a[i];
		y = __gcd(y, (ll)b[i]);
	}
	printf("%I64d %I64d\n", x, y);

	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
