#define _CRT_SECURE_NO_WARNINGS

#include <cmath>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdint.h>
#include <string>
#include <ctime>
#include <cassert>
using namespace std;

typedef long long ll;
typedef double ld;

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
#ifdef AWWW
	assert(freopen("input.txt", "r", stdin) != nullptr);
#endif

	int l, n, k;
	cin >> l >> n >> k;

	int i;
	for (i = 0; i < l /*&& n > 0*/ && n > k; ++i)
	{
		if (n % k == 1)
			--n;
		n -= (((n - 1) / k) << 1) + 1;
	}

	n -= (l - i);

	cout << max(0, n) << endl;

#ifdef AWWW
	cout << "\n\n\nTIME: " << clock() / (ld)CLOCKS_PER_SEC << endl;
	while (true) {}
#endif
}