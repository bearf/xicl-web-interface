#pragma once
#pragma once
#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <math.h>
//#include <conio.h>

#define long long ll
#define unsigned long long ull

using namespace std;

int main() {

	int L, N, K, F, p;

	cin >> L >> N >> K;
	
	for (int i = 1; i <= L; i++) {

		F = (N / K);
		if (N%K > 2) {
			F++;
		}
		p = (F - 1) * 2 + 1;
		N -= p;
		if (N <= 0) {
			cout << 0;
			//_getch();
			return 0;
		}
	}

	cout << N;

	//_getch();

	return 0;

}