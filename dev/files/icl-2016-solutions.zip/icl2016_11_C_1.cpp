#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)

// -- MAIN PART

int d[] = {5, 3, 4, 1, 2, 0};


int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif

	string s, t;
	cin >> s >> t;
	int n = s.size();
	double ans = 1;
	for (int i = 0; i < n; i++) {
		string c;
		cin >> c;
		for (int j = 0; j < 6; j++) {
			if (c[j] == s[i]) {
				if (c[j] == t[i] || (c[d[j]] == t[i])) {
				} else {
					ans *= 0.5;
				}
			}
		}
	}
	cout << ans;


	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
