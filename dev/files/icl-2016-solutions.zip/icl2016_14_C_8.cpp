#include <bits/stdc++.h>

using namespace std;
long double prob=1.0;
long long IMA = 1, MOZE = 1;

bool omotac(char a,char b,char c,char d,char x)
{
    int ret=0;
    if(a==x)ret++;
    if(b==x)ret++;
    if(c==x)ret++;
    if(d==x)ret++;

    return ret;
}
double calc(string s,char p,char t)
{
    long long mog=0,ima=0;

    if(omotac(s[0],s[2],s[4],s[5],p)>0)
    {
        mog+=omotac(s[0],s[2],s[4],s[5],p);
        if(omotac(s[0],s[2],s[4],s[5],t)>0)ima+=omotac(s[0],s[2],s[4],s[5],p);
    }
    if(omotac(s[0],s[1],s[3],s[5],p)>0)
    {
        mog+=omotac(s[0],s[1],s[3],s[5],p);
        if(omotac(s[0],s[1],s[3],s[5],t)>0)ima+=omotac(s[0],s[1],s[3],s[5],p);

    }
    if(omotac(s[1],s[2],s[3],s[4],p)>0)
    {
        mog+=omotac(s[1],s[2],s[3],s[4],p);
        if(omotac(s[1],s[2],s[3],s[4],t)>0)ima+=omotac(s[1],s[2],s[3],s[4],p);

    }

    IMA *= ima;
    MOZE *= mog;
}
string k[1000010];
int main()
{
    string source,target;
    cin>>source>>target;
    int n = source.length();
    for(int i=0; i<n; i++)cin>>k[i];
    for(int i=0; i<n; i++)
    {
        if(source[i]==target[i])continue;
        calc(k[i],source[i],target[i]);
    }

    prob = (long double)IMA / (long double)MOZE;

    cout << fixed << setprecision(11);
    cout << prob;
    return 0;
}
/*
HALLW
HELLO
XABCDH
XAECDe
AbcdeL
AbcdeL
ABOWCD
*/
