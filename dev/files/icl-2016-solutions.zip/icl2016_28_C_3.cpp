#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <string>
#include <iomanip>

using namespace std;

#define mp make_pair
#define pb emplace_back
#define all(a) (a).begin(), (a).end()

typedef long long li;
typedef long double ld;

void solve();

int main() {
#ifdef ICL
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	int t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
}

int pr[6] = { 5, 3, 4, 1, 2, 0 };

void solve() {
	string s, t;
	cin >> s >> t;
	long double ans = 1;
	int n = s.length();
	for (int i = 0; i < n; i++) {
		string st;
		cin >> st;
		long double tmp = 0;
		int cnt = 0;
		for (int j = 0; j < 6; j++)
			if (st[j] == s[i])
				cnt++;
		for (int j = 0; j < 6; j++) {
			if (st[j] == s[i]) {
				if (st[j] == t[i])
					tmp += 1;
				else if (st[pr[j]] == t[i]) {
					tmp += 1;
				}
				else {
					int cn = 0;
					char used[6];
					memset(used, 0, sizeof(used));
					used[j] = used[pr[j]] = 1;
					for (int ij = 0; ij < 6; ij++) {
						if (!used[ij]) {
							used[ij] = used[pr[ij]] = 1;
							if (st[ij] == t[i] || st[pr[ij]] == t[i])
								cn++;
						}
					}
					tmp += cn * 0.5;
				}
			}
		}
		if (cnt == 0)
			ans = 0;
		else
			ans *= (tmp / cnt);
	}

	cout << setprecision(10) << fixed;
	cout << (double)ans << "\n";
}
