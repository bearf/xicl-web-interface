#include <bits/stdc++.h>
using namespace std;

int main() {
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);

    int n;
    scanf("%d", &n);

    int a[n];
    for (int i = 0; i < n; i++) {
        scanf("%d", a + i);
    }

    int ans = 0;
    bool used[n];
    memset(used, 0, sizeof used);

    sort(a, a + n);
    while (true) {
        bool ok = false;
        for (int i = 0, prev = -1; i < n; i++) {
            if (!ok && !used[i]) {
                ok = true;
                prev = i;
                used[i] = true;
            } else if (ok && !used[i] && a[i] > a[prev]) {
                prev = i;
                used[i] = true;
            }
        }
        if (!ok) break;
        ans++;
    }

    printf("%d\n", ans);
}
