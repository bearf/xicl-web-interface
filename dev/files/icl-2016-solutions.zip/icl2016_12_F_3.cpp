#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <string>
#include <map>
#include <queue>
#include<iostream>
#define ll long long int
//#define d double
#define mp make_pair
using namespace std;
const ll mod=1e9+9;
#pragma warning(disable:4996)

ll bp(ll x,ll p){
	if(p==0){
		return (ll)1;
	}
	ll d;
	d=bp(x,p/2);
	if(p%2==0){
		d*=d;
		d%=mod;
	} else{
		d*=d;
		d%=mod;
		d*=x;
		d%=mod;
	}
	return d;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
#endif
	ll k,d,m,i,ans;
	vector<ll> v;
	scanf("%I64d%I64d%I64d",&k,&d,&m);
	if(m%d!=0){
		printf("0");
		return 0;
	}
	m/=d;
	d=m;
	for(i=2;i<sqrt((double)d)+11;i++){
		if(m%i==0){
			v.push_back(0);
			while(m%i==0){
				v[v.size()-1]++;
				m/=i;
			}
		}
	}
	if(m>1){
		v.push_back(1);
	}
	ans=1;
	for(i=0;i<v.size();i++){
		if(v[i]==1){
			d=bp(v[i]+1,k)-2*bp(v[i],k)+2*mod;
		} else{
			d=bp(v[i]+1,k)-2*bp(v[i],k)+bp(v[i]-1,k)+2*mod;
		}
		d%=mod;
		ans*=d;
		ans%=mod;
	}
	printf("%I64d",ans);

	return 0;
}