#include <bits/stdc++.h>

using namespace std;

map <int, int> q;

int main(){
    ios_base::sync_with_stdio(false);
    //freopen("input.txt" , "r" , stdin); freopen("output.txt" , "w" , stdout);
    int n, ans = 0;
    cin >> n;
    int cnt = 0;
    bool log = false;
    for (int i = 0; i < n; i++){
        int x;
        cin >> x;
        q[x]++;
        if (q[x] > ans)
            ans = q[x];
    }

    cout << ans << endl;
    return 0;
}
