import java.io.*;
import java.util.*;
//import java.math.*;

public class D {
	public static void main(String[] args) {
		new D().run();
	}

	Scanner in;
	PrintWriter out;

	void run() {
		in = new Scanner(System.in);
		out = new PrintWriter(System.out);

//		Random rng = new Random();
		// while (true) {
		// System.err.println(":D");
		// int l = rng.nextInt(10) + 1;
		// int n = rng.nextInt(10) + 1;
		// int k = rng.nextInt(10) + 1;
		for (int l = 1; l <= 10; l++)
			for (int n = 1; n <= 10; n++)
				for (int k = 1; k <= 10; k++)
					if (solve(l, n, k) != smart(l, n, k)) {
						throw new AssertionError(l + " " + n + " " + k);
					}

		out.flush();
		// }

//		System.err.println("done");

		 int L = in.nextInt();
		 int N = in.nextInt();
		 int K = in.nextInt();
		 out.println(smart(L, N, K));
		 out.close();
	}

	int f(int n, int d, int k) {
		if (n <= k) {
			return Math.max(n - d, 0);
		}

		if (2 * d >= k) {
			return Math.max(k - d, 0);
		}

		int rem = n % k;

		if (rem >= 2 * d) {
			return (n / k) * (k - 2 * d) + (rem - d);
		} else {
			return (n / k) * (k - 2 * d) + d;
		}
	}

	int solve(int L, int N, int K) {

		// System.err.println(L + " " + N + " " + K);

		int[] dp = new int[L + 1];
		dp[0] = N;

		// int[] from = new int[L + 1];
		int[] from2 = new int[L + 1];
		from2[0] = -1;

		for (int i = 0; i < L; i++)
			for (int j = i + 1; j <= L; j++) {
				int tmp = f(dp[i], j - i, K);
				if (tmp >= dp[j]) {
					dp[j] = tmp;
					from2[j] = i;
				}
			}

		return dp[L];

	}

	int getDiff(int N, int K) {
		if (N <= K) {
			return 1;
		}
		int full = (N - 1) / K;
		int rem = (N - 1) % K;

		return full * 2 + (rem == 0 ? 0 : 1);
	}

	int smart(int L, int N, int K) {
		if (K <= 2) {
			return Math.max(Math.min(N, K) - L, 0);
		}

		while (L > 0) {

			if (N <= 0) {
				return 0;
			}

			int low = 0;
			int high = L;

			int curDiff = getDiff(N, K);

			while (high - low > 1) {
				int mid = (low + high) >> 1;
				if (N <= (long) curDiff * mid || getDiff(N - curDiff * mid, K) != curDiff) {
					high = mid;
				} else {
					low = mid;
				}
			}

			N -= curDiff * high;
			L -= high;
		}

		return N;

	}
}