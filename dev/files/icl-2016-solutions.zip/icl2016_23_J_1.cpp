#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <math.h>
#include <string>

#include <set>
#define re return

typedef long long ll;
typedef unsigned long long ull;

using namespace std;


int main() {
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);

	ll n;
	cin >> n;

	set < pair <ll, ll > > arr;
	set < pair <ll, ll > >::iterator prev, next;
	for (int i = 0; i < n; i++) {
		ll x, y;
		cin >> x;

		if (x > 0) {
			cin >> y;
		}
		else {
			x = abs(x);
			next = arr.lower_bound(make_pair(x, 0));
			ll rl = next->first, rr = next->second;
			if (next != arr.end()) {
				if (x > rl && x < rr) {
						arr.erase(next);
						arr.insert(make_pair(rl, x - 1));
						arr.insert(make_pair(x + 1, rr));
						continue;
					
				}
				else if (x == rl && x != rr) {
					arr.erase(next);
					arr.insert(make_pair(x + 1, rr));
				}
				else if (x == rr && x != rl) {
					arr.erase(next);
					arr.insert(make_pair(rl, x - 1));
				}
			}
			continue;
		}
		if (arr.size() == 0) {
			cout << x << " " << x + y - 1 << endl;
			arr.insert(make_pair(x, x + y - 1));
			continue;
		}
		next = arr.lower_bound(make_pair(x, x + y -1));
		if (next == arr.end()) {
			ll l = arr.begin()->first, r = arr.begin()->second;
			if (x <= r) {

				arr.erase(arr.begin());
				cout << r + 1 << " " << r + y << endl;
				arr.insert(make_pair(l, r + y));
				continue;
			}
			else {
				arr.insert(make_pair(x, x + y - 1));
				cout << x << " " << x + y - 1 << endl;
			}

			continue;
		}
	//	if (next == arr.begin()) {
			prev = next;
			if (prev != arr.begin())
				prev--;
			ll l = prev->first, r = prev->second;
			ll rl = next->first, rr = next->second;
			if (x > r) {
				if (x < rl) {

					arr.insert(make_pair(x, x + y - 2));
					cout << x << " " << x + y - 2 << endl;

				}
				else {

					arr.erase(next);
					cout << x << " " << rr << endl;

					arr.insert(make_pair(x, rr));
				}
			}
			else if (x <= r && x >= l) {
				if (x < rl) {

					arr.erase(prev);
					cout << r + 1<< " " << x + y - 1 << endl;

					arr.insert(make_pair(l, x + y - 1));
				}
				else {
					arr.erase(next);
					arr.erase(prev);
					cout << r + 1 << " " << rr << endl;
					arr.insert(make_pair(l, rr));
				}
			}
			else {
				if (x + y < l) {

					cout <<x << " " << x + y - 1 << endl;

					arr.insert(make_pair(x, x + y - 1));
				}
				else {

					arr.erase(prev);

					cout << x << " " << l - 1 << endl;
					arr.insert(make_pair(x, rr));
				}

			}

		//}
		
	}


	re 0;
}
