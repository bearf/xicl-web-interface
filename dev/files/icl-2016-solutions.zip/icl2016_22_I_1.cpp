#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

const int maxn = 1e5 + 10;

int n;
int t[maxn];
int x[maxn][4];

int read() {
  if (scanf("%d", &n) < 1) {
    return 0;
  }
  for (int i = 0; i < n; ++i) {
    scanf("%d", &t[i]);
    for (int j = 0; j < 4; ++j) {
      scanf("%d", &x[i][j]);
    }
  }
  return 1;
}

int m[4];

int getVal(int x[4]) {
  int val = 0;
  for (int i = 0; i < 4; ++i) {
    val += m[i] * x[i];
  }
  return val;
}

int ans[maxn];

multiset<int> q;

void solve() {
  memset(ans, 0, sizeof(ans));
  for (m[0] = -1; m[0] <= 1; m[0] += 2) {
    for (m[1] = -1; m[1] <= 1; m[1] += 2) {
      for (m[2] = -1; m[2] <= 1; m[2] += 2) {
        for (m[3] = -1; m[3] <= 1; m[3] += 2) {
          q.clear();
          for (int i = 0; i < n; ++i) {
            int val = getVal(x[i]);
            if (t[i] == 1) {
              q.insert(val);
            } else if (t[i] == 2) {
              q.erase(q.find(val));
            } else {
              assert(t[i] == 3);
              ans[i] = max(ans[i], *q.rbegin() - val);
            }
          }
        }
      }
    }
  }
  
  for (int i = 0; i < n; ++i) {
    if (t[i] == 3) {
      printf("%d\n", ans[i]);
    }
  }
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
