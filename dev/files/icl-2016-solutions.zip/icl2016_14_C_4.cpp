#include <bits/stdc++.h>

using namespace std;
long double prob=1.0;
int IMA = 1, MOZE = 1;

bool omotac(char a,char b,char c,char d,char x)
{

    if(a==x)return true;
    if(b==x)return true;
    if(c==x)return true;
    if(d==x)return true;

    return false;
}
double calc(string s,char p,char t)
{
    int mog=0,ima=0;

    if(omotac(s[0],s[2],s[4],s[5],p))
    {
        mog++;
        if(omotac(s[0],s[2],s[4],s[5],t))ima++;
    }
    if(omotac(s[0],s[1],s[3],s[5],p))
    {
        mog++;
        if(omotac(s[0],s[1],s[3],s[5],t))ima++;

    }
    if(omotac(s[1],s[2],s[3],s[4],p))
    {
        mog++;
        if(omotac(s[1],s[2],s[3],s[4],t))ima++;

    }

    IMA *= ima;
    MOZE *= mog;
}
int main()
{
    string source,target;
    cin>>source>>target;
    int n = source.length();
    string k[20];
    for(int i=0; i<n; i++)cin>>k[i];
    for(int i=0; i<n; i++)
    {
      //  if(source[i]==target[i])continue;
        calc(k[i],source[i],target[i]);
    }

    prob = (long double)IMA / (long double)MOZE;

    cout << fixed << setprecision(11);
    cout << prob;
    return 0;
}