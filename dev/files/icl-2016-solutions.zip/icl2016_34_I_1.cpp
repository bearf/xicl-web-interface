#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <map>
#include <string>
#include <complex>

#pragma warning(disable:4996)

using namespace std;

#define x1 first
#define y1 second
#define mlp make_pair
#define pb push_back
#define For(i,n) for(int i=0;i<(n);++i)
#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define all(v) (v).begin(),(v).end()

typedef long long ll;
typedef pair<double, double> point;

const int mod = 1e9 + 9;
const int INF = 2e9;
const ll LONGINF = 4e18;
const double PI = 3.1415926535897932384626433832795;
const double eps = 1e-9;

map<ll, ll> m[16];
ll n, x[4],p[16],tt[4];

void f(ll y) {
	ll t=0,i,j;
	for (i = 0; i < 16; i++) {
		for (j = 0; j < 4; j++) {
			if (i&(1 << j)) {
				tt[j] = -1;
			}
			else {
				tt[j] = 1;
			}
			p[j] = tt[j] * x[j];
		}
		m[i][p[0] + p[1] + p[2] + p[3]] += y;
		if (m[i][p[0] + p[1] + p[2] + p[3]] == 0)m[i].erase(p[0] + p[1] + p[2] + p[3]);
	}
}

void k() {
	ll i, j;
	for (i = 0; i < 16; i++) {
		for (j = 0; j < 4; j++) {
			if (i&(1 << j)) {
				tt[j] = -1;
			}
			else {
				tt[j] = 1;
			}
		}
		p[i] = tt[0] * x[0] + tt[1] * x[1] + tt[2] * x[2] + tt[3] * x[3];
	}
}

void solve() {
	ll i, j, t;
	scanf("%I64d", &n);
	for (i = 0; i < n; i++) {
		scanf("%I64d", &t);
		for (j = 0; j < 4; j++) {
			scanf("%I64d", &x[j]);
		}
		if (t == 1) {
			f(1);
		}
		if (t == 2) {
			f(-1);
		}
		if (t == 3) {
			ll ans = 0;
			for (j = 0; j < 4; j++) {
				x[j] = -x[j];
			}
			k();
			for (j = 0; j < 16; j++) {
				auto it = m[j].rbegin();
				p[j] += it->first;
				ans = max(ans, p[j]);
			}
			printf("%I64d\n", ans);
		}
	}
}

int main() {
#pragma comment(linker,"/STACK:268435456")
#ifdef _DEBUG
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#endif
	//int t;
	//scanf("%d", &t);
	//For(i, t)
	solve();
	return 0;
}