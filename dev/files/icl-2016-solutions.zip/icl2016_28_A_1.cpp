#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <string>
#include <assert.h>

using namespace std;

#define mp make_pair
#define pb emplace_back
#define all(a) (a).begin(), (a).end()

typedef long long li;
typedef long double ld;

void solve();

int main() {
#ifdef ICL
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	cout.precision(20);
	cout << fixed;
	int t = 1;
	cin >> t;
	while (t--) {
		solve();
	}
}

ld PI = acos(-1.0);
ld eps = 1e-9;

struct Point {
	ld x, y;
	Point() {}
	Point(ld x, ld y) :x(x), y(y) {}
	Point operator - (const Point& ot) const {
		return Point(x - ot.x, y - ot.y);
	}
	Point operator + (const Point& ot) const {
		return Point(x + ot.x, y + ot.y);
	}
	Point operator * (ld c) {
		return Point(x * c, y * c);
	}
	Point rotate(ld alpha) const {
		return Point(x * cos(alpha) - y * sin(alpha), x * sin(alpha) + y * cos(alpha));
	}
	void scan() {
		cin >> x >> y;
	}
	ld sqrDist() const {
		return x * x + y * y;
	}
	ld dist() const {
		return sqrt(sqrDist());
	}
	Point normalized() const {
		return Point(x / dist(), y / dist());
	}
	bool operator == (const Point& ot) const {
		return fabs(x - ot.x) < eps && fabs(y - ot.y) < eps;
	}
};

vector<Point> points(3);
vector<ld> angle(2);

bool check(Point a, Point b, ld alpha, Point d) {
	ld cur_co = ((d - a).sqrDist() + (d - b).sqrDist() - (a - b).sqrDist()) / 2 / (d - a).dist() / (d - b).dist();
	return fabs(cos(alpha) - cur_co) < eps;
}

bool check(Point d) {
	bool res = true;
	for (int i = 0; i < 2; ++i) {
		res &= check(points[i], points[i + 1], angle[i], d);
	}
	return res;
}

void solve() {
	for (int i = 0; i < 3; ++i) {
		points[i].scan();
	}
	for (int i = 0; i < 2; ++i) {
		cin >> angle[i];
		angle[i] = angle[i] * PI / 180.0;
	}

	vector<ld> rad(2);
	vector<vector<Point>> centers(2);
	for (int i = 0; i < 2; ++i) {
		rad[i] = (points[i] - points[i + 1]).dist() / 2 / sin(angle[i]);
		for (int dom = -1; dom <= 1; dom += 2) {
			Point cent = (points[i] + points[i + 1]) * 0.5 + (points[i + 1] - points[i]).normalized().rotate(dom * PI / 2) * rad[i] * cos(angle[i]);
			centers[i].push_back(cent);
		}
	}

	for (auto a : centers[0]) {
		for (auto b : centers[1]) {
			ld alpha = acos((rad[0] * rad[0] + (a - b).sqrDist() - rad[1] * rad[1]) / 2 / rad[0] / (a - b).dist());
			for (int dom = -1; dom <= 1; dom += 2) {
				Point now = a + (b - a).normalized().rotate(dom * alpha) * rad[0];
				bool f = true;
				for (int i = 0; i < 3; ++i) {
					if (now == points[i]) {
						f = false;
						break;
					}
				}
				if (!f) {
					continue;
				}
				if (check(now)) {
					cout << now.x << ' ' << now.y << "\n";
					return;
				}
			}
		}
	}
	assert(false);

}
