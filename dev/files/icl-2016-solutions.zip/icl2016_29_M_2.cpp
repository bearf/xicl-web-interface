#include <iostream>
#include <map>
#include <algorithm>

using namespace std;

typedef long long ll;

map <ll, ll> mp;
ll n, q, ans = 1;


ll gcd(ll a, ll b) {
	if (a < b)
		swap(a, b);
	if (b == 0)
		return a;
	return (gcd(a % b, b));
}


int main() {
	cin >> n;
	ll a = 1, b = 1, c, d;
	for (ll i = 0; i < n; i++) {
		cin >> c>> d;
		if (!i)
			a = c, b = d;
		a = a*c/gcd(a, c);
		b = gcd(b, d);
	}
	c = gcd(a, b);
	a /= c;
	b /= c;
	cout << a << ' ' << b;
}