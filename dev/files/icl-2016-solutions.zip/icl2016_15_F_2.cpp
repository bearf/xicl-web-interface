#include <map>
#include <iostream>
#include <stdio.h>
#include <algorithm>
using namespace std;
long long int a[100005] = {0};
map <pair <long long int, long long int>, long long int> x;
    long long int k,d,m, q, w, s,p;
    long long int run(long long fact, long long len)
    {
        if (len == 1)return 1;
        if (x[make_pair(fact, len)] != 0)return x[make_pair(fact, len)];
        long long int sum = 0;
        for (int i = 1; i <= a[0] && a[i] <= fact; i++)
        {
            if ((fact % a[i]) == 0 && (fact / a[i]) % d == 0 && a[i] % d == 0)
            {
                sum = (sum + run(fact / a[i], len - 1)) % 1000000009;
            }
        }
        x[make_pair(fact, len)] = sum;
        return sum;
    }
int main()
{
    cin >> k >> d >> m;
    q = m * d;
    w = 2;
    bool flag;
    while (w * w < q)
    {
        s = w;
        p = a[0];
        flag = false;
        while (q % w == 0)
        {
            flag = true;
            q /= w;
            a[++a[0]] = s;
            s *= w;
        }
        if (flag){
        for (int i = 1; i <= p; i++)
        {
            a[++a[0]] = a[i] * w;
        }}
        w++;
    }
    if (q != 1)
    {
        p = a[0];
        a[++a[0]] = q;
        for (int i = 1; i <= p; i++)
        {
            a[++a[0]] = a[i] * q;
        }
    }
    a[++a[0]] = 1;
    sort(a + 1, a + 1 + a[0]);
    cout << run(m * d, k) << endl;
    return 0;
}
