#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <string>
#include <set>
using namespace std;
int main() {
	
	int n, pr = 0;
	cin >> n;
	int q = 0;
	vector<pair<int, int> > v;
	v.push_back(make_pair(0, 0));
	v.push_back(make_pair(600000000, 600000000));
	for (int i = 0; i < n; i++) {
		int a, b;
		cin >> a;
		q = 0;
		if (a > 0) {
			cin >> b;
			while (a > v[q].first)
				q++;
			int a1, b1;
			if (a > v[q - 1].second && a + b - 1 < v[q].first) {
				b1 = a + b - 1;
				a1 = a;
				pair<int, int> v1 = make_pair(a1, b1);
				v.insert(v.begin() + q, v1);
			}
			else {
				if (a <= v[q - 1].second && a + b - 1 < v[q].first) {
					a1 = v[q - 1].second + 1;
					b1 = a1 + b - 1;
					v[q - 1].second = max(v[q - 1].second, a1 + b - 1);
				}
				else {
					if (a > v[q - 1].second && a + b - 1 >= v[q].first) {
						b1 = v[q].first - 1;
						a1 = a;
						v[q].first = a;
					}
				}
			}

			cout << a1 << ' ' << b1 << endl;
		}
		else
		{
			while (-a > v[q].first) {
				q++;
			}
			pair<int, int> v1 = make_pair(v[q - 1].first, -a - 1);
			pair<int, int> v2 = make_pair(-a + 1, v[q - 1].second);
			v[q].second = v1.second;
			v[q].first = v1.first;

			v.insert(v.begin() + q, v2);
		}
	}
}