#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <string>
using namespace std;
int main() {
	
	string s;
	getline(cin, s);
	int n;
	cin >> n;
	vector<int> v(n);
	for (int i = 0; i < n; i++) {
		cin >> v[i];
	}
	for (int i = 2; i <n; i=i+2) {
		v[i] = v[i - 2] - v[i - 1] + v[i];
	}
	
	if (v[n - 1] < 0) {
		v[n - 1] = n - v[n - 1];
	}
	if (n % 2 == 0) {
		if (v[n - 2] < 0) {
			v[n - 2] = n - v[n - 2];
		}
		reverse(s.begin(), s.begin() + v[n-2]);
		reverse(s.begin() + v[n-2], s.end());
		reverse(s.begin(), s.begin() + v[n-1]);
		reverse(s.begin() + v[n-1], s.end());
	}
	else {
		reverse(s.begin(), s.begin() + v[n - 1]);
		reverse(s.begin() + v[n-1], s.end());
	}
	cout << s;

}
