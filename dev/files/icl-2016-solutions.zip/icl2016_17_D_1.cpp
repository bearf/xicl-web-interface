#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

const int BUBEN = 1e5;
const int T = 5;

int n, k;

int d(int x) {
    return 2 * ((x + k - 1) / k) - 1;
}

int f(int x) {
    if (x % k == 1)
        --x;
    if (x <= 0)
        return 0;
    return x - d(x);
}


int naive(int x, int l) {
    //cerr << x << endl;
    for (int i = 0; i < l; ++i) {
        x = f(x);
        if (x == 0)
            return 0;
        //cerr << x << endl;
    }
    return x;
}

int super(int x, int l) {
    if (x <= BUBEN)
        return naive(x, l);
    while (l > 0) {
        int r = x % k;
        if (r >= T + d(x)) {
            int s = (r - T) / d(x);
            assert(s >= 1);
            int need = min(s, l);
            x -= need * d(x);
            l -= need;
        } else {
            x = f(x);
            --l;
        }
        if (x == 0)
            return 0;
    }
    return x;
}

int shit(int x, int l) {
    if (k < BUBEN)
        return naive(x, l);
    else
        return super(x, l);
}

int main() {
#ifdef LOCAL
    assert(freopen("d.in", "r", stdin));
#endif
    int l;
    cin >> l >> n >> k;

    if (k == 1) {
        cout << "0\n";
        return 0;
    }

    cout << super(n, l) << endl;

}
