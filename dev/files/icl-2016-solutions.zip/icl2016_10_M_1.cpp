#define _CRT_SECURE_NO_WARNINGS
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <ctime>
#include <string>

using namespace std;

void solution();

int main()
{
	ios_base::sync_with_stdio(false);
#ifdef HOME
	freopen("input.txt", "rt", stdin);
	clock_t start = clock();
#endif
	solution();
#ifdef HOME
	cerr.precision(3);
	cerr << endl << "Total time: " << fixed << double(clock() - start) / double(CLOCKS_PER_SEC) << endl;
#endif
	return 0;
}

typedef long long ll;
#define int ll

int gcd(int a, int b)
{
	while (b)
		swap(b, a %= b);
	return a;
}

void solution()
{
	int n;
	cin >> n;
	vector<int> a(n), b(n);
	for (int i = 0; i < n; ++i)
		cin >> a[i] >> b[i];
	int p = 1, q = 1, x = a[0], y = b[0];
	for (int i = 0ll; i < n; ++i)
	{
		p *= a[i];
		q *= b[i];
		x = gcd(x, a[i]);
		y = gcd(y, b[i]);
	}
	p /= x;
	q = y;
	int g = gcd(p, q);
	p /= g;
	q /= g;
	cout << p << " " << q << endl;
}