#include <cstdio>
#include <algorithm>
#include <iostream>
#include <set>
#include <map>
#include <vector>
#include <cstring>
#include <string>
#include <cmath>

#pragma warning (disable : 4996)

#define put push_back
#define mapa make_pair

using namespace std;

long long l, n, k, z = 0;

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
#ifndef _DEBUG
	//freopen("kek.in", "r", stdin);
	//freopen("kek.out", "w", stdout);
#endif
	cin >> l >> n >> k;
	if (k - 2 < 0)
	{
		cout << 0;
		return 0;
	}
	for (long long i = 0; i < l; i++)
	{
		if (n / k == 0)
		{
			cout << 0;
			return 0;
		}
		n = (long long(n / k)) * (k - 2) + max(1ll, n % k - 1);
	}
	//cout << n / (k + (l - 1) * 2) * (k - 2) + max(1ll, n % (k + (l - 1) * 2) - 1);
	cout << n;
	return 0;
}