#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <bitset>
#include <complex>
using namespace std;

typedef long long int int64;

const int mod = 1e9 + 9;

int add(int a, int b)
{
	int res = a + b;
	if (res >= mod)
		res -= mod;
	return res;
}

int sub(int a, int b)
{
	int res = a - b;
	if (res < 0)
		res += mod;
	return res;
}

int mul(int a, int b)
{
	return (int64)a * b % mod;
}

map<int, int> factor(int64 n)
{
	map<int, int> res;
	for (int i = 2; i * i <= n; i++)
	{
		if (n % i != 0)
			continue;
		int cnt = 0;
		while (n % i == 0)
		{
			cnt++;
			n /= i;
		}
		res[i] = cnt;
	}
	if (n != 1)
		res[n] = 1;
	return res;
}

int fast_pow(int a, int64 st)
{
	int res = 1;
	while (st > 0)
	{
		if (st % 2 == 1)
			res = mul(res, a);
		a = mul(a, a);
		st /= 2;
	}
	return res;
}

int solve(int g, int l, int64 k)
{
	auto gf = factor(g);
	auto gl = factor(l);

	vector<int> all;
	for (auto p : gf)
		all.push_back(p.first);
	for (auto p : gl)
		all.push_back(p.first);

	sort(all.begin(), all.end());
	all.erase(unique(all.begin(), all.end()), all.end());

	int ans = 1;
	for (int d : all)
	{
		int a = gf[d];
		int b = gl[d];

		if (a > b)
			return 0;

		int x1 = fast_pow(b - a + 1, k);
		int x2 = mul(2, fast_pow(b - a, k));
		int x3 = 0;
		if (b - a - 1 >= 0)
			x3 = fast_pow(b - a - 1, k);
		int cur = add(x1, x3);
		cur = sub(cur, x2);
		ans = mul(ans, cur);
	}

	return ans;
}

int gcd(int a, int b)
{
	if (b == 0)
		return a;
	return gcd(b, a % b);
}

int lcm(int a, int b)
{
	return a / gcd(a, b) * b;
}

int slow_solve(int g, int l)
{
	int ans = 0;
	for (int i = 1; i <= l; i++)
		for (int j = 1; j <= l; j++)
			if (gcd(i, j) == g && lcm(i, j) == l)
				ans++;
	return ans;
}

void stress()
{
	while (true)
	{
		int a = rand() % 100 + 1;
		int b = rand() % 100 + 1;
		int ans1 = solve(a, b, 2);
		int ans2 = slow_solve(a, b);
		assert(ans1 == ans2);
	}
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int64 k;
	scanf("%lld", &k);
	int64 g, l;
	scanf("%lld%lld", &g, &l);
	
	int ans1 = solve(g, l, k);
	printf("%d\n", ans1);
	

	return 0;
}