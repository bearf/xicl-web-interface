#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{

	int n;
	scanf("%d", &n);
	vector<int> list(n);
	for (int i = 0; i < n; i++)
		scanf("%d", &list[i]);
	sort(list.rbegin(), list.rend());
	vector<bool> used(n);
	int ans = 0;
	for (int i = 0; i < n; i++)
	{
		if (used[i])
			continue;
		ans++;
		int prev = i;
		used[i] = true;
		for (int j = i + 1; j < n; j++)
		{
			if (used[j])
				continue;
			if (list[j] < list[prev])
			{
				used[j] = true;
				prev = j;
			}
		}
	}

	printf("%d", ans);

	return 0;
}