#include <bits/stdc++.h>

#define fr first
#define sc second
#define all(x) x.begin(), x.end()

using namespace std;

const int MAXN = 1e5;

    map<int, int> cnt;
int main()
{
    int n, mas[MAXN];
    cin >> n;
    int mx = 0;
    for (int i = 0; i < n; i++) {
        cin >> mas[i];
        cnt[mas[i]]++;
        if (cnt[mas[i]] > mx) {
            mx = cnt[mas[i]];
        }
    }
    cout << mx;
}
