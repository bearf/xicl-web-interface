#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <map>
#include <string>

#pragma warning(disable:4996)

using namespace std;

#define x1 first
#define y1 second
#define mp make_pair
#define pb push_back
#define For(i,n) for(int i=0;i<(n);++i)
#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define all(v) (v).begin(),(v).end()

typedef long long ll;

const int mod = 1e9 + 9;
const int INF = 2e9;
const ll LONGINF = 4e18;

ll bin(ll a, ll b) {
	ll l,i,dv,k=a%mod;
	ll ans = 1;
	a %= mod;
	for (i = 0; i < 30; i++) {
		dv = (1 << i);
		if ((b&dv) > 0) {
			ans = (ans*k) % mod;
		}
		k = (k*k) % mod;
	}
	return ans%mod;
}


void solve() {
	ll i, j, k, d, m,p,t;
	ll ans = 1;
	scanf("%I64d%I64d%I64d", &k, &d, &m);
	if (m%d != 0) {
		printf("0");
		return;
	}
	m = m / d;
	for (i = 2; i <= sqrt((double)m); i++) {
		p = 0;
		while (m%i == 0) {
			m /= i;
			p++;
		}
		if (p > 0) {
			t = (bin(p+1, k));
			t = (t - bin(p, k) + mod) % mod;
			t = (t - bin(p, k) + mod) % mod;
			t = (t + bin(p-1, k)) % mod;
			ans = (ans*t) % mod;
		}
	}
	p = 1;
	if (m != 1) {
		if (p > 0) {
			t = (bin(p + 1, k));
			t = (t - bin(p, k) + mod) % mod;
			t = (t - bin(p, k) + mod) % mod;
			t = (t + bin(p - 1, k)) % mod;
			ans = (ans*t) % mod;
		}
	}
	printf("%I64d", ans);
}

int main() {
#pragma comment(linker,"/STACK:268435456")
#ifdef _DEBUG
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#endif
	solve();
	return 0;
}