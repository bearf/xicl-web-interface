#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

const int maxn = (int) 1e5 + 10;
int xs[maxn], ps[maxn];

int n;
int read() {
  if (scanf("%d", &n) < 1) {
    return 0;
  }
  for (int i = 0; i < n; ++i) {
    scanf("%d", &xs[i]);
    if (xs[i] > 0) {
      scanf("%d", &ps[i]);
    }
  }
  return 1;
}

void solve() {
  set<pair<int, int> > tree;
  for (int i = 0; i < n; ++i) {
    /*eprintf("%d\n", sz(tree));
    for (auto iter = tree.begin(); iter != tree.end(); ++iter) {
      eprintf("(%d,%d)\n", iter->first, iter->second);
    }*/
    int x = xs[i], p = ps[i];
    if (x > 0) {
      auto iter2 = tree.lower_bound(mp(x + 1, -INF));
      int from = x;
      if (iter2 != tree.begin()) {
        auto iter = iter2;
        --iter;
        from = iter->second;
      }
      if (iter2 != tree.end() && from + p >= iter2->first) {
        printf("%d %d\n", from, iter2->first - 1);
        int left = from, right = iter2->second;
        tree.erase(iter2);
        tree.insert(mp(left, right));
      } else {
        printf("%d %d\n", from, from + p - 1);
        tree.insert(mp(from, from + p));
      }
      
      {
        auto iter = tree.lower_bound(mp(from, -INF));
        assert(iter->first == from);
        auto cur = *iter;
        if (iter != tree.begin()) {
          auto iter2 = iter;
          --iter2;
          if (iter2->second == from) {
            int left = iter2->first;
            tree.erase(iter2);
            tree.erase(cur);
            tree.insert(mp(left, cur.second));
          }
        }
      }
    } else {
      x = -x;
      
      auto iter2 = tree.lower_bound(mp(x + 1, -INF));
      assert(iter2 != tree.begin());
      auto iter = iter2;
      --iter;
      int l = iter->first, r = iter->second;
      assert(l <= x && x < r);
      tree.erase(iter);
      if (l < x) {
        tree.insert(mp(l, x));
      }
      if (x < r) {
        tree.insert(mp(x + 1, r));
      }
    }
  }
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
