#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <string>
#include <assert.h>

using namespace std;

#define mp make_pair
#define pb emplace_back
#define all(a) (a).begin(), (a).end()

typedef long long li;
typedef long double ld;

void solve();

int main() {
#ifdef ICL
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	cout.precision(20);
	cout << fixed;
	int t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
}

vector<vector<int>> ans;

void add12(int n, int x, int y) {
	ans.push_back(vector<int>({ n, x, y }));
}

void add3(int x, int y, int z) {
	ans.push_back(vector<int>({ 3, x, y, y, z }));
}

void out() {
	cout.sync_with_stdio(0);
	cout << ans.size() << "\n";
	for (auto x : ans) {
		for (auto y : x)
			cout << y << " ";
		cout << "\n";
	}
}

void solve() {
	int a, b, c, d;
	cin >> a >> b >> c >> d;
	if (a < b) {
		if (c >= d) {
			puts("0");
			return;
		}
	} else
	if (a > b) {
		if (c <= d) {
			puts("0");
			return;
		}
	}
	else {
		if (c != d) {
			puts("0");
			return;
		}
		else {
			while (a > 1) {
				if (a % 2) {
					add12(1, a, a);
					a += 1;
				}
				else {
					add12(2, a, a);
					a /= 2;
				}
			}
			while (a < c) {
				add12(1, a, a);
				a += 1;
			}
			out();
			return;
		}
	}

	if (a < b) {
		int g = b - a;
		while (g % 2 == 0)
			g /= 2;
		if ((d - c) % g != 0) {
			puts("0");
			return;
		}
		while (b - a > g) {
			if (a % 2 == 0) {
				add12(2, a, b);
				a /= 2, b /= 2;
			}
			else {
				add12(1, a, b);
				a++, b++;
			}
		}
		while (a > 1) {
			if (a % 2 == 1) {
				add12(1, a, b);
				a++, b++;
			}
			for (int i = 0; i < g; i++) {
				add12(1, a + i, b + i);
			}
			add3(a, a + g, a + g + g);
			add12(2, a, a + g + g);
			a /= 2;
			b = a + g;
		}
		while (b - a != d - c) {
			for (int i = 0; i < g; i++) {
				add12(1, a + i, b + i);
			}
			add3(a, a + g, b + g);
			b += g;
		}
		while (a < c) {
			add12(1, a, b);
			a++, b++;
		}
		out();
	}
	else {
		int g = a - b;
		while (g % 2 == 0)
			g /= 2;
		if ((c - d) % g != 0) {
			puts("0");
			return;
		}
		while (a - b > g) {
			if (b % 2 == 0) {
				add12(2, a, b);
				a /= 2, b /= 2;
			}
			else {
				add12(1, a, b);
				a++, b++;
			}
		}
		while (b > 1) {
			if (b % 2 == 1) {
				add12(1, a, b);
				a++, b++;
			}
			for (int i = 0; i < g; i++) {
				add12(1, a + i, b + i);
			}
			add3(a + g, a, a - g);
			add12(2, a + g, a - g);
			b /= 2;
			a = b + g;
		}
		while (b - a != d - c) {
			for (int i = 0; i < g; i++) {
				add12(1, a + i, b + i);
			}
			add3(a + g, b + g, b);
			a += g;
		}
		while (a < c) {
			add12(1, a, b);
			a++, b++;
		}
		out();
	}
}
