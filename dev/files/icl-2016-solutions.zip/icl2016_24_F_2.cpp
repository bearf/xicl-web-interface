#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdint.h>
#include <string>
#define re return
using namespace std;
typedef long long ll;
const ll mod = 1e9 + 9;
ll pow1(ll a, ll st) {
	if (st == 1) re a % mod;
	if (st == 0) re 1;
	ll ans = pow1(a, st / 2);
	ans = (ans * ans) % mod;
	if (st % 2)
		ans = (ans * a) % mod;
	re ans;
}
int main()
{
	
	ll n, m, k, ans = 1;
	cin >> k >> n >> m;
	if (m % n) {
		cout << 0;
		re 0;
	}
	m /= n;
	for (ll i = 2; i * i <= m; i++) {
		ll q = 1;
		while (m % i == 0) {
			q++;
			m /= i;
		}
		if (q > 1) {
			ans = (ans * (pow1(q, k) - 2LL * pow1(q - 1, k) + pow1(q - 2, k))) % mod;
		}
	}
	if (m > 1) {
		ll q = 2;
		ans = (ans * (pow1(q, k) - 2LL * pow1(q - 1, k) + pow1(q - 2, k))) % mod;
	}
	cout << (ans % mod + mod) % mod << endl;
	//cin >> ans;
#ifdef AWWW
	system("pause");
#endif
}