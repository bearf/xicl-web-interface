#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

const int maxn = 15;

int n;
string from, to;
string s[maxn];

void scan() {
    cin >> from >> to;
    n = from.size();
    string t;
    forn(i, n) {
        cin >> t;
        s[i].resize(6);
        s[i][0] = t[0];
        s[i][1] = t[5];
        s[i][2] = t[2];
        s[i][3] = t[4];
        s[i][4] = t[1];
        s[i][5] = t[3];
        //cerr << s[i] << endl;
    }
}

void solve() {
    double res = 1;
    forn(i, n) {
        int c1 = 0, c2 = 0;
        forn(u, 6) forn(f, 6) {
            if (u/2 == f/2) continue;
            if (s[i][f] != from[i]) continue;
            ++c1;
            forn(j, 6) if (u/2 != j/2) {
                if (s[i][j] == to[i]) {
                    ++c2;
                    break;
                }
            }
        }
        //cerr << c1 << " " << c2 << endl;
        res *= (double)c2/c1;
    }
    cout.precision(10);
    cout << fixed;
    cout << res << endl;
}

int main() {
#ifdef LOCAL
    assert(freopen("c.in", "r", stdin));
#endif

    scan();
    solve();

    return 0;
}
