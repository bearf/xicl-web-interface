#include <bits/stdc++.h>
using namespace std;
int tests;
double pi=acos(-1.0);
double dist(double x1,double y1,double x2,double y2)
{
    return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}
double m1x,m1y,m2x,m2y,m3x,m3y;
double angle1,angle2;
pair<double,double> solveQuad(double a,double b, double c)
{
    //printf("%f %f %f\n",a,b,c);
    double disc=sqrt(b*b-4*a*c);
    pair<double,double> ret;
    ret.first=(-b+disc)/2.0/a;;
    ret.second=(-b-disc)/2.0/a;
    return ret;
}
pair<pair<double,double>,pair<double,double> >findIntersection(double x1,double y1,double x2,double y2, double r1,double r2)
{
    double k1=r1*r1-r2*r2+x2*x2+y2*y2-x1*x1-y1*y1;
    double k2=2.0*(y2-y1);
    double k3=2.0*(x2-x1);
    if(x2==x1)
    {
        //printf("ISTI\n");
        double yres=-k1/k2;
        double xres=sqrt(r1*r1-(yres-y1)*(yres-y1));
        return make_pair(make_pair(-xres+x1,yres),make_pair(xres+x1,yres));
    }
    double k4=k1/k3;
    double k5=k2/k3;
    //printf("K45 %f %f\n",k4,k5);
    double a=k5*k5+1;
    double b=2*k4*k5-2*x1*k5-2*y1;
    double c=k4*k4-2*x1*k4+x1*x1+y1*y1-r1*r1;
    pair<double,double> ys=solveQuad(a,b,c);
    return make_pair(make_pair(k4+k5*ys.first,ys.first),make_pair(k4+k5*ys.second,ys.second));
}
double angleFrom(int x1,int y1,int x2,int y2,int x3,int y3)
{
    double ab=dist(x1,y1,x2,y2);
    double bc=dist(x2,y2,x3,y3);
    double ac=dist(x3,y3,x1,y1);
    //printf("%f %f %f\n",ab,ac,bc);
    //printf("%f %f\n",ab*ab+ac*ac-bc*bc,2*ab*ac);
    return (ab*ab+ac*ac-bc*bc)/(2*ab*ac);
}
bool equall(double a, double b)
{
    return fabs(a-b)<0.00000001;
}
double cos1,cos2,sin1,sin2;
bool totallyOkay(pair<double,double> pt)
{
    //printf("%f %f %f %f\n",angleFrom(pt.first,pt.second,m1x,m1y,m2x,m2y),angleFrom(pt.first,pt.second,m2x,m2y,m3x,m3y),cos1,cos2);
    if(equall(angleFrom(pt.first,pt.second,m1x,m1y,m2x,m2y),cos1)&&equall(angleFrom(pt.first,pt.second,m2x,m2y,m3x,m3y),cos2))
    {printf("%.6lf %.6lf\n",pt.first,pt.second);return true;}
    return false;
}
double r1,r2;

bool check(pair<double,double> a,pair<double,double> b)
{
    //printf("%f %f %f %f\n",a.first,a.second,b.first,b.second);
    pair<pair<double,double>,pair<double,double> >ints=findIntersection(a.first,a.second,b.first,b.second,r1,r2);
    if(totallyOkay(ints.first)) return true;
    if(totallyOkay(ints.second)) return true;
    return false;
}
int main()
{
    scanf("%d",&tests);
    while(tests--)
    {

        scanf("%lf%lf%lf%lf%lf%lf%lf%lf",&m1x,&m1y,&m2x,&m2y,&m3x,&m3y,&angle1,&angle2);
        double ang1=1.0*angle1/180*pi;
        double ang2=1.0*angle2/180*pi;
        sin1=sin(ang1);
        cos1=cos(ang1);
        sin2=sin(ang2);
        cos2=cos(ang2);
        double dist1=dist(m1x,m1y,m2x,m2y);
        double dist2=dist(m2x,m2y,m3x,m3y);
        r1=dist1/2.0/sin1;
        r2=dist2/2.0/sin2;
        //if(totallyOkay(make_pair(1.0,1.0))) puts("TRUE");
        //printf("%f %f\n",r1,r2);
        pair<pair<double,double>,pair<double,double> > c1=findIntersection(m1x,m1y,m2x,m2y,r1,r1);
        pair<pair<double,double>,pair<double,double> > c2=findIntersection(m2x,m2y,m3x,m3y,r2,r2);
        if(check(c1.first,c2.first)) continue;
        if(check(c1.second,c2.first))continue;
        if(check(c1.first,c2.second)) continue;
        if(check(c1.second,c2.second)) continue;
    }
    return 0;
}
/*
1
0 0 2 0 2 2 90 90
*/
