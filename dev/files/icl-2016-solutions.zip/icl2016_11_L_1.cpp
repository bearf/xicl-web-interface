#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define F first
#define S second

// -- MAIN PART

const int maxn = 4011;

int a, b, c, d;
int q[32000111];
int q1, q2;
char was[maxn][maxn];
char rec[maxn][maxn];

bitset<4011> A[maxn];
bitset<4011> B[maxn];
bitset<4011> tmp;

vector<string> ans;

set<pair<int, int> > have;

void re(int x, int y) {
	vector<pair<pair<int, int>, char> > e;
	while (x != a || y != b) {
		int xx, yy;
		if (rec[x][y] == '+') {
			xx = x - 1;
			yy = y - 1;
		} else {
			xx = x * 2;
			yy = y * 2;
		}
		e.push_back(mp(mp(xx, yy), rec[x][y]));
		x = xx;
		y = yy;
	}
	reverse(e.begin(), e.end());
	for (int i = 0; i < e.size(); i++) {
		int x = e[i].F.F;
		int y = e[i].F.S;
		char t = e[i].S;

		int xx, yy;
		if (t == '+') {
			xx = x + 1;
			yy = y + 1;
		} else {
			xx = x / 2;
			yy = y / 2;
		}

		if (have.find(mp(xx, yy)) == have.end()) {
			have.insert(mp(xx, yy));
			stringstream q;
			if (t == '+') q << 1; else q << 2;
			q << " " << x << " " << y;
			ans.push_back(q.str());
		}
	}
}

void merg(int x, int y, int z) {
	if (have.find(mp(x, y)) != have.end()) return;
	have.insert(mp(x, y));
	stringstream q;
	q << 3 << " " << x << " " << z << " " << z << " " << y;
	ans.push_back(q.str());
}

void re2(int x, int y) {
	while (x != c || y != d) {
		int xx, yy;
		if (was[x][y] == '-') {
			xx = x + 1;
			yy = y + 1;
		} else {
			xx = x / 2;
			yy = y / 2;
		}
//		cerr << xx << " " << yy << endl;
		if (have.find(mp(xx, yy)) == have.end()) {
			have.insert(mp(xx, yy));
			stringstream q;
			if (was[x][y] == '-') q << 1; else q << 2;
			q << " " << x << " " << y;
			ans.push_back(q.str());
		}
		x = xx;
		y = yy;
	}
}


int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	cin >> a >> b;

	cin >> c >> d;

	was[a][b] = 1;
	q[q1++] = a;
	q[q1++] = b;

	while (q1 != q2) {
		int x = q[q2++];
		int y = q[q2++];
		if (x % 2 == 0 && y % 2 == 0 && was[x / 2][y / 2] == 0) {
			rec[x / 2][y / 2] = 'd';

			was[x / 2][y / 2] = 1;
			q[q1++] = x / 2;
			q[q1++] = y / 2;
		}
		if (max(x, y) + 1 < maxn && was[x + 1][y + 1] == 0) {
			rec[x + 1][y + 1] = '+';

			was[x + 1][y + 1] = 1;
			q[q1++] = x + 1;
			q[q1++] = y + 1;
		}
	}
	if (was[c][d]) {
		re(c, d);
		cout << ans.size() << endl;
		for (int i = 0; i < ans.size(); i++) cout << ans[i] << endl;
		return 0;
	}

	for (int i = 0; i < maxn; i++) for (int j = 0; j < maxn; j++) if (was[i][j]) {
		A[i].set(j);
		B[j].set(i);
	}

	for (int i = 0; i < maxn; i++) for (int j = 0; j < maxn; j++) was[i][j] = 0;

	was[c][d] = 1;
	q[q1++] = c;
	q[q1++] = d;

	while (q1 != q2) {
		int x = q[q2++];
		int y = q[q2++];

		if (max(x, y) * 2 < maxn && was[x * 2][y * 2] == 0) {
			was[x * 2][y * 2] = '*';
			q[q1++] = x * 2;
			q[q1++] = y * 2;
		}
		if (min(x, y) > 1 && was[x - 1][y - 1] == 0) {
			was[x - 1][y - 1] = '-';
			q[q1++] = x - 1;
			q[q1++] = y - 1;
		}
	}

	int aa = -1, bb = -1, cc = -1;

	for (int i = 0; i < maxn; i++) for (int j = 0; j < maxn; j++) if (was[i][j] && aa == -1) {
		tmp = A[i] & B[j];
		if (tmp.count() > 0) {
			for (int k = 0; k < maxn; k++) if (tmp.test(k)) {
				aa = i;
				bb = j;
				cc = k;
				break;
			}
		}
	}
	if (aa == -1) {
		puts("0");
		return 0;
	}
	re(aa, cc);
	re(cc, bb);

	merg(aa, bb, cc);

	re2(aa, bb);

	cout << ans.size() << endl;
	for (int i = 0; i < ans.size(); i++) cout << ans[i] << endl;




	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
