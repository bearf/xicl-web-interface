#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <string>
#include <set>
using namespace std;
int main() {
	
	int n, pr = 0;
	cin >> n;
	set<int> s;
	for (int i = 0; i < n; i++) {
		int a, b,a1,b1;
		cin >> a;
		if (a < 0) {
			s.erase(-a);
			continue;
		}
		cin >> b;
		pr = 0; a1 = 0, b1 = 0;
		for (int j = a; j < a + b; j++) {
			int s1 = s.size();
			int s2;
			s.insert(j);
			if (s.size() == s1 && pr==0) {
				a++;
				continue;
			}
			if (s.size() != s1) {
				if (a1 == 0)
					a1 = j;
				else
					b1 = j;
				pr++;
			}
			else
				break;
		}
		cout << a1 << ' ' << max(b1, a1) << endl;
	}
}