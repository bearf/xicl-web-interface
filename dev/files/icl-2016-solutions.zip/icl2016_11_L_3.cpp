#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define F first
#define S second

// -- MAIN PART

const int maxn = 2011;

int a, b, c, d;
int q[32000111];
int q1, q2;
char was[maxn][maxn];
char rec[maxn][maxn];
int mem[maxn][maxn];

bitset<2011> A[maxn];
bitset<2011> B[maxn];
bitset<2011> tmp;

vector<string> ans;

void re(int x, int y) {
	if (x == a && y == b) return;
	if (was[x][y]) return;
	was[x][y] = 1;

	int xx, yy;

	if (rec[x][y] == '+') {
		xx = x - 1;
		yy = y - 1;
		re(xx, yy);
		stringstream q;

		q << 1 << " " << xx << " " << yy;
		ans.push_back(q.str());
	} else
	if (rec[x][y] == 'd') {
		xx = x * 2;
		yy = y * 2;
		re(xx, yy);
		stringstream q;

		q << 2 << " " << xx << " " << yy;
		ans.push_back(q.str());
	} else {
		int z = mem[x][y];
		re(x, z);
		re(z, y);

		stringstream q;

		q << 3 << " " << x << " " << z << " " << z << " " << y;
		ans.push_back(q.str());
	}
}

int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	cin >> a >> b;

	cin >> c >> d;

	was[a][b] = 1;
	A[a].set(b);
	B[b].set(a);

	q[q1++] = a;
	q[q1++] = b;

	while (q1 != q2) {
		int x = q[q2++];
		int y = q[q2++];
		if (x == c && y == d) break;
//		cout << x << " " << y << endl;
		if (x % 2 == 0 && y % 2 == 0 && was[x / 2][y / 2] == 0) {
			rec[x / 2][y / 2] = 'd';

			A[x / 2].set(y / 2);
			B[y / 2].set(x / 2);
			was[x / 2][y / 2] = 1;

			q[q1++] = x / 2;
			q[q1++] = y / 2;
		}
		if (max(x, y) + 1 < maxn && was[x + 1][y + 1] == 0) {
			rec[x + 1][y + 1] = '+';

			A[x + 1].set(y + 1);
			B[y + 1].set(x + 1);
			was[x + 1][y + 1] = 1;

			q[q1++] = x + 1;
			q[q1++] = y + 1;
		}
		tmp = A[y] & (~A[x]);
		int z = -1;
		for(;;) {
			z = tmp._Find_next(z);
			if (z == maxn) break;

			rec[x][z] = 'm';
			mem[x][z] = y;

			was[x][z] = 1;

			A[x].set(z);
			B[z].set(x);

			q[q1++] = x;
			q[q1++] = z;
		}
		tmp = B[x] & (~B[y]);
		z = -1;
		for(;;) {
			z = tmp._Find_next(z);
			if (z == maxn) break;

			rec[z][y] = 'm';
			mem[z][y] = x;

			was[z][y] = 1;
			A[z].set(y);
			B[y].set(z);

			q[q1++] = z;
			q[q1++] = y;
		}
	}
	if (was[c][d] == 0) {
		puts("0");
		return 0;
	}

	for (int i = 0; i < maxn; i++) for (int j = 0; j < maxn; j++) was[i][j] = 0;
	re(c, d);

	cout << ans.size() << endl;
	for (int i = 0; i < ans.size(); i++) cout << ans[i] << endl;




	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
