#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

const int maxn = 500500;
string s, t;

int main() {
#ifdef LOCAL
    assert(freopen("h.in", "r", stdin));
#endif
    ios::sync_with_stdio(false);
    int q;
    cin >> s >> q;
    t.resize(s.size());
    int n = s.size();
    int pos = 0;
    forn (i, q) {
        int x;
        cin >> x;
        if (x != 0 && x != n) {
            if (pos >= x)
                pos -= x;
            else
                pos += n - x;
        }
        pos = n - 1 - pos;
    }
    //cerr << pos << '\n';
    int delta = q % 2 ? -1 : 1;
    forn (i, n) {
        int to = i * delta + pos;
        to %= n;
        if (to < 0)
            to += n;
        t[to] = s[i];
    }
    cout << t << '\n';
}
