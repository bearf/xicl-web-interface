#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <string>
#include <map>
#include <queue>
#include<iostream>
#define ll long long int
#define d double
#define mp make_pair
using namespace std;
const ll mod=1e9+9;
double pi=3.1415926535897932384626433832795;
#pragma warning(disable:4996)


string s;

struct node {
	ll y,cnt,rev,c;
	node *l,*r;
	node(ll x) {
		y=rand();
		cnt=1;
		rev=0;
		c=x;
		l=r=NULL;
	}
};

void update(node *t) {
	if(t==NULL) {
		return;
	}
	t->cnt=1;
	if(t->l!=NULL) {
		t->cnt+=t->l->cnt;
	}
	if(t->r!=NULL) {
		t->cnt+=t->r->cnt;
	}
	
}

void push(node *t) {
	node *q;
	if(t==NULL) {
		return;
	}
	if(t->rev==1) {
		t->rev=0;
		if(t->l!=NULL) {
			t->l->rev^=1;
		}
		if(t->r!=NULL) {
			t->r->rev^=1;
		}
		q=t->l;
		t->l=t->r;
		t->r=q;
	}
}

void split(node *t,node *&l,node *&r,ll cnt) {
	ll q=0;
	push(t);
	if(cnt==0) {
		l=NULL;
		r=t;
		return;
	}
	if(t->l!=NULL) {
		q=t->l->cnt;
	}
	if(q>=cnt) {
		split(t->l,l,t->l,cnt);
		r=t;
		update(l);
	} else{
		split(t->r,t->r,r,cnt-q-1);
		l=t;
		update(r);
	}
}

void merge(node *&t,node *l,node *r) {
	if(l==NULL) {
		t=r;
		return;
	}
	if(r==NULL) {
		t=l;
		return;
	}
	push(l);
	push(r);
	if(l->y>r->y) {
		merge(l->r,l->r,r);
		t=l;
	} else{
		merge(r->l,l,r->l);
		t=r;
	}
	update(t);
}

void print(node *t) {
	if(t==NULL) {
		return;
	}
	push(t);
	if(t->l!=NULL) {
		print(t->l);
	}
	printf("%c",s[t->c]);
	if(t->r!=NULL) {
		print(t->r);
	}
}

int main() {
#ifdef _DEBUG
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
#endif
	ll n,i,j,m,x;
	node *t,*l,*r,*a,*b;
	cin >> s;
	n=s.size();
	t=new node(0);
	for(i=1;i<n;i++) {
		a=new node(i);
		merge(t,t,a);
	}
	scanf("%I64d",&m);
	for(i=0;i<m;i++) {
		scanf("%I64d",&x);
		split(t,l,r,x);
		if(l!=NULL) {
			l->rev^=1;
		}
		if(r!=NULL) {
			r->rev^=1;
		}
		merge(t,l,r);
	}
	print(t);
	return 0;
}