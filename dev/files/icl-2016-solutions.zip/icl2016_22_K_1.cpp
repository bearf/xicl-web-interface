#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

const int maxn = (int) 1e4 + 10;
char s[maxn], q[maxn];

int n;
int read() {
  if (scanf("%s%s", s, q) < 2) {
    return 0;
  }
  return 1;
}

void makeOp(char *s, vector<pair<int, int> > &ans) {
  int k = 0;
  
  int last = -1;
  for (int i = 0; i < n; ++i) {
    if (s[i] == '0') {
      continue;
    }
    if (last != -1) {
      ans.pb(mp(k, i + 1));
      swap(s[k], s[i]);
      swap(s[last], s[k + i - last]);
      last = k + i - last;
      ++k;
    } else {
      last = i;
    }
  }
}

void solve() {
  n = (int) strlen(s);
  vector<pair<int, int> > ans2;
  makeOp(q, ans2);
  vector<pair<int, int> > ans1;
  makeOp(s, ans1);
  if (strcmp(s, q)) {
    printf("NO\n");
    return;
  }
  reverse(ans2.begin(), ans2.end());
  printf("YES\n");
  for (int i = 0; i < sz(ans2); ++i) {
    ans1.pb(ans2[i]);
  }
  printf("%d\n", sz(ans1));
  for (int i = 0; i < sz(ans1); ++i) {
    printf("%d %d\n", ans1[i].first + 1, ans1[i].second);
  }
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
