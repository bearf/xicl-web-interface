#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

int gcd(int a, int b) {
    while (b) {
        a %= b;
        swap(a, b);
    }
    return a;
}

const int maxn = 15050;
bool rev = false;
int type[maxn]; // 0: +1, 1: /2, 2: merge
int v1[maxn], v2[maxn], v3[maxn];
int nc;

set<pair<int, int>> have;

void ADD(int x, int y) {
    //assert(have.count({x, y}));
    if (have.count({x+1, y+1})) return;
    have.insert({x+1, y+1});
    v1[nc] = x;
    v2[nc] = y;
    type[nc] = 0;
    ++nc;
}

void DIV(int x, int y) {
    //assert(have.count({x, y}));
    //assert(x%2 == 0 && y%2 == 0);
    if (have.count({x/2, y/2})) return;
    have.insert({x/2, y/2});
    v1[nc] = x;
    v2[nc] = y;
    type[nc] = 1;
    ++nc;
}

void MERGE(int x, int y, int z) {
    //assert(have.count({x, y}));
    //assert(have.count({y, z}));
    if (have.count({x, z})) return;
    have.insert({x, z});
    v1[nc] = x;
    v2[nc] = y;
    v3[nc] = z;
    type[nc] = 2;
    ++nc;
}

int a, b, c, d;

void FAIL() {
    cout << 0 << endl;
    exit(0);
}

void reduce() {
    while (a != 1 || b%2 == 1) {
        if (a%2 != b%2) {
            forn(i, b-a) {
                ADD(a + i, b + i);
            }
            MERGE(a, b, b+(b-a));
            b += b-a;
        } else if (a%2 == 0) {
            DIV(a, b);
            a /= 2;
            b /= 2;
        } else {
            ADD(a, b);
            ++a;
            ++b;
        }
    }
}

bool check_reduce() {
    int mx = 0;
    forn(i, 500) forn(j, 500) if (i && j && i <= j) {
        nc = 0;
        have.clear();
        a = i;
        b = j;
        reduce();
        mx = max(mx, nc);
        if (nc >= 15000) {
            cerr << i << " " << j << ": " << nc << endl;
        }
    }
    //cerr << "mx = " << mx << endl;
}

void solve() {
    cin >> a >> b >> c >> d;
    if (a > b) {
        swap(a, b);
        swap(c, d);
        rev = true;
    }

    if ((a == b) != (c == d)) FAIL();
    if (c > d) FAIL();

    have.insert({a, b});

    reduce();
    //cerr << "after reduce: " << a << " " << b << endl;
    //cerr << "g = " << b-1 << endl;

    int g = b-1;

    if (g == 0) {
        forn(i, c-1) {
            ADD(i+1, i+1);
        }
    } else {
        if ((d-c) % g != 0) {
            FAIL();
        } else {
            int k = (d-c) / g;
            forn(i, k-1) {
                forn(j, g) ADD(a+j, b+j);
                MERGE(a, b, b+g);
                MERGE(1, b, b+g);
                a += g;
                b += g;
                //cerr << a << " " << b << endl;
            }
            a = 1;
            forn(i, c-1) {
                ADD(a, b);
                ++a;
                ++b;
            }
            assert(a == c && b == d);
        }
    }
}

void out() {
    assert(nc <= 15000);
    cout << nc << "\n";
    //return;
    forn(i, nc) {
        cout << type[i]+1 << " ";
        if (type[i] == 0 || type[i] == 1) {
            if (!rev) cout << v1[i] << " " << v2[i] << "\n";
            else cout << v2[i] << " " << v1[i] << "\n";
        } else {
            if (rev) swap(v1[i], v3[i]);
            cout << v1[i] << " " << v2[i] << " " << v2[i] << " " << v3[i] << "\n";
        }
    }

#ifdef LOCAL
    cerr << "nc = " << nc << endl;
#endif
}

int main() {
#ifdef LOCAL
    assert(freopen("l.in", "r", stdin));
#endif

    //check_reduce();

    solve();
    out();

    return 0;
}
