#include <bits/stdc++.h>

using namespace std;

string s, s2;
string arr[10];
double chance = 1.0;
double add[6][6] = {
{1.0, 0.5, 0.5, 0.5, 0.5, 1.0},
{0.5, 1.0, 0.5, 1.0, 0.5, 0.5},
{0.5, 0.5, 1.0, 0.5, 1.0, 0.5},
{0.5, 1.0, 0.5, 1.0, 0.5, 0.5},
{0.5, 0.5, 1.0, 0.5, 1.0, 0.5},
{1.0, 0.5, 0.5, 0.5, 0.5, 1.0}
}; 

int main() {
  cin >> s >> s2;
  for (int i = 0; i < s.size(); i++) {
    cin >> arr[i];
  }
  for (int i = 0; i < s.size(); i++) {
    int idx = 0;
    int idx2 = 0;
    vector <int> v1;
    for (int j = 0; j < arr[i].size(); j++) {
      if (arr[i][j] == s[i]) {
        v1.push_back(j);
      }
    }
    //cout << v1.size() << '\n';
    double sum = 0.0;
    double mx = 0.0;
    for (int j = 0; j < v1.size(); j++) {
      for (int k = 0; k < arr[i].size(); k++) {
        if (arr[i][k] == s2[i]) {
          mx = max(add[v1[j]][k], mx);
          //cout << mx << '\n';
        }
        //cout << arr[i][k] << ' ' << s[k] << '\n';
      }
      sum += mx;
    }
    chance *= sum / (1.0*v1.size());
  }
  cout << fixed << setprecision(10) << chance;
  return 0;
}