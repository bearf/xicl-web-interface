#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

const int N = 200200;
char s[N];
int n, q;
int p, z;

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	scanf(" %s", s);
	n = strlen(s);
	scanf("%d", &q);
	p = 0;
	z = 0;
	while (q--)
	{
		int x;
		scanf("%d", &x);
		eprintf("%d\n", x);
		p = (n - p) % n;
		p = (p - x + n) % n;
		z ^= 1;
	}
	if (z)
	{
		for (int i = 0; i < n - 1 - i; i++)
			swap(s[i], s[n - 1 - i]);
	}
	for (int i = p; i < n; i++)
		printf("%c", s[i]);
	for (int i = 0; i < p; i++)
		printf("%c", s[i]);

	return 0;
}