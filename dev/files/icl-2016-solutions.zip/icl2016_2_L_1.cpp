#define _CRT_SECURE_NO_WARNINGS

#include <vector>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>
#include <cassert>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

struct Item
{
	int type;
	int a, b, c, d;

	Item() : type(), a(), b(), c(), d() {}
	Item(int _type, int _a, int _b) : type(_type), a(_a), b(_b), c(-1), d(-1) {}
	Item(int _type, int _a, int _b, int _c, int _d) : type(_type), a(_a), b(_b), c(_c), d(_d) {}
};

bool REV = false;
vector<Item> ans;

int A, B, C, D;

void Fail()
{
	printf("0\n");
	exit(0);
}

void printAns()
{
	printf("%d\n", (int)ans.size());
	for (Item I : ans)
	{
		if (REV)
		{
			swap(I.a, I.b);
			swap(I.c, I.d);
			if (I.type == 3)
			{
				swap(I.a, I.c);
				swap(I.d, I.b);
			}
		}
		if (I.type == 3)
			printf("%d %d %d %d %d\n", I.type, I.a, I.b, I.c, I.d);
		else
			printf("%d %d %d\n", I.type, I.a, I.b);
	}
	exit(0);
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	scanf("%d%d%d%d", &A, &B, &C, &D);

	if (A == B)
	{
		if (C != D)
			Fail();
		while (A > 1)
		{
			if (A % 2 == 0)
			{
				ans.push_back(Item(2, A, A));
				A /= 2;
			}
			else
			{
				ans.push_back(Item(1, A, A));
				A++;
			}
		}
		while (A < C)
		{
			ans.push_back(Item(1, A, A));
			A++;
		}
		printAns();
	}

	if (A > B)
	{
		swap(A, B);
		swap(C, D);
		REV = true;
	}
	if (C >= D)
		Fail();
	while ((B - A) % 2 == 0)
	{
		if (A % 2 == 0)
		{
			ans.push_back(Item(2, A, B));
			A /= 2;
			B /= 2;
		}
		else
		{
			ans.push_back(Item(1, A, B));
			A++;
			B++;
		}
	}
	int X = A;
	int P = B - A;
	if ((D - C) % P != 0)
		Fail();
	for (int i = A; i <= 4000; i++)
		ans.push_back(Item(1, i, i + P));
	while (X > 1)
	{
		if (A % 2 == 1)
			A++;
		ans.push_back(Item(3, A, A + P, A + P, A + 2 * P));
		ans.push_back(Item(2, A, A + 2 * P));
		A /= 2;
		for (int i = A; i < X; i++)
			ans.push_back(Item(1, i, i + P));
		X = A;
	}
	A = C;
	B = C + P;
	while (B < D)
	{
		ans.push_back(Item(3, A, B, B, B + P));
		B += P;
	}

	printAns();

	return 0;
}