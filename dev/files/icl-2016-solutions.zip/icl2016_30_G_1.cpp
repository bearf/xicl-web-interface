#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
using namespace std;

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int n;
	cin >> n;
	vector <int> v(10001, 0);
	int max = 0;
	for (int i = 0; i < n; i++) {
		int a;
		cin >> a;
		v[a]++;
	}
	int r = 0;
	for (int i = 10000; i >= 0; i--) {
		if (v[i] > r) {
			r += v[i] - r;
		}
	}
	cout << r;
	return 0;
}