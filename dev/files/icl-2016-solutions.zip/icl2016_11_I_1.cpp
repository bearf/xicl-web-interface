#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>
#define pw(x) (1ll << (x))

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)

// -- MAIN PART

multiset<int> S[16];
multiset<int>::iterator it;
int x[4];


int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	int t;
	cin >> t;
	while (t--) {
		int type;
		scanf("%d", &type);
		for (int i = 0; i < 4; i++) scanf("%d", &x[i]);

		if (type < 3) {
			for (int o = 0; o < pw(4); o++) {
				int sum = 0;
				for (int i = 0; i < 4; i++) if (o & pw(i)) sum += x[i]; else sum -= x[i];
				if (type == 1) S[o].insert(sum); else {
					S[o].erase(S[o].find(sum));
				}
			}
		} else {
			int ans = 0;
			for (int o = 0; o < pw(4); o++) {
				int sum = 0;
				for (int i = 0; i < 4; i++) if (o & pw(i)) sum -= x[i]; else sum += x[i];
				it = S[o].end();
				it--;
				sum += (*it);
				ans = max(ans, sum);
			}
			printf("%d\n", ans);
		}
	}


	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
