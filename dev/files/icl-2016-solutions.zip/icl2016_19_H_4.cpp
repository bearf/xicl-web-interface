#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <string>
using namespace std;
int main() {
	string s;
	getline(cin, s);
	int c = s.size();
	vector<char> v(c);
	int n;
	cin >> n;
	int a, b;
	cin >> a;
	for (int i = 0; i < n-1; i++) {
		cin >> b;
		if (a == b) {
			cin >> a; i++;
			if (i == n - 2) {
				reverse(s.begin(), s.begin() + a);
				reverse(s.begin() + a, s.end());
			}
			continue;
		}
		else {
			reverse(s.begin(), s.begin() + a);
			reverse(s.begin() + a, s.end());
			a = b;
			if (i == n - 2) {
				reverse(s.begin(), s.begin() + a);
				reverse(s.begin() + a, s.end());
			}
		}
	}
	cout << s;

}