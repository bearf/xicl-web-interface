#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

const int maxn = 5e5 + 100;
int l, n;
char s[maxn];

int read() {
  if (!gets(s) || scanf("%d", &n) < 1) {
    return 0;
  }
  return 1;
}

void solve() {
  int shift = 0;
  l = strlen(s);
  for (int i = 0; i < n; i++) {
    int cur = 0;
    scanf("%d", &cur);
    if (i & 1) {
      cur = l - cur;
    }
    shift = (shift + cur) % l;
  }
  shift = shift % l;
  rotate(s, s + shift, s + l);
  if (n & 1) {
    reverse(s, s + l);
  }
  printf("%s\n", s);
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
