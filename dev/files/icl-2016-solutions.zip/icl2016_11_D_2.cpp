#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define F first
#define S second

// -- MAIN PART

int l, x, k;

void solve1() {
	for (int i = 0; i < l; i++) {
		int t = x % k;
		if (x == 2 && i + 1 == l) {
			puts("1");
			return;
		}
		if (t <= 2) x -= t;
		int d = (x + k - 1) / k + (x - 1) / k;

		x -= d;
		if (x <= 0) {
//			cerr << i << endl;
			puts("0");
			return;
		}
	}
	cout << x << endl;
}

void solve2() {
	for (int i = 0; i < l; i++) {
		int t = x % k;
		if (x == 2 && i + 1 == l) {
			puts("1");
			return;
		}

		if (t <= 2) x -= t;
		int d = (x + k - 1) / k + (x - 1) / k;

		if (t <= 10 + d || i + 1 == l) {
			x -= d;
		} else {
			int f = (t - 10) / d;
			f = min(f, l - i - 1);

//			cerr << f << endl;

			x -= f * d;
			i += f - 1;
		}
		if (x <= 0) {
			puts("0");
			return;
		}
	}
	cout << x << endl;
}




int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	cin >> l >> x >> k;

	if (k == 1) {
		puts("0");
		return 0;
	}
	if (k == 2) {
		if (l == 1) puts("1"); else puts("0");
		return 0;
	}

	if (k <= 1000000) {
		solve1();
	} else {
		solve2();
	}



	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
