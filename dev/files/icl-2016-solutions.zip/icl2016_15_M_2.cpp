#include <iostream>
#include <stdio.h>
using namespace std;
long long int a[10];
long long int b[10];
long long int gcd(long long int a,long long  int b)
{
    if (b == 0)return a;
    return gcd(b, a%b);
}
long long int lcm(long long int a, long long int b)
{
    return (a * b) / gcd(a, b);
}
int main()
{
    int n;
    long long int a1, b1;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        scanf("%lld%lld", &a[i], &b[i]);
    }
    a1 = a[1];
    b1 = b[1];
    for (int i = 2; i <= n; i++)
    {
        a1 = lcm(a1, a[i]);
        b1 = gcd(b1, b[i]);
    }
    cout << a1 << " " << b1 << endl;
    return 0;
}
