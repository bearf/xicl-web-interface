#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

const ld eps = 1e-9;

bool eq(ld a, ld b) {
    return fabsl(a - b) < eps;
}

struct pt {
    ld x, y;

    pt operator-(const pt &p) const {
        return pt{x - p.x, y - p.y};
    }

    pt operator+(const pt &p) const {
        return pt{x + p.x, y + p.y};
    }

    ld operator*(const pt &p) const {
        return x * p.x + y * p.y;
    }

    ld operator%(const pt &p) const {
        return x * p.y - y * p.x;
    }

    pt operator*(const ld &a) const {
        return pt{x * a, y * a};
    }

    bool operator==(const pt &p) const {
        return eq(x, p.x) && eq(y, p.y);
    }

    ld abs() const {
        return hypotl(x, y);
    }

    ld abs2() const {
        return x * x + y * y;
    }

    pt rrot() const {
        return pt{y, -x};
    }

    pt rot() const {
        return pt{-y, x};
    }

    pt rot(ld ang) const {
        return pt{x * cosl(ang) - y * sinl(ang), x * sinl(ang) + y * cosl(ang)};
    }
};

istream &operator>>(istream &in, pt &p) {
    return in >> p.x >> p.y;
}

ostream &operator<<(ostream &out, pt p) {
    return out << p.x << ' ' << p.y << '\n';
}

const ld maxc = 145000;

pt a, b, c;
ld r;

pt Tx(pt a, pt b, pt c, ld x) {
    ld L = -maxc, R = maxc;
    forn (iter, 300) {
        const ld C1 = 3, C2 = 2;
        ld xl = (L * C1 + R * C2) / (C1 + C2);
        ld xr = (L * C2 + R * C1) / (C1 + C2);
        pt pl = pt{x, L};
        pt pr = pt{x, R};
        ld dl = (a - pl).abs() + (b - pl).abs() + (c - pl).abs();
        ld dr = (a - pr).abs() + (b - pr).abs() + (c - pr).abs();
        if (dl < dr)
            R = xr;
        else
            L = xl;
    }
    return pt{x, L};
}

pt T(pt a, pt b, pt c) {
    ld L = -maxc, R = maxc;
    forn (iter, 300) {
        const ld C1 = 3, C2 = 2;
        ld xl = (L * C1 + R * C2) / (C1 + C2);
        ld xr = (L * C2 + R * C1) / (C1 + C2);
        pt pl = Tx(a, b, c, xl);
        pt pr = Tx(a, b, c, xr);
        ld dl = (a - pl).abs() + (b - pl).abs() + (c - pl).abs();
        ld dr = (a - pr).abs() + (b - pr).abs() + (c - pr).abs();
        if (dl < dr)
            R = xr;
        else
            L = xl;
    }
    return Tx(a, b, c, L);
}

const ld SEP = 4000;
const ld PI = acosl(-1);

pt intersect(pt a, pt b, pt c, pt d) {
    ld S = (b - a) % (d - c);
    if (eq(S, 0))
        return pt{1e18, 1e18};
    ld s1 = (c - a) % (d - a);
    pt v = a + (b - a) * (s1 / S);
    return v;
}

vector<pt> Tnorm(pt a, pt b, pt c) {
    pt d = (b - c).rot(PI / 3) + c;
    pt e = (a - b).rot(PI / 3) + b;
    vector<pt> res;
    pt t1 = intersect(a, d, c, e);
    if (!eq(t1.x, 1e18))
        res.push_back(t1);

    d = (b - c).rot(-PI / 3) + c;
    e = (a - b).rot(-PI / 3) + b;
    pt t2 = intersect(a, d, c, e);
    if (!eq(t2.x, 1e18))
        res.push_back(t2);
    return res;
}

ld res = 1e18;

ld forAng(ld al) {
    pt pl = pt{cosl(al), sinl(al)};
    pl = pl * r;
    return (a - pl).abs() + (b - pl).abs();
}

ld dist(pt p, pt a, pt b) {
    ld res = min((a - p).abs(), (b - p).abs());
    if ((p - a) * (b - a) >= 0 && (p - b) * (a - b) >= 0) {
        res = fabsl((b - a) % (p - a)) / (a - b).abs();
    }
    return res;
}

vector<pt> tangent(pt a) {
    pt h = (a - c);
    h = h * ((r * r) / h.abs2());
    h = h + c;
    ld d = sqrtl(max(ld(0), r * r - h.abs2()));
    pt v = (a - c).rot();
    v = v * (d / v.abs());
    return {h + v, h - v};
}

ld circleDist(pt a, pt b) {
    ld ang1 = atan2l(a.y, a.x);
    ld ang2 = atan2l(b.y, b.x);
    if (ang1 > ang2)
        swap(ang1, ang2);
    return r * min(ang2 - ang1, 2 * PI + ang1 - ang2);
}

void solveHard() {
    //cerr << "slozhno\n";
    auto va = tangent(a);
    auto vb = tangent(b);
    for (auto p: va) {
        assert(eq((p - c).abs(), r));
        assert(eq((a - p) * (c - p), 0));
    }
    for (auto p: vb) {
        assert(eq((p - c).abs(), r));
        assert(eq((b - p) * (c - p), 0));
    }
    for (auto pa: va)
        for (auto pb: vb) {
            ld cres = circleDist(pa, pb) + (pa - a).abs() + (pb - b).abs();
            res = min(res, cres);
        }
    cout << res << '\n';
}

bool lt(ld a, ld b) {
    return b - a > eps;
}

void solve() {
    if (lt(dist(c, a, b), r)) {
        solveHard();
        return;
    }
    vector<ld> all;
    forn (iter, SEP)
        all.push_back(iter * (2 * PI) / SEP);
    all.push_back((2 * PI) / SEP);
    vector<pt> tga = tangent(a);
    vector<pt> tgb = tangent(b);
    for (auto p: tga) {
        all.push_back(atan2l(p.y, p.x));
        all.push_back(PI + atan2l(p.y, p.x));
    }
    for (auto p: tgb) {
        all.push_back(atan2l(p.y, p.x));
        all.push_back(PI + atan2l(p.y, p.x));
    }
    sort(all.begin(), all.end());

    forn (iter, sz(all) - 1) {
        ld L = all[iter];
        ld R = all[iter + 1];
        forn (qwer, 100) {
            const ld C1 = 6, C2 = 5;
            ld al = (L * C1 + R * C2) / (C1 + C2);
            ld ar = (L * C2 + R * C1) / (C1 + C2);

            ld ldist = forAng(al);
            ld rdist = forAng(ar);
            if (ldist < rdist)
                R = ar;
            else
                L = al;
        }
        res = min(res, forAng(L));
    }
    //pt t = T(a, b, c);
    auto tv = Tnorm(a, b, c);
    for (auto t: tv) {
        if ((t - c).abs() >= r) {
            ld cres = (t - a).abs() + (t - b).abs() + (t - c).abs() - r;
            res = min(res, cres);
        }
    }

    ld cres = ((b - a).abs() + (b - c).abs() - r);
    res = min(res, cres);
    cres = ((b - a).abs() + (a - c).abs() - r);
    res = min(res, cres);

    cout << res << '\n';
}

int main() {
    cout.precision(10);
    cout.setf(ios::fixed);
#ifdef LOCAL
    assert(freopen("e.in", "r", stdin));
#endif
    //auto tv = Tnorm(pt{0, 0}, pt{0, 10}, pt{10, 0});
    //for (auto t: tv)
        //cerr << t << endl;
    //return 0;
    cin >> a >> b >> c >> r;
    a = a - c;
    b = b - c;
    c = c - c;
    solve();
}
