
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <map>
#include <algorithm>
#include <vector>
#include <math.h>
#include <string>


#define re return

typedef long long ll;
typedef unsigned long long ull;

using namespace std;


int main() {
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);

	string s;
	
	cin >> s;
	int n;
	cin >> n;

	int x = 0;


	for (int i = 0; i < n; ++i) {
		int y;
		cin >> y;
		int a, b, c;

		if (y <= x) {
			a = y;
			b = x - y;
			c = s.size() - x;
			x = a + c;
		}
		else {
			a = x;
			b = y - x;
			c = s.size() - y;
			x = b;
		}
		//cout << x;

	}

	if (n % 2 == 0) {
		for (int i = s.size() - x; i < s.size(); ++i)
			printf("%c", s[i]);
		for (int i = 0; i < s.size() - x; ++i)
			printf("%c", s[i]);

	}
	else {
		for (int i = x-1; i >= 0; --i)
			printf("%c", s[i]);
		for (int i = s.size()-1; i >= x; --i)
			printf("%c", s[i]);

	}











	re 0;
}
