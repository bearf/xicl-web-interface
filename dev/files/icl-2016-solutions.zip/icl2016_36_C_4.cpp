#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

vector<ll> b;
string s, t;
vector<string> st;
ll n;

void next(){
    for (ll i = (ll)b.size() - 1; i >= 0; i--){
        if (b[i] == 5){
            b[i] = 0;
        }
        else{
            b[i]++;
            break;
        }
    }
}

bool check(){
    for (ll i = 0; i < n; i++){
        if (st[i][b[i]] != s[i])
            return 0;
    }
    return 1;
}

bool is_pair(ll i, ll j){
    bool res = 0;
    res |= j == 0 && (b[i] == 5 || b[i] == 0);
    res |= j == 1 && (b[i] == 3 || b[i] == 1);
    res |= j == 2 && (b[i] == 4 || b[i] == 2);

    res |= j == 5 && (b[i] == 5 || b[i] == 0);
    res |= j == 3 && (b[i] == 3 || b[i] == 1);
    res |= j == 4 && (b[i] == 4 || b[i] == 2);

    return res;
}

pair<ll, ll> solve(){
    pair<ll, ll> res = {1, 1};
    for (ll i = 0; i < n; i++){
        ll now = -1;
        for (ll j = 0; j < 6; j++)
            if (st[i][j] == t[i])
                now = max(now, (ll)(is_pair(i, j)));
        if (now == -1)
            res.first = 0;
        if (now == 0)
            res.second *= 2;
    }

    return res;
}


int main()
{
    //ifstream cin("a.in");
    //ofstream cout("a.out");
    ios::sync_with_stdio(0);
    cin >> s >> t;
    string tr;
    ll k = 1;
    while (cin >> tr)
        st.push_back(tr), k *= 6, b.push_back(0), n++;

    pair<ll, ll> ans = {0, 1};
    ll cnt = 0;
    for (ll i = 0; i < k; i++){
        if (check()){
            cnt++;
            auto kek = solve();
            ans.first = ans.first * kek.second + kek.first * ans.second;
            ans.second *= kek.second;
        }
        next();
    }
    ans.second *= cnt;
    if (cnt == 0)
        cout << 0 << endl;
    else
        cout << setprecision(10) << (double)ans.first / (double)ans.second;
}
