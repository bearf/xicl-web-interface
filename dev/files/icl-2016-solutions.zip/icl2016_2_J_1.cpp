#define _CRT_SECURE_NO_WARNINGS

#include <vector>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;
typedef pair<int, int> pii;
#define X first
#define Y second
#define mp make_pair

set <pii> badSegments;

bool contain(pii seg, int x)
{
	return seg.X <= x && x <= seg.Y;
}

void addSegment(int l, int r)
{
	if (l <= r)
		badSegments.insert(mp(l, r));
}

void eraseField(int x)
{
	auto it = badSegments.lower_bound(mp(x + 1, -1));
	if (it == badSegments.begin())
		return;
	it = prev(it);
	if (contain(*it, x))
	{
		pii cur = *it;
		badSegments.erase(cur);
		addSegment(cur.X, x - 1);
		addSegment(x + 1, cur.Y);
	}
}

pii tmp[10];
int tmpSize = 0;

void mergeTmp()
{
	int newTmp = 0;
	for (int i = 1; i < tmpSize; i++)
	{
		if (tmp[newTmp].Y + 1 == tmp[i].X)
			tmp[newTmp].Y = tmp[i].Y;
		else
			tmp[++newTmp] = tmp[i];
	}
	tmpSize = newTmp + 1;
}

void fix(pii seg)
{
	auto it = badSegments.lower_bound(seg);
	if (*it != seg)
		return;
	if (it != badSegments.begin())
		it--;
	tmpSize = 0;
	for (int i = 0; i < 3 && it != badSegments.end(); i++)
	{
		tmp[tmpSize++] = *it;
		it++;
	}
	for (int i = 0; i < tmpSize; i++)
	{
		badSegments.erase(tmp[i]);
	}
	mergeTmp();
	for (int i = 0; i < tmpSize; i++)
		addSegment(tmp[i].X, tmp[i].Y);
}

pii fillSegment(int x, int len)
{
	auto it = badSegments.lower_bound(mp(x + 1, -1));
	int startPos = x;
	if (it != badSegments.begin())
	{
		it = prev(it);
		if (contain(*it, x))
			startPos = it->Y + 1;
	}
	
	it = badSegments.lower_bound(mp(startPos, -1));
	int endPos = startPos + len - 1;
	if (it != badSegments.end())
		endPos = it->X - 1;
	pii added;
	if (endPos - startPos + 1 > len)
	{
		added = mp(startPos, startPos + len - 1);
	}
	else
	{
		added = mp(startPos, endPos);
	}
	addSegment(added.X, added.Y);
	fix(added);
	return added;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		int x;
		scanf("%d", &x);
		if (x < 0)
			eraseField(-x);
		else
		{
			int len;
			scanf("%d", &len);
			pii res = fillSegment(x, len);
			printf("%d %d\n", res.X, res.Y);
		}
	}

	return 0;
}