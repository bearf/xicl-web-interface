#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

#define nullptr NULL

struct node
{
    int x;
    int sum;
    bool is_set;
    int set;

    node *l, *r;

    node()
    {
        x = 0;
        sum = 0;
        is_set = false;
        l = r = nullptr;
    }
};

void push(node *t, int l, int r)
{
    if (!t -> l)
        t -> l = new node();
    if (!t -> r)
        t -> r = new node();

    if (t -> is_set)
    {
        int m = (l + r) / 2;
        t -> l -> is_set = true;
        t -> r -> is_set = true;
        t -> l -> set = t -> set;
        t -> r -> set = t -> set;
        t -> l -> sum = t -> set * (m - l);
        t -> r -> sum = t -> set * (r - m);

        t -> is_set = false;
    }
}

int get(node *t, int l, int r, int x, int y)
{
    //cerr << l << " " << r << endl;
    if (y <= l || r <= x)
    {
        return 0;
    }
    else if (x <= l && r <= y)
    {
        return t->sum;
    }
    else
    {
        push(t, l, r);
        int m = (l + r) >> 1;
        int answer = 0;

        answer += get(t -> l, l, m, x, y);
        answer += get(t -> r, m, r, x, y);

        return answer;
    }
}

void setp(node *t, int l, int r, int x, int y, int st)
{
    if (y <= l || r <= x)
    {
        return;
    }
    else if (x <= l && r <= y)
    {
        t -> is_set = true;
        t -> set = st;
        t -> sum = st * (r - l);
        return;
    }
    else
    {
        push(t, l, r);
        int m = (l + r) >> 1;

        setp(t -> l, l, m, x, y, st);
        setp(t -> r, m, r, x, y, st);

        t -> sum = t -> l -> sum + t -> r -> sum;

        return;
    }
}

const int MAX_P = 63 * 1000*1000*10;
int n;
node* tree = new node();

int main()
{
    scanf("%d", &n);

    int v1, v2;
    for (int i = 0; i < n; ++i)
    {
        scanf("%d", &v1);

        if (v1 < 0)
        {
            setp(tree, 0, MAX_P, -v1 - 1, -v1, 0);
        }
        else
        {
            scanf("%d", &v2);

            int l = v1 - 1;
            int r = MAX_P;
            int m;

            while (r - l > 1)
            {
                m = (l + r) >> 1;
                if (get(tree, 0, MAX_P, v1 - 1, m) < (m - v1 + 1))
                {
                    r = m;
                }
                else
                {
                    l = m;
                }
            }

            printf("%d ", r);
            int q = r;
            l = q - 1;
            r = MAX_P;

            while (r - l > 1)
            {
                m = (l + r) >> 1;
                if (get(tree, 0, MAX_P, q - 1, m) == 0)
                {
                    l = m;
                }
                else
                {
                    r = m;
                }
            }
            r = min(l, q + v2 - 1) + 1;

            printf("%d\n", r - 1);

            setp(tree, 0, MAX_P, v1 - 1, r - 1, 1);
            //cout << get(tree, 0, MAX_P, v1 - 1, r - 1) << endl;
        }
    }

    return 0;
}

/*

6
5 2
6 3
4 7
1 1
-4
2 4

*/
