#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <string>
#include <map>
#include <queue>
#include<iostream>
#define ll long long int
#define d double
#define mp make_pair
using namespace std;
const ll mod=1e9+9;
const double pi=3.1415926535897932384626433832795;
#pragma warning(disable:4996)


int main() {
#ifdef _DEBUG
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
#endif
	char c[11][11],s1[11],s2[11];
	int i,j,s,n,l;
	double ans,k;
	s=0;
	gets_s(s1);
	n=strlen(s1);
	gets_s(s2);
	for(i=0;i<n;i++){
		gets_s(c[10]);
		c[i][0]=c[10][0];
		c[i][1]=c[10][5];
		c[i][2]=c[10][1];
		c[i][3]=c[10][3];
		c[i][4]=c[10][2];
		c[i][5]=c[10][4];
	}
	ans=1;
	for(i=0;i<n;i++){
		if(s1[i]!=s2[i]){
			s=0;
			k=0;
			for(j=0;j<6;j++){
				if(c[i][j]==s1[i]){
					s++;
				}
			}
			for(j=0;j<6;j++){
				if(c[i][j]==s1[i]){
					if(j%2==0){
						if((c[i][(j+2)%6]==s2[i]||c[i][(j+3)%6]==s2[i])&&(c[i][(j+5)%6]==s2[i]||c[i][(j+4)%6]==s2[i])){
							k+=(double)1/s;
						} else{
							if((c[i][(j+2)%6]==s2[i]||c[i][(j+3)%6]==s2[i])||(c[i][(j+5)%6]==s2[i]||c[i][(j+4)%6]==s2[i])){
								k+=(double)1/(2*s);
							}
						}
					} else{
						if((c[i][(j+1)%6]==s2[i]||c[i][(j+2)%6]==s2[i])&&(c[i][(j+3)%6]==s2[i]||c[i][(j+4)%6]==s2[i])){
							k+=(double)1/s;
						} else{
							if((c[i][(j+1)%6]==s2[i]||c[i][(j+2)%6]==s2[i])||(c[i][(j+3)%6]==s2[i]||c[i][(j+4)%6]==s2[i])){
								k+=(double)1/(2*s);
							}
						}
					}
				}
			}
			ans*=k;
		}
	}
	printf("%.10lf",ans);


	return 0;
}