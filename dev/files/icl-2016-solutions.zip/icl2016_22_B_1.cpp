#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

const int MOD = (int) 1e9 + 9;

void add(int &x, int y) {
  if ((x += y) >= MOD) {
    x -= MOD;
  }
}

struct Matrix {
  const static int maxn = 100 + 10;
  int a[maxn][maxn];
  int n;
  
  Matrix(int _n = 0, int diag = 0) : n(_n) {
    for (int i = 0; i < n; ++i) {
      for (int j = 0; j < n; ++j) {
        a[i][j] = (i == j) ? diag : 0;
      }
    }
  }
  
  Matrix operator * (const Matrix &m) const {
    Matrix res(n);
    for (int i = 0; i < n; ++i) {
      for (int j = 0; j < n; ++j) {
        long long val = 0;
        for (int k = 0; k < n; ++k) {
          val += (long long) a[i][k] * m.a[k][j];
          if (val >= (long long) 8e18) {
            val %= MOD;
          }
        }
        res.a[i][j] = val % MOD;
      }
    }
    return res;
  }
  
  Matrix operator ^ (long long pw) const {
    Matrix res(n, 1);
    Matrix cur(*this);
    for (; pw; pw >>= 1) {
      if (pw & 1) {
        res = res * cur;
      }
      cur = cur * cur;
    }
    return res;
  }
};

long long n;
int m;

const int maxm = 10;
int cs[maxm];

int read() {
  if (scanf("%I64d%d", &n, &m) < 2) {
    return 0;
  }
  cs[0] = 0;
  for (int i = 1; i <= m; ++i) {
    scanf("%d", cs + i);
  }
  return 1;
}

int getId(int x, int y) {
  return x * m + y;
}

void solve() {
  Matrix a(m * m);
  for (int x = 0; x < m; ++x) {
    for (int y = 0; y < m; ++y) {
      if (x && y) {
        add(a.a[getId(x - 1, y - 1)][getId(x, y)], 1);
        continue;
      }
      if (x) {
        for (int t = 1; t <= m; ++t) {
          int nx = x - 1, ny = t - 1;
          add(a.a[getId(nx, ny)][getId(x, y)], cs[t]);
        }
        continue;
      }
      if (y) {
        for (int t = 1; t <= m; ++t) {
          int nx = t - 1, ny = y - 1;
          add(a.a[getId(nx, ny)][getId(x, y)], cs[t]);
        }
        continue;
      }
      for (int t1 = 1; t1 <= m; ++t1) {
        for (int t2 = 1; t2 <= m; ++t2) {
          int nx = t1 - 1, ny = t2 - 1;
          add(a.a[getId(nx, ny)][getId(x, y)], (long long) cs[t1] * cs[t2] % MOD);
        }
      }
      if (m >= 2) {
        add(a.a[getId(0, 0)][getId(x, y)], cs[2]);
      }
    }
  }
  
  a = a ^ n;
  
  assert(getId(0, 0) == 0);
  printf("%d\n", a.a[0][0]);
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
