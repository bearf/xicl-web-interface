/*
ICL 2016
Team: Mathematical Grammar School, Belgrade
*/
#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MOD=1000000009ll;
int glob=0;
struct entry
{
  int x[4];
  bool operator ==(const entry &a) const
  {
      for(int i=0;i<4;i++) if(x[i]!=a.x[i]) return false;
      return true;
  }
  bool operator <(const entry &a)const
  {
      return value()>a.value();
  }
  public:
      entry()
      {
          x[0]=0;
          x[1]=0;
          x[2]=0;
          x[3]=0;
      }
    entry(int a,int b,int c,int d)
  {
      x[0]=a;
      x[1]=b;
      x[2]=c;
      x[3]=d;
  }
  int value() const
  {
      int res=0;
      for(int i=0;i<4;i++) if(glob&(1<<i)) res+=x[i];
      else res-=x[i];
      return res;
  }
  void print()
  {
      for(int i=0;i<4;i++) printf("%d ",x[i]);
      printf("\n");
  }
};
int dist(entry a,entry b)
{
    int ret=0;
    for(int i=0;i<4;i++) ret+=abs(a.x[i]-b.x[i]);
    return ret;
}
set<entry> s[16];
int main() {
    int n;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        int type;
        int x,y,z,t;
        scanf("%d",&type);
        scanf("%d%d%d%d",&x,&y,&z,&t);
        entry e=*new entry(x,y,z,t);
        if(type==1)
        {
            //puts("ADDING" );
            //e.print();
            for(int w=0;w<16;w++)
            {
                glob=w;
                s[w].insert(e);
            }
        }
        else if(type==2)
        {
            //puts("DELETING" );
            //e.print();
            for(int w=0;w<16;w++)
            {
                glob=w;
                s[w].erase(e);
            }
        }
        else
        {
            //puts("CALCULATING" );
            //e.print();
            int ans=-1;
            for(int w=0;w<16;w++)
            {
                glob=w;
                entry ee=*(s[w].begin());
                ans=max(ans,dist(e,ee));
            }
            printf("%d\n",ans);
        }
    }
    return 0;
}
/*
5
1 0 0 0 0
1 -10 2 6 -9
3 -8 0 9 -5
2 0 0 0 0
3 -8 0 9 -5
*/
/*
9
1 2 0 0 0
1 4 3 0 0
1 1 5 0 0
3 2 3 0 0
3 -1 2 0 0
2 4 3 0 0
3 -1 2 0 0
2 2 0 0 0
3 1 5 0 0
*/
