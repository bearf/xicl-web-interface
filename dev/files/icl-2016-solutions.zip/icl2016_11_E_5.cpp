#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#define mp make_pair
#define F first
#define S second

// -- MAIN PART

typedef double dbl;
const dbl PI = acos(-1);
const dbl eps = 1e-11;

struct pt
{
	dbl x, y;
	pt(){}
	pt(dbl xx, dbl yy): x(xx), y(yy) {}
	void read()
	{
		scanf("%lf%lf", &x, &y);
	}
};

inline pt operator + (pt p1, pt p2) { return pt(p1.x + p2.x, p1.y + p2.y); }
inline pt operator - (pt p1, pt p2) { return pt(p1.x - p2.x, p1.y - p2.y); }
inline pt operator * (pt p, dbl c) { return pt(p.x * c, p.y * c); }

inline dbl vect(pt p1, pt p2) { return p1.x * p2.y - p1.y * p2.x; }
inline dbl scal(pt p1, pt p2) { return p1.x * p2.x + p1.y * p2.y; }


inline dbl dist(pt p1, pt p2)
{
	dbl dx = p1.x - p2.x;
	dbl dy = p1.y - p2.y;
	return sqrt(dx * dx + dy * dy);
}

struct line
{
	dbl a, b, c;
	line(){}
	line(dbl aa, dbl bb, dbl cc): a(aa), b(bb), c(cc) {}
	line(pt p1, pt p2)
	{
		a = p1.y - p2.y;
		b = p2.x - p1.x;
		c = p1.x * p2.y - p1.y * p2.x;
		norm();
	}
	void norm()
	{
		dbl d = sqrt(a * a + b * b);
		a /= d;
		b /= d;
		c /= d;
	}
	dbl calc(pt p)
	{
		return p.x * a + p.y * b + c;
	}
};

pt proj(pt p, line l)
{
	return p - pt(l.a, l.b) * l.calc(p);
}

inline bool bet(dbl x, dbl y, dbl z)
{
	return abs(x - y) + abs(x - z) < abs(y - z) + eps;
}

inline bool between(pt A, pt B, pt C)
{
	return bet(A.x, B.x, C.x) && bet(A.y, B.y, C.y);
}

inline dbl ang(pt p)
{
	return atan2(p.y, p.x);
}

inline dbl len(pt p)
{
	return sqrt(p.x * p.x + p.y * p.y);
}

inline pt rot(pt p, dbl a)
{
	return pt(p.x * cos(a) - p.y * sin(a), p.x * sin(a) + p.y * cos(a));
}

pair<dbl, vector<dbl>> get(pt A, pt O, dbl R)
{
	dbl d = dist(A, O);
	dbl alp = asin(max(-1., min(1., R / d)));

	pt v = O - A;
	dbl l = len(v);
	v = v * (1. / l);

	dbl res = sqrt(max(0.,  d * d - R * R));


	pt X = A + rot(v, alp) * res;
	pt Y = A + rot(v, -alp) * res;


	vector<dbl> vec;
	vec.push_back(ang(X - O));
	vec.push_back(ang(Y - O));

	return mp(res, vec);
}

pt A, B;
	pt O;
	dbl R;

void solve1()
{
		pair<dbl, vector<dbl>> ta = get(A, O, R);	
		pair<dbl, vector<dbl>> tb = get(B, O, R);	
		dbl res = ta.F + tb.F;
		dbl val = 1e100;
		forn(i, 2) forn(j, 2)
		{
			dbl alp = (ta.S[i] - tb.S[j]);
			while (alp > PI) alp -= 2 * PI;
			while (alp < -PI) alp += 2 * PI;
			val = min(val, abs(alp) * R);
		}
		res += val;
		
		printf("%.10f\n", res);
}	
#define pb push_back
#define sz(a) ((int)(a).size())

dbl calc(vector<dbl> f, dbl x)
{
	dbl res = 0;
	for (int i = sz(f) - 1; i >= 0; --i)
	{
		res = res * x + f[i];
	}
	return res;
}

vector<dbl> solve(vector<dbl> f)
{
	if (sz(f) == 1) return vector<dbl>();
	vector<dbl> f1;
	for (int i = 1; i < sz(f); ++i) f1.pb(f[i] * i);

	vector<dbl> vv = solve(f1);
	vector<dbl> v;
	v.pb(-1e20);
	forn(i, sz(vv)) v.pb(vv[i]);
	v.pb(1e20);

	vector<dbl> res;
	forn(i, sz(v) - 1)
	{
		dbl l = v[i];
		dbl r = v[i + 1];
		dbl fl = calc(f, l);
		dbl fr = calc(f, r);
		if ((fl < 0) != (fr < 0))
		{
			forn(_, 100)
			{
				dbl m = (l + r) * 0.5;
				if ((calc(f, m) < 0) == (fl < 0)) l = m;
				else r = m;
			}
			res.pb(l);
		}
	}

	return res;
}



bool can(dbl S)
{
	dbl d = dist(A, B);
	pt M = (A + B) * 0.5;
	pt v1 = B - M;
	pt v2 = O - M;
    dbl alp = atan2(vect(v1, v2), scal(v1, v2));
	
	dbl dd = dist(M, O);

    dbl x1 = cos(alp) * dd;
    dbl y1 = sin(alp) * dd;

    dbl a = (S / 2) * (S / 2);
    dbl b = (S / 2) * (S / 2) - (d / 2) * (d / 2);

    vector<dbl> f;
    f.pb(a * a * b * b - x1 * x1 * a * b * b - y1 * y1 * b * a * a);
    f.pb(2 * a * b * b + 2 * b * a * a - 2 * x1 * x1 * a * b - 2 * y1 * y1 * a * b);
    f.pb(a * a + b * b + 4 * a * b - x1 * x1 * a - y1 * y1 * b);
    f.pb(2 * a + 2 * b);
    f.pb(1);

    vector<dbl> roots = solve(f);

    //eprintf("a = %.10f, b = %.10f\n", a, b);
    forn(i, sz(roots))
    {
		dbl lambda = roots[i];
		dbl x = x1 * a / (a + lambda);
		dbl y = y1 * b / (b + lambda);
		//eprintf("lambda = %.10f\n", lambda);
		//eprintf("x = %.10f\n", x);
		//eprintf("y = %.10f\n", y);
		pt p = pt(x, y);
		pt p2 = pt(x1, y1);
		if (dist(p, p2) < R) return true;
	}
	return false;
}	

void solve2()
{
		const int CNT = 239;
		
		dbl res = 1e100;

		forn(it, CNT)
		{
			dbl l = it * 2 * PI / CNT;
			dbl r = (it + 1) * 2 * PI / CNT;
			forn(_, 100)
			{
				dbl m1 = (2 * l + r) / 3;
				dbl m2 = (l + 2 * r) / 3;
				pt p1 = O + pt(cos(m1), sin(m1)) * R;
				pt p2 = O + pt(cos(m2), sin(m2)) * R;
				dbl v1 = dist(A, p1) + dist(p1, B);
				dbl v2 = dist(A, p2) + dist(p2, B);
				res = min(res, v1);
				res = min(res, v2);
				if (v1 < v2) r = m2;
				else l = m1;
			}
		}

		dbl l = dist(A, B);
		dbl r = res;

		forn(_, 100)
		{
			dbl m = (l + r) * 0.5;
			if (can(m)) r = m;
			else l = m;
		}
		//eprintf("can (res + eps) -> %d\n", can(res + eps));
		//eprintf("was = %.10f\n", res);
		//eprintf("new = %.10f\n", r);
		res = r;

	   	res = min(res, dist(A, B) + min(dist(A, O), dist(B, O)) - R);
		
		printf("%.10f\n", res);
}

int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	A.read();
	B.read();
	O.read();
	scanf("%lf", &R);


	if (dist(A, B) < eps) solve2();
	else
	{
	    
	    
		pt P = proj(O, line(A, B));
	    
		if (between(P, A, B) && dist(O, P) < R + eps)
		{
			solve1();
		}
		else
		{
			solve2();
		}
	}


	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
