#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <string>
using namespace std;
int main() {
	string s;
	getline(cin, s);
	int c = s.size();
	vector<char> v(c);
	for (int i = 0; i < s.size(); i++) {
		v[i] = s[i];
	}
	
	int n;
	
	cin >> n;
	vector<int> p(n);
	for (int i = 0; i < n; i++) {
		cin >> p[i];
	}
	for (int i = 0; i < n; i++) {
		if (i<n-1 && p[i] == p[i + 1]) {
			i ++;
			continue;
		}
		reverse(v.begin(), v.begin() + p[i]);
		reverse(v.begin() + p[i], v.end());
	}
	for (int i = 0; i < c; i++) {
		cout << v[i];
	}

}