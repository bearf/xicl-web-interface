#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <map>
#include <string>
#include <complex>

#pragma warning(disable:4996)

using namespace std;

#define x1 first
#define y1 second
#define mp make_pair
#define pb push_back
#define For(i,n) for(int i=0;i<(n);++i)
#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define all(v) (v).begin(),(v).end()

typedef long long ll;
typedef pair<long double, long double> point;

const int mod = 1e9 + 9;
const int INF = 2e9;
const ll LONGINF = 4e18;
const long double PI = 3.1415926535897932384626433832795;
const long double eps = 1e-9;

point operator-(point a, point b) {
	return mp(a.x1 - b.x1, a.y1 - b.y1);
}

point operator+(point a, point b) {
	return mp(a.x1 + b.x1, a.y1 + b.y1);
}

point operator/(point a, long double b) {
	return mp(a.x1 / b, a.y1 / b);
}

point operator*(point a, long double b) {
	return mp(a.x1 * b, a.y1 * b);
}

long double abs(point a) {
	return sqrt(a.x1*a.x1 + a.y1*a.y1);
}

pair<point, point> inter(point O1, long double r1, point O2, long double r2) {
	point v = O2 - O1;
	long double d = sqrt(v.x1*v.x1 + v.y1*v.y1);
	long double p = (r1 + r2 + d) / 2;
	long double a = (r1*r1 + d*d - r2*r2) / 2 / d;
	long double h = sqrt(r1*r1 - a*a);
	point q = v / abs(v)*a;
	point H = mp(-v.y1, v.x1);
	H = H / abs(H)*h;
	return mp(O1 + q + H, O1 + q - H);
}

point p[3];

point norm(point a) {
	return mp(-a.y1, a.x1);
}

long double scal(point a, point b) {
	return a.x1*b.x1 + a.y1*b.y1;
}

void eq(complex<long double> &a, point b) {
	a.real(b.x1);
	a.imag(b.y1);
}

bool check(point p, point a, point b, long double ang) {
	complex<long double> q1,q2,q3;
	eq(q1, p - a);
	eq(q2, p - b);
	q3 = q1 / q2;
	if (abs(abs(arg(q3)) - ang) > eps) return false;
	return abs(p - a) > eps && abs(p - b) > eps;
}

void solve() {
	For(i, 3) {
		cin >> p[i].x1 >> p[i].y1;
	}
	long double a1, a2;
	cin >> a1 >> a2;
	a1 = a1 / 180 * PI;
	a2 = a2 / 180 * PI;
	point O1, O2, p1, p2, d1, d2, ans;
	long double r1, r2;

	d1 = norm(p[0] - p[1]);
	d1 = d1 / abs(d1)*abs(p[0] - p[1]) / tan(a1);
	d2 = norm(p[1] - p[2]);
	d2 = d2 / abs(d2)*abs(p[1] - p[2]) / tan(a2);

	if (abs(a1 - PI / 2) < eps) {
		O1 = (p[0] + p[1]) / 2;
		d1 = mp(0, 0);
		r1 = abs(p[0] - p[1]) / 2;
	}

	if (abs(a2 - PI / 2) < eps) {
		O2 = (p[1] + p[2]) / 2;
		d2 = mp(0, 0);
		r2 = abs(p[1] - p[2]) / 2;
	}

	O1 = (p[0] + (p[1] + d1)) / 2;
	r1 = abs(O1 - p[0]);
	O2 = (p[1] + (p[2] + d2)) / 2;
	r2 = abs(O2 - p[2]);

	pair<point, point> t;

	if (abs(O1 - O2) < eps&&abs(r1 - r2) < eps) {
		point pp = O1 - mp(0, r1);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 - mp(0, r1);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 + mp(r1, 0);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 - mp(r1, 0);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
	}
	else {
		t = inter(O1, r1, O2, r2);
		if (check(t.x1, p[0], p[1], a1) && check(t.x1, p[1], p[2], a2)) {
			ans = t.x1;
		}
		if (check(t.y1, p[0], p[1], a1) && check(t.y1, p[1], p[2], a2)) {
			ans = t.y1;
		}
	}

	O1 = (p[0] + (p[1] - d1)) / 2;
	r1 = abs(O1 - p[0]);
	O2 = (p[1] + (p[2] + d2)) / 2;
	r2 = abs(O2 - p[2]);

	if (abs(O1 - O2) < eps&&abs(r1 - r2) < eps) {
		point pp = O1 - mp(0, r1);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 - mp(0, r1);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 + mp(r1, 0);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 - mp(r1, 0);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
	}
	else {
		t = inter(O1, r1, O2, r2);
		if (check(t.x1, p[0], p[1], a1) && check(t.x1, p[1], p[2], a2)) {
			ans = t.x1;
		}
		if (check(t.y1, p[0], p[1], a1) && check(t.y1, p[1], p[2], a2)) {
			ans = t.y1;
		}
	}

	O1 = (p[0] + (p[1] + d1)) / 2;
	r1 = abs(O1 - p[0]);
	O2 = (p[1] + (p[2] - d2)) / 2;
	r2 = abs(O2 - p[2]);

	if (abs(O1 - O2) < eps&&abs(r1 - r2) < eps) {
		point pp = O1 - mp(0, r1);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 - mp(0, r1);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 + mp(r1, 0);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 - mp(r1, 0);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
	}
	else {
		t = inter(O1, r1, O2, r2);
		if (check(t.x1, p[0], p[1], a1) && check(t.x1, p[1], p[2], a2)) {
			ans = t.x1;
		}
		if (check(t.y1, p[0], p[1], a1) && check(t.y1, p[1], p[2], a2)) {
			ans = t.y1;
		}
	}

	O1 = (p[0] + (p[1] - d1)) / 2;
	r1 = abs(O1 - p[0]);
	O2 = (p[1] + (p[2] - d2)) / 2;
	r2 = abs(O2 - p[2]);

	if (abs(O1 - O2) < eps&&abs(r1 - r2) < eps) {
		point pp = O1 - mp(0, r1);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 - mp(0, r1);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 + mp(r1, 0);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
		pp = O1 - mp(r1, 0);
		if (check(pp, p[0], p[1], a1) && check(pp, p[1], p[2], a2)) ans = pp;
	}
	else {
		t = inter(O1, r1, O2, r2);
		if (check(t.x1, p[0], p[1], a1) && check(t.x1, p[1], p[2], a2)) {
			ans = t.x1;
		}
		if (check(t.y1, p[0], p[1], a1) && check(t.y1, p[1], p[2], a2)) {
			ans = t.y1;
		}
	}

	printf("%.10llf %.10llf\n", ans.x1, ans.y1);

}

int main() {
#pragma comment(linker,"/STACK:268435456")
#ifdef _DEBUG
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#endif
	int t;
	scanf("%d", &t);
	For(i, t)
		solve();
	return 0;
}