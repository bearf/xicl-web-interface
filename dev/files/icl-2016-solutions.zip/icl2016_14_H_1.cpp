/*
ICL 2016
Team: Mathematical Grammar School, Belgrade
*/
#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MOD=1000000009ll;
char s[200010];
char ss[200010];
int d[200010];
int main() {
    string st;
    getline(cin,st);
    for(int i=0;i<st.length();i++)
        s[i]=st[i];
    s[st.length()]='\0';
    int len=strlen(s);
    int m;
    scanf("%d",&m);
    for(int i=0;i<m;i++) scanf("%d",&d[i]);
    int start=0;

    for(int i=0;i<m;i+=2)
    {
        if(i+1>=m)continue;
        int x=d[i],y=d[i+1];
        start+=x-y;
        if(start<0)start+=len;
        if(start>=len)start-=len;
         //   printf("D:%d %d\n",start,i);

    }
    int cur=0;
  //  printf("%d\n",start);
    for(int i=start;i<len;i++)
    {
        ss[cur]=s[i];
        cur++;
    }
     for(int i=0;i<start;i++)
    {
        ss[cur]=s[i];
        cur++;
    }
    ss[len]='\0';
//printf("%stest\n",ss);

    if(m%2==1)
    {
        int op=d[m-1];
        for(int i=0;i<op/2;i++)
            swap(ss[i],ss[op-i-1]);
        for(int i=op;i<(len+op)/2;i++)
            swap(ss[i],ss[len-i-1+op]);
            



    }
    printf("%s\n",ss);
    return 0;

}
