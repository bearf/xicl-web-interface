#define _CRT_SECURE_NO_WARNINGS

#include <cmath>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdint.h>
#include <string>
#include <cassert>
using namespace std;

typedef long long ll;
typedef double ld;

const ld EPS = 1e-9;
const ld PI = acos(-1.);

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
#ifdef AWWW
	assert(freopen("input.txt", "r", stdin) != nullptr);
#endif

	int l, n, k;
	cin >> l >> n >> k;

	for (int i = 1; i <= l && n > 0; ++i)
	{
		if (n % k == 1)
			--n;
		n -= (((n - 1) / k) << 1) + 1;
	}

	n = max(0, n);
	cout << n << endl;

#ifdef AWWW
	while (true) {}
#endif
}