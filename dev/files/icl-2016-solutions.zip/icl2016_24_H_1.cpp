#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdint.h>
#include <string>
using namespace std;
typedef long long ll;

struct Node
{
	Node *l = nullptr;
	Node *r = nullptr;
	char c = 0;
	int x = 1, y = rand();
	bool rev = false;

	Node()
	{

	}

	Node(char c) : l(nullptr), r(nullptr), c(c), x(1), y(rand()), rev(false)
	{

	}
};

inline int get_dp(Node* v)
{
	if (v == nullptr)
		return 0;
	return v->x;
}

inline void recalc(Node* v)
{
	if (v == nullptr)
		return;
	v->x = 1 + get_dp(v->l) + get_dp(v->r);
}

inline void modify(Node* v)
{
	if (v == nullptr)
		return;
	v->rev ^= 1;
}

inline void push(Node* v)
{
	if (v == nullptr)
		return;

	if (v->rev)
	{
		swap(v->l, v->r);
		v->rev = 0;
		modify(v->l);
		modify(v->r);
	}
}

pair<Node*, Node*> split_t(Node* v, int x)
{
	push(v);
	if (v == nullptr)
		return{ nullptr, nullptr };

	if (get_dp(v->l) >= x)
	{
		auto p = split_t(v->l, x);
		v->l = p.second;
		recalc(v);
		return{ p.first, v };
	}
	else
	{
		auto p = split_t(v->r, x - get_dp(v->l) - 1);
		v->r = p.first;
		recalc(v);;
		return{ v, p.second };
	}
}

Node* merge_t(Node* a, Node* b)
{
	push(a);
	push(b);
	if (a == nullptr)
		return b;
	if (b == nullptr)
		return a;

	if (a->y > b->y)
	{
		a->r = merge_t(a->r, b);
		recalc(a);
		return a;
	}
	else
	{
		b->l = merge_t(a, b->l);
		recalc(b);
		return b;
	}
}

string sans;
void ans(Node* v)
{
	if (v == nullptr)
		return;
	push(v);
	ans(v->l);
	sans += v->c;
	ans(v->r);
}

int main()
{
	string s;
	cin >> s;

	Node* root = nullptr;

	for (int i = 0; i < s.size(); ++i)
	{
		root = merge_t(root, new Node(s[i]));
	}

	int n;
	cin >> n;

	for (int i = 0; i < n; ++i)
	{
		int x;
		cin >> x;
		auto p = split_t(root, x);
		modify(p.first);
		modify(p.second);
		root = merge_t(p.first, p.second);
	}

	ans(root);
	cout << sans << endl;

#ifdef AWWW
	system("pause");
#endif
}