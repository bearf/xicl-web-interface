#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const ll MOD = 1e9 + 9;

ll gcd(ll a, ll b)
{
    return (!b) ? a:gcd(b, a % b);
}


ll bin(ll x, ll y)
{
    if (y == 0)
        return 1;
    if (y == 1)
        return x;
    ll s = bin(x, y / 2);
    if (y & 1)
        return (((s * s) % MOD) * x) % MOD;
    else
        return (s * s) % MOD;
}

int main() {

    ll k;
    ll a, b;

    cin >> k;
    cin >> a >> b;

    if (b%a != 0)
    {
        cout << 0;
    }
    else
    {
        b = b/a;
        ll i = 2;
        ll ans = 1;
        ll cnt = 0;
        ll s1 = 1, s2 = 1;
        while (i*i <= b)
        {
            while (b % i == 0)
            {
                ++cnt;
                b /= i;
            }
            ++i;
            if (cnt)
            s1 = bin(cnt + 1, k) % MOD;
            s2 = 0;

            s2 = bin(cnt, k) % MOD;
            s1 = (s1 + MOD + MOD - s2 - s2) % MOD;
            if (cnt - 1)
                s1 = (s1 + bin(cnt - 1, k)) % MOD;


            ans = (ans * s1) % MOD;
            }
            cnt = 0;

        if (b != 1)
        {
            cnt = 1;
           s1 = bin(cnt + 1, k) % MOD;
            s2 = 0;

            s2 = bin(cnt, k) % MOD;
            s1 = (s1 + MOD + MOD - s2 - s2) % MOD;
            if (cnt - 1)
                s1 = (s1 + bin(cnt - 1, k)) % MOD;


            ans = (ans * s1) % MOD;
        }
    cout << ans;
    }

    return 0;
}
