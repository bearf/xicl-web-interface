#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <bitset>
#include <complex>
using namespace std;

typedef long long int int64;

const double pi = acos(-1.0);

bool eq(double a, double b, double eps = 1e-8)
{
	return fabs(a - b) < eps;
}

bool ls(double a, double b)
{
	return a < b && !eq(a, b);
}

bool ls_eq(double a, double b)
{
	return a < b || eq(a, b);
}

bool gr(double a, double b)
{
	return a > b && !eq(a, b);
}

bool gr_eq(double a, double b)
{
	return a > b || eq(a, b);
}

double sqr(double a)
{
	return a * a;
}

struct Point
{
	double x, y;

	void scan()
	{
		scanf("%lf%lf", &x, &y);
	}

	Point() : x(), y() {}
	Point(double x, double y) : x(x), y(y) {}

	bool operator == (Point p) const
	{
		return eq(x, p.x) && eq(y, p.y);
	}

	Point operator + (Point p)
	{
		return Point(x + p.x, y + p.y);
	}

	Point operator - (Point p)
	{
		return Point(x - p.x, y - p.y);
	}

	Point operator * (double k)
	{
		return Point(x * k, y * k);
	}

	Point operator / (double k)
	{
		return Point(x / k, y / k);
	}

	double operator % (Point p)
	{
		return x * p.x + y * p.y;
	}

	double length()
	{
		return sqrt(*this % *this);
	}

	double dist_to(Point p)
	{
		return (*this - p).length();
	}

	double operator * (Point p)
	{
		return x * p.y - y * p.x;
	}

	Point rotate()
	{
		return Point(-y, x);
	}

	Point rotate(double angle)
	{
		Point v = *this;
		Point u = v.rotate();
		return v * cos(angle) + u * sin(angle);
	}

	Point normalize(double k)
	{
		if (eq(length(), 0))
		{
			if (eq(k, 0))
				return *this;
			throw;
		}
		return *this / length() * k;
	}
};

bool intersect(Point A, Point B, Point C, Point D, Point &M)
{
	double s1 = (C - A) * (D - A);
	double s2 = (D - B) * (C - B);
	double s = s1 + s2;
	if (eq(s, 0))
		return false;

	Point v = B - A;
	M = A + v / s * s1;

	return true;
}

void get_serper(Point A, Point B, Point &P1, Point &P2)
{
	P1 = (A + B) / 2;
	P2 = P1 + (B - A).rotate();
}

Point M1, M2, M3;
double angle1, angle2;

double read_angle()
{
	double a;
	scanf("%lf", &a);
	return a / 180 * pi;
}

void get_D(Point A, Point B, double angle, Point &D1, Point &D2)
{
	double d = A.dist_to(B);
	double h = (d / 2) / tan(angle / 2);
	Point C = (A + B) / 2;
	Point v = (B - A).normalize(h);

	D1 = C + v.rotate(pi / 2);
	D2 = C + v.rotate(-pi / 2);
}

void get_circle(Point A, Point B, Point C, Point &O, double &r)
{
	Point P1, P2;
	get_serper(A, B, P1, P2);

	Point K1, K2;
	get_serper(B, C, K1, K2);

	assert(intersect(P1, P2, K1, K2, O));
	r = O.dist_to(A);
}

bool check(Point D, Point A, Point B, double angle)
{
	Point v = A - D;
	Point u = B - D;
	double cur_angle = fabs(atan2(v * u, v % u));
	return eq(cur_angle, angle);
}

bool try_print(Point K)
{
	if (!check(K, M1, M2, angle1))
		return false;
	if (!check(K, M2, M3, angle2))
		return false;
	printf("%.10lf %.10lf\n", K.x, K.y);
	return true;
}

bool try_solve(Point O1, double r1, Point O2, double r2)
{
	double dist = O1.dist_to(O2);

	if (gr(dist, r1 + r2))
		return false;

	if (O1 == O2)
	{
		if (!eq(r1, r2))
			return false;

		for (int it = 0; it < 8; it++)
		{
			double cur_angle = 2 * pi / 8 * it;
			Point K = O1 + Point(r1, 0).rotate(cur_angle);
			if (try_print(K))
				return true;
		}
	
		assert(false);
	}
	
	double cosa = (sqr(r1) + sqr(dist) - sqr(r2)) / (2 * r1 * dist);
	double alpha = acos(cosa);

	Point v = (O2 - O1).normalize(r1);
	Point K1 = O1 + v.rotate(alpha);
	Point K2 = O1 + v.rotate(-alpha);

	if (try_print(K1))
		return true;

	if (try_print(K2))
		return true;

	return false;
}

void solve()
{
	M1.scan();
	M2.scan();
	M3.scan();
	angle1 = read_angle();
	angle2 = read_angle();

	Point D1, D2;
	get_D(M1, M2, angle1, D1, D2);
	vector<Point> list1 = { D1, D2 };

	Point K1, K2;
	get_D(M2, M3, angle2, K1, K2);
	vector<Point> list2 = { K1, K2 };

	for (Point P1 : list1)
	{
		for (Point P2 : list2)
		{
			Point O1;
			double r1;
			get_circle(M1, M2, P1, O1, r1);

			Point O2;
			double r2;
			get_circle(M2, M3, P2, O2, r2);

			if (try_solve(O1, r1, O2, r2))
				return;
		}
	}

	assert(false);
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int q;
	scanf("%d", &q);
	for (int i = 0; i < q; i++)
		solve();

	return 0;
}