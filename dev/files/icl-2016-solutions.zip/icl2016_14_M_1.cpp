/*
ICL 2016
Team: Mathematical Grammar School, Belgrade
*/
#include <bits/stdc++.h>
typedef long long ll;
using namespace std;


ll gcd(ll a,ll b) {
    if(b==0) return a;
    return gcd(b,a%b);
}
ll lcm(ll a,ll b)
{
    return a/gcd(a,b)*b;
}
int main() {

    int n;
    scanf("%d",&n);
    ll gcdd,lcmm;
    scanf("%lld%lld",&lcmm,&gcdd);
    for(int i=0;i<n-1;i++)
    {
        ll a,b;
        scanf("%lld%lld",&a,&b);
        lcmm=lcm(lcmm,a);
        gcdd=gcd(gcdd,b);
    }
    ll s=gcd(lcmm,gcdd);
    lcmm/=s;
    gcdd/=s;
    printf("%lld %lld\n",lcmm,gcdd);
    return 0;
}
