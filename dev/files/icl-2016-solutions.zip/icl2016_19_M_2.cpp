#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
using namespace std;
long long nod(long long a,long long b) {
	while (a > 0 && b > 0) {
		if (a > b)
			a = a%b;
		else
			b = b%a;
	}
	return(max(a, b));
}
long long nok(long long a, long long b) {
	long long a1 = a, b1 = b;
	a1 = nod(a1, b1);
	return(a*b / a1);
}
int main() {
	long long n;
	cin >> n;
	long long a, b,ch,zn;
	cin >> ch >> zn;
	for (long long i = 0; i < n-1; i++) {
		cin >> a >> b;
		ch = nok(ch, a);
		zn = nod(zn, b);
	}
	ch = ch / nod(ch, zn);
	zn = zn / nod(ch, zn);
	cout << ch << ' ' << zn;

}