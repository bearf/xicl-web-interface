#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < n; i++)

typedef long long ll;


const int INF = 2e9;
const ll INF64 = 9e18;
const int N = 200100;

multiset < int > s[100];

void push(int x, int y, int z, int u)
{
    for (int xx = -1; xx <= 1; xx++)
        for (int yy = -1; yy <= 1; yy++)
            for (int zz = -1; zz <= 1; zz++)
                for (int uu = -1; uu <= 1; uu++)
                    if (abs(xx) + abs(yy) + abs(zz) + abs(uu) == 4)
                    {
                        int h = 0;
                        if (xx < 0)
                            h += (1 << 0);
                        if (yy < 0)
                            h += (1 << 1);
                        if (zz < 0)
                            h += (1 << 2);
                        if (uu < 0)
                            h += (1 << 3);
                        s[h].insert(-(x * xx + y * yy + z * zz + u * uu));
                    }
}

void del(int x, int y, int z, int u)
{
    for (int xx = -1; xx <= 1; xx++)
        for (int yy = -1; yy <= 1; yy++)
            for (int zz = -1; zz <= 1; zz++)
                for (int uu = -1; uu <= 1; uu++)
                    if (abs(xx) + abs(yy) + abs(zz) + abs(uu) == 4)
                    {
                        int h = 0;
                        if (xx < 0)
                            h += (1 << 0);
                        if (yy < 0)
                            h += (1 << 1);
                        if (zz < 0)
                            h += (1 << 2);
                        if (uu < 0)
                            h += (1 << 3);
                        s[h].erase(s[h].find(-(x * xx + y * yy + z * zz + u * uu)));
                    }
}


int main()
{

    int n;
    cin >> n;
    int cc = 100000001;
    forn(i, n)
    {
        int t, x, y, z , u;
        scanf("%d %d %d %d %d", &t, &x, &y, &z, &u);
        x += cc;
        y += cc;
        z += cc;
        u += cc;
        if (t == 1)
            push(x, y, z, u);
        if (t == 2)
            del(x, y, z, u);
        if (t == 3)
        {
            int maxi = 0;
        for (int xx = -1; xx <= 1; xx++)
        for (int yy = -1; yy <= 1; yy++)
            for (int zz = -1; zz <= 1; zz++)
                for (int uu = -1; uu <= 1; uu++)
                    if (abs(xx) + abs(yy) + abs(zz) + abs(uu) == 4)
                    {
                        int h = 0;
                        if (xx > 0)
                            h += (1 << 0);
                        if (yy > 0)
                            h += (1 << 1);
                        if (zz > 0)
                            h += (1 << 2);
                        if (uu > 0)
                            h += (1 << 3);
                        int sum = x * xx + y * yy + z * zz + u * uu;
                        if (!s[h].empty())
                        maxi = max(maxi, sum + -*s[h].begin());
                    }

        printf("%d\n", maxi);
        }
    }




    return 0;
}

/*

5
1 0 0 0 0
1 -10 2 6 -9
3 -8 0 9 -5
2 0 0 0 0
3 -8 0 9 -5



9
1 2 0 0 0
1 4 3 0 0
1 1 5 0 0
3 2 3 0 0
3 -1 2 0 0
2 4 3 0 0
3 -1 2 0 0
2 2 0 0 0
3 1 5 0 0

*/

