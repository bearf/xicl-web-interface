#define _CRT_SECURE_NO_WARNINGS
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <ctime>
#include <string>

using namespace std;

void solution();

int main()
{
	ios_base::sync_with_stdio(false);
#ifdef HOME
	freopen("input.txt", "rt", stdin);
	clock_t start = clock();
#endif
	solution();
#ifdef HOME
	cerr.precision(3);
	cerr << endl << "Total time: " << fixed << double(clock() - start) / double(CLOCKS_PER_SEC) << endl;
#endif
	return 0;
}

typedef long long ll;
//#define int ll

int gcd(int a, int b)
{
	while (b)
		swap(b, a %= b);
	return a;
}

int lcm(int x, int y)
{
	return x * y / gcd(x, y);
}


#define pow powpow
#define MOD 1000000009ll
#define MP(x, y) make_pair(x, y)
#define N 200000
bool pr[N + 1];
int k, d, m;
int p[N], pc = 0, c[N];

int pow(int a, int n)
{
	if (n == 0)
		return 1;
	else if (n == 1)
		return a;
	if (n % 2 == 0)
	{
		int res = pow(a, n / 2);
		return (res * res) % MOD;
	}
	else
	{
		return (a * pow(a, n - 1)) % MOD;
	}
}

int cnk(int n, int k)
{
	if (k == 0)
		return 1;
	if (k == n)
		return 1;
	return ((n * cnk(n - 1, k - 1)) % MOD * pow(k, MOD - 2)) % MOD;
}

string s;
int n, l[N], e, len;

void calc()
{
	e = 0;
	for (int i = 0; i < n; ++i)
	{
		e *= -1;
		e += l[i];
		if (e < 0)
			e += len;
		e %= len;
	}
}

int solve(int i)
{
	int sign = n % 2 ? -1 : 1;
	int res = e + sign * i - n % 2;
	while (res < 0)
		res += len;
	return res % len;
}

void solution()
{
	getline(cin, s);
	cin >> n;
	len = s.size();
	string res = s;
	for (int i = 0; i < n; ++i)
		cin >> l[i];
	calc();
	vector<int> src(len);
	for (int i = 0; i < len; ++i)
	{
		res[i] = s[solve(i)];
		src[solve(i)] = 1;
	}
	for (int i = 0; i < len; ++i)
		if (!src[i])
			exit(-1);
	cout << res << endl;
}
