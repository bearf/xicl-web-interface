#define _CRT_SECURE_NO_WARNINGS
#include <fstream>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
#include <iostream>
typedef long long ll;
typedef long double ld;
using namespace std;

ll gcd(ll a, ll b)
{
	if (b == 0)
		return a;
	return gcd(b, a%b);
}
ll lcm(ll a, ll b)
{
	return a / gcd(a, b)*b;
}
map <ll, ll> mp;
ll a[6], b[6];
int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> a[i];
		if (mp.count(a[i]))
			mp[a[i]]++;
		else
			mp[a[i]] = 1;
	}
	map<ll, ll>::iterator it;
	
	ll ans = 0;
	
		for (it = mp.begin(); it != mp.end(); it++)
		{
			ans = max(ans, (*it).second);

		}
		cout << ans;
	return 0;
}