#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
using namespace std;

int gcd(int a, int b) {
	while (b) {
		a %= b;
		swap(a, b);
	}
	return a;
}

int nok(int a, int b) {
	return a / gcd(a, b)*b;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int n;
	cin >> n;
	int q = 1, w = 1; // q/w
	cin >> q >> w;
	for (int i = 1; i < n; i++) {
		int a, b;
		cin >> a >> b;
		q = nok(q, a);
		w = gcd(w, b);
	}
	cout << q << " " << w;
}