#include <bits/stdc++.h>
#define fi first
#define se second
using namespace std;

typedef long long ll;


int main() {
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
    ll k, d, m;
    cin >> k >> d >> m;
    if ((m - d) / k == 0) {
        cout << 0;
        return 0;
    }
    cout << (m - d) / k - 1;
}
