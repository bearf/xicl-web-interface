#include <bits/stdc++.h>

using namespace std;

int l, n, k, i, d;


int main()
{
    cin >> l >> n >> k;

    for (i = 1; i <= l; i++){
        d = n / k;
        if (n % k > 0)
            d++;
        d = d * 2 - 1;
        n -= d;
        if (n == 0){
            cout << 0;
            return 0;
        }
    }

    cout << n;

    return 0;
}
