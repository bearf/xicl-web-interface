#include <bits/stdc++.h>

using namespace std;

int a[6], b[6];

long long gcd (int a, int b){
    if (b == 0)
        return a;
    else
        return gcd(b, a % b);
}

int main(){
    ios_base::sync_with_stdio(false);
    //freopen("input.txt" , "r" , stdin); freopen("output.txt" , "w" , stdout);
    int n;
    cin >> n;
    long long ch, zn;
    for (int i = 0; i < n; i++)
        cin >> a[i] >> b[i];

    ch = a[0];
    for (int i = 1; i < n; i++){
        ch = (ch * a[i])/gcd(ch, a[i]);
    }

    zn = b[0];
    for (int i = 1; i < n; i++){
        zn = gcd(zn, b[i]);
    }

    cout << ch << " " << zn << endl;
    return 0;
}
