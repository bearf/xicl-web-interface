#include <bits/stdc++.h>

using namespace std;

string s, s2;
string arr[10];
double chance = 1.0;
double add[6][6] = {
{1.0, 0.5, 0.5, 0.5, 0.5, 1.0},
{0.5, 1.0, 0.5, 1.0, 0.5, 0.5},
{0.5, 0.5, 1.0, 0.5, 1.0, 0.5},
{0.5, 1.0, 0.5, 1.0, 0.5, 0.5},
{0.5, 0.5, 1.0, 0.5, 1.0, 0.5},
{1.0, 0.5, 0.5, 0.5, 0.5, 1.0}
}; 

int main() {
  cin >> s >> s2;
  for (int i = 0; i < s.size(); i++) {
    cin >> arr[i];
  }
  for (int i = 0; i < s.size(); i++) {
    int idx = 0;
    int idx2 = 0;
    for (int j = 0; j < arr[i].size(); j++) {
      if (arr[i][j] == s[i]) {
        idx = j;
      }
      if (arr[i][j] == s2[i]) {
        idx2 = j;
      }
    }
    chance *= add[idx][idx2];
  }
  cout << fixed << setprecision(10) << chance;
  return 0;
}