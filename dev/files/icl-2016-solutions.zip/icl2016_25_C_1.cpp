#include <cstdio>
#include <algorithm>
#include <iostream>
#include <set>
#include <map>
#include <vector>
#include <cstring>
#include <string>
#include <cmath>
#include <iomanip>

#pragma warning (disable : 4996)

#define put push_back
#define mapa make_pair
using namespace std;

string n, m, s;
long long aa = 1, bb = 1, a, b;

void trans(string s, char p, char q) {
	if (s[0] == p) {
		b += 2;
		if (s[0] == q || s[4] == q || s[2] == q || s[5] == q)
			a ++;
		if (s[0] == q || s[1] == q || s[3] == q || s[5] == q)
			a++;
	}
	if (s[1] == p) {
		b += 2;
		if (s[1] == q || s[4] == q || s[2] == q || s[3] == q)
			a++;
		if (s[0] == q || s[1] == q || s[3] == q || s[5] == q)
			a++;
	}
	if (s[2] == p) {
		b += 2;
		if (s[2] == q || s[0] == q || s[4] == q || s[5] == q)
			a++;
		if (s[1] == q || s[4] == q || s[3] == q || s[2] == q)
			a++;
	}
	if (s[3] == p) {
		b += 2;
		if (s[1] == q || s[2] == q || s[3] == q || s[4] == q)
			a++;
		if (s[0] == q || s[1] == q || s[3] == q || s[5] == q)
			a++;
	}
	if (s[4] == p) {
		b += 2;
		if (s[4] == q || s[1] == q || s[2] == q || s[3] == q)
			a++;
		if (s[4] == q || s[0] == q || s[2] == q || s[5] == q)
			a++;
	}
	if (s[5] == p) {
		b += 2;
		if (s[5] == q || s[1] == q || s[0] == q || s[3] == q)
			a++;
		if (s[5] == q || s[2] == q || s[0] == q || s[4] == q)
			a++;
	}
}


int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
#ifndef _DEBUG
	//freopen("kek.in", "r", stdin);
	//freopen("kek.out", "w", stdout);
#endif
	cin >> n >> m;
	cout << fixed << setprecision(12);
	for (int i = 0; i < n.size(); i++)
	{
		cin >> s;
		a = 0;
		b = 0;
		trans(s, n[i], m[i]);
		aa *= a;
		bb *= b;
	}
	cout << double(aa) / double(bb);
	return 0;
}