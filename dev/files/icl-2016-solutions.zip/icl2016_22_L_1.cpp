#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

int a, b, c, d;

int read() {
  if (scanf("%d%d%d%d", &a, &b, &c, &d) < 4) {
    return 0;
  }
  return 1;
}

bool swp;

int sgn(int x) {
  return x < 0 ? -1 : !!x;
}

vector<vector<int> > ans;

void makeOne(int a, int b) {
  vector<int> toadd;
  toadd.pb(1);
  toadd.pb(a);
  toadd.pb(b);
  if (swp) {
    swap(toadd[sz(toadd) - 1], toadd[sz(toadd) - 2]);
  }
  ans.pb(toadd);
}

void makeTwo(int a, int b) {
  assert(a % 2 == 0 && b % 2 == 0);
  vector<int> toadd;
  toadd.pb(2);
  toadd.pb(a);
  toadd.pb(b);
  if (swp) {
    swap(toadd[sz(toadd) - 1], toadd[sz(toadd) - 2]);
  }
  ans.pb(toadd);
}

void makeThree(int a1, int b1, int a2, int b2) {
  assert(b1 == a2);
  vector<int> toadd;
  toadd.pb(3);
  toadd.pb(a1);
  toadd.pb(b1);
  toadd.pb(a2);
  toadd.pb(b2);
  if (swp) {
    reverse(toadd.begin() + 1, toadd.end());
  }
  ans.pb(toadd);
}

void solve() {
  swp = (a > b);
  if (swp) {
    swap(a, b);
    swap(c, d);
  }
  if (sgn(b - a) != sgn(d - c)) {
    printf("0\n");
    return;
  }
  assert(a <= b && c <= d);
  
  ans.clear();
  int k = 0;
  if (b - a) {
    while (!((b - a) & 1)) {
      if (a & 1) {
        makeOne(a, b);
        ++a, ++b;
      }
      makeTwo(a, b);
      a /= 2, b /= 2;
    }

    k = (d - c) / (b - a);
    if (k & (k - 1)) {
      printf("0\n");
      return;
    }
    k = __builtin_popcount(k - 1);
  }
  
  bool first = 1;
  while (a > 1) {
    int a0 = a, b0 = b;
    for (int iter = 0; a < b0; ++iter) {
      if (!first && a > 2 * a0) {
        break;
      }
      makeOne(a, b);
      ++a, ++b;
    }
    first = 0;
    makeThree(a0, b0, a, b);
    a = a0;
    
    if (a & 1) {
      makeOne(a, b);
      ++a, ++b;
    }
    makeTwo(a, b);
    a /= 2, b /= 2;
  }
  assert(a == 1);

  for (int iter = 0; iter < k; ++iter) {
    assert(a == 1);
    int diff = b - a;
    for (int i = 0; i < diff; ++i) {
      makeOne(i + 1, diff + i + 1);
    }
    makeThree(a, b, b, b + diff);
    b += diff;
  }
  
  assert(b - a == d - c);
  
  assert(a <= c);
  while (a < c) {
    makeOne(a, b);
    ++a, ++b;
  }
  assert(a == c && b == d);
  
  printf("%d\n", sz(ans));
  for (int i = 0; i < sz(ans); ++i) {
    for (int j = 0; j < sz(ans[i]); ++j) {
      printf("%d%c", ans[i][j], " \n"[j == sz(ans[i]) - 1]);
    }
  }
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
