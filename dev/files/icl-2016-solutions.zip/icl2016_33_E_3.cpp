#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <ctime>
#include <cassert>
#include <bitset>
#include <complex>
using namespace std;

const double EPS = 1e-9;
const double PI = acos(-1);
const int MAGIC = 100;

bool eq(double a, double b)
{
	return abs(a - b) < EPS;
}

bool ls(double a, double b)
{
	return a < b && !eq(a, b);
}

bool ls_eq(double a, double b)
{
	return a < b || eq(a, b);
}

bool gr(double a, double b)
{
	return a > b && !eq(a, b);
}

double my_sqrt(double a)
{
	if (ls(a, 0))
		throw;
	if (a < 0)
		a = 0;
	return sqrt(a);
}

struct Point
{
	double x, y;

	Point() : x(), y() {}

	Point(double _x, double _y) : x(_x), y(_y) {}

	Point operator+(Point p)
	{
		return Point(x + p.x, y + p.y);
	}

	Point operator-(Point p)
	{
		return Point(x - p.x, y - p.y);
	}

	Point operator*(double k)
	{
		return Point(x * k, y * k);
	}

	Point operator/(double k)
	{
		return Point(x / k, y / k);
	}

	double operator%(Point p)
	{
		return x * p.x + y * p.y;
	}

	double operator*(Point p)
	{
		return x * p.y - y * p.x;
	}

	double length()
	{
		return my_sqrt(*this % *this);
	}

	double length2()
	{
		return *this % *this;
	}

	double dist_to(Point p)
	{
		return (*this - p).length();
	}

	Point height(Point A, Point B)
	{
		Point C = *this;
		double coef = (B - A) % (C - A) / (B - A).length2();
		return A + (B - A) * coef;
	}

	Point ort()
	{
		return Point(-y, x);
	}

	Point rotate(double cosa, double sina)
	{
		return *this * cosa + ort() * sina;
	}

	Point rotate(double angle)
	{
		return rotate(cos(angle), sin(angle));
	}

	double get_angle_with(Point p)
	{
		double angle = atan2(*this * p, *this % p);
		if (angle < 0)
			angle += 2 * PI;
		return angle;
	}

	double get_std_angle()
	{
		return Point(1, 0).get_angle_with(*this);
	}

	bool on_segment(Point A, Point B)
	{
		double mul = (A - *this) % (B - *this);
		return ls_eq(mul, 0);
	}

	double dist_to_seg(Point A, Point B)
	{
		Point O = *this;
		Point H = O.height(A, B);
		if (H.on_segment(A, B))
			return O.dist_to(H);
		return min(O.dist_to(A), O.dist_to(B));
	}

	Point with_length(double k)
	{
		double len = length();
		if (eq(len, 0))
		{
			if (eq(k, 0))
				return Point();
			throw;
		}
		return *this / len * k;
	}

	void scan()
	{
		scanf("%lf%lf", &x, &y);
	}
};

void get_tangent(Point A, Point O, double r, Point &P1, Point &P2)
{
	double d = A.dist_to(O);
	double sina = r / d;
	double cosa = my_sqrt(1 - sina * sina);
	double len = my_sqrt(d * d - r * r);
	Point v = (O - A).with_length(len);
	P1 = A + v.rotate(cosa, sina);
	P2 = A + v.rotate(cosa, -sina);
}

double get_circle_dist(Point A, Point B, Point O, double r)
{
	double x = (A - O).get_std_angle();
	double y = (B - O).get_std_angle();
	double angle = min(abs(x - y), 2 * PI - abs(x - y));
	return angle * r;
}

Point A, B, O;
Point C;
double r;

void solve1()
{
	Point P1, P2;
	get_tangent(A, O, r, P1, P2);
	vector<Point> pts_a = { P1, P2 };
	get_tangent(B, O, r, P1, P2);
	vector<Point> pts_b = { P1, P2 };

	double best = 1e20;
	for (Point P : pts_a)
		for (Point Q : pts_b)
		{
			double cur = A.dist_to(P) + get_circle_dist(P, Q, O, r) + Q.dist_to(B);
			best = min(best, cur);
		}

	printf("%.10lf\n", best);
}

double eval_result(double coef1, double coef2)
{
	Point P = C + (A - C) * coef1 + (B - C) * coef2;
	return A.dist_to(P) + B.dist_to(P) + C.dist_to(P);
}

double eval_deeper(double coef1)
{
	double l = 0, r = 1;
	for (int i = 0; i < MAGIC; i++)
	{
		double m1 = l + (r - l) / 3;
		double m2 = r - (r - l) / 3;
		if (eval_result(coef1, m1) < eval_result(coef1, m2))
			r = m2;
		else
			l = m1;
	}
	return eval_result(coef1, (l + r) / 2);
}

double eval(double angle)
{
	C = Point(r, 0).rotate(angle);
	double l = 0, r = 1;
	for (int i = 0; i < MAGIC; i++)
	{
		double m1 = l + (r - l) / 3;
		double m2 = r - (r - l) / 3;
		if (eval_deeper(m1) < eval_deeper(m2))
			r = m2;
		else
			l = m1;
	}
	return eval_deeper((l + r) / 2);
}

pair<double, double> get_seg(Point P, int type)
{
	Point P1, P2;
	get_tangent(P, O, r, P1, P2);
	double angle1 = (P1 - O).get_std_angle();
	double angle2 = (P2 - O).get_std_angle();
	if (gr(angle1, angle2))
	{
		if (type == 0)
			angle1 = 0;
		else
			angle2 = 2 * PI;
	}
	return make_pair(angle1, angle2);
}

pair<double, double> inter_seg(pair<double, double> a, pair<double, double> b)
{
	return make_pair(max(a.first, b.first), min(a.second, b.second));
}

double solve2(double l, double r, int type)
{
	pair<double, double> seg(l, r);
	pair<double, double> seg_a = get_seg(A, type);
	pair<double, double> seg_b = get_seg(B, type);
	seg = inter_seg(seg, inter_seg(seg_a, seg_b));

	l = seg.first;
	r = seg.second;
	for (int it = 0; it < MAGIC; it++)
	{
		double m1 = l + (r - l) / 3;
		double m2 = r - (r - l) / 3;
		if (eval(m1) < eval(m2))
			r = m2;
		else
			l = m1;
	}

	return eval((l + r) / 2);
}

void solve2()
{
	double res = min(solve2(0, PI, 0), solve2(PI, 2 * PI, 1));
	printf("%.10lf\n", res);
}

void solve()
{
	A.scan();
	B.scan();
	O.scan();
	scanf("%lf", &r);

	double dist = O.dist_to_seg(A, B);
	if (ls(dist, r))
		throw;
		//solve1();
	else
		solve2();
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	solve();

	return 0;
}