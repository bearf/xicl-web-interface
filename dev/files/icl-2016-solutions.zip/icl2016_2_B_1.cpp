#define _CRT_SECURE_NO_WARNINGS

#include <vector>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

const int mod = (int)1e9 + 9;

int add(int a, int b)
{
	a += b;
	if (a < 0)
		return a + mod;
	if (a < mod)
		return a;
	return a - mod;
}

int mult(int a, int b)
{
	return (1LL * a * b) % mod;
}

void fadd(int &a, int b)
{
	a = add(a, b);
}

const int SZ = 100;

struct Matrix
{
	int m[SZ][SZ];
	int sz;
	Matrix()
	{
		sz = 0;
		memset(m, 0, sizeof(m));
	}
	Matrix(int _sz)
	{
		sz = _sz;
		memset(m, 0, sizeof(m));
	}

	Matrix operator * (const Matrix &x) const
	{
		Matrix res = Matrix(sz);
		for (int i = 0; i < sz; i++)
			for (int a = 0; a < sz; a++)
				for (int b = 0; b < sz; b++)
					fadd(res.m[a][b], mult(m[a][i], x.m[i][b]));
		return res;
	}
};

Matrix myPow(Matrix m, ll k)
{
	if (k == 1)
		return m;
	if (k & 1)
		return myPow(m, k - 1) * m;
	Matrix t = myPow(m, k / 2);
	return t * t;
}

int cnt[SZ];
Matrix T;
int m;

int getId(int a, int b)
{
	return a * m + b;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	
	ll n;
	scanf("%lld%d", &n, &m);
	for (int i = 0; i < m; i++)
		scanf("%d", &cnt[i]);
	T = Matrix(m * m);
	for (int a = 0; a < m; a++)
		for (int b = 0; b < m; b++)
		{
			if (a > 0 && b > 0)
			{
				fadd(T.m[getId(a, b)][getId(a - 1, b - 1)], 1);
			}
			else if (a > 0 && b == 0)
			{
				for (int i = 0; i < m; i++)
					fadd(T.m[getId(a, b)][getId(a - 1, i)], cnt[i]);
			}
			else if (a == 0 && b > 0)
			{
				for (int i = 0; i < m; i++)
					fadd(T.m[getId(a, b)][getId(i, b - 1)], cnt[i]);
			}
			else
			{
				fadd(T.m[0][0], cnt[1]);
				for (int i = 0; i < m; i++)
					for (int s = 0; s < m; s++)
						fadd(T.m[getId(a, b)][getId(i, s)], mult(cnt[i], cnt[s]));
			}
		}

	T = myPow(T, n);
	cout << T.m[0][0] << endl;
	return 0;
}