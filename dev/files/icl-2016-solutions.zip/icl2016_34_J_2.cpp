#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <map>
#include <string>
#include <complex>

#pragma warning(disable:4996)

using namespace std;

#define x1 first
#define y1 second
//#define mp make_pair
#define pb push_back
#define For(i,n) for(int i=0;i<(n);++i)
#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define all(v) (v).begin(),(v).end()

typedef long long ll;
typedef pair<double, double> point;

const int mod = 1e9 + 9;
const int INF = 2e9;
const ll LONGINF = 4e18;
const double PI = 3.1415926535897932384626433832795;
const double eps = 1e-9;


ll q;
map<ll, ll>mp;
map<ll, ll>::iterator itl, itr;

pair<ll, ll>put(ll x, ll t) {
	int l, r;
	if (mp.find(x) != mp.end()) {
		itl = mp.find(x);
		itr = next(itl);
		l = itl->first + itl->second;
		if (l + t >= itr->first) {
			r = itr->first - 1;
			itl->second = itr->first + itr->second - itl->first;
			mp.erase(itr->first);
		}
		else {
			itl->second += t;
			r = itl->first + itl->second - 1;
		}
	}
	else {
		mp[x] = 0;
		itl = prev(mp.find(x));
		if (itl->first + itl->second < x) {
			return put(x, t);///////////////////////////////////////////////////////////////
		}
		else {
			l = itl->first + itl->second;
			itr = next(mp.find(x));
			if (l + t < itr->first) {
				r = l + t - 1;
				itl->second += t;
				mp.erase(x);
			}
			else {
				r = itr->first - 1;
				itl->second = itr->second + itr->first - itl->first;
				mp.erase(itr->first);
				mp.erase(x);
			}
		}
	}
	return make_pair(l, r);
}

void del(ll x) {
	map<ll, ll>::iterator it;
	if (mp.find(x) != mp.end()) {
		it = mp.find(x);
		if (it->second == 1) {
			mp.erase(x);
		}
		else {
			mp[x + 1] = it->second - 1;
			mp.erase(x);
		}
	}
	else {
		mp[x] = 1;
		it = prev(mp.find(x));
		if (it->first + it->second <= x) {
			mp.erase(x);
		}
		else {
			mp[x] = it->second - (x - it->first);
			it->second -= mp[x];
			del(x);
		}
	}
}

void solve() {
	ll i, j, x, p;
	pair<ll, ll>t;
	mp[-1e18] = 1;
	mp[1e18] = 1;
	scanf("%I64d", &q);
	for (i = 0; i < q; i++) {
		scanf("%I64d", &x);
		if (x > 0) {
			scanf("%I64d", &p);
			t = put(x, p);
			printf("%I64d %I64d\n", t.first, t.second);
		}
		else {
			del(-x);
		}
	}
	i = i;
}

int main() {
#pragma comment(linker,"/STACK:268435456")
#ifdef _DEBUG
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#endif
	//int t;
	//scanf("%d", &t);
	//For(i, t)
	solve();
	return 0;
}