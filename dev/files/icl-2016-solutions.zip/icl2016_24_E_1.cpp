#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdint.h>
#include <string>
#include <cassert>
using namespace std;

typedef long long ll;
typedef double ld;

const ld EPS = 1e-9;

inline bool eq(ld a, ld b)
{
	return abs(a - b) < EPS;
}

inline bool ls(ld a, ld b)
{
	return a < b - EPS;
}

inline bool gr(ld a, ld b)
{
	return ls(b, a);
}

inline bool lseq(ld a, ld b)
{
	return a < b + EPS;
}

inline bool greq(ld a, ld b)
{
	return lseq(b, a);
}

struct Point
{
	ld x, y;

	Point() {}

	Point(ld _x, ld _y) : x(_x), y(_y) {}

	void Scan()
	{
		int _x, _y;
		cin >> _x >> _y;
		x = _x;
		y = _y;
	}

	Point operator + (Point b)
	{
		return Point(x + b.x, y + b.y);
	}

	Point operator - (Point b)
	{
		return Point(x - b.x, y - b.y);
	}

	Point operator * (ld k)
	{
		return Point(x * k, y * k);
	}

	Point operator / (ld k)
	{
		if (eq(k, 0.))
			throw;
		return Point(x / k, y / k);
	}

	ld operator * (Point b)
	{
		return x * b.y - y * b.x;
	}

	ld operator % (Point b)
	{
		return x * b.x + y * b.y;
	}

	ld sqlen()
	{
		return *this % *this;
	}

	ld len()
	{
		return sqrt(sqlen());
	}

	Point norm(ld k)
	{
		if (eq(len(), 0.))
			throw;
		return *this / len() * k;
	}
};

Point projec(Point A, Point B, Point C)
{
	return A + (B - A) * ((B - A) % (C - A) / (B - A).sqlen());
}

bool seg(Point A, Point B, Point C)
{
	return lseq((A - C) % (B - C), 0.);
}

bool inter(Point A, Point B, Point O, ld r, Point &M1, Point &M2)
{
	Point H = projec(A, B, O);

	ld d = (O - H).len();

	if (greq(d, r))
		return false;

	ld len = sqrt(r * r - d * d);

	Point a = (B - A).norm(len);

	M1 = H + a;
	M2 = H - a;

	return seg(A, B, M1) && seg(A, B, M2);
}

ld oncir(Point O, Point A, Point B)
{
	ld ang = atan2((A - O) * (B - O), (A - O) % (B - O));
	ang = abs(ang);

	return min(ang, 2 * acos(-1.) - ang);
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
#ifdef AWWW
	assert(freopen("input.txt", "r", stdin) != nullptr);
#endif

	Point A, B, O;
	A.Scan();
	B.Scan();
	O.Scan();
	ld r;
	cin >> r;

	Point M1, M2;

	cout.precision(20);

	if (!inter(A, B, O, r, M1, M2))
	{
		cout << (B - A).len();
	}
	else
	{
		if (ls((M2 - A).sqlen(), (M1 - A).sqlen()))
			swap(M1, M2);

		cout << (A - M1).len() + oncir(O, M1, M2) * r + (B - M2).len();
	}

#ifdef AWWW
	while (true) {}
#endif
}