#define __USE_MINGW_ANSI_STDIO 0
#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (n); ++i)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)

// -- MAIN PART

typedef double dbl;
const dbl PI = acos(-1);

struct pt
{
	dbl x, y;
	pt(){}
	pt(dbl xx, dbl yy): x(xx), y(yy) {}
	void read()
	{
		scanf("%lf%lf", &x, &y);
	}
};

inline pt operator + (pt p1, pt p2) { return pt(p1.x + p2.x, p1.y + p2.y); }
inline pt operator - (pt p1, pt p2) { return pt(p1.x - p2.x, p1.y - p2.y); }
inline pt operator * (pt p, dbl c) { return pt(p.x * c, p.y * c); }

inline dbl vect(pt p1, pt p2) { return p1.x * p2.y - p1.y * p2.x; }
inline dbl scal(pt p1, pt p2) { return p1.x * p2.x + p1.y * p2.y; }


inline dbl dist(pt p1, pt p2)
{
	dbl dx = p1.x - p2.x;
	dbl dy = p1.y - p2.y;
	return sqrt(dx * dx + dy * dy);
}

#define mp make_pair
#define F first
#define S second


pair<pt, dbl> get(pt A, pt B, dbl alp, int fl)
{
	pt M = (A + B) * 0.5;
	pt dir = (B - A);
	dir = pt(-dir.y, dir.x);
	dbl l = sqrt(dir.x * dir.x + dir.y * dir.y);
	dir.x /= l;
	dir.y /= l;

	if (fl) dir = dir * -1;

	dbl x = dist(A, M);

	alp /= 2;
	dbl y = x * cos(alp) / sin(alp);

	dbl  z = (x * x - y * y) / (2 * y);

	pt O = M - dir * z;
	dbl R = dist(A, O);

	return mp(O, R);
}

inline pt rot(pt p, dbl alp)
{
	return pt(p.x * cos(alp) - p.y * sin(alp), p.x * sin(alp) + p.y * cos(alp));
}

pt intersect(pair<pt, dbl> c1, pair<pt, dbl> c2, pt B)
{
	pt v = c2.F - c1.F;
	dbl l = sqrt(v.x * v.x + v.y * v.y);
	v = v * (1. / l);

	dbl d = dist(c1.F, c2.F);
	dbl alp = acos(max(-1., min(1., (c1.S * c1.S + d * d - c2.S * c2.S) / (2 * c1.S * d))));


	pt X = c1.F + rot(v, alp) * c1.S;
	pt Y = c1.F + rot(v, -alp) * c1.S;


	if (dist(X, B) < dist(Y, B)) swap(X, Y);

	return X;
}

dbl angle(pt A, pt B, pt C)
{
	dbl ab = dist(A, B);
	dbl bc = dist(B, C);
	dbl ac = dist(A, C);

	return acos(max(-1., min(1., (ab * ab + ac * ac - bc * bc) / (2 * ab * ac))));
}


int main()
{
	#ifdef home
		assert(freopen("1.in", "r", stdin));
		assert(freopen("1.out", "w", stdout));
	#endif
	int tn;
	scanf("%d", &tn);
	forn(tt, tn)
	{
		pt A, B, C;
		A.read();
		B.read();
		C.read();


		dbl kab, kbc;
		scanf("%lf%lf", &kab, &kbc);
		kab = kab * PI / 180.;
		kbc = kbc * PI / 180.;

		pt r = pt(0, 0);
		dbl res = 1e100;
		forn(i, 2) forn(j, 2)
		{

			pair<pt, dbl> cab = get(A, B, kab, i);
			pair<pt, dbl> cbc = get(B, C, kbc, j);

			pt I = intersect(cab, cbc, B);

			dbl val = abs(angle(I, A, B) - kab) + abs(angle(I, B, C) - kbc);
			
			if (val < res)
			{
				res = val;
				r = I;
			}
		}
      	printf("%.10f %.10f\n", r.x, r.y);

	}


	#ifdef home
		eprintf("time = %d ms\n", (int)(clock() * 1000. / CLOCKS_PER_SEC));
	#endif
	return 0;
}
