#include <bits/stdc++.h>

#define fr first
#define sc second
#define all(x) x.begin(), x.end()
#define int long long

using namespace std;

const int MAXN = 1e5;

set<pair<pair<int, int>, pair<int, int>>> kek;

int dist(pair<pair<int, int>, pair<int, int>> x, pair<pair<int, int>, pair<int, int>> y) {
    return abs(x.fr.fr - y.fr.fr) + abs(x.fr.sc - y.fr.sc) + abs(x.sc.fr - y.sc.fr) + abs(x.sc.sc - y.sc.sc);
}

main()
{
//    freopen("in.txt", "r", stdin);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) {
        int a;
        int b, c, d, e;
        cin >> a >> b >> c >> d >> e;
        if (a == 1) {
            pair<pair<int, int>, pair<int, int>> x;
            x.fr.fr = b;
            x.fr.sc = c;
            x.sc.fr = d;
            x.sc.sc = e;
            kek.insert(x);
        }
        if (a == 2) {
            kek.erase({{b, c}, {d, e}});
        }
        if (a== 3) {
            int mx = 0;
            for (auto j : kek) {
                int q = dist({{b, c}, {d, e}}, j);
                mx = max(mx, q);
            }
            cout << mx << endl;
        }
    }
}
