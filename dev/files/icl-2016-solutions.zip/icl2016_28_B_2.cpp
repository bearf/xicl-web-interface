#include <vector>
#include <set>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <string>
#include <assert.h>
#include <time.h>

using namespace std;

#define mp make_pair
#define pb emplace_back
#define all(a) (a).begin(), (a).end()

typedef long long li;
typedef long double ld;

void solve();

int main() {
#ifdef ICL
	clock_t start = clock();
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(0);
	cout.precision(20);
	cout << fixed;
	int t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
#ifdef ICL
	cout << endl << (clock() - start) / 1.0 / CLOCKS_PER_SEC << endl;
#endif
}

#define int li
const int mod = 1000000009;

int binpow(int q, int w) {
	if (!w) {
		return 1;
	}
	if (w & 1) {
		return q * binpow(q, w - 1) % mod;
	}
	return binpow(q * q % mod, w / 2);
}

void mmod(int& cur) {
	if (cur >= mod) {
		cur -= mod;
	}
}

int m;
vector<vector<int>> trans;

vector<vector<char>> used;

vector<int> col;

vector<int> have;

int start[2];

void rec(int x, int y) {
	if (x == 2) {
		return rec(0, y + 1);
	}
	if (y < 2 * m && used[x][y]) {
		return rec(x + 1, y);
	}
	int border[] = { 2 * m, 2 * m };
	for (int w = 0; w < 2; ++w) {
		for (int i = 0; i < 2 * m; ++i) {
			if (!used[w][i]) {
				border[w] = i;
				break;
			}
		}
	}
	if (border[0] > m && border[1] > m) {
		border[0] -= m + 1;
		border[1] -= m + 1;
		int cur_res = 1;
		for (int i = 1; i <= m; ++i) {
			cur_res = cur_res * binpow(col[i], have[i]) % mod;
		}
		trans[start[0] * m + start[1]][border[0] * m + border[1]] += cur_res;
		mmod(trans[start[0] * m + start[1]][border[0] * m + border[1]]);
	}

	if (y == 2 * m) {
		return;
	}

	if (y >= m) {
		++have[1];
		used[x][y] = true;
		rec(x + 1, y);
		used[x][y] = false;
		--have[1];

		if (m >= 2 && x == 0 && !used[1][y]) {
			++have[2];
			used[0][y] = true;
			used[1][y] = true;
			rec(x + 1, y);
			used[0][y] = false;
			used[1][y] = false;
			--have[2];
		}
	}

	for (int cur = 2; cur <= m; ++cur) {
		int nex = y + cur - 1;
		if (nex >= 2 * m) {
			break;
		}
		if (nex >= m) {
			++have[cur];
			for (int z = y; z <= nex; ++z) {
				used[x][z] = true;
			}
			rec(x + 1, y);
			for (int z = y; z <= nex; ++z) {
				used[x][z] = false;
			}
			--have[cur];
		}
	}
}

const int L = 60;

typedef vector<vector<int>> Matrix;

Matrix mult(const Matrix& q, const Matrix& w) {
	vector<vector<int>> res(q.size(), vector<int>(q.size(), 0));
	for (int i = 0; i < q.size(); ++i) {
		for (int k = 0; k < q.size(); ++k) {
			for (int j = 0; j < q.size(); ++j) {
				res[i][j] += q[i][k] * w[k][j];
				res[i][j] %= mod;
			}
		}
	}
	return res;
}

void solve() {
	int n;
	cin >> n >> m;
	col.resize(m + 1);
	for (int i = 1; i <= m; ++i) {
		cin >> col[i];
	}
	trans.assign(m * m, vector<int>(m * m, 0));
	for (int i = 0; i < m; ++i) {
		for (int j = 0; j < m; ++j) {
			vector<vector<int>> dp(2 * m + 1, vector<int>(2 * m + 1));
			dp[i][j] = 1;
			for (int fs = i; fs < 2 * m; ++fs) {
				for (int sc = j; sc < 2 * m; ++sc) {
					if (fs == sc && fs >= m - 1 && m >= 2) {
						dp[fs + 1][sc + 1] += dp[fs][sc] * col[2];
						dp[fs + 1][sc + 1] %= mod;
					}

					if (sc < fs) {
						for (int cur = 1; cur <= m; ++cur) {
							int last = sc + cur;
							if (last > 2 * m) {
								break;
							}
							if (last < m) {
								continue;
							}
							dp[fs][last] += dp[fs][sc] * col[cur];
							dp[fs][last] %= mod;
						}
					}
					else {
						for (int cur = 1; cur <= m; ++cur) {
							int last = fs + cur;
							if (last > 2 * m) {
								break;
							}
							if (last < m) {
								continue;
							}
							dp[last][sc] += dp[fs][sc] * col[cur];
							dp[last][sc] %= mod;
						}
					}
				}
			}

			for (int fs = m; fs < 2 * m; ++fs) {
				for (int sc = m; sc < 2 * m; ++sc) {
					trans[i * m + j][(fs - m) * m + (sc - m)] += dp[fs][sc];
					mmod(trans[i * m + j][(fs - m) * m + (sc - m)]);
				}
			}
		}
	}

	vector<vector<vector<int>>> pows(L);
	pows[0] = trans;
	for (int i = 1; i < L; ++i) {
		pows[i] = mult(pows[i - 1], pows[i - 1]);
	}

	int step = (n - 1) / m + 1;
	vector<vector<int>> res(m * m, vector<int>(m * m));
	for (int i = 0; i < res.size(); ++i) {
		res[i][i] = 1;
	}
	for (int i = 0; i < L; ++i) {
		if (step & 1) {
			res = mult(res, pows[i]);
		}
		step >>= 1;
	}

	int rest = n % m;
	if (rest == 0) {
		rest = m;
	}
	--rest;
	int ans = res.back()[rest * m + rest];

	cout << ans << "\n";
}
