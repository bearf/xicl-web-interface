#include <bits/stdc++.h>
#define mp make_pair
#define endl "\n"
#define F first
#define S second

const double eps = 0.0000000001;
const int INF = 1e9, MAXN = 5 * 1e8 + 1e3 + 1;

using namespace std;
typedef long double ld;
typedef long long ll;

string s, f;
string p[10];
set <pair <char, char> > c;

long double ans = 0;

inline void dfs(int d, long double v, long double k) {
    if (v == 0) {
        return;
    }

    if (d == s.length()) {
        ans += k * v;
        return;
    }

    if (s[d] == f[d]) {
        dfs(d + 1, v, k);
        return;
    }

    c.clear();
    c.insert({p[d][0], p[d][5]});
    c.insert({p[d][5], p[d][0]});
    c.insert({p[d][1], p[d][3]});
    c.insert({p[d][3], p[d][1]});
    c.insert({p[d][2], p[d][4]});
    c.insert({p[d][4], p[d][2]});


    int k1 = 0, k2 = 0;
    for (auto in : c) {
        if (in.first == s[d]) {
            k1++;
        }
    }
    for (auto in : c) {
        if (in.second == f[d]) {
            k2++;
        }
    }

    for (auto in : c) {
        if (in.first == s[d] && in.second == f[d]) {
            dfs(d + 1, v, k * (ld(1) / k1));
        }
    }

    for (int i = 0; i < k1; ++i) {
        for (int j = 0; j < k2; ++j) {
            dfs(d + 1, v * 0.5, k * (ld(1) / k1) * (ld(1) / k2));
        }
    }
}

int main() {
    #ifdef _HOME_
        freopen("input.txt", "r", stdin);
    #endif // _HOME_

    cout.precision(50);

    getline(cin, s);
    getline(cin, f);

    ll x = 1;
    ll a, b;

    for (int i = 0; i < s.length(); ++i) {
        getline(cin, p[i]);

        bool f1, f2;
        f1 = f2 = 0;

        for (int j = 0; j < 6; ++j) {
            if (p[i][j] == f[i]) {
                f1 = 1;
            }
            if (p[i][j] == s[i]) {
                f2 = 1;
            }
        }
        if (!f1 || !f2) {
            cout << 0;
            return 0;
        }
    }

    dfs(0, 1, 1);
    cout << ans;
}
