#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long long i64;
typedef long double ld;
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define forab(i,a,b) for (int i = int(a); i < int(b); ++i)
#define sz(x) ((int) (x).size())

typedef pair<int, int> pii;
#define se second
#define fi first
#define pb push_back

const int maxn = 10500;

vector<pii> canon(const string& s) {
    vector<int> p;
    forn(i, s.size()) {
        if (s[i] == '1') {
            p.pb(i);
        }
    }

    vector<pii> res;
    forn(i, p.size() - 1) {
        int x = p[i];
        int y = p[i+1];
        res.emplace_back(i, y);
        p[i] = i;
        p[i+1] = i + y - x;
    }
    res.emplace_back(-1, p.back());
    return res;
}

int main() {
#ifdef LOCAL
    assert(freopen("k.in", "r", stdin));
#endif

    ios::sync_with_stdio(false);

    string s, t;
    cin >> s >> t;
    {
        int s1 = count(s.begin(), s.end(), '1');
        int s2 = count(t.begin(), t.end(), '1');
        if (s1 != s2) {
            cout << "NO" << endl;
            return 0;
        }
        if (s1 == 0) {
            cout << "YES" << endl;
            cout << "0" << endl;
            return 0;
        }
    }

    auto c1 = canon(s);
    auto c2 = canon(t);

    //cerr << c1.back().se << " " << c2.back().se << endl;

    if (c1.back().se != c2.back().se) {
        cout << "NO" << endl;
        return 0;
    }

    vector<pii> res;
    forn(i, c1.size() - 1) res.pb(c1[i]);
    for (int i = c2.size() - 2; i >= 0; --i) res.pb(c2[i]);

    cout << "YES\n";
    cout << res.size() << "\n";
    for (auto kv: res) {
        cout << kv.fi+1 << " " << kv.se+1 << "\n";

        //assert(count(s.begin() + kv.fi, s.begin() + kv.se + 1, '1') % 2 == 0);
        //reverse(s.begin() + kv.fi, s.begin() + kv.se + 1);
    }

    //cout << s << "\n" << t << endl;
}
