#include <bits/stdc++.h>

using namespace std;

#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#define sz(x) ((int) (x).size())
#define mp make_pair
#define pb push_back
#define TASK "text"

typedef long long ll;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = (int) 1.01e9;
const ld PI = acos(-1.0L);

void precalc() {
}

ll l, n, k;

int read() {
  if (scanf("%I64d%I64d%I64d", &l, &n, &k) < 3) {
    return 0;
  }
  return 1;
}

bool check(ll x) {
  ll cur = l;
  if (x == 0) {
    return true;
  }
  while (cur) {
    ll need = max(1ll, (x - 1 + k - 3) / (k - 2));
    eprintf("cur = %d, x = %d\n", (int) cur, (int) x);
    ll canto = (k - 2) * need + 1;
    assert(canto >= x);
    ll canjump = (canto - x) / (need * 2) + 1;
    canjump = min(canjump, cur);
    x = x + canjump * (need * 2 - 1);
    if (x > n) {
      return false;
    }
    cur -= canjump;
  }
  return true;
}

void solve() {
  if (k == 1) {
    printf("0\n");
  } else if (k == 2) {
    if (n > 1 && l == 1) {
      printf("1\n");
    } else {
      printf("0\n");
    }
  } else {
    ll L = 0, R = 1e9 + 10;
    while (L < R - 1) {
      ll mid = (L + R) / 2;
      if (check(mid)) {
        L = mid;
      } else {
        R = mid;
      }
    }
    printf("%d\n", (int) L);
  }
}

int main() {
  precalc();
  
#ifdef DEBUG
  freopen(TASK ".in", "r", stdin);
  freopen(TASK ".out", "w", stdout);
#endif

  while (1) {
    if (!read()) {
      break;    
    }
    solve();
#ifdef DEBUG
    eprintf("Time %.3f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  }
  return 0;
}
