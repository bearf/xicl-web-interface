#define _CRT_SECURE_NO_WARNINGS

#include <cmath>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <stdint.h>
#include <string>
#include <ctime>
#include <cassert>
#define fi first
#define se second
#define sz(a) int(a.size())
#define re return
#define forn(i, n) for (int i = 0; i < n; i++)
using namespace std;

typedef long long ll;
typedef double ld;
typedef pair<int, int> pii;

int a, b, c, d;
vector<pair<pii, pii> > ans;
int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
#ifdef AWWW
	assert(freopen("input.txt", "r", stdin) != nullptr);
#endif
	cin >> a >> b >> c >> d;
	if (a == b) {
		while (a > 1) {
			if (a % 2 == 1) {
				ans.push_back({ { 1, 0 },{ a, b } });
				a++; b++;
			}
			ans.push_back({ { 2, 0 },{ a, b } });
			a /= 2;
			b /= 2;
		}
		if (c != d) {
			cout << "0";
			re 0;
		}
		while (a < c) {
			ans.push_back({ {1, 0}, {a, b} });
			a++;
		}
		cout << sz(ans) << endl;
		forn(i, sz(ans)) {
			cout << ans[i].fi.fi << " ";
			if (ans[i].fi.fi < 3) cout << ans[i].se.fi << " " << ans[i].se.se << "\n";
			else cout << ans[i].fi.se << " " << ans[i].se.fi << " " << ans[i].se.fi << " " << ans[i].se.se << "\n";
		}
		return 0;
	}
	while (a % 2 == b % 2) {
		if (a % 2 == 1) {
			ans.push_back({ { 1, 0 }, { a, b } });
			a++; b++;
		}
		ans.push_back({ { 2, 0 }, { a, b } });
		a /= 2;
		b /= 2;
	}	

	if (c < a || (d - c) % (b - a) != 0 || (d - c) / (b - a) < 0) {
		cout << 0;
		re 0;
	}
	int aa = a, bb = b, qq = a, pp = b;
	while (bb - aa != d - c) {
		forn(i, abs(a - b)) {
			ans.push_back({ {1, 0}, {qq, pp} });
			qq++;
			pp++;
		}
		ans.push_back({ {3, a}, {bb, pp} });
		bb = pp;
	}
	while (a < c) {
		ans.push_back({ {1, 0}, {a, bb} });
		a++; bb++;
	}
	cout << sz(ans) << endl;
	forn(i, sz(ans)) {
		cout << ans[i].fi.fi << " ";
		if (ans[i].fi.fi < 3) cout << ans[i].se.fi << " " << ans[i].se.se << "\n";
		else cout << ans[i].fi.se << " " << ans[i].se.fi << " " << ans[i].se.fi << " " << ans[i].se.se << "\n";
	}
#ifdef AWWW
	cout << "\n\n\nTIME: " << clock() / (ld)CLOCKS_PER_SEC << endl;
	while (true) {}
#endif
}