#include <bits/stdc++.h>

using namespace std;

int main(){
    ios_base::sync_with_stdio(false);
    //freopen("input.txt" , "r" , stdin); freopen("output.txt" , "w" , stdout);
    string s;
    cin >> s;
    int n;
    cin >> n;
    for (int i = 0; i < n; i++){
        string a, b;
        int x;
        cin >> x;
        reverse(s.begin(), s.begin() + x);
        reverse(s.begin() + x, s.end());
    }
    cout << s << endl;
    return 0;
}
