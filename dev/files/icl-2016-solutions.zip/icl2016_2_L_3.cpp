#define _CRT_SECURE_NO_WARNINGS

#include <vector>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <ctime>
#include <valarray>
#include <cassert>

using namespace std;

#ifndef ONLINE_JUDGE
#define eprintf(...) fprintf(stdout, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif

typedef long long ll;

const double INF = 1e100;
const double eps = 1e-8;
const double pi = atan(1.) * 4;

bool Eq(double a, double b)
{
	return fabs(a - b) < eps;
}

bool Ls(double a, double b)
{
	return a < b && !Eq(a, b);
}

bool LsEq(double a, double b)
{
	return a < b || Eq(a, b);
}

bool Gr(double a, double b)
{
	return a > b && !Eq(a, b);
}

bool GrEq(double a, double b)
{
	return a > b || Eq(a, b);
}

double sqr(double a)
{
	return a * a;
}

double mySqrt(double a)
{
	if (a < 0)
		return 0;
	return sqrt(a);
}

struct Point
{
	double x, y;
	Point() : x(), y() {}
	Point(double _x, double _y) : x(_x), y(_y) {}
	Point operator + (const Point &a) const
	{
		return Point(x + a.x, y + a.y);
	}
	Point operator - (const Point &a) const
	{
		return Point(x - a.x, y - a.y);
	}
	Point operator * (double k) const
	{
		return Point(x * k, y * k);
	}
	Point operator / (double k) const
	{
		return Point(x / k, y / k);
	}
	double operator % (const Point &a) const
	{
		return x * a.x + y * a.y;
	}
	double operator * (const Point &a) const
	{
		return x * a.y - y * a.x;
	}
	double length()
	{
		return mySqrt(x * x + y * y);
	}
	double sqrLen()
	{
		return x * x + y * y;
	}
	Point norm()
	{
		return *this / length();
	}
	Point rotate(double a)
	{
		return rotate(sin(a), cos(a));
	}
	Point rotate(double sina, double cosa)
	{
		return Point(x * cosa - y * sina, x * sina + y * cosa);
	}
	Point ort()
	{
		return Point(-y, x);
	}
	bool operator == (const Point &a) const
	{
		return Eq(x, a.x) && Eq(y, a.y);
	}
	void scan()
	{
		scanf("%lf%lf", &x, &y);
	}
	void print()
	{
		printf("%.7lf %.7lf\n", x, y);
	}
};

double getAngle(Point P, Point A, Point B)
{
	double angle = atan2((A - P) * (B - P), (A - P) % (B - P));
	return (angle);
}

Point getH(Point P, Point A, Point v)
{
	return A + v * ((P - A) % v) / (v % v);
}

bool onLine(Point P, Point A, Point v)
{
	return Eq((P - A) * v, 0);
}

bool onSegment(Point P, Point A, Point B, bool strict = false)
{
	if (!strict)
		return onLine(P, A, B - A) && LsEq((P - A) % (P - B), 0);
	return onLine(P, A, B - A) && Ls((P - A) % (P - B), 0);
}

bool ensureOnSegment(Point P, Point A, Point B, bool strict = false)
{
	if (!strict)
		return LsEq((P - A) % (P - B), 0);
	return Ls((P - A) % (P - B), 0);
}

bool intersectLines(Point A, Point v, Point B, Point u, Point &P)
{
	if (Eq(v * u, 0))
		return false;
	double k = (A * v - B * v) / (u * v);
	P = B + u * k;
	return true;
}

bool intersectCircleLine(Point O1, double R1, Point A, Point v, Point &I1, Point &I2)
{
	Point H = getH(O1, A, v);
	double h = (O1 - H).length();
	if (Gr(h, R1))
		return false;
	double l = mySqrt(sqr(R1) - sqr(h));
	v = v.norm();
	I1 = H + v * l;
	I2 = H - v * l;
	return true;
}

bool intersectCircleSegment(Point O1, double R1, Point A, Point B)
{
	Point I1, I2;
	if (intersectCircleLine(O1, R1, A, B - A, I1, I2))
	{
		return ensureOnSegment(I1, A, B, true) || ensureOnSegment(I2, A, B, true);
	}
	return false;
}

void getTanget(Point P, Point O, double R, Point &I1, Point &I2)
{
	Point v = O - P;
	double d = v.length();
	double alpha = asin(R / d);
	double l = mySqrt(sqr(d) - sqr(R));
	I1 = O + v.norm().rotate(alpha) * l;
	I2 = O + v.norm().rotate(-alpha) * l;
}

double getDistOnCircle(Point O, Point A, Point B)
{
	double angle = getAngle(O, A, B);
	return angle * (A - O).length();
}

Point getIsoTrian(Point A, Point B, Point C)
{
	Point v = (B - A).ort();
	if (Gr((C - A) % v, 0))
		v = v * -1;
	v = v.norm() * (B - A).length() * sqrt(3.) / 2;
	return (A + B) / 2 + v;
}

const double CRIT_ANGLE = 2 * pi / 3;


bool checkAngle(Point P, Point A, Point B)
{
	return GrEq(fabs(getAngle(P, A, B)), CRIT_ANGLE);
}

Point getMagicPoint(Point A, Point B, Point C)
{
	if (checkAngle(A, B, C))
		return A;
	if (checkAngle(B, A, C))
		return B;
	if (checkAngle(C, A, B))
		return C;
	Point H1 = getIsoTrian(A, B, C);
	Point H2 = getIsoTrian(B, C, A);
	Point I;
	assert(intersectLines(H1, C - H1, H2, A - H2, I));
	return I;
}

bool inCircle(Point P, Point O, double R)
{
	return LsEq((P - O).length(), R);
}

Point tmpA[10];
Point tmpB[10];

double getDistForPoint(Point P, Point A, Point B, Point O, double R)
{
	return (P - A).length() + (P - B).length() + (P - O).length() - R;
}

double solveWithTangent(Point A, Point B, Point O, double R)
{
	getTanget(A, O, R, tmpA[0], tmpA[1]);
	getTanget(B, O, R, tmpB[0], tmpB[1]);

	double ans = INF;
	for (int i = 0; i < 2; i++)
		for (int s = 0; s < 2; s++)
		{
			tmpA[i].print();
			tmpB[s].print();
			ans = min(ans, (A - tmpA[i]).length() + (B - tmpB[s]).length() + getDistOnCircle(O, tmpA[i], tmpB[s]));
		}
	return ans;
}

const int STEPS = 1000;
const int IT = 100;

double solveTern(Point A, Point B, Point O, double R, double l, double r)
{
	Point v = Point(R, 0);
	for (int it = 0; it < IT; it++)
	{
		double m1 = l + (r - l) / 3;
		double m2 = r - (r - l) / 3;

		Point H1 = O + v.rotate(m1);
		Point H2 = O + v.rotate(m2);
		double value1 = getDistForPoint(H1, A, B, O, R);
		double value2 = getDistForPoint(H2, A, B, O, R);
		if (value1 < value2)
			r = m2;
		else
			l = m1;
	}
	double mid = (l + r) / 2;
	Point H = O + v.rotate(mid);
	return getDistForPoint(H, A, B, O, R);
}

double solveWithMagic(Point A, Point B, Point O, double R)
{
	Point P = getMagicPoint(A, B, O);
	if (!inCircle(P, O, R))
		return getDistForPoint(P, A, B, O, R);
	double delta = 2 * pi / STEPS;
	double ans = INF;
	for (int i = 0; i < STEPS; i++)
	{
		double l = delta * i;
		double r = l + 2 * delta;
		ans = min(ans, solveTern(A, B, O, R, l, r));
	}
	return ans;
}

double solve(Point A, Point B, Point O, double R)
{
	if (intersectCircleSegment(O, R, A, B))
	{
		return solveWithTangent(A, B, O, R);
	}
	else if (onLine(O, A, B - A))
	{
		return max((A - O).length(), (B - O).length()) - R;
	}
	else
		return solveWithMagic(A, B, O, R);
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	assert(sizeof(long double) == sizeof(double));
	return 0;
	Point A, B;
	Point O;
	double R;
	A.scan();
	B.scan();
	O.scan();
	scanf("%lf", &R);

	printf("%.10lf\n", solve(A, B, O, R));

	return 0;
}