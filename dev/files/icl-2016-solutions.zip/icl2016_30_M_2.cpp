#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#define ull long long
# define uull unsigned long long
using namespace std;

ull gcd(ull a, ull b) {
	while (b) {
		a %= b;
		swap(a, b);
	}
	return a;
}

ull nok(ull a, ull b) {
	return a / gcd(a, b)*b;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	ull n;
	cin >> n;
	ull q = 1, w = 1; // q/w
	cin >> q >> w;
	for (ull i = 1; i < n; i++) {
		ull a, b;
		cin >> a >> b;
		q = nok(q, a);
		w = gcd(w, b);
	}
	cout << q << " " << w;
}