import ru.icl.dicewars.client.*;

import java.io.File;
import java.io.PrintWriter;
import java.util.*;

public class Bot implements Player {

    //private PrintWriter write;

    private static final double WINPROB = 0.5;

    private static final double WINEPS = 1E-5;
    private static final int MINPREDICT = 8;
    private static final int MAXPREDICT = 8;

    class State{
        Integer diceCount = null, maxComp = null, compCnt = null, area = null;
        State(){}
    };

    class Pair {
        int a, b, c;

        Pair() {
        }

        Pair(int a, int b, int c) {
            this.a = a;
            this.b = b;
            this.c = c;
        }
    }

    class Dsu {
        int c[];
        int cnt[];

        public Dsu() {
        }

        Dsu(int size) {
            c = new int[size];
            cnt = new int[size];
            for (int i = 0; i < c.length; ++i) {
                c[i] = i;
                cnt[i] = 1;
            }
        }

        int root(int v) {
            return c[v] == v ? v : (c[v] = root(c[v]));
        }

        boolean merge(int v, int u) {
            v = root(v);
            u = root(u);
            if (v == u) return false;

            c[v] = u;
            cnt[u] = cnt[v] + cnt[u];
            return true;
        }
    }


    class Graph {
        int g[][], n;

        TreeMap<Integer, Integer> num;
        int toLandId[];

        Flag[] color;
        int dice[];

        Graph(World cur) {
            n = cur.getLands().size();
            toLandId = new int[n];
            g = new int[n][];
            color = new Flag[n];
            dice = new int[n];
            num = new TreeMap<Integer, Integer>();
            for (Land L : cur.getLands()) {
                if (!num.containsKey(L.getLandId())) {
                    int val = num.size();
                    num.put(L.getLandId(), val);
                    toLandId[val] = L.getLandId();
                }
                int id = num.get(L.getLandId());
                g[id] = new int[L.getNeighbouringLands().size()];
                color[id] = L.getFlag();
                dice[id] = L.getDiceCount();
            }

            for (Land L : cur.getLands()) {
                int idx = 0, mn = num.get(L.getLandId());
                for (Land s : L.getNeighbouringLands()) {
                    g[mn][idx++] = num.get(s.getLandId());
                }
            }
        }

        
        int maxVFromDinamic = -1;
        int movesFromDinamic = -1;
        double probFromDinamic = 0.0;

        MyAttack calcDinamics(Flag my, int cnt, boolean init) {
            cnt = Math.min(MAXPREDICT, cnt);
            double d[][][] = new double[n][10][cnt + 1];
            Pair par[][][] = new Pair[n][10][cnt + 1];
            ArrayDeque<Pair> q = new ArrayDeque<Pair>();

            for (int i = 0; i < n; ++i) {
                if (color[i].equals(my)) {
                    d[i][dice[i]][0] = 1.0;
                    q.add(new Pair(i, dice[i], 0));
                }
            }

            while (q.size() > 0) {
                Pair cur = q.getFirst();
                q.removeFirst();
                int v = cur.a, dCount = cur.b, step = cur.c;

                if (step == cnt || dCount == 1) continue;

                for (int i = 0; i < g[v].length; ++i) {
                    int u = g[v][i];
                    if (!color[u].equals(my)) {
                        if (d[u][dCount - 1][step + 1] < d[v][dCount][step] * canWin(dCount, dice[u])) {
                            if (d[v][dCount][step] * canWin(dCount, dice[u]) >= WINPROB) {
                                d[u][dCount - 1][step + 1] = d[v][dCount][step] * canWin(dCount, dice[u]);
                                Pair cc = new Pair(u, dCount - 1, step + 1);
                                par[u][dCount - 1][step + 1] = new Pair(v, dCount, step);
                                q.addLast(cc);
                            }
                        }
                    }
                }
            }

            int ans = -1;
            Pair res = new Pair(-1, -1, -1);
            Pair prev = new Pair(-1, -1, -1);

            for (int v = 0; v < n; ++v) {
                for (int c = 1; c <= 8; c++) {
                    for (int k = 1; k <= cnt; k++) {

                        if (d[v][c][k] >= WINPROB) {

                            ArrayList<Integer> path = new ArrayList<Integer>();

                            Dsu dsu = new Dsu(n);
                            for (int i = 0; i < n; ++i) {
                                for (int j = 0; j < g[i].length; ++j) {
                                    if (color[i].equals(color[g[i][j]]) && color[i].equals(my)) {
                                        dsu.merge(i, g[i][j]);
                                    }
                                }
                            }

                            for (Pair cur = new Pair(v, c, k); cur != null; cur = par[cur.a][cur.b][cur.c]) {
                                if (par[cur.a][cur.b][cur.c] != null)
                                    dsu.merge(cur.a, par[cur.a][cur.b][cur.c].a);
                                path.add(cur.a);
                                for (int i = 0; i < g[cur.a].length; ++i) {
                                    int nn = g[cur.a][i];
                                    if (color[nn].equals(my)) {
                                        dsu.merge(cur.a, nn);
                                    }
                                }
                            }

                            int maxV = -1;
                            for (int i = 0; i < n; i++) {
                                if (dsu.cnt[i] > maxV && color[i].equals(my)) {
                                    maxV = dsu.cnt[i];
                                }
                            }

                            if (maxV > ans || (maxV == ans && (d[prev.a][prev.b][prev.c] < d[v][c][k] ||
                                    (Math.abs(d[prev.a][prev.b][prev.c] - d[v][c][k]) < WINEPS && prev.b < c)))) {
                                ans = maxV;
                                prev = new Pair(v, c, k);
                                res = new Pair(path.get(path.size() - 1), path.get(path.size() - 2), 0);
                            }

                        }

                    }
                }
            }

            if (ans == -1) return null;

            if(init){
                maxVFromDinamic = ans;
                movesFromDinamic = prev.c;
                probFromDinamic = d[prev.a][prev.b][prev.c];
            }

            return new MyAttack(toLandId[res.a], toLandId[res.b]);
        }

        int dfs(int v, boolean used[], int p[]) {
            used[v] = true;
            int ans = 1;
            for (int i = 0; i < g[v].length; ++i) {
                int u = g[v][i];
                if (!used[u]){
                    ans += dfs(u, used, p);
                    p[u] = v;
                }
            }
            return ans;
        }

        int getBiggestComp(Flag cur) {
            int sz = 0;

            boolean used[] = new boolean[n];
            int p[] = new int[n];
            Arrays.fill(p, -1);

            for (int i = 0; i < n; ++i) {
                if (color[i].equals(cur) && !used[i]) {
                    sz = Math.max(sz, dfs(i, used, p));
                }
            }

            return sz;
        }

        void setColor(Land s, Flag col) {
            color[num.get(s.getLandId())] = col;
        }

    }

    private final int INF = (int) 1E9;
    private final double EPS = 1E-9;

    public String getName() {
        return "Don Gun";
    }

    double dWin[][];
    double dSum[][];

    void initSum() {
        dSum = new double[9][80];
        dSum[0][0] = 1.0;
        for (int cnt = 0; cnt < 8; cnt++) {
            for (int sum = 0; sum <= 70; sum++) {
                if (Math.abs(dSum[cnt][sum]) < EPS) continue;
                for (int now = 1; now <= 6; now++) {
                    dSum[cnt + 1][now + sum] += (1.0 / 6.0) * dSum[cnt][sum];
                }
            }
        }
    }

    void initWin() {
        initSum();
        dWin = new double[9][9];
        for (int cnt1 = 1; cnt1 <= 8; cnt1++)
            for (int cnt2 = 1; cnt2 <= 8; cnt2++) {
                for (int sum1 = 1; sum1 <= 70; sum1++) {
                    for (int sum2 = 1; sum2 <= 70; sum2++) {
                        if (sum1 > sum2)
                            dWin[cnt1][cnt2] += dSum[cnt1][sum1] * dSum[cnt2][sum2];
                    }
                }
            }
    }

    double canWin(int k1, int k2) {
        return dWin[k1][k2];
    }

    public void init() {
        initWin();

        //debug(canWin(3, 2));

        //throw new UnsupportedOperationException("Not supported yet.");
    }

    public Flag chooseFlag(World arg0, Set<Flag> can) {
        //throw new UnsupportedOperationException("Not supported yet.");
        Graph g = new Graph(arg0);

        int maxV = 0, move = -1;
        double prob = 0.0;
        Flag ans = null;

        for (Flag i : can) {
            g.calcDinamics(i, 10, true);
            if(g.maxVFromDinamic > maxV || ((g.maxVFromDinamic == maxV && g.movesFromDinamic < move) ||
               (g.movesFromDinamic == move && g.probFromDinamic > prob))){

                maxV = g.maxVFromDinamic;
                move = g.movesFromDinamic;
                ans = i;
                prob = g.probFromDinamic;

            }
        }

        return ans;
    }

    Land getLand(World now, int id) {


        for (Land L : now.getLands()) {
            if (L.getLandId() == id)
                return L;
        }
        assert (false);
        return null;
    }

    public void opponentAttack(Flag arg0, Attack arg1, World arg2, boolean arg3) {
        //throw new UnsupportedOperationException("Not supported yet.");
        //debug(getMinDist(getLand(arg2, arg1.getFromLandId()), getLand(arg2, arg1.getFromLandId()), arg2, false));
    }

    private class MyAttack implements Attack {

        int from, to;

        MyAttack(int from, int to) {
            this.from = from;
            this.to = to;
        }

        public int getFromLandId() {
            //throw new UnsupportedOperationException("Not supported yet.");
            return from;
        }

        public int getToLandId() {
            //throw new UnsupportedOperationException("Not supported yet.");
            return to;
        }

    }

    ArrayList<Land> getEnemy(Land cur, Flag fl) {
        Set<Land> n = cur.getNeighbouringLands();
        ArrayList<Land> ans = new ArrayList<Land>();
        for (Land c : n) {
            if (!c.getFlag().equals(fl))
                ans.add(c);
        }
        return ans;
    }


    public Attack attack(World now) {
        //throw new UnsupportedOperationException("Not supported yet.");
        Graph g;
        g = new Graph(now);
        Set<Land> cur = now.getLands();
        Flag my = now.getMyFlag();

        MyAttack ttt = g.calcDinamics(my, Math.max(MINPREDICT, now.getAvailableAttackCount()), false);

        return ttt;
    }

}
