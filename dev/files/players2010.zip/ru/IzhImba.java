package ru;

import java.util.List;
import java.io.File;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class IzhImba implements Player{

	public boolean loaded;
	final int EW_ITER = 10;
	final int MAX_DEPTH = 4;
	final int PREC_ITER = 100000;
	final int INF = 1000000000;
	final int STO_PICOT = 10000;
	
	public class MyLand {
		public int old_id;
		public int armyCount;
		public int flag_id;
		
		MyLand( final Land land )
		{
			old_id = land.getLandId();
			armyCount = land.getDiceCount();
			flag_id = land.getFlag().ordinal();
		}
	}
	
	public class MyWorld {
		public int n;
		public MyLand lands[];
		public Map<Integer, Integer> landId;
		public int v[][];
		public int your_id;
		public int attack_count;
		public int reserve;
		public int all_flags[];
		
		MyWorld( World w )
		{
			Set<Land> ls = w.getLands();
			landId = new HashMap<Integer, Integer>( );
			n = ls.size();
			lands = new MyLand[n];
			v = new int[n][];
			int i = 0;
			for (final Land land : ls) {
				lands[i] = new MyLand( land );
				landId.put( land.getLandId(), i);
				++ i;
			}	
			for (final Land land : ls) {
				int id = landId.get(land.getLandId());
				Set<Land> ng = land.getNeighbouringLands();
				v[id] = new int[ng.size()];
				i = 0;
				for ( final Land ngl : ng)
				{
					v[id][i] = landId.get(ngl.getLandId());
					++ i;
				}
			}	
			List<Flag> wf = w.getFlags();
			all_flags = new int[wf.size()];
			i = 0;
			for ( Flag f : wf )
			{
				all_flags[i] = f.ordinal();
				++ i;
			}

			if ( loaded )
			{
				your_id = w.getMyFlag().ordinal();
				attack_count = w.getAvailableAttackCount();
				reserve = w.getDiceCountInReserve( w.getMyFlag() );
			}
			else
			{
				your_id = -1;
				attack_count = 0;
				reserve = 0;
			}
		}

		MyWorld( MyWorld w )
		{
			landId = w.landId;
			lands = w.lands.clone();
			n = w.n;
			v = w.v;
			attack_count = w.attack_count;
			reserve = w.reserve;
			your_id = w.your_id;
			all_flags = w.all_flags;
		}
	
	}	
	
	double win_chances[][];
	
	private void precalc( )
	{
		win_chances = new double[9][9];
		int a, b, k;
		for ( a = 0; a < 9; ++ a )
		{
			for ( b = 0; b < 9; ++ b )
			{
				int cnt = 0;
				for ( k = 0; k < PREC_ITER; ++ k )
				{
					if ( (int)( Math.random() * a * 6 ) + a > 
						(int)( Math.random() * b * 6 ) + b )
					{
						++ cnt;
					}
				}
				win_chances[a][b] = (double)cnt / PREC_ITER;
			}
		}
		
	}
	
	@Override
	public void init(){
		loaded = false;
		precalc( );
	}
	
	@Override
	public String getName() {
		return "Izhevsk: Tantum Repus";
	}
	
	int d[][];
	
	private void precalc_dist( MyWorld w )
	{
		d = new int[w.n][w.n];
		int i;
		for ( i = 0; i < w.n; ++ i )
		{
			Arrays.fill( d[i], INF );
			Queue<Integer> q = new LinkedList<Integer>();
			d[i][i] = 0;
			q.add(i);
			while ( !q.isEmpty() )
			{
				int j, id = q.poll();
				int nd = d[i][id] + 1;
				for ( j = 0; j < w.v[id].length; ++ j )
				{
					int nid = w.v[id][j];
					if ( d[i][nid] > nd )
					{
						d[i][nid] = nd;
						q.add( nid );
					}
				}
			}		
		}
	}
	
	@Override
	public Flag chooseFlag(World world, Set<Flag> af) {
		MyWorld w = new MyWorld( world );
		precalc_dist( w );
		double res = 0;
		int fl = -110000;
		Flag flag = af.iterator().next();
		for ( final Flag f : af )
		{
			int fid = f.ordinal();
			w.your_id = fid;
			double cur = getStartPoints( w );
			if ( fl < -10000 || res < cur )
			{
				flag = f;
				fl = fid;
				res = cur;
			}
		}
		return flag;
	}
	
	@Override
	public void opponentAttack(Flag opponentFlag, Attack attack, World beforeWorld, boolean wasAttackWon) {
	}

	private int GetArmyCount( int flag, MyWorld w )
	{
		int i;
		int res = 0;
		for ( i = 0; i < w.n; ++ i ) {
			if ( w.lands[i].flag_id == flag  )
			{
				res += w.lands[i].armyCount;
			}
		}
		return res;
	}
	
	private int GetLandCount( int flag, MyWorld w )
	{
		int i;
		int res = 0;
		for ( i = 0; i < w.n; ++ i ) {
			if ( w.lands[i].flag_id == flag  )
			{
				res += 1;
			}
		}
		return res;
	}
	
	private int GetMaxComponent( int flag, MyWorld w )
	{
		int visited[] = new int[w.n];
		int i, c = 0;
		int res = 0;
		for ( i = 0; i < w.n; ++ i ) {
			if ( visited[i] == 0 && w.lands[i].flag_id == flag  )
			{
				++ c;
				int cnt = 0;
				Queue<Integer> q = new LinkedList<Integer>();
				visited[i] = c;
				q.add(i);
				++ cnt;
				while ( !q.isEmpty() )
				{
					int j, id = q.poll();
					for ( j = 0; j < w.v[id].length; ++ j )
					{
						int nid = w.v[id][j];
						if ( w.lands[nid].flag_id == flag && visited[nid] == 0 )
						{
							visited[nid] = c;
							q.add( nid );
							++ cnt;
						}
					}
				}		
				if ( res < cnt )
				{
					res = cnt;
				}
			}
		}
		return res;
	}
	
	private MyWorld endTurnWorld( MyWorld w, int addDices )
	{
		MyWorld res = new MyWorld( w );
		int i, j, n;
		res.reserve = 0;
		for ( j = 0; j < addDices; ++ j )
		{
			n = 0;
			for ( i = 0; i < res.n; ++ i )
				if ( res.lands[i].flag_id == res.your_id && res.lands[i].armyCount < 8 )
					++ n;
			if ( n == 0 )
			{
				res.reserve = addDices - j;
				break;
			}
			int id = (int)( Math.random( ) * n );
			if ( id == n )
				-- id;
			for ( i = 0; i < res.n; ++ i )
				if ( res.lands[i].flag_id == res.your_id && res.lands[i].armyCount < 8 )
				{
					if ( id -- == 0 )
					{
						++ res.lands[i].armyCount;
						break;
					}
				}
		}
		if ( res.reserve > 100 )
			res.reserve = 100;
			
		return res;
	}
	
	private int GetMinTree( int fid, MyWorld w )
	{
		int visited[] = new int[w.n];
		int comps[][] = new int[w.n][w.n];
		int cn[] = new int[w.n];
		int i, c = 0;
		int res = 0;
		int tc = 0;
		//precalc components;
		for ( i = 0; i < w.n; ++ i ) {
			if ( visited[i] == 0 && w.lands[i].flag_id == fid  )
			{
				++ c;
				int cnt = 0;
				Queue<Integer> q = new LinkedList<Integer>();
				visited[i] = c;
				q.add(i);
				comps[c - 1][cnt] = i;
				++ cnt;
				++ tc;
				while ( !q.isEmpty() )
				{
					int j, id = q.poll();
					for ( j = 0; j < w.v[id].length; ++ j )
					{
						int nid = w.v[id][j];
						if ( w.lands[nid].flag_id == fid && visited[nid] == 0 )
						{
							visited[nid] = c;
							q.add( nid );
							comps[c - 1][cnt] = nid;
							++ cnt;
							++ tc;
						}
					}
				}		
				cn[c - 1] = cnt;
			}
		}
		//calc edges
		int v[][];
		if ( c == 1 )
			return 0;
		int j;
		v = new int[c][c];
		for ( i = 0; i < c; ++ i )
		{
			for ( j = 0; j < i; ++ j )
			{
				v[i][j] = INF;
				int a, b;
				for ( a = 0; a < cn[i]; ++ a )
				{
					for ( b = 0; b < cn[j]; ++ b )
					{
						v[i][j] = Math.min( v[i][j], d[comps[i][a]][comps[j][b]] );
					}
				}
				v[j][i] = v[i][j];
			}
		}
		//building tree
		boolean was[] = new boolean[c];
		was[0] = true;
		int sum = 0;
		for ( i = 1; i < c; ++ i )
		{
			int mv = INF;
			int b = -1;
			if ( was[i] )
			{
				for ( j = 0; j < c; ++ j )
				{
					if ( !was[j] && v[i][j] < mv )
					{
						mv = v[i][j];
						b = j;
					}
				}
			}
			if ( b < 0 )
				break;
			sum += mv;
			was[b] = true;
		}
		return sum;
	}
	
	private int getBorder( int fid, MyWorld w )
	{
		int res = 0;
		int i, j;
		boolean v[] = new boolean[w.n];
		for ( i = 0; i < w.n; ++ i )
		{
			if ( w.lands[i].flag_id == fid )
			{
				for ( j = 0; j < w.v[i].length; ++ j )
				{
					if ( w.lands[w.v[i][j]].flag_id != fid )
					{
						if ( !v[w.v[i][j]] )
						{
							v[w.v[i][j]] = true;				
							++ res;
						}
					}
				}
			}
		}
		return res;
	}

	private int getBorderArmy( int fid, MyWorld w )
	{
		int res = 0;
		int i, j;
		boolean v[] = new boolean[w.n];
		for ( i = 0; i < w.n; ++ i )
		{
			if ( w.lands[i].flag_id == fid )
			{
				for ( j = 0; j < w.v[i].length; ++ j )
				{
					if ( w.lands[w.v[i][j]].flag_id != fid )
					{
						if ( !v[i] )
						{
							v[i] = true;				
							res += w.lands[i].armyCount;
						}
					}
				}
			}
		}
		return res;
	}

	
	private int getSuperConnectivity( int fid, MyWorld w ) 
	{
		int res = 0;
		int i, j;
		for ( i = 0; i < w.n; ++ i )
		{
			if ( w.lands[i].flag_id == fid )
			{
				for ( j = 0; j < w.v[i].length; ++ j )
				{
					if ( w.lands[w.v[i][j]].flag_id == fid )
					{
						++ res;						
					}
				}
			}
		}
		return res;
	}
	
	private int GetComponentCount( int flag, MyWorld w )
	{
		int visited[] = new int[w.n];
		int i, c = 0;
		int res = 0;
		for ( i = 0; i < w.n; ++ i ) {
			if ( visited[i] == 0 && w.lands[i].flag_id == flag  )
			{
				++ c;
				int cnt = 0;
				Queue<Integer> q = new LinkedList<Integer>();
				visited[i] = c;
				q.add(i);
				++ cnt;
				while ( !q.isEmpty() )
				{
					int j, id = q.poll();
					for ( j = 0; j < w.v[id].length; ++ j )
					{
						int nid = w.v[id][j];
						if ( w.lands[nid].flag_id == flag && visited[nid] == 0 )
						{
							visited[nid] = c;
							q.add( nid );
							++ cnt;
						}
					}
				}		
			}
		}
		return c;				
	}
	
	private double getYourPoints( MyWorld w )
	{
		double res = 0;
		int visited[] = new int[w.n];
		int comps[][] = new int[w.n][w.n];
		int cn[] = new int[w.n];
		int i, c = 0;
		int tc = 0;
		for ( i = 0; i < w.n; ++ i ) {
			if ( visited[i] == 0 && w.lands[i].flag_id == w.your_id  )
			{
				++ c;
				int cnt = 0;
				Queue<Integer> q = new LinkedList<Integer>();
				visited[i] = c;
				q.add(i);
				comps[c - 1][cnt] = i;
				++ cnt;
				++ tc;
				while ( !q.isEmpty() )
				{
					int j, id = q.poll();
					for ( j = 0; j < w.v[id].length; ++ j )
					{
						int nid = w.v[id][j];
						if ( w.lands[nid].flag_id == w.your_id && visited[nid] == 0 )
						{
							visited[nid] = c;
							q.add( nid );
							comps[c - 1][cnt] = nid;
							++ cnt;
							++ tc;
						}
					}
				}		
				cn[c - 1] = cnt;
			}
		}
		int j, ma = 0, ci = -1;
		for ( i = 0; i < c; ++ i )
		{
			int ca = 0;
			for ( j = 0; j < cn[i]; ++ j )
			{
				ca += w.lands[comps[i][j]].armyCount;
			}
			if ( ca > ma )
			{
				ci = i;
				ma = ca;
			}
		}
		int sa = 0;
		for ( i = 0; i < cn[ci]; ++ i )
		{
			for ( j = 0; j < w.v[comps[ci][i]].length; ++ j )
			{
				if ( visited[w.v[comps[ci][i]][j]] == ci )
					++ sa;
			}
		}
		res = cn[ci] + (double)sa / cn[ci] - getBorder( w.your_id, w ) * 0.1;
		return res;		
	}
	
	private double getStartPoints( MyWorld w )
	{
		double res = 0;
		int visited[] = new int[w.n];
		int comps[][] = new int[w.n][w.n];
		int cn[] = new int[w.n];
		int i, c = 0;
		int tc = 0;
		for ( i = 0; i < w.n; ++ i ) {
			if ( visited[i] == 0 && w.lands[i].flag_id == w.your_id  )
			{
				++ c;
				int cnt = 0;
				Queue<Integer> q = new LinkedList<Integer>();
				visited[i] = c;
				q.add(i);
				comps[c - 1][cnt] = i;
				++ cnt;
				++ tc;
				while ( !q.isEmpty() )
				{
					int j, id = q.poll();
					for ( j = 0; j < w.v[id].length; ++ j )
					{
						int nid = w.v[id][j];
						if ( w.lands[nid].flag_id == w.your_id && visited[nid] == 0 )
						{
							visited[nid] = c;
							q.add( nid );
							comps[c - 1][cnt] = nid;
							++ cnt;
							++ tc;
						}
					}
				}		
				cn[c - 1] = cnt;
			}
		}
		int mcnt = 0;
		int j, ma = 0, ci = -1;
		for ( i = 0; i < c; ++ i )
		{
			int ca = 0;
			int cnt = 0;
			for ( j = 0; j < cn[i]; ++ j )
			{
				++ cnt;
				ca += w.lands[comps[i][j]].armyCount;
			}
			if ( ca > ma )
			{
				mcnt = cnt;
				ci = i;
				ma = ca;
			}
		}
		res = getBorderArmy( w.your_id, w ) * 0.2 + ma * mcnt - getBorder( w.your_id, w ) * 0.1;
		return res;
	}

	private double getSafeInnerSpace( int fid, MyWorld w )
	{
		int i, j;
		int res = 0;
		for ( i = 0; i < w.n; ++ i )
			if ( w.lands[i].flag_id == fid  )
			{
				for ( j = 0; j < w.v[i].length; ++ j )
				{
					if ( w.lands[w.v[i][j]].flag_id != fid )
						break;				
				}
				if ( j == w.v[i].length )
					++ res;
			}
			
		return res;
	}
	
	private double getPoints( MyWorld w )
	{
		double res = 0;
		int i;
		if ( w.all_flags.length == 2 )
		{
			int enemy_id = 0;
			for ( i = 0; i < w.all_flags.length; ++ i )
			{
				int fid = w.all_flags[i];
				if ( fid != w.your_id )
				{
					enemy_id = fid;
				}
			}
			int your_lc = GetLandCount( w.your_id, w);
			int enemy_lc = GetLandCount( enemy_id, w);
//			if ( your_lc > enemy_lc * 2 )
			{
				if ( enemy_lc == 0 )
					return INF;
				return ( getBorderArmy( w.your_id, w) * 0.1 + GetMaxComponent(w.your_id, w) +  your_lc ) / (double) enemy_lc;
			}
/*			else
			{
//					res += getYourPoints( w );
				int mc = GetMaxComponent( w.your_id, w );
				res +=  ( mc / (double)your_lc * 3 + 1 - getBorder(w.your_id, w) / (double)your_lc * 0.25 +
					getSuperConnectivity( w.your_id, w ) / (double)your_lc + GetArmyCount(w.your_id, w) * 0.1 / (double)your_lc ) * your_lc -
					GetMinTree( w.your_id, w ) * (double)GetComponentCount( w.your_id, w ) * 0.25;
				res -= enemy_lc + GetArmyCount(enemy_id, w) * 0.05;
			}
*/		}
		else
		{
			for ( i = 0; i < w.all_flags.length; ++ i )
			{
				int fid = w.all_flags[i];
				int lc = GetLandCount(fid, w);
				if ( fid == w.your_id )
				{
//					res += getYourPoints( w );
					int mc = GetMaxComponent( fid, w );
					res += STO_PICOT + ( mc / (double)lc * 5 + 1 + getSafeInnerSpace(fid, w) * 10 / (double)lc +
						getSuperConnectivity( fid, w ) / (double)lc + getBorderArmy(fid, w) * 0.1 / (double)lc ) * lc -
						GetMinTree( fid, w ) * (double)GetComponentCount( fid, w ) * 0.03;
				}
				else
				{
					if ( lc == 0 )
					{
						if ( w.reserve > 10 )
							res += INF;
						else
						if ( GetMaxComponent( w.your_id, w ) > 15 )
							res += 10;                 
								
					}
					else
						res -= ( lc + GetArmyCount(fid, w) * 0.1 ) * ( 1. / ( w.all_flags.length - 1 ) );
				}
			}
		}
		return res;
	}
	
	private double getEndWorldPoints( MyWorld w )
	{
/*		if ( w.attack_count == 0 )
		{
			double res = 0;
			int cnt = w.reserve + GetMaxComponent( w.your_id, w );
			for ( int i = 0; i < EW_ITER; ++ i )
			{
				res += getPoints( endTurnWorld( w, cnt ) );			
			}
			return res / EW_ITER;
		}
*/		return getPoints( w );
	}

	private int bestAttackFrom;
	private int bestAttackTo;
	private double bestAttackPoint;
	
	private double getWinChance( int a, int b )
	{
		return win_chances[a][b];
	}

	private double brute( MyWorld w, int id, int depth, int m_depth )
	{
		double cur = getEndWorldPoints( w );
		if ( depth >= m_depth )
			return cur;
		MyWorld mw = new MyWorld( w );
		int st = w.lands[id].armyCount;
		mw.lands[id].armyCount = 1;
		double lose_point = getEndWorldPoints( mw );
		int i, nid;
		for ( i = 0; i < w.v[id].length; ++ i )
		{
			nid = w.v[id][i];			
			if ( w.lands[nid].flag_id != w.your_id )
			{
				int old_fl = mw.lands[nid].flag_id;
				int old_arm = mw.lands[nid].armyCount;
				double win_chance = getWinChance( st, old_arm );
				
				mw.lands[nid].flag_id = w.your_id;
				mw.lands[nid].armyCount = st - 1;
				-- mw.attack_count;
				double ncur = lose_point * ( 1. - win_chance ) + win_chance * brute( mw, nid, depth + 1, m_depth );
				if ( ncur > cur )
				{
					cur = ncur;
					if ( depth == 0 && bestAttackPoint < cur )
					{
						bestAttackPoint = cur;
						bestAttackFrom = id;
						bestAttackTo = nid;
					}
				}
				++ mw.attack_count;
				mw.lands[nid].flag_id = old_fl;
				mw.lands[nid].armyCount = old_arm;
			}
		}
		return cur;
	}
	
	private void myassert( boolean a )
	{
		int i, j;
		while ( !a )
		{
			i = 1;
			j = 2;
			i += j;
			if ( i == 2 )
				break;
		}
	}
	
	@Override
	public Attack attack(World world) {
		loaded = true;
		int i = 1, j = 2;
		MyWorld w = new MyWorld( world );
		bestAttackFrom = -1;
		bestAttackTo = -1;
		bestAttackPoint = getEndWorldPoints( w );
		for ( i = 0; i < w.n; ++ i )
		{
			if ( w.lands[i].flag_id == w.your_id && w.lands[i].armyCount > 1 )
			{
				int m_depth = Math.min( MAX_DEPTH, Math.min( w.attack_count, w.lands[i].armyCount - 1 ) );
				brute( w, i, 0, m_depth );
			}
		}
		if ( bestAttackFrom >= 0 )
		{
			final int bbestAttackFrom = w.lands[bestAttackFrom].old_id;
			final int bbestAttackTo = w.lands[bestAttackTo].old_id;
			return new Attack() {
				@Override
				public int getFromLandId() {
					return bbestAttackFrom;
				}

				@Override
				public int getToLandId() {
					return bbestAttackTo;
				}
			};
		}
		else
		{
			return null;
		}
	}

}
