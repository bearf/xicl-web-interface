package ru.icl.dicewars.mypack;

import java.util.Set;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;
import java.util.HashSet;
import java.util.Set;

public class Dolphin implements Player{
	public Flag bestFlag;
	public int icolor;
	public Set<Land> ourLands = new HashSet<Land>(200);
	public Set<Land> borderLands = new HashSet<Land>(200);
	public Set<Land> neighbouringLands = new HashSet<Land>(20);
	public Set<Land> behindStrongLands = new HashSet<Land>(20);	
	public Set<Land> iCanFUCKIt = new HashSet<Land>(20);
	public Set<Land> nebLands = new HashSet<Land>(20);
	public Set<Land> nICFI = new HashSet<Land>(20); 
	public Set<Land> iCFI = new HashSet<Land>(20); 
	public int turn=1;
	public int counter=0;
	public int bestOpponentId;
	public Land enemyLand,ourLand;
	public int deadspase;
	
	@Override
	public void init(){
	}
	
	@Override
	public String getName() {
		return "Dolphin";
	}
	
	@Override
	public Flag chooseFlag(World world, Set<Flag> availableFlags) {
		int counter[] = {0,0,0,0,0,0,0,0};
		Set<Land> lands = world.getLands();
		boolean free;
		
		for (final Land land : lands) {
			free=false;
			for (final Flag flag : availableFlags) {
				if (land.getFlag().equals(flag)) {
					free=true;
					break;
				}
			}
			if (free) {
				counter[land.getFlag().ordinal()]=counter[land.getFlag().ordinal()]+land.getDiceCount();
			}
		}
		
		int max=-1;
		for(int i = 0; i < counter.length; i++) {
			if (counter[i]>max) {
				max=counter[i];
				icolor=i;
			}
		}
		
		if (icolor==0) { bestFlag=Flag.RED; }
		else if (icolor==1) { bestFlag=Flag.GREEN; }
		else if (icolor==2) { bestFlag=Flag.BLUE; }
		else if (icolor==3) { bestFlag=Flag.ORANGE; }
		else if (icolor==4) { bestFlag=Flag.YELLOW; }
		else if (icolor==5) { bestFlag=Flag.CYAN; }
		else if (icolor==6) { bestFlag=Flag.MAGENTA; }
		else { bestFlag=Flag.GRAY; }
				
		return bestFlag;
	}
	
	@Override
	public void opponentAttack(Flag opponentFlag, Attack attack, World beforeWorld, boolean wasAttackWon) {
			
	}

	@Override
	public Attack attack(World world) {
		Set<Land> lands = world.getLands();
		
//		��������� ������ ������
		ourLands.clear();
		for (final Land land: lands) {
			if (land.getFlag().equals(bestFlag)) {
				ourLands.add(land);
			}
		}
		
				
//		��������� ��������� ������
		boolean inOurLands;			
		borderLands.clear();
		for (final Land borderLand: ourLands) {
			Set<Land> neighbouringLands = borderLand.getNeighbouringLands();
			for (final Land neighbouringLand : neighbouringLands) {
				inOurLands=false;
				for (final Land bLand: ourLands) {
					if (neighbouringLand==bLand) {
						inOurLands=true;
						break;
					}
				}
				if (!(inOurLands)) {
					borderLands.add(borderLand);
					break;
				}
			}	
		}
		
		deadspase=1;
		if ((ourLands.size() - borderLands.size())>2*borderLands.size()) { deadspase=2; }
		if ((ourLands.size() - borderLands.size())>4*borderLands.size()) { deadspase=4; }
		if ((ourLands.size() - borderLands.size())>5*borderLands.size()) { deadspase=3; }
		
//		���� ���� ����� � ����� ����������� � ���� ��������� �� ������� ����� �����, �� �������
		int enemiesCnt = 0; //���������� ������ � �����, ���� 1 �� �������
		boolean oneEnemy=false;
		for (final Land land : borderLands) {
			nebLands = land.getNeighbouringLands();
			enemiesCnt = 0;
			for (final Land nebLand : nebLands) {
				if (nebLand.getFlag()!=world.getMyFlag()) {
					enemiesCnt++;
					if (enemiesCnt==2) {
						break;
					}
					enemyLand=nebLand;
				}
			}
			if ((enemiesCnt==1)&&(land.getDiceCount()>=enemyLand.getDiceCount())&&(land.getDiceCount()>1)) {
				ourLand=land;
				oneEnemy=true;
				break;		
			}
		}
		
		if (oneEnemy) {
			return new Attack() {
				@Override
				public int getFromLandId() {
					return ourLand.getLandId();
				}
	
				@Override
				public int getToLandId() {
					return enemyLand.getLandId();
				}
			};		
		}
		else {

//		����� ���������� ����� ������		
		int maxDiceCount=0;
		Set<Land> ourStrongLands = new HashSet<Land>(100);
		Set<Land> strongEnemies = new HashSet<Land>(100);
		for (final Land land : borderLands) {
			if (land.getDiceCount()>maxDiceCount) {
				maxDiceCount=land.getDiceCount();
			}
		}
		maxDiceCount++;

		do {
			maxDiceCount--;
			if (maxDiceCount==1) { break; }
//			����� ������ � ������������� ������
			ourStrongLands.clear();			
			for (final Land land : borderLands) {			
				if (land.getDiceCount()==maxDiceCount) {
					ourStrongLands.add(land);	//���� ���������� �����
				}
			}
			if (ourStrongLands.isEmpty()) { continue; } 
			
			int sum,minsum;
			boolean flagAttack=true;
			for (final Land strongLand :ourStrongLands) {
		
//				������� ������ ������������� � ����� ������� �����
				neighbouringLands = strongLand.getNeighbouringLands();
				
				boolean failAttack=false;
				iCanFUCKIt.clear();
				behindStrongLands.clear();
				for (final Land neighbouringLand : neighbouringLands) {
					if ((neighbouringLand.getFlag()!=world.getMyFlag())&&(neighbouringLand.getDiceCount()<=strongLand.getDiceCount())) {
						iCanFUCKIt.add(neighbouringLand);
					}
					else
					{
						if (!borderLands.contains(neighbouringLand)) {
							behindStrongLands.add(neighbouringLand);
						}
					}
				}
				
				if (!behindStrongLands.isEmpty()) { 				
					for (final Land behindLand : behindStrongLands) {
						if ((behindLand.getDiceCount()==1)&&(strongLand.getDiceCount()<7)) {
							failAttack=true;
							break;
						}
					}
					if (failAttack) {
						failAttack = false; 
						continue; 
					}
				}
				
				neighbouringLands.clear();
				if (iCanFUCKIt.isEmpty()) { continue; } 
								
				minsum=9999;		
				for (final Land neighbouringLand : iCanFUCKIt) {				
					Set<Land> freshMeat = neighbouringLand.getNeighbouringLands();
					sum=0;
					for (final Land meat : freshMeat) {
						if (!(meat.getFlag()==world.getMyFlag())) {
							sum+=meat.getDiceCount();  
						}	
					}
					if (sum<minsum) {
						minsum=sum;
						bestOpponentId=neighbouringLand.getLandId();
					}
					freshMeat.clear();					
				}
							
				return new Attack() {
					@Override
					public int getFromLandId() {
						return strongLand.getLandId();
					}

					@Override
					public int getToLandId() {
						return bestOpponentId;
					}
				};	
			}
		} while ((maxDiceCount>1));
		}				
		return null;
	}
	
}