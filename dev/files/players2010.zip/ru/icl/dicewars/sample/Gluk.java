package ru.icl.dicewars.sample;

import java.util.*;
import java.lang.*;

import ru.icl.dicewars.client.*;

public class Gluk implements Player{
Flag myFlag;
Vector<Land> lland = new Vector<Land>(0);

@Override
public void init(){
lland.clear();
}

@Override
public String getName() {
return "Gluk (v 0.2)";
}

@Override
public Flag chooseFlag(World world, Set<Flag> availableFlags) {
myFlag = availableFlags.iterator().next();
int dice = calcLand(world,myFlag);
for(final Flag flag : availableFlags){
int d = calcLand(world,flag);
if(d > dice)
myFlag = flag;
}

return myFlag;
}

private int calcLand(World world,Flag flag){
Set<Land> lands = world.getLands();
int dice = 0, bad = 0;

for (final Land land : lands) {
if (land.getFlag().equals(flag) &&
land.getDiceCount() >= 3) {
dice+= land.getDiceCount();
}
if(land.getDiceCount() == 1)
bad++;
bad+=countEnemiesDices(land,flag);
}
return dice-bad;
}


@Override
public void opponentAttack(Flag opponentFlag, Attack attack,
World beforeWorld, boolean wasAttackWon) {
lland.clear();
}

@Override
public Attack attack(World world) {
myFlag = world.getMyFlag();

Land l = findMyLand(world,lland);

while(l!=null){
Attack atk = LandAction(l,world);
if(atk!=null)
return atk;
l = findMyLand(world,lland);
}

return null;
}

private Land findMyLand(World world,Vector<Land> lland){
Set<Land> lands = world.getLands();
Land taget = null;
int dice = 1;

for (final Land land : lands){
if (land.getFlag().equals(world.getMyFlag()) &&
land.getDiceCount() > dice &&
!lland.contains(land)) {
dice = land.getDiceCount();
taget = land;
}
}
lland.add(taget);
return taget;
}

private double landKoef(Land taget,Flag fl){

return taget.getDiceCount()
- countEnemiesDices(taget,fl)/(5)
+ NearLandCount(taget,myFlag);
}

private Attack LandAction(Land land,World world){
Set<Land> nearLands = land.getNeighbouringLands();
Land taget = null;
double dice = 0;//land.getDiceCount();

for (final Land nearLand : nearLands) {
if (!nearLand.getFlag().equals(world.getMyFlag()) &&
//AtkKoef(land,nearLand)>=0.6 &&
land.getDiceCount() > nearLand.getDiceCount() &&
dice < landKoef(nearLand,world.getMyFlag())) {
taget = nearLand;
dice = landKoef(taget,world.getMyFlag());
}
}
if(taget != null)
return genAtk(land,taget);else
return null;
}

private double AtkKoef(Land my,Land enem){
double k = 0.0;
if(enem.getDiceCount()>0)
k = 0.5*my.getDiceCount()/enem.getDiceCount();else
k = 1.0;
if(enem.getDiceCount()==1)
k = 1.0;
return k;
}

private int NearLandCount(Land land,Flag f){
int result = 0;
for(final Land nland : land.getNeighbouringLands()){
if(nland.getFlag().equals(f))
result++;
}
return result;
}

private double LandKoef(Land my,Land enem){
double max = 0.1;
Set<Land> nearLands = my.getNeighbouringLands();
for (final Land nearLand : nearLands) {
double akoef = AtkKoef(enem,nearLand);
if (!nearLand.getFlag().equals(myFlag) &&
akoef > max) {
max = akoef;
}
}
return max;
}

private int countEnemies(Land land){
return countEnemies(land,land.getFlag());
}

private int countEnemies(Land land,Flag fl2){
int result = 0;
Set<Land> nearLands = land.getNeighbouringLands();
Flag fl = land.getFlag();
for (final Land nearLand : nearLands) {
if(!nearLand.getFlag().equals(fl) &&
!nearLand.getFlag().equals(fl2)) {
result++;
}
}
return result;
}


private int countEnemiesDices(Land land,Flag fl2){
int result = 0;
Set<Land> nearLands = land.getNeighbouringLands();
Flag fl = land.getFlag();
for (final Land nearLand : nearLands) {
if(!nearLand.getFlag().equals(fl) &&
!nearLand.getFlag().equals(fl2)) {
result+=nearLand.getDiceCount();
}
}
return result;
}

private Attack genAtk(final Land mLand,
final Land eLand){
return new Attack() {
@Override
public int getFromLandId() {
return mLand.getLandId();
}

@Override
public int getToLandId() {
return eLand.getLandId();
}
};
}
}