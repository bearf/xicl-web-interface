package ru.icl.dicewars.sample;

import java.io.*;
import java.util.*;
import java.math.*;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class Plumbum implements Player
{
	int[][] g=new int[120][120];
	int[] lev=new int[120];
	int[] f=new int[120];
	int[] d=new int[120];
	int[] u=new int[120];
	int[] komp=new int[120];
	int[] color=new int[120];
	int[] ind=new int[120];
	int[] coldice=new int[120];
	Land[] cards=new Land[120];
	double[][] c=new double[10][120];
	int n,myflag,agrnland,agrdland,cols,maincol,move;

	double chancetowin(int x,int y)
	{
		if (x==1) return 0;
		double ans=0;
		for(int i=0;i<120;i++)
		for(int j=i+1;j<120;j++)
		ans+=c[x][j]*c[y][i];
		return ans;
	}

	int flagtoint(Flag flag)
	{
		if (flag==Flag.RED) return 0;
		if (flag==Flag.GREEN) return 1;
		if (flag==Flag.BLUE) return 2;
		if (flag==Flag.ORANGE) return 3;
		if (flag==Flag.YELLOW) return 4;
		if (flag==Flag.CYAN) return 5;
		if (flag==Flag.MAGENTA) return 6;
		return 7;
	}

	void dfs(int x,int col)
	{
		komp[x]=col;
		color[col]++;
		coldice[col]+=d[x];
		for(int i=1;i<n;i++)
		if (g[x][i]==1 && f[i]==myflag && komp[i]==0) dfs(i,col);
	}

	int max(int x,int y)
	{
		if (x>y) return x; return y;
	}

	void makegraph(World world)
	{
		for(int i=0;i<120;i++)
		for(int j=0;j<120;j++)
		g[i][j]=0;
		Set<Land> lands = world.getLands();
		for (final Land land : lands) 
		{
			cards[land.getLandId()]=land;
			f[land.getLandId()]=flagtoint(land.getFlag());
			d[land.getLandId()]=land.getDiceCount();
			Set<Land> neighbouringLands = land.getNeighbouringLands();
			for (final Land neighbouringLand : neighbouringLands) 
			{
				g[land.getLandId()][neighbouringLand.getLandId()]=1;
			}
		}
		n=lands.size()+1;
		for(int k=0;k<n;k++)
		for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
		if (g[i][k]>0 && g[k][j]>0)
		if (g[i][j]==0 || g[i][j]>g[i][k]+g[k][j]) g[i][j]=g[i][k]+g[k][j];
		cols=1;
		for(int i=0;i<120;i++)
		{
			komp[i]=0;
			color[i]=0;
			coldice[i]=0;
		}
		for(int i=1;i<n;i++)
		if (f[i]==myflag && komp[i]==0)
		{
			dfs(i,cols);
			cols++;
		}
		maincol=1;
		for(int i=2;i<cols;i++)
		{
			if (color[i]>color[maincol] || color[i]==color[maincol] && coldice[i]>coldice[maincol]) maincol=i;
		}
		for(int i=1;i<n;i++)
		{
			lev[i]=0;
			for(int j=1;j<n;j++)
			lev[i]=max(lev[i],g[i][j]*100);
			for(int j=1;j<n;j++)
			if (lev[i]/100==g[i][j]) lev[i]++;
		}
		for(int i=1;i<n;i++)
		ind[i]=i;
		for(int i=1;i<n-1;i++)
		for(int j=i+1;j<n;j++)
		if (lev[ind[i]]<lev[ind[j]]) 
		{
			int aaa=ind[i];
			ind[i]=ind[j];
			ind[j]=aaa;
		}
	}

	@Override
	public void init()
	{
		move=0;
		for(int i=0;i<10;i++)
		for(int j=0;j<120;j++)		
		c[i][j]=0;
		c[0][0]=1;
		for(int i=1;i<=8;i++)
		{
			for(int j=0;j<90;j++)        
			for(int q=1;q<=6;q++)
			c[i][j+q]+=c[i-1][j];
			double sum=0;
			for(int j=0;j<120;j++)                
			sum+=c[i][j];
			if (sum>0.5)
			for(int j=0;j<120;j++)                
			{
				c[i][j]/=sum;
			}
		}

	}
	
	@Override
	public String getName() 
	{
		return "���� ���";
	}
	
	@Override
	public Flag chooseFlag(World world, Set<Flag> availableFlags) 
	{
		myflag=0;
		makegraph(world);
		Flag bst=Flag.RED;
		int res=-1;
		for (final Flag flag : availableFlags) 
		for(int i=1;i<n;i++)
		{
			int now=0;
			if (f[ind[i]]==flagtoint(flag)) now=d[ind[i]]; else now=-d[ind[i]]/2;
			for(int j=1;j<n;j++)
			if (g[ind[i]][ind[j]]==1 && f[ind[j]]==flagtoint(flag))
			{
				now+=d[ind[j]];
			}
			if (now>res)
			{
				res=now;
				bst=flag;
			}
		}
		myflag=flagtoint(bst);
		return bst;
	}
	
	@Override
	public void opponentAttack(Flag opponentFlag, Attack attack, World beforeWorld, boolean wasAttackWon) 
	{
	}

	int blocked(int x)
	{
		int best=-1,res=0;
		for(int i=1;i<n;i++)
		if (f[ind[i]]==myflag && g[ind[i]][x]==1)
		{
			int q=0;
			for(int j=1;j<n;j++)
			if (g[ind[i]][ind[j]]==1 && f[ind[j]]!=myflag) q++;
			if (q==1)
			{
				if (d[ind[i]]>best)
				{
					best=d[ind[i]];
					res=ind[i];
				}
			}
		}
		return res;
	}

	boolean goblocked() 
	{
		for(int t=20;t>=1;t--)
		{
			int q,x=-1,y=-1,bl;
			for(int i=1;i<n;i++)
			if (f[ind[i]]!=myflag)
			{
				q=0;
				for(int j=1;j<n;j++)
				if (f[ind[j]]==myflag && g[ind[i]][ind[j]]==1 && komp[ind[j]]==maincol && d[ind[j]]>1) 
				{
					q++;
				}
				bl=blocked(ind[i]);				
				if (q==t && bl>0 && d[bl]>d[ind[i]])
				{
					boolean need=true;
					for(int j=1;j<n;j++)
					if (f[ind[j]]!=myflag && g[ind[i]][ind[j]]==1 && d[ind[j]]-1>=d[bl] && move>6)
					{
						need=false;
						break;
					}
					if (need)
					{
						agrnland=bl;
						agrdland=ind[i];
						return true;									
					}
				}
			}
		}
		for(int t=20;t>=1;t--)
		{
			int q,x=-1,y=-1,bl;
			for(int i=1;i<n;i++)
			if (f[ind[i]]!=myflag)
			{
				q=0;
				for(int j=1;j<n;j++)
				if (f[ind[j]]==myflag && g[ind[i]][ind[j]]==1 && komp[ind[j]]==maincol && d[ind[j]]>1) 
				{
					q++;
				}
				bl=blocked(ind[i]);				
				if (q==t && bl>0 && d[bl]>=d[ind[i]])
				{
					boolean need=true;
					for(int j=1;j<n;j++)
					if (f[ind[j]]!=myflag && g[ind[i]][ind[j]]==1 && d[ind[j]]-1>=d[bl] && move>8)
					{
						need=false;
						break;
					}
					if (need)
					{
						agrnland=bl;
						agrdland=ind[i];
						return true;									
					}
				}
			}
		}
		return false;
	}

	boolean unite(boolean unimain,double ch)
	{
		for(int i=1;i<n;i++)
		if (f[ind[i]]==myflag && ((komp[ind[i]]==maincol)==unimain))
		for(int j=1;j<n;j++)
		if (f[ind[j]]==myflag && komp[ind[j]]!=komp[ind[i]] && g[ind[i]][ind[j]]==2)
		for(int t=1;t<n;t++)
		if (f[ind[t]]!=myflag && g[ind[i]][ind[t]]==1 && g[ind[t]][ind[j]]==1)
		{
			int bl=blocked(ind[t]);
			if (bl>0 && chancetowin(d[bl],d[ind[t]])>ch)
			{
				agrnland=bl;
				agrdland=ind[t];
				return true;				
			}
			if (chancetowin(d[ind[i]],d[ind[t]])>ch)
			{
				agrnland=ind[i];
				agrdland=ind[t];
				return true;
			}
			if (chancetowin(d[ind[j]],d[ind[t]])>ch)
			{
				agrnland=ind[j];
				agrdland=ind[t];
				return true;
			}
		}
		return false;
	}

	boolean doit(int low)
	{
		if (goblocked()) return true;
		for(int t=20;t>=low;t--)
		{
			int q,bst=-1200000,now,x=-1,y=-1;
			for(int i=1;i<n;i++)
			if (f[ind[i]]!=myflag)
			{
				q=0;
				now=-1200000;
				for(int j=1;j<n;j++)
				if (f[ind[j]]==myflag && g[ind[i]][ind[j]]==1 && komp[ind[j]]==maincol) 
				{
					q++;
					if (d[ind[j]]-d[ind[i]]>0 && 10+(d[ind[j]]-d[ind[i]])>now)
					{
						now=10+(d[ind[j]]-d[ind[i]]);
						x=ind[j];
						y=ind[i];
					}
				}
				if (q==t && now>bst)
				{
					boolean need=true;
					for(int j=1;j<n;j++)
					if (f[ind[j]]!=myflag && g[ind[i]][ind[j]]==1 && d[ind[j]]-t>=d[x] && move>8)
					{
						need=false;
						break;
					}
					if (need)
					{
						bst=now;
						agrnland=x;
						agrdland=y;								
					}
				}
			}
			if (bst>-1200000)
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public Attack attack(World world) 
	{
		makegraph(world);

		move=max(move,world.getAvailableAttackCount());

		if (world.getAvailableAttackCount()>1)
		{
			if (goblocked())
			{
				return new Attack() 
				{
					@Override
					public int getFromLandId() 
					{
						return agrnland;
					}
					@Override
					public int getToLandId() 
					{
						return agrdland;
					}
				};
			}
		}

		if (unite(true,0.67))
		{
			return new Attack() 
			{
				@Override
				public int getFromLandId() 
				{
					return agrnland;
				}
				@Override
				public int getToLandId() 
				{
					return agrdland;
				}
			};
		}

		if (doit(2))
		{
			return new Attack() 
			{
				@Override
				public int getFromLandId() 
				{
					return agrnland;
				}
				@Override
				public int getToLandId() 
				{
					return agrdland;
				}
			};
		}

		if (unite(true,0.4))
		{
			return new Attack() 
			{
				@Override
				public int getFromLandId() 
				{
					return agrnland;
				}
				@Override
				public int getToLandId() 
				{
					return agrdland;
				}
			};
		}

		for(int i=1;i<n;i++)
		if (f[ind[i]]==myflag && komp[ind[i]]!=maincol && d[ind[i]]>=5)
		{
			for(int j=1;j<n;j++)
			if (f[ind[j]]!=myflag && d[ind[j]]<d[ind[i]] && g[ind[i]][ind[j]]==1)
			{
				for(int t=1;t<n;t++)
				if (f[ind[t]]==myflag && komp[ind[t]]==maincol && g[ind[j]][ind[t]]<g[ind[i]][ind[t]])
				{
					agrnland=ind[i];
					agrdland=ind[j];
					return new Attack() 
					{
						@Override
						public int getFromLandId() 
						{
							return agrnland;
						}
						@Override
						public int getToLandId() 
						{
							return agrdland;
						}
					};
				}
			}
		}

		for(int i=1;i<n;i++)
		if (f[ind[i]]==myflag && komp[ind[i]]!=maincol && d[ind[i]]>=7)
		{
			for(int j=1;j<n;j++)
			if (f[ind[j]]!=myflag && d[ind[j]]<d[ind[i]] && g[ind[i]][ind[j]]==1)
			{
				for(int t=1;t<n;t++)
				if (f[ind[t]]==myflag && komp[ind[t]]==maincol && g[ind[j]][ind[t]]<=g[ind[i]][ind[t]])
				{
					agrnland=ind[i];
					agrdland=ind[j];
					return new Attack() 
					{
						@Override
						public int getFromLandId() 
						{
							return agrnland;
						}
						@Override
						public int getToLandId() 
						{
							return agrdland;
						}
					};
				}
			}
		}

		for(int i=1;i<n;i++)
		if (f[ind[i]]==myflag && komp[ind[i]]==maincol && d[ind[i]]>1)
		{
			for(int j=1;j<n;j++)
			if (g[ind[i]][ind[j]]==1 && d[ind[j]]<d[ind[i]] && f[ind[j]]!=myflag)
			{
				boolean letsdo=true;
				for(int t=1;t<n;t++)
				if (g[ind[j]][ind[t]]==1 && f[ind[t]]!=myflag && d[ind[t]]-1>=d[ind[i]] && move>8) letsdo=false;
				if (letsdo)
				{
					agrnland=ind[i];
					agrdland=ind[j];
					return new Attack() 
					{
						@Override
						public int getFromLandId() 
						{
							return agrnland;
						}
						@Override
						public int getToLandId() 
						{
							return agrdland;
						}
					};					
				}
			}
		}

		if (unite(false,0.67))
		{
			return new Attack() 
			{
				@Override
				public int getFromLandId() 
				{
					return agrnland;
				}
				@Override
				public int getToLandId() 
				{
					return agrdland;
				}
			};
		}


		for(int i=1;i<n;i++)
		if (f[ind[i]]==myflag && d[ind[i]]==8)
		for(int j=1;j<n;j++)
		if (g[ind[i]][ind[j]]==1 && f[ind[j]]!=myflag)
		{
			agrnland=ind[i];
			agrdland=ind[j];
			return new Attack() 
			{
				@Override
				public int getFromLandId() 
				{
					return agrnland;
				}
				@Override
				public int getToLandId() 
				{
					return agrdland;
				}
			};				
		}	
		
		return null;		
	}
}
