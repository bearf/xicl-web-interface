package ru.icl.dicewars.sample;

import java.util.Set;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class maxDamage implements Player {

    private double[][] p;
    private boolean[] m, mt;
    private int n;
    private int[] diceCount;
    private Flag[] flags;
    private boolean graph[][];
    private int[][] dist;

    private void ReadGraph(World world) {

        graph = new boolean[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) graph[i][j] = false;
        }

        for (final Land land : world.getLands()) {
            Set<Land> nLands = land.getNeighbouringLands();
            for (final Land nland : nLands) {
                graph[land.getLandId()][nland.getLandId()] = true;
            }
        }

        dist = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) dist[i][j] = -1;
        }
        for (int i = 0; i < n; i++) {
            int[] q = new int[n];
            int[] d1=new int[n];
            for(int j=0;j<n;j++)d1[j]=-1;
            int qs = 0, qe = 1;
            q[0] = i;
            d1[i] = 0;
            while (qs != qe) {
                for (int j = 0; j < n; j++) {
                    if (graph[q[qs]][j]) {
                        if (d1[j] == -1) {
                            d1[j] = d1[q[qs]] + 1;
                            q[qe] = j;
                            qe++;
                        }
                    }
                }
                qs++;
            }
            for (int j = 0; j < n; j++) {
                dist[i][j] = d1[j];
            }
        }
    }

    private void ReadData(World world) {
        for (final Land land : world.getLands()) {
            flags[land.getLandId()] = land.getFlag();
            diceCount[land.getLandId()] = land.getDiceCount();
        }
    }

    private void dfs(int v, Flag curFlag) {
        if (mt[v]) return;
        mt[v] = true;
        for (int i = 0; i < n; i++) {
            if (graph[v][i] && flags[i]==curFlag) dfs(i,curFlag);
        }
    }

    private double CountryPower(Flag curFlag) {
        for (int i = 0; i < n; i++) m[i] = false;
        double vvp = -1.0;
        for (int i = 0; i < n; i++) {
            if (flags[i] == curFlag && !m[i]) {
                for (int j = 0; j < n; j++) mt[j] = false;
                dfs(i,curFlag);
                double vvp_cur = 0;
                for (int j = 0; j < n; j++) {
                    if (mt[j]) {
                        m[j] = true;
                        vvp_cur+=1.0;
                    }
                }
                if (vvp_cur > vvp) vvp = vvp_cur;
            }
        }
        if(vvp<0)
        {
            return -30;
        }
        double res = 0;
        final double c1 = 2.7, c2 = 1.3, c3 = -1.1;          
        for (int i = 0; i < n; i++) {
            if (curFlag == flags[i]) {
                res += c1 * diceCount[i];
                for (int j = 0; j < n; j++) {
                    if (i == j) continue;
                    if(!graph[i][j])continue;
                    if (flags[i] == flags[j]) {
                        res += c2 * diceCount[j];
                    } else {
                        res += c3 * diceCount[j];
                    }
                }
            }
        }
        res *= vvp;
        vvp = 0;
        for (int i = 0; i < n; i++) {
            if (flags[i] != curFlag) continue;
            for (int j = 0; j < n; j++) {
                if (flags[j] != curFlag) continue;
                vvp += dist[i][j];
            }
        }
        if(vvp<0.00001)vvp=1;
        res /= vvp;
        return res;
    }

    private static long[] getVariantCount(final int cubeCount) {
        long res[] = new long[49];
        int cubes[] = new int[cubeCount + 1];
        for (int i = 0; i < cubeCount; i++) cubes[i] = 1;
        do {
            int s = 0;
            for (int i = 0; i < cubeCount; i++) s += cubes[i];
            res[s]++;
            int i = 0;
            while (cubes[i] == 6) {
                cubes[i] = 1;
                i++;
            }
            if (i == cubeCount) break;
            cubes[i]++;
        } while (true);
        return res;
    }

    @Override
    public void init() {
        p = new double[9][9];
        long varCount[][] = new long[9][];
        for (int i = 1; i < 9; i++) {
            varCount[i] = getVariantCount(i);
        }
        for (int i = 1; i < 9; i++) {
            for (int j = 1; j < 9; j++) {
                long wins = 0, total = 0;
                for (int x = 1; x < 49; x++) {
                    for (int y = 1; y < 49; y++) {
                        total += varCount[i][x] * varCount[j][y];
                        if (x > y) wins += varCount[i][x] * varCount[j][y];
                    }
                }
                p[i][j] = (wins * 1.0d) / (total * 1.0d);
            }
        }
    }

    @Override
    public String getName() {
        return "EXbot";
    }

    @Override
    public Flag chooseFlag(World world, Set<Flag> availableFlags) {



        n = world.getLands().size() + 2;
        m = new boolean[n];
        mt = new boolean[n];
        flags = new Flag[n];
        diceCount = new int[n];
        graph = new boolean[n][n];

        ReadGraph(world);
        ReadData(world);


        Flag resFlag = null;
        double res = -1000000;
        for (Flag f:availableFlags) {
            double t = CountryPower(f);
            if (t > res) {
                res = t;
                resFlag = f;
            }
        }
        return resFlag;
    }

    private double max3(double a,double b,double c)
    {
        if(a>b)
        {
            if(a>c)return a;
            else return c;
        }
        else
        {
            if(b>c)return b;
            else return c;
        }
    }

    @Override
    public void opponentAttack(Flag opponentFlag, Attack attack, World beforeWorld, boolean wasAttackWon) {

    }

    @Override
    public Attack attack(World world) {
        Flag curFlag = world.getMyFlag();
        ReadData(world);

        double curPower = CountryPower(curFlag), resPower=-(8-world.getFlags().size())/6.0;
        boolean retNull = true;

        int id1=-1, id2=-1;
        boolean flagWrite=true;
        for (int i = 1; i < n; i++) {
            if (flags[i] != curFlag || diceCount[i] == 1) continue;
            for (int j = 1; j < n; j++) {
                if (i == j) continue;
                if (flags[j] == curFlag) continue;
                if (!graph[i][j]) continue;
                ReadData(world);
                int dice1 = diceCount[i], dice2 = diceCount[j];
                Flag flag1 = flags[j];
                double successMove=CountryPower(flag1);
                double firstPower=successMove;

                diceCount[j] = diceCount[i] - 1;
                diceCount[i] = 1;
                flags[j] = curFlag;
                successMove+=CountryPower(curFlag);
                successMove-=CountryPower(flag1);
                diceCount[j] = dice2;
                flags[j] = flag1;
                double unSuccessMove = CountryPower(curFlag)-CountryPower(flag1)+firstPower;
                double avg = successMove * p[dice1][dice2] + (1 - p[dice1][dice2]) * unSuccessMove;
                if(avg-curPower>resPower)
                {
                    resPower=avg-curPower;
                    retNull=false;
                    id1=i;
                    id2=j;
                }
            }
        }
        if (retNull) return null;
        final int res1=id1, res2=id2;

        return new Attack() {
            @Override
            public int getFromLandId() {
                return res1;
            }

            @Override
            public int getToLandId() {
                return res2;
            }
        };           
    }
}
