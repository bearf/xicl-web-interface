package ru.icl.dicewars.sample;

import java.util.Set;
import java.util.Vector;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class udsu implements Player{
	@Override
	public void init(){
		maxMoves = 0;
		nomoveCnt = 0;
	}
	
	@Override
	public String getName() {
		return "Udmurt SU bot";
	}
	
	@Override
	public Flag chooseFlag(World world, Set<Flag> availableFlags) {
		Flag bestFlag;
		int q;
		int maxq;
    	n = world.getLands().size();

    	flag = new int[n + 1];
		component = new int[n + 1];
		color = new int[n + 1];
		color2 = new boolean[n + 1];
		dices = new int[n + 1];        


		InitMatr(world);

		maxq = 0;
		bestFlag = availableFlags.iterator().next();
		for (final Flag flag : availableFlags) {
			q = Quality(world, flag);
			if (q > maxq) {
				maxq = q;
				bestFlag = flag;
			}
		}
		//System.out.println(bestFlag);
		return bestFlag;
	}
	
	@Override
	public void opponentAttack(Flag opponentFlag, Attack attack, World beforeWorld, boolean wasAttackWon) {
	}

	private int nomoveCnt;
	private int n;
	private int myFlag;
	private int[] flag;
	private boolean[][] matr;
	private int[] dices;
	private int[] component;
	private int moves;
	private int avrg;
	private int selComponent;
	private int maxMoves;
	private int extra;
	private int players;

	private int FlagToNum(Flag flag) {
		if (flag == Flag.RED) return 1;
        if (flag == Flag.GREEN) return 2;
        if (flag == Flag.BLUE) return 3;
        if (flag == Flag.ORANGE) return 4;
        if (flag == Flag.YELLOW) return 5;
        if (flag == Flag.CYAN) return 6;
        if (flag == Flag.MAGENTA) return 7;
        if (flag == Flag.GRAY) return 8;
        return -1;
	}

	private int Quality(World world, Flag flag) {
	    int res;
	    res = 0;
		Set<Land> lands = world.getLands();
		for (final Land land : lands) {
			if (land.getFlag() == flag) res += land.getDiceCount() * land.getDiceCount();
		}
		return res;
	}

	private void InitMatr(World world) {
		matr = new boolean[n + 1][n + 1];
		Set<Land> lands = world.getLands();
		for (final Land land : lands) {
			Set<Land> neighbouringLands = land.getNeighbouringLands();
			for (final Land neighbouringLand : neighbouringLands) {
				matr[land.getLandId()][neighbouringLand.getLandId()] = true;
			}
		}
		for (int j=1; j<=n; j++) {
			for (int i=1; i<=n; i++) {
//				System.out.print(matr[j][i] + " ");
			}
//			//System.out.println();
		}
	}

	private void Update(World world) {
		int i;
		int q;
   		myFlag = FlagToNum(world.getMyFlag());
		moves = world.getAvailableAttackCount();
		extra = world.getDiceCountInReserve(world.getMyFlag());
		Set<Land> lands = world.getLands();
		for (final Land land : lands) {
			flag[land.getLandId()] = FlagToNum(land.getFlag());
			dices[land.getLandId()] = land.getDiceCount();
		}
		CountComponents();

		int[] a = new int[n + 1];

		avrg = 0;
		q = 0;
		players = 0;
		for (i=1; i<=n; i++) {
			if (a[flag[i]] == 0) {
				a[flag[i]] = 1;
				players++;
			}
			if (flag[i] == myFlag) {
				q++;
				avrg += dices[i];
			}
		}
		avrg = (int)((double)avrg / (double)q + .5);
	}

	private int[] color;

	private void dfs(int x, int num) {
		int i;
		color[x] = num;
		for (i=1; i<=n; i++) {
			if (!matr[x][i]) continue;
			if (color[i] != 0) continue;
			if (flag[x] != flag[i]) continue;
			dfs(i, num);
		}
	}

	private void CountComponents() {
		int i;
		int k;
		k = 0;
		for (i=1; i<=n; i++) {
			color[i] = 0;
		}
		for (i=1; i<=n; i++) {
			if (color[i] != 0) continue;
			k++;
			dfs(i, k);
		}
		for (i=1; i<=n; i++) {
//			System.out.print(color[i] + " ");
			component[i] = color[i];
		}
//		//System.out.println();
	}

	boolean DontAttack() {
		if (moves != maxMoves || extra > 15) return false;
		int q[];
		q = new int[n + 1];
		int i;
		int myMax;
		int enemyMax;
		myMax = 0;
		enemyMax = 0;
		for (i=1; i<=n; i++) {
			q[component[i]]++;
			if (flag[i] == myFlag) {
				myMax = Math.max(myMax, q[component[i]]);
			} else {
				enemyMax = Math.max(enemyMax, q[component[i]]);
			}
		}
		////System.out.println(myMax + " " + enemyMax);
		if (myMax >= enemyMax + 3 && myMax > n / 3 && avrg <= 6) {
			//System.out.println("Don't Attack " + myMax + " " + enemyMax + " " + avrg);
			return true;
		}
		if (myMax > n / 2 && myMax >= enemyMax + 5 && avrg < 8) {
			//System.out.println("Don't Attack " + myMax + " " + enemyMax + " " + avrg);
			return true;
		}
		return false;
	}

	private boolean[] color2;

	private int Path(int a, int b, int k) {
		int i, j;
		int d, m;
		int move;
		int qx[] = new int[2*n + 1];
		int qd[] = new int[2*n + 1];
		int qm[] = new int[2*n + 1];
		int p[] = new int[n + 1];
		int c1, c2;
		int x;
		for (i=1; i<=n; i++) {
			color2[i] = false;
			p[i] = 0;
		}
		c1 = 0;
		c2 = 1;
		qx[0] = a;
		qd[0] = dices[a];
		qm[0] = moves;
		color2[a] = true;
		while (c1 != c2) {
			x = qx[c1];
			d = qd[c1];
			m = qm[c1];
			c1++;
			for (i=1; i<=n; i++) {
				if (!matr[x][i]) continue;

				if (i == b) {
					p[i] = x;
					continue;
				}

				if (d == 1 || m == 0) continue;

				if (flag[i] == myFlag) continue;				
				if (color2[i]) continue;
				if (dices[i] + k > d) continue;

				color2[i] = true;
				qx[c2] = i;
				qd[c2] = d - 1;
				qm[c2] = m - 1;
				p[i] = x;
				c2++;
			}
		}
		if (p[b] != 0) {
			x = b;
			while (p[x] != a) {
				x = p[x];
			}
			return x;
		}
//		move = dfs2(a, b, dices[a], moves, k);
		return 0;
	}

	private Attack Move(final int a, final int b) {
		return new Attack() {
			@Override
			public int getFromLandId() {
				return a;
			}
           	@Override
			public int getToLandId() {
				return b;
			}
		};
	}

	private Attack TryToConnect() {
		int i, j, k;
		int first;
		for (k=3; k>=1; k--) {
			for (i=1; i<=n; i++) {
				if (flag[i] != myFlag) continue;
				if (dices[i] == 1) continue;
				for (j=1; j<=n; j++) {
					if (i == j) continue;
					if (component[i] != selComponent && component[j] != selComponent) continue;
					if (flag[j] != myFlag) continue;
					if (component[i] == component[j]) continue;
					first = Path(i, j, k);
					if (first != 0) {
						//System.out.println("Connect " + i + " " + j);
						//System.out.println("Move " + i + " " + first);
						return Move(i, first);
					}
				}
			}
		}
		return null;
	}

	private void SelectComponent() {
		int q[];
		int p[];
		q = new int[n + 1];
		int i;
		int maxq;
		maxq = 0;
		for (i=1; i<=n; i++) {
			if (flag[i] != myFlag) continue;
			q[component[i]] += 2 + dices[i];
			if (q[component[i]] > maxq) {
			    maxq = q[component[i]];
			    selComponent = component[i];
			}
		}
	}

	private int MyNeighbours(int x) {
		int res;
		int i;
		res = 0;
		for (i=1; i<=n; i++) {
			if (matr[x][i] && flag[i] == myFlag) {
				res++;
			}
		}
		return res;
	}

	private int Q;

	private double Front() {
		int i, j;
		int res;
		int q;
		q = 0;
		res = 0;
		for (i=1; i<=n; i++) {
			for (j=1; j<=n; j++) {
				if (!matr[i][j]) continue;
				if (flag[i] == myFlag && flag[j] != myFlag) {
					res += (-4 + dices[i]);
					q++;
					break;
				}
			}
		}
		Q = q;
		return res;
	}

	private int ChangeFront(int p, int x) {
		int i, j;
		double res, res2;
		int q, q2;
		int v;
		boolean f;
		res = Front();
		res2 = 0;
		q = Q;
		q2 = 0;
		for (i=1; i<=n; i++) {
			v = 10;
			f = false;
			for (j=1; j<=n; j++) {
				if (!matr[i][j]) continue;
				if ((flag[i] == myFlag || i == x) && (flag[j] != myFlag && j != x)) {
					f = true;
					if (i == p) {
						if (dices[j] == 2) v = Math.min(v, -1);
						if (dices[j] == 3) v = Math.min(v, -2);
						if (dices[j] >= 4) v = Math.min(v, -4);
//						res2 += (-4);
					} else if (i == x) {
						if (dices[j] <= dices[i] - 2) v = Math.min(v, -3);
						if (dices[j] == dices[i] - 1) v = Math.min(v, -1);
						if (dices[j] == dices[i] + 1) v = Math.min(v, 2);
						if (dices[j] >= dices[i] + 2) v = Math.min(v, 3);
//						res2 += (-4 + (dices[p] - 1));
					} else {
//						res2 += (-4 + dices[i]);
					}
				}
			}
			if (v != 10) res2 += v;
			if (f) q2++;
		}
//		res = res2 - res;
		return (int)res2 + Math.max(0, 2 * (q - q2));
	}

	private int ChangeEnemyFront(int p, int x) {
		int i, j;
		double res, res2;
		res = 0;
		res2 = 0;

		for (j=1; j<=n; j++) {
			for (i=1; i<=n; i++) {
				if (!matr[i][j]) continue;
				if ((flag[i] == myFlag) && flag[j] != myFlag) {
					res += dices[j];
					break;
				}
			}
		}
		
		for (j=1; j<=n; j++) {
			for (i=1; i<=n; i++) {
				if (!matr[i][j]) continue;
				if ((flag[i] == myFlag || i == x) && (flag[j] != myFlag && j != x)) {
					res2 += dices[j];
					break;
				}
			}
		}
		return (int)(res2 - res);
//		return Math.max(0, (int)(res2 - res));
	}

	private int mostStrongEnemy() {
		int i;
		int[] q;
		int[] p;
		int maxq;
		int maxp;
		int enemyFlag;
		q = new int[n + 1];
		p = new int[n + 1];
		maxq = 0;
		maxp = 0;
		enemyFlag = -1;
		for (i=1; i<=n; i++) {
			if (flag[i] == myFlag) continue;
			q[component[i]]++;
			p[component[i]] += dices[i] * dices[i];
			if (q[component[i]] > maxq || q[component[i]] == maxq && p[component[i]] > maxp) {
				maxq = q[component[i]];
				maxp = p[component[i]];
				enemyFlag = flag[i];
			}
		}
		return enemyFlag;
	}

	private int mostStrongEnemyLands() {
		int i;
		int[] q;
		int[] p;
		int maxq;
		int maxp;
		q = new int[n + 1];
		p = new int[n + 1];
		maxq = 0;
		maxp = 0;
		for (i=1; i<=n; i++) {
			if (flag[i] == myFlag) continue;
			q[component[i]]++;
			p[component[i]] += dices[i] * dices[i];
			if (q[component[i]] > maxq || q[component[i]] == maxq && p[component[i]] > maxp) {
				maxq = q[component[i]];
				maxp = p[component[i]];
			}
		}
		return maxq;
	}

	private Attack OptimalAttack() {
		int i, j;
		int q;
		int maxq;
		int maxa, maxb;
		int mainEnemy;
		int border;
		int myMax;
		int enemyMax;
		boolean attackToMainEnemy;
		maxq = -100000;
		maxa = 0;
		maxb = 0;
		mainEnemy = mostStrongEnemy();
		enemyMax = mostStrongEnemyLands();

		myMax = 0;

		for (i=1; i<=n; i++) {
			if (component[i] == selComponent && flag[i] == myFlag) {
				myMax++;
			}
		}

		if (myMax >= n / 2 && avrg >= 6 || players == 2 && avrg >= 4 || nomoveCnt >= 2 || myMax <= 3) {
			border = -10000;
		} else if (players >= 4) {
			if (avrg >= 4) {
				border = -9;
			} else {
				border = -5;
			}
		} else if (players == 3) {
			if (avrg >= 7) {
				border = -10000;
			} else {
				if (myMax >= n / 3 || avrg >= 4) {
					border = -11;
				} else {
					border = -5;
				}
			}
		} else {
			border = -5;
		}

		for (i=1; i<=n; i++) {
			
			if (flag[i] != myFlag) continue;
			if (dices[i] == 1) continue;
			attackToMainEnemy = false;
			if (nomoveCnt == 1) {}
			else if (component[i] != selComponent && enemyMax >= myMax + 5) {attackToMainEnemy = true;}
			else if (component[i] != selComponent) continue;

			for (j=1; j<=n; j++) {
				
				if (flag[j] == myFlag) continue;
				if (!matr[i][j]) continue;
				if (dices[j] > dices[i]) continue;

				if (attackToMainEnemy && flag[j] != mainEnemy) continue;

//				q = 3 * MyNeighbours(j) + 2 * (dices[i] - dices[j]) - 4 * ChangeFront(i, j) / 3 - 5 * ChangeEnemyFront(i, j) / 3 - 4 * dices[i] / 3;
         		q = ChangeFront(i, j) - ChangeEnemyFront(i, j) - dices[i] / 2;
				if (flag[j] == mainEnemy) q += Math.min(maxMoves / 3, 7);
   				if (attackToMainEnemy) q += 4;
				else if (flag[j] == mainEnemy && enemyMax >= myMax + 4) {
					q += Math.min(4, enemyMax - myMax - 4);
				}
				if (dices[i] >= dices[j] + 1) q += 1;
				if (dices[i] >= dices[j] + 2) q += 2;
				if (dices[i] >= dices[j] + 3) q += 2;
				
				if (q > maxq || q == maxq && Math.random() > 0.5) {
					nomoveCnt = 0;
					maxq = q;
					maxa = i;
					maxb = j;
				}
			}
		}
		if (maxq >= border) {
			//System.out.println("Optimal move " + maxq + " (" + border + ")");
			//System.out.println("Move " + maxa + " " + maxb);
			//System.out.println("Change Front " + ChangeFront(maxa, maxb));
			//System.out.println("Change Enemy Front " + ChangeEnemyFront(maxa, maxb));
			return Move(maxa, maxb);
		} else {
			if (maxq != -100000) {
				//System.out.println("Best move " + maxa  + " " + maxb + " (" + maxq + ")");
				//System.out.println("Border " + border);
				//System.out.println("Change Front " + ChangeFront(maxa, maxb));
				//System.out.println("Change Enemy Front " + ChangeEnemyFront(maxa, maxb));
			}
			nomoveCnt++;
		}
		return null;
	}

	private Attack RandomMove() {
		int i, j, k;
		for (k=1; k<=10000; k++) {
			i = (int)(Math.random() * n) + 1;
			j = (int)(Math.random() * n) + 1;
			if (flag[i] != myFlag) continue;
			if (dices[i] == 1) continue;
			if (component[i] != selComponent) continue;
			if (flag[j] == myFlag) continue;
			if (!matr[i][j]) continue;
			if (dices[j] <= dices[i]) {
//				//System.out.println("Random Move");
//	    		//System.out.println("Move " + i + " " + j);
				return Move(i, j);
			}
		}
		return null;
	}

	@Override
	public Attack attack(World world) {
		Attack attack;
		Update(world);
		SelectComponent();
		if (moves > maxMoves) {
			//System.out.println();
			//System.out.println("Turn " + moves);
			maxMoves = moves;
		}
		if (DontAttack()) return null;
		attack = TryToConnect();
		if (attack != null) return attack;
		attack = OptimalAttack();
		if (attack != null) return attack;
//		return RandomMove();
		//System.out.println("Don't move");
		return null;
	}
}
