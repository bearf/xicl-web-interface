package ru.icl.dicewars.sample;

import java.util.*;
import java.math.*;
import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class AESCMSU implements Player{
	double percent[][] =new double[10][10];
	double dp[][] =new double[100][100];
	int xod=1;
	@Override
	public void init(){
		dp[0][0]=1;
		for (int i=1;i<=8;i++)
			for (int j=0;j<=50;j++)
				for (int k=1;k<=6;k++)
					dp[i][j+k]+=dp[i-1][j]/6;
		for (int i=1;i<=8;i++)
			for (int j=1;j<=8;j++){
				percent[i][j]=0;
				for (int k=1;k<=50;k++)
					for (int l=1;l<k;l++)
						percent[i][j]+=dp[i][k]*dp[j][l];
			}
	}
	
	@Override
	public String getName() {
		return "AESC MSU";
	}
	int[][] a=new int[300][300];
	public void calcDist(Set<Land> lands){
		for (int i=0;i<200;i++)
			for (int j=0;j<200;j++)
				if (i!=j) 
					a[i][j]=10000;
				else
					a[i][j]=0;
		for (final Land ln : lands){
			for (final Land ln2 : ln.getNeighbouringLands()){
				a[ln.getLandId()][ln2.getLandId()]=1;
			}
		}
		for (int k=0;k<200;k++)
			for (int i=0;i<200;i++)
				for (int j=0;j<200;j++)
					a[i][j]=Math.min(a[i][j],a[i][k]+a[k][j]);
	}
	public int getDist(Land ln,Land ln2){
		return a[ln.getLandId()][ln2.getLandId()];
	}
	@Override
	public Flag chooseFlag(World world, Set<Flag> avFlags) {
		Set<Land> lands=world.getLands();
		Set<Land> mnlands=new HashSet<Land>();
		int mnk=10000;
		for(final Land land : lands){
			mnk=Math.min(mnk,land.getNeighbouringLands().size());
		}
		for(final Land land : lands){
			if (mnk==Math.min(mnk,land.getNeighbouringLands().size())){
				mnlands.add(land);
			}
		}
		calcDist(lands);
		int mnd=100000;
		Flag mnf=null;
		for (final Flag fl : avFlags){
			int ff=10000;
			for (final Land ln :lands) 
				if (ln.getFlag()==fl)
					for (final Land ln2 : mnlands){
							ff=Math.min(ff,getDist(ln,ln2));
					}
			if (ff<mnd){
				mnd=ff;
				mnf=fl;
			}
		}
		return mnf;
	}
	int tt=0;
	boolean ttf=false;
	@Override
	public void opponentAttack(Flag opponentFlag, Attack attack, World beforeWorld, boolean wasAttackWon) {
		tt=0;
		if (ttf){
			ttf=false;
			xod++;
		}
	}

	@Override
	public Attack attack(World world) {
		Set<Land> lands = world.getLands();
		ttf=true;
		if (xod%3==1){
			int mxk=0;
		for (final Land land : lands) {
			if (land.getFlag().equals(world.getMyFlag()) ) {
				mxk=Math.max(mxk,land.getDiceCount());
			}
		}
		for (final Land land : lands) {
			if (land.getFlag().equals(world.getMyFlag()) && land.getDiceCount()>=mxk) {
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				int mnk=8;
				for (final Land neighbouringLand : neighbouringLands) 
					if (!neighbouringLand.getFlag().equals(world.getMyFlag())){
						mnk=Math.min(mnk,neighbouringLand.getDiceCount());
					}
				for (final Land neighbouringLand : neighbouringLands) {
					if (!neighbouringLand.getFlag().equals(world.getMyFlag()) && 
						neighbouringLand.getDiceCount()<=mnk) {
						if ((percent[mxk][mnk]>=0.3)&&(mxk>=5)){
							return new Attack() {
								@Override
								public int getFromLandId() {
									return land.getLandId();
								}
								@Override
								public int getToLandId() {
									return neighbouringLand.getLandId();
								}				
							};	
						}
					}
				}
			}
		}
		}
		double mxpr=0;
		for (final Land land : lands) {
			if (land.getFlag().equals(world.getMyFlag()) && land.getDiceCount()>=7) {
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				for (final Land neighbouringLand : neighbouringLands) {
					if (!neighbouringLand.getFlag().equals(world.getMyFlag()) && 
						percent[land.getDiceCount()][neighbouringLand.getDiceCount()]>=mxpr) {
						mxpr=percent[land.getDiceCount()][neighbouringLand.getDiceCount()];
					}
				}
			}
		}
		for (final Land land : lands) {
			if (land.getFlag().equals(world.getMyFlag()) && land.getDiceCount()>=7 ) {
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				for (final Land neighbouringLand : neighbouringLands) {
					if (!neighbouringLand.getFlag().equals(world.getMyFlag()) && 
						percent[land.getDiceCount()][neighbouringLand.getDiceCount()]>=mxpr) {
						if ((mxpr>=0.3)){
							tt++;
							return new Attack() {
								@Override
								public int getFromLandId() {
									return land.getLandId();
								}
								@Override
								public int getToLandId() {
									return neighbouringLand.getLandId();
								}				
							};	
						}
					}
				}
			}
		}
		return null;
	}
}
