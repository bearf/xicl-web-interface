package ru.icl.dicewars.sample;

import java.util.*;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class PermSU2Bot implements Player{

	Land[] getLand;
	int groupNum;
	int worldSize;
	int[] group;

	@Override
	public void init(){
	}

	void makeComponent (SimpleLand[] lands, int[] group, int s, int groupNum) {
		Queue<Integer> q = new LinkedList<Integer>();
		q.offer(s);
		Set<Land> neighbours = getLand[lands[s].id].getNeighbouringLands();
		for(Land curLand : neighbours) {
			if(group[curLand.getLandId()-1] == 0) {
				q.offer(curLand.getLandId()-1);
			}
		}
		while(!q.isEmpty()) {
			s = q.poll();
			if(group[s] != 0) continue;
			group[s] = groupNum;
			neighbours = getLand[lands[s].id].getNeighbouringLands();
			for(Land curLand : neighbours) {
				if(group[curLand.getLandId()-1] == 0 && lands[curLand.getLandId()-1].deg < lands[s].deg) {
					q.offer(curLand.getLandId()-1);
				}
			}
		}
	}

	private class SimpleLand implements Comparable<SimpleLand> {
		int id;
		int deg;
		public SimpleLand(int id, int degree) {this.id = id; deg = degree;}
		public int compareTo(SimpleLand sl) {
			if(this.deg < sl.deg) return 1;
			if(this.deg == sl.deg) return 0;
			return -1;
		}
	}

	@Override
	public String getName() {
		return "PermSU #2 Bot";
	}

	@Override
	public Flag chooseFlag(World world, Set<Flag> availableFlags) {
		worldSize = world.getLands().size();
		getLand = new Land[worldSize];
		Set<Land> worldLands = world.getLands();

		for(Land curLand : worldLands) {
			getLand[curLand.getLandId() - 1] = curLand;
		}

		group = new int[worldSize];
		SimpleLand[] lands = new SimpleLand[worldSize];
		int i = 0;
		for(Land curLand : worldLands) {
			lands[i++] = new SimpleLand(curLand.getLandId() - 1, curLand.getNeighbouringLands().size());
		}
		Arrays.sort(lands);

		groupNum = 1;
		for(i = 0; i < worldSize; i++) {
			if(group[i] == 0) makeComponent(lands, group, i, groupNum++);
		}

		FlagArmy[] flags = new FlagArmy[8];
		flags[0] = new FlagArmy(0, Flag.RED, 0, 0);
		flags[1] = new FlagArmy(1, Flag.GREEN, 0, 0);
		flags[2] = new FlagArmy(2, Flag.BLUE, 0, 0);
		flags[3] = new FlagArmy(3, Flag.ORANGE, 0, 0);
		flags[4] = new FlagArmy(4, Flag.YELLOW, 0, 0);
		flags[5] = new FlagArmy(5, Flag.CYAN, 0, 0);
		flags[6] = new FlagArmy(6, Flag.MAGENTA, 0, 0);
		flags[7] = new FlagArmy(7, Flag.GRAY, 0, 0);
		boolean[] used = new boolean[worldSize];
		for(Land land : world.getLands()) {
			if(used[land.getLandId() - 1]) continue;
			curMaxArmy = 0;
			LinkedList<Land> comp = new LinkedList<Land>();
			bfs(land.getLandId()-1, used, world, comp, land.getFlag());
			for(i = 0; i < 8; i++)
				if(flags[i].flag == land.getFlag()) {
					if(flags[i].maxComp <= comp.size()) {
						flags[i].maxComp = comp.size();
						flags[i].maxArmy = Math.max(flags[i].maxArmy, curMaxArmy);
					}
				}
		}
		Arrays.sort(flags);
		for(i = 0; i < 8; i++) {
			if(availableFlags.contains(flags[i].flag))
				return flags[i].flag;
		}
		return availableFlags.iterator().next();
	}

	class FlagArmy implements Comparable<FlagArmy> {
		int flagId;
		Flag flag;
		int maxComp;
		int maxArmy;

		public FlagArmy(int flagId, Flag flag, int maxComp, int maxArmy) {
			this.flagId = flagId;
			this.flag = flag;
			this.maxComp = maxComp;
			this.maxArmy = maxArmy;
		}

		public int compareTo(FlagArmy other) {
			if(this.maxComp > other.maxComp) return -1;
			if(this.maxComp < other.maxComp) return 1;
			if(this.maxArmy > other.maxArmy) return -1;
			return 1;
		}
	}

	@Override
	public void opponentAttack(Flag opponentFlag, Attack attack, World beforeWorld, boolean wasAttackWon) {
	}

	int curMaxArmy;

	void bfs(int id, boolean[] used, World world, LinkedList< Land > curComp, Flag flag) {
		used[id] = true;
		curComp.add(getLand[id]);
		Queue< Land > q = new LinkedList< Land >();
		q.offer(getLand[id]);
		while(!q.isEmpty()) {
		  Land land = q.poll();
		  if(land.getDiceCount() > curMaxArmy) curMaxArmy = land.getDiceCount();
		  for(Land neighbour : land.getNeighbouringLands()) {
			  if(!used[neighbour.getLandId() - 1] && neighbour.getFlag() == flag) {
				used[neighbour.getLandId() - 1] = true;
				curComp.add(neighbour);
				q.offer(neighbour);
			  }
		  }
		}
	}

	@Override
	public Attack attack(World world) {
		getLand = new Land[worldSize];
		Set<Land> worldLands = world.getLands();

		for(Land curLand : worldLands) {
			getLand[curLand.getLandId() - 1] = curLand;
		}

		LinkedList< LinkedList<Land> > components = new LinkedList< LinkedList<Land> >();
		LinkedList< Land > curComp = new LinkedList< Land >();
		boolean[] used = new boolean[worldSize];
		for(Land land : world.getLands()) {
			if(!used[land.getLandId() - 1] && land.getFlag() == world.getMyFlag()) {
				bfs(land.getLandId() - 1, used, world, curComp, world.getMyFlag());
				components.add(curComp);
				curComp = new LinkedList< Land >();
			}
		}
		int maxComp = 0;
		int maxTotalArmy = 0;
		int maxGreatArmy = 0;
		for(int i = 0; i < components.size(); i++) {
			int curTotalArmy = 0;
			int curGreatArmy = 0;
			for(Land land : components.get(i)) {
				if(land.getDiceCount() > curGreatArmy) curGreatArmy = land.getDiceCount();
				curTotalArmy += land.getDiceCount();
			}
			if(maxTotalArmy < curTotalArmy) {
				maxTotalArmy = curTotalArmy;
				maxGreatArmy = curGreatArmy;
				maxComp = i;
			}
			else if(maxTotalArmy == curTotalArmy && curGreatArmy > maxGreatArmy) {
				maxGreatArmy = curGreatArmy;
				maxComp = i;
			}
		}


		LinkedList< Land > sortedComp = components.get(maxComp);
		for(int i = 0; i < sortedComp.size(); i++)
			for(int j = i+1; j < sortedComp.size(); j++)
				if(sortedComp.get(i).getDiceCount() < sortedComp.get(j).getDiceCount()) {
					int tmp = sortedComp.get(i).getLandId()-1;
					sortedComp.set(i, sortedComp.get(j));
					sortedComp.set(j, getLand[tmp]);
				}

		for(int i = 0; i < sortedComp.size(); i++) {
			Set<Land> neighbours = sortedComp.get(i).getNeighbouringLands();
			LinkedList<Land> fromGroup = new LinkedList<Land>();
			//LinkedList<Land> others = new LinkedList<Land>();
			for(Land neighbour : neighbours) {
				if(group[neighbour.getLandId() - 1] == group[sortedComp.get(i).getLandId() - 1])
					fromGroup.add(neighbour);
			}
			for(Land land : fromGroup) {
				if(land.getFlag() != world.getMyFlag() && land.getDiceCount() < sortedComp.get(i).getDiceCount()) {
					final Land from = sortedComp.get(i);
					final Land to = land;
					return new Attack() {
						@Override
						public int getFromLandId() {
							return from.getLandId();
						}
						@Override
						public int getToLandId() {
							return to.getLandId();
						}
					};
				}
			}
		}

		for(int i = 0; i < sortedComp.size(); i++) {
			Set<Land> neighbours = sortedComp.get(i).getNeighbouringLands();
			//LinkedList<Land> fromGroup = new LinkedList<Land>();
			LinkedList<Land> others = new LinkedList<Land>();
			for(Land neighbour : neighbours) {
				if(group[neighbour.getLandId() - 1] != group[sortedComp.get(i).getLandId() - 1])
					others.add(neighbour);
			}
			for(Land land : others) {
				if(land.getFlag() != world.getMyFlag() && land.getDiceCount() < sortedComp.get(i).getDiceCount()) {
					final Land from = sortedComp.get(i);
					final Land to = land;
					return new Attack() {
						@Override
						public int getFromLandId() {
							return from.getLandId();
						}
						@Override
						public int getToLandId() {
							return to.getLandId();
						}
					};
				}
			}
		}

		LinkedList<SimpleLand> lands = new LinkedList<SimpleLand>();
		for(int i = 0; i < components.size(); i++) {
			for(Land land : components.get(i)) {
				lands.add(new SimpleLand(land.getLandId() - 1, land.getDiceCount()));
			}
		}
		Collections.sort(lands);
		for(SimpleLand simpleLand : lands) {
			final Land myLand = getLand[simpleLand.id];
			if(myLand.getFlag() == world.getMyFlag() && myLand.getDiceCount() > 1) {
				for(final Land neighbour : myLand.getNeighbouringLands()) {
					if(neighbour.getFlag() != world.getMyFlag() && neighbour.getDiceCount() <= myLand.getDiceCount())
						return new Attack() {
							@Override
							public int getFromLandId() {
								return myLand.getLandId();
							}
							@Override
							public int getToLandId() {
								return neighbour.getLandId();
							}
						};
				}
			}
		}

		return null;
	}
}
