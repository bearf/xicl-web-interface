package ru.icl.dicewars;

import java.util.*;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class NNSUBot2 implements Player {

	private double prop[][];
	
	private double table[][];
	private boolean was[][];
	
	private World world;
	
	int getbonus(Flag flag, World world) {
		int ans = 0;
		Set<Land> lands = world.getLands();
		for (Land land: lands) {
			if (land.getFlag().equals(flag))
				ans += (1 << land.getDiceCount()); 
		}
		
		return ans;
	}
	
	@Override
	public Flag chooseFlag(World arg0, Set<Flag> arg1) {
		Flag res = arg1.iterator().next();
		for (Flag flag: arg1) {
			if (getbonus(flag, arg0) > getbonus(res, arg0))
				res = flag;
		}
		
		return res;
	}

	@Override
	public String getName() {
		return "TopLamers";
	}
	
	double getans(int col, int sum) {
		if (sum < 0)
			return 0;

		if (col == 0) {
			if (sum > 0)
				return 0;
			else
				return 1;
		}
		
		if (was[col][sum])
			return table[col][sum];
		
		was[col][sum] = true;
		
		double ans = 0;
		
		for (int i = 1; i <= 6; i++)
			ans += getans(col - 1, sum - i);
		
		ans /= 6;
		table[col][sum] = ans;
			
		return ans;
	}

	private void calculateProps() {
		prop = new double[10][10];
		table = new double[10][100];
		was = new boolean[10][100];
	
		for (int i = 0; i < 10; i++)
			for (int j = 0; j < 100; j++)
				was[i][j] = false;
		
		for (int i = 1; i <= 8; i++)
			for (int j = 1; j <= 8; j++) {
				double ans = 0;
				for (int col1 = 1; col1 <= 48; col1++)
					for (int col2 = 1; col2 < col1; col2++)
						ans += getans(i, col1) * getans(j, col2);
				prop[i][j] = ans;
			}
	}
	
	@Override
	public void init() {
		calculateProps();
	}

	@Override
	public void opponentAttack(Flag arg0, Attack arg1, World arg2, boolean arg3) {
	}
	
	
	private Attack getAttack(final int ind1, final int ind2) {
		return new Attack() {
			@Override
			public int getFromLandId() {
				return ind1;
			}

			@Override
			public int getToLandId() {
				return ind2;
			}
		};		
	}
	
	private double p1 = 0.5, p2 = 0.75, p3 = 0.8;
	
	private Flag ourFlag;
	
	int getOpponentsCol(Land land) {
		int ans = 0;
		
		for (final Land tmp : land.getNeighbouringLands())
			if (tmp.getFlag().equals(ourFlag) == false)
				ans++;
		
		return ans;
	}
	
	private Attack attack22(World world) {
		Set<Land> lands = world.getLands();
		for (final Land land : lands) {
			if (land.getFlag().equals(world.getMyFlag()) && land.getDiceCount() == 2) {
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				for (final Land land2 : neighbouringLands) {
					if (!land2.getFlag().equals(world.getMyFlag())) {
						if (land2.getDiceCount() == 2)
							return getAttack(land.getLandId(), land2.getLandId());
					}
				}
			}
		}		
		return null; 
	}
	
	private int getOurCount(final Set<Land> lands) {
		int ans = 0;
		
		for (Land land: lands) {
			if (land.getFlag() == ourFlag)
				ans++;
		}
		
		return ans;
	}
	
	double res[] = new double[200];
	int color[] = new int[200];
	int count[] = new int [200];
	int c;
	Vector<Land> myLands = new Vector<Land>();
	
	boolean isMy(Land land) {
		return land.getFlag().equals(ourFlag);
	}

	boolean isIn(Land land) {
		Set<Land> nn = land.getNeighbouringLands();
		for (final Land next: nn) {
			if (!isMy(next)) {
				return false;
			}
		}
		
		return true;
	}
	
	double getBadp(Land land) {
		double badp = 0;
		int col = land.getDiceCount();		
		
		Set<Land> nn = land.getNeighbouringLands();
		for (final Land next: nn) {
			if (!isMy(next)) {				
				if (next.getDiceCount() >= col && next.getDiceCount() > 1) {
					double p = prop[next.getDiceCount()][col];
					if (next.getDiceCount() == col)
						p /= 2;
					badp += p;						
				}
			}
		}
		
		return badp;
	}
	
	double getBonus(Land land) {
		double ans = 0;
		double badp = 0;		
		int col = land.getDiceCount();
				
		badp = getBadp(land);
		
		ans = col;
		if (badp < 0.1 && !isIn(land))
			ans *= 1.5;
		if (badp > 0.3)
			ans = ans / (1 + badp / 2);
		
		//System.out.println("land id = " + land.getLandId() + ", bonus = " + ans + ", badp = " + badp);
		
		return ans;
	}
	
	void go(Land land, int c) {
		color[land.getLandId()] = c;
		res[c] += getBonus(land);
		count[c]++;
		
		Set<Land> nn = land.getNeighbouringLands();
		for (final Land next: nn) {
			if (isMy(next) && color[next.getLandId()] == -1)
				go(next, c);
		}
	}
	
	private void prepare() {
		for (int i = 0; i < 200; i++) {
			color[i] = -1;
			res[i] = 0;
			count[i] = 0;
		}		
		
		myLands.clear();
		Set<Land> lands = world.getLands();
		
//		System.out.println("Total = " + lands.size());
		for (final Land land: lands)
			if (land.getFlag().equals(ourFlag))
				myLands.add(land);
		//System.out.println("My = " + myLands.size());
		
		
		c = 0;
		for (Land land: myLands)
			if (color[land.getLandId()] == -1) {
				go(land, c);				
				//System.out.println("new: " + land.getLandId() + "   " + c + "   " + count[c] + "  res = " + res[c]);
				c++;
			}			
	}
	
	boolean goodLand(Land land, int c) {
		if (land.getDiceCount() < 2)
			return false;
		
		if (c != -1 && color[land.getLandId()] != c)
			return false;
		
		return true;
	}
	
	Attack tryAttack(int c) {
		double bestCol = 0;
		int bestOurId = -1;
		int bestTheirsId = -1;
		
		for (final Land land : myLands) {
			if (goodLand(land, c)) {
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				for (final Land land2 : neighbouringLands) {
					if (getOpponentsCol(land) == 1 || getOpponentsCol(land2) == 0)
					if (!land2.getFlag().equals(world.getMyFlag())) {
						double p = prop[land.getDiceCount()][land2.getDiceCount()];
						if (p > p2) {
							if (land2.getDiceCount() > bestCol) {
								bestCol = land2.getDiceCount();
								bestOurId = land.getLandId();
								bestTheirsId = land2.getLandId();
							}
						}
					}
				}
			}
		}
		
		if (bestOurId != -1)
			return getAttack(bestOurId, bestTheirsId);
		

		for (final Land land : myLands) {
			if (goodLand(land, c)) {
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				for (final Land land2 : neighbouringLands) {
					if (!land2.getFlag().equals(world.getMyFlag())) {
						double p = prop[land.getDiceCount()][land2.getDiceCount()];
						if (p > p3) {
							if (land2.getDiceCount() > bestCol) {
								bestCol = land2.getDiceCount();
								bestOurId = land.getLandId();
								bestTheirsId = land2.getLandId();
							}
						}
					}
				}
			}
		}
		
		if (bestOurId != -1)
			return getAttack(bestOurId, bestTheirsId);		
		
		int bestBob = 0;
		
		for (final Land land : myLands) {
			if (goodLand(land, c)) {
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				for (final Land land2 : neighbouringLands) {
					if (!land2.getFlag().equals(world.getMyFlag())) {
						double p = prop[land.getDiceCount()][land2.getDiceCount()];
						
						if (p > .5) {
							if (getOurCount(land2.getNeighbouringLands()) > bestBob) {
								bestBob = getOurCount(land2.getNeighbouringLands());
								bestOurId = land.getLandId();
								bestTheirsId = land2.getLandId();
							}
						}
					}
				}
			}
		}		
		
		if (c != -1)
			return null;
		
		double bestp = p1;
		for (final Land land : myLands) {
			if (goodLand(land, c)) {
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				for (final Land land2 : neighbouringLands) {
					if (getOpponentsCol(land) == 1 || getOpponentsCol(land2) == 0)
					if (!land2.getFlag().equals(world.getMyFlag())) {
						double p = prop[land.getDiceCount()][land2.getDiceCount()];						
						
						if (p > bestp) {
							bestp = p;
							bestOurId = land.getLandId();
							bestTheirsId = land2.getLandId();
						}
					}
				}
			}
		}		
		
		if (bestOurId != -1)
			return getAttack(bestOurId, bestTheirsId);	
		
	
		if (bestOurId != -1)
			return getAttack(bestOurId, bestTheirsId);
		
		
		
		if (attack22(world) != null)
			return attack22(world);
		
		if (world.getDiceCountInReserve(world.getMyFlag()) > 0) {
			for (final Land land : myLands) {
				if (goodLand(land, c)) {
					Set<Land> neighbouringLands = land.getNeighbouringLands();
					for (final Land land2 : neighbouringLands) {
						if (!land2.getFlag().equals(world.getMyFlag())) {
							if (land2.getDiceCount() == land.getDiceCount())
								return getAttack(land.getLandId(), land2.getLandId());
						}
					}
				}
			}					
		}
		
		return null;		
	}
	
	@Override
	public Attack attack(World world) {
		//System.out.println("1b: " + world.getAvailableAttackCount());
		ourFlag = world.getMyFlag();
		this.world = world;
		
//		if (world.getAvailableAttackCount() > 1)
			//return null;
		
		prepare();
			
		int bestc = 0;
	
		for (int i = 0; i < c; i++)
			if (res[i] > res[bestc])	
				bestc = i;
		
		//System.out.println(res[bestc]);
		
		if (world.getFlags().size() > 2) {		
			Attack res = tryAttack(bestc);
		
			if (res != null)
				return res;
		}
		
		return tryAttack(-1);
	}
}
