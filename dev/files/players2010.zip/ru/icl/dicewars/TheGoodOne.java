/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ru.icl.dicewars;

import ru.icl.dicewars.client.*;

import java.util.Collections.*;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


/**
 *
 * @author Jack
 */
public class TheGoodOne implements Player{

    private Flag FF;
    static private Land sel;
    static private Land att;

    private int[] landPriority;


    public String getName()
    {
        return "TheGoodOne v1.1";
    }

    public void init()
    {
    }

    public Flag chooseFlag(World world, Set<Flag> availableFlags)
    {
        Iterator<Flag> x=availableFlags.iterator();
        FF = x.next();
        return FF;
    }

    public void opponentAttack(Flag opponentFlag, Attack attack,
            World beforeWorld, boolean wasAttackWon)
    {
        //do nothing;
    }

    private int getCountOfEnemiesAround(Land land)
    {
        Set<Land> ld = land.getNeighbouringLands();
        Iterator<Land> x = ld.iterator();
        
        int Count=0;
        
        while(x.hasNext())
        {
            Land temp = x.next();
            if(temp.getFlag()!=FF)
            {
                Count++;
            }
        }
        return Count;
    }

    private int getCountOfTheSameAround(Land land)
    {
        Set<Land> ld = land.getNeighbouringLands();
        Iterator<Land> x = ld.iterator();

        Flag flag=land.getFlag();

        int Count=0;

        while(x.hasNext())
        {
            Land temp = x.next();
            if(temp.getFlag()==flag)
            {
                Count++;
            }
        }
        return Count;
    }

    private int getCountOfMyAround(Land land)
    {
        Set<Land> ld = land.getNeighbouringLands();
        Iterator<Land> x = ld.iterator();

        int Count=0;

        while(x.hasNext())
        {
            Land temp = x.next();
            if(temp.getFlag()==FF)
            {
                Count++;
            }
        }
        return Count-1;
    }

    private boolean findIdealAttack(World world)
    {
        int maxPriority = 100;

        Set<Land> ld=world.getLands();
        Iterator<Land> x = ld.iterator();

        outer: while(x.hasNext())
        {
            Land s = x.next();
            if(s.getFlag()==FF && s.getDiceCount()>=2 && getCountOfEnemiesAround(s)==1)
            {
                Set<Land> ff=s.getNeighbouringLands();
                Iterator<Land> t = ff.iterator();

                Land temp=null;
                while(t.hasNext())
                {
                    temp=t.next();
                    int count = temp.getDiceCount();
                    int priority =Math.abs((s.getDiceCount()-count)-2);
                    if(temp.getFlag()!=FF && s.getDiceCount()>count && priority<maxPriority &&
                            getCountOfEnemiesAround(temp)==0 && count>1)
                    {
                        maxPriority = priority;
                        sel=s;
                        att=temp;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void findBestAttack(World world)
    {
        boolean flag=false;
        flag = findIdealAttack(world);
        if(!flag)
        {
            if(!flag)
        {
            int maxPriority = -100;

            Set<Land> ld=world.getLands();
            Iterator<Land> x = ld.iterator();

            outer: while(x.hasNext())
            {
                Land s = x.next();
                if(s.getFlag()==FF && s.getDiceCount()>=2)
                {
                    Set<Land> ff=s.getNeighbouringLands();
                    Iterator<Land> t = ff.iterator();

                    Land temp=null;
                    while(t.hasNext())
                    {
                        temp=t.next();
                        int count = temp.getDiceCount();
                        int E=getCountOfEnemiesAround(s);
                        int M =getCountOfMyAround(temp);
                        int priority =//getCountOfTheSameAround(temp)
                                -E + M;
                        if(temp.getFlag()!=FF && s.getDiceCount()>=count && priority>maxPriority)
                        {
                            maxPriority = priority;
                            sel=s;
                            att=temp;
                        }
                    }
                }
            }
        }
        }
    }

    public Attack attack(World world)
    {
        //setupWorldPriority(world);
        findBestAttack(world);

        if(att!=null)
        {
            final int xaxax=sel.getLandId();
            final int yayay=att.getLandId();
        Attack attk = new Attack() {

            public int getFromLandId() {
                return xaxax;
            }

            public int getToLandId() {
                return yayay;
            }
        };

            return attk;
        }
        else
        {
            return null;
        }
    }
}
