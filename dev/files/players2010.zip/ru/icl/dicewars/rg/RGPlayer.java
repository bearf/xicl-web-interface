package ru.icl.dicewars.rg;

import java.util.Set;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class RGPlayer implements Player
{

	public boolean used[] = new boolean[105];
	public Land q[] = new Land[105];
	public int landsCount;
	
	public int bfs(Land myLand, Flag myFlag, int diceCount[])
	{
		int sizeQ = 0;
		q[sizeQ++] = myLand;
		used[myLand.getLandId()] = true;
		Set<Land> nbs;
		if (myLand.getFlag() == myFlag)
			diceCount[0] = myLand.getDiceCount();
		for (int cl = 0; cl < sizeQ; ++cl)
		{
			nbs = q[cl].getNeighbouringLands();
			for (Land land : nbs)
			{
				if (land.getFlag() == myFlag && !used[land.getLandId()])
				{
					used[land.getLandId()] = true;
					diceCount[0] += land.getDiceCount();
					q[sizeQ++] = land;
				}
			}
		}
		return sizeQ;
	}
	
	@Override
	public void init()
	{
	}

	@Override
	public String getName()
	{
		return "IzhHunter";
	}
	
	int gGet(Flag flag)
	{
		return flag.ordinal();
	}

	@Override
	public Flag chooseFlag(World world, Set<Flag> availableFlags)
	{
		Set<Land> lands = world.getLands();
		landsCount = lands.size();
		if (landsCount > 100)
			q = new Land[landsCount + 5];		
		int mx = 0, r;
		int tt[] = new int[10];
		for (int i = 0; i < 10; i++)
			tt[i] = 0;
		Flag ret = availableFlags.iterator().next();
		for (int i = landsCount - 1; i >= 0; --i)
			used[i] = false;
		int z[] = new int[1];
		int maxDicePoint = 0;
		for (Land land : lands)
		{
			if (availableFlags.contains(land.getFlag()) && !used[land.getLandId()])
			{
				z[0] = 0;
				r = bfs(land, land.getFlag(), z);
				tt[gGet(land.getFlag())] = Math.max(tt[gGet(land.getFlag())], r);
				/*if (r > mx || r == mx && z[0] > maxDicePoint)
				{
					maxDicePoint = z[0];
					mx = r;
					ret = land.getFlag();
					//System.out.println(r + " " + mx + " " + maxDicePoint);
				}*/
			}
		}
		
		//return ret;
		
		
		Set<Land> nbs;
		mx = 0;
		double prob[] = new double[10];
		for (int i = 0; i < 10; ++i)
		{
			prob[i] = 1;
			//System.out.println(i + ": " + prob[i]);
		}
		double rr;
		for (Land land : lands)
		{
			if (availableFlags.contains(land.getFlag()))
			{
				rr = 1.0;
				nbs = land.getNeighbouringLands();
				for (Land nb : nbs)
				{
					if (nb.getFlag() != land.getFlag())
						rr *= probability(land.getDiceCount(), nb.getDiceCount()) * 2.0;
				}
				prob[gGet(land.getFlag())] *= rr;
			}
		}
		mx = 0;
		for (Flag flag : availableFlags)
		{
			r = tt[gGet(flag)];
			//System.out.println(flag + " " + r + " " + tt[gGet(flag)]);
			if (r > mx)
			{
				mx = r;
				ret = flag;
			}
		}
		for (Flag flag : availableFlags)
		{
			r = tt[gGet(flag)];
			//System.out.println(flag + " " + r + " " + prob[gGet(flag)]);
			if ((r == mx - 1) && prob[gGet(flag)] - prob[gGet(ret)] > 1e-3 || (r == mx) && prob[gGet(flag)] > prob[gGet(ret)] ||
				(r == mx - 2) && prob[gGet(flag)] - prob[gGet(ret)] > 1e-1)
			{
				//mx = r;
				ret = flag;
			}
		}
		return ret;
		//return availableFlags.iterator().next();
	}

	@Override
	public void opponentAttack(Flag opponentFlag, Attack attack,
			World beforeWorld, boolean wasAttackWon)
	{
	}
	
	public double probability(int myLand, int vragLand)
	{
		double r = 0;
		if (myLand == vragLand)
			return 0.5;
		myLand *= 6;
		vragLand *= 6;
		for (int i = 2; i <= myLand; i++)
		{
			double vragP = (double)(i - 1) / vragLand;
			if (i - 1 > vragLand)
				vragP = 1;
			r += vragP / myLand;
		}
		//System.out.println(r);
		return r;
	}	
	
	
	public double probTo(Land myLand, int diceCount, Flag myFlag)
	{
		Set<Land> nbs = myLand.getNeighbouringLands();
		double rWin = 0, rLose = 0;
		int minDiceCount = 1000000, maxDiceCount = -1;
		double r = 1;
		for (Land land : nbs)
		{
			if (!land.getFlag().equals(myFlag))
			{
				r *= probability(myLand.getDiceCount(), land.getDiceCount());
				minDiceCount = Math.min(minDiceCount, land.getDiceCount());
				maxDiceCount = Math.max(maxDiceCount, land.getDiceCount());
			}
		}
		return r;
		/*
		if (maxDiceCount >= 0)
		{
			rWin = probability(diceCount - 1, minDiceCount);
			rLose = probability(maxDiceCount, diceCount - 1);
		}
		if (rLose != 0)
			return rWin / rLose;
		return 100;*/
	}
	
	public double thisWin(Land myLand, Flag myFlag)
	{
		Set<Land> nbs = myLand.getNeighbouringLands();
		double r = 1;
		for (Land land : nbs)
		{
			if (!land.getFlag().equals(myFlag))
				r *= probability(1, land.getDiceCount());
		}
		//System.out.println("R = " + r);
		return r;
	}
	
	public double vragCount(Flag vragFlag, Set<Land> lands)
	{
		int r = 0;
		for (Land land : lands)
		{
			if (land.getFlag() == vragFlag)
				r++;
		}
		return r;
	}
	
	int compCount(Land myLand, Flag myFlag)
	{
		int z[] = new int[1];
		z[0] = 0;
		for (int i = landsCount - 1; i >= 0; i--)
			used[i] = false;
		return bfs(myLand, myFlag, z);
	}
	
	double gFunc(double x)
	{
		x /= 25.0;
		//System.out.println(x);
		return x;
	}
	
	static int z = 0;
	public double power(Land myLand, Land vragLand, World world, Set<Land> lands)
	{
		double pr = probability(myLand.getDiceCount(), vragLand.getDiceCount());
		if (pr <= 0.45)
			return 0;
		Set<Land> nbs = vragLand.getNeighbouringLands();
		int k = 0;
		for (Land land : nbs)
		{
			if (land.getFlag() == world.getMyFlag() && land.getDiceCount() >= myLand.getDiceCount())
				k++;
		}
		if (pr < 0.55 && (k < 2 || world.getAvailableAttackCount() < 3))
			return 0;
		
		double prTo = probTo(vragLand, myLand.getDiceCount(), world.getMyFlag());
		double compCnt = compCount(vragLand, world.getMyFlag());
		double vragCnt = vragCount(vragLand.getFlag(), lands);
		double vragDice = vragLand.getDiceCount();
		double thWin = thisWin(myLand, world.getMyFlag());

		pr *= 2.0;
		prTo *= 4.0;
		thWin *= 3.6;
		compCnt = 3.5 * gFunc(compCnt);
		vragCnt = 0.4 * (1.0 - vragCnt / landsCount);
		vragDice *= 0.2;
		//System.out.println(pr+ " " + prTo + " " + thWin + "  " + compCnt + " " + vragCnt + " " + vragDice);
		return pr + prTo + thWin + compCnt + vragCnt + vragDice;
	}
	
	@Override
	public Attack attack(World world)
	{
		Set<Land> lands = world.getLands();
		landsCount = lands.size();
		if (landsCount > 100)
			used = new boolean[landsCount + 5];
		int myId = 0, vragId = 0;
		double curProb = -1;
		for (final Land land : lands)
		{
			if (land.getFlag().equals(world.getMyFlag()) && land.getDiceCount() > 1)
			{
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				
				for (final Land neighbouringLand : neighbouringLands)
				{
					if (!neighbouringLand.getFlag().equals(world.getMyFlag()) && 
						power(land, neighbouringLand, world, lands) > 
						curProb)
					{
						curProb = power(land, neighbouringLand, world, lands);
						myId = land.getLandId();
						vragId = neighbouringLand.getLandId();
						//bestLand = land;
						//vragLand = neighbouringLand;	
					}
				}
			}
		}
		final int my = myId;
		final int vrag = vragId;
		//System.out.println(++z + ": " + curProb + " " + my + " " + vrag);
		if (curProb > 0.1)
		{
			return new Attack()
			{
				@Override
				public int getFromLandId()
				{
					return my;
				}

				@Override
				public int getToLandId()
				{
					return vrag;
				}
			};
		}
		return null;
	}
}
