package ru.icl.dicewars;

import java.util.*;
import java.io.*;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class LebedPlayer implements Player
{
	//===========================CONSTANTS======================================
	public final int MAX_N = 100+3;
	public final double MIN_PROBABILITY = 0.44;
	public final double Probability[][] = {
		{ 0.0, 0.000000 , 0.000000 , 0.000000 , 0.000000 , 0.000000 , 0.000000 , 0.000000, 0.000000},
		{ 0.0, 0.416740 , 0.091999 , 0.011628 , 0.000765 , 0.000030 , 0.000000 , 0.000000, 0.000000 },
		{ 0.0, 0.837481 , 0.443331 , 0.152274 , 0.035872 , 0.006104 , 0.000811 , 0.000069, 0.000007 },
		{ 0.0, 0.973291 , 0.778750 , 0.453381 , 0.191537 , 0.061320 , 0.014949 , 0.002939, 0.000492 },
		{ 0.0, 0.997331 , 0.938999 , 0.742741 , 0.460722 , 0.220248 , 0.083448 , 0.025689, 0.006463 },
		{ 0.0, 0.999866 , 0.987884 , 0.909579 , 0.718200 , 0.463570 , 0.242836 , 0.104228, 0.036513 },
		{ 0.0, 0.999993 , 0.998202 , 0.975163 , 0.884521 , 0.698880 , 0.466728 , 0.259312, 0.121492 },
		{ 0.0, 0.999999 , 0.999776 , 0.994673 , 0.961523 , 0.862128 , 0.685905 , 0.469273, 0.274138 },
		{ 0.0, 0.999999 , 0.999983 , 0.999067 , 0.989509 , 0.947700 , 0.843923 , 0.673590, 0.471788 }
    };



	//================================TYPES=====================================
	//quick struct
	public class Vertex implements Serializable
	{
		int landId;
		int diceCount;
		Flag flag;

		int n[],nSize;
		Vertex()
		{
			n = new int[MAX_N];
		}
	}
	//condense vertex
	public class Area implements Serializable
	{
		int l[];
		int lSize;
		Flag flag;
		int areaId;
		Area()
		{
			l = new int[MAX_N];
		}
	}
	//world map
	public class WorldMap implements Serializable
	{
		Vertex w[];
		int wSize;
		Area area[];
		int areaSize;
		boolean was[];
		Queue <Integer> q;
		int sCapital;
		Map< Flag, Integer > reserve;
		
		public WorldMap()
		{
			w = new Vertex[MAX_N];
			area = new Area[MAX_N];
			
			for(int i = 0; i < MAX_N; i++)
				w[i] = new Vertex();
			for(int i = 0; i < MAX_N; i++)
				area[i] = new Area();
			 
			 was = new boolean[MAX_N];
			 q = new LinkedList<Integer>();

			 sCapital = -1;
			 reserve = new HashMap();
		}

		//condese graph
		
		public void bfs(Area curArea, int start)
		{
			q.clear();
			q.add( (Integer)start );
			was[ start ] = true;
			while( !q.isEmpty() )
			{
				int cur = (int)q.remove();
				curArea.l[ curArea.lSize++ ] = cur;

				for(int i = 0; i < w[cur].nSize; i++)
				{
					int n = w[cur].n[i];
					if( !was[n] && w[n].flag == w[cur].flag )
					{
						q.add((Integer)n);
						was[n] = true;
					}
				}
			}//while
		}

		public void condense()
		{
			for(int i = 0; i < wSize; i++)
				was[i] = false;

			sCapital = -1;
			areaSize = 0;
			for(int i = 0; i < wSize; i++)
				if( !was[i] )
				{
					area[ areaSize ].areaId = areaSize;
					area[ areaSize ].flag = w[i].flag;
					area[ areaSize ].lSize = 0;
					bfs( area[areaSize], i );

					if( area[areaSize].lSize > sCapital ) sCapital = area[ areaSize ].lSize;

					areaSize++;
			}
		}

		//import
		public void setWorld(World world)
		{
			Set<Land> lands = world.getLands();
			wSize = lands.size();

			for (final Land land : lands)
			{
				int cur = land.getLandId()-1;
				w[ cur ].diceCount = land.getDiceCount();
				w[ cur ].landId = land.getLandId()-1;
				w[ cur ].flag = land.getFlag();
				w[ cur ].nSize = 0;
				
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				for (final Land neighbouringLand : neighbouringLands)
				{
					w[cur].n[ w[cur].nSize ] = neighbouringLand.getLandId()-1;
					w[cur].nSize++;
				}
			}

			List<Flag> flags= world.getFlags();
			reserve.clear();
			for(final Flag flag: flags)
			{
				reserve.put(flag, world.getDiceCountInReserve(flag));
			}
		}
		
	}//class


	//Chance
	public class Chance implements Serializable
	{
		int diceCount;
		double maxChance;
		int areaId;
		int i,k,p;
		Chance()
		{
			p = -1;
			i = -1;
			k = -1;

		}
	}


	//=================================VAR======================================
	Flag ourFlag;
	WorldMap curWorld;
	
	//minimum, medium and maximum size of army
	double Amin, Amed, Amax;
	double eps = 0.001;

	double C1 = 0.9, D1 = 0.1;  // good front   [0.9, 1.0];
	double C2 = 0.3, D2 = 0.2;  // bad front    [0.3, 0.5];
	double C3 = 0.7, D3 = 0.2;  // good reserve [0.7, 0.9];
	double C4 = 0.5, D4 = 0.2;  // bad reserve  [0.5, 0.7];

    double ArmyRank(WorldMap world, int id) // id = id of island in area (we have deal with area[id].l)
    {
        Area area[] = world.area;
        Vertex w[] = world.w;

        double army = 0.0;

        for(int i = 0; i < area[id].lSize; i++)
        {
           int maxEnemyDices = 0;
           int cur = area[id].l[i];

           for(int j = 0; j < w[cur].nSize; j++)
           {

               int to = w[cur].n[j];

               if ((!w[to].flag.equals(w[cur].flag)) &&
                  (maxEnemyDices < w[to].diceCount))
                   maxEnemyDices = w[to].diceCount;
           }

           if (maxEnemyDices == 0) // reserve or front ?
             {
               // reserve

               if ((double)w[cur].diceCount >= Amed)  // is reseve good?
                 {
                   // good reserve
                   if (Amax - Amed < eps)
                     army = army + C3 + D3;
                    else
                     army = army + C3 + D3 * ( ((double)w[cur].diceCount - Amed) / (Amax - Amed) );
                 }
                else
                 {
                   // bad reserve

                   if (Amed - Amin < eps)
                     army = army + C4 + D4;
                    else
                     army = army + C4 + D4 * ( (Amed - (double)w[cur].diceCount) / (Amed - Amin) );
                 }
             }
           else
             {
                 // front
                 if (w[cur].diceCount >= maxEnemyDices) //is our front reliable?
                   {
                     // good front!
                     if (Amax == maxEnemyDices)
                       army = army + C1 + D1;
                      else
                       army = army + C1 + D1 * ( ((double)w[cur].diceCount - maxEnemyDices) / (double)(Amax - maxEnemyDices) );
                   }
                  else
                   {
                     // bad front
                     army = army + C2 + D2 * (1.0 - Probability[ maxEnemyDices ][ w[cur].diceCount ]);
                   }
             }
        }

        return army;
    }

    // Alpha-function
    double Rank(WorldMap world, Flag flag)
    {
        int areaSize = world.areaSize;
        Area area[] = world.area;
        Vertex w[] = world.w;

        double curArmy, capArmy = 0.0, func = 0.0;
        int componentsNumber = 0, capId = -1;

        for(int i = 0; i < areaSize; i++)
            if (area[i].flag == flag)
            {
                componentsNumber++;

                curArmy = ArmyRank(world, i);

                func = func + curArmy;

                if  ( (capId == -1) ||
                      (area[i].lSize > area[capId].lSize) ||
                      ((area[i].lSize == area[capId].lSize) && (curArmy > capArmy))
                    )
                {
                    capId = i;
                    capArmy = curArmy;
                }

            }

        func = func - capArmy;

        if (componentsNumber > 1)
          func = func / (double)(componentsNumber-1);

        func = func + capArmy;

        return func;
    }

	double GeoRank2(WorldMap world, Flag flag)
	{
		double res = 0;

		double f = 0;
		for(int i = 0; i < world.wSize; i++)
			if( world.w[i].diceCount < 8 ) f++;
		double a = (world.sCapital+world.reserve.get(flag)) / f;

		for(int i = 0; i < world.areaSize; i++)
			if( world.area[i].flag == flag )
			{
				double p = 0;
				for(int j = 0; j < world.area[i].lSize; j++)
				{
					int cur = world.area[i].l[j];
					for(int k = 0; k < world.w[cur].nSize; k++)
						if(		world.w[ world.w[cur].n[k] ].flag != flag
							&&	world.w[ world.w[cur].n[k] ].diceCount > world.w[cur].diceCount+a )
						{
							p+=1;
						}
				}

				double areaRank = (4.0 * world.area[i].lSize) / p;
				areaRank *= (double)world.area[i].lSize*(double)world.area[i].lSize
							/ (double)(world.sCapital)*(double)(world.sCapital);

				res += areaRank;
			}

		return res;
	}


	double GeoRank(WorldMap world, Flag flag)
	{
		double res = 0;

		for(int i = 0; i < world.areaSize; i++)
			if( world.area[i].flag == flag )
			{
				double p = 0;
				for(int j = 0; j < world.area[i].lSize; j++)
				{
					int cur = world.area[i].l[j];
					for(int k = 0; k < world.w[cur].nSize; k++)
						if( world.w[ world.w[cur].n[k] ].flag != flag )
						{
							p+=1;
						}
				}

				double areaRank = (4.0 * world.area[i].lSize) / p;
				areaRank *= (double)world.area[i].lSize*(double)world.area[i].lSize
							/ (double)(world.sCapital)*(double)(world.sCapital);

				res += areaRank;
			}

		return res;
	}

	//================================CODE======================================

	
	class PairII implements Serializable
	{
		int i,k;
		PairII(int _i,int _k)
		{
			i = _i;
			k = _k;
		}
	}

	Queue<PairII> goQ = new LinkedList<PairII>();
	Chance goChance[][] = new Chance[MAX_N][8];
	int goColor[][] = new int[MAX_N][8];
	Flag gFlag[] = new Flag[MAX_N];
	int gCount[] = new int[MAX_N];
	int gTo,gFrom,cTo,cFrom;
	double maxC = 0;

	double f(WorldMap world,Flag flag,int i1,int k1,int i2,int k2)
	{
		//System.out.println(":f");
		double res = 0;

		for(int i = 0; i < MAX_N; i++)
		{
			gFlag[i] = world.w[i].flag;
			gCount[i] = world.w[i].diceCount;
		}

		if( goChance[i1][k1].k == 0 )
		{
		} else
		{
			//System.out.println("i1 = "+i1+"p = "+goChance[i1][k1].p+"k1 = "+k1);
			world.w[i1].diceCount = goChance[i1][k1].diceCount;
			world.w[i1].flag = flag;
			while( goChance[i1][k1].p != -1 )
			{
				cTo = i1;
				i1 = goChance[i1][k1].p;
				k1-=1;
				//System.out.println("i1 = "+i1+"p = "+goChance[i1][k1].p+"k1 = "+k1);
			}
			cFrom = i1;
		}

		

		if( goChance[i2][k2].p == -1 )
		{
		} else
		{
			//System.out.println("i2 = "+i2+"p = "+goChance[i2][k2].p+"k2 = "+k2);

			world.w[i2].diceCount = goChance[i2][k2].diceCount;
			world.w[i2].flag = flag;
			while( goChance[i2][k2].p != -1 )
			{
				cTo = i2;
				i2 = goChance[i2][k2].p;
				k2-=1;
				//System.out.println("i2 = "+i2+"p = "+goChance[i2][k2].p+"k2 = "+k2);
			}
			cFrom = i2;
		}
		
		world.condense();
		

		res = Rank(world,flag);

		for(int i = 0; i < MAX_N; i++)
		{
			world.w[i].flag = gFlag[i];
			world.w[i].diceCount = gCount[i];
		}
		world.condense();
		//System.out.println(333333);

		return res;
	}

	void goUnion(WorldMap world,Flag flag,int steps)
	{
		//System.out.println("Union steps = "+steps);

		goQ.clear();
		for(int i = 0; i < MAX_N; i++)
			for(int j = 0; j < 8; j++)
			{
				goColor[i][j] = 0;
				goChance[i][j].areaId = -1;
				goChance[i][j].diceCount = -1;
				goChance[i][j].i = -1;
				goChance[i][j].k = -1;
				goChance[i][j].p = -2;
			}


		for(int a = 0; a < world.areaSize; a++)
		{
			Area curArea = world.area[a];
			if( curArea.flag == flag )
			for(int l = 0; l < curArea.lSize; l++)
			{
				int cur = curArea.l[l];

				for(int i = 0; i < world.w[cur].nSize; i++)
				{
					int n = world.w[cur].n[i];

					if( world.w[n].flag != flag )
					{
						goChance[cur][0].maxChance = 1.0;
						goChance[cur][0].diceCount = world.w[cur].diceCount;
						goChance[cur][0].i = cur;
						goChance[cur][0].k = 0;
						goChance[cur][0].p = -1;
						goChance[cur][0].areaId = curArea.areaId;
						goColor[cur][0] = 2;
						if( world.w[cur].diceCount > 1 )
							goQ.add( new PairII(cur,0) );
					}

				}
			}
		}
		//System.out.println(2);
		
		while( !goQ.isEmpty() )
		{
			PairII cur = goQ.remove();
			goColor[cur.i][cur.k] = 2;

			//System.out.println("pop = "+(cur.i+1)+", k = "+cur.k);

			for(int i = 0; i < world.w[cur.i].nSize; i++)
			{
				int n = world.w[cur.i].n[i];

				for(int k = 0; k < 8; k++)
					if( cur.k+k<=steps && goColor[n][k] == 2 )
					if( goChance[cur.i][cur.k].areaId != goChance[n][k].areaId )
					{
						double curC = goChance[cur.i][cur.k].maxChance * goChance[n][k].maxChance;

						//System.out.println("want union "+(cur.i+1)+", "+(n+1));
						//System.out.println("want union area1 = "+goChance[cur.i][cur.k].areaId+", area2 = "+goChance[n][k].areaId);
						curC *= f(world,flag,cur.i,cur.k,n,k);
						//System.out.println("curCahnce = "+curC);

						if( curC > maxC )
						{
							maxC = curC;
							gTo = cTo;
							gFrom = cFrom;
						}
					}

				if( world.w[n].flag != flag )
				{
					int imHave = goChance[cur.i][cur.k].diceCount;
					int enemyHave = world.w[n].diceCount;
					double curC = Probability[imHave][enemyHave]*goChance[cur.i][cur.k].maxChance;
					if( curC > MIN_PROBABILITY )
					{
						if( goColor[n][cur.k+1] != 2 )
						{
							if( goColor[n][cur.k+1] == 0 || goColor[n][cur.k+1] == 1 && goChance[n][cur.k+1].maxChance < curC )
							{
								goChance[n][cur.k+1].maxChance = curC;
								goChance[n][cur.k+1].diceCount = imHave-1;
								goChance[n][cur.k+1].i = n;
								goChance[n][cur.k+1].k = cur.k+1;
								goChance[n][cur.k+1].p = cur.i;
								goChance[n][cur.k+1].areaId = goChance[cur.i][cur.k].areaId;
								if( goColor[n][cur.k+1] == 0 )
								{
									goColor[n][cur.k+1] = 1;
									goQ.add( new PairII(n,cur.k+1) );
								}

							}
						}
					}
				}
			}

		}

	}



	double goEx(WorldMap world,int from,int to)
	{
		Vertex To = new Vertex();
		Vertex From = new Vertex();

		To.diceCount = world.w[to].diceCount;
		To.flag = world.w[to].flag;
		From.diceCount = world.w[from].diceCount;

		world.w[to].diceCount = world.w[from].diceCount-1;
		world.w[to].flag = world.w[from].flag;
		world.w[from].diceCount = 1;

		world.condense();
		double res = Rank( world, world.w[from].flag );

		world.w[to].diceCount = To.diceCount;
		world.w[to].flag = To.flag;
		world.w[from].diceCount = From.diceCount;
	
		return res;
	}

	//================================SYSTEM====================================
	@Override
	public void init()
	{
		//init WorldMaps
		curWorld = new WorldMap();


		//init Chance map
		for(int i = 0; i < MAX_N; i++)
			for(int j = 0; j < 8; j++)
			{
				goChance[i][j] = new Chance();
			}
		
	}

	@Override
	public String getName()
	{
		return "SteamPlayer";
	}

	@Override
	public Flag chooseFlag(World world, Set<Flag> availableFlags)
	{
		curWorld.setWorld(world);
		curWorld.condense();
		double maxRank = 0;
		Flag resFlag = availableFlags.iterator().next();
		
		for(final Flag flag: availableFlags)
		{
			double curRank = GeoRank(curWorld,flag);
			if( curRank > maxRank )
			{
				maxRank = curRank;
				resFlag = flag;
			}
		}
		
		return resFlag;
	}

	@Override
	public void opponentAttack(Flag opponentFlag, Attack attack, World beforeWorld, boolean wasAttackWon)
	{
	}

	void funk(WorldMap world)
	{
		Vertex w[] = world.w;
		int wSize = world.wSize;

		//get medium of army
		Amed = 0.0;
		Amax = 0.0;
		Amin = 10.0;
		for(int i = 0; i < wSize; i++)
		  {
		    Amed = Amed + (double)w[i].diceCount;
            if (Amin > w[i].diceCount)
                Amin = w[i].diceCount;
            if (Amax < w[i].diceCount)
                Amax = w[i].diceCount;
		  }
		Amed /= (double)wSize;
	}

	@Override
	public Attack attack(World world)
	{

		long start = System.currentTimeMillis();

		//System.out.println("Attack");
		ourFlag = world.getMyFlag();
		
		//copy into quick struct
		curWorld.setWorld(world);
		//System.out.println("setWorld");
		
		funk(curWorld);
		//System.out.println("funk");


		//union
		curWorld.condense();
		gTo = -1;
		gFrom = -1;
		maxC = 0.0;
		goUnion(curWorld,ourFlag,world.getAvailableAttackCount());
		
		
		double maxChance = maxC;


		Vertex w[] = curWorld.w;
		int resTo = gTo,resFrom = gFrom;
		
		for(int cur = 0; cur < curWorld.wSize; cur++)
		if( w[cur].flag == ourFlag )
		{

			if( w[cur].diceCount > 1 )
			//for neighbouringLands
				for(int j = 0; j < w[cur].nSize; j++)
				{
					int neighbour = w[cur].n[j];
					if( w[neighbour].flag != ourFlag )
					{
					
						int imHave = w[cur].diceCount;
						int enemyHave = w[neighbour].diceCount;
						double curChance = Probability[ imHave ][ enemyHave ];

						if( curChance >= MIN_PROBABILITY )
						{
					
							curChance*=goEx( curWorld, cur, neighbour);

							//System.out.println(">["+cur+","+neighbour+"] = "+curChance);
							if( curChance > maxChance )
							{
								maxChance = curChance;
								resTo = neighbour;
								resFrom = cur;
							}
						}

					}
				}//for
		}
		

		//System.out.println("time = "+(System.currentTimeMillis()-start));

		if( resTo != -1 )
		{
			final int getFrom = resFrom+1;
			final int getTo = resTo+1;

			//System.out.println("return Attack: "+"["+getFrom+","+getTo+"]");

			return new Attack()
			{
						@Override
						public int getFromLandId() 
						{
							return getFrom;
						}
						@Override
						public int getToLandId()
						{
							return getTo;
						}
			};

		}
		
		return null;
	}//attack method

}//class
