package SamaraSAU2;

import java.util.Arrays;
import java.util.Set;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class SimplePlayer implements Player
{
	int AvailableAttackCount = 0;
	int[] a;
	@Override
	public void init()
	{
		a = new int[500];
	}
	
	@Override
	public String getName() 
	{
		return "SSAU";
	}
	
	@Override
	public Flag chooseFlag(World world, Set<Flag> availableFlags) 
	{
		return availableFlags.iterator().next();
	}
	
	@Override
	public void opponentAttack(Flag opponentFlag, Attack attack, World beforeWorld, boolean wasAttackWon) 
	{	}

	@Override
	public Attack attack(World world) 
	{
		Arrays.fill(a, 0);
		int min = Integer.MAX_VALUE, nmin = 0;
		Set<Land> lands = world.getLands();
		
		for (final Land land : lands) 
		{
			if (land.getFlag().equals(world.getMyFlag()))
			{
				int n = 0;
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				for (final Land neighbouringLand : neighbouringLands) 
				{
					if (!neighbouringLand.getFlag().equals(world.getMyFlag()) && land.getDiceCount() > neighbouringLand.getDiceCount())
					{
						n++;
					}
				}
				a[land.getLandId()] = n;
				
				
			}
		}
		
		min = Integer.MAX_VALUE;
		nmin = 0;
		
		for(int i=0;i<100;i++)
		{
			if (a[i]<min && a[i]>0)
			{
				min = a[i];
				nmin = i;
			}
		}
		
		if (min==Integer.MAX_VALUE)
			return null;
		
		for (final Land land : lands) 
		{
			if (land.getLandId() == nmin)
			{
				Set<Land> neighbouringLands = land.getNeighbouringLands();
				for (final Land neighbouringLand : neighbouringLands) 
				{
					if (land.getDiceCount() > neighbouringLand.getDiceCount()) 
					{
						return new Attack() 
						{
							@Override
							public int getFromLandId()
							{
								return land.getLandId();
							}

							@Override
							public int getToLandId() 
							{
								return neighbouringLand.getLandId();
							}
						};
					}
				}
			}
		}
		
		
		return null;
	}
}
