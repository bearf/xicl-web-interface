package samarasau;

import ru.icl.dicewars.client.*;
import java.util.*;

public class Hohol
	implements Player {

    public void init() {
    }

    public String getName() {
	String s = this.getClass().getName();
	return s.substring(s.indexOf('.') + 1);
	//return "it\'s me!!1";
    }

    public Flag chooseFlag(World world, Set<Flag> availableFlags) {
	this.graph = Vertex.graph = new Graph(world);
	Flag bestFlag = null;
	double max = Double.NEGATIVE_INFINITY;
	for (Flag flag : availableFlags) {
	    MyFlag = flag;
	    double test = this.evalPosition();
	    if (test > max) {
		max = test;
		bestFlag = flag;
	    }
	}
	MyFlag = bestFlag;
	return MyFlag;
    }

    public void opponentAttack(Flag opponentFlag, Attack attack, World beforeWorld, boolean wasAttackWon) {
    }

    void debug() {
	if(!Debug)
	    return;
	System.out.println("Enter smth");
	try {
	    Scanner scanner = new Scanner(System.in);
	    if (scanner.next().equals("q")) {
		Debug = false;
	    }
	} catch (Exception e) {
	}
    }
    boolean Debug = false;

    public Attack attack(final World world) {
        debug();
	this.graph.update(world);
	double max = -1e100;
	Vertex bestFrom = null, bestTo = null;
	for (Vertex from : graph.vertices) {
	    if (from.flag == MyFlag) {
		for (Vertex to : from.adjacent) {
		    if (to.flag != MyFlag) {
			//double test = evalAttack(from, to);
			double test = evalAttack(from, to, Math.min(2, graph.StepCount));

			if(Debug)
			    System.out.println(from.ID + " " + to.ID + " " + test);
			if (test > max) {
			    max = test;
			    bestFrom = from;
			    bestTo = to;
			}
		    }
		}
	    }
	}
	return attack(bestFrom, bestTo);
    }
    Graph graph;
    Flag MyFlag;

    double evalAttack(final Vertex from, final Vertex to, int depth) {
	if (from.DiceCount <= to.DiceCount) {
	    if (from.DiceCount != 8 || !isStrong(from)) {
		return Double.NEGATIVE_INFINITY;
	    }
	}



	/*Vertex fromBuf = new Vertex(from), toBuf = new Vertex(to);
	to.DiceCount = from.DiceCount - 1;
	to.flag = from.flag;
	from.DiceCount = 1;

	double test = evalPosition();
	

	from.update(fromBuf);
	to.update(toBuf);
	return test + to.DiceCount;*/

	Vertex fromBuf = new Vertex(from), toBuf = new Vertex(to);
	to.DiceCount = from.DiceCount - 1;
	to.flag = from.flag;
	from.DiceCount = 1;

	double max;
	if(depth == 1) {
	    max = evalPosition();
	} else {
	    max = -1e100;
	    boolean hasMove = false;
	    for (Vertex f : graph.vertices) {
		if (f.flag == MyFlag) {
		    for (Vertex t : f.adjacent) {
			if (t.flag != MyFlag) {
			    double test = evalAttack(f, t, depth - 1);
			    if (test > max) {
				max = test;
				hasMove = true;
			    }
			}
		    }
		}
	    }
	    if(!hasMove)
		max = evalPosition();
	}

	from.update(fromBuf);
	to.update(toBuf);
	if(from.DiceCount <= to.DiceCount + 1)
	    max--;
	else
	    max += to.DiceCount;
	return max;

    }

    double evalPosition() {
	
	int res = 0;
	res += graph.maxConnectedComponent(MyFlag);
	res -= this.badEdgeCount();
	//res += this.goodLandCount();

	return res;
    }

    int maxNeighbour(Vertex vertex, boolean my) {
	int max = 0;
	for (Vertex v : vertex.adjacent) {
	    if (my && v.flag == MyFlag || !my && v.flag != MyFlag) {
		if (v.DiceCount > max) {
		    max = v.DiceCount;
		}
	    }
	}
	return max;
    }

    int minNeighbour(Vertex vertex, boolean my) {
	int min = 20;
	for (Vertex v : vertex.adjacent) {
	    if (my && v.flag == MyFlag || !my && v.flag != MyFlag) {
		if (v.DiceCount < min) {
		    min = v.DiceCount;
		}
	    }
	}
	if (min == 20) {
	    return 0;
	}
	return min;
    }

    int badEdgeCount() {
	int res = 0;

	for (Vertex vertex : graph.vertices) {
	    if (vertex.flag == MyFlag) {
		/*int a = this.maxNeighbour(vertex, true);
		int b = this.maxNeighbour(vertex, false);
		if (b > Math.max(a, vertex.DiceCount)) {/**/
		if (this.maxNeighbour(vertex, false) > vertex.DiceCount) {
		    res++;
		}
	    }
	}
	return res;
    }

    boolean isStrong(Vertex vertex) {
	boolean ok = false;
	for (Vertex v : vertex.adjacent) {
	    if (v.flag == vertex.flag) {
		if (v.DiceCount == 8) {
		    ok = true;
		} else {
		    return false;

		}
	    }
	}
	return ok;
    }

    Attack attack(final Vertex from, final Vertex to) {
	if (from == null) {
	    return null;
	}

	return new Attack() {

	    public int getFromLandId() {
		return from.ID;
	    }

	    public int getToLandId() {
		return to.ID;
	    }
	};
    }
}

class Vertex
	implements java.io.Serializable {

    int DiceCount;
    int ID;
    Flag flag;
    Vector<Vertex> adjacent;
    static Graph graph;

    Vertex(Land land) {
	DiceCount = land.getDiceCount();
	flag = land.getFlag();
	ID = land.getLandId();
    }

    void update(Vertex vertex) {
	DiceCount = vertex.DiceCount;
	flag = vertex.flag;
    }

    Vertex(Vertex vertex) {
	ID = vertex.ID;
	adjacent = vertex.adjacent;
	update(vertex);
    }
}

class Graph
	implements java.io.Serializable {

    Vertex[] vertices;
    int StepCount;

    void update(World world) {
	for (Land land : world.getLands()) {
	    Vertex vertex = vertices[land.getLandId() - 1];
	    vertex.DiceCount = land.getDiceCount();
	    vertex.flag = land.getFlag();
	}
	StepCount = world.getAvailableAttackCount();
    }

    private int getComponentSize(Vertex vertex) {
	Queue<Vertex> q = new LinkedList();
	visited |= (1 << vertex.ID);
	q.add(vertex);
	int res = 0;
	while (q.size() != 0) {
	    Vertex cur = q.remove();
	    res++;
	    for (Vertex v : cur.adjacent) {
		if (v.flag == vertex.flag && (visited & (1 << v.ID)) == 0) {
		    q.add(v);
		    visited |= (1 << v.ID);
		}
	    }

	}
	return res;
    }
    private long visited;

    int maxConnectedComponent(Flag flag) {
	int max = 0;
	visited = 0;
	for (Vertex vertex : vertices) {
	    if (vertex.flag == flag && (visited & (1 << vertex.ID)) == 0) {
		int test = getComponentSize(vertex);
		if (test > max) {
		    max = test;
		}
		visited |= (1 << vertex.ID);
	    }
	}
	return max;
    }

    Graph(World world) {
	int size = world.getLands().size();
	vertices = new Vertex[size];
	for (Land l : world.getLands()) {
	    vertices[l.getLandId() - 1] = new Vertex(l);  // vertices[i].ID == i+1
	}

	for (Land l : world.getLands()) {
	    Vertex vertex = vertices[l.getLandId() - 1];
	    vertex.adjacent = new Vector<Vertex>();
	    for (Land neighbour : l.getNeighbouringLands()) {
		vertex.adjacent.add(vertices[neighbour.getLandId() - 1]);
	    }
	}
    }
}
