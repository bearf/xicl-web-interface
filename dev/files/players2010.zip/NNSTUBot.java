import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class NNSTUBot implements Player {

	private static final long serialVersionUID = 291817627127610162L;
	private static final double MIN_P_TO_UNION_ATTACK = 0.65;
	private static final int NO_COMPONENT = -1;
	private static final int MAX_DICE = 6;
	private static final int MAX_DICE_COUNT = 8;
	private static final double MIN_P_TO_EXPANSION_ATTACK = 0.70;
	private static final int INF = 1000;
	private static final int MIN_DICE_TO_RUSH = 5;
	private static final int MIN_DIST_TO_UNION = 3;

	private static ExpansionOpportunityComparator expansionOpportunityComparator;

	private static UnionOpportunityComparator unionOpportunityComparator;

	private static double[][] probability;

	private static class FlagOpportunity implements Comparable<FlagOpportunity> {
		public Flag flag;
		public int numLands;
		public int minDist;

		@Override
		public int compareTo(FlagOpportunity o) {
			if (numLands == o.numLands)
				return minDist - o.minDist;
			return o.numLands - numLands;
		}

		@Override
		public String toString() {
			return flag.name() + ": mindist=" + minDist + ", numLands="
					+ numLands;
		}
	}

	void gen(long[][] count, int diceCount, int curSum) {
		if (diceCount + 1 < count.length) {
			for (int i = 1; i <= MAX_DICE; ++i) {
				++count[diceCount + 1][curSum + i];
				gen(count, diceCount + 1, curSum + i);
			}
		}
	}

	double[][] calculateProbabiltyTable() {
		// calculate
		long[][] count = new long[MAX_DICE_COUNT + 1][MAX_DICE * MAX_DICE_COUNT
				+ 1];
		gen(count, 0, 0);
		double[][] prob = new double[MAX_DICE_COUNT + 1][MAX_DICE_COUNT + 1];
		for (int i = 1; i <= MAX_DICE_COUNT; ++i) {
			for (int j = 1; j <= MAX_DICE_COUNT; ++j) {
				long total = 0;
				long totalWin = 0;
				for (int x = i; x <= MAX_DICE * i; ++x) {
					for (int y = j; y <= MAX_DICE * j; ++y) {
						if (x > y)
							totalWin += count[i][x] * count[j][y];
						total += count[i][x] * count[j][y];
					}
				}
				prob[i][j] = (double) totalWin / (double) total;
			}
		}
		return prob;
	}

	Set<Land> getOpponentNeighbourLands(final World world, final Land land) {
		final Set<Land> result = new HashSet<Land>();
		final Flag myFlag = world.getMyFlag();
		for (final Land aLand : land.getNeighbouringLands()) {
			if (!aLand.getFlag().equals(myFlag)) {
				result.add(aLand);
			}
		}
		return result;
	}

	int[][] getAdjacencyMatrix(World w) {
		Set<Land> lands = w.getLands();
		final int n = lands.size();
		int[][] m = new int[n + 1][n + 1];
		for (int[] row : m) {
			Arrays.fill(row, INF);
		}

		for (final Land l : lands) {
			m[l.getLandId()][l.getLandId()] = 0;
			for (final Land l2 : l.getNeighbouringLands()) {
				m[l.getLandId()][l2.getLandId()] = 1;
			}
		}
		return m;
	}

	int splitConnected(int[] numbers, int[][] m, boolean[] toCheck) {
		Arrays.fill(numbers, NO_COMPONENT);
		int cur = 0;
		for (int i = 1; i < numbers.length; ++i) {
			if (toCheck[i] && numbers[i] == NO_COMPONENT) {
				markDfs(m, i, numbers, toCheck, cur++);
			}
		}
		return cur;
	}

	private void markDfs(int[][] m, int v, int[] numbers, boolean[] toCheck,
			int mark) {
		numbers[v] = mark;
		for (int i = 1; i < numbers.length; ++i) {
			if (toCheck[i] && numbers[i] == NO_COMPONENT && m[v][i] != INF) {
				markDfs(m, i, numbers, toCheck, mark);
			}
		}

	}

	private void getAllShortestPathes(int[][] m, int[][] outPathes,
			int[][] outThrough) {
		final int l = m[0].length - 1;
		for (int i = 1; i <= l; ++i) {
			System.arraycopy(m[i], 1, outPathes[i], 1, l);
		}
		for (int k = 1; k <= l; ++k) {
			for (int i = 1; i <= l; ++i) {
				for (int j = 1; j <= l; ++j) {
					if (i == j || i == k || j == k)
						continue;
					if (outPathes[i][j] > outPathes[i][k] + outPathes[k][j]) {
						outPathes[i][j] = outPathes[i][k] + outPathes[k][j];
						outThrough[i][j] = k;
					}
				}
			}
		}
	}

	private int[][] mAdj;
	private int[][] mDists;
	private int[][] mPathes;
	private boolean[] mLands;

	// private int[] mComponents;

	Attack expansionAttack(World world) {
		final Flag myFlag = world.getMyFlag();
		final List<Opportunity> opportunities = new ArrayList<Opportunity>();
		for (final Land aLand : world.getLands()) {
			if (aLand.getFlag().equals(myFlag)) {
				final Land myLand = aLand;
				final Set<Land> oppLands = getOpponentNeighbourLands(world,
						myLand);
				for (final Land oppLand : oppLands) {
					final Opportunity newOpp = new Opportunity();
					newOpp.fromLandId = myLand.getLandId();
					newOpp.distance = 0;
					newOpp.toLandId = oppLand.getLandId();
					newOpp.probability = probability[myLand.getDiceCount()][oppLand
							.getDiceCount()];
					newOpp.opponentDiceCount = oppLand.getDiceCount();
					if (newOpp.probability > MIN_P_TO_EXPANSION_ATTACK) {
						opportunities.add(newOpp);
					}
				}
			}
		}

		Collections.sort(opportunities, expansionOpportunityComparator);

		Attack result = null;

		if (!opportunities.isEmpty()) {
			result = new MyAttack(opportunities.get(0).fromLandId,
					opportunities.get(0).toLandId);
		}

//		if (result != null) {
//			System.err.println("expansionAttack: " + result.getFromLandId()
//					+ " to " + result.getToLandId());
//		}

		return result;
	}

	private Attack unionAttack(World world) {
		final int[][] dists = mDists;
		final int[][] pathes = mPathes;
		final int[] numbers = mNumbers;
		final boolean[] lands = mLands;
		final int L = mAdj.length - 1;
		int minDist = INF, from = -1, to = -1;
		// getAllShortestPathes(mAdj, dists, pathes);
		getAllFlagLandNumbers(lands, world, world.getMyFlag());

		int componentCount = splitConnected(numbers, mAdj, lands);

		for (int i = 1; i <= L; ++i) {
			for (int j = 1; j <= L; ++j) {
				if (numbers[i] != numbers[j] && numbers[i] != NO_COMPONENT
						&& numbers[j] != NO_COMPONENT
						&& getLandById(i).getDiceCount() > MIN_DICE_TO_RUSH) {
					if (dists[i][j] < minDist) {
						minDist = dists[i][j];
						from = i;
						to = j;
					}
				}
			}
		}

		final List<Opportunity> oppList = new ArrayList<Opportunity>();

		for (int i = 1; i <= L; ++i) {
			if (lands[i]) {
				final Land myLand = getLandById(i);
				final Set<Land> neibs = getOpponentNeighbourLands(world, myLand);
				for (final Land neighbour : neibs) {
					int mindist = INF;
					int toLandId = -1;
					int k = neighbour.getLandId();
					for (int j = 1; j <= L; ++j) {
						if (lands[j] && numbers[i] != numbers[j]) {
							if (dists[k][j] < mindist) {
								mindist = dists[k][j];
								toLandId = k;
							}
						}
					}
					if (toLandId > -1) {
						final Opportunity opp = new Opportunity();
						opp.distance = mindist;
						opp.fromLandId = i;
						opp.toLandId = toLandId;
						opp.probability = probability[myLand.getDiceCount()][getLandById(
								toLandId).getDiceCount()];
						oppList.add(opp);
					}
				}
			}
		}

		Collections.sort(oppList, unionOpportunityComparator);

		Attack result = null;

		for (final Opportunity op : oppList) {
			if (isLandAttackable(getLandById(op.fromLandId),
					getLandById(op.toLandId), MIN_P_TO_UNION_ATTACK)) {
				result = new MyAttack(op.fromLandId, op.toLandId);
				break;
			}
			if (op.distance > Math.min(MIN_DIST_TO_UNION, world
					.getAvailableAttackCount() + 1)) {
				break;
			}
		}
//		if (result != null) {
//			System.err.println("unionAttack: " + result.getFromLandId()
//					+ " to " + result.getToLandId());
//		}

		return result;
	}

	private boolean isLandAttackable(final Land from, final Land to,
			final double minProbability) {
		return probability[from.getDiceCount()][to.getDiceCount()] >= minProbability;
	}

	@Override
	public Attack attack(World world) {
		try {
			updateLands(world);
			// Attack a = newAttack(world);
			Attack a = unionAttack(world);
			if (a == null) {
				a = expansionAttack(world);
			}
			if (a == null) {
				a = getForTwoEights(world);
			}
//			if (a == null) {
//				System.err.println("NULL");
//			}
			return a;
		} catch (Exception ex) {
//			ex.printStackTrace(System.err);
			return null;
		}

	}

	Land[] mIdToLand;
	private int[] mNumbers;

	private void updateLands(World w) {
		if (mIdToLand == null) {
			mIdToLand = new Land[w.getLands().size() + 1];
		}
		for (Land l : w.getLands()) {
			mIdToLand[l.getLandId()] = l;
		}
	}

	private Land getLandById(int id) {
		return mIdToLand[id];
	}

	private void getAllFlagLandNumbers(boolean[] numbers, World w, Flag f) {
		for (Land l : w.getLands()) {
			if (f.equals(l.getFlag())) {
				numbers[l.getLandId()] = true;
			} else {
				numbers[l.getLandId()] = false;
			}
		}
	}

	@Override
	public Flag chooseFlag(World world, Set<Flag> flags) {
		mAdj = getAdjacencyMatrix(world);
		mDists = new int[mAdj.length][mAdj.length];
		mPathes = new int[mAdj.length][mAdj.length];
		mLands = new boolean[mAdj.length];
		mNumbers = new int[mAdj.length];
		getAllShortestPathes(mAdj, mDists, mPathes);

		List<FlagOpportunity> opps = new ArrayList<FlagOpportunity>();
		for (Flag f : flags) {
			opps.add(evalFlag(world, f));
		}
		Collections.sort(opps);
		return opps.get(0).flag;
	}

	private FlagOpportunity evalFlag(final World world, final Flag flag) {
		final FlagOpportunity opp = new FlagOpportunity();
		final boolean[] filteredLands = mLands;
		final int[] numbers = mNumbers;
		getAllFlagLandNumbers(filteredLands, world, flag);
		final int connCount = splitConnected(numbers, mAdj, filteredLands);
		int maxConn = -INF;
		final int L = mAdj.length - 1;
		for (int i = 0; i < connCount; ++i) {
			int cur = 0;
			for (int l = 1; l <= L; ++l) {
				if (numbers[l] == i) {
					++cur;
				}
			}
			if (maxConn < cur) {
				maxConn = cur;
			}
		}

		Land maxDiceLand = null;
		int maxDiceCnt = -INF;
		for (final Land land1 : world.getLands()) {
			if (land1.getFlag().equals(flag)
					&& land1.getDiceCount() > maxDiceCnt) {
				maxDiceCnt = land1.getDiceCount();
				maxDiceLand = land1;
			}
		}
		int sumDist = 0;
		int l1 = maxDiceLand.getLandId();

		for (final Land land2 : world.getLands()) {
			int l2 = land2.getLandId();
			if (filteredLands[l2]) {
				sumDist += mDists[l1][l2];
			}

		}
		opp.minDist = sumDist;
		opp.numLands = maxConn;
		opp.flag = flag;
//		System.err.println(opp);
		return opp;
	}

	@Override
	public void init() {
		expansionOpportunityComparator = new ExpansionOpportunityComparator();
		unionOpportunityComparator = new UnionOpportunityComparator();
		probability = calculateProbabiltyTable();
	}

	@Override
	public void opponentAttack(Flag arg0, Attack arg1, World arg2, boolean arg3) {
		// TODO Auto-generated method stub
	}

	static class Opportunity {
		public int fromLandId;
		public int toLandId;
		public int distance; // the distance between toLandId and nearest
		// connect
		// component which fromLand doesn't belong to
		public double probability;
		public int opponentDiceCount;
	}

	static class ExpansionOpportunityComparator implements
			Comparator<Opportunity> {

		@Override
		public int compare(Opportunity o1, Opportunity o2) {
			// return (int) Math.signum(-o1.probability + o2.probability);
			if (o1.opponentDiceCount != o2.opponentDiceCount) {
				return (int) Math.signum(-o1.opponentDiceCount
						+ o2.opponentDiceCount);
			} else {
				return (int) Math.signum(-o1.probability + o2.probability);
			}
		}

	}

	static class UnionOpportunityComparator implements Comparator<Opportunity> {

		@Override
		public int compare(Opportunity o1, Opportunity o2) {
			if (o1.distance != o2.distance) {
				return o1.distance - o2.distance;
			} else {
				return (int) Math.signum(-o1.probability + o2.probability);
			}
		}
	}

	static class MyAttack implements Attack {
		int from, to;

		MyAttack(int from, int to) {
			this.from = from;
			this.to = to;
		}

		@Override
		public int getFromLandId() {
			return from;
		}

		@Override
		public int getToLandId() {
			return to;
		}

	}

	private Set<Land> getAllMoveables(World w) {
		final Flag ourFlag = w.getMyFlag();
		final Set<Land> result = new HashSet<Land>();
		for (Land l : w.getLands()) {
			if (l.getFlag().equals(ourFlag)
					&& !getOpponentNeighbourLands(w, l).isEmpty()) {
				result.add(l);
			}
		}
		return result;
	}

	private Attack getForTwoEights(World w) {
		Set<Land> candidates = getAllMoveables(w);
		for (Land l : candidates) {
			if (l.getDiceCount() == MAX_DICE_COUNT) {
				Land maxNeighbourOpponent = null;
				Land maxNeighbourFriend = null;
				for (Land n : l.getNeighbouringLands()) {
					if (n.getFlag().equals(w.getMyFlag())) {
						if (maxNeighbourFriend == null
								|| n.getDiceCount() > maxNeighbourFriend
										.getDiceCount()) {
							maxNeighbourFriend = n;
						}
					} else {
						if (maxNeighbourOpponent == null
								|| n.getDiceCount() > maxNeighbourOpponent
										.getDiceCount()) {
							maxNeighbourOpponent = n;
						}
					}
				}
				if (maxNeighbourFriend != null
						&& maxNeighbourFriend.getDiceCount() == MAX_DICE_COUNT
						&& maxNeighbourOpponent != null) {
					int from = l.getLandId();
					int to = maxNeighbourOpponent.getLandId();
//					System.err.printf("For2Eights from %d to %d\n", from, to);
					return new MyAttack(from, to);
				}
			}
		}
		return null;
	}

	@Override
	public String getName() {
		return "Lord Kenny";
	}
}
