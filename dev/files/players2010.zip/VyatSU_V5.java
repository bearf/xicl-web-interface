import java.util.Set;
import java.util.Random;

import ru.icl.dicewars.client.Attack;
import ru.icl.dicewars.client.Flag;
import ru.icl.dicewars.client.Land;
import ru.icl.dicewars.client.Player;
import ru.icl.dicewars.client.World;

public class VyatSU_V5 implements Player{
	int [][] count = {
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,1,2,3,4,5,6,5,4,3,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,1,3,6,10,15,21,25,27,27,25,21,15,10,6,3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,1,4,10,20,35,56,80,104,125,140,146,140,125,104,80,56,35,20,10,4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,1,5,15,35,70,126,205,305,420,540,651,735,780,780,735,651,540,420,305,205,126,70,35,15,5,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,1,6,21,56,126,252,456,756,1161,1666,2247,2856,3431,3906,4221,4332,4221,3906,3431,2856,2247,1666,1161,756,456,252,126,56,21,6,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,1,7,28,84,210,462,917,1667,2807,4417,6538,9142,12117,15267,18327,20993,22967,24017,24017,22967,20993,18327,15267,12117,9142,6538,4417,2807,1667,917,462,210,84,28,7,1,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,1,8,36,120,330,792,1708,3368,6147,10480,16808,25488,36688,50288,65808,82384,98813,113688,125588,133288,135954,133288,125588,113688,98813,82384,65808,50288,36688,25488,16808,10480,6147,3368,1708,792,330,120,36,8,1}
			
			};
	
	public void init(){

	}
	
	public String getName() {
		return "VyatkaSU WA2";
	}
	
	public Flag chooseFlag(World world, Set<Flag> availableFlags) {
		Set<Land> lands = world.getLands();
		int [][] sumDice = new int [lands.size()+10][9];
		Flag [] flag = new Flag [lands.size()+10];
		for (final Land tland : lands) {
			++sumDice[tland.getLandId()][tland.getDiceCount()];
			flag[tland.getLandId()] = tland.getFlag();
		}
		int [] w = {0,0,2,4,8,16,32,64,128};
		int n = lands.size();
		int mx = 0, tmp;
		Flag ret = availableFlags.iterator().next();
		for (final Flag tflag : availableFlags) {
			tmp = 0;
			for (int i = 1; i <= n; ++i) {
				if (flag[i].equals(tflag)) {
					for (int j = 1; j <= 8; ++j) {
						tmp += w[j] * sumDice[i][j];
					}
				}
			}
			if (tmp > mx) {
				mx = tmp;
				ret = tflag;
			}
		}
		return ret;
	}
	
	public void opponentAttack(Flag opponentFlag, Attack attack, World beforeWorld, boolean wasAttackWon) {
		
	}
	public boolean canBeat(int n, int m) {
		if (n>m)
			return true;
		else return false;
		//double prob = getProb(n,m); 
		//return prob>0.55;
	}
	public double getProb(int n, int m) {
		//precalc
		double [] p = new double [9];
		p[0] = 1.0;
		for (int i = 1; i < 9; ++ i) {
			p[i] = p[i-1] / 6.0;
		}
		//calc
		double prob = .0, tp;
		for (int i = n; i <= 6*n; ++i ) {//my count
			tp = .0;
			for (int j = m; j < i; ++j) {//enemy count
				tp += count[m][j] * p[m];
			}
			prob += count[n][i] * p[n] * tp;
		}	
		prob = prob + .0;
		return prob;
	}
	
	int [] cnt;
	int [][] mas;
	int [] flag;
	int [] comp;
	Land [] land;
	Flag [] compCol;
	boolean [] compUse;
	public void dfsLand(int v, int it) {
		flag[v] = it;
		++comp[it];
		for (int i = 1; i <= cnt[v]; ++i) {
			int to = mas[v][i];
			if (flag[to]==0 && land[v].getFlag().equals(land[to].getFlag())) {
				dfsLand(to,it);
			}
		}
	}
	public Attack greedyStrat(World world) {
		compCol = new Flag [world.getLands().size()+10];
		compUse  = new boolean [world.getLands().size()+10]; 
		comp = new int [world.getLands().size()+10];
		cnt = new int [world.getLands().size()+10];
		flag = new int [world.getLands().size()+10];
		mas = new int [world.getLands().size()+10][world.getLands().size()+10];
		land = new Land [world.getLands().size()+10];
		
		//make matrix
		Set<Land> lands = world.getLands();
		int n = lands.size(), v;
		for (final Land tland : lands) {
			v = tland.getLandId();
			land[v] = tland;
			cnt[v] = 0;
			flag[v] = 0;
			Set<Land> nLands = tland.getNeighbouringLands();
			for (final Land nLand : nLands) {
				mas[v][++cnt[v]] = nLand.getLandId();
			}
		}
		//make comp
		int it = 0;
		for (int i=1;i<=n;i++) {
			if (flag[i]==0) {
				++it;
				comp[it] = 0;
				compCol[it] = land[i].getFlag();
				dfsLand(i,it);
			}
		}
		int i,j,mx,c,mx2,k,to,S,T,mxval;
		double mxprob = .0;
		mx2 = S = T = mxval = 0;
		for (i = 1; i <= it; ++i) {//find max source component
			if (!compUse[i] && compCol[i].equals(world.getMyFlag())) {
				mx = comp[i];
				c = i;
				for (j = 1; j <= it; ++j) {
					if (i==j)
						continue;
					if (!compUse[j] && compCol[j].equals(world.getMyFlag()) && comp[j] > mx) {
						mx = comp[j];
						c = j;
					}
					
				}
				compUse[c] = true;
				for (v = 1; v <= n; ++v) {//try each land from max component
					if (flag[v]==c && land[v].getDiceCount()>1){//land from this comp
						for (k = 1; k <= cnt[v]; ++k) {//look neighb
							to = mas[v][k];
							if (!land[to].getFlag().equals(world.getMyFlag())) {//enemy land
								double d = getProb(land[v].getDiceCount(),land[to].getDiceCount());
								if (canBeat(land[v].getDiceCount(),land[to].getDiceCount()) && comp[c]+1 > mx2) {
									mx2 = comp[c] + 1;
									S = v;
									T = to;
									mxprob = d;
									mxval = land[to].getDiceCount();
								}
								else if (canBeat(land[v].getDiceCount(),land[to].getDiceCount()) && (comp[c]+1)==mx2 && land[to].getDiceCount() > mxval) {
									mxval = land[to].getDiceCount();
									mxprob = d;
									S = v;
									T = to;
								}
							}
						}
					}
				}
	
			}
		}
		int curmax = 0;
		for (i=1;i<=n;i++) {
			if (land[i].getFlag().equals(world.getMyFlag()) && comp[flag[i]] > curmax)
				curmax = comp[flag[i]];
		}
		double eps = 1e-8;
		int t1,t2;
		for (v = 1; v <= n; ++v) {
			if (!land[v].getFlag().equals(world.getMyFlag())) {//enemy land
				for (i = 1; i <= cnt[v]; ++i) {
					t1 = mas[v][i];
					if (land[t1].getFlag().equals(world.getMyFlag())) {
						for (j = i+1; j <= cnt[v]; ++j) {
							t2 = mas[v][j];
							if (land[t2].getFlag().equals(world.getMyFlag())) {
								boolean can1, can2;
								can1 = canBeat(land[t1].getDiceCount(),land[v].getDiceCount());
								can2 = canBeat(land[t2].getDiceCount(),land[v].getDiceCount());
								if (land[t1].getDiceCount()==1)
									can1 = false;
								if (land[t2].getDiceCount()==1)
									can2 = false;
								double d1,d2,mxd;
								d1 = getProb(land[t1].getDiceCount(),land[v].getDiceCount());
								d2 = getProb(land[t2].getDiceCount(),land[v].getDiceCount());
								mxd =d1;
								if (d2 > d1)
									mxd = d2;
								if (flag[t1]!=flag[t2] && (can1 || can2)) {//different lands
									if (comp[flag[t1]]+comp[flag[t2]]+1 > mx2) {
										mxval = land[v].getDiceCount();
										mx2 = comp[flag[t1]]+comp[flag[t2]]+1;
										mxprob = mxd;
										if (can1 && !can2)
											S = t1;
										else if (can2 && !can1)
											S = t2;
										else {
											if (d1-d2 > eps)
												S = t1;
											else if (d2-d1 > eps)
												S = t2;
											else {
												Random random = new Random();
												if (random.nextInt()%2==0)
													S = t1;
												else S = t2;
											}
										}
										T = v;
									}
									else if (comp[flag[t1]]+comp[flag[t2]]+1 == mx2 && land[v].getDiceCount() > mxval) {
										mxval = land[v].getDiceCount();
										mxprob = mxd;
										if (can1 && !can2)
											S = t1;
										else if (can2 && !can1)
											S = t2;
										else {
											if (d1-d2 > eps)
												S = t1;
											else if (d2-d1 > eps)
												S = t2;
											else {
												Random random = new Random();
												if (random.nextInt()%2==0)
													S = t1;
												else S = t2;
											}
										}
										T = v;
									}
								}
							}
						}
					}
				}
			}
		}
		if (mx2>0) {
			final int From = S, To = T;
			return new Attack() {
				public int getFromLandId() {
					return From;
				}
				public int getToLandId() {
					return To;
				}
			};			
		}		
		
		return null;		
	}
	Flag [] aFlag;
	int [] cntFlag;
	int cntAFlag;
	
	public int getAlivePlayer(World world) {
		Set<Land> lands = world.getLands();
		aFlag = new Flag [8];
		cntFlag = new int [8];
		int res = 0;
		for (final Land tland : lands) {
			int fl = 0;
			for (int i = 0; i < res; ++i) {
				if (aFlag[i].equals(tland.getFlag())){
					fl = 1;
					++cntFlag[i];
				}
			}
			if (fl==0) {
				aFlag[res] = tland.getFlag();
				cntFlag[res] = 1;
				++res;
			}
		}
		cntAFlag = res;
		return res;
	}

	int [] vx;
	int [] vy;
	boolean [] fx;
	boolean [] fy;
	int [] dx;
	int [] dy;
	int cx, cy;
	int [] stx;
	int [] sty;
	int cntSt;
	
	public Attack dfsKill(int ost) {
		if (ost==0){
			return new Attack() {
				public int getFromLandId() {
					return stx[cntSt];
				}
				public int getToLandId() {
					return sty[cntSt];
				}
			};
		}
		int i,j,to,from,k;
		for (i=1;i<=cx;i++){
			from = vx[i];
			for (j=1;j<=cy;++j){
				if (!fy[j]) {
					to = vy[j];
					for (k=1;k<=cnt[from];++k){
						if (mas[from][k]==to && canBeat(dx[i],dy[j])) {
							int t1 = dx[i];
							dx[i] = 1;
							fy[j] = true;
							cx++;
							dx[cx] = t1 - 1 + dy[j];
													
							stx[ost] = from;
							sty[ost] = to;
							
							Attack tryAttack = dfsKill(ost-1);
							if (tryAttack!=null)
								return tryAttack;
							--cx;
							fy[j] = false;
							dx[i] = t1;
						}
					}
				}
			}

		}
		return null;
	}
	public Attack canKill(Flag enemyFlag, World world) {
		int i,j,n;
		cx = cy = 0;
		n = world.getLands().size();
		vx = new int [n+1];
		vy = new int [n+1];
		fx = new boolean [n+1];
		fy = new boolean [n+1];
		dx = new int [n+1];
		dy = new int [n+1];
		stx = new int [n+1];
		sty = new int [n+1];

		for (i=1;i<=n;++i) {
			if (land[i].getFlag().equals(world.getMyFlag())) {
				++cx;
				vx[cx] = land[i].getLandId();
				dx[cx] = land[i].getDiceCount();
			}
			else if (land[i].getFlag().equals(enemyFlag)){
				++cy;
				vy[cy] = land[i].getLandId();
				dy[cy] = land[i].getDiceCount();
			}
		}
		cntSt = cy;
		return dfsKill(cy);
	}
	public Attack attack(World world) {
		
		compCol = new Flag [world.getLands().size()+10];
		compUse  = new boolean [world.getLands().size()+10]; 
		comp = new int [world.getLands().size()+10];
		cnt = new int [world.getLands().size()+10];
		flag = new int [world.getLands().size()+10];
		mas = new int [world.getLands().size()+10][world.getLands().size()+10];
		land = new Land [world.getLands().size()+10];
		int aliveP = getAlivePlayer(world);
		if (aliveP==2){
			return greedyStrat(world);
		}
	
		//make matrix
		Set<Land> lands = world.getLands();
		int n = lands.size(), v;
		for (final Land tland : lands) {
			v = tland.getLandId();
			land[v] = tland;
			cnt[v] = 0;
			flag[v] = 0;
			Set<Land> nLands = tland.getNeighbouringLands();
			for (final Land nLand : nLands) {
				mas[v][++cnt[v]] = nLand.getLandId();
			}
		}
		//make comp
		int it = 0;
		for (int i=1;i<=n;i++) {
			if (flag[i]==0) {
				++it;
				comp[it] = 0;
				compCol[it] = land[i].getFlag();
				dfsLand(i,it);
			}
		}
		
		//try eat player
		for (int i = 0; i < cntAFlag; ++i) {
			if (cntFlag[i]<6 && !aFlag[i].equals(world.getMyFlag()) && world.getAvailableAttackCount() >= cntFlag[i]) {
				Attack at = canKill(aFlag[i],world);
				if (at!=null)
					return at;
			}
		}
		return greedyStrat(world);
		/*Land source, target;
		final Land from = source;
		final Land to = target;
		return new Attack() {
			public int getFromLandId() {
				return from.getLandId();
			}
			public int getToLandId() {
				return to.getLandId();
			}
		};
		return null;*/
	}
}
