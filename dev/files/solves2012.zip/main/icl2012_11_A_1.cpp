#include <iostream>
#include <set>
#include <cstdlib>

#define p pair<int, int>
#define s second
#define f first

using namespace std;


int main() {
	freopen("bricks.in", "r", stdin);
	freopen("bricks.out", "w", stdout);
	int n, k;
	set<p> s;
	cin >> n >> k;
	p t, t1, t2;
	for (int i = 0; i < k; ++i) {
		cin >> t.f >> t.s;
		t1.f = t.f;
		t2.f = t.f - 1;
		t1.s = t2.s = t.s - 1;
		if (t.s > 1 && s.find(t1) != s.end() && s.find(t2) == s.end()) {
			cout << i + 1;
			exit(0);
		}
		t1.f = t.f;
		t2.f = t.f - 1;
		t1.s = t.s + 1;
		t2.s = t.s;
		if (t.s < t.f && s.find(t1) != s.end() && s.find(t2) == s.end()) {
			cout << i + 1;
			exit(0);
		}
		s.insert(t);
	}

	cout << -1;
	return 0;
}