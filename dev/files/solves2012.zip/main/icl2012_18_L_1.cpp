#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair <int, int> pii;

#define x first
#define y second
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define sz(a) (int)((a).size())
#define debug(...) fprintf(stderr, __VA_ARGS__)

#define problemname "race"
int n;
pair<ld, int> p[1000000];
ld a[1000000];
int main() {
    freopen(problemname".in", "r", stdin);
    freopen(problemname".out", "w", stdout);
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        double x;
        scanf("%lf", &x);
        a[i] = M_PI - x;
        p[i].x = abs(M_PI / 2 - a[i]);
        p[i].y = i;
    }
    sort(p, p + n);
    set<int> s;
    vector<int> ans;
    for (int i = 0; i < n; i++) {
        set<int>::iterator l = s.lower_bound(p[i].y);
        if (l != s.begin()) {
            l--;
        }  
        set<int>::iterator r = s.upper_bound(p[i].y);
        bool add = true;
//        cerr<<p[i].y<<endl;
        if (l != s.end() && *l < p[i].y) {
//            cerr<<p[i].y<<" l "<<*l<<endl;
            if (a[*l] > a[p[i].y]) {
                add = false;
            }
        }  
        if (r != s.end() && *r > p[i].y) {
  //          cerr<<p[i].y<<" r "<<*r<<endl;
            if (a[*r] < a[p[i].y]) {
                add = false;
            }
        }  
        if (add) {
            ans.pb(p[i].y);
            s.insert(p[i].y);
        }
    }
    printf("%d\n", sz(ans));
    for (int i = 0; i < sz(ans); i++) {
        printf("%d%c", ans[i] + 1, " \n"[i == sz(ans) - 1]);
    }
    return 0;
}
