#include <iostream>
#include <sstream>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <vector>
#include <string>
#include <ctime>
#include <cmath>
using namespace std;

const int N = 100005;
const double PI = acos(-1.0);

typedef pair<int, int> pii;
typedef pair<double, pii> pdii;
#define X first
#define Y second

int n;
pdii ang[N];
vector<int> res;
int fen[N];

void fenAdd(int v, int val)
{
	v++;
	for ( ; v <= n; v = (v | (v + 1)))
		fen[v] += val;
}

int fenGet(int v)
{
	int sum = 0;
	for ( ; v > 0; v = (v & (v + 1)) - 1)
		sum += fen[v];
	return sum;
}

int fenSum(int l, int r)
{
	l++; r++;
	l = max(l, 1);
	r = min(r, n);
	return fenGet(r) - (l ? fenGet(l - 1) : 0);
}

int main()
{
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	freopen("race.in", "r", stdin); freopen("race.out", "w", stdout);
	
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		double t;
		scanf("%lf", &t);
		t = PI / 2 - t;
		if (t < 0)
			ang[i] = pdii(-t, pii(-1, i));
		else
			ang[i] = pdii(t, pii(1, i));
	}
	sort(ang, ang + n, greater<pdii>());

	for (int i = 0; i < n; i++)
		fenAdd(i, 1);

	for (int i = 0; i < n; i++)
	{
		int sum = 0;
		if (ang[i].Y.X == -1)
			sum = fenSum(0, ang[i].Y.Y - 1);
		else
			sum = fenSum(ang[i].Y.Y + 1, n - 1);
		if (sum == 0)
			res.push_back(ang[i].Y.Y);
		fenAdd(ang[i].Y.Y, -1);
	}

	printf("%d\n", (int)res.size());
	for (int i = 0; i < res.size(); i++)
		printf("%d ", res[i] + 1);

	return 0;
}
