#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <algorithm>
#include <string>
#include <string.h>
#include <set>
#include <map>

using namespace std;

#define pb push_back
#define mp make_pair
#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)

#define TASK "bricks"

typedef long long int64;

int64 n, k;

set <pair<int64, int64> > t;

bool Check(int64 a, int64 b) {
	if (t.find(mp(a, b) ) != t.end()) return false;
	if (t.find(mp(a + 1, b)) != t.end() && t.find(mp(a + 1, b + 1)) != t.end()) {
		return true;
	}
	return false;
}

int main() {
	int64 i;
	int64 a, b;
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
	scanf("%I64d %I64d", &n, &k);
	fi(1, k) {
		scanf("%I64d %I64d", &a, &b);
		t.insert(mp(a, b));
		if (Check(a - 1, b - 1) && b >= 2 || Check(a - 1, b)) {
			printf("%I64d\n", i);
			return 0;
		}
	}
	printf("-1\n");
	return 0;
}