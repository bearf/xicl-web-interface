#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <ctime>
#include <cmath>

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define fs first
#define sc second
#define len(x) ((int) (x).size())
#define last(x) (x)[(len(x)-1)]
#define plast(x) (x)[(len(x)-2)]
#define sqr(x) ((x)*(x))
#define foreach(i, x) for (__typeof((x).begin()) i = (x).begin(); i != (x).end(); ++i)
#define forn(i, n) for (int i = 0; i < int(n); ++i)

using namespace std;

typedef long double ld;
typedef unsigned long long int64;

const int maxn = 100010;
const int mx[4] = {-1, 0, 1, 0};
const int my[4] = {0, -1, 0, 1};

struct pt
{
	int x, y;
};

int n, m;
string s[maxn]; 
vector<bool> was[2][maxn];
char temp[maxn];
pt a, b;

bool dfs(pt v, int k)
{
	if ((v.x == b.x) && (v.y == b.y)) 
		return true;
	was[k][v.x][v.y] = true;	
	pt u;
	for (int i = 0; i < 4; i++)
	{
		u.x = v.x + mx[i];
		u.y = v.y + my[i];
		if ((u.x < 0) || (u.x >= n) || (u.y < 0) || (u.y >= m))		
			continue;
		bool res = false;	
		if (s[v.x][v.y] - k >= '1')
		{
			if (!was[0][u.x][u.y])			
				res = res | dfs(u, 0);
		}			
		if ((s[u.x][u.y] != '0') && (!was[1][u.x][u.y]))
			res = res | dfs(u, 1);
		if (res)
			return true;

	}
	return false;
}

int main() {
	freopen("islands.in", "r", stdin);
	freopen("islands.out", "w", stdout);
	scanf("%d %d\n", &n, &m);
	for (int i = 0; i < n; i++)
	{
		scanf("%s\n", temp);
		s[i] = temp;
		was[0][i].resize(m);
		was[1][i].resize(m);
	}

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			was[0][i][j] = was[1][i][j] = false;

	scanf("%d %d", &a.x, &a.y);
	a.x--;
	a.y--;
	scanf("%d %d", &b.x, &b.y);
	b.x--;
	b.y--;
	if (dfs(a, 0))
		printf("YES");
	else
		printf("NO");

	fclose(stdin);
	fclose(stdout);	      	
	return 0;
}
