import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {

	void _solve() throws Exception {
		int m = nextInt();
		int[] curCount = new int[m];
		int initSum = 0;
		for (int i = 0; i < m; ++i) {
			curCount[i] = nextInt();
			initSum += curCount[i];
		}
		int[] init = curCount.clone();
		int[] goal = new int[m];
		int goalSum = 0;
		for (int i = 0; i < m; ++i) {
			goal[i] = nextInt();
			goalSum += goal[i];
		}
		if (initSum != goalSum) {
			out.print(-1);
			return;
		}
		int[] needToAdd = new int[m];
		int left = 0;
		while (true) {
			int indToChange = -1;
			for (int i = 0; i < m; ++i) {
				if (curCount[i] < goal[i]) {
					indToChange = i;
				}
			}
			if (indToChange < 0) {
				break;
			}
			++needToAdd[indToChange];
			for (int i = 0; i < m; ++i) {
				if (i == indToChange) {
					curCount[i] += m - 1;
				} else {
					--curCount[i];
				}
			}
			++left;
		}
		curCount = init;
		ArrayList<Integer> ans = new ArrayList<Integer>();
		while (left > 0) {
			--left;
			boolean canDo = true, complete = true;
			int indToChange = -1, minNum = Integer.MAX_VALUE;
			for (int i = 0; i < m; ++i) {
				if (needToAdd[i] > 0 && curCount[i] < minNum) {
					indToChange = i;
					minNum = curCount[i];
				}
			}
			ans.add(indToChange + 1);
			--needToAdd[indToChange];
			for (int i = 0; i < m; ++i) {
				if (i == indToChange) {
					curCount[i] += m - 1;
				} else {
					--curCount[i];
					if (curCount[i] < 0) {
						out.print(-1);
						return;
					}
				}
			}
		}
		out.println(ans.size());
		for (int a : ans) {
			out.print(a + " ");
		}
	}
	
	BufferedReader in;
	StringTokenizer stringTokenizer;
	PrintWriter out;
	
	long nextLong() {
		return Long.parseLong(nextToken());
	}
	
	double nextDouble() {
		return Double.parseDouble(nextToken());
	}
	
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	
	String nextToken() {
		while (!stringTokenizer.hasMoreTokens()) {
			String line = null;
			try {
				line = in.readLine();
			} catch (IOException e) {
				NOO(e);
			}
			if (line == null) {
				return null;
			} else {
				stringTokenizer = new StringTokenizer(line);
			}
		}
		return stringTokenizer.nextToken();
	}
	
	public void run() {
		try {
			_solve();
		} catch (Exception e) {
			NOO(e);
		} finally {
			out.close();
		}
	}
	
	void NOO(Exception e) {
		e.printStackTrace();
		System.exit(42);
	}
	
	public Solution(String name) {
		try {
			in = new BufferedReader(new FileReader(name + ".in"));
			stringTokenizer = new StringTokenizer("");
			out = new PrintWriter(new FileWriter(name + ".out"));
		} catch (Exception e) {
			NOO(e);
		}
	}
	
	public static void main(String[] args) {
		new Solution("changes").run();
	}

}
