import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {
	
	int[][][][][] ans;
	boolean[][][][] visited;
	int[][] ar;
	int n = 30, m = 30;

	void _solve() throws Exception {
		/*ArrayList<Integer> a = new ArrayList<Integer>();
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < m; ++j) {
				a.add(i * n + m);
			}
		}
		Collections.shuffle(a);*/
		n = nextInt();
		m = nextInt();
		ar = new int[n][m];
		for (int x = 0; x < n; ++x) {
			for (int y = 0; y < m; ++y) {
				//ar[x][y] = a.get(x * n + y);
				ar[x][y] = nextInt();
				--ar[x][y];
			}
		}
		ans = new int[n][m][n][m][];
		visited = new boolean[n][m][n][m];
		solve(0, 0, n - 1, m - 1);
		//System.out.println(ans);
		int cur = 0;
		for (int i = 0; i < n * m; ++i) {
			cur += ans[0][0][n - 1][m - 1][i];
			out.print(cur + " ");
		}
	}


	private int[] solve(int xFrom, int yFrom, int xTo, int yTo) {
		if (visited[xFrom][yFrom][xTo][yTo]) {
			return ans[xFrom][yFrom][xTo][yTo];
		}
		visited[xFrom][yFrom][xTo][yTo] = true;
		ans[xFrom][yFrom][xTo][yTo] = new int[n * m];
		Arrays.fill(ans[xFrom][yFrom][xTo][yTo], Integer.MAX_VALUE);
		
		int minXPos = -1, minYPos = -1, minVal = Integer.MAX_VALUE;
		for (int x = xFrom; x <= xTo; ++x) {
			for (int y = yFrom; y <= yTo; ++y) {
				if (ar[x][y] < minVal) {
					minVal = ar[x][y];
					minXPos = x;
					minYPos = y;
				}
			}
		}
		if (xFrom == xTo && yFrom == yTo) {
			Arrays.fill(ans[xFrom][yFrom][xTo][yTo], -1);
			ans[xFrom][yFrom][xTo][yTo][minVal] = 0;
			return ans[xFrom][yFrom][xTo][yTo];
		}
		if (minXPos > xFrom) {
			merge(solve(xFrom, yFrom, minXPos - 1, yTo), solve(minXPos, yFrom, xTo, yTo), ans[xFrom][yFrom][xTo][yTo]);
		}
		if (minXPos < xTo) {
			merge(solve(xFrom, yFrom, minXPos, yTo), solve(minXPos + 1, yFrom, xTo, yTo), ans[xFrom][yFrom][xTo][yTo]);
		}
		if (minYPos > yFrom) {
			merge(solve(xFrom, yFrom, xTo, minYPos - 1), solve(xFrom, minYPos, xTo, yTo), ans[xFrom][yFrom][xTo][yTo]);
		}
		if (minYPos < yTo) {
			merge(solve(xFrom, yFrom, xTo, minYPos), solve(xFrom, minYPos + 1, xTo, yTo), ans[xFrom][yFrom][xTo][yTo]);
		}
		
		/*for (int newXFrom = xFrom; newXFrom <= xTo; ++newXFrom) {
			for (int newXTo = newXFrom; newXTo <= xTo; ++newXTo) {
				for (int newYFrom = yFrom; newYFrom <= yTo; ++newYFrom) {
					for (int newYTo = newYFrom; newYTo <= yTo; ++newYTo) {
						if ((newXFrom == minXPos || newXFrom == minXPos + 1 || newXFrom == xFrom) &&
								(newXTo == minXPos - 1 || newXTo == minXPos || newXTo == xTo) &&
								(newYFrom == minYPos || newYFrom == minYPos + 1 || newYFrom == yFrom) &&
								(newYTo == minYPos - 1 || newYTo == minYPos || newYTo == yTo)) {
							dfs(newXFrom, newYFrom, newXTo, newYTo);
						}
					}
				}
			}
		}*/
		/*for (int i = 0; i < n * m; ++i) {
			if (ans[xFrom][yFrom][xTo][yTo][i] >= 0) {
				++ans[xFrom][yFrom][xTo][yTo][i];
			}
		}*/
		++ans[xFrom][yFrom][xTo][yTo][minVal];
		return ans[xFrom][yFrom][xTo][yTo];
	}


	private void merge(int[] a, int[] b, int[] prev) {
		for (int i = 0; i < n * m; ++i) {
			if (a[i] < 0 && b[i] < 0) {
				prev[i] = -1;
			} else {
				if (a[i] >= 0 && b[i] >= 0) {
					throw new RuntimeException();
				}
				int cur = Math.max(a[i], b[i]);
				if (cur != prev[i]) {
					if (cur > prev[i]) {
						return;
					} else {
						for (int j = 0; j < n * m; ++j) {
							prev[j] = Math.max(a[j], b[j]);
						}
					}
					break;
				}
			}
		}
	}


	BufferedReader in;
	StringTokenizer stringTokenizer;
	PrintWriter out;
	
	long nextLong() {
		return Long.parseLong(nextToken());
	}
	
	double nextDouble() {
		return Double.parseDouble(nextToken());
	}
	
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	
	String nextToken() {
		while (!stringTokenizer.hasMoreTokens()) {
			String line = null;
			try {
				line = in.readLine();
			} catch (IOException e) {
				NOO(e);
			}
			if (line == null) {
				return null;
			} else {
				stringTokenizer = new StringTokenizer(line);
			}
		}
		return stringTokenizer.nextToken();
	}
	
	public void run() {
		try {
			_solve();
		} catch (Exception e) {
			NOO(e);
		} finally {
			out.close();
		}
	}
	
	void NOO(Exception e) {
		e.printStackTrace();
		System.exit(42);
	}
	
	public Solution(String name) {
		try {
			in = new BufferedReader(new FileReader(name + ".in"));
			stringTokenizer = new StringTokenizer("");
			out = new PrintWriter(new FileWriter(name + ".out"));
		} catch (Exception e) {
			NOO(e);
		}
	}
	
	public static void main(String[] args) {
		new Solution("cuts").run();
	}

}
