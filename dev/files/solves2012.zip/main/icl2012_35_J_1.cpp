#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cassert>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <string>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define _(a, b) memset(a, b, sizeof(a))

typedef long long lint;
typedef unsigned long long ull;

const int INF = 1000000000;
const lint LINF = 4000000000000000000ll;
const double eps = 1e-9;

void prepare(string file)
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#else
	freopen((file + ".in").c_str(), "r", stdin);
	freopen((file + ".out").c_str(), "w", stdout);
#endif
}

int n, m;

vector< string > a;

char tmp[100005];

pair<int, int> st, en;

int encode(pair<int, int> x)
{
	return x.first * m + x.second;
}

int encode(int ny, int nx)
{
	return ny * m + nx;
}

pair<int, int> decode(int x)
{
	return mp(x / m, x % m);
}

bool used[100005][2][5];
queue< pair<int, pair<int, int>> > q;

int dx[4] = {0, 1, 0, -1};
int dy[4] = {1, 0, -1, 0};

bool check(int y, int x)
{
	return (y >= 0 && x >= 0 && y < n && x < m);
}

bool bfs()
{
	_(used, 0, 0);
	used[encode(st)][0][4] = true;
	q.push( mp(encode(st), mp(0, 4)) );

	while (!q.empty())
	{
		pair<int, pair<int, int>> cur = q.front();
		q.pop();

		pair<int, int> pos = decode(cur.first);

		if (a[pos.first][pos.second] == 0)
		{
			for (int k = 0; k < 4; k++)
				if (k != cur.second.second)
				{
					int ny = pos.first + dy[k];
					int nx = pos.second + dx[k];
					int enc = encode(ny, nx);
					if (check(ny, nx))
					{
						if (a[ny][nx] >= 1)
						{
							int p1 = (a[ny][nx] == 1) ? 1 : 0;
							if (!used[enc][p1][4])
							{
								used[enc][p1][4] = true;
								q.push( mp( enc, mp(p1, 4) ) );
							}
						}
					}
				}
		}
		else if (a[pos.first][pos.second] == 1)
		{
			if (cur.second.first == 1)
			{
				for (int k = 0; k < 4; k++)
				{
					int ny = pos.first + dy[k];
					int nx = pos.second + dx[k];
					int enc = encode(ny, nx);
					if (check(ny, nx))
					{
						if (a[ny][nx] >= 1)
						{
							int p1 = (a[ny][nx] == 1) ? 1 : 0;
							if (!used[enc][p1][4])
							{
								used[enc][p1][4] = true;
								q.push( mp( enc, mp(p1, 4) ) );
							}
						}
					}
				}
			}
			else
			{
				for (int k = 0; k < 4; k++)
				{
					int ny = pos.first + dy[k];
					int nx = pos.second + dx[k];
					int enc = encode(ny, nx);
					if (check(ny, nx))
					{
						int p2 = 0;
						if (k == 1)
							p2 = 3;
						else if (k == 3)
							p2 = 1;
						else if (k == 0)
							p2 = 2;
						if (!used[enc][0][p2])
						{
							used[enc][0][p2] = true;
							q.push( mp( enc, mp(0, p2) ) );
						}
					}
				}
			}
		}
		else
		{
			for (int k = 0; k < 4; k++)
				{
					int ny = pos.first + dy[k];
					int nx = pos.second + dx[k];
					int enc = encode(ny, nx);
					if (check(ny, nx))
					{
						if (!used[enc][0][4])
						{
							used[enc][0][4] = true;
							q.push( mp( enc, mp(0, 4) ) );
						}
					}
				}
		}
	}

	int een = encode(en);
	for (int i = 0; i < 2; i++)
		for (int j = 0; j < 5; j++)
			if (used[een][i][j])
				return true;

	return false;
}

bool solve()
{
	scanf("%d%d", &n, &m);
	for (int i = 0; i < n; i++)
	{
		scanf("%s", tmp);
		string s(tmp);
		for (int j = 0; j < s.size(); j++)
			s[j] -= '0';
		a.pb( s );
	}

	scanf("%d%d", &st.first, &st.second);
	scanf("%d%d", &en.first, &en.second);

	st.first--; st.second--;
	en.first--; en.second--;

	_(used, 0);

	if (bfs())
		printf("YES\n");
	else
		printf("NO\n");
	
	return false;
}

int main()
{
	prepare("islands");
	while (solve());
	return false;
}