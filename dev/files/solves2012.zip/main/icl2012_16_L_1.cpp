#include <iostream>
#include <sstream>
#include <stdio.h>
#include <cassert>
#include <memory.h>
#include <math.h>
#include <time.h>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <bitset>

using namespace std;

#define mp make_pair
#define pb push_back
#define all(a) (a).begin(),(a).end()
#define _(a,b) memset((a),b,sizeof(a))
#define sz(a) ((int)(a).size())

typedef long long lint;
typedef unsigned long long ull;
typedef pair < int , int > pii;

const int INF = 1000000000;
const lint LINF = 4000000000000000000LL;
const double eps = 1e-9;

void prepare(string s)
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
#else
	freopen((s + ".in").c_str(),"r",stdin);
	freopen((s + ".out").c_str(),"w",stdout);
#endif
}

struct Line
{
	double a,b,c;
	int id;
	Line(){}
	Line(int _id,double x1,double y1,double x2,double y2)
	{
		id = _id;
		a = y1 - y2;
		b = x2 - x1;
		c = -(x1 * a + y1 * b);
	}

	double det(double _a,double _b,double _c,double _d)
	{
		return _a * _d - _b * _c;
	}

	bool isIntersect(Line &oth,double &x,double &y)
	{
		double zn = det(a,b,oth.a,oth.b);
		if (fabs(zn) > eps)
		{
			x = -det(c,b,oth.c,oth.b) / zn;
			y = -det(a,c,oth.a,oth.c) / zn;
			return y > 0;
		}
		else
			return false;
	}
};

double dist(double dx, double dy)
{
	return sqrt(dx * dx + dy * dy);
}

vector < Line > st;
double ang;
int n;

bool solve()
{
	scanf("%d",&n);
	for (int i = 0; i < n; i ++)
	{
		scanf("%lf",&ang);
		Line cur = Line(i, i, 0, i + cos(ang), 0 + sin(ang));
		double x,y;
		bool ok = true;
		while (sz(st) > 0 && st.back().isIntersect(cur,x,y))
		{
			double d1,d2;
			d1 = dist(st.back().id - x, 0 - y);
			d2 = dist(i - x,0 - y);
			if (d1 > d2)
				st.pop_back();
			else
			{
				ok = false;
				break;
			}
		}
		if (ok)
			st.pb(cur);
	}
	printf("%d\n",sz(st));
	for (int i = 0; i < sz(st); i ++)
	{
		if (i) printf(" ");
		printf("%d",st[i].id + 1);
	}
	printf("\n");
	return false;
}

int main()
{
	prepare("race");
	while (solve());
	return 0;
}