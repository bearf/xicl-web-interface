#include<iostream>
#include<cmath>
#include<algorithm>
#include<set>
#include<map>
#include<vector>
#include<stack>
#include<queue>
#include<deque>
#include<list>
#include<string>
#include<cstring>
#include<cstdio>

#define PI 3.14159265358979323
#define EPS 1e-7

using namespace std;

int main(){
	freopen("cuts.in","rt",stdin);
	freopen("cuts.out","wt",stdout);
	int n,m;
	int a[33][33],c[33][33];
	memset(a,0,sizeof(a));
	memset(c,255,sizeof(c));
	int t=0;
	cin>>n>>m;
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			cin>>a[i][j];
			c[i][j]=t;
		}
	}
	for (int k=1;k<=n*m;){
		int x,y;
		for (int i=1;i<=n;i++){
			for (int j=1;j<=m;j++){
				if (a[i][j]==k){
					x=i;
					y=j;
					break;
				}
			}
		}
		vector <pair<vector<int>, int> > b;
		if (y>1 && c[x][y]==c[x][y-1]){
			vector <int> tmp;
			for (int i=1;i<=n;i++){
				if (c[i][y-1]==c[x][y]){
					tmp.push_back(a[i][y-1]);
				}
			}
			sort(tmp.begin(),tmp.end());
			if (tmp.size()>0) b.push_back(make_pair(tmp,0));
			tmp.clear();
			for (int i=1;i<x;i++){
				if (c[i][y]==c[x][y]){
					tmp.push_back(a[i][y]);
				}
			}
			for (int i=x+1;i<=n;i++){
				if (c[i][y]==c[x][y]){
					tmp.push_back(a[i][y]);
				}
			}
			sort(tmp.begin(),tmp.end());
			if (tmp.size()>0) b.push_back(make_pair(tmp,0));
		}
		if (y<m && c[x][y]==c[x][y+1]){
			vector <int> tmp;
			for (int i=0;i<=n;i++){
				if (c[i][y+1]==c[x][y]){
					tmp.push_back(a[i][y+1]);
				}
			}
			sort(tmp.begin(),tmp.end());
			if (tmp.size()>0) b.push_back(make_pair(tmp,1));
			tmp.clear();
			for (int i=0;i<x;i++){
				if (c[i][y]==c[x][y]){
					tmp.push_back(a[i][y]);
				}
			}
			for (int i=x+1;i<=n;i++){
				if (c[i][y]==c[x][y]){
					tmp.push_back(a[i][y]);
				}
			}
			sort(tmp.begin(),tmp.end());
			if (tmp.size()>0) b.push_back(make_pair(tmp,1));
		}
		if (x>1 && c[x][y]==c[x-1][y]){
			vector <int> tmp;
			for (int i=0;i<=m;i++){
				if (c[x-1][i]==c[x][y]){
					tmp.push_back(a[x-1][i]);
				}
			}
			sort(tmp.begin(),tmp.end());
			if (tmp.size()>0) b.push_back(make_pair(tmp,2));
			tmp.clear();
			for (int i=0;i<y;i++){
				if (c[x][i]==c[x][y]){
					tmp.push_back(a[x][i]);
				}
			}
			for (int i=y+1;i<=m;i++){
				if (c[x][i]==c[x][y]){
					tmp.push_back(a[x][i]);
				}
			}
			sort(tmp.begin(),tmp.end());
			if (tmp.size()>0) b.push_back(make_pair(tmp,2));
		}
		if (x<n && c[x][y]==c[x+1][y]){
			vector <int> tmp;
			for (int i=0;i<=m;i++){
				if (c[x+1][i]==c[x][y]){
					tmp.push_back(a[x+1][i]);
				}
			}
			sort(tmp.begin(),tmp.end());
			if (tmp.size()>0) b.push_back(make_pair(tmp,3));
			tmp.clear();
			for (int i=0;i<y;i++){
				if (c[x][i]==c[x][y]){
					tmp.push_back(a[x][i]);
				}
			}
			for (int i=y+1;i<=m;i++){
				if (c[x][i]==c[x][y]){
					tmp.push_back(a[x][i]);
				}
			}
			sort(tmp.begin(),tmp.end());
			if (tmp.size()>0) b.push_back(make_pair(tmp,3));
		}
		if (b.size()==0){
			cout<<t<<' ';
			k++;
		}
		else{
			sort(b.begin(),b.end());
			t++;
			if (b[0].second==0){
				for (int i=1;i<=n;i++){
					for (int j=1;j<y;j++){
						if (c[x][y]==c[i][j]){
							c[i][j]=t;
						}
					}
				}
			}
			if (b[0].second==1){
				for (int i=1;i<=n;i++){
					for (int j=y+1;j<=m;j++){
						if (c[x][y]==c[i][j]){
							c[i][j]=t;
						}
					}
				}
			}
			if (b[0].second==2){
				for (int i=1;i<x;i++){
					for (int j=1;j<=m;j++){
						if (c[x][y]==c[i][j]){
							c[i][j]=t;
						}
					}
				}
			}
			if (b[0].second==3){
				for (int i=x+1;i<=n;i++){
					for (int j=1;j<=m;j++){
						if (c[x][y]==c[i][j]){
							c[i][j]=t;
						}
					}
				}
			}
		}
	}
	return 0;

}