import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.StringTokenizer;
import java.util.Vector;

public class Solution {
	static class Car implements Comparable<Car> {
		double an;
		int id;

		public Car(double A, int I) {
			id = I;
			an = A;
		}

		double cool() {
			return Math.abs(an - Math.PI / 2.);
		}

		@Override
		public int compareTo(Car c) {
			if (cool() - c.cool() > eps)
				return 1;
			if (cool() - c.cool() < -eps)
				return -1;

			if (an > Math.PI / 2.)
				return c.id - id;
			else
				return id - c.id;
		}
	}

	static double eps = 1e-9;

	public static void main(String[] args) throws Exception {
		BufferedReader in = new BufferedReader(new FileReader("race.in"));
		PrintWriter out = new PrintWriter(new File("race.out"));

		int n = Integer.parseInt(in.readLine());

		StringTokenizer st = new StringTokenizer(in.readLine());

		Car[] c = new Car[n];

		for (int i = 0; i < n; i++) {
			double d = Double.parseDouble(st.nextToken());
			c[i] = new Car(d, i);
		}

		Arrays.sort(c);

		Car l = c[0], r = c[0];
		Vector<Car> vc = new Vector<Car>();
		vc.add(c[0]);
		for (int i = 1; i < c.length; i++) {
			if (c[i].id > r.id) {
				if (c[i].an < r.an + eps) {
					r = c[i];
					vc.add(c[i]);
				}
			} else if (c[i].id < l.id) {
				if (c[i].an > l.an - eps) {
					l = c[i];
					vc.add(c[i]);
				}
			}
		}

		out.println(vc.size());
		for (Car cc : vc)
			out.print((cc.id + 1) + " ");

		out.close();
	}
}
