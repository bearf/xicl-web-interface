#include <cstdio>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <iostream>
#include <cmath>

using namespace std;

#pragma comment(linker, "/STACK:160000000")

const int INF = (int) 1e9;
const double EPS = 1e-8;
const double PI = acos(-1.);

typedef pair<int, int> pii;
typedef long long ll;

#define NAME "ice"

struct point
{
	ll x, y;
	point(){}
	point(ll _x, ll _y)
	{
		x = _x;
		y = _y;
	}
	void scan()
	{
		scanf("%lld%lld", &x, &y);
	}
};

const int TREESIZE = 1 << 24;

struct IntervalTree
{
	int tree[TREESIZE * 2];
	void init()
	{
		memset(tree, 0xff, sizeof(tree));
	}
	void push(int pos)
	{
		if (tree[pos] != -1 && pos < TREESIZE)
		{
			tree[pos*2] = tree[pos*2+1] = tree[pos];
			tree[pos] = -1;
		}
	}
	void push()
	{
		for (int i = 0; i < TREESIZE; ++i)
		{
			push(i);
		}
	}
	void set(int l, int r, int val)
	{
		if (l >= r) return;
//cerr <<l<<" "<<r<<endl;
		set(l, r, 0, TREESIZE, 1, val);
	}
	void set(int l, int r, int from, int to, int pos, int val)
	{
		if (l == from && r == to)
		{
			tree[pos] = val;
			return;
		}
		int m = (from + to) / 2;
		push(pos);
		if (m <= l)
		{
			set(l, r, m, to, pos*2+1, val);
			return;
		}
		if (r <= m)
		{
			set(l, r, from, m, pos*2, val);
			return;
		}
		set(l, m, from, m, pos*2, val);
		set(m, r, m, to, pos*2+1, val);
	}
} I;
point C[40400];
ll R[40400];
int V[40400];
bool cmp(int a, int b)
{
	return C[a].y < C[b].y;
}
double X[10001000];
int main()
{
	freopen (NAME".in", "r", stdin);
	freopen (NAME".out", "w", stdout);
	I.init();
	int N, M;
	scanf ("%d%d", &N, &M);
	for (int i = 0; i < M; ++i)
	{
		C[i].scan();
		scanf ("%lld", &R[i]);
		V[i] = i;
	}
	sort(V, V + M, cmp);
	for (int ii = 0; ii < M; ++ii)
	{
		int i = V[ii];
		I.set(max(C[i].x - R[i], 0ll), min(C[i].x + R[i], ll(N)) + 1, i);
	}
	I.push();
	double H = C[V[M-1]].y + R[M-1];
	for (int i = 0; i <= N; ++i)
	{
		int nm = I.tree[i + TREESIZE];
		if (nm == -1)
		{
			X[i] = 1e18;
		}
		else
		{
			ll d = C[nm].x - i;
			X[i] = H - sqrt(fabs(1.*R[nm]*R[nm] - d*d)) - C[nm].y;
		}
	}
	double ans = 0;
	int cnt = 0;
	double T = 1e18;
	for (int i = 0; i < N; ++i)
	{
		X[i] = min(X[i], X[i + 1]);
		T = min(X[i], T);
	}
	for (int i = 0; i < N; ++i)
	{
		if (X[i] < 1e17)
		{
			ans += X[i] - T;
			++cnt;
		}
	}
//	cerr << cnt;
	printf("%.9lf", ans/cnt);
	return 0;
}