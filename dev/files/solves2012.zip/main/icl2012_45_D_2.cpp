#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>
using namespace std;

#define TASK_NAME "millenium"

map<int,int> q;

int main () {

#ifdef INPUT_VAR
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#else
	freopen(TASK_NAME ".in", "rt", stdin);
	freopen(TASK_NAME ".out", "wt", stdout);
#endif
	int n,a,b;
	scanf("%d%d%d",&n,&a,&b);
	for (int i=0;i<n;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		q[x]++;
	}
	int curout=0;
	int last=0;
	for (map<int,int>::iterator i=q.begin();i!=q.end();i++)
	{
		int cur=(*i).first;
		curout-=(cur-last-1)*b;
		curout=max(0,curout);
		last=cur;
		int x=(*i).second;
		x+=curout;
		x-=b;
		curout=max(x,0);
	}
	last+=(curout+b-1)/b;
	printf("%d",last);


	return 0;
}