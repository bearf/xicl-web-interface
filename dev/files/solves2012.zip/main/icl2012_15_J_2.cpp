#include <iostream>
#include <sstream>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <vector>
#include <string>
#include <ctime>
using namespace std;
#pragma comment(linker, "/STACK:30000000")

int n, m;
int startX, startY, finishX, finishY;
int dx [] = {0, -1, 0, +1};
int dy [] = {+1, 0, -1, 0};
bool ans;
vector<vector<int> > briges;
vector<vector<vector<vector<int> > > > used;

bool niceKor (int x, int y)
{
	if (x >= 1 && x <= n && y >= 1 && y <= m)
		return true;
	else
		return false;
}

void DFS (int x, int y, int predX, int predY, int last)  //last = 1 - ���� ������� ������
{
	if (x == finishX && y == finishY)
	{
		ans = 1;
		return;
	}
	
	for (int i = 0; i < 4; i++)
	{
		if (used [x][y][i][last] == 1)
			continue;
		used [x][y][i][last] = 1;

		int nextX = x + dx [i];
		int nextY = y + dy [i];

		if (!niceKor(nextX, nextY))
			continue;

		if (nextX == predX && nextY == predY)
		{
			if (briges [nextX][nextY] + briges [x][y] < 2)
				continue;

			int locBrig = briges [x][y];
			if (last == 0)  //���� �� ����
				locBrig--;

			if (locBrig > 0)
				DFS (nextX, nextY, x, y, 1);
			else
				DFS (nextX, nextY, x, y, 0);
		}
		else
		{
			int locBriges = briges [x][y];
			if (last == 0)
				locBriges--;
			int nextBriges = briges [nextX][nextY];
			
			int sum = locBriges + nextBriges;
			if (sum <= 0)
				continue;

			if (locBriges >= 1)
				DFS (nextX, nextY, x, y, 1);
			else
				DFS (nextX, nextY, x, y, 0);
		}
	}
}

int main()
{
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	freopen("islands.in", "r", stdin); freopen("islands.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	getchar();
	briges.resize(n + 1, vector<int>(m + 1));
	for (int x = 1; x <= n; x++)
	{
		for (int y = 1; y <= m; y++)
		{
			char c;
			scanf("%c", &c);
			briges[x][y] = c - '0';
		}
		getchar();
	}
	used.resize(n + 1, vector<vector<vector<int> > >(m + 1, vector<vector<int> >(4, vector<int>(2))));
	
	scanf("%d%d", &startX, &startY);
	scanf("%d%d", &finishX, &finishY);

	DFS (startX, startY, -1, -1, 1);
	
	if (ans)
		puts("YES");
	else
		puts("NO");

	return 0;
}
