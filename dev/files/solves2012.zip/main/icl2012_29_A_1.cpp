#include <cstdio>
#include <set>

using namespace std;

int n, k;
set<pair<int,int> > st;

int main()
{
	freopen("bricks.in", "r", stdin);
	freopen("bricks.out", "w", stdout);
	scanf("%d%d", &n, &k);
	for (int i = 0; i < k; i++)
	{
		int l, p;
		scanf("%d%d", &l, &p);
		if (l > 1)
		{
			if (p > 1)
			{
				if (st.count(make_pair(l-1, p-1)) == 0 &&
					st.count(make_pair(l, p-1)) == 1 )
				{
					printf("%d\n", i+1);
					exit(0);
				}
			}
			if (p < l)
			{
				if (st.count(make_pair(l-1, p)) == 0 &&
					st.count(make_pair(l, p+1)) == 1 )
				{
					printf("%d\n", i+1);
					exit(0);
				}
			}
		}
		st.insert(make_pair(l, p));
	}
	printf("-1\n");
	return 0;
}