#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>
using namespace std;

#define TASK_NAME "bricks"

set < pair < int , int > > sMet, sDel;
int n, m;

bool del (int row, int col) {
	int rowNew, colNew;

	if (row != 1) {
		rowNew = row - 1;

		colNew = col - 1;
		if (colNew >= 1 && colNew <= rowNew)
			if (sMet.find(make_pair(rowNew, colNew)) != sMet.end() && sDel.find(make_pair(rowNew, colNew)) == sDel.end())
				return true;

		colNew = col;
		if (colNew >= 1 && colNew <= rowNew)
			if (sMet.find(make_pair(rowNew, colNew)) != sMet.end() && sDel.find(make_pair(rowNew, colNew)) == sDel.end())
				return true;

		colNew = col - 1;
		if (colNew >= 1 && colNew <= rowNew && sDel.find(make_pair(rowNew, colNew)) == sDel.end())
			sMet.insert(make_pair(rowNew, colNew));

		colNew = col;
		if (colNew >= 1 && colNew <= rowNew && sDel.find(make_pair(rowNew, colNew)) == sDel.end())
			sMet.insert(make_pair(rowNew, colNew));
	}

	sDel.insert(make_pair(row, col));

	return false;
}

int main () {

#ifdef INPUT_VAR
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#else
	freopen(TASK_NAME ".in", "rt", stdin);
	freopen(TASK_NAME ".out", "wt", stdout);
#endif

	int i, k1, k2;

	scanf("%d%d", &n, &m);

	for (i = 0;i < m;i++) {
		scanf("%d%d", &k1, &k2);
		if (del(k1, k2)) {
			printf("%d", i + 1);
			return 0;
		}
	}

	printf("-1");

	return 0;
}