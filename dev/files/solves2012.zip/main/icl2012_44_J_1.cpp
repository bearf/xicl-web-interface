#include <cstdio>
#include <cstring>
#include <cmath>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <iostream>
#include <fstream>
#include <set>

#define mp make_pair
#define pb push_back
#define zero(a) memset(a, 0, sizeof(a))
#define SZ(a) ((int)(a.size()))
#define sqr(a) ((a)*(a))
                
typedef long long ll;
typedef long double ld;

#define taskname "islands"

using namespace std;


int n,m;

vector<char> s[110000];

vector<bool> used[110000][2];

const int dx[4] = {0,1,0,-1};
const int dy[4] = {1,0,-1,0};

bool good(int x,int y){
	return 0 <= x && x < n && 0 <= y && y < m;
}


bool dfs(int x,int y,int tox,int toy,int q){
	if (q > s[x][y] - '0')
		return false;
	if (used[x][q][y])
		return false;
	if (x == tox && y == toy)
		return true;
	used[x][q][y] = true;
	for (int i = 0; i < 4; i++)
		if (good(x+dx[i],y+dy[i]))
			if (dfs(x+dx[i],y+dy[i],tox,toy,q == s[x][y]-'0'))
				return true;
	return false;
}

int main (void)
{
  freopen (taskname".in", "rt", stdin);
  freopen (taskname".out", "wt", stdout);

  scanf("%d %d",&n,&m);

  for (int i = 0; i < n; i++){
  	s[i].resize(m);
  	used[i][0].resize(m);
  	used[i][1].resize(m);
  	for (int j = 0; j < m; j++){
  		scanf(" %c",&s[i][j]);
  	}

  }

  int x,y;
  int tox,toy;

  scanf("%d %d %d %d",&x,&y,&tox,&toy);
  --x,--y,--tox,--toy;

  if (dfs(x,y,tox,toy,0))
  	printf("YES\n");
  else
  	printf("NO\n");

  return 0;
}


