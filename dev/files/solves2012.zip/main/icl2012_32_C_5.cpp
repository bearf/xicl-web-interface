#include <cstdlib>
#include <cstdio>
#include <map>
#include <iostream>
#include <vector>
#include <set>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int) n; ++i)
#define seta(a, b) memset(a, b, sizeof(a))
#define fs first;
#define sc second
#define mp make_pair
#define pb push_back
typedef pair <int, int> pii;

const int NMAX = 10000010;
const int MMAX = 50001;

struct TC
{
	int x, y, r;
	TC() {}
};

bool operator <(const TC &a, const TC &b)
{
	return a.y < b.y;
}

int n, m, lvl, cnt;
double ans = 0, tmin;
TC c[MMAX];
vector <int> zn[NMAX];
set <int> S;

double cross(int now, int pos)
{
	if (fabs(pos - c[now].x) > c[now].r + 1e-8) return 1e100;
	return lvl - c[now].y - sqrt(fabs((double) c[now].r * c[now].r - (double) (pos - c[now].x) * (pos - c[now].x)));
}

int main()
{
	freopen("ice.in", "r", stdin);
	freopen("ice.out", "w", stdout);

//	cout << 10000000 << " " << 40000 << endl;
//	forn(i, 40000)
//		cout << rand()%30000 - 15000 << " " << rand()%30000 - 15000 << " " << rand()%30000 << endl;
//	return 0;	

	cin >> n >> m;
	forn(i, m)
	{
		scanf("%d%d%d", &c[i].x, &c[i].y, &c[i].r);
	}
	sort(c, c + m);
	reverse(c, c + m);
	lvl = c[0].y + c[0].r;
	forn(i, m)
	{
		lvl = max(lvl, c[i].y + c[i].r);
		zn[max(0, min(c[i].x - c[i].r - 1, n))].pb(i + 1);
		zn[min(n, max(c[i].x + c[i].r + 1, 0))].pb(- i - 1);
	}

	cerr << clock() << endl;
	S.clear();
	ans = 0, cnt = 0, tmin = 1e10;
	forn(i, n)
	{
		forn(j, zn[i].size())
			if (zn[i][j] > 0)
				S.insert(zn[i][j] - 1);
			else
				S.erase(- 1 - zn[i][j]);
		if (S.size() > 0) 
		{
			cnt++;
			double now = min(cross(*S.begin(), i), cross(*S.begin(), i + 1));
			tmin = min(tmin, now);
			ans += now;
		}
	}
	printf("%.10lf\n", (ans - cnt * tmin) / (cnt + 1));

	return 0;
}
