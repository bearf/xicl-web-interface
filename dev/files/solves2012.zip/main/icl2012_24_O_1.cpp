#include <stdio.h>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

#define mp make_pair
#define pb push_back

typedef long long li;
typedef double ld;

#define FILE "darts"
void solve();
int main()
{
#ifdef _DEBUG
	freopen ("in.txt", "r", stdin);
	cout<<FILE<<endl;
#else
	freopen (FILE ".in", "r", stdin);
	freopen (FILE ".out", "w", stdout);
#endif
	int t=1;
	while (t--)
		solve();
	return 0;
}

//#define int li

int n, m;
int k;

vector < int > v, h;
map < int, int > segs;

void solve()
{
	cin>>n>>m>>k;
	for (int i=0; i<k; i++)
	{
		int q, w;
		cin>>q>>w;
		v.pb(q);
		h.pb(w);
	}
	v.pb(0);
	h.pb(0);
	v.pb(n);
	h.pb(m);
	sort (v.begin(), v.end());
	v.resize( unique(v.begin(), v.end()) - v.begin() );
	sort (h.begin(), h.end());
	h.resize( unique(h.begin(), h.end()) - h.begin() );
	//cout<<v.size()<<' '<<h.size()<<endl;
	for (int i=0; i<v.size(); i++)
		for (int j=i+1; j<v.size(); j++)
			segs[v[j]-v[i]]++;
	int ans=0;
	for (int i=0; i<h.size(); i++)
		for (int j=0; j<h.size(); j++)
		{
			map <int, int>::iterator l=segs.find(h[j]-h[i]);
			if (l!=segs.end())
				ans+=l->second;
		}
	cout<<ans;
}