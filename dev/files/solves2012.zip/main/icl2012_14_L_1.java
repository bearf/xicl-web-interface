import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class Solution {
	private static final String TASKNAME = "race";
	private static final double EPS = 1e-7;

	class Inter implements Comparable<Inter> {
		double time;
		int a, b, who;

		public Inter(double time, int a, int b, int who) {
			this.time = time;
			this.a = a;
			this.b = b;
			this.who = who;
		}

		@Override
		public int compareTo(Inter that) {
			double d = this.time - that.time;
			if (d == 0) {
				if (a == that.a) {
					return b - that.b;
				}
				return a - that.a;
			}
			return d < 0 ? -1 : 1;
		}
	}

	private void solve() throws IOException {
		int n = nextInt();
		double[] x1 = new double[n];
		double[] y1 = new double[n];
		double[] x2 = new double[n];
		double[] y2 = new double[n];
		for (int i = 0; i < n; ++i) {
			x1[i] = i;
			y1[i] = 0;
			double ang = nextDouble();
			x2[i] = x1[i] + Math.cos(ang);
			y2[i] = y1[i] + Math.sin(ang);
		}

		TreeSet<Integer> remain = new TreeSet<Integer>();
		for (int i = 0; i < n; ++i) {
			remain.add(i);
		}
		boolean[] dead = new boolean[n];
		TreeSet<Inter> inters = new TreeSet<Solution.Inter>();
		for (int i = 0; i + 1 < n; ++i) {
			Inter inter = getInter(x1, y1, x2, y2, i, i + 1);
			if (inter != null) {
				inters.add(inter);
			}
		}

		while (!inters.isEmpty()) {
			Inter inter = inters.first();
			inters.remove(inter);
			if (dead[inter.a] || dead[inter.b]) {
				continue;
			}
//			System.err.println(inter.a + " " + inter.b + " " + inter.time + " " + inter.who);
			dead[inter.who] = true;
			remain.remove(inter.who);
			Integer less = remain.floor(inter.who);
			Integer higher = remain.ceiling(inter.who);
			if (less != null && higher != null) {
				inters.add(getInter(x1, y1, x2, y2, less, higher));
			}
		}

		ArrayList<Integer> ans = new ArrayList<Integer>();
		for (int i = 0; i < n; ++i) {
			if (!dead[i]) {
				ans.add(i + 1);
			}
		}

		println(ans.size());
		for (int i : ans) {
			print(i + " ");
		}
		println("");
	}

	private Inter getInter(double[] x1, double[] y1, double[] x2, double[] y2,
			int i, int j) {
		double a1 = y1[i] - y2[i];
		double b1 = x2[i] - x1[i];
		double c1 = -(x1[i] * a1 + y1[i] * b1);

		double a2 = y1[j] - y2[j];
		double b2 = x2[j] - x1[j];
		double c2 = -(a2 * x1[j] + b2 * y1[j]);

		double det = a1 * b2 - a2 * b1;
		if (Math.abs(det) < EPS) {
			return null;
		}

		double x = (b1 * c2 - b2 * c1) / det;
		double y = -(a1 * c2 - a2 * c1) / det;
		
		if (y <= EPS) {
			return null;
		}

		double d1 = sq(x - x1[i]) + sq(y - y1[i]);
		double d2 = sq(x - x1[j]) + sq(y - y1[j]);
//		System.err.println("inter " + i + " " + j + " : " +x + " " + y + " " + d1 + " " + d2);
//		System.err.println((a1 * x + b1 * y + c1) + " " + (a2 * x + b2 * y + c2));
		return new Inter(Math.max(d1, d2), i, j, d1 > d2 ? i : j);
	}

	private double sq(double d) {
		return d * d;
	}

	public static void main(String[] args) {
		long time = System.currentTimeMillis();
		Locale.setDefault(Locale.US);
		new Solution().run();
		System.err.printf("%.3f\n", 1e-3 * (System.currentTimeMillis() - time));
	}

	private StringTokenizer tokenizer;
	private BufferedReader reader;
	private PrintWriter writer;

	private String nextToken() throws IOException {
		while (tokenizer == null || !tokenizer.hasMoreTokens()) {
			tokenizer = new StringTokenizer(reader.readLine());
		}
		return tokenizer.nextToken();
	}

	private int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	private long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	private double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	private void print(Object o) {
		writer.print(o);
	}

	private void println(Object o) {
		writer.println(o);
	}

	private void printf(String format, Object... o) {
		writer.printf(format, o);
	}

	private void run() {
		try {
			reader = new BufferedReader(new FileReader(TASKNAME + ".in"));
			writer = new PrintWriter(TASKNAME + ".out");

			solve();

			reader.close();
			writer.close();

		} catch (IOException e) {
			e.printStackTrace();
			System.exit(13);
		}
	}
}
