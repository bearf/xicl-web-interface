#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <ctime>
#include <cmath>

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define fs first
#define sc second
#define len(x) ((int) (x).size())
#define last(x) (x)[(len(x)-1)]
#define plast(x) (x)[(len(x)-2)]
#define sqr(x) ((x)*(x))
#define foreach(i, x) for (__typeof((x).begin()) i = (x).begin(); i != (x).end(); ++i)
#define forn(i, n) for (int i = 0; i < int(n); ++i)

using namespace std;

typedef long double ld;
typedef unsigned long long int64;

int a[100100];
int n, k;

int gcd(int a, int b) {
	return (a ? gcd(b % a, a) : b);
}

int64 solve(int d) {
	return int64((a[0] + 1) / d) * int64((n - a[k - 1]) / d);
}

int main() {
	freopen("trees.in", "r", stdin);
	freopen("trees.out", "w", stdout);
	cin >> n >> k;
	forn (i, k) {
		cin >> a[i];
		--a[i];
	}
	if (k == 1) {
		int x = a[0], y = n - a[0] - 1;
		vector<pair<pair<int, int>, bool> > av;
		for (int i = 1; i * i <= 100 * x; ++i) {
			av.pb(mp(mp(i, x / i), 0));
			int h = (x / i) + bool(x % i);
			if (x / h == i) {
				av.pb(mp(mp(h, i), 0));
			}	
		}
		av.pb(mp(mp(x + 1, 0), 0));
		for (int i = 1; i * i <= 100 * y; ++i) {
			av.pb(mp(mp(i, y / i), 1));
			int h = (y / i) + bool(y % i);
			if (y / h == i) {
				av.pb(mp(mp(h, i), 1));
			}	
		}
		av.pb(mp(mp(y + 1, 0), 1));
		sort(av.begin(), av.end());
		forn (i, av.size()) {
			cerr << av[i].fs.fs << " " << av[i].fs.sc << " " << av[i].sc << endl;
		}
		int64 ans = 1;
		int l = -1, c = 0;
		forn (i, av.size()) {
			if (av[i].sc) {
				if (l != -1) {
					ans += (av[i].fs.fs - l) * c;
				}
				c = av[i].fs.sc;
				l = av[i].fs.fs;
			}
		}
		cerr << ans << endl;
		l = -1;
		c = 0;
		forn (i, av.size()) {
			if (!av[i].sc) {
				if (l != -1) {
					ans += (av[i].fs.fs - l) * c;
				}
				c = av[i].fs.sc;
				l = av[i].fs.fs;
			}
		}
		cerr << ans << endl;
		int c1 = 0, c2 = 0;
		l = 0;
		forn (i, av.size()) {
//			cerr << av[i].fs.fs << " " << av[i].fs.sc << " " << av[i].sc << endl;
			if (i) {
//				cerr << av[i].fs.fs - av[i - 1].fs.fs << " " << c1 << " " << c2 << "!" << endl;
				ans += int64(av[i].fs.fs - av[i - 1].fs.fs) * c1 * c2;
			}
			if (av[i].sc) {
				c2 = av[i].fs.sc;
			} else {
				c1 = av[i].fs.sc;
			}
		}
		cout << ans;
		return 0;
	}
	int g = a[1] - a[0];
	for (int i = 1; i < k - 1; ++i) {
		g = gcd(g, a[i + 1] - a[i]);
	}
	int64 ans = 0;
	for (int d = 1; d * d <= g; ++d) {
		ans += solve(d);
		if (d * d != g) {
			ans += solve(d);
		}
	}
	cout << ans;
	return 0;
}
