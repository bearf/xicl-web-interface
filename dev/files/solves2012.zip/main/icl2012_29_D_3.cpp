#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#include <map>


#pragma comment(linker,"/STACK:146000000")


using namespace std;


vector<int> v;



int main()
{
	freopen("millenium.in","r",stdin);
	freopen("millenium.out","w",stdout);
	int n, a, b;
	scanf("%d%d%d", &n, &a, &b);
	for(int i = 0; i < n; i++)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		v.push_back(x);
	}
	sort(v.begin(), v.end());
	int t = 0;
	int cur = 0;
	while(cur < n)
	{                     
		t = max(t, v[cur]);
		//("%d\n", t);
		int left = b;
		while(cur < n && v[cur] <= t && left > 0)
		{
			cur++;
			left--;
		}
		t++;
	}
	printf("%d", t - 1);
}