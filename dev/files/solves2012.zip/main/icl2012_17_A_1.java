import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.StringTokenizer;
import java.util.TreeSet;


public class Solution implements Runnable {

	public static void main(String[] args) throws IOException {
		new Solution().run();
	}

	StringTokenizer in;
	BufferedReader br;
	PrintWriter out;

	public String nextToken() throws IOException {
		while (in == null || !in.hasMoreTokens()) {
			in = new StringTokenizer(br.readLine());
		}
		return in.nextToken();
	}

	public int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	static class Point implements Comparable<Point> {
		int x, y;

		public Point(int x, int y) {
			this.x = x;
			this.y = y;
		}

		@Override
		public int compareTo(Point e) {
			// TODO Auto-generated method stub
			return e.x == x && e.y == y ? 0 : x < e.x ? -1 : x > e.x ? 1 : y < e.y ? -1 : 1;			
		}
	}

	public void solve() throws IOException {
		int n = nextInt(), k = nextInt();
		TreeSet<Point> tree = new TreeSet<Point>();
		for (int i=  0; i < n; i++){
			int x = nextInt(), y = nextInt();
			tree.add(new Point(x, y));
			if (tree.contains(new Point(x, y-1))){
				if (!tree.contains(new Point(x - 1, y - 1))){
					out.print(i + 1);
					return;
				}
			}
			if (tree.contains(new Point(x, y+1))){
				if (!tree.contains(new Point(x - 1, y))){
					out.print(i + 1);
					return;
				}
			}
		}
		out.print("-1");
	}

	@Override
	public void run() {
		try {
			 br = new BufferedReader(new FileReader("bricks.in"));
//			br = new BufferedReader(new InputStreamReader(System.in));
			 out = new PrintWriter(new File("bricks.out"));
//			out = new PrintWriter(new OutputStreamWriter(System.out));
			solve();
			br.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

}
