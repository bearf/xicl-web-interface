#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cassert>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <string>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define _(a, b) memset(a, b, sizeof(a))

typedef long long lint;
typedef unsigned long long ull;

const int INF = 1000000000;
const lint LINF = 4000000000000000000ll;
const double eps = 1e-6;

void prepare(string file)
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#else
	freopen((file + ".in").c_str(), "r", stdin);
	freopen((file + ".out").c_str(), "w", stdout);
#endif
}

int n;
double a[100005];
double b[100005];

vector< pair<double, int> > p[2];

const double pi = atan(1.0) * 4.0;
const double pi2 = atan(1.0) * 2.0;


bool solve()
{
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		scanf("%lf", &a[i]);

	int need = 0;
	for (int i = 1; i < n; i++)
		if (fabs(a[i] - pi2) < fabs(a[need] - pi2))
			need = i;

	for (int i = 0; i < n; i++)
		b[i] = fabs(a[i] - pi2);

	vector< pair<double, int> > right;
	right.pb( mp( a[need], need  ));
	for (int i = need + 1; i < n; i++)
	{
		while (right.size() >= 1 && fabs(right[right.size() - 1].first - pi2) > fabs(a[i] - pi2) + eps)
			right.pop_back();
		if (right[right.size() - 1].first + eps > a[i])
			right.push_back( mp(a[i], i) );
	}

	vector< pair<double, int> > left;
	left.pb( mp(a[need], need ));
	for (int i = need - 1; i >= 0; i--)
	{
		while (left.size() >= 1 && fabs(left[left.size() - 1].first - pi2) > fabs(a[i] - pi2) + eps)
			left.pop_back();
		if (left[left.size() - 1].first < a[i] + eps)
			left.push_back( mp(a[i], i) );
	}

	vector<int> ans;
	for (int i = 0; i < left.size(); i++)
		ans.pb(left[i].second);
	for (int i = 0; i < right.size(); i++)
		ans.pb(right[i].second);

	sort(ans.begin(), ans.end());
	ans.resize(unique(ans.begin(), ans.end()) - ans.begin());
	
	printf("%d\n", ans.size());
	for (int i = 0; i < ans.size(); i++)
		printf("%d ", ans[i] + 1);
	printf("\n");

	return false;
}

int main()
{
	prepare("race");
	while (solve());
	return false;
}