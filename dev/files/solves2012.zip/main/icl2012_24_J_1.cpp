#include <stdio.h>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#include <math.h>

using namespace std;

#define pi 3.14159265358979323846

#define mp make_pair
#define pb push_back
#define all(a) a.begin(),a.end()

typedef long long li;
typedef double ld;

#define FILE "islands"
void solve();
int main()
{
#ifdef _DEBUG
	freopen ("in.txt", "r", stdin);
	cout<<FILE<<endl;
#else
	freopen (FILE ".in", "r", stdin);
	freopen (FILE ".out", "w", stdout);
#endif
	int t=1;
	while (t--)
		solve();
	return 0;
}

//#define int li

int n, m;
vector < vector <int> > matrix;

vector <vector < vector <int> > > was;

void dfs( pair <int, int> cur, int num )
{
	if (was[cur.first][cur.second][num])
		return;
	was[cur.first][cur.second][num]=1;
	if (cur.first>0)
	{
		pair <int, int> now=mp(cur.first-1, cur.second);
		if (num>0)
			dfs( now, matrix[now.first][now.second] );
		if (matrix[now.first][now.second]>0)
			dfs( now, matrix[now.first][now.second]-1 );
	}
	if (cur.first<n-1)
	{
		pair <int, int> now=mp(cur.first+1, cur.second);
		if (num>0)
			dfs( now, matrix[now.first][now.second] );
		if (matrix[now.first][now.second]>0)
			dfs( now, matrix[now.first][now.second]-1 );
	}
	if (cur.second>0)
	{
		pair <int, int> now=mp(cur.first, cur.second-1);
		if (num>0)
			dfs( now, matrix[now.first][now.second] );
		if (matrix[now.first][now.second]>0)
			dfs( now, matrix[now.first][now.second]-1 );
	}
	if (cur.second<m-1)
	{
		pair <int, int> now=mp(cur.first, cur.second+1);
		if (num>0)
			dfs( now, matrix[now.first][now.second] );
		if (matrix[now.first][now.second]>0)
			dfs( now, matrix[now.first][now.second]-1 );
	}
}

void solve()
{
	cin>>n>>m;
	matrix.resize(n);
	for (int i=0; i<n; i++)
		matrix[i].resize(m);
	was.resize(n);
	for (int i=0; i<n; i++)
		was[i].resize(m);
	for (int i=0; i<n; i++)
		for (int j=0; j<m; j++)
			was[i][j].resize(3);
	for (int i=0; i<n; i++)
		for (int j=0; j<m; j++)
		{
			scanf ("%1d", &matrix[i][j]);
			if (matrix[i][j]>2)
				matrix[i][j]=2;
		}
	pair <int, int> beg, en;
	cin>>beg.first>>beg.second;
	cin>>en.first>>en.second;
	beg.first--; beg.second--;
	en.first--; en.second--;
	dfs(beg, matrix[beg.first][beg.second]);
	bool f=false;
	for (int i=0; i<3; i++)
		f|=was[en.first][en.second][i];
	if (f)
		cout<<"YES";
	else
		cout<<"NO";
}