 #include <fstream>
#include <algorithm>
#define _USE_MATH_DEFINES
#include <math.h>
#include <vector>
using namespace std;
struct str
{
	int n;
	double v;
	str ()
	{
		n=0;
		v=0; 
	}
	str (int q, double vv)
	{
		n=q;
		v=vv;
	}
	bool operator > (str b)
	{
		return v>b.v;
	}
	bool operator ==(str b)
	{
		return v==b.v;
	}
};
vector <str> a;
int search(str b)
{
	int l=0;
	int r=a.size()-1;
	while (l<r)
	{
		int c=(l+r)/2;
		if (a[c]>b)
			r=c;
		else
			l=c+1;
	}
	while (l<a.size()&&b==a[l])
		l++;
	if (l==a.size()||b>a[l]) 
		return -1;
	return l;
}
void main()
{
	int n;
	ifstream cin("race.in");
	cin>>n;
	double q;
	str b;
	for (int i=0;i<n;i++)
	{
		cin>>q;
		b.v=M_PI-q;
		b.n=i+1;
		int pos1=search(b);
		if (pos1==-1)
		{
			a.push_back(b);
			continue;
		}
		int pos2=search(str(i+1,q));
		if (pos2>=0)
			a.erase(a.begin()+pos2,a.end());
		if (pos2==pos1)
			a.push_back(b);
	}
	cin.close();
	ofstream cout("race.out");
	cout<<a.size()<<endl;
	for (int i=0;i<a.size();i++)
		cout<<a[i].n<<' ';
	cout.close();
}