#include <cstdlib>
#include <cstdio>
#include <map>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <ctime>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int) n; ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; i--)
#define fs first
#define sc second
#define mp make_pair
#define all(x) x.begin(), x.end()
#define pb push_back

typedef long long int64;
typedef pair <int, int> pii;


const int nmax = 10100;

typedef pair<int, int> pii;

int n;
int a[nmax], b[nmax], cur[nmax];
set<pii> h, w;
vector<int> res;

void write(){
	cout << res.size() << endl;
	forn(i, res.size()){
		printf("%d", res[i] + 1);
		if (i + 1 < (int)res.size())
			printf(" ");
		else
			puts("");
	}
	exit(0);
}

void no(){
	puts("-1");
	exit(0);
}

int main()
{
	freopen("changes.in", "r", stdin);
	freopen("changes.out", "w", stdout);

	cin >> n;
	forn(i, n)
		scanf("%d", &a[i]);
	forn(i, n)
		scanf("%d", &b[i]);
	forn(i, n){
		if (a[i] < b[i]){
			h.insert(mp(a[i], i));
		} else {
			w.insert(mp(a[i] - b[i], i));
		}
		cur[i] = a[i];
	}

	int step = 0;
	forn(i, 1000000){
		if (step == 10000) step -= 10000;
		if (step == 0 && 1.0 * clock() / CLOCKS_PER_SEC > 1.8)
			no();
		step ++;
		while (((int)w.size() > 0) && ((w.begin() -> fs) == i - 1)){
			int pos = w.begin() -> sc;
			w.erase(w.begin());
			h.insert(mp(cur[pos] - i, pos));
		}
//		cerr << h.size() << " " << w.size() << endl;
//		forn(j, n)
//			cerr << cur[j] - i << " ";
//		cerr << endl;
		if (h.size() == 0)
			write();
		int pos = h.begin() -> sc;
		h.erase(h.begin());
		if (cur[pos] < i)
			no();
		res.pb(pos);
		cur[pos] += n;
//		cerr << pos << " " << b[pos] << " " << cur[pos] << " " << i + 1 << endl;
		if (cur[pos] - i - 1< b[pos]){
			h.insert(mp(b[pos] - cur[pos] - i - 1, pos));
		} else {
			w.insert(mp(cur[pos] - b[pos], pos));
		}
	}
	no();

	
	return 0;
}
