#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <ctime>
#include <cmath>

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define fs first
#define sc second
#define len(x) ((int) (x).size())
#define last(x) (x)[(len(x)-1)]
#define plast(x) (x)[(len(x)-2)]
#define sqr(x) ((x)*(x))
#define foreach(i, x) for (__typeof((x).begin()) i = (x).begin(); i != (x).end(); ++i)

using namespace std;

typedef long long int64;
typedef long double ld;
typedef unsigned long long lint;
typedef pair<int, int> vc;

int n;
vector<vc> a;

int main(){
	freopen("wire.in", "r", stdin);
	freopen("wire.out", "w", stdout);
	cin >> n; a.resize(n);
	for (int i = 0; i < n; i++)
		cin >> a[i].fs >> a[i].sc;
	int res = 0;
	for (int i = 0; i < n-2; i++){
		int x1 = a[i+1].fs - a[i].fs, x2 = a[i+2].fs - a[i+1].fs;
		int y1 = a[i+1].sc - a[i].sc, y2 = a[i+2].sc - a[i+1].sc;
		if (x1 * x2 + y1 * y2 == 0)
			++res;
	}
	cout << res << endl;
	return 0;
}