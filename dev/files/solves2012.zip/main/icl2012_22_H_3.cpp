#include <fstream>
#include <vector>
#include <iostream>
using namespace std;
__int64 gcd(int a,int b)
{
	if (b>a)
		swap(a,b);
	if (b==0)
		return a;
	return gcd(b,a%b);
}
void main()
{
	int n,k;
	ifstream cin("trees.in");
	ofstream cout("trees.out");
	cin>>n>>k;
	int prev, next;
	cin>>prev;
	int bef,aft;
	bef=prev-1;
	int rast=0;
	for (int i=1;i<k;i++)
	{
		cin>>next;
		rast=gcd(rast,next-prev);
		prev=next;
	}
	aft=n-prev;
	__int64 res=0;
	if (rast>0)
	{
		for (int i=1;i*i<=rast;++i)
		if (rast%i==0)
		{
			res+=(bef/i+1)*(aft/i+1);
			res+=(bef/(rast/i)+1)*(aft/(rast/i)+1);
		}
	}
	else
	{
		res=1;
		for (int i=1;i<=bef||i<=aft;i++)
			res+=(bef/i+1)*(aft/i+1)-1;
	}
	cin.close();
	cout<<res;
	cout.close();
} 