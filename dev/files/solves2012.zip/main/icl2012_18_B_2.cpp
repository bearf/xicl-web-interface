#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair <int, int> pii;

#define x first
#define y second
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define sz(a) (int)((a).size())
#define debug(...) fprintf(stderr, __VA_ARGS__)

#define problemname "cuts"

int n,m;
int a[40][40];
vector<pair<int,int> > ret[30][30][30][30];

void print(vector<pair<int,int> > a)
{
  for(int i=0;i<sz(a); i++)
    printf("%d : %d\n",a[i].x,a[i].y);
  puts("");
}

void opt(vector<pair<int,int> >&a, const vector<pair<int,int> >&b, const vector<pair<int,int> >&c)
{
  int b0=0, c0=0;
  int bu=0, cu=0;
  int bs = sz(b), cs = sz(c);

  int i = 0;
  bool ok = false;

  while (bu != bs || cu != cs)
  {
    int tv = 100000;

    if (bu != bs)
      tv = min(tv, b[bu].x);
    if (cu != cs)
      tv = min(tv, c[cu].x);

    if (bu < bs && b[bu].x == tv)
      b0 = max(b0, b[bu].y);
    if (cu < cs && c[cu].x == tv)
      c0 = max(c0, c[cu].y);

//    printf("%d-%d, %d-%d : %d ; %d %d\n",bu,bs,cu,cs,tv,b0,c0);
    if (ok || a[i].y > b0 + c0 + 1)
    {
      a[i] = mp(tv,b0+c0+1);
      ok = true;
    }
    if (a[i].y < b0 + c0 + 1 && !ok)
      return;
    if (bu == bs)
      cu++;
    else if (cu == cs)
      bu++;
    else if (b[bu] < c[cu])
      bu++;
    else cu++; 
    i++;
  } 
}

vector<pair<int,int> > get(int x0, int y0, int x1, int y1)
{
  if(sz(ret[x0][y0][x1][y1])!=0)
    return ret[x0][y0][x1][y1];

  int mnx = x0, mny = y0;
  for(int i=x0;i<=x1;i++)
    for(int j=y0;j<=y1;j++)
      if (a[mnx][mny] > a[i][j])
      {
        mnx = i;
        mny = j;
      }
            
  vector<pair<int,int> >ans((x1-x0+1)*(y1-y0+1));
  int t = 0;
  for(int i=x0;i<=x1;i++)
    for(int j=y0;j<=y1;j++)
      ans[t++] = mp(a[i][j],(int)1e9);

  if (x0 == x1 && y0 == y1)
  {
    ans[0] = mp(a[x0][y0],0);
    return ans;
  }
//  print(ans);

  if (mnx != x1)
    opt(ans,get(x0,y0,mnx,y1),get(mnx+1,y0,x1,y1));
  if (mnx != x0)
    opt(ans,get(x0,y0,mnx-1,y1),get(mnx,y0,x1,y1));

  if (mny != y1)
    opt(ans,get(x0,y0,x1,mny),get(x0,mny+1,x1,y1));
  if (mny != y0)
    opt(ans,get(x0,y0,x1,mny-1),get(x0,mny,x1,y1));

//  print(ans);

  return ret[x0][y0][x1][y1] =  ans;
}

int main() {
    freopen(problemname".in", "r", stdin);
    freopen(problemname".out", "w", stdout);
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)
      for(int j=0;j<m;j++)
        scanf("%d",&a[i][j]),a[i][j]--;

    vector<pair<int,int> > ans = get(0,0,n-1,m-1);
    for(int i=0;i<sz(ans);i++)
      printf("%d%c",ans[i].y," \n"[i+1==sz(ans)]);
    return 0;
}
