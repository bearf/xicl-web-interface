#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <ctime>
#include <cmath>

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define fs first
#define sc second
#define len(x) ((int) (x).size())
#define last(x) (x)[(len(x)-1)]
#define plast(x) (x)[(len(x)-2)]
#define sqr(x) ((x)*(x))
#define foreach(i, x) for (__typeof((x).begin()) i = (x).begin(); i != (x).end(); ++i)
#define forn(i, n) for (int i = 0; i < int(n); ++i)

using namespace std;

typedef long double ld;
typedef long long int64;

const int cmax = 200;

int64 n, m;
int64 d[cmax][2];
int64 b[cmax];

void run(){
	cin >> n >> m;
	for (int64 i = 0; i < cmax; i++)
		for (int64 j = 0; j < 2; j++)
			d[i][j] = 0;
	int64 ln = 0;
	for (int64 i = 0; i < cmax; i++)
		b[i] = 0;
	while (m > 0){
		b[ln++] = m % 2;
		m /= 2;
	}
	ln = max(ln, n);   
	d[0][1] = 1;
	for (int64 i = 0; i < ln-1; i++){
		if (b[i] == 0){
			d[i+1][1] += d[i][1];
			d[i+1][1] += d[i][0];
			d[i+1][0] += d[i][0];
		}	
		else if (b[i] == 1){
			d[i+1][0] += d[i][0];
			d[i+1][1] += d[i][1];
			d[i+1][0] += d[i][1];
		}
	}                           
	/*for (int64 j = 0; j < 2; j++){
		for (int64 i = 0; i < ln; i++)
			cerr << d[i][j] << ' ';
		cerr << endl;
	}*/
	if (ln > n)
		cout << 0 << endl;
	else{
		int64 res = 0;
		res += d[ln-1][b[ln-1]];
		if (b[ln-1] == 0)
			res += d[ln-1][1-b[ln-1]];
		cout << res << endl;
	}
}

int main() {
	freopen("weights.in", "r", stdin);
	freopen("weights.out", "w", stdout);
	int64 t; cin >> t;
	for (int64 i = 0; i < t; i++)
		run();
	fclose(stdin);
	fclose(stdout);	      	
	return 0;
}
