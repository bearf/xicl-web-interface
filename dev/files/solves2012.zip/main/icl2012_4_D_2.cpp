#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <algorithm>
#include <string>
#include <string.h>
#include <set>
#include <map>

using namespace std;

#define pb push_back
#define mp make_pair
#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)
#define ZERO(x) memset(x, 0, sizeof(x))
#define COPY(x,y) memcpy(x, y, sizeof(y))
#define SIZE(x) (int)x.size()

typedef long long int64;

#define TASK "millenium"

#define MAX 100010

int64 n, a, b;

int64 x[MAX];
int64 y[MAX];

int64 ans;

map <int64, int64> q;

int main() {
	int64 i;
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
	scanf("%I64d %I64d %I64d", &n, &a, &b);
	fi(1, n) {
		scanf("%I64d %I64d", &y[i], &x[i]);
		q[y[i]]++;
	}
	fi(1, n) {
		ans = max(ans, y[i] + (q[y[i]] - 1) / b);
	}

	ans = max(ans, (n - 1) / b + 1);
	printf("%I64d\n", ans);
	return 0;
}