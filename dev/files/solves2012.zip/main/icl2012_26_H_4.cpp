#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <cstdio>

using namespace std;

long long n, k;
long long minE, maxE, last, x, nowGcd;
unsigned long long ans;

long long gcd(long long x, long long y) {
	if (y == 0) return x;
	return gcd(y, x % y);
}

void add(long long x) {
	ans += (1L + (minE - 1)/x)*(1L + (n - maxE)/x);
}

int main() {
	freopen("trees.in", "r", stdin);
	freopen("trees.out", "w", stdout);
	cin >> n >> k;
	if (k == 1) {
		cin >> minE;
		ans = 1;
		for (long long d = 1; d <= max(minE - 1, n - minE); d++) {
			long long x1 = 1 + (minE - 1) / d;
			long long x2 = 1 + (n - minE) / d;
			long long dMax = max(minE - 1, n - minE);
			long long d1= dMax, d2 = dMax;
			if (x1 > 1) d1 = (minE - 1) / (x1 - 1);
			if (x2 > 1) d2 = (n - minE) / (x2 - 1);
			if (d1 < dMax) dMax = d1;
			if (d2 < dMax) dMax = d2;
			if (dMax < d) dMax = d;
			ans += (dMax - d + 1)*(x1 * x2 - 1);
			d = dMax;
		}
	} else {
		scanf("%I64d ", &minE);
		last = minE;
		for (long long i = 1; i < k - 1; i++) {
			scanf("%I64d ", &x);
			if (i == 1) nowGcd = x-minE; else
				nowGcd = gcd(nowGcd, x - last);
			last = x;
		}
		scanf("%I64d ", &maxE);
		if (k == 2) nowGcd = maxE - minE; else
			nowGcd = gcd(nowGcd, maxE - last);
		for (long long i = 1; i*i <= nowGcd; i++) {
			if (nowGcd % i == 0) {
				add(i);
				if (i * i != nowGcd) {
					add(nowGcd / i);
				}
			}
		}
	}
	cout << ans << endl;
}