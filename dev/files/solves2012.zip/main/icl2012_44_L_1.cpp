#include <cstdio>
#include <cstring>
#include <cmath>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <iostream>
#include <fstream>
#include <set>

#define mp make_pair
#define pb push_back
#define zero(a) memset(a, 0, sizeof(a))
#define SZ(a) ((int)(a.size()))
#define sqr(a) ((a)*(a))
                
typedef long long ll;
typedef long double ld;

#define taskname "race"

using namespace std;

vector <int> V;
long double A[110000];
bool u[110000];
int n, Next[110000], Prev[110000];
set <pair <long double, int> > S;
pair <long double, int> ne;

int main (void)
{
  int i, v, cv;
  double x;
  freopen (taskname".in", "rt", stdin);
  freopen (taskname".out", "wt", stdout);
  scanf("%d", &n);
  for (i=0; i<n; i++)
    scanf("%lf", &x), A[i]=x;
  for (i=0; i<n-1; i++)
  {
    Next[i]=i+1, Prev[i]=i-1, u[i]=1;
    if (A[i]<A[i+1])
      S.insert(mp(sin(A[i])/sin(A[i+1]-A[i]),i));
  }
  Next[n-1]=n, Prev[n-1]=n-2, Prev[0]=n, u[n-1]=1;
  while (S.size())
  {
    //cerr<<"!!!"<<endl;
    ne=(*S.begin()), S.erase(S.begin()), cv=ne.second, v=Next[cv];
    if ((!u[cv]) || (!u[v]))
      continue;
    if (A[cv]>M_PI-A[v])
    {
      u[v]=0, Next[cv]=Next[v], Prev[Next[v]]=cv;
      if (Next[cv]==n)
        continue;
      if (A[cv]<A[Next[cv]])
        S.insert(mp(sin(A[cv])/sin(A[cv]-A[Next[cv]]),cv));
    }  
    else
    {
      u[cv]=0, Next[Prev[cv]]=v, Prev[v]=Prev[cv];
      if (Prev[v]==n)
        continue;
      if (A[Prev[v]]<A[v])
        S.insert(mp(sin(A[Prev[v]])/sin(A[Prev[v]]-A[v]),v));
    }
  }
  for (i=0; i<n; i++)
    if (u[i])
      V.pb(i+1);
  printf("%d\n", (int)V.size());
  for (i=0; i<(int)V.size(); i++)
    printf("%d ", V[i]);
  printf("\n");
  return 0;
}


