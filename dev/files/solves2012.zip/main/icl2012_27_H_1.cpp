#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <list>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()
#define X first
#define Y second

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

int a[200000];

vector<pt> get(int L){
    vector<pt> ans;

    for(int b = L; b >= 1;){
        int l = (L/(b+1))+1, r = L/b;
        if(l <= r)
            ans.pb(mp(l, r));

        int nr = r+1;
        b = L/nr;
    }
    ans.pb(mp(L+1, 2100000000));

    return ans;
}

li inter(pt a, pt b){
    pt c(max(a.X, b.X), min(a.Y, b.Y));
    if(c.X > c.Y) return 0;
    return c.Y - c.X + 1;
}

li gcd(li a, li b){
    return a == 0 ? b : gcd(b % a, a);
}

int main(){
#ifdef home
    freopen("input.txt", "r", stdin);
//    freopen("output.txt", "w", stdout);
#else
    freopen("trees.in", "r", stdin);
    freopen("trees.out", "w", stdout);
#endif

    int n, k;
    cin >> n >> k;
    forn(i, k)
        scanf("%d", &a[i]);

    if(k == 1){
        li ans = 0, L = a[0]-1, R = n - a[0];
        vector<pt> x = get(L), y = get(R);

        /*
        li cans = 0;
        for1(d, n)
            cans += ((L/d+1) * (R/d+1) - 1);
        cans++;
        cerr << cans << endl;
        */

        //cerr << sz(y) << endl;

        int j = 0;
        forn(i, sz(x)){
            while(j < sz(y) && y[j].Y < x[i].X)
                j++;

            li sum = 0;
            while(j < sz(y) && y[j].X <= x[i].Y){
                sum += inter(x[i], y[j]) * ((R/y[j].X+1) * (L/x[i].X+1) - 1);
                j++;            
            }

            if(j > 0)
                j--;

            ans += sum;
        }
        ans++;
        cout << ans << endl;                
        exit(0);
    }

    li ans = 0;
    
    li g = 0, L = a[0] - 1, R = n - a[k-1];
    forn(i, k - 1)
        g = gcd(g, a[i + 1] - a[i]);

    vector<li> ds;
    for(li d = 1; d*d <= g; d++){
        if(g % d == 0){
            ds.pb(d);
            ds.pb(g / d);
        }
    }

    sort(all(ds));
    ds.erase(unique(all(ds)), ds.end());

    forn(i, sz(ds)){
        li cd = ds[i];
        ans += ((L / cd) + 1) * ((R / cd) + 1);
    }

    cout << ans << endl;

    return 0;
}