#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <string>
#include <string.h>
#include <math.h>
#include <memory.h>
using namespace std;

#define li long long
#define pb push_back
#define mp make_pair
#define all(a) a.begin(),a.end()

li n,k;
vector <li> a;
li abc(li x)
{
	if(x>0)
		return x;
	return -x;
}
li mi(li aa,li bb)
{
	if(aa>bb)
		return bb;
	return aa;
}
li nod(li x,li y)
{
	if(x>y)
		swap(x,y);
	if(x==0)
		return y;
	return nod(y%x,x);
}
int main()
{
	//freopen("input.txt", "r", stdin);
	freopen("trees.in", "r", stdin);
	freopen("trees.out", "w", stdout);
	li n,k,t,sum=0,minus=0;
	cin>>n>>k;
	for(li i=0;i<k;i++)
	{
		cin>>t;
		a.pb(t);
	}
	li res=0;
	if(k==1)
	{
		li a1=a[0]-1;
		li b1=n-a[0];
		if(b1<a1)
			swap(b1,a1);
		if(b1>=200000)
		{
			vector < li > perep;
			li bx=b1,ax=a1;
			li i=1;
			while(bx/i>=200000)
			{
				perep.pb(bx/i);
				i++;
			}
			i=1;
			while(ax/i>=200000)
			{
				perep.pb(ax/i);
				i++;
			}
			perep.pb(200000);
			sort(perep.begin(),perep.end());
			li r=perep.size()-1;
			for(li i=0;i<r;i++)
			{
				li u=perep[i+1]-perep[i];
				if(u>0)
				{
					sum+=u*(((a1)/perep[i+1]+1)*((b1)/perep[i+1]+1)-1);
				}
			}
		}
		li v=b1;
		v=mi(200000,v);
		for(li i=1;i<=v;i++)
		{
			sum+=(a1/i+1)*(b1/i+1)-1;
		}
		sum++;
		cout<<sum;
		return 0;
	}
	res=a[1]-a[0];
	for(li i=2;i<k;i++)
	{
		res=nod(res,a[i]-a[i-1]);
	}
	li i;
	for(i=1;i*i<res;i++)
		if(res%i==0)
		{
			t=res/i;
			sum+=((a[0]-1)/i+1)*((n-a[k-1]+1-1)/i+1);
			sum+=((a[0]-1)/t+1)*((n-a[k-1]+1-1)/t+1);
		}
	if(i*i==res)
	{
		sum+=((a[0]-1)/i+1)*((n-a[k-1]+1-1)/i+1);
	}
	cout<<sum;





	return 0;
}