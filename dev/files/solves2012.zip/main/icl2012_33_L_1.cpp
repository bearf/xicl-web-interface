#include <iostream>
#include <sstream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <ctime>
#include <cmath>

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define fs first
#define sc second
#define len(x) ((int) (x).size())
#define last(x) (x)[(len(x)-1)]
#define plast(x) (x)[(len(x)-2)]
#define sqr(x) ((x)*(x))
#define foreach(i, x) for (__typeof((x).begin()) i = (x).begin(); i != (x).end(); ++i)
#define forn(i, n) for (int i = 0; i < int(n); ++i)

using namespace std;

typedef long double ld;
typedef long long int64;                
typedef unsigned long long lint;
 
const int cmax = 100500;

struct tree
{
	int x, y, cnt;
	tree *l, *r;
};

int n;
vector<int> a;
int win[cmax];

tree *mktree(int x)
{
	tree *a = new(tree);
	a->x = x;
	a->cnt = 1;
	a->y = (rand() << 16) + rand();
	a->l = a->r = NULL;
	return a;
}

void split(tree *rt, tree *&l, tree *&r, int x)
{
	if (!rt)
		l = r = NULL;
	else if (rt->x < x)
	{
		split(rt->r, rt->r, r, x);
		l = rt;
	}	      
	else
	{
		split(rt->l, l, rt->l, x);
		r = rt;
	}
}

void merge(tree *&rt, tree *l, tree *r)
{
	if ((!l) && (!r))
		rt = NULL;
	else if ((!l) || (!r))
		rt = l ? l : r;
	else if (l->y < r->y)	
	{
		merge(l->r, l->r, r);
		rt = l;		
	}
	else
	{
		merge(r->l, l, r->l);
		rt = r;
	}
}

void insert(tree *&rt, int x)
{
	tree *l, *m, *r;
	split(rt, l, r, x);
	split(r, m, r, x + 1);
	if (!m)
	{
		m = mktree(x);
	}
	else
		m->cnt++;
	merge(m, m, r);
	merge(rt, l, m);
}

void write_tree(tree *root, bool flag = true){
	if (!root)
		return;
	write_tree(root->l, false);
	cout << root->x << ' ';
	write_tree(root->r, false);
	if (flag)
		cout << endl;
}

void del(tree *&rt, int x)
{
	tree *l, *m, *r;
	split(rt, l, r, x);
	split(r, m, r, x + 1);	
	if (m)
	{
		if (m->cnt == 1)
			m = NULL;
		else
			m->cnt--;
	}
	merge(m, m, r);
	merge(rt, l, m);
}

const ld eps = 1e-9;
const ld cc = 1e+6;
const int sang = int((M_PI / 2) * cc + eps);

tree *l, *r; 

int main() {
	freopen("race.in", "r", stdin);
	freopen("race.out", "w", stdout);
	cin >> n; a.resize(n);
	srand(3 * n);
	for (int i = 0; i < n; i++){
		ld t; cin >> t; t *= cc;
		a[i] = (int) (t + eps);
	}
	l = r = NULL;
	for (int i = 0; i < n; i++)
		insert(r, a[i]);
	for (int i = 0; i < n; i++){
		del(r, a[i]);
		if (a[i] == sang)
			win[i] = 1;
		else if (a[i] < sang){
		    int lft = a[i]+1, rgt = 2 * sang - a[i] - 1;
			if (rgt < lft)
				win[i] = 1;
			else{
				tree *ll, *mm, *rr;
				split(r, ll, rr, lft);
				split(rr, mm, rr, rgt+1);
				if (!mm)
					win[i] = 1;
				else
					win[i] = 0;
				merge(r, ll, mm);
				merge(r, r, rr);
			}
		}
		else{
			int lft = 2 * sang - a[i] + 1, rgt = a[i] - 1;
			if (rgt < lft){
				win[i] = 1;
			}
			else{
				tree *ll, *mm, *rr;
				split(l, ll, rr, lft);
				split(rr, mm, rr, rgt+1);
				if (!mm)
					win[i] = 1;
				else
					win[i] = 0;
				merge(l, ll, mm);
				merge(l, l, rr);
			}
		}	
		insert(l, a[i]);
	}	
	int res = 0;
	for (int i = 0; i < n; i++)
		res += win[i];
	cout << res << endl;
	for (int i = 0; i < n; i++)
		if (win[i] == 1)
			cout << i+1 << ' ';
	cout << endl;
	return 0;
}
