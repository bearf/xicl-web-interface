#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <string>
#include <string.h>

#define li unsigned long long
#define pb push_back
#define mp make_pair

#define INF (1000 * 1000 * 1000)
#define EPS (1e-9) 

using namespace std;

li n, m, a[2020], b[2020];
vector <li> w;

map <li, li> q;

int main(){
	freopen("darts.in", "r", stdin);
	freopen("darts.out", "w", stdout);
	li i, k;
	cin >> n >> m >> k;
	for (i = 0; i < k; i++) cin >> a[i] >> b[i];
	a[k] = n, a[k+1] = 0;
	b[k] = m, b[k+1] = 0;
	k += 2;
	sort(a, a + k);
	sort(b, b + k);

	li j;
	for (i = 0; i < k; i++){
		if (i == 0 || a[i] != a[i-1]){
			for (j = 0; j < k; j++)
				if (j == 0 || b[j] != b[j-1]){
		
					if (q[a[i]+b[j]] == 0) w.pb(a[i] + b[j]);
					q[a[i] + b[j]]++;
				}
		}
	}

	li res = 0;
	for (i = 0; i < w.size(); i++){
		li h = q[w[i]];
		res += (h * (h - 1)) / 2;
		//cerr << h << ' ' << res << endl;
	}
	cout << res << endl;
	
}