#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <ctime>
#include <cmath>

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define fs first
#define sc second
#define len(x) ((int) (x).size())
#define last(x) (x)[(len(x)-1)]
#define plast(x) (x)[(len(x)-2)]
#define sqr(x) ((x)*(x))
#define foreach(i, x) for (__typeof((x).begin()) i = (x).begin(); i != (x).end(); ++i)
#define forn(i, n) for (int i = 0; i < int(n); ++i)

using namespace std;

typedef long double ld;
typedef unsigned long long int64;

set<pair<int, int> > s;

int main() {
	freopen("bricks.in", "r", stdin);
	freopen("bricks.out", "w", stdout);
	int n, k;
	cin >> n >> k;
	forn (i, k) {
		int x, y;
		cin >> x >> y;
		if (s.find(mp(x, y - 1)) != s.end() &&
			s.find(mp(x - 1, y - 1)) == s.end()) {
			cout << i + 1;
			return 0;
		}
		if (s.find(mp(x, y + 1)) != s.end() &&
			s.find(mp(x - 1, y)) == s.end()) {
			cout << i + 1;
			return 0;
		}
		s.insert(mp(x, y));
	}
	cout << -1;
	return 0;
}
