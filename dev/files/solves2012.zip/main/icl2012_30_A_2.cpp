#include <cstdlib>
#include <cstdio>

using namespace std;

#define N 200010

int main(int argc, char* argv[]) {
	long k, i, j, bri[N][2], find[4], end = -1;
	freopen("bricks.in", "r", stdin);
	freopen("bricks.out", "w", stdout);
	scanf("%ld%ld", &k, &k);
	for(i = 1; i < k + 1; i++){
		find[0] = 0;
		find[1] = 0;
		find[2] = 0;
		find[3] = 0;
		scanf("%ld%ld", &(bri[i][0]), &(bri[i][1]));
		for(j = 1; j < i; j++){
			if(bri[j][0]>1 && bri[j][1] > 1) {
				if(bri[j][0] == bri[i][0]){
					if(bri[j][1] == bri[i][1] - 1)
						find[0]++;
					if(bri[j][1] == bri[i][1] + 1)
						find[1]++;
				}else if(bri[j][0] == bri[i][0] - 1){
					if(bri[j][1] == bri[i][1] - 1)
						find[2]++;
					if(bri[j][1] == bri[i][1])
						find[3]++;
				}
			}
		}
		if((find[0] == 1)&&(find[2] == 0)){
			end = i -1;
		}
		if((find[1] == 1)&&(find[3] == 0)){
			end = i - 1;
		}
	}
	printf("%ld", end);
	return 0;
}