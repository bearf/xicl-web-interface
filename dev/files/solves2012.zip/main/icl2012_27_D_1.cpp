#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <list>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()
#define X first
#define Y second

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

int main(){
#ifdef home
    freopen("input.txt", "r", stdin);
//    freopen("output.txt", "w", stdout);
#else
    freopen("millenium.in", "r", stdin);
    freopen("millenium.out", "w", stdout);
#endif

    int n, A, b;
    cin >> n >> A >> b;
    vector<pt> a(n);
    forn(i, n)
        scanf("%d%d", &a[i].X, &a[i].Y);
    sort(all(a));

    li lastTime = -INF, ans = 0;
    int rem = 0;

    forn(i, n){

        int j = i;
        while(j < n && a[i].X == a[j].X)
            j++;

        int cnt = j - i;
        li curTime = a[i].X;
        
        if(curTime > lastTime){
            lastTime = curTime - 1;
            rem = b;           
        }

        int add = min(b - rem, cnt);
        cnt -= add, rem += add;
        
        if(cnt > 0){
            lastTime += (cnt / b) + int(cnt % b != 0);
            rem = ((cnt % b == 0) ? b : cnt % b);
        }
    
        ans = max(ans, lastTime);
        i = j - 1;
    }

    cout << ans << endl;
    return 0;
}