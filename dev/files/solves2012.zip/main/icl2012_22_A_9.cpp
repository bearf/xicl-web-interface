#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;
struct snd
{
	int x,y;
	snd (int xx, int yy)
	{
		x=xx;
		y=yy;
	}
	bool operator < (snd b)
	{
		return x<b.x||x==b.x&&y<b.y;
	}
	bool operator == (snd b)
	{
		return x==b.x&&y==b.y;
	}
};
vector <snd> heap;
bool search(snd b)
{
	int l=0,r=heap.size()-1,c;
	while (l<=r)
	{
		c=(l+r)/2;
		if (heap[c]==b)
			return true;
		if (heap[c]<b)
			r=c-1;
		else
			l=c+1;
	}
	return false;
}
int main()
{
	int n,k;
	ifstream cin("bricks.in");
	ofstream cout("bricks.out");
	cin>>n>>k;
	int x,y;
	for (int i=0;i<k;i++)
	{
		cin>>x>>y;
		if (search(snd(x,y+1))&&!search(snd(x-1,y))||
			search(snd(x,y-1))&&!search(snd(x-1,y-1)))
		{
			cout<<(i+1);
			return 0;
		}
		heap.push_back(snd(x,y));
	}
	cin.close();
	cout<<(-1);
	cout.close();
	return 0;
}