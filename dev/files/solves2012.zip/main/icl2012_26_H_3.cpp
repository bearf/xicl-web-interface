#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <cstdio>

using namespace std;

long long n, k;
long long minE, maxE, last, x, nowGcd;
long long ans;

long long gcd(long long x, long long y) {
	if (y == 0) return x;
	return gcd(y, x % y);
}

void add(long long x) {
	ans += (1L + (minE - 1)/x)*(1L + (n - maxE)/x);
}

int main() {
	freopen("trees.in", "r", stdin);
	freopen("trees.out", "w", stdout);
	cin >> n >> k;
	if (k == 1) {
		cin >> minE;
		ans = minE*(1+n-minE);
	} else {
		scanf("%I64d ", &minE);
		last = minE;
		for (long long i = 1; i < k - 1; i++) {
			scanf("%I64d ", &x);
			if (i == 1) nowGcd = x-minE; else
				nowGcd = gcd(nowGcd, x - last);
			last = x;
		}
		scanf("%I64d ", &maxE);
		if (k == 2) nowGcd = maxE - minE; else
			nowGcd = gcd(nowGcd, maxE - last);
		for (long long i = 1; i*i <= nowGcd; i++) {
			if (nowGcd % i == 0) {
				add(i);
				if (i * i != nowGcd) {
					add(nowGcd / i);
				}
			}
		}
	}
	cout << ans << endl;
}