import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {

	class Point implements Comparable<Point> {
		int x, y;

		public Point(int x, int y) {
			super();
			this.x = x;
			this.y = y;
		}

		@Override
		public int compareTo(Point o) {
			if (x != o.x) {
				return x - o.x;
			} else {
				return y - o.y;
			}
		}
	}
	
	int n, k;
	TreeSet<Point> deleted;
	
	void _solve() throws Exception {
		n = nextInt();
		k = nextInt();
		deleted = new TreeSet<Solution.Point>();
		for (int i = 0; i < k; ++i) {
			int x = nextInt(), y = nextInt();
			if (deleted.contains(new Point(x, y + 1)) && hasBrick(x - 1, y) ||
					deleted.contains(new Point(x, y - 1)) && hasBrick(x - 1, y - 1)) {
				out.print(i + 1);
				return;
			}
			/*if (deleted.contains(new Point(x + 1, y)) && deleted.contains(new Point(x + 1, y + 1))) {
				out.print(i + 1);
				return;
			}*/
			deleted.add(new Point(x, y));
		}
		out.print(-1);
	}
	
	private boolean hasBrick(int x, int y) {
		if (deleted.contains(new Point(x, y))) {
			return false;
		}
		return y > 0 && y <= x;
	}

	BufferedReader in;
	StringTokenizer stringTokenizer;
	PrintWriter out;
	
	long nextLong() {
		return Long.parseLong(nextToken());
	}
	
	double nextDouble() {
		return Double.parseDouble(nextToken());
	}
	
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	
	String nextToken() {
		while (!stringTokenizer.hasMoreTokens()) {
			String line = null;
			try {
				line = in.readLine();
			} catch (IOException e) {
				NOO(e);
			}
			if (line == null) {
				return null;
			} else {
				stringTokenizer = new StringTokenizer(line);
			}
		}
		return stringTokenizer.nextToken();
	}
	
	public void run() {
		try {
			_solve();
		} catch (Exception e) {
			NOO(e);
		} finally {
			out.close();
		}
	}
	
	void NOO(Exception e) {
		e.printStackTrace();
		System.exit(42);
	}
	
	public Solution(String name) {
		try {
			in = new BufferedReader(new FileReader(name + ".in"));
			stringTokenizer = new StringTokenizer("");
			out = new PrintWriter(new FileWriter(name + ".out"));
		} catch (Exception e) {
			NOO(e);
		}
	}
	
	public static void main(String[] args) {
		new Solution("bricks").run();
	}

}
