#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <list>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()
#define X first
#define Y second

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

int n, m;
int a[30][30];

vector<pt> z[900][900];

void fillCur(const vector<pt>& lf, const vector<pt>& rg, vector<pt>& cur){
    int cnt = 0;
    int cutIdx = 1;
    cur.resize(sz(lf) + sz(rg));
    int ilf = 0, irg = 0;
    while(ilf < sz(lf) || irg < sz(rg)){
        if(ilf == sz(lf)){
            cur[cnt++] = rg[irg++];
            cur[cnt - 1].Y += cutIdx;
            cutIdx = 0;
            continue;
        }
        if(irg == sz(rg)){
            cur[cnt++] = lf[ilf++];
            cur[cnt - 1].Y += cutIdx;
            cutIdx = 0;
            continue;
        }

        if(lf[ilf].X < rg[irg].X){
            cur[cnt++] = lf[ilf++];
            cur[cnt - 1].Y += cutIdx;
            cutIdx = 0;
        }else{
            cur[cnt++] = rg[irg++];
            cur[cnt - 1].Y += cutIdx;
            cutIdx = 0;
        }
    }
}

void solve(int x1, int y1, int x2, int y2){
    if((x2 - x1 + 1) * (y2 - y1 + 1) == 1){
        z[x1*m + y1][x2*m + y2].resize(1);
        z[x1*m + y1][x2*m + y2][0] = pt(a[x1][y1], 0);
        return;
    }

    if(z[x1*m + y1][x2*m + y2].empty()){
        vector<pt>& ans = z[x1*m + y1][x2*m + y2];
        int mn = INF;
        pt c;

        for(int x = x1; x <= x2; ++x)
        for(int y = y1; y <= y2; ++y){
            if(a[x][y] < mn){
                mn = a[x][y];
                c.X = x;
                c.Y = y;
            }
        }

        if(c.Y != y1){
            vector<pt> cur;

            solve(x1, y1, x2, c.Y - 1);
            solve(x1, c.Y, x2, y2);

            const vector<pt>& lf = z[x1*m + y1][x2*m + c.Y - 1];
            const vector<pt>& rg = z[x1*m + c.Y][x2*m + y2];

            fillCur(lf, rg, cur);
            
            if(sz(ans) == 0)
                ans = cur;
            else
                ans = min(ans, cur);
        }

        if(c.Y != y2){
            vector<pt> cur;

            solve(x1, y1, x2, c.Y);
            solve(x1, c.Y + 1, x2, y2);

            const vector<pt>& lf = z[x1*m + y1][x2*m + c.Y];
            const vector<pt>& rg = z[x1*m + c.Y + 1][x2*m + y2];

            fillCur(lf, rg, cur);
            
            if(sz(ans) == 0)
                ans = cur;
            else
                ans = min(ans, cur);
        }

        if(c.X != x1){
            vector<pt> cur;

            solve(x1, y1, c.X - 1, y2);
            solve(c.X, y1, x2, y2);

            const vector<pt>& lf = z[x1*m + y1][(c.X - 1)*m + y2];
            const vector<pt>& rg = z[c.X*m + y1][x2*m + y2];

            fillCur(lf, rg, cur);
            
            if(sz(ans) == 0)
                ans = cur;
            else
                ans = min(ans, cur);
        }

        if(c.X != x2){
            vector<pt> cur;

            solve(x1, y1, c.X, y2);
            solve(c.X + 1, y1, x2, y2);

            const vector<pt>& lf = z[x1*m + y1][c.X*m + y2];
            const vector<pt>& rg = z[(c.X + 1)*m + y1][x2*m + y2];

            fillCur(lf, rg, cur);
            
            if(sz(ans) == 0)
                ans = cur;
            else
                ans = min(ans, cur);
        }
    }
}

int main(){
#ifdef home
    freopen("input.txt", "r", stdin);
//    freopen("output.txt", "w", stdout);
#else
    freopen("cuts.in", "r", stdin);
    freopen("cuts.out", "w", stdout);
#endif

    cin >> n >> m;

    forn(i, n){
        forn(j, m){
            cin >> a[i][j];
            a[i][j]--;
        }
    }

    /*{
        vector<int> p;
        forn(i, n*m)
            p.push_back(i);
        random_shuffle(all(p));

        forn(i, n)
        forn(j, m)
            a[i][j] = p[i*m + j];
    }*/

    solve(0, 0, n - 1, m - 1);

    int sum = 0;

    forn(i, n*m){
        sum += z[0][(n - 1)*m + m - 1][i].Y;
        printf("%d", sum);
        if(i + 1 == n*m)
            puts("");
        else
            printf(" ");
    }

    return 0;
}