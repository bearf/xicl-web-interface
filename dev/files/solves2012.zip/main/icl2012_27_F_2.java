import java.io.*;
import java.math.*;
import java.util.*;


public class Solution {
	final int M = 1000000007;
	
	public static void main(String[] args) throws Exception{
		new Solution().run();
	}
	
	int p;
	BigInteger n;
	
	int sznp;
	int[] np = new int[100500];
	
	int[][][][] z = new int[2][2][2][100500];
	boolean[][][][] used = new boolean[2][2][2][100500];
	
	int[] nums = new int[3];
	
	void run() throws Exception{
		Scanner sc = new Scanner(new File("oranges.in"));
		PrintWriter pw = new PrintWriter(new File("oranges.out"));
		p = sc.nextInt();
		n = sc.nextBigInteger();
		//n = BigInteger.TEN.pow(2000);
			
		nums[0] = 0;
		nums[1] = p - 2;
		nums[2] = p - 1;
		
		if(n.compareTo(BigInteger.valueOf(2)) <= 0){
			pw.write("0\n");
			pw.close();
			return;
		}
		
		BigInteger on = n;
		
		n = n.subtract(BigInteger.valueOf(2));
		
		
		while(n.compareTo(BigInteger.ZERO) != 0){
			np[sznp++] = n.remainder(BigInteger.valueOf(p)).intValue();
			n = n.divide(BigInteger.valueOf(p));
		}
		
		//System.out.println(sznp);
		
		for(int idx = sznp; idx >= 0; --idx)
		for(int r = 1; r >= 0; --r)
		for(int c1 = 0; c1 <= 1; ++c1)
		for(int c2 = 0; c2 <= 1; ++c2){
			if(idx == sznp){
				z[r][c1][c2][idx] = 1 - r;
				continue;
			}
			
			int ans = 0;
			
			for(int i1 = 0; i1 <= 2; ++i1)
			for(int i2 = 0; i2 <= 2; ++i2){
				int a1 = nums[i1];
				int a2 = nums[i2];
				
				if(c1 == 1 && a1 != 0)
					continue;
				if(c2 == 1 && a2 != 0)
					continue;
				
				int sum = a1 + a2 + r;
				int nr = (sum >= p) ? 1 : 0;
				if(nr == 1)
					sum -= p;
				
				if(sum != np[idx])
					continue;
				
				//int ndif = (dif == 1 || a1 != a2) ? 1 : 0;
				int nc1 = (a1 == 0) ? 1 : 0;
				int nc2 = (a2 == 0) ? 1 : 0;
				
				ans = (ans + z[nr][nc1][nc2][idx + 1]) % M;
			}
			
			z[r][c1][c2][idx] = ans;
		}
		
		int ans = z[0][0][0][0];
		
		//System.out.println(ans);
		
		if(on.remainder(BigInteger.valueOf(2)).intValue() == 0){
			BigInteger m = on.divide(BigInteger.valueOf(2)).subtract(BigInteger.ONE);
			boolean good = true;
			while(m.compareTo(BigInteger.ZERO) != 0){
				int cur = m.remainder(BigInteger.valueOf(p)).intValue();
				if(cur != p - 2 && cur != p - 1){
					good = false;
					break;
				}
				
				m = m.divide(BigInteger.valueOf(p));
			}
			
			if(good)
				ans = (ans + M - 1) % M;
		}
		
				
		BigInteger cans = BigInteger.valueOf(ans).multiply(BigInteger.valueOf(2).modInverse(BigInteger.valueOf(M))).remainder(BigInteger.valueOf(M));
		
		pw.write(cans + "\n");
		//System.out.println(cans);
		pw.close();
	}
	
}
