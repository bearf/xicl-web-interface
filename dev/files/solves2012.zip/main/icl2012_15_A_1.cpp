#include <iostream>
#include <sstream>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <vector>
#include <string>
#include <ctime>
using namespace std;

#define X first
#define Y second
#define mp make_pair

bool giveLeft (int x, int y, int & px, int & py)
{
	if (x == 1)
		return false;

	px = x - 1;
	py = y - 1;

	if (py < 1)
		return false;

	return true;
}

bool giveRigth (int x, int y, int & px, int & py)
{
	if (x == 1)
		return false;

	px = x - 1;
	py = y;

	if (py > px)
		return false;

	return true;
}

const int INF = 1e9;
int n, k;
map <pair<int, int> , int> op;

int main()
{
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	freopen("bricks.in", "r", stdin); freopen("bricks.out", "w", stdout);
	
	scanf("%d%d", &n, &k);
	for (int i = 0; i < k; i++)
	{
		int x, y;
		scanf("%d%d", &x, &y);

		int xl, yl;
		if (giveLeft(x, y, xl, yl))
		{
			if (op.find(mp(xl, yl)) == op.end())
				op[mp(xl, yl)] = 2;

			op[mp(xl, yl)]--;

			if (op[mp(xl, yl)] == 0)
			{
				printf("%d", i + 1);
				return 0;
			}
		}

		int xr, yr;
		if (giveRigth(x, y, xr, yr))
		{
			if (op.find(mp(xr, yr)) == op.end())
				op[mp(xr, yr)] = 2;

			op[mp(xr, yr)]--;

			if (op[mp(xr, yr)] == 0)
			{
				printf("%d", i + 1);
				return 0;
			}
		}

		op[mp(x, y)] = INF;
	}

	puts("-1");

	return 0;
}
