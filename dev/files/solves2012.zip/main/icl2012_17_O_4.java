import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

import javax.management.Query;

public class Solution implements Runnable {

	public static void main(String[] args) throws IOException {
		new Solution().run();
	}

	StringTokenizer in;
	BufferedReader br;
	PrintWriter out;

	public String nextToken() throws IOException {
		while (in == null || !in.hasMoreTokens()) {
			in = new StringTokenizer(br.readLine());
		}
		return in.nextToken();
	}

	public int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}
	public void solve() throws IOException {
		int n = nextInt(), m = nextInt(), k = nextInt();
		List<Integer> x = new ArrayList<Integer>(), y =  new ArrayList<Integer>(); 
		Map<Integer, Boolean> check1 = new Hashtable<Integer, Boolean>();
		Map<Integer, Boolean> check2 = new Hashtable<Integer, Boolean>();
		Map<Integer, Integer> forx = new Hashtable<Integer, Integer>();
		Map<Integer, Integer> fory = new Hashtable<Integer, Integer>();
		x.add(m);
		x.add(0);
		y.add(n);
		y.add(0);
		check1.put(m, true);
		check1.put(0, true);
		check2.put(n, true);
		check2.put(0, true);
		forx.put(m, 1);
		fory.put(n, 1);
		for (int i = 0; i < k; ++i){
			int b = nextInt(), a = nextInt();
			if (check1.get(a) == null){
				for (int t : x){
					if (forx.get(Math.abs(a - t)) == null)
						forx.put(Math.abs(a - t), 1);
					else{
						Integer cur = forx.get(Math.abs(a - t));
						forx.remove(Math.abs(a - t));
						forx.put(Math.abs(a - t), cur+1);
					}
				}
				x.add(a);
				check1.put(a, true);
			}
			if (check2.get(b) == null){
				for (int t : y){
					if (fory.get(Math.abs(b - t)) == null)
						fory.put(Math.abs(b - t), 1);
					else{
						Integer cur = fory.get(Math.abs(b - t));
						fory.remove(Math.abs(b - t));
						fory.put(Math.abs(b - t), cur+1);
					}
				}
				y.add(b);
				check2.put(b, true);
			}
		}
		if (k >= 1500){
			out.print("-1");
			return;
		}
		long ans = 0;
		Set<Integer> set = forx.keySet();
		for (int i : set) {
			if (fory.get(i) != null)
			ans += forx.get(i) * fory.get(i);
		}
		out.print(ans);
	}

	@Override
	public void run() {
		try {
			br = new BufferedReader(new FileReader("darts.in"));
//			 br = new BufferedReader(new InputStreamReader(System.in));
			out = new PrintWriter(new File("darts.out"));
//			 out = new PrintWriter(new OutputStreamWriter(System.out));
			solve();
			br.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

}
