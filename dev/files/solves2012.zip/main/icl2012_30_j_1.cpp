#include <cstdio>
#include <cstdlib>
#include <queue>

using namespace std;

#define pnt pair<long, long>

#define g(y, x) _g[x + (y)*m]
#define num(y, x) (x + (y)*m)
#define N 100010

int main(int argc, char* argv[]) {
	long _g[N], used[N][8], i, j, n, m;
	queue < pair<pnt, int> > q;
	pnt fr, to, tmpP;
	pair<pnt, int> tmp, cur;
	char str[N];
	freopen("islands.in", "r", stdin);
	freopen("islands.out", "w", stdout);
	scanf("%ld%ld", &n, &m);
	for(i=0; i<n; ++i) {
		scanf("%s", str);
		for(j=0; j<m; ++j) {
			g(i, j) = (int)(str[j] - '0');
		}
	}
	for(i=0; i<N; ++i) {
		used[i][0]=used[i][1]=used[i][2]=used[i][3]=0;
		used[i][4]=used[i][5]=used[i][6]=used[i][7]=0;
	}

	scanf("%ld%ld%ld%ld", &(fr.first), &(fr.second), &(to.first), &(to.second));
	

	fr.first--;
	fr.second--;
	to.first--;
	to.second--;

	tmp.first = fr;
	tmp.second = -1;
	q.push(tmp);

	while (!q.empty()) {
		cur = q.front();

		if(cur.first == to) {
			printf("YES\n");
			return 0;
		}

		if(cur.first.first > 0) { //�����
			if(g(cur.first.first, cur.first.second) && !(g(cur.first.first, cur.first.second)<=1 && cur.second >=0 && cur.second <4) && !used[num(cur.first.first-1, cur.first.second)][6]) { //�� ������ �����
				tmpP.first = cur.first.first-1;
				tmpP.second = cur.first.second;
				tmp.first = tmpP;
				tmp.second = 6;
				q.push(tmp);
				used[num(cur.first.first-1, cur.first.second)][6] = 1;
			}
			if(g(cur.first.first-1, cur.first.second) && !(g(cur.first.first-1, cur.first.second)<=1 && cur.second == 4) && !used[num(cur.first.first-1, cur.first.second)][2]) {
				tmpP.first = cur.first.first-1;
				tmpP.second = cur.first.second;
				tmp.first = tmpP;
				tmp.second = 2;
				q.push(tmp);
				used[num(cur.first.first-1, cur.first.second)][2] = 1;
			}
		}

		if(cur.first.second > 0) { //�����
			if(g(cur.first.first, cur.first.second) && !(g(cur.first.first, cur.first.second)<=1 && cur.second >=0 && cur.second <4) && !used[num(cur.first.first, cur.first.second-1)][7]) { //�� ������ �����
				tmpP.first = cur.first.first;
				tmpP.second = cur.first.second-1;
				tmp.first = tmpP;
				tmp.second = 7;
				q.push(tmp);
				used[num(cur.first.first, cur.first.second-1)][7]=1;
			}
			if(g(cur.first.first, cur.first.second-1) && !(g(cur.first.first, cur.first.second-1)<=1 && cur.second == 5) && !used[num(cur.first.first, cur.first.second-1)][3]) {
				tmpP.first = cur.first.first;
				tmpP.second = cur.first.second-1;
				tmp.first = tmpP;
				tmp.second = 3;
				q.push(tmp);
				used[num(cur.first.first, cur.first.second-1)][3]=1;
			}
		}

		if(cur.first.first < n) { //����
			if(g(cur.first.first, cur.first.second) && !(g(cur.first.first, cur.first.second)<=1 && cur.second >=0 && cur.second <4) && !used[num(cur.first.first+1, cur.first.second)][0]) { //�� ������ �����
				tmpP.first = cur.first.first+1;
				tmpP.second = cur.first.second;
				tmp.first = tmpP;
				tmp.second = 0;
				q.push(tmp);
				used[num(cur.first.first+1, cur.first.second)][0] = 1;
			}
			if(g(cur.first.first+1, cur.first.second) && !(g(cur.first.first+1, cur.first.second)<=1 && cur.second == 6) && !used[num(cur.first.first+1, cur.first.second)][4]) {
				tmpP.first = cur.first.first+1;
				tmpP.second = cur.first.second;
				tmp.first = tmpP;
				tmp.second = 4;
				q.push(tmp);
				used[num(cur.first.first+1, cur.first.second)][4] = 1;
			}
		}

		if(cur.first.second < m) { //������
			if(g(cur.first.first, cur.first.second) && !(g(cur.first.first, cur.first.second)<=1 && cur.second >=0 && cur.second <4) && !used[num(cur.first.first, cur.first.second+1)][1]) { //�� ������ �����
				tmpP.first = cur.first.first;
				tmpP.second = cur.first.second+1;
				tmp.first = tmpP;
				tmp.second = 1;
				q.push(tmp);
				used[num(cur.first.first, cur.first.second+1)][1]=1;
			}
			if(g(cur.first.first, cur.first.second-1) && !(g(cur.first.first, cur.first.second+1)<=1 && cur.second == 7) && !used[num(cur.first.first, cur.first.second+1)][5]) {
				tmpP.first = cur.first.first;
				tmpP.second = cur.first.second+1;
				tmp.first = tmpP;
				tmp.second = 5;
				q.push(tmp);
				used[num(cur.first.first, cur.first.second+1)][5]=1;
			}
		}
		q.pop();
	}
	printf("NO\n");
	return 0;
}

