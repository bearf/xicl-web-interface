#pragma comment(linker,"/STACK:64000000")
#define _CRT_SECURE_NO_WARNINGS


#include <algorithm>
#include <ctime>
#include <cmath>
#include <iostream>
#include <memory.h>
#include <map>
#include <set>
#include <string>
#include <sstream>
#include <stdio.h>
#include <vector>

using namespace std;

#define RE scanf
#define WR printf
#define FI first
#define SE second
#define PB push_back
#define MP make_pair

#define FOR(i,a,b) for(int i = (a);i<=(b);i++)
#define DFOR(i,a,b) for(int i = (a);i>=(b);i--)
#define SZ(a) (int)((a).size())
#define FA(i,v) FOR(i,0,SZ(v)-1)
#define RFA(i,v) DFOR(i,SZ(v)-1,0)
#define CLR(a) memset(a,0,sizeof(a))

#define PAR pair<int,int>
#define LL unsigned long long
#define o_O 1000000000

void __never(int a) {printf("\nOPS %d\n",a);}
#define ass(f) {if (!(f)) {__never(__LINE__);cout.flush();cerr.flush();abort();}}

int gcd(int x, int y)
{
	while (x&&y) x>y ? x%=y : y%=x;
	return x+y;
}

int n, k;
int p[100500];

LL cnt(int L, int R, int d)
{
	L--;
	R=n-R;
	return (LL)(R/d+1)*(L/d+1);
}

LL get_sum_stupid(int L, int R)
{
	LL ans=0;
	FOR(a,1,max(L,R)) ans += (LL)(L/a+1)*(R/a+1) - 1;
	return ans;
}

LL get_sum(int L, int R)
{
	vector< PAR > vec;
	int Z = 100;
	if (max(L,R)<10000) return get_sum_stupid(L,R);
	FOR(a,1,Z)
	{
		vec.PB( make_pair(L/a, 1) );
		vec.PB( make_pair(R/a, 2) );
	}
	sort( vec.begin(), vec.end() );
	reverse( vec.begin(), vec.end() );
	LL ans=0;
	int t = max(L/Z, R/Z);
	int L1=0, R1=0;
	FA(a,vec)
	{
		if (a) ans += ((LL)(L1+1)*(R1+1)-1)*(LL)(vec[a-1].FI-vec[a].FI);
		if (vec[a].FI==t) break;
		if (vec[a].SE==1) L1++;
		else R1++;
	}
	FOR(a,1,t) ans += (LL)(L/a+1)*(R/a+1)-1;

	return ans;
}

void sol()
{
	LL ans = 0;
	if (k==1)
	{
		ans++;
		int L = p[1]-1;
		int R = n-p[1];
		//FOR(a,1,min(L,R)) ans += (LL)(L/a+1)*(R/a+1) - 1;
		ans += get_sum(L, R);
		cout << ans;
		return;
	}

	int g = 0;
	FOR(a,2,k) g = gcd(g, p[a]-p[1]);
	for (int a=1; a*a<=g; a++)
	{
		ans += cnt(p[1],p[k],a);
		if (a*a<g) ans += cnt(p[1],p[k],g/a);
	}

	cout << ans;
}
void stress()
{
	while(1)
	{
		int L = rand(), R=rand();
		if (get_sum(L,R) != get_sum_stupid(L,R))
		{
			cerr << "fail!";
			cout << L << " " << R << "\n";
			cout << get_sum(L,R) << "\n";
			cout << get_sum_stupid(L,R) << "\n";
			return;
		}
		cerr << L << " " << R << " ok\n";
	}
}
int main(){
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
	freopen("trees.in","r",stdin);
	freopen("trees.out","w",stdout);

	//stress();
	//return 0;
	RE("%d%d", &n, &k);
	FOR(a,1,k) RE("%d", &p[a]);
	sol();
	return 0;
}
