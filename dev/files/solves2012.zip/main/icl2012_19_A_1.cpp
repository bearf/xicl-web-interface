#include <cstdio>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <iostream>
#include <cmath>

using namespace std;

const int INF = (int) 1e9;
const double EPS = 1e-8;
const double PI = acos(-1.);

typedef pair<int, int> pii;
typedef long long ll;

#define NAME "bricks"

int main()
{
	freopen (NAME".in", "r", stdin);
	freopen (NAME".out", "w", stdout);
	set<pii> S;
	int N, K;
	scanf ("%d%d", &N, &K);
	for (int i = 0; i < K; ++i)
	{
		int a, b;
		scanf ("%d%d", &a, &b);
		if (S.find(pii(a, b-1)) != S.end() && S.find(pii(a-1, b-1)) == S.end() ||
			S.find(pii(a, b+1)) != S.end() && S.find(pii(a-1, b)) == S.end()
		)
		{
			printf("%d", i+1);
			return 0;
		}
		S.insert(pii(a, b));
	}
	printf("-1");
	return 0;
}