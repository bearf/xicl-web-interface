#pragma comment(linker,"/STACK:64000000")
#define _CRT_SECURE_NO_WARNINGS


#include <algorithm>
#include <ctime>
#include <cmath>
#include <iostream>
#include <memory.h>
#include <map>
#include <set>
#include <string>
#include <sstream>
#include <stdio.h>
#include <vector>

using namespace std;

#define RE scanf
#define WR printf
#define FI first
#define SE second
#define PB push_back
#define MP make_pair

#define FOR(i,a,b) for(int i = (a);i<=(b);i++)
#define DFOR(i,a,b) for(int i = (a);i>=(b);i--)
#define SZ(a) (int)((a).size())
#define FA(i,v) FOR(i,0,SZ(v)-1)
#define RFA(i,v) DFOR(i,SZ(v)-1,0)
#define CLR(a) memset(a,0,sizeof(a))

#define PAR pair<int,int>
#define LL long long
#define o_O 1000000000

void __never(int a) {printf("\nOPS %d\n",a);}
#define ass(f) {if (!(f)) {__never(__LINE__);cout.flush();cerr.flush();abort();}}


struct Cont{
	set<PAR> del;
	bool Contain(PAR p){
		return del.find(p) != del.end();
	}
	void Delete(PAR p){
		del.insert(p);
	}
};


Cont c;
int n, k;
void sol(){
	cin >> n >> k;
	int x, y;
	FOR(i,1,k){
		RE("%d %d",&x,&y);
		PAR xy = MP(x,y);
		ass(!c.Contain(xy));
		if (x > 1) {
			if (y > 1){
				if (!c.Contain(MP(x-1,y-1)) && c.Contain(MP(x,y-1))) {
					cout << i;
					return ;
				}
			}
			if (y < x) {
				if (!c.Contain(MP(x-1,y)) && c.Contain(MP(x,y+1))) {
					cout << i;
					return ;
				}
			}
		}
		c.Delete(xy);
	}
	cout << "-1";

}
int main(){
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
	freopen("bricks.in","r",stdin);
	freopen("bricks.out","w",stdout);
	sol();
	return 0;
}
