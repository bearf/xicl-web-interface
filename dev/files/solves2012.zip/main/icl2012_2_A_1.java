import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class Solution {
	static class Br implements Comparable<Br> {
		int x, y;

		public Br(int X, int Y) {
			x = X;
			y = Y;
		}

		@Override
		public int compareTo(Br b) {
			return b.x != x ? x - b.x : y - b.y;
		}
	}

	static TreeSet<Br> set = new TreeSet<Br>();
	static TreeSet<Br> del = new TreeSet<Solution.Br>();

	public static void main(String[] args) throws Exception {
		BufferedReader in = new BufferedReader(new FileReader("bricks.in"));
		PrintWriter out = new PrintWriter(new File("bricks.out"));

		StringTokenizer st = new StringTokenizer(in.readLine());

		int n = Integer.parseInt(st.nextToken()), k = Integer.parseInt(st
				.nextToken());

		int ans = -1;

		for (int i = 0; i < k; i++) {
			st = new StringTokenizer(in.readLine());

			int row = Integer.parseInt(st.nextToken()), col = Integer
					.parseInt(st.nextToken());

			int upLeft = col - 1;
			int upRight = col;

			if (upLeft > 0) {
				Br upL = new Br(upLeft, row - 1);
				if (!del.contains(upL)) {
					if (!set.contains(upL))
						set.add(upL);
					else {
						ans = i + 1;
						break;
					}
				}
			}

			if (upRight <= row) {
				Br upR = new Br(upRight, row - 1);
				if (!del.contains(upR)) {
					if (!set.contains(upR))
						set.add(upR);
					else {
						ans = i + 1;
						break;
					}
				}
			}

			del.add(new Br(col, row));
		}

		out.println(ans);
		out.close();
	}
}
