import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Solution {
	public void run(Scanner input, PrintWriter output) {
		int n = input.nextInt();
		int[] a = new int[n];
		int[] b = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = input.nextInt();
		}
		for (int i = 0; i < n; i++) {
			b[i] = input.nextInt();
		}
		// find p
		int p = ((a[0] - b[0]) % n + n) % n;
		// check
		for (int i = 0; i < n; i++) {
			if ((b[i] - a[i] + p) % n != 0) {
				output.println(-1);
				return;
			}
		}
		// find ki
		int[] k = new int[n];
		for (int i = 0; i < n; i++) {
			k[i] = (b[i] - a[i] + p) / n;
		}
		// find min, and +this
		int min = 0;
		for (int i = 0; i < n; i++) {
			min = Math.min(min, k[i]);
		}
		int ansC = 0;
		for (int i = 0; i < n; i++) {
			k[i] -= min;
			ansC += k[i];
		}

		List<Integer> res = new ArrayList<Integer>();
		// now a
		// find pos with k[i] != 0 and increase
		for (int iter = 0; iter < ansC; iter++) {
			int pos = -1;
			int nulls = 0;
			for (int i = 0; i < n; i++) {
				if (k[i] != 0) {
					if (a[i] == 0) {
						nulls++;
					}
					if (pos == -1 || a[i] < a[pos]) {
						pos = i;
					}
				}
			}
			// apply to pos
			if (nulls > 1) {
				output.println(-1);
				return;
			}
			res.add(pos);
			k[pos]--;
			a[pos] += n;
			for (int i = 0; i < n; i++) {
				a[i]--;
			}
		}

		output.println(res.size());
		for (int i = 0; i < res.size(); i++) {
			if (i != 0) {
				output.print(" ");
			}
			output.print(res.get(i) + 1);
		}
		output.println();
	}

	public static void main(String[] args) throws IOException {
		// Scanner input = new Scanner(System.in);
		// PrintWriter output = new PrintWriter(System.out);
		Scanner input = new Scanner(new File("changes.in"));
		PrintWriter output = new PrintWriter(new File("changes.out"));

		new Solution().run(input, output);

		input.close();
		output.close();
	}
}
