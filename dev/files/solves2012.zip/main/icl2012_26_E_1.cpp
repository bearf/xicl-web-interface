#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <cstdio>
#include <algorithm>

using namespace std;
const int N=410000, inf = 1e9;

int m, a[N], b[N], cnt[N];

int count(int a, int b) {
	if (b <= a) return a - b;
	else {
		int res = 1 + (b - a - 1) / (m - 1);
		a += res * (m - 1);
		res += (a - b);
		return res;
	}
}

vector<int> otv;
int main() {
	freopen("changes.in", "r", stdin);
	freopen("changes.out", "w", stdout);
	cin >> m;
	for (int i = 0; i < m; i++) {
		scanf("%d", &a[i]);
	}
	for (int i = 0; i < m; i++) {
		scanf("%d", &b[i]);
		cnt[i] = count(a[i], b[i]);	
	}
	int ost = cnt[0] % m;
	int ans = 0;
	for (int i = 1; i < m; i++) 
		if (cnt[i] % m != ost) {
			cout << -1;
			return 0;
		} else ans = max(ans, cnt[i]);
	for (int it = 0; it < ans; it++) {
		int best = -1;
		for (int i = 0; i < m; i++)
			if (a[i] < ans && ((best == -1) || (a[i] < a[best]))) {
				best = i;
			}
		if (a[best] < 0 || best == -1) {
			cout << -1;
			return 0;
		}
		a[best] += m;
		for (int i = 0; i < m; i++)
			a[i]--;
		otv.push_back(best + 1);
	}
	cout << ans << endl;
	for (int i = 0; i < ans; i++) printf("%d ", otv[i]);
}