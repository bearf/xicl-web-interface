#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <list>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()
#define X first
#define Y second

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

const int N = 100000;

int n;

int maxA;
int sumA, sumB;

int a[N], b[N], c[N];
int k1[N], k2[N];

int szans;
int ans[N];

int mk;

int main(){
#ifdef home
    freopen("input.txt", "r", stdin);
//    freopen("output.txt", "w", stdout);
#else
    freopen("changes.in", "r", stdin);
    freopen("changes.out", "w", stdout);
#endif

    cin >> n;

    maxA = 0;
    
    forn(i, n){
        scanf("%d", &a[i]);
        maxA = max(maxA, a[i]);
        sumA += a[i];
    }
    forn(i, n){
        scanf("%d", &b[i]);
        sumB += b[i];
    }

    if(sumA != sumB){
        puts("-1");
        return 0;
    }

    forn(i, n){
        int sm = a[i] % n;
        int fm = b[i] % n;

        int d;
        if(fm <= sm)
            d = sm - fm;
        else
            d = sm + n - fm;


        if(i == 0)
            mk = d;
        else{
            if(mk != d){
                puts("-1");
                return 0;
            }
        }
    }

    forn(md, 10001){
        int k = md*n + mk;

        if(k > maxA)
            break;

        bool good = true;

        forn(i, n){
            k1[i] = (b[i] - a[i] + k) / n;
            k2[i] = k - k1[i];

            if(k1[i] < 0 || k2[i] < 0){
                good = false;
                break;
            }
        }

        if(!good)
            continue;

        memcpy(c, a, sizeof(int)*n);

        szans = 0;

        forn(q, k){
            int cnt0 = 0;

            int mn = INF;
            int idx = -1;

            forn(i, n){
                if(c[i] == 0)
                    cnt0++;

                if(k1[i] > 0 && a[i] < mn){
                    mn = a[i];
                    idx = i;
                }
            }

            if(cnt0 > 1 || (cnt0 == 1 && mn != 0)){
                good = false;
                break;
            }

            ans[szans++] = idx;

            forn(i, n){
                if(idx == i){
                    c[i] += n - 1;
                    k1[i]--;
                }else{
                    c[i]--;
                    k2[i]--;
                }

                if(k1[i] < 0 || k2[i] < 0 || c[i] < 0){
                    good = false;
                    break;
                }
            }

            if(!good)
                break;
        }

        forn(i, n)
            if(c[i] != b[i]){
                good = false;
                break;
            }

        if(!good)
            continue;

        printf("%d\n", szans);

        forn(i, szans){
            printf("%d", ans[i]  + 1);
            printf((i + 1 == szans) ? "\n" : " ");
        }

        return 0;
    }

    puts("-1");
    return 0;
}
