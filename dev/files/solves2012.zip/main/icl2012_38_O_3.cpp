#include <iostream>
#include <stdio.h>
#include <map>
#include <string>
#include <vector>
#include <utility>
#include <algorithm>
#include <set>

using namespace std;


int main(){
	freopen("darts.in", "r", stdin);
	freopen("darts.out", "w", stdout);

	long n,m;
	cin >> n >> m;
	int k;
	cin >> k;

	set<long> x;
	set<long> y;

	for (int i = 0; i<k; i++){
		long a,b;
		cin >> a >> b;
		x.insert(a);
		y.insert(b);
	}

	x.insert(0); 
	x.insert(n);
	y.insert(0);
	y.insert(m);

	map<long, long> d;

	vector<long> dx;
	for ( set<long>::iterator i = x.begin(); i!=x.end(); i++) dx.push_back( *i );

	vector<long> dy;
	for ( set<long>::iterator i = y.begin(); i!=y.end(); i++) dy.push_back( *i );

	for (int i = 0; i<dx.size(); i++)
		for (int j = i+1; j<dx.size(); j++)
			d[ dx[j] - dx[i] ] ++;

	long long ans = 0;

	for (int i = 0; i<dy.size(); i++)
		for (int j = i+1; j<dy.size(); j++) if (d.find(dy[j]-dy[i])!=d.end() ) ans+=d[ dy[j] - dy[i] ];

	cout << ans;

	return 0;
}