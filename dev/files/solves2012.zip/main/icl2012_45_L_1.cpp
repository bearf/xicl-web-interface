#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>
using namespace std;

set <pair<double,int>> alp;
double pi; 


int main () {

#ifdef INPUT_VAR
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#else
	freopen(TASK_NAME ".in", "rt", stdin);
	freopen(TASK_NAME ".out", "wt", stdout);
#endif
	pi=acos(-1.);
	int n,ans=0;
	scanf("%d",&n);
	for (int i=0;i<n;i++)
	{
		double curalpha;
		scanf("%lf",&curalpha);
		
		double falpha=pi-curalpha;

		set<pair<double,int>>::iterator xx;
		
		while (alp.size()>0 && fabs( (*(alp.begin())).first -pi/2.) > fabs(curalpha-pi/2.) && (*(alp.begin())).first<pi/2.)
		{
			alp.erase(alp.begin());
			ans--;
		}


		if (alp.size()==0 ||  curalpha<pi/2. || fabs( (*(alp.begin())).first -pi/2.) > fabs(curalpha-pi/2.) )
		{
			ans++;
			alp.insert(make_pair(curalpha,i+1));
		}

	}
	printf("%d\n",ans);
	for (set<pair<double,int>>::iterator i=alp.begin();i!=alp.end();i++)
		printf("%d ",(*i).second);



	return 0;
}