#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair <int, int> pii;

#define x first
#define y second
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define sz(a) (int)((a).size())
#define debug(...) fprintf(stderr, __VA_ARGS__)

#define problemname "trees"
int a[1000000];
int n, k;
const int C = 100000;
int gcd(int x, int y) {
    if (y == 0) return x;
    return gcd(y, x % y);
}
int main() {
    freopen(problemname".in", "r", stdin);
    freopen(problemname".out", "w", stdout);
    scanf("%d %d", &n, &k);
    for (int i = 0; i < k; i++) {
        scanf("%d", &a[i]);
    }
    sort(a, a + k);
    if (k == 1) {
        ll ans = 1;
        for (int d = 1; d <= C; d++) {
            ans += (ll)((a[0] + d - 1)/ d) * ((n - a[0] + 1 + d - 1)/ d) - 1;
        }
        ll tkx = ((a[0] + (C + 1) - 1)/ (C + 1));
        ll tky = ((n - a[0] + 1 + (C + 1) - 1)/ (C + 1));
        while (tkx > 1 ||  tky > 1) {
            ll l0 = (a[0] + tkx - 1) / (tkx);
            ll r0 = 2 * (ll)1e9;
            if (tkx != 1) 
                r0 = (a[0] + tkx - 2) / (tkx - 1) - 1;
            ll l1 = (n - a[0] + 1 + tky - 1) / (tky);
            ll r1 = 2 * (ll)1e9; 
            if (tky != 1) 
                r1 = (n - a[0] + 1 + tky - 2) / (tky - 1) - 1;
            l0 = max(l0, (ll)C + 1);
            l1 = max(l1, (ll)C + 1);
            ans += (tkx * tky - 1) * (max(0ll, min(r0, r1) - max(l0, l1) + 1));
            if (r0 < r1) {
                tkx--;
            } else {
                tky--;
            }
        }
        cout<<ans<<endl;
        return 0;
    } else {
        int g = a[1] - a[0];
        for (int i = 1; i < k; i++) {
            g = gcd(g, a[i] - a[i - 1]);
        }
        vector<int> del;
        for (int i = 1; i * i <= g; i++) {
            if (g % i == 0) {
                del.pb(i);
                if (i != g / i)
                del.pb(g / i);
            }
        }
        ll ans = 0;
        for (int i = 0; i < sz(del); i++) {
            ans += (ll)((a[0] + del[i] - 1)/ del[i]) * ((n - a[k - 1] + 1 + del[i] - 1)/ del[i]);
        }
        cout<<ans<<endl;
    }
    return 0;
}
