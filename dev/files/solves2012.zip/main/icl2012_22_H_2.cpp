#include <fstream>
#include <iostream>
using namespace std;
void main()
{
	ifstream cin("trees.in");
	ofstream cout("trees.out");
	long n,result=0,k,minPosDist=0,emptyBef=0,emptyAft=0;
	cin>>n>>k;
	long prev,next,rast;
	cin>>prev;
 	emptyBef=prev-1;
	for (int i=1;i<k;i++)
	{
		cin>>next;
		rast=next-prev;
		if (minPosDist==0||minPosDist>rast)
			minPosDist=rast;
		prev=next;
	}
	emptyAft=n-prev;
	long t=minPosDist;
	while (t>0)
	{
		result++;
		if (emptyBef/t)
			result+=emptyBef/t;
		if (emptyAft/t)
			result+=emptyAft/t;
		if (emptyBef/t&&emptyAft/t)
			result+=(emptyBef/t)+(emptyAft/t);
		t/=2;
	}
	if (minPosDist==0)
	{
		t=emptyBef;
		while (t>0)
		{
			if (emptyBef/t)
				result+=emptyBef/t;
			t/=2;
		}
		t=emptyAft;
		while (t>0)
		{
			if (emptyAft/t)
				result+=emptyAft/t;
			t/=2;
		}
		if(emptyBef&&emptyAft){
			t=emptyBef+emptyAft;
			while (t>0)
			{
				if (emptyBef/t)
					result+=emptyBef/t;
				if (emptyAft/t)
					result+=emptyAft/t;
				t/=2;
			}
		}
	}
	cout<<result;
	cin.close();
	cout.close();
} 