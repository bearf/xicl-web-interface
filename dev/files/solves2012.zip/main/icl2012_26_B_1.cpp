#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <cstdio>

using namespace std;
const int N = 32;

int n, m;
int a[N][N];
struct point{
	int i, j, val;
	point(int i, int j, int val) : i(i), j(j), val(val) {};
	point() : i(0), j(0), val(0) {};
};
point wh[N * N];



struct seg{
	int i1, i2, j1, j2;
	int ok;
	seg(int i1, int j1, int i2, int j2) : i1(i1), i2(i2), j2(j2), j1(j1), ok(1) {};
	int intersec(point p) {
		if (i1 == i2) {
			if (p.j >= j1 && p.j < j2 && (p.i == i1 || p.i == i1 - 1)) return 1;
			return 0;
		} else {
			if (j1 == j2) {
				if (p.i >= i1 && p.i < i2 && (p.j == j1 || p.j == j1 - 1)) return 1;
				return 0;
			}
		}
	}
};

struct par{
	int f, s;
	par(int f, int s): f(f), s(s) {};
	par() : f(0), s(0) {};
};


vector<par> solve(int i1, int j1, int i2, int j2) {
	if (i2 - 1 == i1 && j2 - 1 == j1) {
		vector<par> res;	
		return res;
	}
	int xv = 1e9;
	for (int i = i1; i < i2; i++)
		for (int j = j1; j < j2; j++)
			xv = min(a[i][j], xv);
	point x = wh[xv];
	vector<seg> pr;
	seg s1 = seg(i1, x.j, i2, x.j);
	seg s2 = seg(i1, x.j + 1, i2, x.j + 1);
	seg s3 = seg(x.i, j1, x.i, j2);
	seg s4 = seg(x.i + 1, j1, x.i + 1, j2);
	if (s1.j1 != j1) pr.push_back(s1);
	if (s2.j1 != j2) pr.push_back(s2);
	if (s3.i1 != i1) pr.push_back(s3);
	if (s4.i1 != i2) pr.push_back(s4);
	int t = pr.size();
	if (t == 0) {
		par x;
		x.f = a[i1][j1];
		x.s = 0;
		vector <par> ss;
		ss.push_back(x);
		return ss;
	}
	for (int yv = xv + 1; yv < n * m; yv++) {
		int per = 0;
		for (int j = 0; j < pr.size(); j++) {
			if (pr[j].intersec(wh[yv])) {
				per = 1;
			} 
		}
		if (per == 1) {
			for (int j = 0; j < pr.size(); j++)
				if (!pr[j].intersec(wh[yv])) {
					pr[j].ok = 0;
					t--;
				}
		}
		if (t == 1) break;
	}
	vector <par> tmp;
	vector <par> tmp2;
	for (int j = 0; j < pr.size(); j++)
		if (pr[j].ok == 1) {
			if (pr[j].i1 == pr[j].i2) {
				tmp = solve(i1, j1, pr[j].i1+1, j2);
				tmp2 = solve(pr[j].i1, j1, i2, j2);
			} else {
				tmp = solve(i1, j1, i2, pr[j].j2+1);
				tmp2 = solve(i1, pr[j].j2, i2, j2);
			}
			break;
		}
	vector<par> res;
	int t1 = 0;
	int t2 = 0;
	int p1 = 0, p2 = 0;
	while (p1 < tmp.size() && p2 < tmp2.size()) {
		if (tmp[p1].f < tmp2[p2].f) {
			t1 += tmp[p1].s;
			tmp[p1].s += t2;
			res.push_back(tmp[p1++]);
		}
		else {
			t2 += tmp[p1].s;
			tmp[p1].s += t1;
			res.push_back(tmp2[p2++]);
		}
	}
	while (p1 < tmp.size()) {
		tmp[p1].s += t2;
		res.push_back(tmp[p1++]);
	}
	while (p2 < tmp2.size()) {
		tmp2[p2].s += t1;
		res.push_back(tmp2[p2++]);
	}
}

int main() {
	freopen("cuts.in", "r", stdin);
	freopen("cuts.out", "w", stdout);
	cin >> n >> m;
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++) {
			cin >> a[i][j];
			wh[a[i][j]] = point(i, j, a[i][j]);			
		}
	vector<par> ans = solve(0, 0, n, m);
	for (int i = 0; i < ans.size(); i++) printf("%d ", ans[i].s);
}