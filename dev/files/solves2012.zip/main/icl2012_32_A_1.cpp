#include <cstdlib>
#include <cstdio>
#include <map>
#include <iostream>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int) n; ++i)
#define fs first;
#define sc second
#define mp make_pair
typedef pair <int, int> pii;

int GLOB, n, k;
map <pii, int> M;

void try_(int x, int y)
{
	if (x == 0) return;
	if (M.count(mp(x, y))) return;
	if (M.count(mp(x + 1, y)) && M.count(mp(x + 1, y + 1)))
	{
		cout << GLOB + 1 << endl;
		exit(0);
	}
}

int main()
{
	freopen("bricks.in", "r", stdin);
	freopen("bricks.out", "w", stdout);

	cin >> n >> k;
	M.clear();
	forn(i, k)
	{
		GLOB = i;
		int x, y;
		scanf("%d%d", &x, &y);
		M[mp(x, y)] = 1;
		if (y == 1) try_(x - 1, y);
		else if (y == x) try_(x - 1, y - 1);
		else
		{
			try_(x - 1, y - 1);
			try_(x - 1, y);
		}
	}
	cout << -1 << endl;

	return 0;
}