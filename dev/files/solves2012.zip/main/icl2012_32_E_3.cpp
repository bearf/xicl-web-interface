#include <cstdlib>
#include <cstdio>
#include <map>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <ctime>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int) n; ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; i--)
#define fs first
#define sc second
#define mp make_pair
#define all(x) x.begin(), x.end()
#define pb push_back

typedef long long int64;
typedef pair <int, int> pii;


const int nmax = 10100;

typedef pair<int, int> pii;

int n;
int a[nmax], b[nmax], cur[nmax];
set<pii> now;
int res[nmax * 10];
int x[nmax];

void no(){
	puts("-1");
	exit(0);
}

int main()
{
	freopen("changes.in", "r", stdin);
	freopen("changes.out", "w", stdout);

	cin >> n;
	forn(i, n)
		scanf("%d", &a[i]);
	forn(i, n)
		scanf("%d", &b[i]);

	int mod = - 1;
	forn(i, n){
	 	int now = ((b[i] - a[i]) % n + n) % n;
	 	mod = now;
	}
	forn(i, n){
	 	int now = ((b[i] - a[i]) % n + n) % n;
	 	if (now != mod)
	 		no();
	}

	int cnt = n - mod;
	forn(i, n){
	 	int now = b[i] - a[i];
	 	while (now + cnt < 0)
	 		cnt += n;
	}
		forn(i, n)
			x[i] = (b[i] - a[i] + cnt) / n;
		forn(i, n)
			if (x[i] > 0)
				now.insert(mp(a[i], i));
		forn(i, n)
			cur[i] = a[i];
		bool done = 1;
		forn(i, cnt){
			int w = now.begin() -> sc;
			now.erase(now.begin());
			if (cur[w] < i){
				done = 0;
				break;
			}
			res[i] = w;
                        cur[w] += n;
                        x[w] --;
                        if (x[w] > 0)
                        	now.insert(mp(cur[w], w));
		}
		if (done){
			cout << cnt << endl;
			forn(i, cnt){
				printf("%d", res[i] + 1);
				if (i + 1 < cnt)
					printf(" ");
				else
					puts("");
			}
			exit(0);
		}
		no();
	return 0;
}
