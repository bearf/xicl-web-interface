#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <algorithm>
#include <string>
#include <string.h>
#include <set>
#include <map>

using namespace std;

#define pb push_back
#define mp make_pair
#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)
#define ZERO(x) memset(x, 0, sizeof(x))
#define COPY(x,y) memcpy(x, y, sizeof(y))
#define SIZE(x) (int)x.size()

typedef long long int64;

#define TASK "changes"

#define MAX 10100

int n;

int a[MAX];
int b[MAX];

int q1, q2;

int main() {
	vector <int> ans;
	int i;
	int g;
	int flag;
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
	scanf("%d", &n);
	
	fi(1, n) {
		scanf("%d", &a[i]);
	}
	fi(1, n) {
		scanf("%d", &b[i]);
	}

	fi(1, n) {
		q1 += a[i];
		q2 += b[i];
	}
	if (q1 != q2) {
		printf("-1\n");
		return 0;
	}
	vector <pair<int, int> > v;
	while (1) {
		v.clear();
		fi(1, n) {
			v.pb(mp(a[i], i));
		}
		sort(v.begin(), v.end());
		g = 0;
		flag = 1;

		fi(0, SIZE(v) - 1) {
			if (a[v[i].second] - g < 0) {
				printf("-1\n");
				return 0;
			}
			if (a[v[i].second] < b[v[i].second]) {
				ans.pb(v[i].second);
				g++;
				a[v[i].second] += n;
				flag = 0;
			}
		}

		if (flag) break;

		fi(1, n) {
			a[i] -= g;
		}

		if (SIZE(ans) > 100000) {
			printf("-1\n");
			return 0;
		}
	}

	printf("%d\n", SIZE(ans));
	fi(0, SIZE(ans) - 1) {
		printf("%d ", ans[i]);
	}
	printf("\n");
	return 0;
}