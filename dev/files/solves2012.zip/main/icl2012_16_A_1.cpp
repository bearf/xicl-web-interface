#include <iostream>
#include <sstream>
#include <stdio.h>
#include <cassert>
#include <memory.h>
#include <math.h>
#include <time.h>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <bitset>

using namespace std;

#define mp make_pair
#define pb push_back
#define all(a) (a).begin(),(a).end()
#define _(a,b) memset((a),b,sizeof(a))
#define sz(a) ((int)(a).size())

typedef long long lint;
typedef unsigned long long ull;
typedef pair < int , int > pii;

const int INF = 1000000000;
const lint LINF = 4000000000000000000LL;
const double eps = 1e-9;

void prepare(string s)
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
#else
	freopen((s + ".in").c_str(),"r",stdin);
	freopen((s + ".out").c_str(),"w",stdout);
#endif
}
const int nmax = 4 * 100005;
vector < int > X;
vector < pii > q;
int n,k;
set < int > used[nmax];

void read()
{
	scanf("%d%d",&n,&k);
	for (int i = 0; i < k; i ++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		X.pb(x);
		if (x > 1)
			X.pb(x - 1);
		q.pb(mp(x,y));
	}
	sort(all(X));
	X.erase(unique(all(X)),X.end());
}

bool isUsed(int x,int y)
{
	return used[x].find(y) != used[x].end();
}

bool unstable(int x,int y)
{
	if (x == n) return false;
	if (isUsed(x,y)) return false;
	return isUsed(x + 1,y) && isUsed(x + 1,y + 1);
}

bool ok(int x,int y)
{
	if (x <= 0 || x >= n) return false;
	if (y < 1 || y > x) return false;
	return true;
}

bool solve()
{
	read();
	for (int i = 0; i < sz(q); i ++)
	{
		int x = q[i].first, y = q[i].second;
		used[x].insert(y);
		if (ok(x - 1,y - 1) && unstable(x - 1,y - 1) 
			|| ok(x - 1,y) && unstable(x - 1,y))
		{
			printf("%d\n",i + 1);
			return false;
		}
	}
	printf("-1\n");
	return false;
}

int main()
{
	prepare("bricks");
	while (solve());
	return 0;
}
