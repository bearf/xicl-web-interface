#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <stack>
#include <string>
#include <sstream>
#include <cstring>
#include <cmath>
#include <ctime>
#include <numeric>

using namespace std;

#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define re return
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int) (x).size())
#define sqr(x) ((x) * (x))
#define sqrt(x) sqrt(abs(x))
#define rep(i, n) for (int i= 0; i < (n); i++)
#define rrep(i, n) for (int i = (n) - 1; i >= 0; i--)
#define re return
#define y0 y2369
#define y1 y347256
#define fill(x, y) memset(x, y, sizeof(x))

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef vector<string> vs;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef double D;
typedef long double LD;

template <class T> T abs(T x) { re x > 0 ? x : -x;}

#define FILENAME "trees"

int n;
int m;
int k;

int mas[100500];

int gcd(int a, int b) {
	re a ? gcd(b % a, a) : b;
}	

ll get(ll o, ll l1, ll l2) {
	re (l1 / o + 1) * (l2 / o + 1);
}

ll get(ll x, ll nx, ll tmp, ll l) {
	ll r = n;
	while (r - l > 1) {
		ll c = (l + r) / 2;
		ll o = (ll)(x / c + 1) * (nx / c + 1) - 1;		
		if (o == tmp)
			l = c;
		else
			r = c;	
	}
	re l;
}

int main() {
	freopen(FILENAME".in", "r", stdin);
	freopen(FILENAME".out", "w", stdout);

	cin >> n >> k;

	rep(i, k) {
		scanf("%d", &mas[i]);
	}

	if (k == 1) {
		ll ans = 1;
		int d = 1;
		int x = mas[0] - 1;
		int nx = n - x - 1;
		while (1) {
			ll tmp = (ll)(x / d + 1) * (nx / d + 1) - 1;
			if (tmp == 0)
				break;
			if (d <= 1000000) {
				ans += tmp;
				d++;
			}
			else {
				ll nd = get(x, nx, tmp, d);
				//cout << nd << endl;
				ans += (nd - d + 1) * tmp;
				d = nd + 1;
			}	
				
		}		
		cout << ans << endl;
	}
	else {
		int d = 0;
		rep(i, k - 1)
			d = gcd(d, mas[i + 1] - mas[i]);
		ll ans = 0;	
		ll l1 = mas[0] - 1;
		ll l2 = n - mas[k - 1];
		for (ll o = 1; o * o <= d; o++) {
			if (d % o == 0) {
				ans += get(o, l1, l2);
				if (d / o != o)
					ans += get(d / o, l1, l2);
			}
		}
		cout << ans << endl;
	}
	
	return 0;
}
