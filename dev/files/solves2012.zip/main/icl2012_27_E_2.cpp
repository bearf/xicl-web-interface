#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <list>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()
#define X first
#define Y second

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

const int N = 100000;

int n;

int maxA;
int sumA, sumB;

int a[N], b[N], c[N];
int k1[N], k2[N];

int szans;
int ans[N];

int mk;

vector<int> gen(){
    srand(time(NULL));

    forn(i, n){
        a[i] = rand() % 100 + 1;
        b[i] = a[i];
    }
   
    vector<int> ans;

    forn(i, n){
        int idx = rand() % n;
        ans.push_back(idx);
        forn(j, n)
            if(j == idx){
                b[j] += n - 1;
            }else{
                b[j]--;
            }
    }

    int add = 0;
    forn(i, n)
        add = min(add, b[i]);

    forn(i, n){
        a[i] -= add;
        b[i] -= add;
    }

    return ans;
}

int main(){
#ifdef home
    freopen("input.txt", "r", stdin);
//    freopen("output.txt", "w", stdout);
#else
    freopen("changes.in", "r", stdin);
    freopen("changes.out", "w", stdout);
#endif

    cin >> n;

    //vector<int> pa = gen();

    maxA = 0;
    
    forn(i, n){
        scanf("%d", &a[i]);
        maxA = max(maxA, a[i]);
        sumA += a[i];
    }
    forn(i, n){
        scanf("%d", &b[i]);
        sumB += b[i];
    }

    if(sumA != sumB){
        puts("-1");
        //throw;
        return 0;
    }

    forn(i, n){
        int sm = a[i] % n;
        int fm = b[i] % n;

        int d;
        if(fm <= sm)
            d = sm - fm;
        else
            d = sm + n - fm;


        if(i == 0)
            mk = d;
        else{
            if(mk != d){
                puts("-1");
                //throw;
                return 0;
            }
        }
    }

    forn(md, 20001){
        int k = md*n + mk;

        if(k > maxA + 10)
            break;

        bool good = true;

        forn(i, n){
            if(b[i] - a[i] + k < 0){
                good = false;
                break;
            }
            //if((b[i] - a[i] + k) % n != 0)
            //    throw;

            k1[i] = (b[i] - a[i] + k) / n;
            k2[i] = k - k1[i];

            if(k1[i] < 0 || k2[i] < 0){
                good = false;
                break;
            }
        }

        if(!good)
            continue;

        memcpy(c, a, sizeof(int)*n);

        szans = 0;

        forn(q, k){
            int mn = INF;
            int idx = -1;

            forn(i, n){
                if(k1[i] > 0 && c[i] < mn){
                    mn = c[i];
                    idx = i;
                }
            }

            if(idx == -1){
                good = false;
                break;
            }

            ans[szans++] = idx;

            forn(i, n){
                if(idx == i){
                    c[i] += n - 1;
                    k1[i]--;
                }else{
                    c[i]--;
                    k2[i]--;
                }

                if(k1[i] < 0 || k2[i] < 0 || c[i] < 0){
                    good = false;
                    break;
                }
            }

            if(!good)
                break;
        }

        forn(i, n)
            if(k1[i] != 0 || k2[i] != 0 || c[i] != b[i]){
                good = false;
                break;
            }

        if(!good)
            continue;

        printf("%d\n", szans);

        forn(i, szans){
            printf("%d", ans[i]  + 1);
            printf((i + 1 == szans) ? "\n" : " ");
        }

        return 0;
    }

    //throw;
    puts("-1");
    return 0;
}
