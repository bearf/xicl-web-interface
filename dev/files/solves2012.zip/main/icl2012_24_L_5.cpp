#include <stdio.h>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#include <math.h>

using namespace std;

#define pi 3.14159265358979323846

#define mp make_pair
#define pb push_back
#define all(a) a.begin(),a.end()

typedef long long li;
typedef double ld;

#define FILE "race"
void solve();
int main()
{
#ifdef _DEBUG
	freopen ("in.txt", "r", stdin);
	cout<<FILE<<endl;
#else
	freopen (FILE ".in", "r", stdin);
	freopen (FILE ".out", "w", stdout);
#endif
	int t=1;
	while (t--)
		solve();
	return 0;
}

const long double E=0.00000000001;

//#define int li

int n, k;
vector< pair <ld, pair<int, int> > > a;

void solve()
{
	cin>>n;

	for(int i=0;i<n;i++)
	{
		ld cur;
		scanf("%lf",&cur);
//		cur=pi-cur;
		if((ld)2*cur<pi)
			a.push_back(mp(cur,mp(1,i)));
		else
			a.push_back(mp(pi-cur,mp(-1,i)));
	}
	sort(all(a));
	reverse(all(a));
	ld mx=-10,mn=n+2;
	ld mxnow=-10, mnnow=n+2;
	vector<int> res;
	ld r=a[0].first;
	for(int i=0;i<n;i++)
	{
		if(a[i].first-r>E || r-a[i].first>E)
		{
			mn=mnnow;
			mx=mxnow;
			r=a[i].first;
		}
		int cur=a[i].second.second;
		if(a[i].second.first==-1)
		{
			bool t=true;
			if(cur>mn)
				t=false;
			if(t)
				res.push_back(cur+1);
		}
		if(a[i].second.first==1)
		{
			bool t=true;
			if(cur<mx)
				t=false;
			if(t)
				res.push_back(cur+1);
		}
		if(cur>mxnow)
			mxnow=cur;
		if(cur<mnnow)
			mnnow=cur;
	}
	printf("%d\n", res.size());
	for(int i=0;i<res.size();i++)
		printf("%d ",res[i]);
}