#include <stdio.h>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

#define mp make_pair
#define pb push_back

typedef long long li;
typedef double ld;

#define FILE "darts"
void solve();
int main()
{
#ifdef _DEBUG
	freopen ("in.txt", "r", stdin);
	cout<<FILE<<endl;
#else
	freopen (FILE ".in", "r", stdin);
	freopen (FILE ".out", "w", stdout);
#endif
	int t=1;
	while (t--)
		solve();
	return 0;
}

//#define int li

int n, m;
int k;

vector < int > v, h;
vector <int> segs;
vector <int> b;
int bp (int val)
{
	int l=0, r=b.size();
	while (l+1<r)
	{
		int mm=l+r; mm/=2;
		if (b[mm]>val)
			r=mm;
		else
			l=mm;
	}
	return l;
}
void solve()
{
	cin>>n>>m>>k;
	for (int i=0; i<k; i++)
	{
		int q, w;
		cin>>q>>w;
		v.pb(q);
		h.pb(w);
	}
	v.pb(0);
	h.pb(0);
	v.pb(n);
	h.pb(m);
	sort (v.begin(), v.end());
	v.resize( unique(v.begin(), v.end()) - v.begin() );
	sort (h.begin(), h.end());
	h.resize( unique(h.begin(), h.end()) - h.begin() );
	//cout<<v.size()<<' '<<h.size()<<endl;
	for (int i=0; i<v.size(); i++)
		for (int j=i+1; j<v.size(); j++)
			b.pb(v[j]-v[i]);
	sort (b.begin(), b.end());
	b.resize( unique (b.begin(), b.end()) - b.begin() );
	segs.resize(b.size());
	for (int i=0; i<v.size(); i++)
		for (int j=i+1; j<v.size(); j++)
			segs[bp(v[j]-v[i])]++;
	int ans=0;
	for (int i=0; i<h.size(); i++)
		for (int j=0; j<h.size(); j++)
		{
			int cur=bp(h[j]-h[i]);
			if ( b[cur]==h[j]-h[i] )
				ans+=segs[cur];
		}
	cout<<ans;
}