#include <cstdio>
#include <cstdlib>
#include <map>
#include <set>

using std::set;
using std::map;

#define trs(cont, it) for(set<long>::iterator it=cont.begin(); it!=cont.end(); ++it)
#define tr(cont, it) for(map<long,long>::iterator it=cont.begin(); it!=cont.end(); ++it)
#define abs(x) (x>0 ? x : -(x))

int main(int argc, char* argv[]) {
	map <long, long> ver, gor;
	set <long> gorP, verP;
	long n, m, k, tmpX, tmpY, i;
	long long count = 0;
	freopen("darts.in", "r", stdin);
	freopen("darts.out", "w", stdout);
	scanf("%ld%ld%ld", &n, &m, &k);
	gorP.insert(0);
	gorP.insert(n);
	verP.insert(0);
	verP.insert(m);
	for(i=0; i<k; ++i) {
		scanf("%ld%ld", &tmpX, &tmpY);
		gorP.insert(tmpX);
		verP.insert(tmpY);
	}

	trs(gorP, it1) {
		trs(gorP, it2) {
			gor[abs(*it1 - *it2)]++;
		}
	}
	

	trs(verP, it1) {
		trs(verP, it2) {
			ver[abs(*it1 - *it2)]++;
		}
	}

	tr(gor, it) {
		if(it->first)
			count += (long long)((it->second * ver[it->first])/4);
	}
	
	printf("%I64d\n", count);

	return 0;
}
