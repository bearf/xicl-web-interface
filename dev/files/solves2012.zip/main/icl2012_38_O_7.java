import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.StringTokenizer;


public class Main {


	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("darts.in"));
		BufferedWriter bw = new BufferedWriter(new FileWriter("darts.out"));

		StringTokenizer st = new StringTokenizer(br.readLine());
		
		long n = Long.parseLong(st.nextToken());
		long m = Long.parseLong(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		
		long[] x = new long[k+2];
		long[] y = new long[k+2];
		
		x[k+1] = n;
		y[k+1] = m;
		
		for (int i = 0; i<k; i++){
			long a,b;
			st = new StringTokenizer(br.readLine());
			a = Long.parseLong(st.nextToken());
			b = Long.parseLong(st.nextToken());
			
			x[i] = a;
			y[i] = b;
		}

		Arrays.sort(x);
		Arrays.sort(y);
		
		HashMap<Long, Long> map = new HashMap<Long, Long>();
		
		k+=2;
		
		for (int i = 0; i<k; i++)
			for (int j = i+1; j<k; j++){
				if (x[j]-x[i]>0){
					long d = x[j] - x[i];
					if (map.containsKey(d)){
						long num = map.get(d);
						map.put(d, num+1);
					} else {
						map.put(d, (long) 1);
					}
				}
			}
		
		long ans = 0;
		
		for (int i = 0; i<k; i++)
			for (int j = i+1; j<k; j++){
				ans += map.get(y[j] - y[i]);
			}
		
		bw.write(String.valueOf(ans));
		
		br.close();
		bw.close();
	}

}
