#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <cstdio>

using namespace std;

int n, k;
int minE, maxE, last, x, nowGcd;
long long ans;

int gcd(int x, int y) {
	if (y == 0) return x;
	return gcd(y, x % y);
}

void add(long long x) {
	ans += (1 + (minE - 1)/x)*(1 + (n - maxE)/x);
}

int main() {
	freopen("trees.in", "r", stdin);
	freopen("trees.out", "w", stdout);
	cin >> n >> k;
	if (k == 1) {
		cin >> minE;
		ans = minE*(1+n-minE);
	} else {
		scanf("%d ", &minE);
		last = minE;
		for (int i = 1; i < k - 1; i++) {
			scanf("%d ", &x);
			if (i == 1) nowGcd = x-minE; else
				nowGcd = gcd(nowGcd, x - last);
			last = x;
		}
		scanf("%d ", &maxE);
		if (k == 2) nowGcd = maxE - minE; else
			nowGcd = gcd(nowGcd, maxE - last);
		for (int i = 1; i*i <= nowGcd; i++) {
			if (nowGcd % i == 0) {
				add(i);
				if (i * i != nowGcd) {
					add(nowGcd / i);
				}
			}
		}
	}
	cout << ans << endl;
}