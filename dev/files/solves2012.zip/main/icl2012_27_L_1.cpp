#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <list>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()
#define X first
#define Y second

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

int main(){
#ifdef home
    freopen("input.txt", "r", stdin);
//    freopen("output.txt", "w", stdout);
#else
    freopen("race.in", "r", stdin);
    freopen("race.out", "w", stdout);
#endif

    int n;
    cin >> n;
    vector<ld> a(n);

    vector<int> ok;

    forn(i, n){
        double d;
        scanf("%lf", &d);
        a[i] = d;

        if(fabs(a[i] - PI/2) < EPS)
            ok.pb(i);
    }

    reverse(all(a));
    
    {
        set<ld> s;
        forn(i, sz(a)){
            if(a[i]+EPS < PI/2){
                ld L = a[i], R = PI-a[i];
                set<ld>::iterator it = s.lower_bound(L);

                bool bad = false;

                while(it != s.end()){
                    ld v = *it;

                    if(L+EPS < v && v+EPS < R){
                        bad = true;
                        break;    
                    }

                    if(R+EPS < v) break;
                    it++;
                }

                if(!bad)
                    ok.pb(n - i - 1);
            }

            s.insert(a[i]);
        }

        s.clear();
        ford(i, sz(a)){
            if(a[i]+EPS > PI/2 + EPS){
                ld L = PI-a[i], R = a[i];
                set<ld>::iterator it = s.lower_bound(L);

                bool bad = false;

                while(it != s.end()){
                    ld v = *it;

                    if(L+EPS < v && v+EPS < R){
                        bad = true;
                        break;    
                    }

                    if(R+EPS < v) break;
                    it++;
                }

                if(!bad)
                    ok.pb(n - i - 1);                
            }
            s.insert(a[i]);
        }
    }


    sort(all(ok));
    ok.erase(unique(all(ok)), ok.end());

    cout << sz(ok) << endl;
    forn(i, sz(ok)){
        if(i)
            printf(" ");
        printf("%d", ok[i]+1);
    }
    puts("");
    return 0;
}