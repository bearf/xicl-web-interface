#include <stdio.h>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <set>
#include <string>

using namespace std;

#define mp make_pair
#define pb push_back

typedef long long li;
typedef double ld;

#define FILE "bricks"
void solve();
int main()
{
#ifdef _DEBUG
	freopen ("in.txt", "r", stdin);
	cout<<FILE<<endl;
#else
	freopen (FILE ".in", "r", stdin);
	freopen (FILE ".out", "w", stdout);
#endif
	int t=1;
	while (t--)
		solve();
	return 0;
}

//#define int li

int n, k;
set <pair <int, int> > is; 

pair <int, int> br[200500];

void solve()
{
	cin>>n>>k;
	for (int i=0; i<k; i++)
		cin>>br[i].first>>br[i].second;
	/*for (int i=0; i<k; i++)
	{
		pair <int, int> cur=br[i];
		is.insert(cur);
		if (cur.first>1 && cur.second<cur.first)
			is.insert( mp(cur.first-1, cur.second) );
		if (cur.first>1 && cur.second>1)
			is.insert( mp(cur.first-1, cur.second-1) );
		if (cur.second>1)
			is.insert( mp(cur.first, cur.second-1) );
		if (cur.second<cur.first)
			is.insert( mp(cur.first, cur.second+1) );
	}*/
	for (int i=0; i<k; i++)
	{
		pair <int, int> cur=br[i];
		is.insert(cur);
		pair <int, int> now=mp(cur.first-1, cur.second);
		if (is.find(now)==is.end() && now.first>0 && now.second>0 && now.second<=now.first)
		{
			if (is.find( mp(now.first+1, now.second+1) )!=is.end() )
			{
				cout<<i+1;
				return;
			}
		}
		now=mp(cur.first-1, cur.second-1);
		if (is.find(now)==is.end() && now.first>0 && now.second>0)
		{
			if (is.find( mp(now.first+1, now.second) )!=is.end() )
			{
				cout<<i+1;
				return;
			}
		}
	}
	cout<<"-1";
}