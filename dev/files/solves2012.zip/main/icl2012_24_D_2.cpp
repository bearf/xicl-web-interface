#include <stdio.h>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#include <math.h>

using namespace std;

#define mp make_pair
#define pb push_back
#define pii pair<int,int> 

typedef long long li;
typedef double ld;

#define FILE "millenium"
void solve();
int main()
{
#ifdef _DEBUG
	freopen ("in.txt", "r", stdin);
	cout<<FILE<<endl;
#else
	freopen (FILE ".in", "r", stdin);
	freopen (FILE ".out", "w", stdout);
#endif
	int t=1;
	while (t--)
		solve();
	return 0;
}

//#define int li

map<int,int > s;

void solve()
{
	int n;
	cin>>n;
	int a,b;
	cin>>a>>b;
	for(int i=0;i<n;i++)
	{
		int r,rr;
		cin>>r>>rr;
		s[r]++;
	}
	long long t=0;
	int os=0;
	for( map<int,int> ::iterator i=s.begin();i!=s.end(); i++)
	{
		pii cur=*i;
		if(t<cur.first)
		{
			t=cur.first-1;
			os=0;
		}
		if(cur.second>os)
		{
			t+=(cur.second-os)/b;
			os=b-(cur.second-os)%b;
			if(os==b)
				os=0;
			else
				t++;
		}
		else
			os-=cur.second;
	}
	cout<<t;
}