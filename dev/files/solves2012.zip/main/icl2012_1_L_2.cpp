#include<iostream>
#include<cmath>
#include<algorithm>
#include<set>
#include<map>
#include<vector>
#include<stack>
#include<queue>
#include<deque>
#include<list>
#include<string>
#include<cstring>
#include<cstdio>

using namespace std;

int main(){
	freopen("race.in","rt",stdin);
	freopen("race.out","wt",stdout);
	int n;
	cin>>n;
	int d[100013];
	bool b[100013];;
	set <int> s;
	for (int i=0;i<n;i++){
		double tt;
		cin>>tt;
		d[i]=(int)(tt*100000+0.1);
		b[i]=1;
	}
	for (int i=0;i<n;i++){
		if (d[i]>157079){
			set <int>::iterator it1 = s.lower_bound(314159-d[i]); //3.141592653589
			set <int>::iterator it2 = s.lower_bound(d[i]-1);
			if (it1==s.end() && it2==s.end()){
			}
			else{
				if ((it1==s.end() && it2!=s.end() && 314159-d[i]<=(*it2) && (*it2)<=d[i]-1)  
					|| (it1!=s.end() && it2==s.end() && 314159-d[i]<=(*it1) && (*it1)<=d[i]-1) 
					|| (it1!=s.end() && it2!=s.end() && (*it1)<=314159-d[i] && d[i]-1<=(*it2) &&(*it1)<=(*it2))){
					b[i]=0;
				}
			}
		}
		s.insert(d[i]);
	}
	s.clear();
	for (int i=n-1;i>=0;i--){
		if (d[i]<=157079){
			set <int>::iterator it1 = s.lower_bound(314159-d[i]); //3.141592653589
			set <int>::iterator it2 = s.lower_bound(d[i]+1);
			if (it1==s.end() && it2==s.end()){
			}
			else{
				if ((it1==s.end() && it2!=s.end() && d[i]+1<=(*it2) && (*it2)<=314159-d[i])  
					|| (it1!=s.end() && it2==s.end() && d[i]+1<=(*it1) && (*it1)<=314159-d[i]) 
					|| (it1!=s.end() && it2!=s.end() && (*it1)>=314159-d[i] && d[i]+1>=(*it2) &&(*it1)>=(*it2))){
					b[i]=0;
				}
			}
		}
		s.insert(d[i]);
	}
	int ans=0;
	
	for (int i=0;i<n;i++){
		if (b[i]) ans++;
	}
	cout<<ans<<endl;
	for (int i=0;i<n;i++){
		if (b[i]) cout<<i+1<<' ';
	}
	return 0;

}