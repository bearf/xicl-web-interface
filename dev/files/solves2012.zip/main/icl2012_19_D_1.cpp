#include <cstdio>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <iostream>
#include <cmath>

using namespace std;

const int INF = (int) 1e9;
const double EPS = 1e-8;
const double PI = acos(-1.);

typedef pair<int, int> pii;
typedef long long ll;

#define NAME "millenium"

int x[100500], y[100500];
int ind[100500];
int ans[100500];

bool cmp(int i, int j)
{
	return x[i] < x[j];
}

int main()
{
	freopen (NAME".in", "r", stdin);
	freopen (NAME".out", "w", stdout);
	int n, a, b;
	int i;
	scanf("%d%d%d", &n, &a, &b);
	for (i = 0; i < n; ++i)
	{
		scanf("%d%d", &x[i], &y[i]);
		ind[i] = i;
	}
	sort(ind, ind + n, cmp);
	int res = 0;
	for (i = 0; i < n; ++i)
	{
		if (i < b)
			ans[i] = max(1, x[i]);
		else
			ans[i] = max(ans[i - b] + 1, x[i]);
		res = max(res, ans[i]);
	}
	printf("%d\n", res);
	return 0;
}