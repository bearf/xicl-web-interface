import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;


public class Solution {


	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("darts.in"));
		BufferedWriter bw = new BufferedWriter(new FileWriter("darts.out"));

		StringTokenizer st = new StringTokenizer(br.readLine());
		
		long n = Long.parseLong(st.nextToken());
		long m = Long.parseLong(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		
		long[] x = new long[k+2];
		long[] y = new long[k+2];
		
		x[k] = n;
		y[k] = m;
		
		for (int i = 0; i<k; i++){
			long a,b;
			st = new StringTokenizer(br.readLine());
			a = Long.parseLong(st.nextToken());
			b = Long.parseLong(st.nextToken());
			
			x[i] = a;
			y[i] = b;
		}

		Arrays.sort(x);
		Arrays.sort(y);
		
		List<Long> dx = new ArrayList<Long>();
		dx.add(x[0]);
		for (int i = 1; i<k+2; i++){
			if (x[i]!=x[i-1]) dx.add(x[i]);
		}
		
		List<Long> dy = new ArrayList<Long>();
		dy.add(y[0]);
		for (int i = 1; i<k+2; i++){
			if (y[i]!=y[i-1]) dy.add(y[i]);
		}
		
		HashMap<Long, Long> map = new HashMap<Long, Long>();
		
		k+=2;
		
		for (int i = 0; i<dx.size(); i++)
			for (int j = i+1; j<dx.size(); j++){
				if (dx.get(j)-dx.get(i)>0){
					long d = dx.get(j)-dx.get(i);
					if (map.containsKey(d)){
						long num = map.get(d);
						map.put(d, num+1);
					} else {
						map.put(d, (long) 1);
					}
				}
			}
		
		long ans = 0;
		
		for (int i = 0; i<dy.size(); i++)
			for (int j = i+1; j<dy.size(); j++){
				if (dy.get(j)-dy.get(i)>0)
				if (map.containsKey( dy.get(j)-dy.get(i) )) ans += map.get( dy.get(j)-dy.get(i) );
			}
		
		bw.write(String.valueOf(ans));
		
		br.close();
		bw.close();
	}

}
