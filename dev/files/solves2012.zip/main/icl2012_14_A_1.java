import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Locale;
import java.util.StringTokenizer;

public class Solution {
	private static final String TASKNAME = "bricks";

	private void solve() throws IOException {
		int n = nextInt();
		int m = nextInt();
		HashSet<Long> set = new HashSet<Long>();
		for (int i = 0; i < m; ++i) {
			int y = nextInt();
			int x = nextInt();
			int c = x;
			int row = n - y + 1;
			long key = 1l * row * n + c;
			set.add(key);
//			System.err.println(row + " " + c);
			if (row == n) {
				continue;
			}
			int prow = row + 1;
			long pkey = 1l * prow * n + c;
			
			boolean fail = false;
			int colsInRow = y;
			if (!set.contains(pkey)) {
				if (c + 1 <= colsInRow) {
					long siblingKey = 1l * row * n + c + 1;
					if (set.contains(siblingKey)) {
						fail = true;
					}
				}
			}
			if (c > 1) {
				pkey = 1l * prow * n + c - 1;
				if (!set.contains(pkey)) {
					long siblingKey = 1l * row * n + c - 1;
					if (set.contains(siblingKey)) {
						fail = true;
					}
				}
			}
			if (fail) {
				println((i + 1));
				return;
			}
		}
		println(-1);
	}

	public static void main(String[] args) {
		long time = System.currentTimeMillis();
		Locale.setDefault(Locale.US);
		new Solution().run();
		System.err.printf("%.3f\n", 1e-3 * (System.currentTimeMillis() - time));
	}

	private StringTokenizer tokenizer;
	private BufferedReader reader;
	private PrintWriter writer;

	private String nextToken() throws IOException {
		while (tokenizer == null || !tokenizer.hasMoreTokens()) {
			tokenizer = new StringTokenizer(reader.readLine());
		}
		return tokenizer.nextToken();
	}

	private int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	private long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	private double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	private void print(Object o) {
		writer.print(o);
	}

	private void println(Object o) {
		writer.println(o);
	}

	private void printf(String format, Object... o) {
		writer.printf(format, o);
	}

	private void run() {
		try {
			reader = new BufferedReader(new FileReader(TASKNAME + ".in"));
			writer = new PrintWriter(TASKNAME + ".out");

			solve();

			reader.close();
			writer.close();

		} catch (IOException e) {
			e.printStackTrace();
			System.exit(13);
		}
	}
}
