#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <map>
#include <set>

using namespace std;

int main() {
	freopen("darts.in", "r", stdin);
	freopen("darts.out", "w", stdout);
	set<int>sx,sy;
	int N, M, K;
	cin >> N >> M >> K;
	for(int i = 0; i < K; ++i)
	{
		int x,y;
		scanf("%i%i",&x,&y);
		sx.insert(x);
		sy.insert(y);
	}
	sx.insert(0);
	sx.insert(N);
	sy.insert(0);
	sy.insert(M);
	map<int, pair<int, int> > m;
	vector<int>vx(sx.size()), vy(sy.size());
	int I = -1;
	for(set<int>::iterator it = sx.begin(); it != sx.end(); ++it)
	{
		vx[++I] =*it;

	}
	I = -1;
	for(set<int>::iterator it = sy.begin(); it != sy.end(); ++it)
	{
		
		vy[++I] = *it;
	}
	for(int i = 0; i < vx.size(); ++i)
	{
		for(int j = i + 1; j < vx.size(); ++j)
		{
			int t = vx[j] - vx[i];
			++m[t].first;
		}
	}
	long long int cnt = 0;

	for(int i = 0; i < vy.size(); ++i)
	{
		for(int j = i + 1; j < vy.size(); ++j)
		{
			int t = vy[j] - vy[i];
			if(m.count(t))
				cnt += m.find(t)->second.first;
		}
	}
	
	
	cout << cnt;
	
	return 0;
}