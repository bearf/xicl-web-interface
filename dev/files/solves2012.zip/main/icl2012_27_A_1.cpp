#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <list>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()
#define X first
#define Y second

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

int main(){
#ifdef home
    freopen("input.txt", "r", stdin);
//    freopen("output.txt", "w", stdout);
#else
    freopen("bricks.in", "r", stdin);
    freopen("bricks.out", "w", stdout);
#endif

    int n, k;
    cin >> n >> k;

    map<int, map<int, int> > cnt, used;

    forn(i, k){
        int x, y;
        scanf("%d%d", &x, &y);
        x--, y--;

        if(x > 0){
            if(y <= x-1){
                cnt[x-1][y]++;
                if(cnt[x-1][y] == 2 && !used[x-1][y]){
                    printf("%d\n", i+1);
                    exit(0);
                }
            }
            if(y > 0){
                cnt[x-1][y-1]++;
                if(cnt[x-1][y-1] == 2 && !used[x-1][y-1]){
                    printf("%d\n", i+1);
                    exit(0);
                }
            }
        }

        used[x][y] = true;
    }

    puts("-1");

    return 0;
}