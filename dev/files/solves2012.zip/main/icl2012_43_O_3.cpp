#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <string>
#include <string.h>
#include <math.h>
#include <memory.h>
using namespace std;

#define li int
#define pb push_back
#define mp make_pair
#define all(a) a.begin(),a.end()

li n,m,k;
vector <li> vert, gor, dg, dv;
li abc(li x)
{
	if(x>0)
		return x;
	return -x;
}
int main()
{
	//freopen("input.txt", "r", stdin);
	freopen("darts.in", "r", stdin);
	freopen("darts.out", "w", stdout);
	li i,j;
	long long res=0;
	cin>>n>>m>>k;
	li x, y, d;
	for(i=0;i<k;i++)
	{
		cin>>x>>y;
		gor.pb(x);
		vert.pb(y);
	}
	gor.pb(n), gor.pb(0);
	vert.pb(m), vert.pb(0);
	sort(gor.begin(), gor.end());
	gor.resize( unique(gor.begin(), gor.end())-gor.begin());
	sort(vert.begin(), vert.end());
	vert.resize(unique(vert.begin(), vert.end())-vert.begin());
	for(i=0;i<gor.size();i++)
		for(j=i+1;j<gor.size();j++)
				dg.pb(gor[j]-gor[i]);
	for(i=0;i<vert.size();i++)
		for(j=i+1;j<vert.size();j++)
			dv.pb(abc(vert[j]-vert[i]));
	sort(all(dg));
	sort(all(dv));
	dg.pb(2000000002);
	dv.pb(2000000003);
	i=0;j=0;
	while(i<dg.size())
	{
		li cur=1, cur1=0;
		while(i<dg.size()-1 && dg[i]==dg[i+1])
		{
			cur++;
			i++;
		}
		while(j<dv.size() && dv[j]<=dg[i])
		{
			if(dv[j]==dg[i])
				cur1++;
			j++;
		}
		res+=(long long)cur*(long long)cur1;
		i++;
	}
	cout<<res;
	return 0;
}