import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {

	void _solve() throws Exception {
		int m = nextInt();
		int[] curCount = new int[m];
		int initSum = 0;
		for (int i = 0; i < m; ++i) {
			curCount[i] = nextInt();
			initSum += curCount[i];
		}
		int[] goal = new int[m];
		int goalSum = 0;
		for (int i = 0; i < m; ++i) {
			goal[i] = nextInt();
			goalSum += goal[i];
		}
		if (initSum != goalSum) {
			out.print(-1);
			return;
		}
		ArrayList<Integer> ans = new ArrayList<Integer>();
		while (true) {
			boolean canDo = true, complete = true;
			int indToChange = -1, minNum = Integer.MAX_VALUE;
			for (int i = 0; i < m; ++i) {
				if (curCount[i] != goal[i]) {
					complete = false;
				}
				if (curCount[i] < goal[i] && curCount[i] < minNum) {
					indToChange = i;
					minNum = curCount[i];
				} else if (curCount[i] == 0) {
					canDo = false;
				}
			}
			if (complete) {
				break;
			}
			if (!canDo) {
				out.print(-1);
				return;
			}
			ans.add(indToChange + 1);
			for (int i = 0; i < m; ++i) {
				if (i == indToChange) {
					curCount[i] += m - 1;
				} else {
					--curCount[i];
				}
			}
		}
		out.println(ans.size());
		for (int a : ans) {
			out.print(a + " ");
		}
	}
	
	BufferedReader in;
	StringTokenizer stringTokenizer;
	PrintWriter out;
	
	long nextLong() {
		return Long.parseLong(nextToken());
	}
	
	double nextDouble() {
		return Double.parseDouble(nextToken());
	}
	
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	
	String nextToken() {
		while (!stringTokenizer.hasMoreTokens()) {
			String line = null;
			try {
				line = in.readLine();
			} catch (IOException e) {
				NOO(e);
			}
			if (line == null) {
				return null;
			} else {
				stringTokenizer = new StringTokenizer(line);
			}
		}
		return stringTokenizer.nextToken();
	}
	
	public void run() {
		try {
			_solve();
		} catch (Exception e) {
			NOO(e);
		} finally {
			out.close();
		}
	}
	
	void NOO(Exception e) {
		e.printStackTrace();
		System.exit(42);
	}
	
	public Solution(String name) {
		try {
			in = new BufferedReader(new FileReader(name + ".in"));
			stringTokenizer = new StringTokenizer("");
			out = new PrintWriter(new FileWriter(name + ".out"));
		} catch (Exception e) {
			NOO(e);
		}
	}
	
	public static void main(String[] args) {
		new Solution("changes").run();
	}

}
