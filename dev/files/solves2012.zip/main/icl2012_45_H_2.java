import java.util.*;
import java.io.*;
import java.math.*;

public class Solution {
	
	Scanner in;
	PrintWriter out;
	
	int a[] = new int [100500];
	int n,k;

	public static void main(String[] args) throws IOException {
		(new Solution()).run();
	}
	
	int gcd(int a,int b) {
		return (b==0?a:gcd(b,a%b));
	}
	
	BigInteger getKol (int num) {
		if (num == 0)
			return BigInteger.ONE;
		
		int i;
		BigInteger ans = BigInteger.ONE;
		int pred = num, cur = pred;
		
		for (i = 2;i <= num;i++) {
			cur = num / i;
			if (cur == pred)
				break;
			ans = ans.add(BigInteger.valueOf(pred));
			pred = cur;
		}
		
		if (i == num + 1) {
			ans = ans.add(BigInteger.valueOf(cur));
			return ans;
		}
		
		int lc = i - 1, l = i - 1, r, mid, rightest;
		while (l <= num) {
			r = num;
			rightest = l;
			while (l <= r) {
				mid = (l + r) / 2;
				if (num / mid == cur) {
					rightest = mid;
					l = mid + 1;
				}else
				{
					r = mid - 1;
				}
			}
			ans.add(BigInteger.valueOf(cur).multiply(BigInteger.valueOf(rightest - l + 1)));
			lc = rightest + 1;
			l = lc;
			cur = num / l;
		}
		
		return ans;
	}
	
	void solve1 () {
		BigInteger ans;
		
		ans = getKol(a[0] - 1).multiply(getKol(n - a[0]));
		out.print(ans);
	}
	
	public void run () throws IOException {
		
		//in = new Scanner(System.in);
		//out = new PrintWriter(System.out);
		in = new Scanner(new File("trees.in"));
		out = new PrintWriter(new File("trees.out"));

		n = in.nextInt(); k = in.nextInt();
		for (int i=0;i<k;i++)
			a[i] = in.nextInt();
		int g=a[1]-a[0];
		for (int i=1;i<k-1;i++)
			g=gcd(g,a[i+1]-a[i]);

		//������ ��. k=1

		if (k==1)
		{
			solve1();
		}else
		{
			long ans=0;
		 	for (int i=1;i<=g;i++)
				if (g%i==0)
				{
					int bef=(a[0]+i-1)/i;
					int aft=(n-a[k-1]+i)/i;
					ans += (long) bef * (long) aft;
				}
		 	out.print(ans);
		}
		
		out.flush();
		
	}

}
