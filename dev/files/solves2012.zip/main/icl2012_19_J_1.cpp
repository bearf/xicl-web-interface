#include <cstdio>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <iostream>
#include <cmath>

using namespace std;

const int INF = (int) 1e9;
const double EPS = 1e-8;
const double PI = acos(-1.);

typedef pair<int, int> pii;
typedef long long ll;

#define NAME "islands"

const int di[] = {-1, 0, 1, 0};
const int dj[] = {0, 1, 0, -1};

bool use[100500][2];
char* s[100500];
int n, m;

void dfs(int u, int f)
{
	use[u][f] = true;
	int i = u/m;
	int j = u%m;
	for (int y = 0; y < 4; ++y)
	{
		int ni = i + di[y];
		int nj = j + dj[y];
		int nv = ni*m + nj;
		if (ni >= 0 && ni < n && nj >= 0 && nj < m && 
			(f == 0 && s[ni][nj] >= '1' && !use[nv][min(s[ni][nj] - '1', 1)]))
		{
			dfs(nv, min(s[ni][nj] - '1', 1));
		}
		if (ni >= 0 && ni < n && nj >= 0 && nj < m && 
			f == 1 && !use[nv][min(s[ni][nj] - '0', 1)])
		{
			dfs(nv, min(s[ni][nj] - '0', 1));
		}
	}
}

int main()
{
	freopen (NAME".in", "r", stdin);
	freopen (NAME".out", "w", stdout);
	scanf("%d%d", &n, &m);
	int i, j;
	for (i = 0; i < n; ++i)
	{
		s[i] = new char[m + 5];
		scanf("%s", s[i]);
	}
	int x1, x2, y1, y2;
	scanf("%d%d", &x1, &y1);
	--x1; --y1;
	int from = x1*m + y1;
	scanf("%d%d", &x2, &y2);
	--x2; --y2;
	int to = x2*m + y2;
	if (s[x1][y1] == '0')
		dfs(from, 0);
	else
		dfs(from, 1);
	for (i = 0; i < n; ++i)
	{
		delete [] s[i];
	}
	if (use[to][0] || use[to][1])
		printf("YES\n");
	else
		printf("NO\n");
	return 0;
}