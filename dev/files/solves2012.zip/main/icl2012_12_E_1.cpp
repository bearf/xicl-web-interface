#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <set>
#include <string>
#include <vector>

using namespace std;

#define forn(i,n) for (int i = 0; i < (n); i++)
#define forit(it,v) for (typeof((v).end()) it = (v).begin(); it != (v).end(); ++it)
#define sz(v) ((int)((v).size()))
typedef long long LL;
typedef long long ll;
typedef pair<int, int> ii;

#define TASK "changes"

#define N 10004
int n;
int a[N], b[N];
int c[N], d[N];

int main() {
	assert(freopen(TASK ".in", "r", stdin));
	assert(freopen(TASK ".out", "w", stdout));
	scanf("%d", &n);
	forn(i, n) scanf("%d", &a[i]);
	forn(i, n) scanf("%d", &b[i]);
	int k = -1, maxd = -1000000000;
	forn(i, n) if (a[i] - b[i] > maxd) maxd = a[i] - b[i], k = i;
	
	int r = a[k] - b[k];
	forn(i, n) {
		if ((b[i]-a[i]+r) % n) return 0 * printf("-1\n");
		d[i] = (b[i] - a[i] + r) / n;
	}
	
	set<ii> s;
	forn(i, n) if (d[i] > 0) s.insert(ii(a[i], i));
	int sub = 0;
	
	vector<int> ans;
	while (!s.empty()) {
		ii z = *s.begin();
		if (z.first - sub < 0) return 0 * printf("-1\n");
		s.erase(s.begin());
		int i = z.second;
		ans.push_back(i);
		a[i] += n;
		sub++;
		d[i]--;
		if (d[i] > 0) s.insert(ii(a[i], i));
	}
	
	forn(i, n) if (a[i]-sub != b[i]) return 0 * printf("-1\n");
	
	printf("%d\n", sz(ans));
	forn(i, sz(ans)) printf("%d%c", ans[i] + 1, " \n"[i+1==sz(ans)]);
	
	return 0;
}
