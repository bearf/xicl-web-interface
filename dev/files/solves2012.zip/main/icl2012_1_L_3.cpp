#include<iostream>
#include<cmath>
#include<algorithm>
#include<set>
#include<map>
#include<vector>
#include<stack>
#include<queue>
#include<deque>
#include<list>
#include<string>
#include<cstring>
#include<cstdio>

#define PI 3.14159265358979323
#define EPS 1e-7

using namespace std;

int main(){
	freopen("race.in","rt",stdin);
	freopen("race.out","wt",stdout);
	int n;
	cin>>n;
	double d[100013];
	bool b[100013];;
	set <double> s;
	for (int i=0;i<n;i++){
		cin>>d[i];
		b[i]=1;
	}
	for (int i=0;i<n;i++){
		if (d[i]>PI/2){
			set <double>::iterator it1 = s.lower_bound(PI-d[i]+EPS);
			set <double>::iterator it2 = s.lower_bound(d[i]-EPS);
			if (it1==s.end() && it2==s.end()){
			}
			else{
				if ((it1==s.end() && it2!=s.end() && PI-d[i]-EPS<=(*it2) && (*it2)<=d[i]+EPS)  
					|| (it1!=s.end() && it2==s.end() && PI-d[i]-EPS<=(*it1) && (*it1)<=d[i]+EPS) 
					|| (it1!=s.end() && it2!=s.end() && PI-d[i]-EPS<=(*it1) && (*it2)<=d[i]+EPS &&(*it1)<=(*it2)+EPS)){
					b[i]=0;
				}
			}
		}
		s.insert(d[i]);
	}
	s.clear();
	for (int i=n-1;i>=0;i--){
		if (d[i]<PI/2){
			set <double>::iterator it1 = s.lower_bound(PI-d[i]-EPS);
			set <double>::iterator it2 = s.lower_bound(d[i]+EPS);
			if (it1==s.end() && it2==s.end()){
			}
			else{
				if ((it1==s.end() && it2!=s.end() && PI-d[i]+EPS>=(*it2) && (*it2)>=d[i]-EPS)  
					|| (it1!=s.end() && it2==s.end() && PI-d[i]+EPS>=(*it1) && (*it1)>=d[i]-EPS) 
					|| (it1!=s.end() && it2!=s.end() && PI-d[i]+EPS>=(*it1) && (*it2)>=d[i]-EPS && (*it1)+EPS>=(*it2))){
					b[i]=0;
				}
			}
		}
		s.insert(d[i]);
	}
	int ans=0;
	
	for (int i=0;i<n;i++){
		if (b[i]) ans++;
	}
	cout<<ans<<endl;
	for (int i=0;i<n;i++){
		if (b[i]) cout<<i+1<<' ';
	}
	return 0;

}