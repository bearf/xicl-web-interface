#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <string>
#include <string.h>
#include <math.h>
#include <memory.h>
using namespace std;

#define li int
#define pb push_back
#define mp make_pair
#define all(a) a.begin(),a.end()

li n,m,k;
map < pair<li,li>, pair<bool,bool> > a;
map < pair<li,li>,bool> b;
li abc(li x)
{
	if(x>0)
		return x;
	return -x;
}
int main()
{
	//freopen("input.txt", "r", stdin);
	freopen("bricks.in", "r", stdin);
	freopen("bricks.out", "w", stdout);
	li i,j;
	pair <li,li> t;
	pair <bool,bool> p;
	p=mp(1,1);
	cin>>n>>k;
	for(i=0;i<k;i++)
	{
		li x,y;
		cin>>x>>y;
		b[mp(x,y)]=true;
		if(y!=x)
		{
			t=mp(x-1,y);
			if(a.find(t)==a.end())
				a[t]=mp(1,0);
			else
			{
				a[t].first=1;
				if(!b[t] && a[t]==p)
				{
					cout<<i+1;
					return 0;
				}
			}
		}
		if(y!=1)
		{
			t=mp(x-1,y-1);
			if(a.find(t)==a.end())
				a[t]=mp(0,1);
			else
			{
				a[t].second=1;
				if(!b[t] && a[t]==p)
				{
					cout<<i+1;
					return 0;
				}
			}
		}
	}
	cout<<-1;
	return 0;
}