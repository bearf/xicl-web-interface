#include <iostream>
#include <stdio.h>
#include <map>
#include <string>
#include <vector>
#include <utility>

using namespace std;


int main(){
	freopen("bricks.in", "r", stdin);
	freopen("bricks.out", "w", stdout);

	long n;
	cin >> n;

	int k;
	cin >> k;

	map< pair<long, long>, long > m;

	for (int l = 1; l<=k; l++){
		long j,i;
		cin >> j >> i;

		m[ make_pair(j,i) ] = -2;

		m[ make_pair(j-1, i-1) ]+=1;
		m[ make_pair(j-1, i) ]+=1;

		if (m[ make_pair(j-1, i-1) ]>=2 || m[ make_pair(j-1, i) ]>=2) {
			cout << l;
			return 0;
		}
	}

	cout << "-1";

	return 0;
}