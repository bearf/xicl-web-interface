#include <cstdlib>
#include <cstdio>
#include <map>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int) n; ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; i--)
#define fs first;
#define sc second
#define mp make_pair
#define all(x) x.begin(), x.end()
#define pb push_back

typedef long long int64;
typedef pair <int, int> pii;

const int nmax = 100100;

int px[] = {-1, 0, 1, 0};
int py[] = {0, 1, 0, -1};

int n, m, sx, sy, fx, fy;
int a[nmax];
int used[nmax][2];

void dfs(int x, int y, int tp){
//	cerr << x << " " << y << " " << tp << endl;
	used[x * m + y][tp] = 1;
//	if (tp == 1 && a[x * m + y] <= 1)
//		return;
	forn(i, 4){
		int nx = x + px[i];
		int ny = y + py[i];
		if (nx < 0 || ny < 0 || nx >= n || ny >= m)
			continue;

		int ntp = 1;
		if (tp == 0 && a[x * m + y] > 0)
			ntp = 0;
		if (a[x * m + y] > 1)
			ntp = 0;
		if (ntp == 1 && a[nx * m + ny] == 0)
			continue;
		if (used[nx * m + ny][ntp])
			continue;
		dfs(nx, ny, ntp);
	}
}

int main()
{
	freopen("islands.in", "r", stdin);
	freopen("islands.out", "w", stdout);

	cin >> n >> m;
	forn(i, n)
		forn(j, m){
			char ch;
			scanf(" %c", &ch);
			a[i * m + j] = ch - '0';
		}
	cin >> sx >> sy >> fx >> fy;
	sx --; sy --;
	fx --; fy --;
	dfs(sx, sy, 0);
	if (used[fx * m + fy][0] || used[fx * m + fy][1])
		puts("YES");
	else
		puts("NO");
	
	return 0;
}
