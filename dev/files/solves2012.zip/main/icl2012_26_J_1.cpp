#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <cstdio>

using namespace std;
const int N=410000, inf = 1e9;

int n, m, ist, jst, ien, jen, stp, enp;
int st1, en1, st2, en2, d[N], with[N];
string s, cur;
int q1[N], q2[N];
int di[] = {1, 0, -1, 0},
	dj[] = {0, 1, 0, -1};
int main() {
	freopen("islands.in", "r", stdin);
	freopen("islands.out", "w", stdout);
	cin >> n >> m;
	for (int i = 0; i < n; i++) {
		cin >> cur;
		s += cur;
	}
	for (int i = 0; i < n * m; i++) d[i] = with[i] = inf;
	cin >> ist >> jst;
	cin >> ien >> jen;
	ist--;
	jst--;
	ien--;
	jen--;
	stp = m * ist + jst;
	d[stp] = 0;
	enp = m * ien + jen;
	q1[en1++] = stp;
	while (st1 != en1 || st2 != en2) {
		int add = 0;
		int x = 0;
		int curdist = 0;
		if (st1 != en1) {
			x = q1[st1++];
			curdist = d[x];
		}
		else {
			x = q2[st2++];
			curdist = with[x];
			add = 1;
		}
		int i = x / m;
		int j = x % m;
		for (int oper = 0; oper < 4; oper++) {
			int ni = i + di[oper];
			int nj = j + dj[oper];
			int np = ni * m + nj;
			if (ni >= 0 && ni < n && nj >= 0 && nj < m && np < n * m) {
				if (s[x] >= '1' + add && d[np] == inf) {
					q1[en1++] = np;
					d[np] = curdist + 1;
				}else if (s[np] >= '1' && with[np] == inf) {
					q2[en2++] = np;
					with[np] = curdist + 1;
				}
			}
		}
	}
	/*for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			if (d[i*m + j] != inf) cout << d[i * m + j] << "/";	
			else cout << -1 << " ";	
			if (with[i*m + j] != inf) cout << with[i * m + j] << " ";	
			else cout << -1 << " ";	
		}
		cout << endl;
	}*/
	if (d[enp] != inf || with[enp] != inf) cout << "YES";
	else cout << "NO";
}