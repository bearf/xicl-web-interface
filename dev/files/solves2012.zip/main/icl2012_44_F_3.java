import java.util.*;
import java.lang.*;
import java.io.*;
import java.math.*;

public class Solution{

    int MOD = 1000000007;
    int p;

    boolean check(BigInteger n){
		int[] a = new int[100000];
    	int ptr = 0;

    	while (!n.equals(BigInteger.ZERO)){
    		a[ptr++] = n.mod(BigInteger.valueOf(p)).intValue();
    		n = n.divide(BigInteger.valueOf(p));
    	}

    	boolean q = true;

   		for (int i = 0; i < ptr && q; i++){
   			if (a[i] != 0 && a[i] != p-1 && a[i] != p-2)
   				q = false;
   			if (a[i] == p-2 && (i == 0 || a[i-1] == 0))
   				q = false;    				
   		}

   		return q;
    }

    long pow(long a,long b,long mod){
    	if (b == 0)
    		return 1;
    	if (b % 2 == 1)
    		return (a*pow((a*a)%mod,b/2,mod))%mod;
    	return pow((a*a)%mod,b/2,mod);
    }


    void solve(){
    	p = in.nextInt();
    	BigInteger n = new BigInteger((new StringTokenizer(in.nextLine())).nextToken());
    	BigInteger n1 = n;
    	BigInteger n2 = n.divide(BigInteger.valueOf(2));
    	int[] a = new int[100000];
    	int ptr = 0;

    	while (!n.equals(BigInteger.ZERO)){
    		a[ptr++] = n.mod(BigInteger.valueOf(p)).intValue();
    		n = n.divide(BigInteger.valueOf(p));
    	}

    	int[][][][] dp = new int[ptr+1][3][3][2];


    	dp[0][0][0][0] = 1;

    	int[] val = new int[3];
    	val[0] = 0;
    	val[1] = p-1;
    	val[2] = p-2;


    	for (int i = 0; i < ptr; i++)
    		for (int j = 0; j < 3; j++)
    			for (int k = 0; k < 3; k++)
    				for (int l = 0; l < 2; l++){
    					int temp = dp[i][j][k][l];
    					if (temp == 0)
    						continue;
//		    			System.err.println(i+" "+j+" "+k+" "+l+" "+dp[i][j][k][l]);    						
    					for (int u = 0; u < 3; u++)
    						for (int v = 0; v < 3; v++){
    							if (j == 0 && u == 2)
    								continue;
    							if (k == 0 && v == 2)
    								continue;
    							if ((val[u] + val[v] + l) % p != a[i])
    								continue;
    							dp[i+1][u][v][(val[u] + val[v] + l)/p] += dp[i][j][k][l];
    							dp[i+1][u][v][(val[u] + val[v] + l)/p] %= MOD;
    						}
    				}

    	int res = 0;
    	for (int i = 0; i < 3; i++)
    		for (int j = 0; j < 3; j++){
//    			if (dp[ptr][i][j][0] != 0)
//	    			System.err.println(ptr+" "+i+" "+j+" 0 "+dp[ptr][i][j][0]);
    			res += dp[ptr][i][j][0];
    		}

    	res = (int)((res * (long)(pow(2,MOD-2,MOD)))%(long)MOD);


    	if (n2.multiply(BigInteger.valueOf(2)).equals(n))
    		if (check(n2))
    			res--;
    	if (check(n1))
    		res--;

    	for (int i = 0; i < ptr; i++){
    		boolean q = true;
    		
    		a[i]--;
    		for (int j = i; a[j] < 0; j++){
    			a[j] += p;
    			a[j+1]--;
    		}

    		for (int j = 0; j < ptr && q; j++){
    			if (a[j] != 0 && a[j] != p-1 && a[j] != p-2)
    				q = false;
    			if (a[j] == p-2 && (j == 0 || a[j-1] == 0))
    				q = false;    				
    		}

    		a[i]++;
    		for (int j = i; a[j] >= p; j++){
    			a[j] -= p;
    			a[j+1]++;
    		}    		

    		if (q)
    			res++;
    	}

    	res = (res + MOD)%MOD;
		out.println(res);
    	return;
    }


    public static void main(String[] args) throws IOException{
    	new Solution().run();
    }

    Scanner in;
    PrintWriter out;

    void run(){
    	try{
    		in = new Scanner(new File("oranges.in"));
    		out = new PrintWriter(new File("oranges.out"));
    		solve();
    		in.close();
    		out.close();
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
    }
}