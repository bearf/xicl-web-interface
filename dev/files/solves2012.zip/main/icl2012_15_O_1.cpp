#include <iostream>
#include <sstream>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <vector>
#include <string>
#include <ctime>
using namespace std;

typedef long long ll;

int n, m, k;
vector<int> xs, ys, z, t;

int main()
{
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	freopen("darts.in", "r", stdin); freopen("darts.out", "w", stdout);
		
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 0; i < k; i++)
	{
		int x, y;
		scanf("%d%d", &x, &y);
		xs.push_back(x);
		ys.push_back(y);
	}

	xs.push_back(0);
	xs.push_back(n);
	ys.push_back(0);
	ys.push_back(m);
	sort(xs.begin(), xs.end());
	xs.resize(unique(xs.begin(), xs.end()) - xs.begin());
	sort(ys.begin(), ys.end());
	ys.resize(unique(ys.begin(), ys.end()) - ys.begin());

	for (int i = 0; i < xs.size(); i++)
		for (int j = 0; j < i; j++)
			z.push_back(xs[i] - xs[j]);
	for (int i = 0; i < ys.size(); i++)
		for (int j = 0; j < i; j++)
			t.push_back(ys[i] - ys[j]);
	sort(z.begin(), z.end());
	sort(t.begin(), t.end());

	ll ans = 0, prev = 0;
	int ptr = 0;
	for (int i = 0; i < z.size(); i++)
	{
		if (i && z[i] == z[i - 1])
		{
			ans += prev;
			continue;
		}
		else
			prev = 0;
		while (ptr < t.size() && t[ptr] < z[i])
			ptr++;
		while (ptr < t.size() && t[ptr] == z[i])
		{
			prev++;
			ans++;
			ptr++;
		}
	}

	cout << ans;

	return 0;
}
