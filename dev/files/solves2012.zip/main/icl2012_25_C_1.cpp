#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <stack>
#include <string>
#include <sstream>
#include <cstring>
#include <cmath>
#include <ctime>
#include <numeric>

using namespace std;

#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define re return
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int) (x).size())
#define sqr(x) ((x) * (x))
#define sqrt(x) sqrt(abs(x))
#define rep(i, n) for (int i= 0; i < (n); i++)
#define rrep(i, n) for (int i = (n) - 1; i >= 0; i--)
#define re return
#define y0 y2369
#define y1 y347256
#define fill(x, y) memset(x, y, sizeof(x))

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef vector<string> vs;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef double D;
typedef long double LD;

template <class T> T abs(T x) { re x > 0 ? x : -x;}

#define FILENAME "ice"

int n;
int m;

ii ev[10000000 + 80000 + 123];

double t[10000123];

set <ii> S;

ii e1[80123];

int x[40000], y[40000], r[40000];


int main() {
	freopen(FILENAME".in", "r", stdin);
	freopen(FILENAME".out", "w", stdout);

	cin >> n >> m;
	rep(i, n)
		t[i] = 1e20;
	rep(i, m) {
		cin >> x[i] >> y[i] >> r[i];
		e1[2 * i] = mp(x[i] - r[i], -(i + 1));
		e1[2 * i + 1] = mp(x[i] + r[i], (i + 1));
	}
	sort(e1, e1 + 2 * m);
	rep(i, 2 * m)
		e1[i].se *= -1;
	int k = 0;
	int cur1 = 0, cur2 = 0;
	while (cur1 < 2 * m || cur2 < n + 1) {
		if (cur2 == n + 1 || (cur1 < 2 * m && e1[cur1].fi < cur2)) {
			ev[k++] = e1[cur1++];
			continue;
		}
		if (cur1 == 2 * m || (cur2 < n + 1 && cur2 < e1[cur1].fi)) {
			ev[k++] = mp(cur2++, 0);
			continue;
		}
		if (e1[cur1].fi == cur2) {
			if (e1[cur1].se > 0) {
				ev[k++] = e1[cur1++];
			} else {
				ev[k++] = mp(cur2++, 0);
			}
			continue;
		}
	}
//	rep(i, k)
//		cerr << ev[i].fi << ' ' << ev[i].se << endl;
//		re 0;
	double tmin = 1e20;
	rep(i, k) {
		if (ev[i].se > 0) {
			S.insert(mp(y[ev[i].se - 1], ev[i].se - 1));
		}
		if (ev[i].se < 0) {
			S.erase(mp(y[-(ev[i].se) - 1], -(ev[i].se) - 1));
		}
		if (ev[i].se == 0 && sz(S)) {
//			cerr << ev[i].fi << endl;
			int num = S.rbegin()->se;
			int x = ::x[num];
			int y = ::y[num];
			int r = ::r[num];
			int x0 = ev[i].fi;
			double t = -y - sqrt(sqr((D)r) - sqr((D)x - (D)x0));
			::t[x0] = min(::t[x0], t);
			if (x0)
				::t[x0 - 1] = min(::t[x0 - 1], t);
			tmin = min(tmin, t);
		}
	}
	//rep(i, n)
	//	cerr << t[i] - tmin << endl;
	double sum = 0;
	int cnt = 0;
	rep(i, n) {
		if (t[i] < 1e19) {
			sum += t[i] - tmin;
			cnt++;
		}
	}
	printf("%.10lf\n", sum / cnt);
	return 0;
}
