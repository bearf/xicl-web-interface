import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.Locale;
import java.util.Scanner;

public class Solution {
	int p;
	BigInteger _p;

	public void run(Scanner input, PrintWriter output) {
		p = input.nextInt();
		_p = BigInteger.valueOf(p);
		BigInteger n = input.nextBigInteger();
		output.println(count(n));
	}

	public boolean check(BigInteger n) {
		if (n.equals(BigInteger.ONE)) {
			return true;
		}
		int modu = n.mod(_p).intValue();
		if (modu == 0) {
			return check(n.divide(_p));
		}
		if (modu + 1 == p) {
			return check(n.add(BigInteger.ONE).divide(_p));
		}
		return false;

	}

	public int count(BigInteger n) {
		if (n.equals(BigInteger.ONE)) {
			return 0;
		}
		
		int plus = 0;
		if (check(n.subtract(BigInteger.ONE))) {
			plus = 1;
		}

		int modu = n.mod(_p).intValue();
		//System.out.println(n+" "+modu+" "+plus);
		if (modu == 0) {
			return plus + count(n.divide(_p));
		}
		if (modu + 1 == p) {
			return plus + count(n.add(BigInteger.ONE).divide(_p));
		}
		if (modu + 2 == p) {
			return plus + count(n.add(BigInteger.valueOf(2)).divide(_p));
		}

		return plus;
	}

	public static void main(String[] args) throws FileNotFoundException {
		// Scanner input = new Scanner(System.in);
		// PrintWriter output = new PrintWriter(System.out);
		Scanner input = new Scanner(new File("oranges.in"));
		PrintWriter output = new PrintWriter(new File("oranges.out"));

		new Solution().run(input, output);

		input.close();
		output.close();
	}
}
