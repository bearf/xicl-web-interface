#pragma comment(linker,"/STACK:256000000")
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <math.h>
#include <string>
#include <queue>
using namespace std;
int main(){
	//freopen("1.txt","r",stdin);
	freopen("islands.in","r",stdin);
	freopen("islands.out","w",stdout);

	int n,m;
	cin>>n>>m;
	vector<string> s(n);
	vector<vector<int> > d(n,vector<int> (m));
	vector<vector<int> > dt(n,vector<int> (m));
	for(int i=0;i<n;i++)
		cin>>s[i];
	pair<int,int> a,b;
	cin>>a.first>>a.second>>b.first>>b.second;
	a.first--;
	b.first--;
	a.second--;
	b.second--;
	queue<pair<pair<int,int> , int > > q;
	q.push(make_pair(a,1));
	int w[]={0,0,1,-1},e[]={1,-1,0,0};
	while(!q.empty()){
		int x=q.front().first.first;
		int y=q.front().first.second;
		int t=q.front().second;
		//cout<<x<<" "<<y<<endl;
		if(b.first==x && b.second==y){
			cout<<"YES\n";
			return 0;
		}
		q.pop();
		if((t && s[x][y]!='0') || (t==0 && s[x][y]!='0' && s[x][y]!='1')){
			for(int k=0;k<4;k++)
				if(x+w[k]>=0 && x+w[k]<n && y+e[k]>=0 && y+e[k]<m)
					if(dt[x+w[k]][y+e[k]]==0){
						dt[x+w[k]][y+e[k]]=1;
						q.push(make_pair(make_pair(x+w[k],y+e[k]),1));
					}
		}
		else{
			for(int k=0;k<4;k++)
				if(x+w[k]>=0 && x+w[k]<n && y+e[k]>=0 && y+e[k]<m)
					if(s[x+w[k]][y+e[k]]!='0' && d[x+w[k]][y+e[k]]==0){
						d[x+w[k]][y+e[k]]=1;
						q.push(make_pair(make_pair(x+w[k],y+e[k]),0));
					}
		}
	}
	cout<<"NO\n";
	
	
}
				



	





