#include <cstdio>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <iostream>
#include <cmath>

using namespace std;

const int INF = (int) 1e9;
const double EPS = 1e-8;
const double PI = acos(-1.);

typedef pair<int, int> pii;
typedef long long ll;

#define NAME "race"

bool win[100100];
int alf[100100];
int main()
{
	freopen (NAME".in", "r", stdin);
	freopen (NAME".out", "w", stdout);
	int N;
	memset(win, true, sizeof(win));
	scanf ("%d", &N);
	for (int i = 0; i < N; ++i)
	{
		double t;
		scanf ("%lf", &t);
		alf[i] = t*1e7 + 0.5;
	}
	int l = PI*1e7;
	int r = 0;
	int d = (PI/2) * 1e7;
	for (int i = 0; i < N; ++i)
	{
		int a = labs(alf[i] - d);
		int x = labs(l - d);
		int y = labs(r - d);
		if (alf[i] >= d)
		{
			if (a > x || a > y)
			{
				win[i] = false;
			}
			if (a < x)
			{
				l = alf[i];
			}			
		}
		else
		{
			if (a < y)
			{
				r = alf[i];
			}
		}
	}
	l = PI*1e7;
	r = 0;
	for (int i = N-1; i >= 0; --i)
	{
		int a = labs(alf[i] - d);
		int x = labs(l - d);
		int y = labs(r - d);
		if (alf[i] <= d)
		{
			if (a > x || a > y)
			{
				win[i] = false;
			}
			if (a < y)
			{
				r = alf[i];
			}			
		}
		else
		{
			if (a < x)
			{
				l = alf[i];
			}
		}
	}
	int cnt = 0;
	for (int i = 0; i < N; ++i)
	{
		if (win[i])
			++cnt;
	}
	printf("%d\n", cnt);
	for (int i = 0; i < N; ++i)
	{
		if (win[i])
			printf("%d ", i + 1);
	}
	return 0;
}