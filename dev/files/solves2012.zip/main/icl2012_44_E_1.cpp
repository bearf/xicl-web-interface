#include <cstdio>
#include <cstring>
#include <cmath>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <iostream>
#include <fstream>
#include <set>

#define mp make_pair
#define pb push_back
#define zero(a) memset(a, 0, sizeof(a))
#define SZ(a) ((int)(a.size()))
#define sqr(a) ((a)*(a))
                
typedef long long ll;
typedef long double ld;

#define taskname "changes"

using namespace std;

int A[11000], B[11000], bal, n, res;
int C[11000];
int Res[11000];

int main (void)
{
  int i, j, tmp, tmp2;
  freopen (taskname".in", "rt", stdin);
  freopen (taskname".out", "wt", stdout);
  scanf("%d", &n);
  for (i=0; i<n; i++)
    scanf("%d", &A[i]), bal+=A[i], C[A[i]]++;
  for (i=0; i<n; i++)
    scanf("%d", &B[i]), bal-=B[i], res=max(res,A[i]-B[i]);
  if (bal!=0)
  {
    puts("-1");
    return 0;
  }
  for (i=0; i<=min(res,n); bal+=C[i], i++)
    if (bal>i)
    {
      puts("-1");
      return 0;
    }
  //cerr<<res<<endl;
  for (i=0; i<n; i++)
  {
    //cerr<<B[i]<<" "<<A[i]<<" "<<res<<endl;
    if ((B[i]-A[i]+res)%(n)!=0)
    {
      puts("-1");
      return 0;
    }
    tmp=(B[i]-A[i]+res)/(n);
    for (j=0; j<tmp; j++)
    {
      tmp2=min(A[i]+n*j,res-1);
      while (Res[tmp2]!=0)
      {
        tmp2--;
        if (tmp2<0)
        {
          puts("-1");
          return 0;
        }
      }
      Res[tmp2]=i+1;
    }
  }
  printf("%d\n", res);
  for (i=0; i<res; i++)
    printf("%d ", Res[i]);
  printf("\n");
  return 0;
}


