#include <algorithm>
#include <iostream>
#include <vector>
#include <set>
using namespace std;
typedef pair <int, int> pii;
int n, k;
struct tt{
	pair <int, int> a;
	tt(int x, int y){ a = pii(x, y);}
	bool operator<(const tt &b)const{
		return (a.first==b.a.first)?(a.second<b.a.second):(a.first<b.a.first);
	}
};
set < tt > a, b;

void bad(int v){
	cout << v + 1;
	exit(0);
}
int main(){
	freopen("bricks.in", "r", stdin); freopen("bricks.out", "w", stdout);
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	cin >> n >> k;
	for (int i = 0; i < k; i++){
		int x, y;
		cin >> x >> y;
		x = (n - x + 1);
		b.insert(tt(x, y));
		if (y < n - x + 1 && b.find(tt(x + 1, y)) == b.end())
			if (a.find(tt(x + 1, y)) == a.end()) a.insert(tt(x + 1, y));
			else bad(i);
		if (y > 1 && b.find(tt(x + 1, y - 1)) == b.end())
			if (a.find(tt(x + 1, y - 1)) == a.end()) a.insert(tt(x + 1, y - 1));
			else bad(i);
		set <tt> :: iterator it = a.find(tt (x, y));
		if (it != a.end()) a.erase(it);
	}
	cout << -1;
	return 0;
}