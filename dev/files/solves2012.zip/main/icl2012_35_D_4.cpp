#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cassert>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <string>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define _(a, b) memset(a, b, sizeof(a))

typedef long long lint;
typedef unsigned long long ull;

const int INF = 1000000000;
const lint LINF = 4000000000000000000ll;
const double eps = 1e-9;

void prepare(string file)
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#else
	freopen((file + ".in").c_str(), "r", stdin);
	freopen((file + ".out").c_str(), "w", stdout);
#endif
}

int n;
lint a, b;
pair <lint, lint> m[200000];
int pv = 0;
lint ans = 0;
vector <pair <lint,lint > > v;

void readdata ()
{
	scanf ("%d %lld %lld", &n, &a, &b);
	for (int i = 0; i < n; i++)
	{
		scanf ("%lld %lld", &m[i].first, &m[i].second);
	}
	sort (m, m + n);
	v.pb (mp (m[0].first, 1));
	pv = 0;
	ans = 0;
	for (int i = 1; i < n; i++)
	{
		if (m[i].first == v[pv].first)
		{
			v[pv].second ++;
		}
		else
		{	
			pv ++;
			v.push_back ( mp (m[i].first, 1));
		}
	}
}



void writedata ()
{
	cout << ans << endl;
}

bool solve()
{
	lint free_place = 0;
	lint ttime = 0;
	for (int i = 0; i < v.size(); i++)
	{
		if (ttime >= v[i].first)
		{
			if (free_place != 0)
			{
				lint mmin = min (free_place, v[i].second);
				v[i].second -= mmin;
				free_place -= mmin;
			}
		}
		free_place = 0;
		if (ttime >= v[i].first)
		{
			ttime += (v[i].second / b);
		}
		else
		{
			ttime += (v[i].second / b) + (v[i].first - ttime);
		}
		if (v[i].second % b != 0)
		{
			ttime ++;
			free_place = b - v[i].second % b;
		}
	}
	ans = ttime;
	return false;
}

int main()
{
	prepare("millenium");
	readdata ();
	while (solve());
	writedata ();
	return false;
}