#include <cstdio>
#include <cstring>
#include <cmath>
#include <iostream>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <string>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <iostream>
#include <fstream>

#define mp make_pair
#define pb push_back
#define zero(a) memset(a, 0, sizeof(a))
#define SZ(a) ((int)(a.size()))
#define sqr(a) ((a)*(a))
                
typedef long long ll;
typedef long double ld;

using namespace std;

#define taskname "bricks"

set<pair<int,int> > s;

int main (void)
{
  freopen (taskname".in", "rt", stdin);
  freopen (taskname".out", "wt", stdout);

  int n,k;
  scanf("%d %d",&n,&k);

  for (int i = 0; i < k; i++){
  	int x,y;
  	scanf("%d %d",&x,&y);
  	x = n - x+1;
  	s.insert(mp(x,y));
  	if (y != n - x + 1){
  		if (s.find(mp(x,y+1)) != s.end() && s.find(mp(x+1,y)) == s.end()){
  			printf("%d\n",i+1);
  			return 0;
  		}
  	}
  	if (y != 1){
  		if (s.find(mp(x,y-1)) != s.end() && s.find(mp(x+1,y-1)) == s.end()){
  			printf("%d\n",i+1);
  			return 0;
  		}
  	}
  }

  cout << -1 << endl;

  return 0;
}


