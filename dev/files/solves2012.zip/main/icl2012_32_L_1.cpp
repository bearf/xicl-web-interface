#include <cstdlib>
#include <cstdio>
#include <map>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int) n; ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; i--)
#define fs first;
#define sc second
#define mp make_pair
#define all(x) x.begin(), x.end()
#define pb push_back

typedef long long int64;
typedef pair <int, int> pii;

const int nmax = 100100;
const double pi = 2 * acos(0);

int n;
double a[nmax];
vector<int> now;

bool kill(int v, int u){
	return a[v] > pi - a[u];
}

int main()
{
	freopen("race.in", "r", stdin);
	freopen("race.out", "w", stdout);

	cin >> n;
	forn(i, n)
		scanf("%lf", &a[i]);
	ford(i, n){
		while (1){
			if (now.size() == 0 || a[i] >= a[now.back()]){
				now.pb(i);
				break;
			}

			if (kill(i, now.back()))
				now.pop_back();
			else
				break;
		}
	}
	sort(all(now));
	cout << now.size() << endl;
	forn(i, now.size()){
		printf("%d", now[i] + 1);
		if (i + 1 < now.size())
			printf(" ");
		else
			puts("");
	}
	return 0;
}
