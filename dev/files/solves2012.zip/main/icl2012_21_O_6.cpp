#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <map>
#include <set>

using namespace std;

typedef long long int LL;

int main() {
	freopen("darts.in", "r", stdin);
	freopen("darts.out", "w", stdout);

	int N, M, K;
	cin >> N >> M>> K;
	int MIN = min(N,M);
	
	int x, y;
	set<int>sx, sy;
	for(int i = 0; i < K; ++i)
	{
		scanf("%i%i",&x,&y);
		sx.insert(x);
		sy.insert(y);
	}
	sx.insert(0);
	sy.insert(0);
	sx.insert(N);
	sy.insert(M);
	map<int,int>mx,my;
	for(set<int>::iterator iti = sx.begin(); iti != sx.end(); ++iti)
	{
		for(set<int>::iterator itj = iti; itj != sx.end();)
		{
			itj++;
			if(itj == sx.end())
				break;
			int t = *itj - *iti;
			if(t > MIN)
				break;
			else
				mx[t]++;
		}
	}
	long long int cnt = 0;

	for(set<int>::iterator iti = sy.begin(); iti != sy.end(); ++iti)
	{
		for(set<int>::iterator itj = iti; itj != sy.end();)
		{
			itj++;
			if(itj == sy.end())
				break;
			int t = *itj - *iti;
			if(t > MIN)
				break;
			else
			{
				if(mx.count(t))
				{
					LL u = mx.find(t)->second;
					cnt += u;
				}
			}
		}
	}
	cout << cnt;


	return 0;
}