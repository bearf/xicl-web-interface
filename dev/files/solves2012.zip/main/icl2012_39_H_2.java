import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {

	void _solve() throws Exception {
		n = nextInt();
		k = nextInt();
		a = new int[k];
		for (int i = 0; i < k; i++) {
			a[i] = nextInt() - 1;
		}
		if (k == 1) {
			out.print(getCount(a[0], n));
			return;
		}
		Arrays.sort(a);
		d = new int[k - 1];
		for (int i = 0; i < k - 1; i++) {
			d[i] = a[i + 1] - a[i];
		}
		int g = 0;
		for (int i = 0; i < d.length; i++) {
			g = gcd(g, d[i]);
		}
		res = BigInteger.ZERO;
		for (int i = 1; i * i <= g; i++) {
			if (g % i == 0) {
				check(i);
				if (i * i != g) {
					check(g / i);
				}
			}
		}
		out.println(res);
	}

	BigInteger res;
	int[] a, d;
	int n, k;
	
	private void check(int len) {
		long left = a[0] / len;
		long right = (n - a[k - 1]) / len;
		while (a[k - 1] + right * len >= n)
			--right;
		
		++left;
		++right;
		long c = left * right;
		//System.out.println(len + " " + left + " " + right);
		res = res.add(BigInteger.valueOf(c));
	}
	
	private int gcd(int a, int b) {
		return b == 0 ? a : gcd(b, a % b);
	}
	
	BigInteger getCount(int x, int n) {
		int toLeft = x;
		int toRight = n - toLeft - 1;
		BigInteger ans = BigInteger.ONE;
		int curDiv = 1;
		while (toLeft / curDiv > 0 || toRight / curDiv > 0) {
			int nextDiv;
			if (toLeft / curDiv == 0) {
				nextDiv = getNext(toRight, curDiv);
			} else if (toRight / curDiv == 0) {
				nextDiv = getNext(toLeft, curDiv);
			} else {
				nextDiv = Math.min(getNext(toLeft, curDiv), getNext(toRight, curDiv));
			}
			ans = ans.add(BigInteger.valueOf((long) (nextDiv - curDiv) * ((long) (toLeft / curDiv + 1) * (toRight / curDiv + 1) - 1)));
			curDiv = nextDiv;
		}
		return ans;
	}
	
	private int getNext(int cnt, int div) {
		int cur = cnt / div;
		if (cur == 1) {
			return cnt + 1;
		}
		long lo = div, hi = cnt + 1;
		while (hi - lo > 1) {
			long mid = (lo + hi) / 2;
			if (cnt / mid < cur) {
				hi = mid;
			} else {
				lo = mid;
			}
		}
		return (int) hi;
	}

	BufferedReader in;
	StringTokenizer stringTokenizer;
	PrintWriter out;
	
	long nextLong() {
		return Long.parseLong(nextToken());
	}
	
	double nextDouble() {
		return Double.parseDouble(nextToken());
	}
	
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	
	String nextToken() {
		while (!stringTokenizer.hasMoreTokens()) {
			String line = null;
			try {
				line = in.readLine();
			} catch (IOException e) {
				NOO(e);
			}
			if (line == null) {
				return null;
			} else {
				stringTokenizer = new StringTokenizer(line);
			}
		}
		return stringTokenizer.nextToken();
	}
	
	public void run() {
		try {
			_solve();
		} catch (Exception e) {
			NOO(e);
		} finally {
			out.close();
		}
	}
	
	void NOO(Exception e) {
		e.printStackTrace();
		System.exit(42);
	}
	
	public Solution(String name) {
		try {
			in = new BufferedReader(new FileReader(name + ".in"));
			stringTokenizer = new StringTokenizer("");
			out = new PrintWriter(new FileWriter(name + ".out"));
		} catch (Exception e) {
			NOO(e);
		}
	}
	
	public static void main(String[] args) {
		new Solution("trees").run();
	}

}
