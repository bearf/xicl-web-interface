#include <iostream>
#include <sstream>
#include <stdio.h>
#include <cassert>
#include <memory.h>
#include <math.h>
#include <time.h>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <bitset>

using namespace std;

#define mp make_pair
#define pb push_back
#define all(a) (a).begin(),(a).end()
#define _(a,b) memset((a),b,sizeof(a))
#define sz(a) ((int)(a).size())

typedef long long lint;
typedef unsigned long long ull;
typedef pair < int , int > pii;

const int INF = 1000000000;
const lint LINF = 4000000000000000000LL;
const double eps = 1e-9;

void prepare(string s)
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
#else
	freopen((s + ".in").c_str(),"r",stdin);
	freopen((s + ".out").c_str(),"w",stdout);
#endif
}

const int maxn = 200100;

int n;
int k;
int a[maxn];

int gcd(int a, int b)
{
	return b ? gcd(b, a % b) : a;
}

lint calc(lint d)
{
	lint l = a[0];
	lint r = n - a[k - 1] - 1;
	return (l / d + 1) * (r / d + 1);
}

void vvv()
{
	map<int, int> se;
	for (int i = 1; i <= n; i++)
	{
		se[n / i]++;
	}
	printf("%d\n", sz(se));

	map<int, int> se2;
	for (lint d = 1; d <= n;)
	{
		int ndiv = n / d;
		int nmod = n % d;
		se2[ndiv] += nmod / ndiv + 1;
		d += se2[ndiv];
	}
	for (map<int, int>::iterator it = se.begin(); it != se.end(); ++it)
	{
		if (it->second != se2[it->first])
			printf("A");
	}
	printf("%d\n", sz(se2));
}

int tt[1000];
int stup()
{
	int res = 0;
	bool ok ;
	for (int len = 1; len <= n; len++)
	{
		for (int pos = 0; pos < n; pos++)
		{
			ok = true;
			for (int j = 0; j < k; j++)
			{
				if (a[j] < pos || (a[j] - pos) % len != 0)
				{
					ok = false;
					break;
				}
			}
			if (!ok)
				continue;
			_(tt, 0);
			for (int cnt = 1; cnt <= n; cnt++)
			{
				if (a[k - 1] > pos + cnt * len)
					continue;
				if (pos + cnt * len < n)
				{
					tt[pos + cnt * len] = true;
					res++;
				}
				else
					break;
			}
		}
	}
	return res + 1;
}

void gen( )
{
	n = rand() % 10 + 1;
	k = rand() % 1 + 1;
	vector<int> v;
	for (int i = 0; i < k; i++)
		v.pb(rand() % n);
	sort(all(v));
	v.resize(unique(all(v)) - v.begin());
	k = sz(v);
	for (int i = 0; i < k; i++)
		a[i] = v[i];
}

bool solve()
{
	scanf("%d%d", &n, &k);
	for (int i = 0; i < k; i++)
	{
		scanf("%d", &a[i]);
		a[i]--;
	}
	lint res = 0;
	if (k > 1)
	{
		int g = a[1] - a[0];
		for (int i = 1; i < k; i++)
		{
			assert(a[i] > a[i - 1]);
			g = gcd(g, a[i] - a[i - 1]);
		}
		for (lint i = 1; i * i <= g; i++)
		{
			if (g % i == 0)
			{
				res += calc(i);
				if (i * i != g)
					res += calc(g / i);
			}
		}
	}
	else
	{
		lint l = a[0];
		lint r = n - a[k - 1] - 1;
		lint mx = max(l, r);
		for (lint d = 1; d <= mx; )
		{
			lint ldiv = l / d;
			lint lmod = l % d;
			lint rdiv = r / d;
			lint rmod = r % d;
			lint dl = mx + 10;
			if (ldiv)
				dl = lmod / ldiv + 1;
			lint dr = mx + 10;
			if (rdiv)
				dr = rmod / rdiv + 1;
			if (ldiv || rdiv)
			{
				res += min(dl, dr) * (l / d) * (r / d);
				res += ldiv * min(dl, dr);
				res += rdiv * min(dl, dr);
			}
			d += min(dl, dr);
		}
		res++;
	}
	cout << res << endl;
	return false;
}

int main()
{
	prepare("trees");
	while (solve());
	return 0;
}