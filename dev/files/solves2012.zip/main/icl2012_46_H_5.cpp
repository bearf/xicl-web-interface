#include <iostream>
#include <algorithm>
#include <cstdio>
#include <set>
#include <map>

using namespace std;

long long gcd(long long a, long long b) {
	while (b)
		swap(a%=b, b);
	return a;
}

map<long long, long long> p;
long long d[1000000];
long long nd;

int main() {
	freopen("trees.in", "r", stdin);
	freopen("trees.out", "w", stdout);
	
	long long n, k;

	cin >> n >> k;

	long long g = 0;

	long long s = 0;
	cin >> s;
	long long t;
	
	for (long long i=1; i<k; i++) {
		cin >> t;
		g = gcd(g, t - s);
	}
	long long res=0;
	
	long long f = g;
	for (long long i=2; i<=f; i++) {
		while (f%i == 0) {
			f/=i;
			p[i]++;
		}
	}
	d[nd++]=1;
	for (map<long long, long long>::iterator it=p.begin(); it!=p.end(); ++it) {
		long long x = it->first;
		long long xn = it->second;
		for (long long z=x; xn>0; xn--, z*=x)
			for (long long i=nd-1; i>=0; i--)
				d[nd++] = d[i]*z;
	}

	if (g) {
		for (long long i=0; i<nd; i++)
				res+= ((s-1)/d[i]+1)*((n-t)/d[i]+1);
	} else {
		long long mx = max(s-1, n-s);
		for (long long i=1; i<=mx; i++)
			res += ((s-1)/i+1)*((n-s)/i+1);
		res -= (mx-1);
	}

	cout << res << endl;

	return 0;
}