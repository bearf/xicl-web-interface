#include<iostream>
#include<cmath>
#include<algorithm>
#include<set>
#include<map>
#include<vector>
#include<stack>
#include<queue>
#include<deque>
#include<list>
#include<string>
#include<cstring>
#include<cstdio>

using namespace std;

int main(){
	freopen("bricks.in","rt",stdin);
	freopen("bricks.out","wt",stdout);
	int n,k;
	set <pair<int,int> > m;
	cin>>n>>k;
	for (int i=0;i<k;i++){
		int x,y;
		cin>>x>>y;
		m.insert(make_pair(x,y));
		if (y>1 && m.find(make_pair(x,y-1))!=m.end() && m.find(make_pair(x-1,y-1))==m.end()){
			cout<<i+1;
			return 0;
		}
		if (y<x && m.find(make_pair(x,y+1))!=m.end() && m.find(make_pair(x-1,y))==m.end()){
			cout<<i+1;
			return 0;
		}
	}

	return 0;

}