#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#include <map>


#pragma comment(linker,"/STACK:146000000")


using namespace std;


vector<int> ans;
int k[10146], l[10146];
int add[10146];
set<pair<int, int> > q, s;


int main()
{
	freopen("changes.in","r",stdin);
	freopen("changes.out","w",stdout);
	int m;
	scanf("%d", &m);
	for(int i = 0; i < m; i++)
		scanf("%d", &k[i]);
	for(int i = 0; i < m; i++)
		scanf("%d", &l[i]);
	int pos = 0;
	for(int i = 0; i < m; i++)
	{
		if(k[i] - l[i] > k[pos] - l[pos])
			pos = i;
	}	
	int cnt = k[pos] - l[pos];
	int sum = 0;
	for(int i = 0; i < m; i++)
	{
		if((cnt + l[i] - k[i]) % m != 0)
		{
			printf("-1");
			return 0;
		}
		add[i] = (cnt + l[i] - k[i]) / m;
		sum += add[i];
	}
	if(sum != cnt)
	{
		printf("-1");
		return 0;
	}
	int n = m;                                      
	for(int i = 0; i < n; i++)
	{
		s.insert(make_pair(k[i], i));
		q.insert(make_pair(k[i], i));
	}
	cnt = 0;
	while(!q.empty())
	{
		int x = q.begin()->second;
		if(add[x] == 0)
		{
			
		q.erase(q.begin());
			continue;
		}
		if(s.begin()->first < cnt)
		{
			printf("-1");
			return 0;
		}
		ans.push_back(x);
		s.erase(make_pair(k[x], x));
		q.erase(make_pair(k[x], x));
		k[x] += m;
		s.insert(make_pair(k[x], x));
		q.insert(make_pair(k[x], x));
		add[x]--;
		cnt++;
	}
	printf("%d\n", cnt);
	for(int i = 0; i < ans.size(); i++)
		printf("%d ", ans[i] + 1);
}