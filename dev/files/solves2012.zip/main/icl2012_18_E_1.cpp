#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair <int, int> pii;

#define x first
#define y second
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define sz(a) (int)((a).size())
#define debug(...) fprintf(stderr, __VA_ARGS__)

#define problemname "changes"

#define maxn 10010

int m;
int k[maxn], l[maxn], a[maxn];

int I;

set <pii> s;



int main() {
    freopen(problemname".in", "r", stdin);
    freopen(problemname".out", "w", stdout);

    scanf("%d", &m);
    int s1 = 0, s2 = 0;
    for (int i = 0; i < m; i++) {
        scanf("%d", &k[i]);
        s1 += k[i];
    }
    for (int i = 0; i < m; i++) {
        scanf("%d", &l[i]);
        s2 += l[i];
    }

    if (s1 != s2) {
        puts("-1");
        return 0;
    }

    I = 0;
    int dd = ((l[0] - k[0]) % m + m) % m;
    for (int i = 0; i < m; i++) {
        if (((l[i] - k[i]) % m + m) % m != dd) {
            puts("-1");
            return 0;
        }
        I = max(I, k[i] - l[i]);
    }

    for (int i = 0; i < m; i++) {
        int delta = l[i] - k[i];
        a[i] = (delta + I) / m;
        assert((delta + I) % m == 0);

        if (a[i] > 0) {
            s.insert(pii(k[i], i));
        }
    }

    vector <int> ans;

//    printf("%d\n", I);
    for (int q = 0; q < I; q++) {
        pii minp = *(s.begin());
        s.erase(s.begin());

        int i = minp.y;

        //printf("%d%c", i + 1, " \n"[q + 1 == m]);
        ans.pb(i + 1);

        if (k[i] - q < 0) {
            puts("-1");
            return 0;
        }

        //add_all(-1);
        a[i]--;

        k[i] += m;
        if (a[i] > 0) {
            s.insert(pii(k[i], i));
        }
    }

    printf("%d\n", I);
    for (int i = 0; i < I; i++) {
        printf("%d%c", ans[i], " \n"[i + 1 == I]);
    }

    return 0;
}
