#include <iostream>
#include <sstream>
#include <stdio.h>
#include <cassert>
#include <memory.h>
#include <math.h>
#include <time.h>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <bitset>

using namespace std;

#define mp make_pair
#define pb push_back
#define all(a) (a).begin(),(a).end()
#define _(a,b) memset((a),b,sizeof(a))
#define sz(a) ((int)(a).size())

typedef long long lint;
typedef unsigned long long ull;
typedef pair < int , int > pii;

const int INF = 1000000000;
const lint LINF = 4000000000000000000LL;
const double eps = 1e-9;

void prepare(string s)
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
#else
	freopen((s + ".in").c_str(),"r",stdin);
	freopen((s + ".out").c_str(),"w",stdout);
#endif
}

int n,m;
vector < char > a[100005];
vector < bool > used[2][100005];
char tmp[100005];

bool in(int x,int y)
{
	return 0 <= x && x < n && 0 <= y && y < m;
}

int dx[4] = { -1, 1, 0, 0 };
int dy[4] = { 0, 0, -1, 1 };

void dfs(int x,int y,int f)
{
	used[f][x][y] = true;
	int left = a[x][y] - f;
	for (int i = 0; i < 4; i ++)
	{
		int nx = x + dx[i];
		int ny = y + dy[i];
		if (in(nx,ny))
		{
			if (left && !used[0][nx][ny])
			{
				dfs(nx,ny,0);
			}
			if (a[nx][ny] > 0 && !used[1][nx][ny])
			{
				dfs(nx,ny,1);
			}
		}
	}
}

bool solve()
{
	scanf("%d%d",&n,&m);
	for (int i = 0; i < n; i ++)
	{
		a[i].resize(m);
		used[0][i].resize(m);
		used[1][i].resize(m);
		scanf("%s",tmp);
		for (int j = 0; j < m; j ++)
			a[i][j] = tmp[j] - '0';
	}
	int x,y;
	scanf("%d%d",&x,&y);
	x--;
	y--;
	dfs(x,y,0);
	scanf("%d%d",&x,&y);
	x--;
	y--;
	if (used[0][x][y] || used[1][x][y])
		printf("YES\n");
	else
		printf("NO\n");
	return false;
}

int main()
{
	prepare("islands");
	while (solve());
	return 0;
}