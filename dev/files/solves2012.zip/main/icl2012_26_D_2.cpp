#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <cstdio>
#include <algorithm>

using namespace std;
const int N=410000, inf = 1e9;

int n, a, b, x[N], y[N];

int main() {
	freopen("millenium.in", "r", stdin);
	freopen("millenium.out", "w", stdout);
	cin >> n >> a >> b;
	for (int i = 0; i < n; i++) scanf("%d%d",&y[i], &x[i]);
	sort(y, y + n);
	int cur = 1;
	int cnt = b;
	for (int i = 0; i < n; i++) {
		if (y[i] > cur) {
			cur = y[i];
			cnt = b;
		}
		if (cnt > 0) cnt--;
		else {
			cur++;
			cnt = b - 1;
		}
	}
	cout << cur;
}