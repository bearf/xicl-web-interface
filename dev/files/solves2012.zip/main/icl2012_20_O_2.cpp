#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <string>
#include <string.h>

#define li unsigned long long
#define pb push_back
#define mp make_pair

#define INF (1000 * 1000 * 1000)
#define EPS (1e-9) 

using namespace std;

li n, m;
vector <li> v, a, b;

int main(){
	freopen("darts.in", "r", stdin);
	freopen("darts.out", "w", stdout);
	li k, aq, bq;
	cin >> n >> m >> k;
	for (int i = 0; i < k; i++) {
		cin >> aq >> bq;
		a.push_back(aq);
		b.push_back(bq);
	}
	a.push_back(n);
	a.push_back(0);
	b.push_back(m);
	b.push_back(0);
	sort(a.begin(), a.end());
	sort(b.begin(), b.end());
	a.resize(unique(a.begin(), a.end()) - a.begin());
	b.resize(unique(b.begin(), b.end()) - b.begin());
	for (size_t i = 0; i < a.size(); ++i)
		for (size_t j = 0; j < b.size(); ++j) {
			v.push_back(a[i] + b[j]);
			//cerr << v[v.size() - 1] << ' ';
		}
	sort(v.begin(), v.end());
	li prev = -INF;
	int cnt = 0;
	li res = 0;
	for (size_t i = 0; i < v.size(); ++i) {
		if (v[i] == prev)
			++cnt;
		else {
			prev = v[i];
			res += (cnt * (cnt - 1)) / 2;
			cnt = 1;
		}
	}
	cout << res << endl;
}