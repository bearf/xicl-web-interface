#include <stdio.h>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#include <math.h>

using namespace std;

#define mp make_pair
#define pb push_back

typedef long long li;
typedef double ld;

#define FILE "trees"
void solve();
int main()
{
#ifdef _DEBUG
	freopen ("in.txt", "r", stdin);
	cout<<FILE<<endl;
#else
	freopen (FILE ".in", "r", stdin);
	freopen (FILE ".out", "w", stdout);
#endif
	int t=1;
	while (t--)
		solve();
	return 0;
}

#define int li

int n, k;
int a[100500];

int gcd (int q, int w)
{
	if (q<w)
		swap(q, w);
	while (w)
	{
		q%=w;
		swap(q, w);
	}
	return q;
}

void solve()
{
	cin>>n>>k;
	for (int i=0; i<k; i++)
		cin>>a[i];
	if (k==1)
	{
		vector < pair <pair <int, int> , int> > events;
		int x, y;
		x=a[0]-1;
		y=n-a[0];
		double gg=sqrt( (double)max(x, y) );
		int s=(int)gg;
		//cout<<s<<endl;
		for (int i=0; i<=s; i++)
		{
			int cur1=x/(i+1)+1;
			events.pb( mp( mp(cur1, i), 1 ) );
			int cur2=y/(i+1)+1;
			events.pb( mp( mp(cur2, i), 2 ) );
		}
		int ans=1;
		for (int i=1; i<s; i++)
			ans+=(x/i+1)*(y/i+1)-1;
		//cout<<ans<<' '<<s<<endl;
		sort (events.begin(), events.end());
		int last=s;
		int cur1=x/s, cur2=y/s;
		for (int i=0; i<events.size(); i++)
		{
			pair < pair <int, int>, int > cur=events[i];
			if (cur.first.first<=s)
			{
				if (cur.second==2)
					cur2=min(cur2, cur.first.second);
				if (cur.second==1)
					cur1=min(cur1, cur.first.second);
				continue;
			}
			//cout<<cur1<<' '<<cur2<<endl;
			//cout<<cur.first.first<<' '<<cur.first.second<<' '<<cur.second<<endl;
			ans+=((cur1+1)*(cur2+1)-1)*(cur.first.first-last);
			if (cur.second==2)
				cur2=min(cur.first.second, cur2);
			if (cur.second==1)
				cur1=min(cur.first.second, cur1);
			last=cur.first.first;
		}
		cout<<ans;
		return;
	}
	int g=a[1]-a[0];
	for (int i=1; i<k-1; i++)
		g=gcd(g, a[i+1]-a[i]);
	int ans=0;
	for (int i=1; i*i<=g; i++)
		if (g%i==0)
		{
			int cur1=(a[0]-1)/i+1;
			int cur2=(n-a[k-1])/i+1;
			ans+=cur1*cur2;
			if (i*i!=g)
			{
				int h=g/i;
				int cur1=(a[0]-1)/h+1;
				int cur2=(n-a[k-1])/h+1;
				ans+=cur1*cur2;
			}
		}
	cout<<ans;
}