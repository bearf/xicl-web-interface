#include <iostream>
#include <set>

const int N = int(1e+5) + 2;
const int pi = 3.1415;

using namespace std;

bool used[N];
int size;

int main() {
	freopen("race.in", "r", stdin);
	freopen("race.out", "w", stdout);
	int n;
	cin >> n;
	double a[N];
	for (int i = 0; i < n; ++i)
		cin >> a[i];
	
	set<double> s;
	set<double>::iterator it;
	for (int i = 0; i < n; ++i) {
		s.insert(a[i]);
		if (a[i] > pi / 2.0) {
			s.insert(pi - a[i]);
			it = s.find(pi - a[i]);
			++it;
			used[i] = (*it) < a[i];
			--it;
			s.erase(it);
		} 
	}
	s.clear();
	for (int i = n - 1; i >= 0; --i) {
		s.insert(a[i]);
		if (a[i] < pi / 2.0) {
			s.insert(pi - a[i]);
			it = s.find(a[i]);
			++it;
			if (!used[i])
				used[i] = (*it) < (pi - a[i]);
			--it;
			s.erase(it);
		} 
	}

	for (int i = 0; i < n; ++i)
		size += !used[i];
	cout << size << endl;
	for (int i = 0; i < n; ++i)
		if (!used[i])
			cout << i + 1 << " ";
	return 0;
}