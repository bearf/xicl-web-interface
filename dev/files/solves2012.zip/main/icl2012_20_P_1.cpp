#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <string>
#include <string.h>

#define li unsigned long long
#define pb push_back
#define mp make_pair

#define INF (1000 * 1000 * 1000)
#define EPS (1e-9) 

using namespace std;

int x[1000], y[1000];

int main(){
	freopen("wire.in", "r", stdin);
	freopen("wire.out", "w", stdout);
	int n, i;
	cin >> n;
	for (i = 0; i < n; i++) cin >> x[i] >> y[i];
	int t;
	if (x[0] == x[1]) t = 0; else t  = 1;
	int r = 0;
	for (i = 2; i < n; i++)
		if (x[i] == x[i-1] && t == 1){
			t = 0;
			r++;
		} else 
			if (y[i] == y[i-1] && t == 0){
				t = 1;
				r++;
			}
	cout << r << endl;
}