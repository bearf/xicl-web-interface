#pragma comment(linker,"/STACK:256000000")
#include <iostream>
#include <vector>
#include <map>
using namespace std;
__int64 gcd(__int64 a,__int64 b){
	while(a){
		b%=a;
		swap(a,b);
	}
	return b;
}
int main(){
	//freopen("1.txt","r",stdin);
	freopen("trees.in","r",stdin);
	freopen("trees.out","w",stdout);
	__int64 n,k;
	cin>>n>>k;
	vector<__int64> a(k);
	for(int i=0;i<k;i++)
		cin>>a[i];
	if(k==1){
		__int64 ans=1;
		__int64 aa=n-a[0];
		__int64 b=a[0]-1;
		vector<pair<pair<__int64,__int64>, __int64> > A,B;
		for(int i=1;i<=aa;i++){
			__int64 j=aa/i;
			A.push_back(make_pair(make_pair(i,aa/j),j));
			i=aa/j;
		}
		//if(aa==0) A.push_back(make_pair(make_pair(1,n),0));
		//if(b==0) B.push_back(make_pair(make_pair(1,n),0));
		for(int i=1;i<=b;i++){
			__int64 j=b/i;
			B.push_back(make_pair(make_pair(i,b/j),j));
			i=b/j;
		}
		if(b+1<=n) B.push_back(make_pair( make_pair(b+1,n),0));
		if(aa+1<=n) A.push_back(make_pair( make_pair(aa+1,n),0));
		/*if(aa==0 && b==0){
			cout<<1<<endl;
			return 0;
		}
		if(aa==0){
			for(int i=0;i<B.size();i++)
				ans+=(B[i].first.second-B[i].first.first+1)*1ll*(B[i].second+1)-1;
			cout<<ans<<endl;
			return 0;
		}
		if(b==0){
			for(int i=0;i<A.size();i++)
				ans+=(A[i].first.second-A[i].first.first+1)*1ll*(A[i].second+1)-1;
			cout<<ans<<endl;
			return 0;
		}*/

		int i=0,j=0;
		while(i<A.size() && j<B.size()){
			__int64 l=max(A[i].first.first,B[j].first.first);
			__int64 r=min(A[i].first.second,B[j].first.second);
			__int64 d=r-l+1;
			if(d<0) d=0;
			ans+=d*((A[i].second+1)*1ll*(B[j].second+1)-1);
			if(A[i].first.second==r) i++;
			if(B[j].first.second==r) j++;
		}
	
		
		cout<<ans<<endl;

	}
	else
	{
		__int64 p=-1;
		__int64 ans=0;
		 p=a[1]-a[0];
		for(int i=2;i<k;i++)
			gcd(p,a[i]-a[i-1]);
		for(int i=1;i*i<=p;i++)
			if(p%i==0){
				__int64 l=(a[0]-1)/i+1;
				__int64 r=(n-a[k-1])/i+1;
				ans+=l*1ll*r;
			
				//ans++;
				//if(k==(a[k-1]-a[0]+1)/i+1) ans--;
				if(i*i!=p){
				/*	ans+=(a[0]-1)/(p/i);
					ans+=(n-a[k-1])/(p/i);
					ans++;*/
					__int64 l=(a[0]-1)/(p/i)+1;
				__int64 r=(n-a[k-1])/(p/i)+1;
				 ans+=l*1ll*r;
				//if(k==(a[k-1]-a[0]+1)/(p/i)+1) ans--;
				}
			}
		cout<<ans<<endl;
	}
	
}
				



	





