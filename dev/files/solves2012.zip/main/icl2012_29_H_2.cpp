#include <iostream>

using namespace std;


int a[100500];


int gcd(int a, int b)
{
	while(a > 0 && b > 0)
	{
		if(a > b) a %= b;
		else b %= a;
	}
	return a + b;
}


long long getRes(long long gMax, long long A, long long B)
{
	long long res = 0;
	for(int g = 1; g <= gMax; g++)
	{
		long long NA = A / g;
		long long la = (A + NA) / (NA + 1);
		long long ra = NA == 0 ? gMax : A / NA;
		long long NB = B / g;
		long long lb = (B + NB) / (NB + 1);
		long long rb = NB == 0 ? gMax : B / NB;
		long longs r = min(ra, rb);
		res += (r - g + 1) * ((NA + 1) * (NB + 1) - 1);//(A / g + 1) * (B / g + 1) - 1;
		g = r;
	}
	return res;
}


int main()
{
	freopen("trees.in", "r", stdin);
	freopen("trees.out", "w", stdout);
	int n, k;
	scanf("%d %d", &k, &n);
	for(int i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
		a[i]--;
	}
	int G = 0;
	for(int i = 1; i < n; i++)
	{
		G = gcd(G, a[i] - a[0]);
	}
	long long res = 0;
	if(n == 1)
	{
		res = 1;
		int gMax = max(a[0] + 1, k - a[n - 1]);
		long long A = a[0];
		long long B = k - 1 - a[n - 1];
		res = 1 + getRes(gMax, A, B);
		cout << res << endl;
		return 0;
	}
	for(int g = 1; g * g <= G; g++)
	{
		if(G % g == 0)
		{
			int g1 = G / g;
			res += (long long )(a[0] / g + 1) * (long long )( ( k - 1 - a[n  - 1]) / g + 1);
			if(g1 != g)
			{
				res += (long long )(a[0] / g1 + 1) * (long long )( ( k - 1 - a[n  - 1]) / g1 + 1);
			}
		}
	}
	cout << res << endl;
	return 0;
}