import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.TreeMap;

public class Solution {
	public void run(Scanner input, PrintWriter output) {
		int n = input.nextInt();
		int a = input.nextInt();
		int b = input.nextInt();
		TreeMap<Integer, Integer> c = new TreeMap<Integer, Integer>();
		for (int i = 0; i < n; i++) {
			int x = input.nextInt();
			long y = input.nextLong();

			Integer v = c.get(x);
			if (v == null) {
				c.put(x, 1);
			} else {
				c.put(x, v + 1);
			}
		}
		int d = 0;
		int ans = 0;
		int prev = 1;
		for (int key : c.keySet()) {
			int steps = key - prev;
			prev = key;
			ans += steps;
			d = Math.max(0, d - b * steps);
			d += c.get(key);
		}
		if (d % b == 0) {
			ans += d / b;
		} else {
			ans += d / b + 1;
		}
		output.println(ans);
	}

	public static void main(String[] args) throws FileNotFoundException {
//		Scanner input = new Scanner(System.in);
//		PrintWriter output = new PrintWriter(System.out);
		Scanner input = new Scanner(new File("millenium.in"));
		PrintWriter output = new PrintWriter(new File("millenium.out"));

		new Solution().run(input, output);

		input.close();
		output.close();
	}
}
