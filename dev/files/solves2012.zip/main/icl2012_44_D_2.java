#include <cstdio>
#include <cstring>
#include <cmath>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <iostream>
#include <fstream>
#include <set>

#define mp make_pair
#define pb push_back
#define zero(a) memset(a, 0, sizeof(a))
#define SZ(a) ((int)(a.size()))
#define sqr(a) ((a)*(a))
                
typedef long long ll;
typedef long double ld;

#define taskname "millenium"

using namespace std;

int n;
long long a, b;
pair <long long, long long> A[110000];

int main (void)
{
  long long x, y, l, r;
  int i;
  freopen (taskname".in", "rt", stdin);
  freopen (taskname".out", "wt", stdout);
  scanf("%d%I64d%I64d", &n, &a, &b);
  for (i=0; i<n; i++)
    scanf("%I64d%I64d", &A[i].second, &A[i].first), A[i].first--; 
  sort(A,A+n);
  long long res=0, sz=b;
  for (i=0; i<n; i++)
  {
    if (res<A[i].first)
      res=A[i].first, sz=b;
    if (sz==0)
      res++, sz=b;
    sz--;
  }
  cout<<res<<endl;
  return 0;
}


