#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <stack>
#include <string>
#include <sstream>
#include <cstring>
#include <cmath>
#include <ctime>
#include <numeric>

using namespace std;

#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define re return
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int) (x).size())
#define sqr(x) ((x) * (x))
#define sqrt(x) sqrt(abs(x))
#define rep(i, n) for (int i= 0; i < (n); i++)
#define rrep(i, n) for (int i = (n) - 1; i >= 0; i--)
#define re return
#define y0 y2369
#define y1 y347256
#define fill(x, y) memset(x, y, sizeof(x))

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef vector<string> vs;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef double D;
typedef long double LD;

template <class T> T abs(T x) { re x > 0 ? x : -x;}

#define FILENAME "changes"

int n;
int m;

int a[10000], b[10000], col[10000];
int need[10000];
int h;

int get(int i) {
	re a[i] + col[i] * n - h;
}	

bool l1(int i, int j) {
	if (get(i) != get(j))
		re get(i) < get(j);
	re i < j;	
}

set<int, bool (*) (int, int)> s(l1);

void makeans(int k) {
	rep(i, n) {	
		int tmp = a[i] - k;
		need[i] = (b[i] - tmp) / n;
	}	

	rep(i, n)
		if (need[i] > 0)
			s.insert(i);
	vi ans;	
	while (!s.empty()) {
		int p = *s.begin();
		if (get(p) < 0) {
			cout << -1 << endl;
			re;
		}
		s.erase(p);
		if (!s.empty()) {
			int q = *s.begin();
			if (get(q) <= 0) {
				cout << -1 << endl;
				re;
			}
		}
		col[p]++;
		ans.pb(p);
		if (need[p] > col[p])
			s.insert(p);
		h++;	
	}
	cout << sz(ans) << endl;
	rep(i, sz(ans))
		cout << ans[i] + 1 << ' ';
	cout << endl;	
}

int main() {
	freopen(FILENAME".in", "r", stdin);
	freopen(FILENAME".out", "w", stdout);

	cin >> n;
	rep(i, n)
		cin >> a[i];
	rep(i, n)
		cin >> b[i];

	int f = (a[0] - b[0] + 10000 * n) % n;	
	rep(i, n) {
		if ((a[i] - b[i] + 10000 * n) % n != f) {
			cout << -1 << endl;
			re 0;
		}
	}	
        
	for (int t = 0; t <= 1000000; t++) {
		if ((ll) t * n > 100000000)
			break;
		int o = t * n + f;
		int s = 0;
		int g = 1;
		rep(i, n) {	
			int tmp = a[i] - o;
			if (tmp > b[i]) {
				g = 0;
				break;
			}
			s += (b[i] - tmp) / n;
		}	
		if (s != o)
			g = 0;
		if (!g)
			continue;	
		makeans(o);
		re 0;	
	}

	cout << -1 << endl;
	
	return 0;
}
