import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class Solution {
	static boolean[][][] was;

	static class State implements Comparable<State> {
		int i, j, br;

		public State(int I, int J, int Br) {
			i = I;
			j = J;
			br = Br;
		}

		@Override
		public int compareTo(State s) {
			return s.i != i ? i - s.i : s.j != j ? j - s.j : br - s.br;
		}
	}

	static short[][] a;
	static State end;
	static int n, m;

	public static void main(String[] args) throws Exception {
		BufferedReader in = new BufferedReader(new FileReader("islands.in"));
		PrintWriter out = new PrintWriter(new File("islands.out"));

		StringTokenizer st = new StringTokenizer(in.readLine());

		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());

		a = new short[n][m];
		was = new boolean[n][m][11];

		for (int i = 0; i < n; i++) {
			String s = in.readLine();
			for (int j = 0; j < s.length(); j++)
				a[i][j] = (short) (s.charAt(j) - '0');
		}

		st = new StringTokenizer(in.readLine());
		State init = new State(Integer.parseInt(st.nextToken()) - 1, Integer.parseInt(st.nextToken()) - 1, 10);
		st = new StringTokenizer(in.readLine());
		end = new State(Integer.parseInt(st.nextToken()) - 1, Integer.parseInt(st.nextToken()) - 1, 10);

		if (bfs(init))
			out.println("YES");
		else
			out.println("NO");

		out.close();
	}

	static int[] di = { -1, 0, 1, 0 };
	static int[] dj = { 0, 1, 0, -1 };

	private static boolean bfs(State init) {
		LinkedList<State> q = new LinkedList<State>();
		q.add(init);
		was[init.i][init.j][init.br] = true;

		while (!q.isEmpty()) {
			State curr = q.pop();

			if (curr.i == end.i && curr.j == end.j)
				return true;

			for (int i = 0; i < di.length; i++) {
				int newI = curr.i + di[i], newJ = curr.j + dj[i];
				if (!isOk(newI, newJ))
					continue;

				// from curr bridges
				for (int j = 0; j < a[curr.i][curr.j]; j++) {
					if (curr.br == j)
						continue;
					if (was[newI][newJ][10])
						continue;

					State newS = new State(newI, newJ, 10);
					was[newS.i][newS.j][newS.br] = true;
					q.add(newS);
				}

				// from neig. bridges
				for (int j = 0; j < a[newI][newJ]; j++) {
					if (was[newI][newJ][j])
						continue;

					State newS = new State(newI, newJ, j);
					was[newS.i][newS.j][newS.br] = true;
					q.add(newS);
				}
			}
		}

		return false;
	}

	private static boolean isOk(int i, int j) {
		return i >= 0 && i < n && j >= 0 && j < m;
	}
}
