#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <string>
#include <queue>
#include <string.h>

#define li unsigned long long
#define pb push
#define mp make_pair

#define INF (1000 * 1000 * 1000)
#define EPS (1e-9) 

using namespace std;

vector < vector <int> > a;
vector < vector <int> > b, c;
int n, m, xs, ys, xf, yf;
queue <int> xx, yy, tt;

void bfs(int xs, int ys){
	int x = xs, y = ys, xcur, ycur, dx, dy, t;
	xx.pb(x), yy.pb(y), tt.pb(1);
	c[x][y] = 1;
	while (!xx.empty()){
		x = xx.front(), y = yy.front(), t = tt.front();
		xx.pop(), yy.pop(), tt.pop();
		//cerr << x + 1 << ' ' << y + 1 << ' ' << t << endl;
		//cerr << "_________" << endl;
		if (b[xf][yf] == 1 || c[xf][yf] == 1) return;
		for (dx = -1; dx <= 1; dx++)
			for (dy = -1; dy <= 1; dy++)
				if ((dx == 0 || dy == 0) && (dx != 0 || dy != 0)){
					xcur = x + dx, ycur = y + dy;
					if (xcur < 0 || xcur == n || ycur < 0 || ycur == m) continue;
					
					//cerr << xcur + 1 << ' ' << ycur + 1 << ' ' << endl;

					if (t == 1 && a[x][y] != 0 && c[xcur][ycur] == 0){
						c[xcur][ycur] = 1;
						xx.pb(xcur), yy.pb(ycur), tt.pb(1);
					}

					if (t == 1 && a[xcur][ycur] > 0 && b[xcur][ycur] == 0){
						b[xcur][ycur] = 1;
						xx.pb(xcur), yy.pb(ycur), tt.pb(0);
					}

					if (t == 0 && a[x][y] > 1 && c[xcur][ycur] == 0){
						c[xcur][ycur] = 1;
						xx.pb(xcur), yy.pb(ycur), tt.pb(1);
					}

					if (t == 0 && a[xcur][ycur] != 0 && b[xcur][ycur] == 0){
						b[xcur][ycur] = 1;
						xx.pb(xcur), yy.pb(ycur), tt.pb(0);
					}

				}
		//cerr << "_________" << endl;
	}
}

int main(){
	freopen("islands.in", "r", stdin);
	freopen("islands.out", "w", stdout);
	cin >> n >> m;
	int i, j;
	a.resize(n);
	b.resize(n);
	c.resize(n);
	for (i = 0; i < n; i++) {
		a[i].resize(m);
		b[i].resize(m, 0);
		c[i].resize(m, 0);
	}
	char cc;
	for (i = 0; i < n; i++)
		for (j = 0; j < m; j++){
			cin >> cc;
			a[i][j] = cc - '0';
		}
		
	cin >> xs >> ys >> xf >> yf;
	xs--, ys--, xf--, yf--;
	bfs(xs, ys);
	if (b[xf][yf] == 1 || c[xf][yf] == 1) 
		cout << "YES" << endl; 
	else 
		cout << "NO" << endl;
}