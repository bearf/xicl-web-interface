#include <iostream>
#include <vector>
#include <cassert>
#include <set>
#include <cstdio>
#include <map>
#include <deque>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < int(n); ++i)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; --i)
#define all(a) a.begin(), a.end()
#define fs first
#define sc second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef long double ld;

const string filename("islands");

vector <int> a[100100];
vector <bool> use[100100][2];
const int x1[4] = {0, 0, 1, -1};
const int y1[4] = {1, -1, 0, 0}; 
int n, m;

void dfs(int x, int y, int q){
	use[x][q][y] = true;
	bool q1 = false;
	if (a[x][y] - q > 0) q1 = true;
	forn(i, 4){
		int x2 = x + x1[i], y2 = y + y1[i];
		if (x2 < 0 || y2 < 0 || x2 >= n || y2 >= m) continue;
		if (q1){
			if (!use[x2][0][y2]) dfs(x2, y2, 0);
		} else {
			if (a[x2][y2] > 0 && !use[x2][1][y2]) dfs(x2, y2, 1);
		}


	}


}

int solve () {
//	int n, m;
	scanf("%d %d\n", &n, &m);
	forn(i, n){
		a[i].resize(m);
		use[i][0].resize(m);
		use[i][1].resize(m);
		forn(j, m){
			char c;
			scanf("%c", &c); 
			a[i][j] = int(c) - '0';
		}
		scanf("\n");
	}
	int a, b, c, d;
	cin >> a >> b >> c >> d;
	a --;
	b --;
	c --;
	d --;
	//cerr << c << ' ' << d << endl;
	dfs(a, b, 0);
	cerr << '!' << endl;
	if (use[c][0][d] || use[c][1][d]){
		printf ("YES\n");
	} else printf ("NO\n");	



	return 1;
}

int main () {
	#ifdef _LOCAL_MACHINE41
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
	while (!solve());
	#else
	freopen((filename + ".in").data(), "rt", stdin);
	freopen((filename + ".out").data(), "wt", stdout);
	solve();
	#endif
	return 0;
}
