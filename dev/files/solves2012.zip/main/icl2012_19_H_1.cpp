#include <cstdio>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <iostream>
#include <cmath>

using namespace std;

const int inf = (int) 2e9;
const double EPS = 1e-8;
const double PI = acos(-1.);

typedef pair<int, int> pii;
typedef long long ll;

#define NAME "trees"

vector <int> dv;
int a[100500];

int gcd(int x, int y)
{
	return y == 0 ? x : gcd(y, x%y);
}

int main()
{
	freopen (NAME".in", "r", stdin);
	freopen (NAME".out", "w", stdout);
	int n, k;
	int i, j;
	scanf("%d%d", &n, &k);
	int g = 0;
	for (i = 0; i < k; ++i)
	{
		scanf("%d", &a[i]);
		if (i > 0)
			g = gcd(a[i] - a[i - 1], g);
	}
	if (k == 1)
	{
		int i = 1;
		int m1 = a[0] - 1;
		int m2 = n - a[k - 1];
		int l = m1;
		int r = m2;
		long long ans = 0;
		while (m1 > 0 || m2 > 0)
		{
			int j1 = m1 == 0 ? inf : l/m1 + 1;
			int j2 = m2 == 0 ? inf : r/m2 + 1;
			ans += ((long long)(m1 + 1)*(m2 + 1) - 1)*(min(j1, j2) - i);
			i = min(j1, j2);
			m1 = l/i;
			m2 = r/i;
		}
		printf("%I64d\n", ans + 1);
		return 0;
	}
	for (i = 1; i*i <= g; ++i)
	{
		if (g%i != 0)
			continue;
		dv.push_back(i);
		if (i*i < g)
			dv.push_back(g/i);
	}
//	printf("%d\n", g);
	sort(dv.begin(), dv.end());
	long long ans = 0;
	for (i = 0; i < dv.size(); ++i)
	{
		ans += (long long)((a[0] - 1)/dv[i] + 1)*((n - a[k - 1])/dv[i] + 1);
	}
	printf("%I64d\n", ans);
	return 0;
}