import java.io.File;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.Scanner;


public class Solution {
	public static void main(String [] args) throws Exception
	{
		String name = "oranges";
		Scanner in = new Scanner(new File(name + ".in"));
		PrintWriter out = new PrintWriter(name + ".out");
		int p = in.nextInt();
		BigInteger n = in.nextBigInteger();
		BigInteger bp = BigInteger.valueOf(p);
		
		int len = 0;
		BigInteger tk = n;
		int r1[] = new int[5000];
		int r[] = new int[5000];
		
		while (tk.compareTo(BigInteger.ZERO) > 0) {
			r1[len] = tk.mod(bp).intValue();
			len++;
			tk = tk.divide(bp);
		}
		//System.err.println(len);
		BigInteger pw[] = new BigInteger[len + 2];
		pw[0] = BigInteger.ONE;
		for (int i = 1; i <= len + 1; i++) {
			pw[i] = pw[i - 1].multiply(bp);
		}
		BigInteger pw2[] = new BigInteger[len + 2];
		pw2[0] = BigInteger.ONE;
		for (int i = 1; i <= len + 1; i++) {
			pw2[i] = pw2[i - 1].multiply(BigInteger.valueOf(2));
		}
				
		BigInteger ans = BigInteger.ZERO;
		for (int i = len + 1; i >= Math.max(0, len - 1); i--) {
			for (int j = Math.min(i, len); j >= 0; j--) {
				for (int k = len + 1; k >= 0; k--) {
					r[k] = r1[k];
				}
				r[i]--;
				r[j]--;
				for (int k = 0; k <= len + 1; k++) {
					r[k] = -r[k];
				}
				//System.err.println(i + " " + j);
				for (int k = 0; k <= len + 1; k++) {
					if (r[k] < 0) {
						r[k] += p;
						r[k + 1]--;
					}
					//System.err.print(r[k] + " ");
				}
				//System.err.println();
				
				int cc = 0;
				boolean can = true;
				
				if (r[len + 2] < 0) {
					can = false;
				}
				boolean gg = i == j;
				for (int ii = 0; ii <= len + 1; ii++) {
					int rz = ii;
					int ff = r[ii];
					if (ff != 2 && ff != 0) {
						gg = false;
					}
					if (ff > 2) {
						can = false;
						break;
					}
					if (ff == 2 && rz >= j) {
						can = false;
						break;
					}
					if (ff == 1 && rz >= i) {
						can = false;
						break;
					}					
					if (ff == 1 && rz < j) {
						cc++;
					}
					
				}
				if (gg && can) {
					ans = ans.subtract(BigInteger.ONE);
				}
				if (can)
					ans = ans.add(pw2[cc]);
			}
		}
		out.println(ans);
		out.close();
	}

}
