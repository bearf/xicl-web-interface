#include <iostream>
#include <sstream>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <vector>
#include <string>
#include <ctime>
#include <cmath>
using namespace std;

typedef long long int ll;
typedef pair<int, int> pii;
#define X first
#define Y second

const int N = 100005;

const ll INF = 1e15;
int n, a, b;
ll T [N];
map<ll, ll> trans;

int main()
{
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	freopen("millenium.in", "r", stdin); freopen("millenium.out", "w", stdout);
	
	T [0] = -INF;

	scanf("%d%d%d", &n, &a, &b);
	for (int i = 0; i < n; i++)
	{
		ll x, y;
		scanf("%I64d%I64d", &y, &x);
		trans[y]++;
	}
	
	ll time;
	trans[INF] = 0;
	for (map<ll, ll>::iterator it = trans.begin(); it != trans.end(); it++)
	{
		ll row = it->X;  //i
		ll cnt = it->Y;
		
		map<ll, ll>::iterator temp = it;
		temp++;

		ll nextRow = (temp)->X;
		ll nextCnt = (temp)->Y;
		
		if (nextRow == INF)
		{
			ll x = (cnt + b - 1) / b;
			time = x + row - 1;
			break;
		}

		ll t = nextRow - row;
		ll dx = t * b;

		if (cnt > dx)
		{
			cnt -= dx;
			trans [nextRow] += cnt;
		}
	}

	printf("%I64d", time);

	return 0;
}
