#pragma comment(linker,"/STACK:64000000")
#define _CRT_SECURE_NO_WARNINGS


#include <algorithm>
#include <ctime>
#include <cmath>
#include <iostream>
#include <memory.h>
#include <map>
#include <set>
#include <string>
#include <sstream>
#include <stdio.h>
#include <vector>

using namespace std;

#define RE scanf
#define WR printf
#define FI first
#define SE second
#define PB push_back
#define MP make_pair

#define FOR(i,a,b) for(int i = (a);i<=(b);i++)
#define DFOR(i,a,b) for(int i = (a);i>=(b);i--)
#define SZ(a) (int)((a).size())
#define FA(i,v) FOR(i,0,SZ(v)-1)
#define RFA(i,v) DFOR(i,SZ(v)-1,0)
#define CLR(a) memset(a,0,sizeof(a))

#define PAR pair<int,int>
#define LL long long
#define o_O 1000000000

void __never(int a) {printf("\nOPS %d\n",a);}
#define ass(f) {if (!(f)) {__never(__LINE__);cout.flush();cerr.flush();abort();}}

int n;
int A[10100], B[10100];
int d[10100];
int t[10100];
int ans[10100], a_sz=0;

void sol()
{
	int mi_d=0;
	FOR(a,1,n)
	{
		d[a] = B[a]-A[a];
		mi_d = min(d[a], mi_d);
	}
	int c = ((d[1]%n)+n)%n;
	FOR(a,1,n) if (((d[a]%n)+n)%n != c)
	{
		cout << -1;
		return;
	}

	int k=0;
	FOR(a,1,100000) if (mi_d+(n-c)-n+a*n >= 0)
	{
		k = (n-c)-n+a*n;
		break;
	}

	//cout << k << "\n";
	FOR(a,1,n)
	{
		ass((d[a]+k)%n==0);
		t[a] = (d[a]+k)/n;
		ass(t[a]>=0);
		//cout << t[a] << " ";
	}

	FOR(a,1,k)
	{
		int mi = 0;
		FOR(b,1,n)
			if (t[b]>0)
				if (mi==0 || A[b]<A[mi])
					mi = b;
		t[mi]--;
		ans[a_sz++] = mi;
		FOR(b,1,n)
			if (b==mi) A[b]+=n-1;
			else
			{
				if (A[b]==0)
				{
					cout << -1;
					return;
				}
				A[b]--;
			}
	}

	cout << k << "\n";
	FOR(a,0,a_sz-1) WR("%d ", ans[a]);
}
int main(){
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
	freopen("changes.in","r",stdin);
	freopen("changes.out","w",stdout);

	cin >> n;
	FOR(a,1,n) RE("%d", &A[a]);
	FOR(a,1,n) RE("%d", &B[a]);
	sol();
	return 0;
}
