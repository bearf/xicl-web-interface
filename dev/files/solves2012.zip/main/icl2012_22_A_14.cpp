#include <fstream>
#include <algorithm>
#include <vector>
#include <map>
using namespace std;
unsigned __int64 n;
bool chk(__int64 x, __int64 y)
{
	return x>=0&&y>=0&&y<=x;
}
unsigned __int64 hash(__int64 x, __int64 y)
{
	x--;
	y--;
	unsigned __int64 h;
	h=x*n+y;
	return h;
}
void main()
{
	ifstream cin("bricks.in");
	ofstream cout("bricks.out");
	__int64 k;
	cin>>n>>k;
	__int64 x,y;
	map <unsigned __int64, bool> st;
	for (__int64 i=0;i<k;i++)
	{
		cin>>x>>y;
		x--;
		y--;
		if (chk(x,y+1)&&st[hash(x,y+1)]&&chk(x-1,y)&&!st[hash(x-1,y)])
		{
			cout<<(i+1);
			break;
		}
		if (chk(x,y-1)&&st[hash(x,y-1)]&&chk(x-1,y-1)&&!st[hash(x-1,y-1)])
		{
			cout<<(i+1);
			break;
		}
		st[hash(x,y)]=1;
	}
	cin.close();
	cout.close();
}