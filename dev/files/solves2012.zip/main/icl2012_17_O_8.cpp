#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int main()
{
	freopen("darts.in","r",stdin);
	freopen("darts.out","w",stdout);
	int l,r,n,m,k,i,j,e;
	vector<pair<int,int>> a,q;pair<int,int>w;
	vector <int>q3,q4,q1,q2;
	cin>>n>>m>>k;
	vector<int> b,c;
	for(i=0;i<k;i++)
	{cin>>w.first>>w.second;
	a.push_back(w);}
	sort(a.begin(),a.end());
	q.push_back(a[0]);
	for(i=1;i<k;i++)
     if(a[i]!=a[i-1])q.push_back(a[i]);
	w.first=0;w.second=0;q.push_back(w);
	w.first=n;w.second=m;q.push_back(w);
	for(i=0;i<(int)q.size();i++)
	{q1.push_back(q[i].first);
	q2.push_back(q[i].second);}
sort(q1.begin(),q1.end());
sort(q2.begin(),q2.end());
q3.push_back(q1[0]);
for(i=1;i<(int)q1.size();i++)
if(q1[i]!=q1[i-1]) q3.push_back(q1[i]);
q4.push_back(q2[0]);
for(i=1;i<(int)q2.size();i++)
if(q2[i]!=q2[i-1]) q4.push_back(q2[i]);
            for(i=0;i<q3.size()-1;i++)
		   for(j=i+1;j<q3.size();j++)
		   {if(abs(q3[i]-q3[j])!=0) b.push_back(abs(q3[i]-q3[j]));}
		for(i=0;i<q4.size()-1;i++)
		for(j=i+1;j<q4.size();j++)
		{
	if(abs(q4[i]-q4[j])!=0)c.push_back(abs(q4[i]-q4[j]));
	}
		sort(b.begin(),b.end());
		sort(c.begin(),c.end());
		i=0;j=0;
		k=0;
		while(i<b.size()&&j<c.size())
		{l=0;r=0;
			if(b[i]>c[j]) j++;else
				if(b[i]<c[j]) i++;
			if(b[i]==c[j])
			{
               e=b[i];
			   while(i<b.size() && b[i]==e) {r++;i++;}
			   while(j<c.size() && c[j]==e) {l++;j++;}
			   k=k+l*r;
			}
		}
		cout<<k;
		return 0;
}
/*
5 8 4
4 2
2 4
2 5
4 2
*/