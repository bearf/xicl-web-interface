#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <map>
#include <set>

using namespace std;

typedef long long int LL;

int main() {
	freopen("darts.in", "r", stdin);
	freopen("darts.out", "w", stdout);

	int N, M, K;
	cin >> N >> M>> K;
	int MIN = min(N,M);
	
	int x, y;
	vector<int>vx(2005);
	vector<int>vy(2005);
	for(int i = 0; i < K; ++i)
	{
		scanf("%i%i",&x,&y);
		vx[i] = x;
		vy[i] = y;
	}
	sort(vx.begin(), vx.end());
	sort(vy.begin(), vy.end());
	int w = vx[0];
	for(int i = 1; i < 2005; ++i)
	{
		if(vx[i] == w)
			vx[i] = 0;
		else
			w = vx[i];
	}
	w = vy[0];
	for(int i = 1; i < 2005; ++i)
	{
		if(vy[i] == w)
			vy[i] = 0;
		else
			w = vy[i];
	}
	vector<int>tvx;
	bool p = 0;
	tvx.push_back(0);
	for(int i = 0; i < 2005; ++i)
	{
		if(vx[i] != 0)
			tvx.push_back(vx[i]);
	}
	if(tvx[tvx.size()-1] != N)
		tvx.push_back(N);
	p = 0;
	vector<int>tvy;
	tvy.push_back(0);
	for(int i = 0; i < 2005; ++i)
	{
		if(vy[i] != 0)
			tvy.push_back(vy[i]);
	}
	if(tvy[tvy.size()-1] != M)
		tvy.push_back(M);
	map<int,int>mx;
	int xsi = tvx.size();
	int ysi = tvy.size();
	for(int i = 0; i < xsi; i++)
	{
		for(int j = i + 1; j < xsi; j++)
		{
			int t = tvx[j] - tvx[i];
			if(t > MIN)
				break;
			else
				mx[t]++;
		}
	}
	long long int cnt = 0;

	for(int i = 0; i < ysi; ++i)
	{
		for(int j = i+1; j < ysi; ++j)
		{
			int t = tvy[j] - tvy[i];
			if(t > MIN)
				break;
			else
			{
				map<int,int> ::iterator e = mx.find(t);
				if(e != mx.end())
				{
					LL u = e->second;
					cnt += u;
				}
			}
		}
	}
	cout << cnt;


	return 0;
}