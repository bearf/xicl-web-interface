#include <cstdio>
#include <cstring>
#include <cmath>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <iostream>
#include <fstream>
#include <set>

#define mp make_pair
#define pb push_back
#define zero(a) memset(a, 0, sizeof(a))
#define SZ(a) ((int)(a.size()))
#define sqr(a) ((a)*(a))
                
typedef long long ll;
typedef long double ld;

#define taskname "trees"
#define sqrtn 200000

using namespace std;

long long res;
int n, k, A[110000];
int E[10*sqrtn], up;

int main (void)
{
  int i, j, t, d;
  freopen (taskname".in", "rt", stdin);
  freopen (taskname".out", "wt", stdout);
  scanf("%d%d", &n, &k);
  for (i=0; i<k; i++)
    scanf("%d", &A[i]);
  sort(A,A+k);
  if (k==1)
  {
    res++;
    int d1=A[0]-1, d2=n-A[0];
    for (i=1; i<=sqrtn; i++)
      E[++up]=i;
//    cout<<res<<endl;
    for (j=1; j<=sqrtn; j++)
    {
      if (d1/j)
        E[up+1]=d1/j, up++;
      if (d2/j)
        E[up+1]=d2/j, up++;
    }
    assert(sqrtn*1ll*sqrtn>=n*4ll);
    //cerr<<up<<endl;
    sort(E+1,E+up+1);
    //up=unique(E+1,E+up+1)-E, up--;
    E[0]=0;
    /*cerr<<E[505]<<" "<<(d1/E[505]+1)*1ll*(d2/E[505]+1)-1ll<<endl;
    cerr<<E[505]-1<<" "<<(d1/(E[505]-1)+1)*1ll*(d2/(E[505]-1)+1)-1ll<<endl;
    cerr<<E[505]+1<<" "<<(d1/(E[505]+1)+1)*1ll*(d2/(E[505]+1)+1)-1ll<<endl;
    cerr<<E[504]<<" "<<E[505]<<" "<<E[506]<<endl;*/

    for (i=1; i<=up; i++)
      res+=max(0,E[i]-E[i-1])*1ll*((d1/E[i]+1)*1ll*(d2/E[i]+1)-1ll);
    cout<<res<<endl;
    return 0;
  }
  for (d=A[1]-A[0], i=1; i<k-1; i++)
    d=__gcd(d,A[i+1]-A[i]);
  for (i=1; i*1ll*i<=d; i++)
  {
    t=i;
    res+=((n-A[k-1])/t+1)*1ll*((A[0]-1)/t+1);
    //cerr<<t<<" "<<res<<" "<<d<<endl;
    if (i*i!=d)
    {
      t=d/i;
      res+=((n-A[k-1])/t+1)*1ll*((A[0]-1)/t+1);
    }
    //cerr<<t<<" "<<res<<" "<<d<<endl;
  }
  cout<<res<<endl;
  return 0;
}


