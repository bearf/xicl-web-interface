#include <cstdlib>
#include <cstdio>
#include <map>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int) n; ++i)
#define ford(i, n) for (int i = (int)n-1; i >= 0; --i)
#define fs first
#define sc second
#define x first
#define y second
#define mp make_pair
#define pb push_back
#define all(x) x.begin(), x.end()
#define seta(x,y) memset (x, y, sizeof (x))

typedef long long int64;
typedef pair <int, int> pii;

int n;
int64 a, b;
map <int64, int> M;
vector <pair <int64, int> > A;

int main()
{
	freopen("millenium.in", "r", stdin);
	freopen("millenium.out", "w", stdout);
	cin >> n >> a >> b;
	forn (i, n) {
		unsigned int x, y;
		scanf ("%u%u", &x, &y);
		int64 X, Y;
		X = x;
		Y = y;
		M[X] ++;
	}
	A = vector <pair <int64, int> > (M.begin(), M.end());
	int64 res = A.back().fs;
	forn (i, A.size()) {
		int64 rem = b;
		if (i > 0) {
			if (A[i-1].sc > 0) {
				while (A[i-1].sc > b) {
					A[i-1].sc -= b;
					res ++;
				}
				rem -= A[i-1].sc;
			}
		}
		A[i].sc -= rem;
	}
	while (A.back().sc > 0) {
		A.back().sc -= b;
		res ++;
	}
	cout << res << endl;
	return 0;
}
