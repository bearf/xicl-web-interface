#include <algorithm>
#include <iostream>
#include <vector>
#include <set>
#include <cmath>
using namespace std;
typedef pair <int, int> pii;
const int pi = 314159;
int n, head;
vector <int> next, key, prev;
bool cross(int w, int v){
	return (v > w);
}
bool less1(int w, int v){
	return abs(pi - w * 2) > abs(pi - 2 * v);
}
int main(){
	freopen("race.in", "r", stdin); freopen("race.out", "w", stdout);
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	cin >> n;
	next.resize(n + 1);
	key.resize(n + 1);
	prev.resize(n + 1);
	next[0] = 1;
	for (int i = 1; i <= n; i++){
		double w;
		cin >> w;
		w *= 100000;
		key[i] = floor(w); 
		next[i] = (i + 1) % (n + 1);
		prev[i] = i - 1;
	}
	int v = 1, kol = n;
	while (next[v] != 0){
		if (cross(key[v], key[next[v]]))
			if (less1(key[v], key[next[v]])){
				next[prev[v]] = next[v];
				prev[next[v]] = prev[v];
				v = next[v];
				kol--;
				while (prev[v] != 0){
					bool tt = false;
					if (cross(key[prev[v]], key[v]))
						if (less1(key[prev[v]], key[v])){
							prev[v] = prev[prev[v]];
							next[prev[v]] = v;
							v = prev[v];
							kol--;
						}
						else{
							kol--;
							next[prev[v]] = next[v];
							tt = true;
						}
					else tt = true;
					if (tt) break;
				}
			}
			else{
				kol--;
				next[v] = next[next[v]];
			}
		else
			v = next[v]; 
	}
	v = 0;
	cout << kol << "\n";
	if (kol == 0) return 0;
	while (next[v] == 0) v++;
	while (next[v] != 0){
		cout << next[v] << " ";
		v = next[v];
	}
	return 0;
}