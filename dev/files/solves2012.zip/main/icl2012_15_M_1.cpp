#include <iostream>
#include <sstream>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <vector>
#include <string>
#include <ctime>
#include <cmath>
using namespace std;

typedef unsigned long long int ll;
#define mp make_pair
#define X first
#define Y second

int ans, n;
map <ll, bool> used;

bool niceBit (ll mask, int pos)
{
	return (mask & ((ll)1 << pos));
}

void onBit (ll & mask, int pos)
{
	mask ^= ((ll)1 << pos);
}

void ofBit (ll & mask, int pos)
{
	mask ^= ((ll)1 << pos);
}

void invers (ll & mask)
{
	ll locMask = ((ll)1 << n) - 1;
	mask ^= locMask;
}

ll giveMask (ll m)
{
	ll ansMask = 0;
	for (int i = n - 1; i >= 0; i--)
	{
		ll locM = ((ll)1 << i);
		if (locM <= m)
		{
			m -= locM;
			onBit(ansMask, i);
		}
	}

	if (m != 0)
		return -1;
	else
		return ansMask;
}

void DFS (ll maskLeft, ll maskRigth)
{
	if (used[maskRigth])
		return;
	
	used [maskRigth] = 1;
	ans++;
	
	ll maskUp = (maskLeft | maskRigth);
	invers(maskUp);

	for (int i = 0; i < n - 1; i++)
	{
		ll maskLeftS = maskLeft;
		ll maskRigthS = maskRigth;
		
		if (niceBit (maskRigth, i))
		{
			if (niceBit(maskLeft, i + 1))
			{
				ofBit(maskLeft, i + 1);
				ofBit (maskRigth, i);
				onBit (maskLeft, i);

				DFS(maskLeft, maskRigth);
			}
			else if (niceBit (maskUp, i + 1))
			{
				ofBit (maskRigth, i);
				onBit (maskRigth, i + 1);
				onBit (maskLeft, i);

				DFS(maskLeft, maskRigth);
			}

			maskLeft = maskLeftS;
			maskRigth = maskRigthS;
		}
	}
}

int main()
{
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	freopen("weights.in", "r", stdin); freopen("weights.out", "w", stdout);
	
	int t;
	cin >> t;

	for (int i = 0; i < t; i++)
	{
		used.clear();
		ans = 0;

		ll M;
		cin >> n >> M;
		
		ll startMask = giveMask(M);
		if (startMask == -1)
		{
			puts("0");
			continue;
		}

		DFS (0, startMask);

		cout << ans << endl;
	}

	return 0;
}
