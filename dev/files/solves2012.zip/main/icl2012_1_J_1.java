import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Solution {
	public static final int[] dx = { 1, -1, 0, 0 };
	public static final int[] dy = { 0, 0, 1, -1 };

	public void run(Scanner input, PrintWriter output) {
		int n = input.nextInt();
		int m = input.nextInt();
		input.nextLine();
		int[][] f = new int[n][m];
		for (int i = 0; i < n; i++) {
			String l = input.nextLine();
			for (int j = 0; j < m; j++) {
				f[i][j] = l.charAt(j) - '0';
			}
		}
		int ax = input.nextInt()-1, ay = input.nextInt()-1;
		int bx = input.nextInt()-1, by = input.nextInt()-1;
		int[][] s = new int[n][m];
		// 0 - nothing, 1 - possible by using own b, 2 - possible by using other
		// b
		s[ax][ay] = 2;
		List<Integer> updX = new ArrayList<Integer>();
		List<Integer> updY = new ArrayList<Integer>();
		updX.add(ax);
		updY.add(ay);
		while (!updX.isEmpty()) {
			List<Integer> newX = new ArrayList<Integer>();
			List<Integer> newY = new ArrayList<Integer>();

			for (int i = 0; i < updX.size(); i++) {
				int cx = updX.get(i);
				int cy = updY.get(i);

				// can update on 2?
				if ((s[cx][cy] == 1 && f[cx][cy] > 1)
						|| (s[cx][cy] == 2 && f[cx][cy] > 0)) {
					// update -> 2
					for (int j = 0; j < dx.length; j++) {
						int nx = cx + dx[j], ny = cy + dy[j];
						if (nx >= 0 && ny >= 0 && nx < n && ny < m) {
							if (s[nx][ny] != 2) {
								s[nx][ny] = 2;
								newX.add(nx);
								newY.add(ny);
							}
						}
					}
				} else {
					// update -> 1
					for (int j = 0; j < dx.length; j++) {
						int nx = cx + dx[j], ny = cy + dy[j];
						if (nx >= 0 && ny >= 0 && nx < n && ny < m) {
							if (s[nx][ny] == 0 && f[nx][ny] > 0) {
								s[nx][ny] = 1;
								newX.add(nx);
								newY.add(ny);
							}
						}
					}
				}
			}

			updX = newX;
			updY = newY;
		}
		
		output.println(s[bx][by] == 0 ? "NO" : "YES");
	}

	public static void main(String[] args) throws IOException {
		// Scanner input = new Scanner(System.in);
		// PrintWriter output = new PrintWriter(System.out);

		Scanner input = new Scanner(new File("islands.in"));
		PrintWriter output = new PrintWriter(new File("islands.out"));

		new Solution().run(input, output);

		input.close();
		output.close();
	}
}
