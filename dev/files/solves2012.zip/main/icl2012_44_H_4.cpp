#include <cstdio>
#include <cstring>
#include <cmath>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <iostream>
#include <fstream>
#include <set>

#define mp make_pair
#define pb push_back
#define zero(a) memset(a, 0, sizeof(a))
#define SZ(a) ((int)(a.size()))
#define sqr(a) ((a)*(a))
                
typedef long long ll;
typedef long double ld;

#define taskname "trees"
#define sqrtn 200000

using namespace std;

int n,k;

vector<int> pos;
ll res = 0;
int a[110000];

int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}

int main (void)
{
  freopen (taskname".in", "rt", stdin);
  freopen (taskname".out", "wt", stdout);
  scanf("%d%d", &n, &k);
  for (int i=0; i<k; i++)
    scanf("%d", &a[i]);

  sort(a,a+k);

  if (k == 1){
  	ll d1 = a[0] - 1;
  	ll d2 = n - a[k-1];

  	pos.pb(0);
  	pos.pb(n);

  	for (int i = 1; i < sqrtn; i++)
  		pos.pb(i), pos.pb(d1/i),pos.pb(d2/i),pos.pb(d1/i+1),pos.pb(d1/i-1),pos.pb(d2/i+1),pos.pb(d2/i-1);

  	sort(pos.begin(),pos.end());


  	pos.erase(unique(pos.begin(),pos.end()),pos.end());

  	while (pos.back() > n)
  		pos.pop_back();
  	reverse(pos.begin(),pos.end());
  	while (pos.back() < 0)
  		pos.pop_back();
  	reverse(pos.begin(),pos.end());
 
  	res = 1;
  	for (int i = 1; i < (int)pos.size(); i++)
  		res += (pos[i] - pos[i-1]) * 1LL * ((d1/pos[i]+1)*1LL*(d2/pos[i]+1)-1LL);

    cout << res << endl;	

  	return 0;
  }

  int d = 0;
//  cerr << a[1] - a[0] << endl;
  for (int j = 1; j < k; j++)
	d = gcd(d,a[j] - a[j-1]);


  
  for (int i = 1; i*1LL*i <= d; i++){
  	if (d % i != 0)
  		continue;
  	res += ((a[0] - 1)/i+1)*1LL*((n - a[k-1])/i+1);
  	if (i*1LL*i != d){
  		int j = d/i;
	  	res += ((a[0] - 1)/j+1)*1LL*((n - a[k-1])/j+1);
  	}
  }

  cout << res << endl;  		
  return 0;
}


