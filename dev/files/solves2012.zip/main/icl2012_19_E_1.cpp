#include <cstdio>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <iostream>
#include <cmath>

using namespace std;

const int INF = (int) 1e9;
const double EPS = 1e-8;
const double PI = acos(-1.);

typedef pair<int, int> pii;
typedef long long ll;

#define NAME "changes"

int val[100100];
int nval[100100];
int cnt[100100];
int main()
{
	freopen (NAME".in", "r", stdin);
	freopen (NAME".out", "w", stdout);
	int N;
	scanf ("%d", &N);
	for (int i = 0; i < N; ++i)
	{
		scanf ("%d", &val[i]);
	}
	for (int i = 0; i < N; ++i)
	{
		scanf ("%d", &nval[i]);
	}
	int x = nval[0] - val[0];
	for (int i = 0; i < N; ++i)
	{
		int f = nval[i] - val[i];
		if ((f - x)%N != 0)
		{
			printf("-1\n");
			return 0;
		}
		x = min(f, x);		
	}
	x = -x;
	set<pii> S;
	for (int i = 0; i < N; ++i)
	{
		int f = nval[i] - val[i];
		cnt[i] = (x + f)/N;
		if (cnt[i] > 0)
		{
			S.insert(pii(val[i], i));
		}
	}
	vector<int> ans;
	int sub = 0;
	while (!S.empty())
	{
		pii t = *S.begin();
		S.erase(S.begin());
		int nm = t.second;
		if (val[nm] - sub < 0)
		{
			printf("-1\n");
			return 0;
		}
		++sub;
		val[nm] += N;
		--cnt[nm];
		if (cnt[nm] > 0)
		{
			S.insert(pii(val[nm], nm));
		}
		ans.push_back(nm);
	}
	printf("%d\n", ans.size());
	for (int i = 0; i < ans.size(); ++i)
	{
		printf("%d ", ans[i] + 1);
	}
	return 0;
}