#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <ctime>
#include <cmath>

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define fs first
#define sc second
#define len(x) ((int) (x).size())
#define last(x) (x)[(len(x)-1)]
#define plast(x) (x)[(len(x)-2)]
#define sqr(x) ((x)*(x))
#define foreach(i, x) for (__typeof((x).begin()) i = (x).begin(); i != (x).end(); ++i)
#define forn(i, n) for (int i = 0; i < int(n); ++i)

using namespace std;

typedef long double ld;
typedef long long int64;

int64 a[10100], b[10100], c[10100];

inline int64 sgn(int64 a) {
	return (a < 0 ? -1 : 1);
}

inline int64 abs1(int64 a) {
	return (a < 0 ? -a : a);
}

int main() {
	freopen("changes.in", "r", stdin);
	freopen("changes.out", "w", stdout);
	int64 n;
	cin >> n;
	int64 sa = 0;
	forn (i, n) {
		cin >> a[i];
		sa += a[i];
	}
	int64 sb = 0;
	forn (i, n) {
		cin >> b[i];
		sb += b[i];
	}
	if (sa != sb) {
		cout << -1;
		return 0;
	}
	int64 r = (a[0] - b[0] + n * 11000ll) % n;
	forn (i, n) {
		if ((a[i] - b[i] + n * 11000ll) % n != r) {
			cout << -1;
			return 0;
		}
		c[i] = (abs1(b[i] - a[i] + r) / n) * sgn(b[i] - a[i] + r);
	}
	int64 ans = 0, mn = 0;
	forn (i, n) {
		ans += c[i];
		mn = min(mn, c[i]);
	}
	if (mn < 0) {
		ans -= mn * n;
		forn (i, n) {
			c[i] -= mn;
		}
	}
/*	forn (i, n) {
		cerr << c[i] << " ";
	}
	cerr << endl;
*/	vector<int> ansv;
	forn (q, ans) {
		int mni = 0;
		forn (i, n) {
			if (c[i] && (!c[mni] || a[mni] > a[i])) {
				mni = i;
			}
		}
		c[mni]--;
		a[mni] += n;
		ansv.pb(mni);
		forn (i, n) {
			a[i]--;
		}
		forn (i, n) {
			if (a[i] < 0) {
				cout << -1;
				return 0;
			}
		}
	}
	cout << ans << endl;
	forn (i, ans) {
		cout << ansv[i] + 1 << " ";
	}
	return 0;
}
