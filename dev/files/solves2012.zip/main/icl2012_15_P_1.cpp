#include <iostream>
#include <sstream>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <vector>
#include <string>
#include <ctime>
using namespace std;

const int N = 105;

int n, x[N], y[N];

int main()
{
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	freopen("wire.in", "r", stdin); freopen("wire.out", "w", stdout);
		
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		scanf("%d%d", x + i, y + i);

	int cnt = 0;
	for (int i = 2; i < n; i++)
		if ((x[i - 2] == x[i - 1] && x[i - 2] != x[i]) ||
			(y[i - 2] == y[i - 1] && y[i - 2] != y[i]))
			 cnt++;

	printf("%d", cnt);

	return 0;
}
