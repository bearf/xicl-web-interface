#include <cstdio>
#include <cstdlib>

int isgood (int x1, int y1, int x2, int y2, int x3, int y3);

int main(int argc, char* argv[])
{
	int v[100][2], count = 0, i, n;
	freopen("wire.in", "r", stdin);
	freopen("wire.out", "w", stdout);
	scanf("%d", &n);
	for( i = 0; i < n; i++){
		scanf("%d%d", &(v[i][0]), &(v[i][1]));
	}
	for(i = 1; i < n - 1; i++){
		if(isgood(v[i-1][0], v[i-1][1], v[i][0], v[i][1], v[i+1][0], v[i+1][1])){
			count++;
		}
	}
	printf("%d", count);
	return 0;
}
int isgood (int x1, int y1, int x2, int y2, int x3, int y3){
	if(((x1 == x2)&&(x2!=x3))||((y1==y2)&&(y2!=y3))){
		return 1;
	}else{
		return 0;
	}
}