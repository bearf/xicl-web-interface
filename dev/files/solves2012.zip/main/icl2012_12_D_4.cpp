#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <set>
#include <string>
#include <vector>

using namespace std;

#define forn(i,n) for (int i = 0; i < (n); i++)
#define forit(it,v) for (typeof((v).end()) it = (v).begin(); it != (v).end(); ++it)
#define sz(v) ((int)((v).size()))
#define eprintf(...) {fprintf(stderr,__VA_ARGS__); fflush(stderr);}
#define mp make_pair
typedef unsigned int LL;
typedef long long ll;
typedef pair<int, int> ii;

#define TASK "millenium"
const int maxn = 1<<23;

pair<int,LL> t[maxn];
int size=0;
int left[maxn],right[maxn];

pair<int,LL> get(LL l,LL r,int root,LL tleft,LL tright) {
	//eprintf("%d %d %d\n",tleft,tright,root);
	if(root==-1) return mp(-1,l);
	if(l==tleft&&tright==r) {
		return t[root];
	}
	LL ave = tleft+(tright-tleft)/2;
	if( r <= ave ) return get(l,r,left[root],tleft,ave);
	if( l >= ave ) return get(l,r,right[root],ave,tright);
	return  min(get(l,ave,left[root],tleft,ave),get(ave,r,right[root],ave,tright));
}

void modify(LL ind,LL val,int root,LL tleft,LL tright) {
	//eprLLf("%d %d %d\n",tleft,tright,root);
	LL ave = tleft+(tright-tleft)/2;
	if( tleft+1==tright) {
		t[root] = mp(val,ind);
		return ;
	}
	if(left[root]==-1) {
		t[size] = mp(-1,tleft); 
		left[root] = size++;
	}
	if(right[root]==-1) {
		t[size] = mp(-1,ave);
		right[root] = size++;
	}
	assert(size<maxn);
	if( ind < ave ) {
		modify(ind,val,left[root],tleft,ave);
	}else{
	
	modify(ind,val,right[root],ave,tright);
	}
	t[root] = min(get(tleft,ave,left[root],tleft,ave),get(ave,tright,right[root],ave,tright));	
}

LL x[maxn],y[maxn];
int p[maxn];

int cmpxy(int a,int b) {
	if(x[a] != x[b] ) return x[a] < x[b];
	return y[a] < y[b];
}

int main() {
	assert(freopen(TASK ".in", "r", stdin));
	assert(freopen(TASK ".out", "w", stdout));
	memset(left,-1,sizeof left);
	memset(right,-1,sizeof right);
	//memset(t,-1,sizeof t);
	int n,a,b;
	scanf("%d%d%d",&n,&a,&b);
	t[0] = mp(-1,a+1);
	size = 1;
	forn(i, n) {
		scanf("%u%u",&x[i],&y[i]);
		p[i] = i;
	}
	sort(p,p+n,cmpxy);
	int res = -1;
	forn(i, n) {
		LL la = max((ll)(y[p[i]] - ((ll)x[p[i]]-1)),(ll)a+1);
		LL ra = min((ll)y[p[i]] + (ll)((ll)x[p[i]]-1)+1,(ll)a+(ll)b+1);
		pair<int,LL> val = get(la,ra,0,a+1,a+b+1);
		//eprintf("%d %d\n",val.first,val.second);
		LL tt = max(x[p[i]],val.first+1u);
		res = max(res,(int)tt);
		modify(val.second,tt,0,a+1,a+b+1);
	}
	printf("%d\n",res);
	return 0;
}
