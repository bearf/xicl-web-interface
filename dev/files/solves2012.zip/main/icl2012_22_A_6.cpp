#include <fstream>
#include <algorithm>
#include <map>
#include <vector>
#include <set>
using namespace std;
struct snd
{
	int x, y;
};
bool operator <(const snd a, const snd b)
{
	return a.x<b.x||a.x==b.x&&a.y<b.y;
}
int main()
{
	int n,k;
	ifstream cin("bricks.in");
	ofstream cout("bricks.out");
	cin>>n>>k;
	set <snd> st;
	snd buf,buf2;
	int q;
	set<snd>::iterator pos=0;
	for (int i=0;i<k;i++)
	{
		cin>>buf.x>>buf.y;
		buf2=buf;
		q=0;
		buf2.y=buf.y+1;
		pos=st.find(buf2);
		if (!pos._Ptr->_Isnil)
			q++;
		if (q)
		{
			buf2.y=buf.y;
			buf2.x=buf.x-1;
			pos=st.find(buf2);
			if (pos._Ptr->_Isnil)
				q++;
			if (q==2)
			{
				cout<<(i+1);
				return 0;
			}
		}
		q=0;
		buf2=buf;
		buf2.y=buf.y-1;
		pos=st.find(buf2);
		if (!pos._Ptr->_Isnil)
			q++;
		if (q)
		{
			buf2.y=buf.y-1;
			buf2.x=buf.x-1;
			pos=st.find(buf2);
			if (pos._Ptr->_Isnil)
				q++;
			if (q==2)
			{
				cout<<(i+1);
				return 0;
			}
		}
		st.insert(buf);
	}
	cin.close();
	cout<<(-1);
	cout.close();
	return 0;
}