#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair <int, int> pii;

#define x first
#define y second
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define sz(a) (int)((a).size())
#define debug(...) fprintf(stderr, __VA_ARGS__)

#define problemname "islands"

#define maxn 100010

struct tri {
  int x;
  int y;
  int z;

 public:
    tri() {}
    tri(int _x, int _y, int _z) : x(_x), y(_y), z(_z) {} 
};

int dx[4] = {-1, 1, 0, 0};
int dy[4] = {0, 0, -1, 1};

int num[2 * maxn];
int was[2 * maxn];
char s[maxn];
int n, m;

int x_fi, y_fi;

int encode(int x, int y, int z) {
    return (y * m + x) * 2 + z;
}

tri decode(int p) {
    tri res;
    res.z = p & 1;
    p >>= 1;
    res.y = p / m;
    p %= m;
    res.x = p;
    return res;
}

void dfs(int x, int y, int z) {
    int q = encode(x, y, z), q0 = q - (q & 1);
    if (was[q] || num[q0] - z < 0) {
        return;
    }
    was[q] = 1;

    if (x == x_fi && y == y_fi) {
        puts("YES");
        exit(0);
    }

    for (int i = 0; i < 4; i++) {
        int xx = x + dx[i],
            yy = y + dy[i];

        if (xx < 0 || yy < 0 || xx >= m || yy >= n) {
            continue;
        }

        if (num[q0] - z > 0) {
            dfs(xx, yy, 0);
        }
        dfs(xx, yy, 1);
    }
}


int main() {
    freopen(problemname".in", "r", stdin);
    freopen(problemname".out", "w", stdout);

    

    scanf("%d %d", &n, &m);
    for (int i = 0; i < n; i++) {
        scanf("%s", s);
        for (int j = 0; j < m; j++) {
            num[encode(j, i, 0)] = s[j] - '0';
        }
    }

    int x_st, y_st;
    scanf("%d %d %d %d", &y_st, &x_st, &y_fi, &x_fi), y_st--, x_st--, x_fi--, y_fi--;
    dfs(x_st, y_st, 0);

    puts("NO");

    return 0;
}
