import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {

	void _solve() throws Exception {
		int n = nextInt();
		int[] a = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = nextAngle();
			System.out.println(a[i]);
		}
		boolean[] winner = new boolean[n];
		Arrays.fill(winner, true);

		for (int i = 0; i < n; i++) {
			int x = a[i];
			if (sum(PI - x + 1, x - 1) != 0) {
				winner[i] = false;
			}
			add(x);
		}
		
		Arrays.fill(tree, 0);
		for (int i = n - 1; i >= 0; i--) {
			int x = PI - a[i];
			if (sum(PI - x + 1, x - 1) != 0) {
				winner[i] = false;
			}
			add(x);
		}

		int nwinners = 0;
		for (int i = 0; i < n; i++) {
			if (winner[i]) {
				++nwinners;				
			}
		}
		out.println(nwinners);
		boolean first = true;
		for (int i = 0; i < n; i++) {
			if (winner[i]) {				
				if (first) {
					first = false;
				} else {
					out.print(" ");
				}
				out.print(i + 1);			
			}
		}
		out.println();
	}

	final static int N = 3150000; // 6 digits
	final static int PI = 3141592;
	// 3.141592653589793

	int[] tree = new int[N];
	private void add(int pos) {
		while (pos < N) {
			tree[pos]++;
			pos |= pos + 1;
		}
	}

	private int sum(int l, int r) {
		if (l > r) return 0;
		return sum(r) - sum(l - 1);
	}

	private int sum(int r) {
		int res = 0;
		while (r >= 0) {
			res += tree[r];
			r = (r & (r + 1)) - 1;
		}
		return res;
	}

	private int nextAngle() {
		String s = nextToken();
		int i = s.indexOf('.');
		if (i < 0) {			
			s = i + ".";
			i = s.indexOf('.');
		}
		int z = s.length() - i - 1;
		while (z < 6) {
			s = s + "0";
			++z;
		}
		i = s.indexOf('.');
		s = s.substring(0, i) + s.substring(i + 1);
		return Integer.parseInt(s);
	}

	BufferedReader in;
	StringTokenizer stringTokenizer;
	PrintWriter out;
	
	long nextLong() {
		return Long.parseLong(nextToken());
	}
	
	double nextDouble() {
		return Double.parseDouble(nextToken());
	}
	
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	
	String nextToken() {
		while (!stringTokenizer.hasMoreTokens()) {
			String line = null;
			try {
				line = in.readLine();
			} catch (IOException e) {
				NOO(e);
			}
			if (line == null) {
				return null;
			} else {
				stringTokenizer = new StringTokenizer(line);
			}
		}
		return stringTokenizer.nextToken();
	}
	
	public void run() {
		try {
			_solve();
		} catch (Exception e) {
			NOO(e);
		} finally {
			out.close();
		}
	}
	
	void NOO(Exception e) {
		e.printStackTrace();
		System.exit(42);
	}
	
	public Solution(String name) {
		try {
			in = new BufferedReader(new FileReader(name + ".in"));
			stringTokenizer = new StringTokenizer("");
			out = new PrintWriter(new FileWriter(name + ".out"));
		} catch (Exception e) {
			NOO(e);
		}
	}
	
	public static void main(String[] args) {
		new Solution("race").run();
	}

}
