import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.StringTokenizer;

public class Solution implements Runnable {
	BufferedReader br;
	StringTokenizer in;
	PrintWriter out;
	int PODGON = 1000000;

	String nextToken() throws IOException {
		while (in == null || !in.hasMoreTokens())
			in = new StringTokenizer(br.readLine());
		return in.nextToken();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Solution().run();
	}

	public int norm(int a, int mod) {
		a %= mod;
		a += mod;
		a %= mod;
		return a;
	}

	public void solve() throws IOException {
		BigInteger a = new BigInteger(nextToken()), b = new BigInteger(
				nextToken());
		int ia = a.intValue();
		int ib = b.intValue();
		int k = b.toString().length();
		BigInteger m = BigInteger.TEN.pow(k).subtract(a);
		int im = m.intValue();
		int in = 1;
		int left = (ia * ib * 10) % im;
		BigInteger x = BigInteger.ZERO;
		while (true) {
			while (norm(left - ib, im) != 0 && in < PODGON + 2) {
				in++;
				left *= 10;
				left = norm(left, im);
			}
			if (in > PODGON)
				break;
			x = b.multiply(
					a.multiply(BigInteger.TEN.pow(in)).subtract(BigInteger.ONE))
					.divide(m);
			if (x.toString().length() == in)
				break;
		}
		if (in > PODGON) {
			out.print(-1);
			return;
		}
		out.print(b);
		out.print(x);
	}

	@Override
	public void run() {
		try {
			//br = new BufferedReader(new InputStreamReader(System.in));
			//out = new PrintWriter(System.out);
			br = new BufferedReader(new FileReader("numbers.in"));
			out = new PrintWriter("numbers.out");
			solve();
			br.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
