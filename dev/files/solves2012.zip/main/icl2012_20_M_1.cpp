#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <string>
#include <string.h>

#define li unsigned long long
#define pb push_back
#define mp make_pair

#define INF (1000 * 1000 * 1000)
#define EPS (1e-9) 

using namespace std;

int n, m;

li dp(int n, int m){
	//cerr << n << ' ' << m << endl;
	
	if (m == 0){
		return 0;
	}

	if (m == 1){
		if (n == 1) return 1; else return 0;
	}

	if (n == 1){
		return m;
	}

	//cerr << "H" << endl;

	if (n == 0) return 1;
	if (n % 2 == 0){
		return dp(n / 2, m - 1);
	} else {
		//cerr << n << ' ' << m << endl;
		li k = n / 2;
		if (k % 2 == 0){
			return 2 * dp(k / 2, m - 2) + dp(k / 2 + 1, m - 2);
		} else {
			return 2 * dp((k + 1) / 2, m - 2) + dp((k - 1) / 2, m - 2);
		}
	}
}

void solve(){
	cin >> m >> n;
	cout << dp(n, m) << endl;
}

int main(){
	freopen("weights.in", "r", stdin);
	freopen("weights.out", "w", stdout);
	int n, i;
	cin >> n;
	for (i = 0; i < n; i++) solve();
}