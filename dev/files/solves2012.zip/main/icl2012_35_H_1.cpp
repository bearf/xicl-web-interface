#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cassert>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <string>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define _(a, b) memset(a, b, sizeof(a))

typedef long long lint;
typedef unsigned long long ull;

const int INF = 1000000000;
const lint LINF = 4000000000000000000ll;
const double eps = 1e-9;

void prepare(string file)
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#else
	freopen((file + ".in").c_str(), "r", stdin);
	freopen((file + ".out").c_str(), "w", stdout);
#endif
}

vector<int> getdiv(int x)
{
	vector<int> ret;

	int sq = (int)(sqrt(x + 0.1)) + 1;
	for (int i = 1; i <= sq; i++)
	{
		if (x % i == 0)
		{
			ret.pb(i);
			ret.pb(x / i);
		}
	}

	return ret;
}

int n, k;
int p[100005];

lint a, b;
lint fun2(lint x)
{
	lint aa = a / x;
	lint bb = b / x;
	return aa * bb + aa + bb + 1;
}

lint fun(lint x)
{
	lint aa = a / x;
	lint bb = b / x;
	return aa * bb + aa + bb;
}

lint gcd(lint a, lint b)
{
	if (b != 0)
		return gcd(b, a % b);
	else
		return a;
}

bool solve()
{
	scanf("%d%d", &n, &k);
	for (int i = 0; i < k; i++)
		scanf("%d", &p[i]);

	a = p[0] - 1;
	b = n - p[k - 1];

	if (k == 1)
	{
		lint ans = 0ll;
		int prev = 1;

		int mx = (int)max(a, b);
		while (prev <= mx)
		{
			lint base = fun(prev);

			lint l = prev, r = mx;

			if (fun(l + 1) == base)
			{

				while (r - l > 1)
				{
					lint c = (l + r) >> 1;
					if (fun(c) == base)
						l = c;
					else
						r = c;
				}

				if (fun(r) == base)
					l = r;

			}

			ans += (l - prev + 1ll) * base;

			prev = l + 1;
		}
		
		printf("%lld\n", ans + 1);
	}
	else
	{
		lint g = p[1] - p[0];
		for (int i = 2; i < k; i++)
			g = gcd(g, p[i] - p[i - 1]);

		vector<int> div = getdiv(g);
		sort(div.begin(), div.end());
		div.resize(unique(div.begin(), div.end()) - div.begin());

		lint ans = 0ll;
		for (int i = 0; i < div.size(); i++)
			ans += fun2(div[i]);

		printf("%lld\n", ans);
	}
	
	return false;
}

int main()
{
	prepare("trees");
	while (solve());
	return false;
}