#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <stack>
#include <string>
#include <sstream>
#include <cstring>
#include <cmath>
#include <ctime>
#include <numeric>

using namespace std;

#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define re return
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int) (x).size())
#define sqr(x) ((x) * (x))
#define sqrt(x) sqrt(abs(x))
#define rep(i, n) for (int i= 0; i < (n); i++)
#define rrep(i, n) for (int i = (n) - 1; i >= 0; i--)
#define re return
#define y0 y2369
#define y1 y347256
#define fill(x, y) memset(x, y, sizeof(x))

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef vector<string> vs;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef double D;
typedef long double LD;

template <class T> T abs(T x) { re x > 0 ? x : -x;}

#define FILENAME "millenium"

int n;

map<int, int> m;

vi v;

int main() {
	freopen(FILENAME".in", "r", stdin);
	freopen(FILENAME".out", "w", stdout);
	
	ll a, b;
	cin >> n >> a >> b;
	rep(i, n) {
		int x, y;
		scanf("%d%d", &x, &y);
		m[x]++;
		v.pb(x);		
	}

	sort(all(v));
	v.resize(unique(all(v)) - v.begin());
	rep(i, sz(v) - 1) {
		ll d = v[i + 1] - v[i];
		ll cur = m[v[i]];
		m[v[i + 1]] += max(0ll, (ll) cur - d * b);
	}
	cout << v[sz(v) - 1] + (m[v[sz(v) - 1]] + b - 1) / b - 1;
	
	return 0;
}
                                 