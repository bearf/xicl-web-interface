#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <stack>
#include <string>
#include <sstream>
#include <cstring>
#include <cmath>
#include <ctime>
#include <numeric>

using namespace std;

#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define re return
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int) (x).size())
#define sqr(x) ((x) * (x))
#define sqrt(x) sqrt(abs(x))
#define rep(i, n) for (int i= 0; i < (n); i++)
#define rrep(i, n) for (int i = (n) - 1; i >= 0; i--)
#define re return
#define y0 y2369
#define y1 y347256
#define fill(x, y) memset(x, y, sizeof(x))

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef vector<string> vs;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef double D;
typedef long double LD;

template <class T> T abs(T x) { re x > 0 ? x : -x;}

#define FILENAME "bricks"

int n;
int m;

set<ii> s;

int check(int a, int b) {
//	cout << a << ' ' << b << ' ' << (s.find(mp(a + 1, b)) != s.end()) << ' ' << (s.find(mp(a + 1, b + 1)) != s.end()) << ' ' << (s.find(mp(a, b)) != s.end()) << endl;
	if (a < b || a < 0 || b < 0 || s.find(mp(a, b)) != s.end())
		re 1;
	if (s.find(mp(a + 1, b)) != s.end() && s.find(mp(a + 1, b + 1)) != s.end())
		re 0;
	re 1;	
}

int main() {
	freopen(FILENAME".in", "r", stdin);
	freopen(FILENAME".out", "w", stdout);

	cin >> n >> m;
	rep(i, m) {
		int a, b;
		scanf("%d%d", &a, &b);
		a--;
		b--;
		s.insert(mp(a, b));
//		cout << "! " << a << ' ' << b << endl;
		if (!check(a - 1, b - 1) || !check(a - 1, b)) {
			cout << i + 1 << endl;
			re 0;
		}	
	}
	cout << - 1 << endl;
	
	return 0;
}
