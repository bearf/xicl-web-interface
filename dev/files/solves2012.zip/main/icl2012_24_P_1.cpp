#include <stdio.h>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

#define mp make_pair
#define pb push_back

typedef long long li;
typedef double ld;

#define FILE "wire"
void solve();
int main()
{
#ifdef _DEBUG
	freopen ("in.txt", "r", stdin);
	cout<<FILE<<endl;
#else
	freopen (FILE ".in", "r", stdin);
	freopen (FILE ".out", "w", stdout);
#endif
	int t=1;
	while (t--)
		solve();
	return 0;
}

//#define int li

int n;
pair <int, int> a[200];

void solve()
{
	cin>>n;
	for (int i=0; i<n; i++)
		cin>>a[i].first>>a[i].second;
	int ans=0;
	for (int i=0; i<n-2; i++)
	{
		pair <int, int> cur1=mp( a[i+2].first-a[i+1].first, a[i+2].second-a[i+1].second );
		pair <int, int> cur2=mp( a[i+1].first-a[i].first, a[i+1].second-a[i].second );
		if ( cur1.first*cur2.first+cur1.second*cur2.second==0 )
			ans++;
	}
	cout<<ans;
}