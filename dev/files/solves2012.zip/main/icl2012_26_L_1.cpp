#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <cstdio>
#include <cmath>

using namespace std;
const int N = 110000;
const double polpi = acos(0.0), eps = 1e-9; 
int n, is[N], cnt;
double a[N];
double cur;

int main() {
	freopen("race.in", "r", stdin);
	freopen("race.out", "w", stdout);
	cin >> n;
	for (int i = 0; i < n; i++) scanf("%lf", &a[i]);
	cur = polpi;
	for (int i = 0; i < n; i++) {
		if (a[i] > polpi && abs(polpi - a[i]) < cur + eps) {
			is[i] = 1;
			cnt++;
		}
		if (abs(polpi - a[i]) < cur + eps) cur = abs(polpi - a[i]);
	}
	cur = polpi;
	for (int i = n - 1; i >= 0; i--) {
		if (a[i] < polpi && abs(polpi - a[i]) < cur + eps) {
			is[i] = 1;
			cnt++;
		}
		if (abs(polpi - a[i]) < cur + eps) cur = abs(polpi - a[i]);
	}
	cout << cnt << endl;
	for (int i = 0; i < n; i++)
		if (is[i]) printf("%d ", i + 1);
}