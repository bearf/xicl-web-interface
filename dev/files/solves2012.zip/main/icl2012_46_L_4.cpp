#include <iostream>
#include <algorithm>
#include <cstdio>
#include <set>
#include <map>
#include <vector>

using namespace std;

double pi = 3.141592653;
bool flag[100001];

struct st{
	int index;
	bool left;
	double otk;
} a[100001];

bool cmp(st arg1, st arg2)
{
	if (arg1.otk < arg2.otk)
		return true;
	else if (arg1.otk > arg2.otk)
		return false;
	else if (arg1.left)
		return arg1.index > arg2.index;	
	else
		return arg1.index < arg2.index;	
}

int main() {
	freopen("race.in", "r", stdin);
	freopen("race.out", "w", stdout);
	
	int n;
	cin >> n;

	for (int i=0; i<n; i++) {
		double x;
		cin >> x;
		a[i].index = i;
		a[i].otk = pi/2 - x > 0 ? pi/2 - x : -pi/2 + x;
		a[i].left = (x - pi/2) > 0;
	}

	sort(a, a+n, cmp);
	
	
	int i_left, i_right, count = 1;
	i_left = i_right = a[0].index;
	flag[a[0].index] = true;

	for (int k=1; k<n; k++)
		if (a[k].left) {
			if (a[k].index < i_left){
				i_left = a[k].index;
				flag[a[k].index] = true;
				count++;
			}
		} else {
			if (a[k].index > i_right){
				i_right = a[k].index;
				flag[a[k].index] = true;
				count++;
			}
		}

	cout << count << endl;

	for (int i=0; i<n; i++)
		if (flag[i])
			cout << i +1<< ' ';
	
	return 0;
}