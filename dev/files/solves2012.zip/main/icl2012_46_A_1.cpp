#include <iostream>
#include <algorithm>
#include <cstdio>
#include <set>
#include <map>

using namespace std;

int main() {
	freopen("bricks.in", "r", stdin);
	freopen("bricks.out", "w", stdout);
	int n, k;
	
	cin >> n >> k;

	map<int, set<int> > row;

	for (int i=1; i<=k; i++) {
		int x, y;
		cin >> x >> y;
		row[x].insert(y);
		if (
			x != 1 && (
			y == 1 && row[x].count(2)
				&& (!row[x-1].count(1))
			|| y>1 && y<x
				&& ( row[x].count(y-1) 
							&& (!row[x-1].count(y-1))
					|| row[x].count(y+1)
							&& (!row[x-1].count(y))
				)
			|| y==x && row[x].count(x-1)
				&& (!row[x-1].count(x-1))
			)
		) {
			cout << i;
			return 0;
		}
	}

	cout << "-1";

	return 0;
}