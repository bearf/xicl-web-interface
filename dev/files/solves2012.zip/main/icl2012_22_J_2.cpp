#include <fstream>
#include <vector>
#include <deque>
#include <string>
using namespace std;
const int dx[]={0,0,-1,1};
const int dy[]={-1,1,0,0};
struct spos
{
	int x,y;
	int p;
};
int n,m;
vector < vector <bool> > us[10];
vector <string> a;
bool ex(spos b)
{
	return b.x>=0&&b.y>=0&&b.x<n&&b.y<m;
}
void main()
{
	ifstream cin("islands.in");
	cin>>n>>m;
	for (int i=0;i<=9;i++)
		us[i].resize(n);
	a.resize(n);
	for (int i=0;i<n;i++)
	{
		for (int j=0;j<=9;j++)
			us[j][i].resize(m);
		cin>>a[i];
	}
	int x1,y1,x2,y2;
	cin>>x1>>y1>>x2>>y2;
	x1--;
	y1--;
	x2--;
	y2--;
	spos buf;
	buf.x=x1;
	buf.y=y1;
	buf.p=a[x1][y1]-'0';
	deque <spos> st;
	st.push_back(buf);
	spos b2;
	int kk;
	while (!st.empty())
	{
		buf=st.front();
		us[buf.p][buf.x][buf.y]=1;
		st.pop_front();
		for (int i=0;i<4;i++)
		{
			b2=buf;
			b2.x+=dx[i];
			b2.y+=dy[i];
			if (!ex(b2))
				continue;
			kk=a[b2.x][b2.y]-'0'-1;
			for (int j=0;j<=kk;j++)
				if (!us[j][b2.x][b2.y])
				{
					us[j][b2.x][b2.y]=1;
					b2.p=j;
					st.push_back(b2);
				}
			if (buf.p>0)
			{
				kk=a[b2.x][b2.y]-'0';
				if (!us[kk][b2.x][b2.y])
				{
					us[kk][b2.x][b2.y]=1;
					b2.p=kk;
					st.push_back(b2);
				}
			}
		}
	}
	cin.close();
	ofstream cout("islands.out");
	for (int j=1;j<=9;j++)
		us[0][x2][y2]=us[0][x2][y2]||us[j][x2][y2];
	if (us[0][x2][y2])
		cout<<"YES";
	else
		cout<<"NO";
	cout.close();
}