#include <algorithm>
#include <iostream>
#include <vector>
#include <set>
#include <cmath>
#include <string>
using namespace std;
typedef pair <int, int> pii;
typedef long long ll;
//ll a, b;
//ll tt[12] = {1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000, 10000000000, 100000000000};
int n, m;
vector < vector < int > > mp;
vector < vector < vector <int> > > used;
pii st, en;
const int di[4] = {-1, 0, 1, 0}; const int dj[4] = {0, 1, 0, -1};
bool eq(pii a, pii b){
	return a.first == b.first && a.second == b.second;
}
void dfs(int v, int u, int k){
	used[v][u][k] = true;
	if (eq(pii(v, u), en)) {
		cout << "YES";
		exit(0);
	}
	for (int i = 0; i < 4; i++){
		int vi = v + di[i], vj = u + dj[i];
		if(vi < 0 || vi >= n || vj < 0 || vj >= m) continue;
		if (k != 0)
			if (!used[vi][vj][mp[vi][vj]])
				dfs(vi, vj, mp[vi][vj]);
		if (mp[vi][vj] != 0)
			if (!used[vi][vj][mp[vi][vj] - 1])
				dfs(vi, vj, mp[vi][vj] - 1);
	}
}
int main(){
	freopen("islands.in", "r", stdin); freopen("islands.out", "w", stdout);
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	cin >> n >> m;
	mp.resize(n, vector <int> (m));
	used.resize(n, vector < vector <int> > (m, vector <int> (10)));
	for (int i = 0; i < n; i++){
		string s;
		cin >> s;
		for (int j = 0; j < m; j++)
			mp[i][j] = s[j] - '0';
	}
	cin >> st.first >> st.second; st.first--;st.second--;
	cin >> en.first >> en.second; en.first--;en.second--;
	dfs(st.first, st.second, mp[st.first][st.second]);
	cout << "NO";
	return 0;
}
