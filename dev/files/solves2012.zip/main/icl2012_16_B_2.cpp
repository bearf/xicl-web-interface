#include <iostream>
#include <sstream>
#include <stdio.h>
#include <cassert>
#include <memory.h>
#include <math.h>
#include <time.h>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <bitset>

using namespace std;

#define mp make_pair
#define pb push_back
#define all(a) (a).begin(),(a).end()
#define _(a,b) memset((a),b,sizeof(a))
#define sz(a) ((int)(a).size())

typedef long long lint;
typedef unsigned long long ull;
typedef pair < int , int > pii;

const int INF = 1000000000;
const lint LINF = 4000000000000000000LL;
const double eps = 1e-9;

void prepare(string s)
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
#else
	freopen((s + ".in").c_str(),"r",stdin);
	freopen((s + ".out").c_str(),"w",stdout);
#endif
}

struct Vec
{
	string s;
	int x,y;
	bool type;

	Vec(){}
	Vec(string _s,int _x,int _y,bool t)
	{
		type = t;
		s = _s;
		x = _x;
		y = _y;
	}

	bool operator > (Vec & oth)
	{
		return s > oth.s;
	}
};

struct Box
{
	int x0,y0,x1,y1;
	
	Box(){}
	Box(int a,int b,int c,int d)
	{
		x0 = a;
		y0 = b;
		x1 = c;
		y1 = d;
	}

	bool in(int x,int y)
	{
		return x0 <= x && x < x1 && y0 <= y && y < y1;
	}

	int sq()
	{
		return (x1 - x0) * (y1 - y0);
	}
};

const int nmax = 35;
int n,m;
int a[nmax][nmax];

int X[nmax * nmax];
int Y[nmax * nmax];

int ans[nmax * nmax];

Box bx[nmax][nmax];
string Empty;

void read()
{
	scanf("%d%d",&n,&m);
	for (int i = 0; i < n; i ++)
	{
		for (int j = 0; j < m; j ++)
		{
			scanf("%d",&a[i][j]);
			X[a[i][j] - 1] = i;
			Y[a[i][j] - 1] = j;
			a[i][j] --;
		}
	}
	for (int i = 0; i < n; i ++)
	{
		for (int j = 0; j < m; j ++)
		{
			Empty.pb('0');
		}
	}
}

string getHor(int x,int y,int N,int M)
{
	string ret = Empty;
	for (; y < M; y ++)
	{
		ret[a[x - 1][y]] = '1';
		ret[a[x][y]] = '1';
	}
	return ret;
}

string getVert(int x,int y,int N,int M)
{
	string ret = Empty;
	for (; x < N; x ++)
	{
		ret[a[x][y]] = '1';
		ret[a[x][y - 1]] = '1';
	}
	return ret;
}

bool solve()
{
	read();
	Box init = Box(0, 0, n, m);
	for (int i = 0; i < n; i ++)
	{
		for (int j = 0; j < m; j ++)
		{
			bx[i][j] = init;
		}
	}
	int T = 0;
	for (int it = 0; it < n * m; it ++)
	{
		int x = X[it];
		int y = Y[it];	
		
		while (bx[x][y].sq() != 1)
		{
			Box curBox = bx[x][y];
			Vec bst,cur;
			bst.s = Empty;
			int nx,ny;
			nx = curBox.x0;
			for (ny = y; ny <= y + 1; ny ++)
			{
				if (ny != curBox.y0 && ny < curBox.y1)
				{
					cur = Vec(getVert(nx,ny,curBox.x1,curBox.y1)
						,nx,ny,false);
					if (cur > bst)
					{
						bst = cur;
					}
				}
			}
			ny = curBox.y0;
			for (nx = x; nx <= x + 1; nx ++)
			{
				if (nx != curBox.x0 && nx < curBox.x1)
				{
					cur = Vec(getHor(nx,ny,curBox.x1,curBox.y1),
						nx,ny,true);
					if (cur > bst)
					{
						bst = cur;
					}
				}
			}
			Box A,B;
			A = curBox;
			B = curBox;
			if (bst.type == 0)
			{
				A.y1 = bst.y;
				B.y0 = bst.y;
			}
			else
			{
				A.x1 = bst.x;
				B.x0 = bst.x;
			}
			for (int i = curBox.x0; i < curBox.x1; i ++)
			{
				for (int j = curBox.y0; j < curBox.y1; j ++)
				{
					if (A.in(i,j))
						bx[i][j] = A;
					else
						bx[i][j] = B;
				}
			}

			T++;
		}
		ans[it] = T;
	}
	for (int i = 0; i < n * m; i ++)
	{
		if (i) printf(" ");
		printf("%d",ans[i]);
	}
	printf("\n");
	return false;
}

int main()
{
	prepare("cuts");
	while (solve());
	return 0;
}