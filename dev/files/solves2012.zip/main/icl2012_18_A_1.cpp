#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair <int, int> pii;

#define x first
#define y second
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define sz(a) (int)((a).size())
#define debug(...) fprintf(stderr, __VA_ARGS__)

#define problemname "bricks"

int n, k;
map <pii, int> cnt;

int inc(int x, int y) {
    if (x < 0 || y < 0 || x > y) return 0;
//    debug("%d %d\n", x, y);

    int cur = cnt[pii(x, y)] + 1;
    if (cur == 0) {
        return 0;
    }
    if (cur == 2) return 1;
    cnt[pii(x, y)] = cur;
    return 0;
}

int main() {
    freopen(problemname".in", "r", stdin);
    freopen(problemname".out", "w", stdout);

    scanf("%d %d", &n, &k);
    for (int i = 0; i < k; i++) {
        int x, y;
        scanf("%d %d", &y, &x), x--, y--;

        cnt[pii(x, y)] = -1;
        if (inc(x - 1, y - 1) || inc(x, y - 1)) {
            printf("%d\n", i + 1);
            return 0;
        }
    }
    puts("-1");

    return 0;
}
