#include <iostream>
#include <sstream>
#include <stdio.h>
#include <cassert>
#include <memory.h>
#include <math.h>
#include <time.h>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <bitset>

using namespace std;

#define mp make_pair
#define pb push_back
#define all(a) (a).begin(),(a).end()
#define _(a,b) memset((a),b,sizeof(a))
#define sz(a) ((int)(a).size())

typedef long long lint;
typedef unsigned long long ull;
typedef pair < int , int > pii;

const int INF = 1000000000;
const lint LINF = 4000000000000000000LL;
const double eps = 1e-9;

void prepare(string s)
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
#else
	freopen((s + ".in").c_str(),"r",stdin);
	freopen((s + ".out").c_str(),"w",stdout);
#endif
}

const int maxn = 100100;

struct Vec
{
	int x, y;
	Vec(){}
	bool operator < (const Vec &v) const
	{
		return y > v.y;
	}
	void read()
	{
		scanf("%d%d", &y, &x);
	}
};

int n, a, b;
Vec p[maxn];

void read()
{
	scanf("%d%d%d", &n, &a, &b);
	for (int i = 0; i < n; i++)
		p[i].read();
}

bool solve()
{
	read();
	sort(p, p + n);
	int mx = 0;
	for (int i = 0; i < n; i++)
	{
		mx = max(mx, p[i].y + i / b);
	}
	printf("%d\n", mx);
	return false;
}

int main()
{
	prepare("millenium");
	while (solve());
	return 0;
}