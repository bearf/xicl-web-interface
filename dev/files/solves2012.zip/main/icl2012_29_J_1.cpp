#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#include <map>


#pragma comment(linker,"/STACK:146000000")


const int dx[] = {0, 1, 0, -1};
const int dy[] = {1, 0, -1, 0};


using namespace std;


string mp[100146];
char s[100146];
vector<vector<vector<bool> > > dp;
pair<pair<int, int>, int> q[300146];
int n, m;


bool good(int x, int y)
{
	return x >= 0 && y >= 0 && x < n && y < m;
}


pair<pair<int, int>, int> trio(int a, int b, int c)
{
	return make_pair(make_pair(a, b), c);
}


int getUsed(int x, int y, int cor)
{
	return min(2, mp[x][y] - '0' + cor);
}


void bfs(int x, int y)
{
	fprintf(stderr, "asdf");
	int l = 0;
	int r = 0;
	q[r++] = trio(x, y, mp[x][y] - '0');
	dp[x][y][mp[x][y] - '0'] = true;
	while(l < r)
	{
		int x = q[l].first.first;
		int y = q[l].first.second;
		int used = q[l].second;
		l++;
		for(int i = 0; i < 4; i++)
		{
			int nx = x + dx[i];
			int ny = y + dy[i];
			if(!good(nx, ny))
				continue;
			if(used == 0)
			{
				int xxx = getUsed(nx, ny, -1);
				if(xxx < 0)
					continue;

				if(!dp[nx][ny][xxx])
				{
					dp[nx][ny][xxx] = true;
					q[r++] = trio(nx, ny, xxx);
				}
			}
			else
			{
				int xxx = getUsed(nx, ny, 0);
				if(xxx < 0)
					continue;
				if(!dp[nx][ny][xxx])
				{
					dp[nx][ny][xxx] = true;
					q[r++] = trio(nx, ny, xxx);
				}
			}
		}
	}
}


int main()
{
	freopen("islands.in","r",stdin);
	freopen("islands.out","w",stdout);
	scanf("%d%d", &n, &m);
	for(int i = 0; i < n; i++)
	{
		scanf("%s", s);
		mp[i] = string(s);
	}
	int x0, y0, x1, y1;
	scanf("%d%d%d%d", &x0, &y0, &x1, &y1);
	x0--;
	y0--;
	x1--;
	y1--;
	dp.resize(n);
	for(int i = 0; i < n; i++)
	{
		dp[i].resize(m);
		for(int j = 0; j < m; j++)
		{
		    dp[i][j].resize(3); 
		    for(int k = 0; k < 3; k++)
		    	dp[i][j][k] = false;
		}
	}
	bfs(x0, y0);
	for(int i = 0; i < 3; i++)
		if(dp[x1][y1][i])
		{
			printf("YES");
			return 0;
		}
	printf("NO");
}