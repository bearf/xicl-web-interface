#include <iostream>
#include <stdio.h>
#include <map>
#include <string>
#include <vector>

using namespace std;

struct pt{
	int x,y;
};

int main(){
	freopen("wire.in", "r", stdin);
	freopen("wire.out", "w", stdout);

	int n;
	cin >> n;

	int k = 0;

	pt a,b;

	cin >> a.x >> a.y >> b.x >> b.y;

	n-=2;

	for (int i = 0; i<n; i++){
		pt c;
		cin >> c.x >> c.y;

		int x1 = a.x - b.x;
		int x2 = c.x - b.x;
		int y1 = a.y - b.y;
		int y2 = c.y - b.y;

		if (x1*x2+y1*y2==0) k++;

		a = b;
		b = c;
	}

	cout << k;

	return 0;
}