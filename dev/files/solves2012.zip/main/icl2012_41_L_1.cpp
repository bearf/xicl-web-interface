#include <iostream>
#include <vector>
#include <cassert>
#include <set>
#include <cstdio>
#include <map>
#include <deque>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < int(n); ++i)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; --i)
#define all(a) a.begin(), a.end()
#define fs first
#define sc second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef long double ld;

const string filename("race");

const ld e = 1e-8;
const ld pi = 3.141592653589793238462643l;

int n;
ld a[200000];
ld up, down;
bool u, d;

bool checkup (ld a) {
	return !u || up < a + e;
}

bool checkdown (ld a) {
	return !d || pi - down < a + e;
}

int solve () {
	u = d = 0;
	int n;
	if (scanf("%d", &n) != 1)
		return 1;
	forn(i, n) {
		double buf;
		if (scanf("%lf", &buf) != 1)
			return 1;
		a[i] = buf;
	}
	vector <int> ans;
	ford(i, n) {
		if (a[i] > pi / 2) {
			//cerr << i << endl;
			if (!d || a[i] < down) {
				down = a[i];
				d = 1;
			}
		} else {
			if (checkup(a[i]) && checkdown(a[i]))
				ans.pb(i);
			if (checkup(a[i])) {
				up = a[i];
				u = 1;
			}
		}
	}
	u = d = 0;
	forn(i, n) {
		a[i] = pi - a[i];
		if (a[i] > pi / 2) {
			//cerr << i << endl;
			if (!d || a[i] < down) {
				down = a[i];
				d = 1;
			}
		} else {
			if (checkup(a[i]) && checkdown(a[i]))
				ans.pb(i);
			if (checkup(a[i])) {
				up = a[i];
				u = 1;
			}
		}
	}
	sort(all(ans));
	ans.erase(unique(all(ans)), ans.end());
	printf("%d\n", (int)ans.size());
	forn(i, ans.size())
		printf("%d ", ans[i] + 1);
	puts("");
	return 0;
}

int main () {
	#ifdef _LOCAL_MACHINE41
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
	while (!solve());
	#else
	freopen((filename + ".in").data(), "rt", stdin);
	freopen((filename + ".out").data(), "wt", stdout);
	solve();
	#endif
	return 0;
}
