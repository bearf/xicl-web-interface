#include <stdio.h>
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#include <math.h>

using namespace std;

#define pi 3.14159265358979323846

#define mp make_pair
#define pb push_back
#define all(a) a.begin(),a.end()

typedef long long li;
typedef double ld;

#define FILE "race"
void solve();
int main()
{
#ifdef _DEBUG
	freopen ("in.txt", "r", stdin);
	cout<<FILE<<endl;
#else
	freopen (FILE ".in", "r", stdin);
	freopen (FILE ".out", "w", stdout);
#endif
	int t=1;
	while (t--)
		solve();
	return 0;
}

//#define int li

int n, k;
vector< pair <ld, pair<int, int> > > a;

void solve()
{
	cin>>n;

	for(int i=0;i<n;i++)
	{
		ld cur;
		scanf("%lf",&cur);
		cur=pi-cur;
		if(cur<pi/2)
			a.push_back(mp(cur,mp(-1,i)));
		else
			a.push_back(mp(pi-cur,mp(1,i)));
	}
	sort(all(a));
	reverse(all(a));
	ld maxl=-1,minl=n,maxr=-1,minr=n;
	vector<int> res;
	for(int i=0;i<n;i++)
	{
		int cur=a[i].second.second;
		if(a[i].second.first==-1)
		{
			bool t=true;
			if(cur>minl || cur>minr)
				t=false;
			if(t)
				res.push_back(cur+1);
			if(cur>maxl)
				maxl=cur;
			if(cur<minl)
				minl=cur;
		}
		if(a[i].second.first==1)
		{
			bool t=true;
			if(cur<maxr && cur<maxl)
				t=false;
			if(t)
				res.push_back(cur+1);
			if(cur>maxr)
				maxr=cur;
			if(cur<minr)
				minr=cur;
		}
	}
	printf("%d\n",res.size());
	for(int i=0;i<res.size();i++)
	{
		printf("%d ",res[i]);
	}
}