#pragma comment(linker,"/STACK:256000000")
#include <iostream>
#include <vector>
#include <map>
using namespace std;
int main(){
	//freopen("1.txt","r",stdin);
	freopen("bricks.in","r",stdin);
	freopen("bricks.out","w",stdout);
	int n,k;
	cin>>n>>k;
	map<pair<int,int>,int> iz;
	map<pair<int,int>,int> p;
	for(int i=0;i<k;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		if(x!=1){
			if(y!=1){
				if(iz.count(make_pair(x-1,y-1)) && p.count(make_pair(x-1,y-1))==0){
					cout<<i+1<<endl;
					return 0;
				}
				else iz[make_pair(x-1,y-1)]=1;
			}
			if(x!=y){
				if(iz.count(make_pair(x-1,y))  && p.count(make_pair(x-1,y))==0){
					cout<<i+1<<endl;
					return 0;
				}
				else iz[make_pair(x-1,y)]=1;
			}
			p[make_pair(x,y)]=1;
		}
		else p[make_pair(x,y)]=1;


	}
	cout<<-1<<endl;
}




