#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <stack>
#include <string>
#include <sstream>
#include <cstring>
#include <cmath>
#include <ctime>
#include <numeric>

using namespace std;

#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define re return
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int) (x).size())
#define sqr(x) ((x) * (x))
#define sqrt(x) sqrt(abs(x))
#define rep(i, n) for (int i= 0; i < (n); i++)
#define rrep(i, n) for (int i = (n) - 1; i >= 0; i--)
#define re return
#define y0 y2369
#define y1 y347256
#define fill(x, y) memset(x, y, sizeof(x))

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef vector<string> vs;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef double D;
typedef long double LD;

template <class T> T abs(T x) { re x > 0 ? x : -x;}

#define FILENAME "islands"

int n;
int m;

string s;

vi a[100000];

const int dx[5] = {-1, 0, 0, 1, 0};
const int dy[5] = {0, -1, 1, 0, 0};

bool w[100000][5];

vii q;

int num(int x, int y) {
	re x * m + y;
}

int main() {
	freopen(FILENAME".in", "r", stdin);
	freopen(FILENAME".out", "w", stdout);

	cin >> n >> m;
	rep(i, n) {
		cin >> s;
		rep(j, m)
			a[i].pb(s[j] - '0');
	}

	int xa, ya;
	int xb, yb;
	cin >> xa >> ya;
	cin >> xb >> yb;
	
	xa--; ya--; xb--; yb--;
	//cerr << xa << ' ' << ya << ' ' << xb << ' ' << yb << endl;
	fill(w, false);
	rep(i, 5) {
		q.pb(mp(num(xa, ya), i));
		w[num(xa, ya)][i] = true;
	}
	

	rep(cur, sz(q)) {
		int x = q[cur].fi / m;
		int y = q[cur].fi % m;
		if (x == xb && y == yb) {
			cout << "YES" << endl;
			re 0;
		}
		int gom = q[cur].se;
		//cerr << x << ' ' << y << ' ' << gom << ' ' << a[x][y] << endl;
		rep(i, 4) {
			int X = x + dx[i];
			int Y = y + dy[i];
			if (X < 0 || X >= n || Y < 0 || Y >= m)
				continue;
			//by the bridge of the current isle
			if (a[x][y] >= 2 || (a[x][y] == 1 && gom != 4)) {
				if (!w[num(X, Y)][3 - i]) {
					w[num(X, Y)][3 - i] = true;
					q.pb(mp(num(X, Y), 3 - i));
				}
			}
			//by the bridge of the next isle
			if (a[X][Y] >= 2 || (a[X][Y] == 1 && gom != i)) {
				if (!w[num(X, Y)][4]) {
					w[num(X, Y)][4] = true;
					q.pb(mp(num(X, Y), 4));
				}
			}
		}
	}
	cout << "NO"<< endl;
	return 0;
}
