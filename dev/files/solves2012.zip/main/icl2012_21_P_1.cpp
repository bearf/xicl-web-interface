#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <map>
#include <set>

using namespace std;

#define FOR(i, a, b) for(int i = a; i < b; i++)
#define REP(i, n) FOR(i, 0, n)

typedef vector<int> VI;
typedef vector<VI> VVI;

struct xy {
	int x, y;
}a, b, c, d;

int vect(xy a1, xy a2) {
	return a1.x * a2.x + a1.y * a2.y;
}


int main() {
	freopen("wire.in", "r", stdin);
	freopen("wire.out", "w", stdout);
	int N, cnt = 0;
	cin >> N;
	if(N == 2) {
		cout << 0;
		return 0;
	}
	cin >> c.x >> c.y;
	cin >> d.x >> d.y; 
	a.x = d.x - c.x;
	a.y = d.y - c.y;
	for(int i = 0; i < N - 2; i++) {
		cin >> c.x >> c.y;
		b.x = c.x - d.x;
		b.y = c.y - d.y;
		if(vect(a, b) == 0)
			cnt++;
		a = b;
		d = c;
	}
	cout << cnt;
	return 0;
}