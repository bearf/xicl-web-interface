#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <algorithm>
#include <string>
#include <string.h>
#include <set>
#include <map>

using namespace std;

#define pb push_back
#define mp make_pair
#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)
#define ZERO(x) memset(x, 0, sizeof(x))
#define COPY(x,y) memcpy(x, y, sizeof(y))
#define SIZE(x) (int)x.size()

typedef long long int64;

#define TASK "race"

#define MAX 100010

set <double> u, d;

int n;
int w;

double pi = acos(-1.);

double ang[MAX];
int f[MAX];

double eps = 1e-9;

int main() {
	int i;
	vector <int> ans;
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
	scanf("%d", &n);
	fi(1, n) {
		scanf("%lf", &ang[i]);		
	}

	fi(1, n) {
		if (ang[i] > pi / 2) {
			if (SIZE(u) > 0 && *u.begin() < ang[i] - eps) {
				f[i] = 1;
			}
			if (SIZE(d) > 0 && *d.rbegin() > pi - ang[i] + eps) {
				f[i] = 1;
			}

			u.insert(ang[i]);
		} else {
			

			d.insert(ang[i]);
		}
	}

	u.clear();
	d.clear();

	fdi(n, 1) {
		if (ang[i] > pi / 2) {			

			u.insert(ang[i]);
		} else {			

			if (SIZE(u) > 0 && *u.begin() < pi - ang[i] - eps) {
				f[i] = 1;
			}
			if (SIZE(d) > 0 && *d.rbegin() > ang[i] + eps) {
				f[i] = 1;
			}

			d.insert(ang[i]);
		}
	}

	fi(1, n) {
		if (!f[i]) {
			ans.pb(i);
		}
	}

	printf("%d\n", SIZE(ans));

	fi(0, SIZE(ans) - 1) {
		printf("%d ", ans[i]);
	}

	return 0;
}