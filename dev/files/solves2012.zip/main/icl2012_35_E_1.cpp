#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cassert>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <string>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define _(a, b) memset(a, b, sizeof(a))

typedef long long lint;
typedef unsigned long long ull;

const int INF = 1000000000;
const lint LINF = 4000000000000000000ll;
const double eps = 1e-9;

void prepare(string file)
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#else
	freopen((file + ".in").c_str(), "r", stdin);
	freopen((file + ".out").c_str(), "w", stdout);
#endif
}

int m;
int k[10005], l[10005];

int a[10005];

const int shift = 1 << 14;
struct tree
{
	pair<int, int> a[shift << 1];

	tree()
	{
		for (int i = 0; i < shift + shift; i++)
			a[i] = mp(INF, INF);
	}

	void upd(int x, int val)
	{
		x += shift;
		a[x] = mp(val, x - shift);
		x >>= 1;
		while (x)
		{
			a[x] = min(a[x << 1], a[(x << 1) | 1]);
			x >>= 1;
		}
	}

	pair<int, int> getmin(int x, int l, int r, int tl, int tr)
	{
		if (tl > tr)
			return mp(INF, INF);

		if (l == tl && r == tr)
			return a[x];

		int mid = (l + r) >> 1;

		return min(getmin(x << 1, l, mid, tl, min(tr, mid)), getmin((x << 1) | 1, mid + 1, r, max(tl, mid + 1), tr));
	}

	pair<int, int> getmin(int l, int r)
	{
		return getmin(1, 0, shift - 1, l, r);
	}
};

tree rmq, rmqx;

bool solve()
{
	scanf("%d", &m);
	for (int i = 0; i < m; i++)
		scanf("%d", &k[i]);
	for (int i = 0; i < m; i++)
		scanf("%d", &l[i]);

	int minval = 0;
	a[0] = 0;
	for (int i = 0; i < m - 1; i++)
	{
		int val = l[i + 1] - l[i] - k[i + 1] + k[i];
		if (val % m != 0)
		{
			printf("-1\n");
			return false;
		}
		a[i + 1] = a[i] + val / m;
		minval = min(minval, a[i + 1]);
	}

	for (int i = 0; i < m; i++)
		a[i] -= minval;

	for (int i = 0; i < m; i++)
	{
		rmq.upd(i, k[i]);
		if (a[i] != 0)
			rmqx.upd(i, k[i]);
		else
			rmqx.upd(i, INF);
	}

	vector<int> ans;

	int dec = 0;
	while (true)
	{
		if (rmq.getmin(0, m - 1).first - dec < 0)
		{
			printf("-1\n");
			return false;
		}

		pair<int, int> cur = rmqx.getmin(0, m - 1);
		if (cur.first == INF)
			break;

		dec++;
		rmq.upd(cur.second, cur.first + m);

		a[cur.second]--;
		if (a[cur.second] != 0)
			rmqx.upd(cur.second, cur.first + m);
		else
			rmqx.upd(cur.second, INF);

		ans.pb(cur.second);
	}

	printf("%d\n", ans.size());
	for (int i = 0; i < ans.size(); i++)
		printf("%d ", ans[i] + 1);
	printf("\n");

	return false;
}

int main()
{
	prepare("changes");
	while (solve());
	return false;
}