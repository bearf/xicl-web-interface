#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>

using namespace std;

typedef long long ll;
typedef double ld;
typedef pair <int, int> pii;

#define x first
#define y second
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define sz(a) (int)((a).size())
#define debug(...) fprintf(stderr, __VA_ARGS__)

#define problemname "race"
int n;
pair<ld, int> p[1000000];
ld a[1000000];
const int sh = 1 << 19;
ld rmn[2 * sh + 20];
ld rmx[2 * sh + 20];


const ld eps = 1e-12;
void upd(int x, ld z) {
    x += sh;
    while (x >= 1) {
        rmn[x] = min(rmn[x], z);
        rmx[x] = max(rmx[x], z);
        x /= 2;
    }
}
ld get_min(int l, int r) {
    l += sh;
    r += sh;
    ld ans = 5;
    while (l <= r) {
        ans = min(ans, rmn[l]);
        ans = min(ans, rmn[r]);
        l = (l + 1) /2;
        r = (r - 1) /2;                                
    }
    return ans;
}
ld get_max(int l, int r) {
    l += sh;
    r += sh;
    ld ans = -5;
    while (l <= r) {
        ans = max(ans, rmx[l]);
        ans = max(ans, rmx[r]);
        l = (l + 1) /2;
        r = (r - 1) /2;                                
    }
    return ans;
}

int main() {
    freopen(problemname".in", "r", stdin);
    freopen(problemname".out", "w", stdout);
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        double x;
        scanf("%lf", &x);
        a[i] = x;
        p[i].x = fabs(M_PI / 2 - x);
        p[i].y = i;
    }
    for (int i = 0; i < 2* sh+ 10; i++) {
        rmn[i] = 5;
        rmx[i] = -5;
    }
    sort(p, p + n);
    vector<int> ans;
    for (int i = 0; i < n; i++) {
        bool add = true;
        ld zn1 = get_min(0, p[i].y);
        ld zn2 = get_max(p[i].y, n - 1);
//        cerr<<p[i].y<<" "<<zn1<<" "<<zn2<<endl;
        if (zn1 < a[p[i].y] - eps) {
            add = false;
        }
        if (zn2 > a[p[i].y] + eps) {
            add = false;
        }
        upd(p[i].y, a[p[i].y]);
        if (add) {
            ans.pb(p[i].y);
        }
    }
    sort(all(ans));
    printf("%d\n", sz(ans));
    for (int i = 0; i < sz(ans); i++) {
        printf("%d%c", ans[i] + 1, " \n"[i == sz(ans) - 1]);
    }
    return 0;
}
