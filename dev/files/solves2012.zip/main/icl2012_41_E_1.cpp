#include <iostream>
#include <vector>
#include <cassert>
#include <set>
#include <cstdio>
#include <map>
#include <deque>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < int(n); ++i)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; --i)
#define all(a) a.begin(), a.end()
#define fs first
#define sc second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef long double ld;

const string filename("changes");

int a[20000], b[20000], c[20000];
bool u[20000];

int solve () {
	memset(u, 0, sizeof u);
	int n;
	if (!(cin >> n)) {
		return 1;
	}
	forn (i, n) {
		cin >> a[i];
		c[i] = max(n - 2, a[i]);
	}
	set<pair<int, int> > s;
	forn (i, n) {
		cin >> b[i];
		s.insert(mp(c[i] - b[i], i));
	}
//	forn (i, n) {
//		cerr << a[i] << ' ' << b[i] << ' ' << c[i] << endl;
//	}
//	for (typeof s.begin() i = s.begin(); i != s.end(); i++) {
//		cerr << i->fs << ' '  << i->sc << endl;
//	}
//	cerr << endl;
	int q = n;
	vector<int> Q(0);
	for (int i = 0; q; i++) {
		set<pair<int, int> >::iterator f = s.begin();
		int fs = f->fs, sc = f->sc;
//		cerr << fs << ' ' << sc << endl;
		if (fs >= i) {

			for (; f != s.end(); f++) {
				if (c[f->sc] - a[f->sc] != f->fs - i) {				
					puts("-1");
					return 0;
				}
			}

			printf("%d\n", Q.size());
			ford (e, Q.size()) {
				printf("%d ", Q[e] + 1);
			}
			puts("");
			return 0;
		}
		Q.pb(sc);
		if (!u[sc]) {
			u[sc] = 1;
			q--;
		}

		s.erase(f);
		s.insert(mp(fs + n, sc));
	}
	puts("-1");
	return 0;
}

int main () {
	#ifdef _LOCAL_MACHINE41
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
	while (!solve());
	#else
	freopen((filename + ".in").data(), "rt", stdin);
	freopen((filename + ".out").data(), "wt", stdout);
	solve();
	#endif
	return 0;
}
