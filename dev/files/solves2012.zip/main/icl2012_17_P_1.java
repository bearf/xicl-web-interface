import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.StringTokenizer;


public class Solution implements Runnable {

	public static void main(String[] args) throws IOException {
		new Solution().run();
	}

	StringTokenizer in;
	BufferedReader br;
	PrintWriter out;

	public String nextToken() throws IOException {
		while (in == null || !in.hasMoreTokens()) {
			in = new StringTokenizer(br.readLine());
		}
		return in.nextToken();
	}

	public int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	static class Point {
		int x, y;

		public Point(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}

	public void solve() throws IOException {
		int n = nextInt();
		Point p1 = new Point(nextInt(), nextInt());
		boolean flag = false;
		Point p2 = new Point(nextInt(), nextInt());
		if (p1.x == p2.x)
			flag = false;
		else
			flag = true;
		int cnt = 0;
		for (int i = 0; i < n - 2; ++i) {
			Point p = new Point(nextInt(), nextInt());
			if ((flag && p.y == p2.y) || (!flag && p.x == p2.x)) {
				p2 = p;
				continue;
			}
			if ((!flag && p.x != p2.x) || (flag && p.y != p2.y)) {
				cnt++;
				flag = !flag;
				p2 = p;
				continue;
			}
		}
		out.print(cnt);
	}

	@Override
	public void run() {
		try {
			 br = new BufferedReader(new FileReader("wire.in"));
//			br = new BufferedReader(new InputStreamReader(System.in));
			 out = new PrintWriter(new File("wire.out"));
//			out = new PrintWriter(new OutputStreamWriter(System.out));
			solve();
			br.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

}
