#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <string>
#include <string.h>

#define li unsigned long long
#define pb push_back
#define mp make_pair

#define INF (1000 * 1000 * 1000)
#define EPS (1e-9) 

using namespace std;

set <pair<int, int> > used;

void bad(int q) {
	cout << q;
	exit(0);
}

void solve(){
	int n, k, x, y;
	cin >> n >> k;
	for (int i = 1; i <= k; ++i) {
		cin >> x >> y;
		if (x - 1 > 0 && y - 1 > 0 && 
			used.find(mp(x, y - 1)) != used.end() && 
			used.find(mp(x - 1, y - 1)) == used.end())
			bad(i);
		if (x - 1 > 0 && y + 1 <= x && 
			used.find(mp(x, y + 1)) != used.end() && 
			used.find(mp(x - 1, y)) == used.end())
			bad(i);
		used.insert(mp(x, y));
	}
	cout << -1;
}

int main(){
	freopen("bricks.in", "r", stdin);
	freopen("bricks.out", "w", stdout);
	solve();
}