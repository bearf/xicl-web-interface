#include <algorithm>
#include <iostream>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <set>
#include <string>
#include <vector>

using namespace std;

#define forn(i,n) for (int i = 0; i < (n); i++)
#define forit(it,v) for (typeof((v).end()) it = (v).begin(); it != (v).end(); ++it)
#define sz(v) ((int)((v).size()))
#define eprintf(...) {fprintf(stderr,__VA_ARGS__); fflush(stderr);}
typedef long long LL;
typedef long long ll;
typedef pair<int, int> ii;

#define TASK "trees"
const int maxn = (int)1e5 + 123;

int a[maxn];
LL get(LL n, LL val) {
	LL left = 1;
	LL right = (LL)1e12;
	while( left + 1 < right ) {
		LL ave = (left+right)/2;
		if( n / ave > val ) left = ave; else right = ave;
	}
	return right; 
}

int main() {
	assert(freopen(TASK ".in", "r", stdin));
	assert(freopen(TASK ".out", "w", stdout));
	int n,k; scanf("%d%d",&n,&k);
	for( int i = 0 ; i < k ; i++ ) {
		scanf("%d",&a[i]);
		a[i]--;
	}
	unsigned long long res = 0;
	if( k == 1 ) {
		res = 1;
		LL p;
		LL l = a[0];
		LL r = n - 1 - a[0];
		//eprintf("%I64d %I64d\n",l,r);
		for( p = 1  ; p < LL(1e6) ; p++ ) {
			res += l/p;
			res += r/p;
			res += (l/p)*(r/p);	
		}
		while( l/p != 0 || r/p != 0 ) {
			LL nl = 0;
			if( l / p == 0 ){
				nl = (LL)1e12;
			}else{
				nl = get(l,l/p - 1);
			}
			LL nr = 0;
			if( r / p == 0 ){
				nr = (LL)1e12;
			}else {
				nr = get(r, r/p - 1);
			}
			LL np = min(nr,nl);
			res += ((l/p)*(r/p) + (l/p) + (r/p))*(np-p);
			p = np;
		}
	}else {
		int g = 0;
		for( int i = 0 ; i < k - 1 ; i++ ) g = __gcd(a[i+1]-a[i], g);
		//eprintf("g = %d\n",g);
		for( int p = 1 ; p*p <= g ; p++ ) {
			LL q = g / p;
			if( g % p == 0 ) {
				res += (LL)(a[0]/p+1)*(LL)((n-1-a[k-1])/p+1);
				if(q!=p) res += (LL)(a[0]/q+1)*(LL)((n-1-a[k-1])/q+1);
			}
		}
	}
	cout << res << endl;
	return 0;
}
