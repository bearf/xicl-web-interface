#include <algorithm>
#include <iostream>
#include <vector>
#include <set>
#include <cmath>
using namespace std;
typedef pair <int, int> pii;
typedef long long ll;
ll a, b;
ll tt[12] = {1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000, 10000000000, 100000000000};
int main(){
	freopen("numbers.in", "r", stdin); freopen("numbers.out", "w", stdout);
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	cin >> a >> b;
	ll t = b; int lb = 0;
	while (t != 0){
		lb++;
		t /= 10;
	}
	for (int i = 1; i <= 10; i++){
		if (b * (a * tt[i] - 1) % (tt[lb] - a) == 0){
			ll x =  b * (a * tt[i] - 1) / (tt[lb] - a);
			if (x < tt[i] && x * tt[lb] + b == (b * tt[i] + x) * a){
				cout << b <<  x;
				return 0;
			}
		}
	}
	cout << -1;
	return 0;
}
