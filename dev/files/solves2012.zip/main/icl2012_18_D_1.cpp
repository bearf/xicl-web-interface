#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair <int, int> pii;

#define x first
#define y second
#define pb push_back
#define mp make_pair
#define all(a) (a).begin(), (a).end()
#define sz(a) (int)((a).size())
#define debug(...) fprintf(stderr, __VA_ARGS__)

#define problemname "millenium"

int N, A, B;

map <int, int> m;

int main() {
    freopen(problemname".in", "r", stdin);
    freopen(problemname".out", "w", stdout);

    scanf("%d %d %d", &N, &A, &B);
    for (int i = 0; i < N; i++) {
        int x, y;
        scanf("%d %d", &y, &x);
        m[y] = m[y] + 1;
    }

    int ans = 0;
    while (m.size()) {
        pii x = *(m.begin());
        m.erase(m.begin());
        ans = max(ans, x.x);
        if (x.y > B) {
            m[x.x + 1] = m[x.x + 1] + x.y - B;
        }
    }

    printf("%d\n", ans);





    return 0;
}
