import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {

	void _solve() throws Exception {
		height = nextInt();
		width = nextInt();
		s = new char[height][];
		for (int r = 0; r < height; r++) {
			s[r] = nextToken().toCharArray();
		}
		int startR = nextInt() - 1;
		int startC = nextInt() - 1;
		int finishR = nextInt() - 1;
		int finishC = nextInt() - 1;
		qt = 0;
		qh = 1;
		int qsize = height * width * 2;
		qr = new int[qsize];
		qc = new int[qsize];
		qactive = new int[qsize];
		was = new boolean[height][width][2];
		qr[0] = startR;
		qc[0] = startC;
		qactive[0] = (s[startR][startC] == '0') ? 0 : 1;
		was[qr[0]][qc[0]][qactive[0]] = true;
		while (qt < qh) {
			int r = qr[qt];
			int c = qc[qt];
			int active = qactive[qt];
			++qt;
			for (int dir = 0; dir < 4; dir++) {
				int nr = r + dr[dir];
				int nc = c + dc[dir];
				if (nr < 0 || nr >= height) continue;
				if (nc < 0 || nc >= width) continue;
				if (active == 0) {
					if (s[nr][nc] == '1') {
						move(nr, nc, 0);
					} else if (s[nr][nc] > '1') {
						move(nr, nc, 1);
					}
				} else {
					if (s[nr][nc] == '0') {
						move(nr, nc, 0);
					} else if (s[nr][nc] > '0') {
						move(nr, nc, 1);
					}
				}
			}
		}
		boolean res = false;
		if (was[finishR][finishC][0]) res = true;
		if (was[finishR][finishC][1]) res = true;
		out.println(res ? "YES" : "NO");
	}
	
	int height, width;
	char[][] s;
	int[] qr;
	int[] qc;
	int[] qactive; // we can throw a bridge out of an active cell
	boolean[][][] was;
	int qt, qh;
	final int[] dr = {-1, 0, 1, 0};
	final int[] dc = {0, -1, 0, 1};
	
	private void move(int nr, int nc, int nactive) {
		if (was[nr][nc][nactive]) return;
		was[nr][nc][nactive] = true;
		qr[qh] = nr;
		qc[qh] = nc;
		qactive[qh] = nactive;
		++qh;
	}

	
	BufferedReader in;
	StringTokenizer stringTokenizer;
	PrintWriter out;
	
	long nextLong() {
		return Long.parseLong(nextToken());
	}
	
	double nextDouble() {
		return Double.parseDouble(nextToken());
	}
	
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	
	String nextToken() {
		while (!stringTokenizer.hasMoreTokens()) {
			String line = null;
			try {
				line = in.readLine();
			} catch (IOException e) {
				NOO(e);
			}
			if (line == null) {
				return null;
			} else {
				stringTokenizer = new StringTokenizer(line);
			}
		}
		return stringTokenizer.nextToken();
	}
	
	public void run() {
		try {
			_solve();
		} catch (Exception e) {
			NOO(e);
		} finally {
			out.close();
		}
	}
	
	void NOO(Exception e) {
		e.printStackTrace();
		System.exit(42);
	}
	
	public Solution(String name) {
		try {
			in = new BufferedReader(new FileReader(name + ".in"));
			stringTokenizer = new StringTokenizer("");
			out = new PrintWriter(new FileWriter(name + ".out"));
		} catch (Exception e) {
			NOO(e);
		}
	}
	
	public static void main(String[] args) {
		new Solution("islands").run();
	}

}
