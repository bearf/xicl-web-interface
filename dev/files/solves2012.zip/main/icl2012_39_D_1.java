import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {

	void _solve() throws Exception {
		int n = nextInt();
		long a = nextLong();
		long b = nextLong();
		long[] inputX = new long[n];
		long[] inputY = new long[n];
		for (int i = 0; i < n; i++) {
			inputX[i] = nextLong() - 1;
			inputY[i] = nextLong() - 1;
			add(inputX[i], 1);
		}

		long curY = 0;
		long res = 0;
		while (am.size() > 0) {
			//printAll(curY);			
			long y = am.firstKey();
			if (curY < y) {
				long delta = y - curY;
				res += delta;
				curY += delta; // our tetris figure is falling!
				continue;
			}
			if (curY > y) {
				throw new AssertionError();
			}
			//curY == y
			int here = am.get(y);
			int leavingNow = here;
			if (leavingNow > b) {
				leavingNow = (int)b;
			}
			am.remove(y);
			add(y + 1, here - leavingNow);

			curY += 1;
			res += 1;
		}
		out.println(res);
	}
	
	private void printAll(long y) {
		System.out.println(y);
		for (Map.Entry<Long, Integer> e : am.entrySet()) {
			System.out.println(e.getKey() + " " + e.getValue());
		}
		System.out.println();
	}

	TreeMap<Long, Integer> am = new TreeMap<Long, Integer>();
	private void add(long y, int val) {
		Integer v = am.get(y);
		if (v == null) {			
			v = 0;
		} 
		long nval = v + val;
		if (nval == 0) {
			am.remove(y);
		} else {
			am.put(y, v + val);
		}
	}
	
	
	
	
	BufferedReader in;
	StringTokenizer stringTokenizer;
	PrintWriter out;
	
	long nextLong() {
		return Long.parseLong(nextToken());
	}
	
	double nextDouble() {
		return Double.parseDouble(nextToken());
	}
	
	int nextInt() {
		return Integer.parseInt(nextToken());
	}
	
	String nextToken() {
		while (!stringTokenizer.hasMoreTokens()) {
			String line = null;
			try {
				line = in.readLine();
			} catch (IOException e) {
				NOO(e);
			}
			if (line == null) {
				return null;
			} else {
				stringTokenizer = new StringTokenizer(line);
			}
		}
		return stringTokenizer.nextToken();
	}
	
	public void run() {
		try {
			_solve();
		} catch (Exception e) {
			NOO(e);
		} finally {
			out.close();
		}
	}
	
	void NOO(Exception e) {
		e.printStackTrace();
		System.exit(42);
	}
	
	public Solution(String name) {
		try {
			in = new BufferedReader(new FileReader(name + ".in"));
			stringTokenizer = new StringTokenizer("");
			out = new PrintWriter(new FileWriter(name + ".out"));
		} catch (Exception e) {
			NOO(e);
		}
	}
	
	public static void main(String[] args) {
		new Solution("millenium").run();
	}

}
