#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <iostream>
#include <set>
using namespace std;

int i, m, cz=0, n=0, k[10000], l[10000], sk=0, sl=0;

int main(){
	freopen("changes.in", "r", stdin);
	freopen("changes.out", "w", stdout);
	cin >> m;
	for (i=0; i<m; i++) {cin >> k[i]; sk+=k[i];}
	for (i=0; i<m; i++) {cin >> l[i]; sl+=l[i];}
	if (sk!=sl)
		{
			cout << -1;
			return 0;
		}
	for (i=1; i<m; i++)
		if ((k[i]+l[i-1]-l[i]-k[i-1])%m)
		{
			cout << -1;
			return 0;
		}
	vector<int> v;
	for (n=0;; n++)
	{
		cz=0;
		for (i=0; i<m; i++)
			if (!k[i]) cz++;
		int zi=0, z=0;
		for (i=0; i<m; i++)
			if (z<l[i]-k[i])
			{
				zi=i;
				z=l[i]-k[i];
			}
		if (!z) break;
		if (cz>1)
		{
			cout << -1;
			return 0;
		}
		v.push_back(zi+1);
		for (i=0; i<m; i++)
		{
			k[i]--;
			if (i==zi) k[i]+=m;
		}
	}
	cout << n << endl;
	for (i=0; i<n; i++)
		cout << v[i] << ' ';
	return 0;
}