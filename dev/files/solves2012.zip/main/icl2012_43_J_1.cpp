#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <string>
#include <string.h>
#include <math.h>
#include <memory.h>
using namespace std;

#define li int
#define pb push_back
#define mp make_pair
#define all(a) a.begin(),a.end()

li n,m,k,nx, ny, kx, ky;
vector<vector<li> > a;
vector <vector <li> > metka, bad;
li abc(li x)
{
	if(x>0)
		return x;
	return -x;
}
li dx[5]={1,0,-1,0};
li dy[5]={0,1,0,-1};
bool prov(li x, li y)
{
	for(int i=0;i<4;i++)
	{
		li xx=x+dx[i], yy=y+dy[i];
		if(xx>=0 && xx<n && yy>=0 && yy<m && a[xx][yy]>1)
			return true;
	}
	return false;
}
void dfs(li x, li y, li used)
{
	metka[x][y]=1;
	if(metka[kx][ky])
	{
		cout<<"YES";
		exit(0);
	}
	
	if(used)
		bad[x][y]=1;
	if(((prov(x,y) && a[x][y]>0) || a[x][y]>1) || (a[x][y]==1 && !used))
	{
		for(int i=0;i<4;i++)
		{
			li xx=x+dx[i], yy=y+dy[i];
			if(xx>=0 && xx<n && yy>=0 && yy<m)
			{
				if(!metka[xx][yy] || bad[xx][yy])
				{
					bad[xx][yy]=0;
					dfs(xx,yy,0);
				}
			}
		}
	}
	else
	{
		for(int i=0;i<4;i++)
		{
			li xx=x+dx[i], yy=y+dy[i];
			if(xx>=0 && xx<n && yy>=0 && yy<m)
			{
				if(metka[xx][yy]==0 && a[xx][yy]>0)
					dfs(xx,yy,1);
			}
		}
	}
}
int main()
{
	//freopen("input.txt", "r", stdin);
	freopen("islands.in", "r", stdin);
	freopen("islands.out", "w", stdout);
	li i,j;
	cin>>n>>m;
	a.resize(n);
	metka.resize(n), bad.resize(n);
	for(i=0;i<n;i++)
		metka[i].resize(m), bad[i].resize(m);
	for(i=0;i<n;i++)
		for(j=0;j<m;j++)
		{
			char c;
			c=getchar();
			if(c==' ' || c=='\n')
				c=getchar();
			if(c>'2')
				c='2';
			a[i].pb((li)(c-'0'));
		}
	cin>>nx>>ny>>kx>>ky;
	nx--,ny--,kx--,ky--;
	dfs(nx, ny, 0);
	cout<<"NO";
	return 0;
}