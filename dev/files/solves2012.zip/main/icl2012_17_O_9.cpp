#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int main()
{
	freopen("darts.in","r",stdin);
	freopen("darts.out","w",stdout);
	int l,r,n,m,k,i,j,e;
	vector<pair<int,int>> a,q;pair<int,int>w;
	vector <int>q3,q4,q1,q2;
	cin>>n>>m>>k;
	vector<int> b,c;
	for(i=0;i<k;i++)
	{cin>>w.first>>w.second;
	a.push_back(w);}
	sort(a.begin(),a.end());
	q.push_back(a.at(0));
	for(i=1;i<k;i++)
     if(a.at(i)!=a[i-1])q.push_back(a.at(i));
	w.first=0;w.second=0;q.push_back(w);
	w.first=n;w.second=m;q.push_back(w);
	for(i=0;i<(int)q.size();i++)
	{q1.push_back(q.at(i).first);
	q2.push_back(q.at(i).second);}
sort(q1.begin(),q1.end());
sort(q2.begin(),q2.end());
q3.push_back(q1.at(0));
for(i=1;i<(int)q1.size();i++)
if(q1.at(i)!=q1[i-1]) q3.push_back(q1.at(i));
q4.push_back(q2.at(0));
for(i=1;i<(int)q2.size();i++)
if(q2.at(i)!=q2[i-1]) q4.push_back(q2.at(i));
            for(i=0;i<q3.size()-1;i++)
		   for(j=i+1;j<q3.size();j++)
		   {if(abs(q3.at(i)-q3.at(j))!=0) b.push_back(abs(q3.at(i)-q3.at(j)));}
		for(i=0;i<q4.size()-1;i++)
		for(j=i+1;j<q4.size();j++)
		{
	if(abs(q4.at(i)-q4.at(j))!=0)c.push_back(abs(q4.at(i)-q4.at(j)));
	}
		sort(b.begin(),b.end());
		sort(c.begin(),c.end());
		i=0;j=0;
		k=0;
		while(i<b.size()&&j<c.size())
		{l=0;r=0;
			if(b.at(i)>c.at(j)) j++;else
				if(b.at(i)<c.at(j)) i++;
			if(b.at(i)==c.at(j))
			{
               e=b.at(i);
			   while(i<b.size() && b.at(i)==e) {r++;i++;}
			   while(j<c.size() && c.at(j)==e) {l++;j++;}
			   k=k+l*r;
			}
		}
		cout<<k;
		return 0;
}
/*
5 8 4
4 2
2 4
2 5
4 2
*/