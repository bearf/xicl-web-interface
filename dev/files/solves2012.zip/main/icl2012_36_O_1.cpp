#include <algorithm>
#include <iostream>
#include <vector>
#include <set>
#include <cmath>
using namespace std;
typedef pair <int, int> pii;
typedef long long ll;
//ll a, b;
//ll tt[12] = {1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000, 10000000000, 100000000000};

int n, m, k, l, i, j, res, maxn, p;
vector <int> a, b, pa, pb, x, y;
bool bo;

int main(){
	freopen("darts.in", "r", stdin); freopen("darts.out", "w", stdout);
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);

	maxn = 1000000000;
	cin >> n >> m >> k;
	x.resize(k + 10);
	y.resize(k + 10);
	a.resize(k * k + 1000);
	b.resize(k * k + 1000);
	pa.resize(k * k + 1000);
	pb.resize(k * k + 1000);
	l = 0;
	p = 0;
	for (i = 0; i < k; i++) {
		cin >> x[p] >> y[p];
		bo = true;
		for (j = 0; j < i; j++) {
			if (x[p] == x[j] && y[p] == y[j]) {
				bo = false;
			}
		}
		if (bo) {
			p++;
		}
	}
	x[p] = 0;
	y[p] = 0;
	bo = true;
	for (j = 0; j < p; j++) {
		if (x[p] == x[j] && y[p] == y[j]) {
			bo = false;
		}
	}
	if (bo) {
		p++;
	}

	x[p] = n;
	y[p] = m;
	bo = true;
	for (j = 0; j < p; j++) {
		if (x[p] == x[j] && y[p] == y[j]) {
			bo = false;
		}
	}
	if (bo) {
		p++;
	}

	x.resize(p);
	y.resize(p);
	sort(x.begin(), x.end());
	sort(y.begin(), y.end());

	/*
	for (i = 0; i < p; i++)
		cout << x[i] << ' ';
	cout << "\n";
	for (i = 0; i < p; i++)
		cout << y[i] << ' ';
	cout << "\n";
	*/

	n = 0;
	a[n] = x[n];
	for (i = 0; i < p; i++) {
		if (a[n] != x[i]) {
			n++;
			a[n] = x[i];
		}
	}
	n++;
	m = 0;
	b[m] = y[m];
	for (i = 0; i < p; i++) {
		if (b[m] != y[i]) {
			m++;
			b[m] = y[i];
		}
	}
	m++;
/*
	for (i = 0; i < n; i++)
		cout << a[i] << ' ';
	cout << "\n";
	for (j = 0; j < m; j++)
		cout << b[j] << ' ';
	cout << "\n";
	cout << "\n";
*/
	x.resize(k * k + 1000);
	y.resize(k * k + 1000);

	k = 0;
	for (i = 0; i < n; i++) {
		for (j = i + 1; j < n; j++) {
			x[k] = abs(a[i] - a[j]);
			k++;
		}
	}

	p = 0;
	for (i = 0; i < m; i++) {
		for (j = i + 1; j < m; j++) {
			y[p] = abs(b[i] - b[j]);
			p++;
		}
	}

	x.resize(k);
	y.resize(p);

	sort(x.begin(), x.end());
	sort(y.begin(), y.end());
	int t = 0;
	a[0] = x[0];
	pa[0] = 1;
	for (i = 1; i < k; i++){
		if (x[i] != x[i - 1]){
			t++;
			a[t] = x[i];
			pa[t] = 1;
		}
		else
			pa[t]++;
	}
	k = t + 1;

	t = 0;
	b[0] = y[0];
	pb[0] = 1;
	for (i = 1; i < p; i++) {
		if (y[i] != y[i - 1]){
			t++;
			b[t] = y[i];
			pb[t] = 1;
		}
		else
			pb[t]++;
	}
	p = t + 1;
/*
	for (i = 0; i < k; i++)
		cout << a[i] << ' ';
	cout << "\n";
	for (j = 0; j < k; j++)
		cout << pa[j] << ' ';
	cout << "\n";
	cout << "\n";
	for (i = 0; i < p; i++)
		cout << b[i] << ' ';
	cout << "\n";
	for (j = 0; j < p; j++)
		cout << pb[j] << ' ';
	cout << "\n";
*/
	i = 0;
	j = 0; 
	res = 0;
	while (i < k && j < p){ 
		if (a[i] == b[j]){
			res += pa[i] * pb[j];
			i++;
			j++;
		}
		else
			if (a[i] < b[j])
				i++;
			else
				j++;
	}

	cout << res;
	return 0;
}
