import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Solution {
	public int gcd(int a, int b) {
		if (a == 0) {
			return b;
		} else {
			return gcd(b % a, a);
		}
	}

	public long calc(int l, int r, int div) {
		return (l / div + 1L) * (r / div + 1L);
	}

	public void run(Scanner input, PrintWriter output) {
		int fMax = 100000;
		int n = input.nextInt();
		int k = input.nextInt();
		int[] pos = new int[k];
		for (int i = 0; i < k; i++) {
			pos[i] = input.nextInt();
		}
		int l = pos[0] - 1;
		int r = n - pos[k - 1];
		if (k == 1) {
			long ans = 1;
			int max = Math.max(l, r);
			int up = Math.min(max, fMax - 1);
			for (int i = 1; i <= up; i++) {
				ans += calc(l, r, i) - 1;
			}

			Set<Integer> toAdd = new TreeSet<Integer>();
			if (max >= fMax) {
				toAdd.add(max);
				if (max - 1 >= fMax) {
					toAdd.add(max - 1);
				}
				toAdd.add(fMax);
				if (fMax + 1 <= max) {
					toAdd.add(fMax + 1);
				}
				for (int i = 1; i <= l / fMax; i++) {
					for (int d = -2; d <= 2; d++) {
						// todo: !
						if ((l / i + d >= fMax) && (l / i + d) <= max) {
							toAdd.add(l / i + d);
						}
					}
				}
				for (int i = 1; i <= r / fMax; i++) {
					for (int d = -2; d <= 2; d++) {
						// todo: !
						if ((r / i + d >= fMax) && (r / i + d) <= max) {
							toAdd.add(r / i + d);
						}
					}
				}
				// analyse
				int[] values = new int[toAdd.size()];
				int _pos = 0;
				for (int v : toAdd) {
					values[_pos++] = v;
				}
				for (int i = 0; i < values.length; i++) {
					// add values[i]
					long curAns = calc(l, r, values[i]) - 1;
					ans += curAns;
					if (i != 0) {
						// maybe add between?
						if (values[i] - values[i - 1] > 1) {
							// check invariant
							if (curAns+1 != calc(l, r, values[i - 1])) {
								throw new RuntimeException();
							}
							ans += (values[i] - values[i - 1] - 1) * curAns;
						}
					}
					if (curAns == 0) {
						break;
					}
				}
			}

			output.println(ans);
		} else {
			long ans = 0;
			int gcd = pos[1] - pos[0];
			for (int i = 2; i < k; i++) {
				gcd = gcd(gcd, pos[i] - pos[i - 1]);
			}
			for (int i = 1; i * i <= gcd; i++) {
				if (gcd % i == 0) {
					// i and gcd/i
					ans += calc(l, r, i);
					if (i * i != gcd) {
						ans += calc(l, r, gcd / i);
					}
				}
			}

			output.println(ans);
		}
	}

	public static void main(String[] args) throws FileNotFoundException {
		// Scanner input = new Scanner(System.in);
		// PrintWriter output = new PrintWriter(System.out);
		Scanner input = new Scanner(new File("trees.in"));
		PrintWriter output = new PrintWriter(new File("trees.out"));

		new Solution().run(input, output);

		input.close();
		output.close();
	}
}
