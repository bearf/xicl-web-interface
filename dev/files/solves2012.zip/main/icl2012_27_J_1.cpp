#include <iostream>
#include <algorithm>
#include <numeric>
#include <functional>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <list>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define for1(i, n) for(int i = 1; i <= int(n); ++i)
#define ford(i, n) for(int i = int(n)-1; i >= 0; --i)
#define fore(i, l, r) for(int i = int(l); i < int(r); ++i)
#define pb push_back
#define mp make_pair
#define sz(v) int((v).size())
#define all(v) (v).begin(), (v).end()
#define X first
#define Y second

typedef long long li;
typedef long double ld;
typedef pair<int, int> pt;

const int INF = int(1e9) + 7;
const ld EPS = 1e-9;
const ld PI = acos(-1.0);

const int N = 300000;

const int dx[] = {0, 0, 1, -1};
const int dy[] = {1, -1, 0, 0};

int n, m;
int b[N];

bool used[2][N];
int H, T;
pt q[N];


int main(){
#ifdef home
    freopen("input.txt", "r", stdin);
//    freopen("output.txt", "w", stdout);
#else
    freopen("islands.in", "r", stdin);
    freopen("islands.out", "w", stdout);
#endif

    cin >> n >> m;

    forn(i, n)
    forn(j, m){
        char c;
        scanf(" %c", &c);
        b[i*m + j] = c - '0';
    }

    pt st, fn;
    cin >> st.X >> st.Y >> fn.X >> fn.Y;
    st.X--; fn.X--; st.Y--; fn.Y--;
    int stI = st.X*m + st.Y;
    int fnI = fn.X*m + fn.Y;


    H = T = 0;
    q[T++] = pt(0, stI);
    used[0][stI] = true;

    while(H != T){
        pt v = q[H++];

        pt vp(v.Y / m, v.Y % m);

        forn(i, 4)
        forn(bi, 2){
            if(bi == 0 && b[v.Y] - v.X == 0)
                continue;

            pt p(vp.X + dx[i], vp.Y + dy[i]);
            if(0 > p.X || n <= p.X || 0 > p.Y || m <= p.Y)
                continue;

            pt u(bi, p.X*m + p.Y);
            if(bi == 1 && b[u.Y] == 0)
                continue;

            if(!used[u.X][u.Y]){
                q[T++] = u;
                used[u.X][u.Y] = true;
            }
        }
    }


    puts((used[0][fnI] || used[1][fnI]) ? "YES" : "NO");

    return 0;
}
