#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <cstdio>

using namespace std;
typedef long long ll;
ll n,k;
ll a,b;
map< pair<ll, ll>, int > not; 
int main() {
	freopen("bricks.in", "r", stdin);
	freopen("bricks.out", "w", stdout);
	cin >> n >> k;
	int was = 0;
	for (int i = 0; i < k; i++) {
		scanf("%I64d%I64d", &a, &b);
		if (b > 1) {
			pair<ll, ll> tl = make_pair(a - 1, b - 1);
			pair<ll, ll> l = make_pair(a, b - 1);
			if (not.count(l) > 0 && not.count(tl) == 0) {
				cout << i + 1;
				was = 1;
				break;
			}
		}
		if (b < a) {
			pair<ll, ll> tr = make_pair(a - 1, b);
			pair<ll, ll> r = make_pair(a, b + 1);
			if (not.count(r) > 0 && not.count(tr) == 0) {
				cout << i + 1;
				was = 1;
				break;
			}
		}
		not[make_pair(a, b)] = 1;
	}
	if (!was) cout << -1;
}