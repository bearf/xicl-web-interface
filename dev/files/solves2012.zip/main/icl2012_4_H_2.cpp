#define _CRT_SECURE_NO_DEPRECATE

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <algorithm>
#include <string>
#include <string.h>
#include <set>
#include <map>

using namespace std;

#define pb push_back
#define mp make_pair
#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)

typedef long long int64;

#define TASK "trees"

#define MAX 100010

int n, k;

int x[MAX];

int gcd(int x, int y) {
	while (y) {
		x %= y;
		swap(x, y);
	}
	return x;
}

int64 ans;

int64 Solve(int d) {
	int64 l, r;
	l = (x[1] - 1) / d + 1;
	r = (n - x[k]) / d + 1;
	return l * r;
}

int cnt_divs = 0;
int divs[1000000];

void enumDiv(int x) {
	for (int d = 1; d * d <= x; d++) {
		if (x % d == 0) {
			divs[cnt_divs++] = d;
			if (d * d != x) {
				divs[cnt_divs++] = x / d;
			}
		}
	}
}

void Solve2() {
	int q1 = x[1] - 1;
	int q2 = n - x[1];
	/*if (q1 > 0) {
		enumDiv(q1);
	}
	if (q2 > 0) {
		enumDiv(q2);
	}
	sort(divs, divs + cnt_divs);
	int * end = unique(divs, divs + cnt_divs);
	cnt_divs = end - divs;
	for (int i = 0; i < cnt_divs; i++) {
		int64 tttt = ((int64)q1 / divs[i] + 1) * ((int64)q2 / divs[i] + 1) - 1;
		if (i > 0) {
			tttt *= divs[i] - divs[i - 1];
		}
		ans += tttt;
	}*/
	if (q1 > q2) {
		swap(q1, q2);
	}
	int r1 = q1;
	int r2 = q2;
	int d = 2000000000;
	for (int i = 1; i <= q2;) {
		d = 2000000000;
		if (r1 > 0) {
			d = (q1 - i * r1) / r1;
		}
		if (r2 > 0) {
			d = min((q2 - i * r2) / r2, d);
		}
		d++;

		int64 tttt = ((int64)q1 / i + 1) * ((int64)q2 / i + 1) - 1;
		tttt *= d;
		ans += tttt;

		i += d;
		r1 = q1 / i;
		r2 = q2 / i;
	}
	ans++;
}


int main() {
	int i;
	int g;
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
	scanf("%d %d", &n, &k);

	fi(1, k) { 
		scanf("%d", &x[i]);
	}

	if (k == 1) {
		Solve2();
		printf("%I64d\n", ans);
		return 0;
	}

	sort(x + 1, x + k + 1);
	g = x[2] - x[1];
	fi(3, k) {
		g = gcd(g, x[i] - x[i - 1]);
	}

	for (i = 1; i * i <= g; i++) {
		if (g % i == 0) {
			ans += Solve(i);
			if (g / i != i) ans += Solve(g / i);
		}
	}
	printf("%I64d\n", ans);
	return 0;
}	