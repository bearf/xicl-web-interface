#include <iostream>
#include <vector>
#include <cassert>
#include <set>
#include <cstdio>
#include <map>
#include <deque>
#include <algorithm>
#include <cmath>

using namespace std;

#define forn(i, n) for (ll i = 0; i < ll(n); ++i)
#define ford(i, n) for (ll i = ll(n) - 1; i < ll(n); --i)
#define all(a) a.begin(), a.end()
#define fs first
#define sc second
#define pb push_back
#define mp make_pair

typedef unsigned long long ll;
typedef long double ld;

const string filename("trees");

ll gcd(ll a, ll b) {
	return a ? gcd(b % a, a) : b;
}

int solve () {
	ll n, k;
	cin >> n >> k;
	ll x;
	if (!(cin >> x)) {
		return 1;
	}
	ll y = x;
	ll ans = 0;
	forn (i, k - 1) {
		cin >> y;
		ans = gcd(ans, y - x);
	}
	x--;
	y--;
	if (k == 1) {
		ll m = 500000ll;
		ll q = 1ll;
		vector<ll> w(0);
		w.pb(max(x, n - 1ll - x) + 1ll);
		for (ll t = 2; t <= m; t++) {
			ll e = x / t + 1ll;
			if (e > m) {
				w.pb(e);
			}
			e = (n - 1ll - x) / t + 1ll;
			if (e > m) {
				w.pb(e);
			}
		}
		sort(w.begin(), w.end());
//		cerr << w.size() << endl;
//		forn (q, w.size()) {
//			cerr << w[q] << ' ';
//		}
//		cerr << endl;
		for (ll t = 1; t < w[0]; t++) {
//			cerr << q << ' ';
			q += (x / t + 1ll) * ((n - 1ll - x) / t + 1ll) - 1ll;
		}
//		cerr << "| ";
		forn (t, w.size() - 1) {
//			cerr << q << ' ';
			q += (w[t + 1] - w[t]) * ((x / w[t] + 1ll) * ((n - 1ll - x) / w[t] + 1ll) - 1ll);
		}
		cout << q << endl;
	} else {
		ll q = 0;
		vector<ll> w(0);
		for (ll d = 1; d * d <= ans; d++) {
			if (ans % d == 0) {
				if (d * d == ans) {
					w.pb(d);
				} else {
					w.pb(d);
					w.pb(ans / d);
				}
			}
		}
		forn (i, w.size()) {
			q += (x / w[i] + 1ll) * ((n - 1ll - y) / w[i] + 1ll);
		}
		cout << q << endl;
	}
	return 0;
}

int main () {
	#ifdef _LOCAL_MACHINE41
	//freopen("input.txt", "rt", stdin);
	//freopen("output.txt", "wt", stdout);
	while (!solve());
	#else
	freopen((filename + ".in").data(), "rt", stdin);
	freopen((filename + ".out").data(), "wt", stdout);
	solve();
	#endif
	return 0;
}
