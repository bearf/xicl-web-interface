#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <ctime>
#include <cmath>

#define pb push_back
#define pbk pop_back
#define mp make_pair
#define fs first
#define sc second
#define len(x) ((int) (x).size())
#define last(x) (x)[(len(x)-1)]
#define plast(x) (x)[(len(x)-2)]
#define sqr(x) ((x)*(x))
#define foreach(i, x) for (__typeof((x).begin()) i = (x).begin(); i != (x).end(); ++i)
#define forn(i, n) for (int i = 0; i < int(n); ++i)

using namespace std;

typedef long double ld;
typedef long long int64;

int64 p[18];

int f(int64 a) {
	forn (i, 18) {
		if (p[i] > a) {
			return i;
		}
	}
}

int main() {
	freopen("numbers.in", "r", stdin);
	freopen("numbers.out", "w", stdout);
	int64 a, b;
	cin >> a >> b;
	if (a == 1) {
		cout << b << b;
		return 0;
	}
	p[0] = 1;
	forn (i, 17) {
		p[i + 1] = p[i] * 10ll;
	}
	int b1 = f(b);
	for (int x1 = 1; x1 < 18; x1++) {
		if (x1 + b1 > 17) {
			break;
		}
		int64 cur = b * (p[x1] * a - 1);
		if (cur % (p[b1] - a) == 0 && x1 == f(cur / (p[b1] - a))) {
			cout << b << cur / (p[b1] - a);
			return 0;
		}
	}
	cout << -1;
	return 0;
}
