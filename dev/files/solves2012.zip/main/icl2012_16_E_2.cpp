#include <iostream>
#include <sstream>
#include <stdio.h>
#include <cassert>
#include <memory.h>
#include <math.h>
#include <time.h>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <bitset>

using namespace std;

#define mp make_pair
#define pb push_back
#define all(a) (a).begin(),(a).end()
#define _(a,b) memset((a),b,sizeof(a))
#define sz(a) ((int)(a).size())

typedef long long lint;
typedef unsigned long long ull;
typedef pair < int , int > pii;

const int INF = 1000000000;
const lint LINF = 4000000000000000000LL;
const double eps = 1e-9;

void prepare(string s)
{
#ifdef _DEBUG
	freopen("input.txt","r",stdin);
#else
	freopen((s + ".in").c_str(),"r",stdin);
	freopen((s + ".out").c_str(),"w",stdout);
#endif
}

const int nmax = 10005;
int k[nmax];
int l[nmax];
int x[nmax];
int need[nmax];
int n;

void read()
{
	scanf("%d",&n);
	for (int i = 0; i < n; i ++)
		scanf("%d",&k[i]);
	for (int i = 0; i < n; i ++)
		scanf("%d",&l[i]);
}

bool check()
{
	for (int i = 0; i < n; i ++)
	{
		if (k[i] != l[i])
		{
			return false;
		}
	}
	return true;
}

bool solve()
{
	read();
	for (int i = 0; i < n; i ++)
	{
		x[i] = max(0, (l[i] - k[i] + (n - 2)) / (n - 1));
		int cur = k[i] + x[i] * (n - 1);
		need[i] = x[i] + cur - l[i];
	}
	int M = need[0];
	for (int i = 0; i < n; i ++)
	{
		if (need[i] % n != need[0] % n)
		{
			printf("-1\n");
			return false;
		}
		M = max(M,need[i]);
	}

	for (int i = 0; i < n; i ++)
	{
		x[i] += (M - need[i]) / n;
	}

	vector < int > ans;
	for (int it = 0; it < M; it ++)
	{
		int mn = -1;
		for (int i = 0; i < n; i ++)
		{
			if (x[i])
			{
				if (mn == -1 || k[mn] > k[i])
				{
					mn = i;
				}
			}
		}
		ans.pb(mn);
		k[mn] += n - 1;
		x[mn] --;
		for (int i = 0; i < n; i ++)
		{
			if (i != mn)
			{
				if (k[i] == 0)
				{
					printf("-1\n");
					return false;
				}
				k[i] --;
			}
		}
	}
	if (!check())
	{
		printf("-1\n");
	}
	else
	{
		printf("%d\n",sz(ans));
		for (int i = 0; i < sz(ans); i ++)
		{
			if (i) printf(" ");
			printf("%d",ans[i] + 1);
		}
		printf("\n");
	}
	return false;
}

int main()
{
	prepare("changes");
	while (solve());
	return 0;
}