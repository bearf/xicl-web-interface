#include <cstdio>
#include <cstring>
#include <cmath>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <iostream>
#include <fstream>
#include <set>
#include <iterator>

#define mp make_pair
#define pb push_back
#define zero(a) memset(a, 0, sizeof(a))
#define SZ(a) ((int)(a.size()))
#define sqr(a) ((a)*(a))


#define dbgv(v) cerr << #v " : (",copy(v.begin(),v.end(),ostream_iterator<int>(cerr," ")),cerr<<")\n"
                
typedef long long ll;
typedef long double ld;

#define taskname "cuts"

using namespace std;

ld START = clock();

struct item{
	vector<int> v;
	vector<int> t;
	bool operator<(const item& r) const{
		return t < r.t;
	}
};


item merge(item& a,item& b){
	item res;
	int sza = a.v.size();
	int szb = b.v.size();
	res.v.resize(sza+szb);
	res.t.resize(sza+szb);

	int tt1,tt2;
	tt1 = tt2 = 0;

	int ptr1,ptr2;
	ptr1 = ptr2 = 0;
	for (int it = 0; it < sza+szb; it++){
		if (ptr1 == sza || (ptr2 != szb && a.v[ptr1] > b.v[ptr2])){
			res.v[ptr1+ptr2] = b.v[ptr2];
			res.t[ptr1+ptr2] = b.t[ptr2] + tt1;
			tt2 = b.t[ptr2];
			ptr2++;
		}
		else {
			res.v[ptr1+ptr2] = a.v[ptr1];
			res.t[ptr1+ptr2] = a.t[ptr1] + tt2;
			tt1 = a.t[ptr1];
			ptr1++;
		}
	}
	return res;
}

item dp[30][30][30][30];

int a[30][30];
int n,m;

item& calc(int lx,int ly,int rx,int ry){
	item& res = dp[lx][ly][rx][ry];
	if (res.t.size())
		return res;

	if (lx == rx && ly == ry){
		res.v.pb(a[lx][ly]);
		res.t.pb(0);
		return res;
	}

	int bi = lx,bj = ly;

	for (int i = lx; i <= rx; i++)
		for (int j = ly; j <= ry; j++)
			if (a[i][j] < a[bi][bj])
				bi = i,bj = j;

	res.t.pb((int)1e9);

    if (lx != bi)
    	res = min(res,merge(calc(lx,ly,bi-1,ry),calc(bi,ly,rx,ry)));

    if (rx != bi)
    	res = min(res,merge(calc(lx,ly,bi,ry),calc(bi+1,ly,rx,ry)));

    if (ly != bj)
    	res = min(res,merge(calc(lx,ly,rx,bj-1),calc(lx,bj,rx,ry)));

    if (ry != bj)
    	res = min(res,merge(calc(lx,ly,rx,bj),calc(lx,bj+1,rx,ry)));

    for (int i = 0; i < (int)res.t.size(); i++)
    	res.t[i]++;	

//	cerr << lx <<" "<<ly <<" "<<rx<<" "<<ry<<endl;
//	dbgv(res.t);
//	dbgv(res.v);
//	cerr << endl << endl;


    return res;  
}

int main (void){
  freopen (taskname".in", "rt", stdin);
  freopen (taskname".out", "wt", stdout);

  scanf("%d %d",&n,&m);

  for (int i = 0; i < n; i++)
  	for (int j = 0; j < m; j++)
  		scanf("%d",&a[i][j]);

  vector<int> t = calc(0,0,n-1,m-1).t;

  for (int i = 0; i < n*m; i++)
  	printf("%d ",t[i]);


//  cerr << (clock()-START)/CLOCKS_PER_SEC << endl;

  return 0;
}


