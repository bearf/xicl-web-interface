#include <iostream>
#include <vector>
#include <cassert>
#include <set>
#include <cstdio>
#include <map>
#include <deque>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < int(n); ++i)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; --i)
#define all(a) a.begin(), a.end()
#define fs first
#define sc second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef long double ld;
typedef pair <int, int> pii;

const string filename("millenium");

int n, A, B;
int a[100006];
int p;

pii get_next () {
	int cnt = 1;
	++p;
	while (p < n && a[p - 1] == a[p]) {
		++p;
		++cnt;
	}
	return mp(a[p - 1], cnt);
}

int w () {
	p = 0;
	pii buf = get_next();
	int row = buf.fs, last = buf.sc;
	while (p < n) {
		buf = get_next();
		while (row < buf.fs && last) {
			++row;
			last -= min(B, last);
		}
		if (!last)
			row = buf.fs;
		last += buf.sc;
	}
	while (last) {
		++row;
		last -= min(B, last);
	}
	return row;
}

int solve () {
	if (scanf("%d%d%d", &n, &A, &B) != 3)
		return 1;
	forn(i, n) {
		int x;
		if (scanf("%d%d", a + i, &x) != 2)
			return 1;
	}
	sort(a, a + n);
	printf("%d\n", w() - 1);
	return 0;
}

int main () {
	#ifdef _LOCAL_MACHINE41
	freopen("input.txt", "rt", stdin);
	//freopen("output.txt", "wt", stdout);
	while (!solve());
	#else
	freopen((filename + ".in").data(), "rt", stdin);
	freopen((filename + ".out").data(), "wt", stdout);
	solve();
	#endif
	return 0;
}
