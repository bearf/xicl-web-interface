#include <cstdio>
#include <algorithm>
#include <iostream>
#include <set>

using namespace std;

const int maxk = 4001;
const int maxc = 5000000;

typedef unsigned long long int int64;

int n, m, k, cnt;
int x[maxk];
int y[maxk];
int dy[maxc];
bool okx[maxk], oky[maxk];
set <int> s;
int64 res;




int main()
{
	freopen("darts.in", "rt", stdin);
	freopen("darts.out", "wt", stdout);
	scanf("%d %d %d", &n, &m, &k);	
	for (int i = 0; i < k; i++)
		scanf("%d %d", &x[i], &y[i]);
	x[k] = 0;
	y[k] = 0;
	k++;
	x[k] = n;
	y[k] = m;
	k++;
	sort(x, x + k);
	sort(y, y + k);
	for (int i = 0; i < k; i++)
		oky[i] = true;
	for (int i = 1; i < k; i++)
	{
		if (y[i] == y[i - 1])
			oky[i] = false;
	}
	cnt = 0;
	for (int i = 0; i < k; i++)
	{
		if (!oky[i])
			continue;
		for (int j = i + 1; j < k; j++)
		{
			if (!oky[j])
				continue;
			dy[cnt++] = abs(y[i] - y[j]);					
		}
    }
	sort(dy, dy + cnt);


		
	res = 0;

	for (int i = 0; i < k; i++)
		okx[i] = true;
	for (int i = 1; i < k; i++)
		if (x[i] == x[i - 1])
			okx[i] = false;	
	for (int i = 0; i < k; i++)
	{
		if (!okx[i])
			continue;
		for (int j = i + 1; j < k; j++)
		{	
			if (!okx[j])
				continue;
			int dx = abs(x[j] - x[i]); 
			//cerr << dx << " " << res << endl;
			res += int64(upper_bound(dy, dy + cnt, dx) - lower_bound(dy, dy + cnt, dx));				
			//cerr << res << endl;
		}
	}
	cout << res;
	fclose(stdin);
    fclose(stdout);         	
	return 0;
}
