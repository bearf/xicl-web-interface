#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <string>
#include <queue>
#include <string.h>

#define li unsigned long long
#define pb push
#define mp make_pair

#define INF (1000 * 1000 * 1000)
#define EPS (1e-9) 
#define PI2 1.57079632679489661923
#define PI  3.14159265358979323846
#define BASE 131072

using namespace std;

inline bool slower(double a, double b) {
	return abs(PI2 - a) > abs(PI2 - b);
}

inline bool eq(double a, double b) {
	return abs(PI2 - a) - abs(PI2 - b) < EPS;
}

int stack[100001];
int stc = 0;
double ang[100001];

int main(){
	freopen("race.in", "r", stdin);
	freopen("race.out", "w", stdout);
	int n;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		cin >> ang[i];
		char good = 1;
		while (stc && ang[stack[stc - 1]] < ang[i]) {
			if (slower(ang[stack[stc - 1]], ang[i]))
				--stc;
			else {
				good = 0;
				break;
			}
		}
		if (good)
			stack[stc++] = i;
	}
	cout << stc << endl;
	for (int i = 0; i < stc; ++i)
		cout << stack[i] + 1 << ' ';
}