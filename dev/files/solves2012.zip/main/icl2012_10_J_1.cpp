#pragma comment(linker,"/STACK:64000000")
#define _CRT_SECURE_NO_WARNINGS


#include <algorithm>
#include <ctime>
#include <cmath>
#include <iostream>
#include <memory.h>
#include <map>
#include <set>
#include <string>
#include <sstream>
#include <stdio.h>
#include <vector>

using namespace std;

#define RE scanf
#define WR printf
#define FI first
#define SE second
#define PB push_back
#define MP make_pair

#define FOR(i,a,b) for(int i = (a);i<=(b);i++)
#define DFOR(i,a,b) for(int i = (a);i>=(b);i--)
#define SZ(a) (int)((a).size())
#define FA(i,v) FOR(i,0,SZ(v)-1)
#define RFA(i,v) DFOR(i,SZ(v)-1,0)
#define CLR(a) memset(a,0,sizeof(a))

#define PAR pair<int,int>
#define LL long long
#define o_O 1000000000

void __never(int a) {printf("\nOPS %d\n",a);}
#define ass(f) {if (!(f)) {__never(__LINE__);cout.flush();cerr.flush();abort();}}

int n, m;
int bx, by, ex, ey;
map< PAR, int > bri;
char S[100500];
set< pair< PAR, PAR > > Set;
int dx[] = { 0, 0, 1, -1 };
int dy[] = { 1, -1, 0, 0 };

bool dfs(int x, int y, int last_x, int last_y)
{
	if (x==ex && y==ey) return true;
	if (Set.find(make_pair( make_pair(x, y), make_pair( last_x, last_y ) )) != Set.end()) return false;
	Set.insert( make_pair( make_pair(x, y), make_pair( last_x, last_y ) ) );

	bool flag = (last_x==x && last_y==y && bri[ make_pair(x,y) ] > 1);
	if (!(last_x==x && last_y==y) && bri[ make_pair(x,y) ] > 0) flag = true;
	if (flag)
		FOR(a,0,3)
		{
			int xx = x + dx[a];
			int yy = y + dy[a];
			if (1<=xx && xx<=n && 1<=yy && yy<=m)
				if (dfs(xx, yy, x, y))
					return true;
		}

	FOR(a,0,3)
	{
		int xx = x + dx[a];
		int yy = y + dy[a];
		if (last_x==xx && last_y==yy) 
		{
			if (bri[ make_pair(xx,yy) ] > 1)
				if (dfs( xx, yy, xx, yy ))
					return true;
		}
		else
		{
			if (bri[ make_pair(xx,yy) ] > 0)
				if (dfs( xx, yy, xx, yy ))
					return true;
		}		
	}

	return false;
}

void sol(){
	if (dfs( bx, by, -1, -1)) cout << "YES";
	else cout << "NO";
}
int main(){
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
	freopen("islands.in","r",stdin);
	freopen("islands.out","w",stdout);

	RE("%d%d", &n, &m);
	FOR(a,1,n)
	{
		RE("%s", &S[1]);
		FOR(b,1,m) bri[ make_pair(a,b) ] = S[b]-'0';
	}
	cin >> bx >> by >> ex >> ey;
	sol();
	return 0;
}
