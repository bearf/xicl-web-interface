import java.io.*;
import java.math.BigInteger;
import java.util.*;


public class Solution {

	/**
	 * @param args
	 */
	
	
	static Scanner in;
	static PrintWriter out; 
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		in = new Scanner(new FileReader("oranges.in")); 
		out = new PrintWriter(new FileWriter("oranges.out"));
		new Solution().sol();
		out.close();
	}

	
	int p;
	BigInteger n;
	
	BigInteger bp;
	BigInteger ps[];
	
	int mx;
	
	int rev(int x, int len) {
		return len - x - 1; 
	}
	
	void sol(){
		p = in.nextInt();
		n = in.nextBigInteger();
		
		bp = BigInteger.valueOf(p);
		
		ps = new BigInteger[10000];
		ps[0] = BigInteger.ONE;
		
		BigInteger nn = n.add(n);
		for (int i = 1;;i++) {
			ps[i] = ps[i-1].multiply(bp);
			if (ps[i].compareTo(nn) >= 0) {
				mx = i-1;
				break;
			}
		}
		
		
		long ans = 0;
		
		for (int a = 0;a<=mx;a++) 
			for (int b = a;b<=mx;b++) 
				if (ps[a].add(ps[b]).compareTo(n) >= 0) { 
					BigInteger k = ps[a].add(ps[b]).subtract(n);
					
					
					
					String d = k.toString(p);

					
					
					int len = d.length();
					
					/*if (d.equals("0"))
					{
						ans = (ans + 1) % 1000000007; 
						continue;
					}*/
					
					boolean flag = true;
					if (len > b) flag = false;
					
					for (int i = 0;i<Math.min(a,len);i++) {
						char ch = d.charAt(rev(i, len)); 
						if (!(ch == '0' || ch=='1' || ch=='2')) flag = false;	
					}
					

					for (int i = a;i<Math.min(b,len);i++) {
						char ch = d.charAt(rev(i, len)); 
						if (!(ch == '0' || ch=='1')) flag = false;	
					}
					
					if (!flag) continue;
					long tmp = 1; 					
					for (int i = 0;i<a;i++) if (d.charAt(rev(i, len))=='1')
						tmp = (tmp*2)%1000000007;
					
					ans = (ans + tmp) % 1000000007; 
					//out.printf("%d %d %s %d\n",a,b,d,ans);
				}
		
		out.print(ans);
	}
}
