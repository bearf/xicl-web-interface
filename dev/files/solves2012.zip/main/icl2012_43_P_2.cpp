#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <string>
#include <string.h>
#include <math.h>
#include <memory.h>
using namespace std;

#define li long long
#define pb push_back
#define mp make_pair
#define all(a) a.begin(), a.end()
#define _name "wire"

int main()
{
//	#ifdef _DEBUG
//cout<<_name<<'\n';
//freopen("input.txt", "r", stdin);
//#else
//freopen(_name".in", "r", stdin);
//freopen(_name".out", "w". stdout);
//#endif
freopen("wire.in", "r", stdin);
freopen("wire.out", "w", stdout);
  li i,j;
  li n;
  cin>>n;
  li x,y,xx,yy,xxx,yyy, res=0;
  cin>>x>>y>>xx>>yy;
  for(i=0;i<n-2;i++)
  {
	  cin>>xxx>>yyy;
	  if((xx-x)*(xxx-xx)+(yy-y)*(yyy-yy)==0)
		  res++;
	  x=xx,y=yy;
	  yy=yyy,xx=xxx;
  }
  cout<<res;
	return 0;
}