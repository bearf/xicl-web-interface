#pragma comment(linker,"/STACK:256000000")
#include <iostream>
#include <vector>
#include <map>
#include <set>
using namespace std;

int main(){
	//freopen("1.txt","r",stdin);
	freopen("changes.in","r",stdin);
	freopen("changes.out","w",stdout);
	int n;
	cin>>n;
	vector<int> a(n),b(n),c(n);
	for(int i=0;i<n;i++)
		cin>>a[i];
	for(int i=0;i<n;i++)
		cin>>b[i];
	set<pair<int,int> > s;
	set<pair<int,int> > ss;
	for(int i=0;i<n;i++){
		c[i]=a[i]-b[i];
		ss.insert(make_pair(a[i],i));		
		s.insert(make_pair(c[i],i));		
	}
	int k=n-1;
	int p=0;
	vector<int> t;
	while(!s.empty()){
		if(s.begin()->first>=p) break;
		p++;
		int g=-s.begin()->first;
		int i=s.begin()->second;
		s.erase(s.begin());
		if(ss.begin()->first<p) {
			cout<<-1<<endl;
			return 0;
		}
		ss.erase(ss.begin());
		a[i]+=n;
		ss.insert(make_pair(a[i],i));

		c[i]+=n;
		t.push_back(i+1);// cout<<i+1<<" ";
		s.insert(make_pair(-g+n,i));
	}
	cout<<t.size()<<endl;
	for(int i=0;i<t.size();i++)
		cout<<t[i]<<" ";
}






	