#include <cstdlib>
#include <cstdio>
#include <map>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int) n; ++i)
#define fs first;
#define sc second
#define mp make_pair
#define all(x) x.begin(), x.end()

typedef long long int64;
typedef pair <int, int> pii;

int gcd (int a, int b) {
	return a ? gcd (b % a, a) : b;
}

int n, k;
vector <int> a;

void calc_1 (int64 n, int64 x) {
	int64 a = x - 1;
	int64 b = n - x;
	int64 res = 1;
	int64 cur = 1;
	while (cur <= a || cur <= b) {
		int64 l = 0;
		int64 r = 1LL << 40;
		while (l < r) {
			int64 mid = (l + r + 1) / 2;
			int64 f = mid + cur;
			if (a / cur == a / f && b / cur == b / f)
				l = mid;
			else
				r = mid - 1;
		}
		res += (r+1) * ((a / cur + 1) * (b / cur + 1) - 1);
		cur += r + 1;
	}
	cout << res << endl;
}

int main()
{
	freopen("trees.in", "r", stdin);
	freopen("trees.out", "w", stdout);
	cin >> n >> k;
	a.resize (k);
	forn (i, k)
		scanf ("%d", &a[i]);
	sort (all (a));
	if (k == 1) {
		calc_1 (n, a[0]);
		return 0;
	}
	int d = a[1] - a[0];
	forn (i, k-1)
		d = gcd (d, a[i+1] - a[i]);
	int64 res = 0;
	int64 l = a[0]-1;
	int64 r = n-a.back();
	for (int i = 1; i * i <= d; i ++) {
		if (d % i == 0) {
		        int64 v = i;
			res += (l / v + 1) * (r / v + 1);
			if (i * i != d) {
			        int64 v = d/i;
				res += (l / v + 1) * (r / v + 1);
			}

		} 
	}
	cout << res << endl;			
	return 0;
}
