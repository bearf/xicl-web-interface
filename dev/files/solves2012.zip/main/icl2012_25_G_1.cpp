#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#include <queue>
#include <deque>
#include <stack>
#include <string>
#include <sstream>
#include <cstring>
#include <cmath>
#include <ctime>
#include <numeric>

using namespace std;

#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define re return
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int) (x).size())
#define sqr(x) ((x) * (x))
#define sqrt(x) sqrt(abs(x))
#define rep(i, n) for (int i= 0; i < (n); i++)
#define rrep(i, n) for (int i = (n) - 1; i >= 0; i--)
#define re return
#define y0 y2369
#define y1 y347256
#define fill(x, y) memset(x, y, sizeof(x))

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef vector<string> vs;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef double D;
typedef long double LD;

template <class T> T abs(T x) { re x > 0 ? x : -x;}

#define FILENAME "runaway"

int n;
int m;

int mas[6];
vi v[100500];
int col[100500];

string ss[3] = {"ALICE", "BOB", "CAESAR"};

queue<int> q;
queue<int> qq;

int a, b, c;

int dist[100500];
int ct;
int ww[100500];
int was[100500];
int ot;

int prev[100500];

int big = 1000000000;

void parseqq(int x) {
	rep(i, sz(v[x])) {
		int y = v[x][i];
		if (ww[y] != ct) {
			ww[y] = ct;
			qq.push(y);
			dist[y] = dist[x] + 1;
		}
	}	
}

int bfs(int x, int y) {
	ct++;
	dist[x] = 0;
	ww[x] = ct;
	qq.push(x);
	while (!qq.empty()) {
		parseqq(qq.front());		
		qq.pop();
	}	
	if (ww[y] == ct)
		re dist[y];
	else
		re big;	
}

int get(int x) {
	while (1) {
		if (prev[x] == -1)
			re x;
		if (was[x] != ot)
			re x;
		x = prev[x];	
	}
}

int got;
int gowas[100500];
int tt1[100500], tt2[100500];
int gtt;

void go(int x) {
 	gowas[x] = got;
	tt1[x] = gtt++;
//	cout << "go: " << x << endl;
	rep(i, sz(v[x])) {
		int y = v[x][i];
		if (was[y] != ot || gowas[y] == got)
			continue;
		go(y);
	}
	tt2[x] = gtt++;
}

int root(int a, int b) {
	re tt1[a] <= tt1[b] && tt2[a] >= tt2[b];
}	

int check(int p) {
	a = mas[p];
	b = mas[p + 1];
	c = mas[p + 2];

	if (!was[b])
		re 0;
	int r = get(b);

//	cout << a << ' ' << b << ' ' << c << ' ' << r << endl;

	gtt = 0;
	got++;
	go(r);

//	cout << r << endl;

	int t1 = bfs(a, r);
	int t2 = bfs(b, r);
	int t3 = bfs(c, r);

//	cout << t1 << ' ' << t2 << ' ' << t3 << endl;

	if (t1 == big)
		re 0;

	if (was[r] == ot && t3 == big)
		re 1;

	if (gowas[a] != got || gowas[b] != got)
		re t1 < t3 && t1 <= t2;

//	cout << tt1[4] << ' ' << tt2[4] << ' ' << tt1[0] << ' ' << tt2[0] << endl;	

	int cr = b;
	while (!root(cr, c))
		cr = prev[cr];

//	cout << "cr = " << cr << endl;	
	
	int l1 = bfs(a, cr);
	int l2 = bfs(b, cr);
	int l3 = bfs(c, cr);

	re l1 <= l2 && l1 < l3;
}

void parse(int x) {
	prev[x] = -1;
	//cout << "q: " << x << endl;
	rep(i, sz(v[x])) {
		int y = v[x][i];
		if (prev[y] != x) {
			prev[x] = y;
			//cout << x << ' ' << y << endl;
			col[y]--;
			if (col[y] <= 1 && was[y] != ot) {
				was[y] = ot;
				q.push(y);				
			}
		}
	}
}

void update() {
	ot++;
	rep(i, n)
		col[i] = sz(v[i]);
	rep(i, n) 
		if (col[i] == 1) {
			q.push(i);
			was[i] = ot;
		}	
	while (!q.empty()) {
		parse(q.front());
		q.pop();
	}		
}

int main() {
	freopen(FILENAME".in", "r", stdin);
	freopen(FILENAME".out", "w", stdout);

	fill(prev, -1);

	int tc;
	cin >> tc;
	rep(tt, tc) {
		scanf("%d%d", &n, &m);
		rep(i, n) {
			v[i].clear();
			prev[i] = -1;
		}	
		rep(i, m) {
			int a, b;
			scanf("%d%d", &a, &b);
			a--;
			b--;
			v[a].pb(b);
			v[b].pb(a);
		}		
		update();
		rep(i, 3) {
			scanf("%d", &mas[i]);	
			mas[i]--;
			mas[i + 3] = mas[i];
		}	

		int f = 0;

		rep(i, 3) {
			if (check(i)) {
				cout << ss[i] << endl;
				f = 1;
				break;
			}	
		}	
		if (!f)
			cout << "DRAW" << endl;
	}
	
	return 0;
}
