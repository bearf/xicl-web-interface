#include <cstdlib>
#include <cstdio>
#include <map>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int) n; ++i)
#define ford(i, n) for (int i = (int)n-1; i >= 0; --i)
#define fs first
#define sc second
#define mp make_pair
#define pb push_back
#define all(x) x.begin(), x.end()

typedef long long int64;
typedef pair <int, int> pii;

int64 P;
vector <int64> a, tmpa;
vector <int64> b;

vector <int64> read () {
	vector <int64> b;
	string s;
	cin >> s;
	forn (i, s.length())
		b.pb (s[i] - '0');
	reverse (all (b));
	vector <int64> res;
	res.clear ();
	while (b.size() > 0) {
		int64 o = 0;
		ford (i, b.size()) {
			o = o * 10 + b[i];
			b[i] = o / P;
			o %= P;
		}
		res.pb (o);
		while (b.size() > 0 && b.back() == 0)		
			b.pop_back();
	}
	return res;
}

int main()
{
	freopen("oranges.in", "r", stdin);
	freopen("oranges.out", "w", stdout);
	cin >> P;
	a = read ();
//	forn (i, a.size())
//		cerr << a[i] << endl;
	a.pb (0);
	a.pb (0);
	a.pb (0);
	int l = max ((int)a.size() - 6, 0);
	int r = a.size();
	a.pb (0);
	a.pb (0);
	int64 answer = 0;
	tmpa = a;
	for (int i = l; i <= r; i ++)
		for (int j = 0; j <= i; j ++) {
			a = tmpa;
//			cerr << "! ";
//			forn (k, a.size())
///				cerr << a[k] << " ";
//				cerr << endl;	
			bool ok = 0;
			for (int k = 0; k < (int) a.size(); k ++) {
				int64 d = 0;
				if (k == i)
					d ++;
				if (k == j)
					d ++;
				int m = 0;
				if (k < i)
					m ++;
				if (k < j)
					m ++;
				for (int w = 0; w <= m; w ++) {
					if (a[k] == d) {
					        if (w == 1 || i != j)
					        	ok = 1;
						break;	
					}
					if (w < m) {
						int pos = k;
						a[pos] ++;
						while (a[pos] >= P) {
							a[pos] -= P;
							a[pos+1] ++;
							pos ++;
						}
					}
				}
	//			cerr << a[k] << " ";
				if (a[k] != d) {
					ok = 0;
					break;
				}
			}
		//	cerr << endl;
			if (ok) {
				answer ++;
		//		cerr << i << " " << j << endl;
			}
		}
	cout << answer << endl;
	return 0;
}
