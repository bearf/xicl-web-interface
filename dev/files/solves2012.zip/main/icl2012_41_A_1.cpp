#include <iostream>
#include <vector>
#include <cassert>
#include <set>
#include <cstdio>
#include <map>
#include <deque>
#include <algorithm>

using namespace std;

#define forn(i, n) for (int i = 0; i < int(n); ++i)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; --i)
#define all(a) a.begin(), a.end()
#define fs first
#define sc second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef long double ld;

const string filename("bricks");

const ll nmax = 1000000100;

inline ll convert (int i, int j) {
	return (i + 2) * nmax + j + 30;
}

inline ll get_left (ll a) {
	return a + nmax;
}

inline ll get_right (ll a){
	return get_left(a) + 1;
}

inline ll get_left_up (ll a) {
	return a - nmax - 1;
}

set <ll> r;

int solve () {
	r.clear();
	int n, m;
	if (scanf("%d%d", &n, &m) != 2)
		return 1;
	vector <pair <int, int> > a(m);
	forn(i, m) {
		if (scanf("%d%d", &a[i].fs, &a[i].sc) != 2)
			return 1;
	}
	forn(i, m) {
		ll c = convert(a[i].fs, a[i].sc);
		r.insert(c);
		if (r.find(c - 1) != r.end() && r.find(get_left_up(c)) == r.end()) {
			printf("%d\n", i + 1);
			return 0;
		}
		if (r.find(c + 1) != r.end() && r.find(get_left_up(c) + 1) == r.end()) {
			printf("%d\n", i + 1);
			return 0;
		}
	}
	puts("-1");
	return 0;
}

int main () {
	#ifdef _LOCAL_MACHINE41
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
	while (!solve());
	#else
	freopen((filename + ".in").data(), "rt", stdin);
	freopen((filename + ".out").data(), "wt", stdout);
	solve();
	#endif
	return 0;
}
