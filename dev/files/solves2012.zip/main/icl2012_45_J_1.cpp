#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>
using namespace std;

#define TASK_NAME "islands"

const int dx[4] = {1, 0, -1, 0};
const int dy[4] = {0, -1, 0, 1};

vector < int > g[100005];
int bx[1000000], by[1000000], bWay[1000000];
bool f[1000000];
int n, m, xs, ys, xf, yf, bSize;

int getHash (int x, int y, int prevWay) {
	return (prevWay + 1) * 100000 + (x * m + y);
}

void bfs () {
	int i, hash, pls;
	int xCur, yCur, way, xNew, yNew;

	int cur = 0;

	while (cur < bSize) {
		xCur = bx[cur]; yCur = by[cur];
		way = bWay[cur];

		for (i = 0;i < 4;i++) {
			xNew = xCur + dx[i]; yNew = yCur + dy[i];

			if (xNew < 0 || xNew > n - 1 || yNew < 0 || yNew > m - 1)
				continue;

			hash = getHash(xNew, yNew, i);
			if (f[hash])
				continue;

			pls = 0;
			if (way < 4 && (way + 2) % 4 == i)
				pls = 1;

			if (g[xNew][yNew] - pls > 0) {
				if (xNew == xf && yNew == yf) {
					printf("YES");
					exit(0);
				}

				bx[bSize] = xNew;
				by[bSize] = yNew;
				bWay[bSize] = i;
				f[hash] = true;
				bSize++;
			}

			pls = 0;
			if (way == 4)
				pls = 1;

			if (g[xCur][yCur] - pls > 0) {
				if (xNew == xf && yNew == yf) {
					printf("YES");
					exit(0);
				}

				bx[bSize] = xNew;
				by[bSize] = yNew;
				bWay[bSize] = 4;
				f[hash] = true;
				bSize++;
			}
		}

		cur++;
	}

	printf("NO");
}

int main () {

#ifdef INPUT_VAR
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#else
	freopen(TASK_NAME ".in", "rt", stdin);
	freopen(TASK_NAME ".out", "wt", stdout);
#endif

	int i, j, xCur, yCur, xNew, yNew;
	char c;

	scanf("%d%d\n", &n, &m);
	for (i = 0;i < n;i++) {
		for (j = 0;j < m;j++) {
			scanf("%c", &c);
			g[i].push_back(c - '0');
		}
		scanf("\n");
	}
	scanf("%d%d\n", &xs, &ys);
	xs--; ys--;
	scanf("%d%d\n", &xf, &yf);
	xf--; yf--;

	if (xs == xf && ys == yf) {
		printf("YES");
		return 0;
	}

	bSize = 0;
	xCur = xs; yCur = ys;
	for (i = 0;i < 4;i++) {
		xNew = xCur + dx[i]; yNew = yCur + dy[i];

		if (xNew < 0 || xNew > n - 1 || yNew < 0 || yNew > m - 1)
			continue;

		if (g[xCur][yCur] + g[xNew][yNew] == 0)
			continue;

		if (xNew == xf && yNew == yf) {
			printf("YES");
			exit(0);
		}

		if (g[xCur][yCur] != 0) {
			bx[bSize] = xNew;
			by[bSize] = yNew;
			bWay[bSize] = i;
			f[getHash(xNew, yNew, i)] = true;
			bSize++;
		}

		if (g[xNew][yNew] != 0) {
			bx[bSize] = xNew;
			by[bSize] = yNew;
			bWay[bSize] = 4;
			f[getHash(xNew, yNew, 4)] = true;
			bSize++;
		}
	}

	bfs();

	return 0;
}