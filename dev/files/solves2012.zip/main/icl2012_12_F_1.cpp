import java.io.*;
import java.math.*;
import java.util.*;

public class Solution {
	
	public static final String FILENAME = "oranges";
	public static final int MAXN = 6000;
	
	long powmod(long x, long k, int mod) {
		long ans = 1;
		while (k > 0) {
			if ((k & 1) == 1) {
				k--;
				ans = (ans * x) % mod;
			} else {
				k >>= 1;
				x = (x * x) % mod;
			}
		}
		return ans;
	}
	
	void solve() throws IOException {
		int p = nextInt();
		BigInteger N = nextBigInteger();
		BigInteger P = BigInteger.valueOf(p);
		int[] a = new int[MAXN];
		int[] b = new int[MAXN];
		BigInteger K = N;
		int z = 0;
		for (; !K.equals(BigInteger.ZERO); z++) {
			a[z] = K.remainder(P).intValue();
			K = K.divide(P);
		}
		
		int n = z + 5;
		
		final int mod = 1000000007;
		long ans = 0;
		for (int l = z - 1; l <= z + 1; l++) {
			for (int k = 0; k <= l; k++) {
				for (int i = 0; i < n; i++) {
					b[i] = -a[i];
					if (i == k) b[i]++;
					if (i == l) b[i]++;
				}
				b[n]=0;
				for (int i = 0; i < n; i++) {
					if (b[i] < 0) {
						b[i+1]--;
						b[i] += p;
					}
				}
				
				boolean ok = b[n] == 0;
				for (int i = 0; i < k; i++) ok = ok && (0 <= b[i] && b[i] <= 2);
				for (int i = k; i < l; i++) ok = ok && (0 <= b[i] && b[i] <= 1);
				for (int i = l; i < n; i++) ok = ok && (b[i] == 0);
				if (!ok) continue;
				
				int ones = 0;
				for (int i = 0; i < k; i++) if (b[i] == 1) ones++;
				ones = ones - (k==l?1:0);
				if (ones >= 0) {
					ans += powmod(2, ones, mod);
					ans %= mod;
				}
			}
		}
		
		out.println(ans);
	}
	
	//----------------------------
	BufferedReader br;
	StringTokenizer _st;
	PrintWriter out;
	
	int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
	
	BigInteger nextBigInteger() throws IOException {
		return new BigInteger(next());
	}
	
	String next() throws IOException {
		if (_st == null || !_st.hasMoreTokens()) {
			String s = br.readLine();
			if (s == null) return null;
			_st = new StringTokenizer(s);
		}
		return _st.nextToken();
	}
	
	void run() {
		try {
			try {
				br = new BufferedReader(new FileReader(FILENAME + ".in"));
				out = new PrintWriter(FILENAME + ".out");
				solve();
			} finally {
				out.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		new Solution().run();
	}
}
