import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.StringTokenizer;

public class Solution {
	private static final String TASKNAME = "changes";

	private void solve() throws IOException {
		int n = nextInt();
		long[] a = new long[n];
		long[] b = new long[n];
		long sum = 0;
		for (int i = 0; i < n; ++i) {
			sum += a[i] = nextInt();
		}
		for (int i = 0; i < n; ++i) {
			sum -= b[i] = nextInt();
		}
		if (sum != 0) {
			println(-1);
			return;
		}
		
		long[] diff = new long[n];
		long diffMin = Long.MAX_VALUE;
		long dSum = 0;
		for (int i =0; i < n; ++i) {
			diff[i] = b[i] - a[i];
			diffMin = Math.min(diffMin, diff[i]);
		}
		for (int i = 0; i < n; ++i) {
			dSum += diff[i] - diffMin;
		}
//		System.err.println(dSum + " " + Arrays.toString(diff));
		long needAns = dSum / n; 
				 
		ArrayList<Integer> ans = new ArrayList<Integer>();
		it: for (int it = 0; it < 50000; ++it) {
			long min = Long.MAX_VALUE;
			int minPos = -1;
			for (int i = 0; i < n; ++i) {
				if (a[i] < b[i] && a[i] < min) {
					min = a[i];
					minPos = i;
				}
			}
			if (minPos < 0) {
				break;
			}
			for (int i = 0; i < n; ++i) {
				if (i != minPos && a[i] == 0) {
					break it;
				}
			}
				
//			if (min == 0) {
//				break;
//			}
			for (int i = 0; i < n; ++i) {
				--a[i];
			}
			a[minPos] += n;
			ans.add(minPos + 1);
			for (int i = 0; i < n; ++i) {
				if (a[i] < 0) {
					throw new AssertionError();
				}
			}
		}
		
		
		for (int i = 0; i < n; ++i) {
			if (a[i] != b[i]) {
				println(-1);
				return;
			}
		}
		println(ans.size());
		if (ans.size() != needAns) {
			throw new AssertionError(needAns + " " + ans.size());
		}
		for (int i : ans) {
			print(i + " ");
		}
		println("");
	}

	public static void main(String[] args) {
		long time = System.currentTimeMillis();
		Locale.setDefault(Locale.US);
		new Solution().run();
		System.err.printf("%.3f\n", 1e-3 * (System.currentTimeMillis() - time));
	}

	private StringTokenizer tokenizer;
	private BufferedReader reader;
	private PrintWriter writer;

	private String nextToken() throws IOException {
		while (tokenizer == null || !tokenizer.hasMoreTokens()) {
			tokenizer = new StringTokenizer(reader.readLine());
		}
		return tokenizer.nextToken();
	}

	private int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	private long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	private double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	private void print(Object o) {
		writer.print(o);
	}

	private void println(Object o) {
		writer.println(o);
	}

	private void printf(String format, Object... o) {
		writer.printf(format, o);
	}

	private void run() {
		try {
			reader = new BufferedReader(new FileReader(TASKNAME + ".in"));
			writer = new PrintWriter(TASKNAME + ".out");

			solve();

			reader.close();
			writer.close();

		} catch (IOException e) {
			e.printStackTrace();
			System.exit(13);
		}
	}
}
