import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Scanner;

public class Solution {
	public void run(Scanner input, PrintWriter output) {
//		Locale.setDefault(Locale.US);
		input.useLocale(Locale.US);
		int n = input.nextInt();
		double[] as = new double[n];
		int[] nums = new int[n];
		int count = 0;
		for (int i = 0; i < n; i++) {
			double a = input.nextDouble();

			boolean add = false;
			while (count > 0) {
				int r = calc(as[count - 1], a);
				if (r == 0) {
					add = true;
					break;
				} else if (r == 1) {
					count--;
				} else if (r == -1) {
					break;
				}
			}
			if (count == 0 || add) {
				// add
				as[count] = a;
				nums[count] = i + 1;
				count++;
			}
		}
		output.println(count);
		output.print(nums[0]);
		for (int i = 1; i < count; i++) {
			output.print(" " + nums[i]);
		}
	}

	public static final double EPS = 1e-7;

	public static int calc(double a1, double a2) {
		if (a1 > a2 - EPS) {
			return 0;
		}
		if (Math.min(a1, Math.PI - a1) < a2 && a2 < Math.max(a1, Math.PI - a1)) {
			return 1;
		}
		return -1;
	}

	public static void main(String[] args) throws FileNotFoundException {
//		Scanner input = new Scanner(System.in);
//		PrintWriter output = new PrintWriter(System.out);
		Scanner input = new Scanner(new File("race.in"));
		PrintWriter output = new PrintWriter(new File("race.out"));


		new Solution().run(input, output);

		input.close();
		output.close();
	}
}
