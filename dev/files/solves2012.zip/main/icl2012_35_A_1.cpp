#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cassert>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <string>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define _(a, b) memset(a, b, sizeof(a))

typedef long long lint;
typedef unsigned long long ull;

const int INF = 1000000000;
const lint LINF = 4000000000000000000ll;
const double eps = 1e-9;

void prepare(string file)
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#else
	freopen((file + ".in").c_str(), "r", stdin);
	freopen((file + ".out").c_str(), "w", stdout);
#endif
}

int n, k;

set< pair<int, int> > p;

bool exist(int x, int y)
{
	if (y >= 1 && y <= n && x >= 1 && x <= n - y + 1)
	{
		if (p.find( mp(x, y) ) == p.end())
			return false;
		else
			return true;
	}
	else
		return false;
}

void kill(int x, int y)
{
	p.insert( mp(x, y) );
}

bool solve()
{
	scanf("%d%d", &n, &k);
	for (int i = 0; i < k; i++)
	{
		int x, y;
		scanf("%d%d", &x, &y);

		if (!exist(x - 1, y) && exist(x - 1, y + 1))
		{
			printf("%d\n", i + 1);
			return false;
		}

		if (!exist(x + 1, y) && exist(x, y + 1))
		{
			printf("%d\n", i + 1);
			return false;
		}

		kill(x, y);
	}

	printf("-1\n");

	return false;
}

int main()
{
	prepare("bricks");
	while (solve());
	return false;
}