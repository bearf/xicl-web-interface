#pragma comment(linker,"/STACK:256000000")
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <math.h>
using namespace std;
int main(){
	//freopen("1.txt","r",stdin);
	freopen("race.in","r",stdin);
	freopen("race.out","w",stdout);
	int n;
	cin>>n;
	double pi=acos(-1.0)/2;
	set<pair<double,int> > s;
	for(int i=0;i<n;i++){
		double a;
		cin>>a;
		if(s.empty()){
			s.insert(make_pair(a,-i));
			continue;
		}
		int h=1,in=0;
		while(!s.empty() && h){
			h=0;
			double d;
			int j;
			d=s.begin()->first;
			j=-s.begin()->second;
			if(d>pi){
				if(a>pi)
					if(d>=a) in=1;
					else in=0;
				if(a<=pi) in=1;
			}
			if(d==pi)
				if(a<=pi) in=1;
				else in=0;
			if(d<pi){
				if(a>pi){
					if(fabs(d-pi)>fabs(a-pi)){
						in=1;
						s.erase(s.begin());
						h=1;
					}
					else in=0;
				}
				if(a==pi){
						in=1;
						s.erase(s.begin());
						
						h=1;
					}
				if(a<pi){
					if(a<=d) in=1;
					if(a>d){
						in=1;
						s.erase(s.begin());
						
						h=1;
					}
				}
			}
		}
			if(in) s.insert(make_pair(a,-i));
		
	}
	cout<<s.size()<<endl;
	while(!s.empty()){
		cout<<(-s.begin()->second)+1<<" ";
		s.erase(s.begin());
	}
		
	
}
				



	





