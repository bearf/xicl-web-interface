#include <cstdio>
#include <cstring>
#include <cmath>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <iostream>
#include <fstream>
#include <set>

#define mp make_pair
#define pb push_back
#define zero(a) memset(a, 0, sizeof(a))
#define SZ(a) ((int)(a.size()))
#define sqr(a) ((a)*(a))
                
typedef long long ll;
typedef long double ld;

#define taskname "millenium"

using namespace std;

int n;
long long a, b;
pair <int, pair <long long, int> > A[110000];
multiset <pair <long long, int> > S; 
pair <int, int> cp;
multiset <pair <long long, int> > :: iterator it;

bool check (long long t)
{
  S.clear();
  //cerr<<"@#$%RTYH "<<t<<endl;
  int j, cid=0;
  long long ct;
  for (int i=0; i<n; i=j)
  {
   // cerr<<t<<" "<<i<<" "<<A[i].first<<"  "<<n<<endl;
    j=i, cid=A[i].first, ct=-t;
    while (A[j].first==A[i].first)
      S.insert(A[j].second), j++;
    //cerr<<S.size()<<"  !!!!!!!!! "<<endl;
    while (S.size() && cid<A[j].first)
    {
      //cerr<<cid<<endl;
      while (S.size())
      {
        it=S.lower_bound(mp(ct,-1));
        if (it==S.end())
          break;
        //cerr<<"!!!  "<<cid<<"  "<<ct<<"   "<<it->first<<" "<<it->second<<endl;
        if (it->second<cid)
          return 0;
        //cerr<<cid<<"  "<<it->second<<endl;
        ct++;
        S.erase(it);
        if (ct>0)
          break;
      }
      cid++, ct=-t;
    }
  }
  if (S.size())
    return 0;
  return 1;
}

int main (void)
{
  long long x, y, l, r;
  int i;
  freopen (taskname".in", "rt", stdin);
  freopen (taskname".out", "wt", stdout);
  scanf("%d%I64d%I64d", &n, &a, &b);
  for (i=0; i<n; i++)
    scanf("%I64d%I64d", &x, &y), A[i]=mp(max(0ll,x-y-a),mp(-y+1ll,min(b-1ll,x+y-a-2ll)));// cerr<<A[i].first<<" "<<A[i].second.first<<" "<<A[i].second.second<<endl;
  sort(A,A+n);
  A[n].first=b;
  l=-1, r=(long long)1e10;
  while (r-l>1ll)
    check((r+l)/2ll)?(r=(r+l)/2ll):(l=(r+l)/2ll);
  cout<<r<<endl;
  return 0;
}


