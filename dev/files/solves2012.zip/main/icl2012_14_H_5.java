import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.StringTokenizer;

public class Solution {
	private static final String TASKNAME = "trees";

	long gcd(long a, long b) {
		return b == 0 ? a : gcd(b, a % b);
	}
	
	private void solve() throws IOException {
		
		int n = nextInt();
		int k = nextInt();
		long[] a = new long[k];
		for (int i = 0; i < k; ++i) {
			a[i] = nextInt();			
		}
		Arrays.sort(a);
		if (k == 1) {
			println(sol(a[0], n));
			return;
		}
		
		long g = a[1] - a[0];
		for (int i = 1; i < k - 1; ++i) {
			g = gcd(g, a[i + 1] - a[i]);
		}

		
		
				
		BigInteger ans = BigInteger.ZERO;
		for (int i = 1; i * i <= g; ++i) {
			if (g % i == 0) {
				ans = ans.add(cnt(a[0], a[k - 1], n, i));
				ans = ans.add(cnt(a[0], a[k - 1], n, g / i));
				if (i * i == g) {
					ans = ans.subtract(cnt(a[0], a[k - 1], n, i));
				}
			}
		}
		println(ans);
				
	}

	long upDiv(long a, long b) {
		return (a + b - 1) / b;
	}
	
	long findMin(long a, int t) {
		long up = a + 1;
		long down = 1;
		if (a < t) {
			return -1;
		}
		while (up - down > 1) {
			long mid = (up + down) / 2;
			if ((a + mid - 1) / mid > t) {
				down = mid;
			} else {
				up = mid;
			}
		}
		return upDiv(a, down) <= t ? down : up;
	}	
	private BigInteger sol(long a, long n) {
		int size = (int)1e4;
		
		long[] f = new long[size];
		long[] g = new long[size];
		
		int F  = (int)a;
		int G = (int)(n - a + 1);
		f[0] = n + 1;
		for (int i = 1; i <= F && i < f.length; ++i) {
			f[i] = findMin(F, i);
		}
		g[0] = n + 1;
		for (int i = 1; i <= G && i < g.length; ++i) {
			g[i] = findMin(G, i);
		}
		int lastF = Math.min(f.length - 1, F);
		int lastG = Math.min(g.length - 1, G);
		
		long nextVal = 0;
		BigInteger ans = BigInteger.ZERO;
		for (int i = 1; i < n - a + 1 || i < a; ) {
//			System.out.println(i);
			if (i == f[lastF] || i == g[lastG]) {
				nextVal = Math.min(lastF > 0 ? f[lastF - 1] : f[lastF],
									lastG > 0 ? g[lastG - 1] : g[lastG]);
				ans = ans.add(
						BigInteger.valueOf(nextVal - i).multiply((cnt(a, a, n, i).subtract(BigInteger.ONE)))
						);
				lastF = lastF > 0 && f[lastF - 1] == nextVal ? lastF - 1 : lastF;
				lastG = lastG > 0 && g[lastG - 1] == nextVal ? lastG - 1 : lastG;
				i = (int)nextVal;
			} else {
				ans = ans.add(cnt(a, a, n, i).subtract(BigInteger.ONE)); 
				++i;
			}						
		}
		return ans.add(BigInteger.ONE);		
	}

	private BigInteger cnt(long a, long b, long n, long d) {
		return BigInteger.valueOf(((a + d - 1) / d)).multiply(BigInteger.valueOf(((n - b + 1 + d - 1) / d)));
	}
	// (a + d - 1) / d * (n - b + 1 + d - 1) / d

	public static void main(String[] args) {
		long time = System.currentTimeMillis();
		Locale.setDefault(Locale.US);
		new Solution().run();
		System.err.printf("%.3f\n", 1e-3 * (System.currentTimeMillis() - time));
	}

	private StringTokenizer tokenizer;
	private BufferedReader reader;
	private PrintWriter writer;

	private String nextToken() throws IOException {
		while (tokenizer == null || !tokenizer.hasMoreTokens()) {
			tokenizer = new StringTokenizer(reader.readLine());
		}
		return tokenizer.nextToken();
	}

	private int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	private long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	private double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	private void print(Object o) {
		writer.print(o);
	}

	private void println(Object o) {
		writer.println(o);
	}

	private void printf(String format, Object... o) {
		writer.printf(format, o);
	}

	private void run() {
		try {
			reader = new BufferedReader(new FileReader(TASKNAME + ".in"));
			writer = new PrintWriter(TASKNAME + ".out");

			solve();

			reader.close();
			writer.close();

		} catch (IOException e) {
			e.printStackTrace();
			System.exit(13);
		}
	}
}
