#define _CRT_SECURE_NO_DEPRECATE

#pragma comment(linker, "/STACK:32000000")

#define y1 y1_______

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <algorithm>
#include <string>
#include <string.h>
#include <set>
#include <map>

#undef y1

using namespace std;

#define pb push_back
#define mp make_pair
#define fi(a,b) for(i=a;i<=b;i++)
#define fj(a,b) for(j=a;j<=b;j++)
#define fo(a,b) for(o=a;o<=b;o++)
#define fdi(a,b) for(i=a;i>=b;i--)
#define fdj(a,b) for(j=a;j>=b;j--)
#define fdo(a,b) for(o=a;o>=b;o--)

typedef long long int64;

#define TASK "islands"

#define MAX 100010

int n, m;

vector <vector <int> > matr;
char str[MAX];

int x1, y1, x2, y2;

vector <vector <vector <int> > > color;

int dx[] = {-1,0,1,0};
int dy[] = {0,-1,0,1};

bool Field(int x, int y) {
	if (x < 1 || x > n) return false;
	if (y < 1 || y > m) return false;
	return true;
}

void dfs(int x, int y, int f) {
	int x2, y2;
	int i;
	if (x == ::x2 && y == ::y2) {
		printf("YES\n");
		exit(0);
	}
	if (color[y][x][f]) return;
	color[y][x][f] = 1;

	fi(0, 3) {
		x2 = x + dx[i];
		y2 = y + dy[i];
		if (!Field(x2, y2)) continue;
		if (matr[y2][x2] > 0) {
			dfs(x2, y2, 0);
		}
		if (matr[y][x] == 1 && f == 1 || matr[y][x] > 1) {
			dfs(x2, y2, 1);
		}
	}
	
}

int main() {
	int i, j;
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
	scanf("%d %d", &m, &n);
	matr.resize(m + 1);
	color.resize(m + 1);
	fi(1, m) {
		matr[i].resize(n + 1);
		color[i].resize(n + 1);
	}

	fj(1, m) {
		fi(1, n) {
			color[j][i].resize(2);
		}
	}
	fj(1, m) {
		scanf("%s", str + 1);
		fi(1, n) {
			matr[j][i] = str[i] - '0';
		}
	}

	scanf("%d %d", &y1, &x1);
	scanf("%d %d", &y2, &x2);

	dfs(x1, y1, 1);

	printf("NO\n");
	return 0;
}