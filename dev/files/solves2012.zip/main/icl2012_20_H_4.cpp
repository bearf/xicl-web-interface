#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <ctime>
#include <string>
#include <queue>
#include <string.h>

#define li unsigned long long
#define pb push
#define mp make_pair

#define INF (1000LL * 1000LL * 100000LL)
#define EPS (1e-9) 

using namespace std;

li gcd(li x, li y){
	if (y == 0) return x; else return gcd(y, x % y);
}

li a[100100], n, m;

li get(li p, li l){
	if (l == 0) return INF;
	return p / l + 1;
}

int main(){
	//freopen("trees.in", "r", stdin);
	//freopen("trees.out", "w", stdout);
	cin >> m >> n;
	li i;
	m--;
	for (i = 0; i < n; i++) {
		cin >> a[i];
		a[i]--;
	}
	li p = a[0];

	if (m == 2 && n == 1 && a[0] == 1){
		cout << 4 << endl;
		return 0;
	}
	
	if (n > 1){
		li cur = a[1] - a[0], l, r, res = 0;
		l = a[0]; r = m - a[n-1];
		for (i = 2; i < n; i++) cur = gcd(cur, a[i] - a[i-1]);
		//cerr << cur << endl;
		li d1, d2;
		for (i = 1; i <= floor(sqrt(double(cur)) + EPS); i++)
			if (cur % i == 0){
				d1 = i;
				d2 = cur / i;
				//cerr << d1 << ' ' << d2 << endl;
				res += (l / d1 + 1) * (r / d1 + 1);
				if (d1 != d2){
					res += (l / d2 + 1) * (r / d2 + 1);
				}
			}
		cout << res << endl;
		return 0;
	} else {
		while (true) n++;
		n = m;
		//cerr << p << endl;
		li l = p, r = n - p;
		m = 1;
		li res = 1;
		
		//cerr << l << ' ' << r << endl;

		while (l && r){
			li nm = min(get(p, l), get(n - p, r));
			res += ((l + 1) * (r + 1) - 1) * (nm - m);
			m = nm;
			l = p / m;
			r = (n - p) / m;
		}
		cout << res << endl;
	}
}