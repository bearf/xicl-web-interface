#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <set>
#include <string>
#include <vector>

using namespace std;

#define forn(i,n) for (int i = 0; i < (n); i++)
#define forit(it,v) for (typeof((v).end()) it = (v).begin(); it != (v).end(); ++it)
#define sz(v) ((int)((v).size()))
typedef long long LL;
typedef long long ll;
typedef pair<int, int> ii;

#define TASK "bricks"

int main() {
	assert(freopen(TASK ".in", "r", stdin));
	assert(freopen(TASK ".out", "w", stdout));
	int n, k;
	scanf("%d%d", &n, &k);
	set<ii> s;
	forn(i, k) {
		int x, y;
		scanf("%d%d", &x, &y);
		int u = 0;
		u |= (y > 1 && s.count(ii(x, y-1)) && x > 1 && !s.count(ii(x-1, y-1)));
		u |= (y < x && s.count(ii(x, y+1)) && x > 1 && !s.count(ii(x-1, y+1)));
		if (u) return 0 * printf("%d\n", i + 1);
		s.insert(ii(x, y));
	}
	return 0;
}
