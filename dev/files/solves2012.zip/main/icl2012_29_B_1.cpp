#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#include <map>


#pragma comment(linker,"/STACK:146000000")


using namespace std;


pair<int, int>* dp[32][32][32][32];
int ar[32][32];
pair<int, int> tmp[1046];


bool better(pair<int, int> * a, pair<int, int> * b, int len)
{
	for(int i = 0; i < len; i++)
		if(a[i].second != b[i].second)
			return a[i].second < b[i].second;
	return false;
}


void relax(pair<int, int> * to, pair<int, int> * a, pair<int, int> * b, int incval, int l1, int l2)
{                                                      
	int p1 = 0;
	int p2 = 0;
	int cur = 0;
	int d1 = 0;
	int d2 = 0;
	while(p1 < l1 || p2 < l2)
	{
		if(p1 == l1 || (p2 != l2 && b[p2].first < a[p1].first))
		{
			tmp[cur] = b[p2];
			tmp[cur].second += d1;
			d2 = b[p2].second;
			p2++;
		}        
		else
		{
			tmp[cur] = a[p1];
			tmp[cur].second += d2;
			d1 = a[p1].second;
			p1++;
		}                     
		cur++;
		tmp[cur - 1].second++;
	}
//	printf("cmp:");
//	for(int i = 0; i < cur; i++)
//		printf("(%d %d) ", tmp[i].first, tmp[i].second);
//	printf("\nto:");
//	for(int i = 0; i < cur; i++)
//		printf("(%d %d) ", to[i].first, to[i].second);
//	printf("\n");
	if(better(tmp, to, cur))
	{
		for(int i = 0; i < cur; i++)
			to[i] = tmp[i];
	}                                                  
}


void countDp(int a, int b, int c, int d)
{
//	printf("%d %d %d %d\n", a, b, c, d);
	if(dp[a][b][c][d] != NULL)
	{
		return;
	}
	dp[a][b][c][d] = new pair<int, int>[(c - a) * (d - b)];
	if((c - a) * (d - b) == 1)
	{
		dp[a][b][c][d][0] = make_pair(ar[a][b], 0);                     
		return;
	}
	for(int i = 0; i < (c - a) * (d - b); i++)
		dp[a][b][c][d][i] = make_pair(100146, 100146);
	int x = a;
	int y = b;                           
	for(int i = a; i < c; i++)
		for(int j = b; j < d; j++)
			if(ar[i][j] < ar[x][y])
			{
				x = i;
				y = j;
			}
	if(x != a)
	{
		countDp(a, b, x, d);
		countDp(x, b, c, d);
		relax(dp[a][b][c][d], dp[a][b][x][d], dp[x][b][c][d], ar[x][y], (x - a) * (d - b), (c - x) * (d - b));
	}

	if(x != c - 1)
	{
		countDp(a, b, x + 1, d);
		countDp(x + 1, b, c, d);
		relax(dp[a][b][c][d], dp[a][b][x + 1][d], dp[x + 1][b][c][d], ar[x][y], (x + 1 - a) * (d - b), (c - x - 1) * (d - b));
	}

	if(y != b)
	{
		countDp(a, b, c, y);
		countDp(a, y, c, d);
		relax(dp[a][b][c][d], dp[a][b][c][y], dp[a][y][c][d], ar[x][y], (c - a) * (y - b), (c - a) * (d - y));
	}


	if(y != d - 1)
	{
		countDp(a, b, c, y + 1);
		countDp(a, y + 1, c, d);
		relax(dp[a][b][c][d], dp[a][b][c][y + 1], dp[a][y + 1][c][d], ar[x][y], (c - a) * (y + 1 - b), (c - a) * (d - y - 1));
	}

}


int main()
{
	freopen("cuts.in","r",stdin);
	freopen("cuts.out","w",stdout);
	int n, m;
	scanf("%d%d", &n, &m);
	for(int i = 0; i < n; i++)
		for(int j = 0; j < m; j++)
			scanf("%d", &ar[i][j]);
	for(int i = 0; i <= n; i++)
		for(int j = 0; j <= m; j++)
			for(int k = 0; k <= n; k++)
				for(int l = 0; l <= m; l++)
					dp[i][j][k][l] = NULL;
	countDp(0, 0, n, m);
	for(int i = 0; i < n * m; i++)
		printf("%d ", dp[0][0][n][m][i].second);
}