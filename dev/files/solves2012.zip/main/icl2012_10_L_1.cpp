#pragma comment(linker,"/STACK:64000000")
#define _CRT_SECURE_NO_WARNINGS


#include <algorithm>
#include <ctime>
#include <cmath>
#include <iostream>
#include <memory.h>
#include <map>
#include <set>
#include <string>
#include <sstream>
#include <stdio.h>
#include <vector>

using namespace std;

#define RE scanf
#define WR printf
#define FI first
#define SE second
#define PB push_back
#define MP make_pair

#define FOR(i,a,b) for(int i = (a);i<=(b);i++)
#define DFOR(i,a,b) for(int i = (a);i>=(b);i--)
#define SZ(a) (int)((a).size())
#define FA(i,v) FOR(i,0,SZ(v)-1)
#define RFA(i,v) DFOR(i,SZ(v)-1,0)
#define CLR(a) memset(a,0,sizeof(a))

#define PAR pair<int,int>
#define LL long long
#define o_O 1000000000

void __never(int a) {printf("\nOPS %d\n",a);}
#define ass(f) {if (!(f)) {__never(__LINE__);cout.flush();cerr.flush();abort();}}







#define MN 100500


double eps = 1e-9;
bool ls(double a, double b) {
	return b - a > eps;
}


int n;
double m[MN];
int dir[MN];

double mal[MN];
double mar[MN];

double PPPI = 3.1415926535897932384626433832795;
double a90 = PPPI * 0.5;

bool kill[MN];
void sol(){
	cin >> n;
	FOR(i,1,n) RE("%lf",&m[i]);
	
	FOR(i,1,n) {
		if (m[i] > a90) {
			dir[i] = 0;
			m[i] = PPPI - m[i];
		} else {
			dir[i] = 1;
		}
	}


	mal[0] = 0.;
	FOR(i,1,n) mal[i] = max(mal[i-1], m[i]);
	mar[n+1] = 0.;
	DFOR(i,n,1) mar[i] = max(mar[i+1], m[i]);


	FOR(i,1,n) {
		if (dir[i] == 0) {
			if (ls(m[i], mal[i-1])) kill[i] = true;
		} else {
			if (ls(m[i], mar[i+1])) kill[i] = true;
		}
	}

	int co = 0;
	FOR(i,1,n) if (!kill[i]) co++;

	cout << co << endl;
	FOR(i,1,n) if (!kill[i]) WR(" %d",i);

}
int main(){
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
	
	freopen("race.in","r",stdin);
	freopen("race.out","w",stdout);
	sol();
	return 0;
}
