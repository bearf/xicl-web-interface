#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <string>
#include <map>
#include <cmath>

#pragma comment(linker,"/STACK:146000000")
using namespace std;

const int N = 100100;
const double eps = 1e-8;
const double PI = 3.1415926535897932384626433832795;

bool Equal(double a, double b)
{
	return fabs(a-b) < eps;
}

bool Less(double a, double b)
{
	return a < b && !Equal(a, b);
}

bool Great(double a, double b)
{
	return a > b && !Equal(a, b);
}


int n;
double angle[N];

struct Maximizer
{
	double arr[1<<18];

	Maximizer()
	{
		for (int i = 0; i < (1<<18); i++)
			arr[i] = 0;
	}

	void SetValue(int pos, double val)
	{
		pos += (1<<17);
		arr[pos] = val;
		while (pos > 1)
		{
			pos /= 2;
			arr[pos] = max(arr[pos*2], arr[pos*2+1]);
		}
	}

	double GetValue(int l, int r)
	{
		l += (1<<17);
		r += (1<<17);
		double val = 0;
		while (l <= r)
		{
			if (l % 2 == 1)
				val = max(val, arr[l]);
			if (r % 2 == 0)
				val = max(val, arr[r]);
			l = (l+1) / 2;
			r = (r-1) / 2;
		}
		return val;
	}
} mx;

struct Minimizer
{
	double arr[1<<18];

	Minimizer()
	{
		for (int i = 0; i < (1<<18); i++)
			arr[i] = PI;
	}

	void SetValue(int pos, double val)
	{
		pos += (1<<17);
		arr[pos] = val;
		while (pos > 1)
		{
			pos /= 2;
			arr[pos] = min(arr[pos*2], arr[pos*2+1]);
		}
	}

	double GetValue(int l, int r)
	{
		l += (1<<17);
		r += (1<<17);
		double val = PI;
		while (l < r)
		{
			if (l % 2 == 1)
				val = min(val, arr[l]);
			if (r % 2 == 0)
				val = min(val, arr[r]);
			l = (l+1) / 2;
			r = (r-1) / 2;
		}
		return val;
	}
} mn;

void Scan()
{
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%lf", &angle[i]);
	}
}

bool ans[N];

void Solve()
{
	for (int i = 0; i < n; i++)
	{
		if (Less(angle[i], PI/2))
			mx.SetValue(i, angle[i]);
		else
			mn.SetValue(i, angle[i]);
	}
	for (int i = 0; i < n; i++)
	{
		ans[i] = true;
		if (Less(angle[i], PI/2))
		{
			if (i < n)
			{
				double x;
				x = mn.GetValue(i+1, n-1);
				if (Great(PI-angle[i], x)) ans[i] = false;
				x = mx.GetValue(i+1, n-1);
				if (Great(x, angle[i])) ans[i] = false;
			}
		}
		else
		{
			if (i > 0)
			{
				double x;
				x = mn.GetValue(0, i-1);
				if (Great(angle[i], x)) ans[i] = false;
				x = mx.GetValue(0, i-1);
				if (Great(x, PI-angle[i])) ans[i] = false;
			}
		}
	}
}

void Print()
{
	int cnt = 0;
	for (int i = 0; i < n; i++)
		if (ans[i])
			cnt++;
	printf("%d\n", cnt);
	for (int i = 0; i < n; i++)
		if (ans[i])
			printf("%d ", i+1);
	printf("\n");
}

int main()
{
	freopen("race.in","r",stdin);
	freopen("race.out","w",stdout);
	Scan();
	Solve();
	Print();
	return 0;
}