#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;

int n, k, i, res;
vector <int> a, b;

bool str(int k) {
	if (a[k - 2] == a[k - 1] && a[k - 1] == a[k])
		return true;
	if (b[k - 2] == b[k - 1] && b[k - 1] == b[k])
		return true;
	return false;
}
int main(){
	freopen("wire.in", "r", stdin); freopen("wire.out", "w", stdout);
	//freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
	cin >> n;
	a.resize(n); 
	b.resize(n);
	for (i = 0; i < n; i++) {
		cin >> a[i] >> b[i];
	}
	res = 0;
	for (i = 2; i < n; i++) {
		if (!str(i))
			res++;
	}
	cout << res;
	return 0;
}