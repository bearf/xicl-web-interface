#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <set>
#include <string>
#include <vector>

using namespace std;

#define forn(i,n) for (int i = 0; i < (n); i++)
#define forit(it,v) for (typeof((v).end()) it = (v).begin(); it != (v).end(); ++it)
#define sz(v) ((int)((v).size()))
#define eprintf(...) {fprintf(stderr,__VA_ARGS__); fflush(stderr);}
typedef long long LL;
typedef long long ll;
typedef pair<int, int> ii;

#define TASK "islands"
const int maxn = 2*(int)1e5;

int n,m;
char str[maxn];
int vis[maxn*2];
int dx[] = {-1,1,0,0};
int dy[] = {0,0,-1,1};

int check(int c,int r) {
	return c >= 0 && c < n && r >= 0 && r < m;
}

void dfs(int c, int r, int flag ) {
	if( str[c*m+r]-'0'-flag < 0 ) return ;
	//eprintf("%d %d %d\n",c,r,flag);
	int s = (c*m+r)*2+flag;
	if( vis[s] ) return ;
	vis[s] = 1;
	forn(k,4) {
		if( check(c+dx[k], r+dy[k]) ) {
			dfs(c+dx[k], r+dy[k],1);
			if(str[s/2]-'0' - flag > 0 ) dfs(c+dx[k],r+dy[k],0);
		}
	}
}
 
int main() {
	assert(freopen(TASK ".in", "r", stdin));
	assert(freopen(TASK ".out", "w", stdout));
	scanf("%d %d",&n,&m);
	memset(vis, 0, sizeof vis);
	forn(i, n) {
		scanf("%s",str+i*m);
	}
	str[n*m] = 0;
	//printf("%s\n",str);
	int aa,ab;
	scanf("%d%d",&aa,&ab);
	aa--,ab--;
	dfs(aa,ab,0);
	int ba,bb;
	scanf("%d%d",&ba,&bb);
	ba--,bb--;
	if( vis[(ba*m+bb)*2+1] || vis[(ba*m+bb)*2]) {
		printf("YES\n");
	}else {
		printf("NO\n");
	}
	return 0;
}
