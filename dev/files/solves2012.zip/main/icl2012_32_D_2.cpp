#include <cstdlib>
#include <cstdio>
#include <map>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int) n; ++i)
#define ford(i, n) for (int i = (int)n-1; i >= 0; --i)
#define fs first
#define sc second
#define x first
#define y second
#define mp make_pair
#define pb push_back
#define all(x) x.begin(), x.end()
#define seta(x,y) memset (x, y, sizeof (x))

typedef long long int64;
typedef pair <int, int> pii;

int n;
int64 a, b;
map <int64, int> M;
vector <pair <int64, int> > A;

int main()
{
	freopen("millenium.in", "r", stdin);
	freopen("millenium.out", "w", stdout);
	cin >> n >> a >> b;
	forn (i, n) {
		unsigned int x, y;
		scanf ("%u%u", &x, &y);
		int64 X, Y;
		X = x;
		Y = y;
		M[X] ++;
	}
	A = vector <pair <int64, int> > (M.begin(), M.end());
	int64 res = A.back().fs;
	int64 need_down = 0;
	int64 cur = 0;
	forn (i, A.size()) {
		int64 del = A[i].fs - cur - 1;
		del *= b;
		need_down -= del;
		if (need_down < 0)
			need_down = 0;
		need_down += A[i].sc - b;
		cur = A[i].fs;
	}
	while (need_down > 0) {
		need_down -= b;
		res ++;
	}
	cout << res << endl;
	return 0;
}
