import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.StringTokenizer;

public class Solution {
	private static final String TASKNAME = "islands";

	private void solve() throws IOException {
		int n = nextInt();
		int m = nextInt();
		grid = new char[n][];
		for (int i = 0; i < n; ++i) {
			grid[i] = nextToken().toCharArray();
		}
		int sx = nextInt() - 1;
		int sy = nextInt() - 1;
		int fx = nextInt() - 1;
		int fy = nextInt() - 1;
		col = new boolean[n][m];
		println(dfs(sx, sy, fx, fy, true) ? "YES" : "NO");
	}
	
	char[][] grid;
	
	private boolean dfs(int x, int y, int fx, int fy, boolean parentBridge) {
		if (x < 0 || y < 0 || x >= col.length || y >= col[0].length || col[x][y]) {
			return false;
		}
		boolean hasBridge = grid[x][y] != '0';
		if (!hasBridge && !parentBridge) {
			return false;
		}
		col[x][y] = true;
		if (x == fx && y == fy) {
			return true;
		}
		return dfs(x - 1, y, fx, fy, hasBridge) || dfs(x + 1, y, fx, fy, hasBridge) || dfs(x, y - 1, fx, fy, hasBridge) || dfs(x, y + 1, fx, fy, hasBridge);
	}

	boolean[][] col;

	public static void main(String[] args) {
		long time = System.currentTimeMillis();
		Locale.setDefault(Locale.US);
		new Solution().run();
		System.err.printf("%.3f\n", 1e-3 * (System.currentTimeMillis() - time));
	}

	private StringTokenizer tokenizer;
	private BufferedReader reader;
	private PrintWriter writer;

	private String nextToken() throws IOException {
		while (tokenizer == null || !tokenizer.hasMoreTokens()) {
			tokenizer = new StringTokenizer(reader.readLine());
		}
		return tokenizer.nextToken();
	}

	private int nextInt() throws IOException {
		return Integer.parseInt(nextToken());
	}

	private long nextLong() throws IOException {
		return Long.parseLong(nextToken());
	}

	private double nextDouble() throws IOException {
		return Double.parseDouble(nextToken());
	}

	private void print(Object o) {
		writer.print(o);
	}

	private void println(Object o) {
		writer.println(o);
	}

	private void printf(String format, Object... o) {
		writer.printf(format, o);
	}

	private void run() {
		try {
			reader = new BufferedReader(new FileReader(TASKNAME + ".in"));
			writer = new PrintWriter(TASKNAME + ".out");

			solve();

			reader.close();
			writer.close();

		} catch (IOException e) {
			e.printStackTrace();
			System.exit(13);
		}
	}
}
