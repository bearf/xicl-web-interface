#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>
using namespace std;

set < pair < double , int > > alp;
double pii; 
double eps=1e-9;
#define TASK_NAME "race"

int main () {

#ifdef INPUT_VAR
	freopen("input.txt", "rt", stdin);
	freopen("output.txt", "wt", stdout);
#else
	freopen(TASK_NAME ".in", "rt", stdin);
	freopen(TASK_NAME ".out", "wt", stdout);
#endif
	pii=atan2(0,-1.);
	int n,ans=0;
	scanf("%d",&n);
	for (int i=0;i<n;i++)
	{
		double curalpha;
		scanf("%lf",&curalpha);
		
		double falpha=pii-curalpha;

		set<pair<double,int> >::iterator xx;
		
		while (alp.size()>0 && fabs( (*(alp.begin())).first -pii/2.) > fabs(curalpha-pii/2.)+eps && (*(alp.begin())).first<pii/2.+eps)
		{
			alp.erase(alp.begin());
			ans--;
		}


		if (alp.size()==0 ||  curalpha<pii/2.+eps || fabs( (*(alp.begin())).first -pii/2.)+eps > fabs(curalpha-pii/2.) )
		{
			ans++;
			alp.insert(make_pair(curalpha,i+1));
		}

	}
	printf("%d\n",ans);
	for (set<pair<double,int> >::iterator i=alp.begin();i!=alp.end();i++)
		printf("%d ",(*i).second);



	return 0;
}