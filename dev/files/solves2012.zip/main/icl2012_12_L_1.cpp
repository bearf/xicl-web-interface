#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <set>
#include <string>
#include <vector>

using namespace std;

#define forn(i,n) for (int i = 0; i < (n); i++)
#define forit(it,v) for (typeof((v).end()) it = (v).begin(); it != (v).end(); ++it)
#define sz(v) ((int)((v).size()))
typedef long long LL;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef pair<ld, ld> pt;

#define TASK "race"

#define N 100500
int n;
ld alpha[N];
int prv[N], nxt[N];
set<int> alive;

ld sqdist(ld x1, ld y1, ld x2, ld y2) {
	return (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2);
}

bool ints(int x1, ld a1, int x2, ld a2, pt& z) {
	assert(x1 != x2);
	if (x1 > x2) swap(x1, x2), swap(a1, a2);
	if (a1 > a2 - 1e-9) return false;
	ld t1 = (x1 - x2) * sin(a2) / (sin(a1)*cos(a2) - sin(a2)*cos(a1));
	z.first = x1 + t1 * cos(a1);
	z.second = t1 * sin(a1);
	return true;
}

void killdude(int i) {
	int inxt = nxt[i];
	int iprv = prv[i];
	alive.erase(i);
	if (inxt >= 0) prv[inxt] = iprv;
	if (iprv >= 0) nxt[iprv] = inxt;
}

int main() {
	assert(freopen(TASK ".in", "r", stdin));
	assert(freopen(TASK ".out", "w", stdout));
	scanf("%d", &n);
	forn(i, n) {
		double x;
		scanf("%lf", &x);
		alpha[i] = x;
	}
	
	prv[0] = nxt[n-1] = -1;
	forn(i, n-1) prv[i+1] = i, nxt[i] = i+1;
	
	forn(i, n) alive.insert(i);
	
	set< pair<ld, int> > s;
	pt z;
	forn(i, n-1) {
		if (ints(i, alpha[i], i+1, alpha[i+1], z)) {
			ld di = sqdist(i, 0, z.first, z.second);
			ld dj = sqdist(i+1, 0, z.first, z.second);
			s.insert(make_pair(min(di, dj), di > dj ? i : (i+1)));
		}
	}
	
	while (!s.empty()) {
		pair<ld, int> zz = *s.begin();
		s.erase(s.begin());
		int i = zz.second;
		if (!alive.count(i)) continue;
		int j = prv[i], k = nxt[i];
		if (j != -1 && k != -1 && ints(j, alpha[j], k, alpha[k], z)) {
			ld dj = sqdist(j, 0, z.first, z.second);
			ld dk = sqdist(k, 0, z.first, z.second);
			s.insert(make_pair(min(dj, dk), dj > dk ? j : k));
		}
		killdude(i);
	}
	
	int ans = sz(alive);
	printf("%d\n", ans);
	bool sp = 0;
	forit(it, alive) {
		if (sp) printf(" "); else sp = 1;
		printf("%d", *it+1);
	}
	
	return 0;
}
