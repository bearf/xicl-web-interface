#include <cstdlib>
#include <cstdio>
#include <map>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int) n; ++i)
#define ford(i, n) for (int i = (int)n-1; i >= 0; --i)
#define fs first
#define sc second
#define x first
#define y second
#define mp make_pair
#define pb push_back
#define all(x) x.begin(), x.end()
#define seta(x,y) memset (x, y, sizeof (x))

typedef long long int64;
typedef pair <int, int> pii;

bool u[30][30][30][30];
vector <pii> ans[30][30][30][30];
int a[30][30];
pii p[30][30][30][30];
int n, m;

vector <pii> merge (const vector <pii> &a, const vector <pii> &b) {
	vector <pii> res;
	int pa = 0;
	int pb = 0;
	int cur = 1;
	int ca = 0;
	int cb = 0;
	while (pa < (int)a.size() || pb < (int)b.size()) {
		if ((pb < (int)b.size()) && (pa == (int)a.size() || a[pa].sc > b[pb].sc)) {
			cur += b[pb].fs - cb;
			res.pb (mp (cur, b[pb].sc));
			cb = b[pb].fs;
			pb ++;
		} else {
			cur += a[pa].fs - ca;
			res.pb (mp (cur, a[pa].sc));
			ca = a[pa].fs;
			pa ++;
		}
	}
	return res;
}

void go (int lx, int ly, int rx, int ry) {
	if (u[lx][ly][rx][ry])
		return;
	u[lx][ly][rx][ry] = 1;
	if (lx == rx && ly == ry) {
		ans[lx][ly][rx][ry].pb (mp (0, a[lx][ly]));
		return;
	}
	vector <pii> x1, y1, x2, y2;
	pii P = p[lx][ly][rx][ry];
	if (lx < P.x) {
		x1.pb (mp (lx, P.x-1));
		y1.pb (mp (ly, ry));
		x2.pb (mp (P.x, rx));
		y2.pb (mp (ly, ry));
	}
	if (rx > P.x) {
		x1.pb (mp (lx, P.x));
		y1.pb (mp (ly, ry));
		x2.pb (mp (P.x+1, rx));
		y2.pb (mp (ly, ry));
	}
	if (ly < P.y) {
		x1.pb (mp (lx, rx));
		y1.pb (mp (ly, P.y-1));
		x2.pb (mp (lx, rx));
		y2.pb (mp (P.y, ry));
	}
	if (ry > P.y) {
		x1.pb (mp (lx, rx));
		y1.pb (mp (ly, P.y));
		x2.pb (mp (lx, rx));
		y2.pb (mp (P.y+1, ry));
	}
	forn (i, x1.size()) {
		go (x1[i].fs, y1[i].fs, x1[i].sc, y1[i].sc);
		go (x2[i].fs, y2[i].fs, x2[i].sc, y2[i].sc);
	}
	vector <pii> &res = ans[lx][ly][rx][ry];
	forn (i, x1.size()) {
		vector <pii> a, b, c;
		a = ans[x1[i].fs] [y1[i].fs] [x1[i].sc] [y1[i].sc];
		b = ans[x2[i].fs] [y2[i].fs] [x2[i].sc] [y2[i].sc];
		c = merge (a, b);
		if (res.size() == 0)
			res = c;
		else
			res = min (res, c);
	}
}
            
int main()
{
	freopen("cuts.in", "r", stdin);
	freopen("cuts.out", "w", stdout);
	cin >> n >> m;
	forn (i, n)
		forn (j, m)
			cin >> a[i][j];
	for (int i = 0; i < n; i ++)	
		for (int j = 0; j < m; j ++)
			for (int k = 0; k <= i; k ++)
				for (int l = 0; l <= j; l ++) {
					pii P = mp (k, l);
					for (int x = k; x <= i; x ++)
						for (int y = l; y <= j; y ++)
							if (a[P.fs][P.sc] > a[x][y])
								P = mp (x, y);
					p[k][l][i][j] = P;
				}
	seta (u, 0);
	go (0, 0, n-1, m-1);
	vector <pii> res = ans[0][0][n-1][m-1];
	forn (i, res.size()) {
		printf ("%d", res[i].fs);
		if (i + 1 < (int)res.size())
			printf (" "); 
	}
	printf ("\n");
	return 0;
}
