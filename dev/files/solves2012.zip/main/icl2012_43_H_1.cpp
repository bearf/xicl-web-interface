#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <string>
#include <string.h>
#include <math.h>
#include <memory.h>
using namespace std;

#define li long long
#define pb push_back
#define mp make_pair
#define all(a) a.begin(),a.end()

li n,k;
vector <li> a;
li abc(li x)
{
	if(x>0)
		return x;
	return -x;
}
li nod(li x,li y)
{
	if(x==0)
		return y;
	return nod(y%x,x);
}
int main()
{
	//freopen("input.txt", "r", stdin);
	freopen("trees.in", "r", stdin);
	freopen("trees.out", "w", stdout);
	li n,k,t,sum=0;
	cin>>n>>k;
	for(li i=0;i<k;i++)
	{
		cin>>t;
		a.pb(t);
	}
	if(k==1)
	{
		cout<<a[0]*(n-a[0]+1);
		return 0;
	}
	li res;
	res=a[1]-a[0];
	for(li i=2;i<k;i++)
		res=nod(res,a[i]-a[i-1]);
	li i;
	for(i=1;i*i<res;i++)
		if(res%i==0)
		{
			t=res/i;
			sum+=((a[0]-1)/i+1)*((n-a[k-1]+1-1)/i+1);
			sum+=((a[0]-1)/t+1)*((n-a[k-1]+1-1)/t+1);
		}
	if(i*i==res)
		sum+=((a[0]-1)/i+1)*((n-a[k-1]+1-1)/i+1);
	cout<<sum;





	return 0;
}