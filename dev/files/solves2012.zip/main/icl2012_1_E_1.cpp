#include<iostream>
#include<cmath>
#include<algorithm>
#include<set>
#include<map>
#include<vector>
#include<stack>
#include<queue>
#include<deque>
#include<list>
#include<string>
#include<cstring>
#include<cstdio>

#define PI 3.14159265358979323
#define EPS 1e-7

using namespace std;

int main(){
	freopen("changes.in","rt",stdin);
	freopen("changes.out","wt",stdout);
	int n;
	cin>>n;
	int a[10013],b[10013];
	for (int i=0;i<n;i++){
		cin>>a[i];
	}
	for (int i=0;i<n;i++){
		cin>>b[i];
	}
	int ans[10013],cans=0;
	for (int i=0;i<n;i++){
		int mm=0;
		for (int j=0;j<n;j++){
			if (a[j]-1<0){
				mm=j;
				break;
			}
			else{
				if (a[j]-b[j]<a[mm]-b[mm]){
					mm=j;
				}
			}
		}
		a[mm]+=n;
		bool pp=1;
		for (int j=0;j<n;j++){
			a[j]--;
			if (a[j]<0){
				cout<<-1;
				return 0;
			}
			if (a[j]!=b[j]) pp=0;
		}
		ans[cans]=mm+1;
		cans++;
		if (pp) break;
	}
	for (int i=0;i<n;i++){
		if (a[i]!=b[i]){
			cout<<-1;
			return 0;
		}
	}
	cout<<cans<<'\n';
	for (int i=0;i<cans;i++){
		cout<<ans[i]<<' ';
	}
	return 0;

}