import java.util.*;
import java.math.*;
import java.util.regex.*;
import java.io.*;

public class Main {
	
	int getLen(int x)
	{
		int cnt = 0;
		while (x > 0)
		{
			cnt++;
			x /= 10;
		}
		return cnt;
	}
	
	void solve() throws IOException
	{
		BigInteger a, b;
		a = in.nextBigInteger();
		b = in.nextBigInteger();
		int f = getLen(b.intValue());
		BigInteger L = BigInteger.ONE;
		BigInteger D = BigInteger.TEN.pow(f).subtract(a);
		for (int p = 1; p <= 10000; p++)
		{
			L = L.multiply(BigInteger.TEN);
			BigInteger up = b.multiply(a.multiply(L).subtract(BigInteger.ONE));
			if (up.mod(D).equals(BigInteger.ZERO))
			{
				out.print(b);
				out.print(up.divide(D));
				return;
			}
		}
		out.print("-1");
	}
	
	Scanner in;
	PrintWriter out;

	public static void main(String[] args) throws IOException {
		new Main().run();
	}
	
	void run() throws IOException
	{
		in = new Scanner(new File("numbers.in"));
		out = new PrintWriter(new File("numbers.out"));
		//in = new Scanner(System.in);
		//out = new PrintWriter(System.out);
		solve();
		out.flush();
	}

}
