#include <iostream>
#include <algorithm>
#include <cstdio>
#include <set>
#include <map>

using namespace std;

int gcd(int a, int b) {
	while (b)
		swap(a%=b, b);
	return a;
}

map<int, int> p;
int d[1000000];
int nd;

int main() {
	freopen("trees.in", "r", stdin);
	freopen("trees.out", "w", stdout);
	
	int n, k;

	cin >> n >> k;

	int g = 0;

	int s = 0;
	cin >> s;
	int t;
	
	for (int i=1; i<k; i++) {
		cin >> t;
		g = gcd(g, t - s);
	}
	int res=0;
	
	int f = g;
	for (int i=2; i<=f; i++) {
		while (f%i == 0) {
			f/=i;
			p[i]++;
		}
	}
	d[nd++]=1;
	for (map<int, int>::iterator it=p.begin(); it!=p.end(); ++it) {
		int x = it->first;
		int xn = it->second;
		for (int z=x; xn>0; xn--, z*=x)
			for (int i=nd-1; i>=0; i--)
				d[nd++] = d[i]*z;
	}

	if (g) {
		for (int i=0; i<nd; i++)
				res+= ((s-1)/d[i]+1)*((n-t)/d[i]+1);
	} else {
		int mx = max(s-1, n-s);
		for (int i=1; i<=mx; i++)
			res += ((s-1)/i+1)*((n-s)/i+1);
		res -= (mx-1);
	}

	cout << res << endl;

	return 0;
}