#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cassert>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <string>
#include <algorithm>

using namespace std;

#define pb push_back
#define mp make_pair
#define _(a, b) memset(a, b, sizeof(a))

typedef long long lint;
typedef unsigned long long ull;

const int INF = 1000000000;
const lint LINF = 4000000000000000000ll;
const double eps = 1e-9;

void prepare(string file)
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
#else
	freopen((file + ".in").c_str(), "r", stdin);
	freopen((file + ".out").c_str(), "w", stdout);
#endif
}

int n;
double a[100005];

vector< pair<double, int> > p[2];

const double pi = atan(1.0) * 4.0;
const double pi2 = atan(1.0) * 2.0;

bool solve()
{
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%lf", &a[i]);
		p[0].pb( mp(a[i], i) );
	}
	
	int cur = 0;
	int next = 1;
	
	while (true)
	{
		bool ok = false;

		p[next].clear();
		for (int i = 0; i < p[cur].size(); i++)
		{
			int j = i;

			pair<double, int> need = mp(-100.0, -1);

			while (j < p[cur].size() - 1 && p[cur][j] < p[cur][j + 1])
				j++;

			for (int k = i; k <= j; k++)
			{
				if (fabs(need.first - pi2) > fabs(p[cur][k].first - pi2))
					need = p[cur][k];
			}

			p[next].pb(need);

			if (j > i)
				ok = true;

			i = j;
		}

		swap(cur, next);

		if (!ok)
			break;
	}

	printf("%d\n", p[cur].size());
	for (int i = 0; i < p[cur].size(); i++)
		printf("%d ", p[cur][i].second + 1);
	printf("\n");

	return false;
}

int main()
{
	prepare("race");
	while (solve());
	return false;
}