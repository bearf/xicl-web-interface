#include <iostream>

using namespace std;


int a[100500];


int gcd(int a, int b)
{
	while(a > 0 && b > 0)
	{
		if(a > b) a %= b;
		else b %= a;
	}
	return a + b;
}


int main()
{
	freopen("trees.in", "r", stdin);
	freopen("trees.out", "w", stdout);
	int n, k;
	scanf("%d %d", &k, &n);
	for(int i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
		a[i]--;
	}
	int G = 0;
	for(int i = 1; i < n; i++)
	{
		G = gcd(G, a[i] - a[0]);
	}
	long long res = 0;
	if(n == 1)
	{
		res = 1;
		int gMax = max(a[0] + 1, k - a[n - 1]);
		for(int g = 1; g <= gMax; g++)
		{
			if(G % g == 0)
			{
				res += (long long )(a[0] / g + 1) * (long long )( ( k - 1 - a[n  - 1]) / g + 1) - 1;
			}
		}
		cout << res << endl;
		return 0;
	}
	for(int g = 1; g <= G; g++)
	{
		if(G % g == 0)
		{
			res += (long long )(a[0] / g + 1) * (long long )( ( k - 1 - a[n  - 1]) / g + 1);
		}
	}
	cout << res << endl;
	return 0;
}