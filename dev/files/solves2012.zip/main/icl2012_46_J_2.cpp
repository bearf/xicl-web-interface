#include <iostream>
#include <algorithm>
#include <cstdio>
#include <set>
#include <map>
#include <queue>
#include <vector>

using namespace std;

int m, n;
short ** a;
short ** u;

struct pnt {
	pnt() {}
	pnt(int x, int y): x(x), y(y) {}
	int x, y;
};

pnt s, t;
queue<pnt> q;

int main () {
	
	freopen("islands.in", "r", stdin);
	freopen("islands.out", "w", stdout);
	cin >> m >> n;

	a = new short* [ m ];
	u = new short* [ m ];
	for (int i=0; i<m; i++) {
		a[i] = new short [ n ];
		u[i] = new short [ n ];
	}

	for (int i=0; i<m; i++)
		for (int j=0; j<n; j++) {
			char c;
			cin >> c;
			a[i][j] = int(c-'0');
			u[i][j] = 0;
		}
	cin >> s.x >> s.y >> t.x >> t.y;
	s.x--;
	s.y--;
	t.x--;
	t.y--;

	q.push(pnt(s.x, s.y));
	u[s.x][s.y] = 2;

	while (!q.empty()) {
		pnt p = q.front();
		q.pop();
		if (p.x == t.x && p.y == t.y) {
			cout << "YES";
			return 0;
		}
		int i, j;
		i = p.x - 1, j = p.y;
		if (p.x>0 && u[p.x-1][p.y]<2) {
			if (a[i][j] > 1) {
				q.push(pnt(i, j));
				u[i][j] = 2;
			} else {
				if (a[p.x][p.y]>1 || (a[p.x][p.y]==1 && u[p.x][p.y] == 2)) {
					q.push(pnt(i, j));
					u[i][j] = 2;
				} else
				if (
					(a[p.x][p.y] == 1 && u[p.x][p.y] == 1 || a[p.x][p.y] == 0)
					&& a[i][j] == 1
				) {
						q.push(pnt(i, j));
						u[i][j] = 1;
				}
			}
		}
		i = p.x + 1, j = p.y;
		if (p.x<m-1 && u[p.x+1][p.y]<2) {
			if (a[i][j] > 1) {
				q.push(pnt(i, j));
				u[i][j] = 2;
			} else {
				if (a[p.x][p.y]>1 || (a[p.x][p.y]==1 && u[p.x][p.y] == 2)) {
					q.push(pnt(i, j));
					u[i][j] = 2;
				} else
				if (
					(a[p.x][p.y] == 1 && u[p.x][p.y] == 1 || a[p.x][p.y] == 0)
					&& a[i][j] == 1
				) {
						q.push(pnt(i, j));
						u[i][j] = 1;
				}
			}
		}
		i = p.x, j = p.y - 1;
		if (p.y>0 && u[p.x][p.y-1]<2) {
			if (a[i][j] > 1) {
				q.push(pnt(i, j));
				u[i][j] = 2;
			} else {
				if (a[p.x][p.y]>1 || (a[p.x][p.y]==1 && u[p.x][p.y] == 2)) {
					q.push(pnt(i, j));
					u[i][j] = 2;
				} else
				if (
					(a[p.x][p.y] == 1 && u[p.x][p.y] == 1 || a[p.x][p.y] == 0)
					&& a[i][j] == 1
				) {
						q.push(pnt(i, j));
						u[i][j] = 1;
				}
			}
		}
		i = p.x, j = p.y + 1;
		if (p.y<n-1 && u[p.x][p.y+1]<2) {
			if (a[i][j] > 1) {
				q.push(pnt(i, j));
				u[i][j] = 2;
			} else {
				if (a[p.x][p.y]>1 || (a[p.x][p.y]==1 && u[p.x][p.y] == 2)) {
					q.push(pnt(i, j));
					u[i][j] = 2;
				} else
				if (
					(a[p.x][p.y] == 1 && u[p.x][p.y] == 1 || a[p.x][p.y] == 0)
					&& a[i][j] == 1
				) {
						q.push(pnt(i, j));
						u[i][j] = 1;
				}
			}
		}
	}

	cout << "NO";

	return 0;
}