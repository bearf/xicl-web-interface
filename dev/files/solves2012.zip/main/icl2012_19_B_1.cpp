#include <cstdio>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <iostream>
#include <cmath>

using namespace std;

const int INF = (int) 1e9;
const double EPS = 1e-8;
const double PI = acos(-1.);

typedef pair<int, int> pii;
typedef long long ll;

#define NAME "cuts"

const int di[] = {-1, 0, 1, 0};
const int dj[] = {0, 1, 0, -1};

int n, m;
int a[40][40], b[40][40];
int pi[1000], pj[1000];
int ans[1000];
vector <int> v[5];

void trans()
{
	int i, j;
	for (i = 0; i < max(n, m); ++i)
		for (j = i + 1; j < max(n, m); ++j)
		{
			swap(a[i][j], a[j][i]);
			swap(b[i][j], b[j][i]);
		}
	swap(n, m);
}

vector <int> make_cut(int i, int j)
{
	vector <int> w;
	int u;
	if (i == 0 || i == n || b[i][j] != b[i - 1][j])
	{
		return w;
	}
	for (u = 0; u < m; ++u)
	{
		if (b[i][u] == b[i][j])
		{
			w.push_back(b[i][u]);
			w.push_back(b[i - 1][u]);
		}
	}
	return w;
}

void draw_cut(int i, int j, int & cnt)
{
	int u, y;
	for (u = 0; u < n; ++u)
		for (y = 0; y < m; ++y)
			if (b[u][y] == b[i][j] && u < i)
			{
				b[u][y] = cnt;
			}
	cnt++;
}

int main()
{
	freopen (NAME".in", "r", stdin);
	freopen (NAME".out", "w", stdout);
	int i, j, u, y;
	scanf("%d%d", &n, &m);
	if (n*m == 1)
	{
		printf("0\n");
		return 0;
	}
	for (i = 0; i < n; ++i)
		for (j = 0; j < m; ++j)
		{
			scanf("%d", &a[i][j]);
			--a[i][j];
			b[i][j] = 0;
			pi[a[i][j]] = i;
			pj[a[i][j]] = j;
		}
	int cnt = 1;
	for (u = 0; u < n*m; )
	{
		if (ans[u] != 0)
		{
			++u;
			continue;
		}
		v[0] = make_cut(pi[u], pj[u]);
		v[1] = make_cut(pi[u] + 1, pj[u]);
		trans();
		v[2] = make_cut(pj[u], pi[u]);
		v[3] = make_cut(pj[u] + 1, pi[u]);
		trans();
		for (y = 0; y < 4; ++y)
			sort(v[y].begin(), v[y].end());
		int best = 0;
		for (y = 1; y < 4; ++y)
		{
			for (i = 0; i < v[y].size() && i < v[0].size() && v[0][i] == v[y][i]; ++i);
			if (i < v[0].size() && i < v[y].size() && v[0][i] > v[y][i] || 
				i == v[0].size() && i < v[y].size())
			{
				swap(v[0], v[y]);
				best = y;
			}
		}
		if (best >= 2)
			trans();
		if (best == 0)
			draw_cut(pi[u], pj[u], cnt);
		else if (best == 1)
			draw_cut(pi[u] + 1, pj[u], cnt);
		else if (best == 2)
			draw_cut(pj[u], pi[u], cnt);
		else
			draw_cut(pj[u] + 1, pi[u], cnt);
		if (best >= 2)
			trans();
		for (i = 0; i < n; ++i)
			for (j = 0; j < m; ++j)
			{
				if (ans[a[i][j]] > 0)
					continue;
				bool f = true;
				for (y = 0; y < 4; ++y)
				{
					int ni = i + di[y];
					int nj = j + dj[y];
					if (ni >= 0 && ni < n && nj >= 0 && nj < m && b[i][j] == b[ni][nj])
						f = false;
				}
				if (f)
					ans[a[i][j]] = cnt - 1;
			}
//		for (i = 0; i < n; ++i)
//		{
//			for (j = 0; j < m; ++j)
//				printf("%d ", b[i][j]);
//			printf("\n");
//		}
//		for (i = 0; i < n*m; ++i)
//			printf("%d ", ans[i]);
//		printf("\n\n");
	}
	for (i = 1; i < n*m; ++i)
		ans[i] = max(ans[i - 1], ans[i]);
	for (i = 0; i < n*m; ++i)
		printf("%d ", ans[i]);
	return 0;
}