import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Solution {
	static class Car implements Comparable<Car> {
		long i, j;

		public Car(long I, long J) {
			i = I;
			j = J;
		}

		@Override
		public int compareTo(Car c) {
			return i < c.i ? -1 : i > c.i ? 1 : 0;
		}
	}

	public static void main(String[] args) throws Exception {
		BufferedReader in = new BufferedReader(new FileReader("millenium.in"));
		PrintWriter out = new PrintWriter(new File("millenium.out"));

		StringTokenizer st = new StringTokenizer(in.readLine());
		long N = Integer.parseInt(st.nextToken()), A = Integer.parseInt(st.nextToken()), B = Integer.parseInt(st.nextToken());

		Car[] c = new Car[(int) N];

		for (int i = 0; i < N; i++) {
			st = new StringTokenizer(in.readLine());
			c[i] = new Car(Long.parseLong(st.nextToken()), Long.parseLong(st.nextToken()));
		}

		Arrays.sort(c);

		long last = 0;
		long lastD = -1;

		for (int i = 0; i < c.length; i++) {
			if (lastD >= c[i].i) {
				if (last < B)
					last++;
				else {
					last = 1;
					lastD++;
				}
			} else {
				last = 1;
				lastD = c[i].i;
			}
		}

		out.println(lastD);
		out.close();
	}
}
