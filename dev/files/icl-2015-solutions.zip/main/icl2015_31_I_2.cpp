#include <iostream>
#include <cassert>
#define fin cin
#define fout cout

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

typedef long long ll;

const ll oo = 1e18;
const int maxh = 35000;
const int maxx = 2200;

ll c[maxh][maxx];
ll n, m;


void solve()
{
    if (m == 1)
    {
        fout << n << endl;
        return;
    }
    if (m == 2)
    {
        ll l = -1;
        ll r = 2e9;
        while (r - l > 1)
        {
            ll mm = (l + r + 1) / 2;
            if ((mm * (mm - 1)) / 2 <= n)
                l = mm;
            else
                r = mm;
        }
        n -= (l * (l - 1)) / 2;
        fout << l << ' ' << n << endl;
        return;
    }
    if (m == 3)
    {
        ll l = -1;
        ll r = 1e6;
        while (r - l > 1)
        {
            ll mm = (l + r + 1) / 2;
            if ((mm * (mm - 1) * (mm - 2)) / 6 <= n)
                l = mm;
            else
                r = mm;
        }
        fout << l << ' ';
        n -= (l * (l - 1) * (l - 2)) / 6;
        l = -1;
        r = 2e9;
        while (r - l > 1)
        {
            ll mm = (l + r + 1) / 2;
            if ((mm * (mm - 1)) / 2 <= n)
                l = mm;
            else
                r = mm;
        }
        fout << l << ' ';
        n -= (l * (l - 1)) / 2;
        fout << n << endl;
        return;
    }



    c[0][0] = 1;
    for (int i = 1; i < maxh; i++)
    {
        //fout << i << endl;
        c[i][0] = 1;
        if (i < maxx)
            c[i][i] = 1;
        for (int j = 1; j < min(i, maxx); j++)
        {
            c[i][j] = c[i - 1][j - 1] + c[i - 1][j];
            if (c[i][j] > oo)
                c[i][j] = oo;
        }
    }
    //fout << "I am alive" << endl;
    int cur = maxh - 1;
    for (int i = m; i > 0; i--)
    {
        if (i <= 2)
            while (c[cur][i] > n)
            cur--;
        else
            while (c[cur][i] > n)
                cur--;
        n -= c[cur][i];
        fout << cur << ' ';
        cur--;
    }
    fout << endl;
    //fout << n << endl;
    assert(n == 0);
}


int main()
{
    fin >> n >> m;
    solve();
    return 0;
}
