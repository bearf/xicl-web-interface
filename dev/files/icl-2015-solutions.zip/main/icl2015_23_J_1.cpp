#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <deque>
#include <queue>
#include <complex>

using namespace std;

#define pb push_back
#define mp make_pair
#define pbk pop_back
#define fs first
#define sc second
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define all(x) (x).begin(), (x).end()
#define next _next
#define prev _prev
#define link _link
#define hash _hash
#define rank _rank
#ifdef LOCAL42
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif
#if _WIN32 || __WIN32__ || _WIN64 | __WIN64__
#define LLD "%I64d"
#else
#define LLD "%lld"
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));

inline int power(int a, int b, int MOD) {
	if (b == 0) {
		return 1 % MOD;
	}
	int res = power(a, b / 2, MOD);
	res = (1ll * res * res) % MOD;
	if (b & 1) {
		res = (1ll * res * a) % MOD;
	}
	return res;
}

inline pair<int, int> multiply(const pair<int, int> &a, const pair<int, int> &b, int MOD) {
	return mp((1ll * a.fs * b.fs) % MOD, a.sc + b.sc);
}

inline pair<int, int> divide(const pair<int, int> &a, const pair<int, int> &b, int phi, int MOD) {
	return mp((1ll * a.fs * power(b.fs, phi - 1, MOD)) % MOD, a.sc - b.sc);
}

const int N = 1e6 + 100;

int value[N], mul[N];

inline void build(int pw, int p) {
	for (int i = 0; i < pw; i++) {
		value[i] = i % p == 0 ? 1 : i % pw;
	}
	for (int i = 0; i < pw; i++) {
		mul[i] = (1ll * (i > 0 ? mul[i - 1] : 1) * value[i]) % pw;
	}
}

inline pair<int, int> factorial(int n, int p, int pw) {
	if (n <= 0) {
		return mp(1, 0);
	}
	int cur = (1ll * power(mul[pw - 1], n / pw, pw) * mul[n % pw]) % pw;
	pair<int, int> curPair = mp(cur, n / p);
	return multiply(curPair, factorial(n / p, p, pw), pw);
}

inline int solvePrime(int64 n, int64 k, int p, int alpha, int pw) {
	int phi = pw / p * (p - 1);
	build(pw, p);
	pair<int, int> f1 = factorial(n, p, pw), f2 = factorial(k, p, pw), f3 = factorial(n - k, p, pw);
	pair<int, int> f = divide(divide(f1, f2, phi, pw), f3, phi, pw);
	return (1ll * f.fs * power(p, f.sc, pw)) % pw;
}

inline int solve(int64 n, int64 k, int m) {
	vector<int> p, a, pw;
	int t = m;
	for (int i = 2; i * i <= m; i++) {
		if (m % i == 0) {
			int q = 0, cur = 1;
			while (m % i == 0) {
				q++;
				m /= i;
				cur *= i;
			}
			p.pb(i);
			a.pb(q);
			pw.pb(cur);
		}
	}
	if (m > 1) {
		p.push_back(m);
		a.push_back(1);
		pw.push_back(m);
	}
	int x = len(p);
	vector<int> ans(x);
	for (int i = 0; i < x; i++) {
		ans[i] = solvePrime(n, k, p[i], a[i], pw[i]);
	}
	for (int i = 0; i < t; i++) {
		bool flag = true;
		for (int j = 0; j < x; j++) {
			if (i % pw[j] != ans[j]) {
				flag = false;
				break;
			}
		}
		if (flag) {
			return i;
		}
	}
	assert(false);
}

int main() {
#ifdef LOCAL42
#define TASK "J"
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
#endif
	int64 n, k;
	int m;
	cin >> n >> k >> m;
	cout << solve(n, k, m) << endl;
	return 0;
}