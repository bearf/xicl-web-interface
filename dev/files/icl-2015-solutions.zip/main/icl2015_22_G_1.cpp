#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

vector<long long> v;

int main()
{
	int n;
	long long mill = 1000000;
	cin >> n;

	for (int i = 0; i < n; i++)
	{
		long long a, b, c;
		cin >> a >> b >> c;
		v.push_back(a * mill * mill + b * mill + c);
	}

	sort(v.begin(), v.end());
	long long sum = 0, m_sum = 0;

	for (int i = 1; i < n; i++)
	{
		if (v[i] != v[0])
			sum += 12 * mill * mill - v[i] + v[0];
	}

	m_sum = sum;

	for (int i = 1; i < n; i++)
	{
		if (v[i] != v[i - 1])
		{
			int k = 0;

			while ((i + k < n) && (v[i + k] == v[i]))
			{
				sum -= 12 * mill * mill - v[i] + v[0];
				k++;
			}
			k--;
			sum += (n - 1 - k) * (v[i] - v[i - 1]);
			if (sum < m_sum)
			{
				m_sum = sum;
			}
		}
	}

	cout << m_sum / (mill * mill) << ' ' << (m_sum % (mill * mill)) / mill << ' ' << m_sum % mill;
	//cin >> n;
	return 0;
}