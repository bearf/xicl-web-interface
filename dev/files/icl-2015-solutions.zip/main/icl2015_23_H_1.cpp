#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <deque>
#include <queue>
#include <complex>

using namespace std;

#define pb push_back
#define mp make_pair
#define pbk pop_back
#define fs first
#define sc second
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define all(x) (x).begin(), (x).end()
#define next _next
#define prev _prev
#define link _link
#define hash _hash
#define rank _rank
#ifdef LOCAL42
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif
#if _WIN32 || __WIN32__ || _WIN64 | __WIN64__
#define LLD "%I64d"
#else
#define LLD "%lld"
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));

int main() {
#ifdef LOCAL42
#define TASK "H"
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
#endif
	int n, s, f;
	scanf("%d %d %d", &n, &s, &f);
	int ans = -1;
	if (n == 2)
		ans = 1;
	else if (abs(s - f) == 1 && (s == 1 || f == 1 || s == n || f == n))
		ans = 1;
	else if (s == f + 1 || f == s + 1)
		ans = -1;
	else
	{
		ans = 0;
		if (s > f)
			swap(s, f);
		if (s > 1)
			ans++, s++;
		if (f < n)
			ans++, f--;
		int t = abs(f - s);
		ans += t % 3 + t / 3;
	}
	printf("%d\n", ans);
	return 0;
}