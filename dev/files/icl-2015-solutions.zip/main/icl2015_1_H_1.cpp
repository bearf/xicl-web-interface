#include <cstdio>
#include <cstring>
#include <iostream>
#include <set>
#include <queue>
#include <cmath>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;

#define ll long long
#define ld long double
#define mp make_pair
#define pb push_back
#define forn(i, n) for(int i = 0; i < n; i++)



const int inf = 1 << 30;
const ld eps = 1e-9;

const int tern_sz = 50;



int main(){
	ll n, s, f, ans = 0;
    cin >>  n >> s >> f; if(s> f)swap(s, f);
    if(s == f){
        cout << -1; return 0;
    }
    if(s == f - 1 && s != 1 && f != n){
        cout << -1; return 0;
    }
    if(s == f - 1){
        cout << 1; return 0;
    }
    if(s != 1){
        ans++;
    }
    if(f != n)ans++;
    if(s == 1)s--;
    if(f == n)f++;
    cout << ans + (f - s - 2) / 3 + (f - s - 2) % 3;
	return 0;
}
