#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const long long day = 12 * 1e12;
const long long lam = 1e6;

int main()
{
    //cout << day << endl;
    long long n, k;
    cin >> n >> k;
    vector <vector <long long> > d(n + 100, vector <long long> (k + 100, 0));
    d[2][1] = 1;
    for (int i = 0; i <= n; i++) d[i][0] = 1;
    for (int i = 3; i <= n; i++){
        for (int j = 1; j <= k; j++){
            for (int o = 1; o <= i; o++){
                for (int p = o + 1; p <= i; p++){
                    for (int m = 0; m < j; m++)
                        d[i][j] += d[p - o - 1][m] * d[i - (p - o + 1)][j - m - 1];
                }
            }
            d[i][j] /= j;
        }
    }
//    for (int i = 0; i <= n; i++){
//        for (int j = 0; j <= k; j++) cout << d[i][j] << ' ';
//        cout << endl;
//    }
    cout << d[n][k];
    return 0;
}
