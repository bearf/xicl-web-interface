#include <cstdio>
#include <cstring>
#include <iostream>
#include <set>
#include <queue>
#include <cmath>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;

#define ll long long
#define mp make_pair
#define pb push_back
#define forn(i, n) for(int i = 0; i < n; i++)
typedef long double ld;


const int inf = 1 << 30;
const ld eps = 1e-9;

ll d[50][50];

int main(){
    int n, k;
    cin >> n >> k;
    d[0][0] = 1;
    for (int i = 1; i <= n; ++i) {
        d[i][0] = 1;
        for (int j = 1; j <= k; ++j) {
            d[i][j] = d[i - 1][j];
            for (int i2 = 0; i2 <= i - 2; ++i2) {
                for (int j2 = 0; j2 < j; ++j2) {
                    d[i][j] += d[i2][j2] * d[i - i2 - 2][j - j2 - 1];
                }
            }
        }
    }
    cout << d[n][k] << endl;

	return 0;
}
