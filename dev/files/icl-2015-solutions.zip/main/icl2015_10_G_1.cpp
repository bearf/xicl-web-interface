#define _USE_MATH_DEFINES

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <bitset>
#include <cassert>
#include <cmath>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) int(a.size())
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define all(a) a.begin(),a.end()

typedef pair<int,int> pt;
#define ft first
#define sc second

typedef unsigned long long li;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = 1e9;

const int N = 100 * 1000 + 5;
const li p6 =1e6;

int n;
li t[N];

bool read() {
	if (!(cin >> n))
		return false;
	forn(i, n) {
		li h, m, s;
		cin >> h >> m >> s;
		t[i] = h * p6 * p6 + m * p6 + s;
	}
	return true;
}

li sum[N];

void solve() {
	sort(t, t + n);

	forn(i, n) {
		sum[i + 1] = sum[i] + t[i];
	}

	li res = li(1e19);

	forn(i, n) {
		li cur = 0;
		cur += t[i] * i - sum[i];

		li sumR = sum[n] - sum[i + 1];
		cur += t[i] * (n - i - 1) + (li(n - i - 1) * 12 * p6 * p6 - sumR) ;
		res = min(res, cur);
	}

	cout << res / (p6 * p6) << " ";
	res %= (p6 * p6);

	cout << res / p6 << " ";
	res %= p6;

	cout << res << endl;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif

	while (read()) {
		solve();
	}

	cerr << clock() * 1000 / CLOCKS_PER_SEC << endl;
	return 0;
}