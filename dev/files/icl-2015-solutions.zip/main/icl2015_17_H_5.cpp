#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
#include <cstring>
#include <map>
#include <algorithm>
#include <ctime>

using namespace std;

typedef long long LL;

#define all(x) (x).begin(), (x).end()
#define INF 1E+9
#define INFll 1E+18

LL fact(LL n, LL m) {
	if (n >= m)
		return 0;
	
	LL ans =1;

	for (int i = 2; i <= n; ++i) {
		ans *= i;
		ans %= m;
	}

	return ans;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int n, s, f;
	cin >> n >> s >> f;

	if (s > f)
		swap(s, f);

	if (s == f || (s != 1 && f != n && f == s + 1)) {
		cout << -1;
		return 0;
	}

	if (n == 2) {
		cout << 1;
		return 0;
	}

	if ((f - s) % 2 == 0) {
		cout << (f - s) / 2 + (2 - (s == 1) - (f == n)) + ((f - s -3) % 4 == 0)?1:0;
	}
	else {
		cout << (f - s + 1) / 2 + ((f - s -3) % 4 == 0)?1:0;
	}

	return 0;
}