#include <iostream>
#include <cstdio>
#include <cmath>

using namespace std;

int mmax, pmax, cnt, pcnt;

int main()
{
    int n;
    cin >> n;
    int a[n];
    mmax = -1;
    pmax = -1;
    for (int i = 0; i < n; ++i){
        cin >> a[i];
        if (a[i] > mmax){
            pmax = mmax;
            mmax = a[i];
            pcnt = cnt;
            cnt = 0;
        }
        if (a[i] == mmax){
            cnt++;
        }
    }
    if (mmax == 0){
        cout << 0;
        return 0;
    }
    if (cnt == 1){
        int nmax = mmax;
        for (int i = 0; i < n; ++i){
            if (a[i] == mmax){
                if (i != 0){
                    if (a[i - 1] < mmax - 2){
                        if (mmax - pmax != 1)
                            nmax--;
                    }
                }
                if (i != n - 1){
                    if (a[i + 1] < mmax - 2){
                        if (mmax - pmax != 1)
                            nmax = min(nmax, mmax - 1);
                    }
                }
            }
        }
        cout << nmax << endl;
        return 0;
    }
    else{
        for (int i = 0; i < n; ++i){
            if (i != 0){
                if (a[i] == mmax && a[i - 1] != 0){
                    cout << mmax + 1 << endl;
                    return 0;
                }
            }
            if (i != n - 1){
                if (a[i] == mmax && a[i + 1] != 0){
                    cout << mmax + 1 << endl;
                    return 0;
                }
            }
        }
        for (int i = 0; i < n; ++i){
            if (a[i] == mmax){
                if (i != 0){
                    if (a[i - 1] > 0){
                        cout << mmax * (cnt - 1);
                        return 0;
                    }
                }
                if (i != n - 1){
                    if (a[i + 1] > 0){
                        cout << mmax * (cnt - 1);
                        return 0;
                    }
                }
            }
        }
        cout << mmax * cnt;
    }
    return 0;
}
