#include <bits/stdc++.h>

using namespace std;

#ifdef FOOBAR
    ifstream fin("input.txt");
#define cin fin
#endif // FOOBAR

int n, s, f;

int main() {
    ios_base::sync_with_stdio(false);

    cin >> n >> s >> f;

    if (s > f) {
        int k = s;
        s = f;
        f = k;
    }

    if (s > 1 && f < n && (f - s) == 1) {
        cout << -1;
        return 0;
    }

    int res = 0;

    if (s > 1) {
        res++;
        s++;
    }

    while (s != f) {
        if (s == f - 1)
        {
            cout << res + 1;
            return 0;
        }
        if (s == f - 2) {
            cout << res + 2;
            return 0;
        }
        if (s == f - 3) {
            if (f < n) {
                cout << res + 3;
                return 0;
            } else {
                cout << res + 1;
                return 0;
            }
        }

        res++;
        s += 3;
    }

    cout << res;
    return 0;
}
