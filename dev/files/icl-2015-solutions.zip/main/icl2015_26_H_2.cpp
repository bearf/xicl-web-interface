#include <iostream>
using namespace std;

int n,s,f,sum,mins=10000;
bool v[10000];

void solve(int start,int vis){
    if(start == f && vis == n-1)
    {
        if(mins>sum)
            mins = sum;
        return;
    }

    //cerr<<start<<' '<<vis<<endl;
    v[start] = 1;

    if(start>2 && !v[start-2]) solve(start-2,vis+1);
    if(start<n-1 && !v[start+2]) solve(start+2,vis+1);
    if(start>1 && !v[start-1]) { sum++; solve(start-1,vis+1); sum--; }
    if(start<n && !v[start+1]) { sum++; solve(start+1,vis+1); sum--; }

    v[start] = 0;
}

int main(){

    cin>>n>>s>>f;
    solve(s,0);
    if(mins!=10000) cout<<mins<<endl;
    else cout<<"-1"<<endl;

    return 0;
}
