#include <cstdio>
#include <iostream>

using namespace std;


const int NMAX = 100001;

int n, a[NMAX], mx, mx_ind, s1, s2;

void mxs()
{
	int p = -1;
	for(int  i = 1; i <= n; i++)
	{
		if(a[i] > p)
		{
			p = a[i];
			mx_ind = i;
		}
	}
	mx = p;
}

int sum()
{
	mxs();
	int p = 0;
	for(int i = 1; i <= n; i++)
	{
		if(a[i] == mx)
		{
			p += a[i];
		}
	}
	return p;
}



int main()
{
	mx = -1;
	scanf("%d", &n);
	a[0] = -2000000;
	a[n+1] = -2000000;
	for(int i = 1; i <= n; i++)
	{
		scanf("%d", &a[i]);
	}

	s1 = sum();


	for(int i = 1; i <= n; i++)
	if(a[i] != 0)
	{
		{
			a[i]--;
			if(i+1 <= n){
				a[i+1]++;
				s2 = sum();
				s1 = min(s1,s2);
				a[i+1]--;
			}

			if(i-1 >= 1){
				a[i-1]++;
				s2 = sum();
				s1 = min(s1,s2);
				a[i-1]--;
			}
			a[i]++;
		}
	}

	/////////////
	
	
	printf("%d", s1);
}