#include <string>
#include <cstring>
#include <iostream>
#include <fstream>
#include <deque>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <ctype.h>
#include <ctime>

#define _USE_MATH_DEFINES
#include <math.h>

#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define LL long long
#define mp make_pair
#define sqr(x) x*x

using namespace std;

void smain();

int main() {
#ifdef _DEBUG
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif
	
	smain();

	return 0;
}

#define int long long

#define M 1000000LL


void smain() {
	int n;
	int mod = M * M * 12;
	for (;cin>>n;) {
		int h, m, s, to;
		vector <int> t(n);

		forn(i,n) {
			cin>>h>>m>>s;
			t[i] = s+ m*M + h*M*M;
		}

		int hh=0, hr;
		forn(i,n) {
			hh += mod - t[i];
		}

		sort(t.begin(), t.end());

		hr = hh;
		to = 0;

		forn(i,n) {
			hh -= mod-t[i] + to;
			hh += (n-1) * (t[i]-to);
			if (hr>hh)
				hr = hh;

			to = t[i];
		}

		s = hr % M;
		hr /= M;
		m = hr % M;
		hr /= M;
		cout<<hr<<' '<<m<<' '<<s<<'\n';
	}
}