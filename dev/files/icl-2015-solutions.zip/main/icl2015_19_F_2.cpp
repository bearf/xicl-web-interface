#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

typedef long long ll;


const int mod = 1e9 + 9;
const int maxn = 1e5 + 10;

int bin(int n, int k) {
	if (k == 0) return 1;
	int res = bin(n, k / 2);
	res = 1LL * res * res % mod;
	if (k % 2 == 1) res = 1LL * res * n % mod;
	return res;
}

int n;
vector<int> divisors[maxn];
int mx[maxn];
vector<int> pr;
double lg[maxn];

int bestans;
double ans;

void rec(int mn, int d, double curlog, int curprod) {
	if (d == 1) {
		if (ans > curlog) {
			ans = curlog;
			bestans = curprod;
		}
		return;
	}
	int p1 = 1;
	for (int i = 1; i < (int)divisors[d / p1].size(); i++) {
		double newlog = curlog + lg[pr[mn]] * (divisors[d / p1][i] * p1 - 1);
		if (newlog > ans) return;
		rec(mn + 1, d / p1 / divisors[d / p1][i], newlog, 1LL * curprod * bin(pr[mn], divisors[d / p1][i] * p1 - 1) % mod);
	}
}

int solve() {
	ans = 1e100;
	rec(1, n, 0, 1);
	return bestans;
}


void precalc() {
	for (int i = 1; i < maxn; i++) {
		lg[i] = log(i);
		if (divisors[i].size() == 1) {
			mx[i] = i;
			pr.push_back(i);
		}
		for (int j = i; j < maxn; j += i) {
			divisors[j].push_back(i);
			mx[j] = max(mx[j], mx[i]);
		}
	}
}

int main() {
	//freopen("task.in", "r", stdin);

	precalc();

	while (cin >> n) {
		cout << solve() << endl;
	}

	return 0;
}