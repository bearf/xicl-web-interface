#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;
typedef long long ll;
#define mp make_pair

const ll M = 1e9 + 9;
const int N = 304;

ll dp[N][N][2];

int n, k;

ll f(int len, int bal, bool has_k_vl)
{
	if (bal == k)
		has_k_vl = 1;
	if (len == 0)
	{
		if (bal == 0 && has_k_vl)
			return 1;
		return 0;
	}
	if (dp[len][bal][has_k_vl] != -1)
		return dp[len][bal][has_k_vl];

	ll res = 0;

	res += f(len - 1, bal, has_k_vl);
	if (bal < k)
		res += f(len - 1, bal + 1, has_k_vl);
	if (bal)
		res += f(len - 1, bal - 1, has_k_vl);
	return dp[len][bal][has_k_vl] = (res % M);
}

int main()
{
#ifdef XXX
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	for (int i = 0; i < N; i++)
		for (int j = 0; j < N; j++)
			for (int k = 0; k < 2; k++)
				dp[i][j][k] = -1;

	cin >> n >> k;
	cout << f(n, 0, 0);
}