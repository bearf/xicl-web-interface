#include <bits/stdc++.h>

using namespace std;

int main() {
	int n, a = 0, b = 0, c = 0;
	string stmp;
	cin >> n;
	getline(cin, stmp);
	for (int i = 0; i < n; i++) {
		string s;
		getline(cin, s);
		bool f1, f2, f3, f4 = false;
		f1 = f2 = f3 = f4;
		for(int j = 0; j < int(s.size()) - 3; j++) {
			if (s[j] == 'b' && s[j + 1] == 'l' && s[j + 2] == 'u' && s[j + 3] == 'e') {
				f1 = true;
			}
			if (s[j] == 'g' && s[j + 1] == 'o' && s[j + 2] == 'l' && s[j + 3] == 'd') {
				f2 = true;
			}
		}
		for(int j = 0; j < int(s.size()) - 4; j++) {
			if (s[j] == 'b' && s[j + 1] == 'l' && s[j + 2] == 'a' && s[j + 3] == 'c' && s[j + 4] == 'k') {
				f3 = true;
			}
			if (s[j] == 'w' && s[j + 1] == 'h' && s[j + 2] == 'i' && s[j + 3] == 't' && s[j + 4] == 'e') {
				f4 = true;
			}
		}
		if (f1 && f3) {
			a++;
		} else if (f2 && f4) {
			b++;
		} else {
			c++;
		}
	}
	double ans1 = double(a) / double(n) * 100.0, ans2 = double(b) / double(n) * 100.0, ans3 = double(c) / double(n) * 100.0;
	cout << fixed << setprecision(9);
	cout << ans1 << endl << ans2 << endl << ans3;
	return 0;
}