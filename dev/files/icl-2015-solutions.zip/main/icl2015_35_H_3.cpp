#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;
typedef long long ll;
#define mp make_pair

int n,s,f;

int solve()
{
	if (n == 2)
	{
		return 1;
	}

	int dx = abs(s - f);
	int fir;
	int sec;
	if (s < f)
	{
		fir = s - 1;
	}
	else
	{
		fir = n - s;
	}
	if (f < s)
	{
		sec = f - 1;
	}
	else
	{
		sec = n - f;
	}

	if (dx == 1 && fir != 0 && sec != 0)
	{
		return -1;
	}

	int ans = 0;
	if (fir > 0)
	{
		--dx;
		++ans;
	}
	if (sec > 0)
	{
		++ans;
		--dx;
	}
	
	ans += dx % 3 + dx / 3;
	return ans;
}

int main()
{
#ifdef XXX
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	cin >> n >> s >> f;

	cout << solve();
}