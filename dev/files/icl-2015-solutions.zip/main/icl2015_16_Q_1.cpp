#include <iostream>
#include <fstream>

using namespace std;

//ifstream cin("input.txt");
//ofstream cout("output.txt");

long long d[45][45];

long long rec(long long n, long long k)
{
    //cout << n << " " << k << endl;
    if (d[n][k] != -1)
        return d[n][k];
    if (k == 0)
        return 1;
    if (k * 2 > n)
        return 0;
    long long ans = 0;
    for (long long i = 0; i <= n - 2; i++)
    {
        for (long long j = 0; j < k; j++)
            if (i * 2 != n - 2)
                ans += rec(i, j) * rec(n - i - 2, k - j - 1);
            else
                ans += rec(i, j) * rec(n - i - 2, k - j - 1);
    }
    ans += rec(n - 1, k);
    d[n][k] = ans;
    return ans;
}

int main()
{
    for (long long i = 0; i < 45; i++)
        for (long long j = 0; j < 45; j++)
            d[i][j] = -1;
    long long n, k;
    cin >> n >> k;
    cout << rec(n, k) << endl;
}
