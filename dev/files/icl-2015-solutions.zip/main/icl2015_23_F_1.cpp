#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <deque>
#include <queue>
#include <complex>

using namespace std;

#define pb push_back
#define mp make_pair
#define pbk pop_back
#define fs first
#define sc second
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define all(x) (x).begin(), (x).end()
#define next _next
#define prev _prev
#define link _link
#define hash _hash
#define rank _rank
#ifdef LOCAL42
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif
#if _WIN32 || __WIN32__ || _WIN64 | __WIN64__
#define LLD "%I64d"
#else
#define LLD "%lld"
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));

inline bool isPrime(int n) {
	for (int i = 2; i * i <= n; i++) {
		if (n % i == 0) {
			return false;
		}
	}
	return true;
}

const int M = 1e9 + 9;

inline int power(int a, int b) {
	if (b == 0)
		return 1;
	int res = power(a, b / 2);
	res = (1ll * res * res) % M;
	if (b & 1) {
		res = (1ll * res * a) % M;
	}
	return res;
}

int main() {
#ifdef LOCAL42
#define TASK "F"
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
#endif
	int n; cin >> n;
	vector<int> fact;
	for (int i = 2; i * i <= n; i++) {
		while (n % i == 0) {
			fact.pb(i - 1);
			n /= i;
		}
	}
	if (n > 1) {
		fact.pb(n - 1);
	}
	int k = len(fact);
	vector<int> primes;
	for (int i = 3; len(primes) < k; i++) {
		if (isPrime(i)) {
			primes.pb(i);
		}
	}
	sort(all(fact));
	reverse(all(fact));
	sort(all(primes));
	int res = 1;
	for (int i = 0; i < len(primes); i++) {
		res = (1ll * res * power(primes[i], fact[i])) % M;
	}
	cout << res << endl;
	return 0;
}