#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <deque>
#include <queue>
#include <complex>

using namespace std;

#define pb push_back
#define mp make_pair
#define pbk pop_back
#define fs first
#define sc second
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define all(x) (x).begin(), (x).end()
#define next _next
#define prev _prev
#define link _link
#define hash _hash
#define rank _rank
#ifdef LOCAL42
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif
#if _WIN32 || __WIN32__ || _WIN64 | __WIN64__
#define LLD "%I64d"
#else
#define LLD "%lld"
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));

const int N = 160500;

struct vt
{
	llong x, y;
	vt(llong _x, llong _y)
	{
		x = _x, y = _y;
	}
	friend vt operator +(vt a, vt b)
	{
		return vt(a.x + b.x, a.y + b.y);
	}
	friend vt operator -(vt a, vt b)
	{
		return vt(a.x - b.x, a.y - b.y);
	}
	friend llong operator *(vt a, vt b)
	{
		return a.x * b.x + a.y * b.y;
	}
	friend llong operator ^(vt a, vt b)
	{
		return a.x * b.y - b.x * a.y;
	}
	friend bool operator <(vt a, vt b)
	{
		return make_pair(a.y, a.x) < make_pair(b.y, b.x);
	}
	friend bool operator ==(vt a, vt b)
	{
		return make_pair(a.y, a.x) == make_pair(b.y, b.x);
	}
	inline vt rot(unsigned int t)
	{
		t &= 3;
		if (t == 0)
			return (*this);
		else if (t == 1)
			return vt(-y, x);
		else if (t == 2)
			return vt(-x, -y);
		else
			return vt(y, -x);
	}
	inline vt unrot(unsigned int t)
	{
		return rot(-t);
	}
	vt(){}
} P[N];

struct Cmp
{
	vt O;
	Cmp(vt _O)
	{
		O = _O;
	}
	bool operator()(vt a, vt b)
	{
		a = a - O;
		b = b - O;
		llong d = a ^ b;
		if (d != 0)
			return d > 0;
		else
			return a * a < b * b;
	}
};

const int IT = 100;

double f(vt a, vt b, vt c, vt d, double phi)
{
	double vx = cos(phi);
	double vy = sin(phi);
	double ans = ((b - d).x * vx + (b - d).y * vy) * ((c - a).x * (-vy) + (c - a).y * vx);
	assert(ans > 0);
	return ans;
}

int cnt = 0;

pair<double, double> get(vt l, vt r, vt a, vt b, vt c, vt d)
{
	cnt++;
	double lx = l.x, ly = l.y;
	double lang = atan2(l.y, l.x), rang = atan2(r.y, r.x);
	pair<double, double> ans = min(
		make_pair(f(a, b, c, d, lang), lang),
		make_pair(f(a, b, c, d, rang), rang)
	);
	for (int it = 0; it < IT; it++) 
	{
		double u = (2 * lang + rang) / 3;
		double v = (lang + 2 * rang) / 3;
		if (f(a, b, c, d, u) < f(a, b, c, d, v))
			rang = v;
		else
			lang = u;
	}
	ans = min(ans, make_pair(f(a, b, c, d, (lang + rang) / 2.0), (lang + rang) / 2.0));
	return ans;
}

int main() {
#ifdef LOCAL42
#define TASK "E"
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
#endif
	int n;
	//scanf("%d", &n);
	n = 80000;
	for (int i = 0; i < n; i++)
	{
		//scanf(LLD " " LLD, &P[i].x, &P[i].y);
		double x = 25000.0 * cos(i * 2 * pi / n);
		double y = 25000.0 * sin(i * 2 * pi / n);
		P[i] = vt(x, y);
	}
	sort(P, P + n);
	n = unique(P, P + n) - P;
	sort(P + 1, P + n, Cmp(P[0]));
	int pt = 0;
	for (int i = 0; i < n; i++)
	{
		vt w = P[i];
		while (true)
		{
			if (pt < 2)
				break;
			vt u = P[pt - 2], v = P[pt - 1];
			if (((v - u) ^ (w - v)) > 0)
				break;
			--pt;
		}
		P[pt++] = w;
	}
	n = pt;
	eprintf("pt = %d\n", pt);
	/*for (int i = 0; i < n; i++)
		eprintf("%lld %lld\n", P[i].x, P[i].y);*/
	memcpy(P + n, P, sizeof(vt) * n);

	int p[4] = {0, 0, 0, 0};
	vt dir(0, -1);
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (dir.rot(j) * P[i] > dir.rot(j) * P[p[j]])
				p[j] = i;
		}
	}

	vt cur(1, 0);

	double ans = 1e100, ang = -42;
	int bp[4];

	while (true)
	{
		/*for (int i = 0; i < 4; i++)
			eprintf("%d ", p[i]);
		eprintf("%d %d\n", (int)cur.x, (int)cur.y);*/
		vt cand[4];
		for (int i = 0; i < 4; i++)
			cand[i] = (P[p[i] + 1] - P[p[i]]).unrot(i);
		vt best = cand[0];
		int ind = 0;
		for (int i = 1; i < 4; i++)
			if ((best ^ cand[i]) < 0)
				best = cand[i], ind = i;
		assert((cur ^ best) >= 0);
		pair<double, double> pr = get(cur, best, P[p[0]], P[p[1]], P[p[2]], P[p[3]]);
		if (pr.first < ans)
		{
			ans = pr.first, ang = pr.second;
			memcpy(bp, p, sizeof(p));
		}

		p[ind]++;
		if (p[ind] == n)
			p[ind] = 0;
		if (p[3] == 1)
			break;
		cur = cand[ind];
	}
	eprintf("ans = %.10lf ang = %.10lf\n", ans, ang);
	double cx = cos(ang), cy = sin(ang);
	for (int i = 0; i < 4; i++)
	{
		double dx = -cy, dy = cx;
		vt a = P[bp[i]];
		vt b = P[bp[(i + 1) & 3]];
		double yy = dx * a.x + dy * a.y;
		double xx = cx * b.x + cy * b.y;
		double vx = xx * cx + yy * dx;
		double vy = xx * cy + yy * dy;
		printf("%.10lf %.10lf\n", vx, vy);
		cx = dx, cy = dy;
	}
	eprintf("%d\n", cnt);
	eprintf("%.2lf\n", clock() * 1.0 / CLOCKS_PER_SEC);
	return 0;
}