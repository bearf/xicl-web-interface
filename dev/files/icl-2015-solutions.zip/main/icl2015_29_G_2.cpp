#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

const long long mil=1000000;
int main()
{
	int n;
	cin>>n;
	long long h, m, s;
	vector<long long> a;
	for(int i=0; i<n; i++)
	{
		cin>>h>>m>>s;
		long long k=0;
		k+=s;
		k+=m*mil;
		k+=h*mil*mil;
		a.push_back(k);
	}
	sort(a.begin(), a.end());
	vector<long long> t;
	long long p=12*mil*mil;
	for(int i=0; i<n; i++)
	{
		long long time=0;
		for(int j=i-1; j>=0; j--)
			time+=a[i]-a[j];
		for(int j=i+1; j<n; j++)
			time+=p-a[j]+a[i];
		t.push_back(time);
	}
		
	long long ans = t[0];
	for(int i=0; i<t.size(); i++)
		ans = min(ans, t[i]);	
	long long ans_h, ans_m, ans_s;
	ans_s = ans%mil;
	ans_m = ans/mil;
	ans_h = ans_m/mil;
	ans_m = ans_m%mil;
	cout<<ans_h<<' '<<ans_m<<' '<<ans_s<<endl;
	return 0;
}