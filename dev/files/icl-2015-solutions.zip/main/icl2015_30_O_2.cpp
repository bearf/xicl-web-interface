#include <iostream>
#include <complex>
#include <vector>
#include <math.h>
#include <stdio.h>

using namespace std;

const double eps = 1e-9;

int main()
{
    double x1, y1, x2, y2, x, y, a, b, c, sum1, sum2;
    cout.precision(20);
    cin >> x1 >> y1 >> x2 >> y2;
    complex<double> norm(y1 - y2, x1 - x2), v1, v2, n1, vl, vr;
    pair<double, double> pr1, pr2;
    int n, i;
    a = y1 - y2;
    b = x2 - x1;
    c = - x1 * a - y1 * b;
    cout << a << ' ' << b << ' ' << c << endl;
    cin >> n;
    vector<complex<double> > pts(n);
    cin >> x >> y;
    pts[0] = {x, y};
    n1 = norm / abs(norm) * abs((a*x + b * y + c)/sqrt(a*a + b*b));
    //cout << abs(a*n1.real() + b*n1.imag() + c) << ' ';
    if (abs(a*(n1+pts[0]).real() + b*(n1+pts[0]).imag() + c) > eps) n1 = - n1;
    n1 = pts[0] + n1;
    //cout << n1 << endl;
    pr1 = {n1.real(), n1.imag()};
    pr2 = {n1.real(), n1.imag()};
    for (i = 1; i < n; i++)
    {
        cin >> x >> y;
        pts[i] = {x, y};
        n1 = norm / abs(norm) * abs((a*x + b * y + c)/sqrt(a*a + b*b));
        //cout << abs(a*n1.real() + b*n1.imag() + c) << ' ';
        if (abs(a*(n1+pts[i]).real() + b*(n1+pts[i]).imag() + c) > eps) n1 = - n1;
        n1 = pts[i] + n1;
        //cout << n1 << endl;
        pr1 = min(pr1, {n1.real(), n1.imag()});
        pr2 = max(pr2, {n1.real(), n1.imag()});
    }
//    cout << pr1.first << ' ' << pr1.second << endl;
//    cout << pr2.first << ' ' << pr2.second << endl;
    v1 = {pr1.first, pr1.second};
    v2 = {pr2.first, pr2.second};
    while (abs(v1 - v2) > eps)
           {
                vl = v1 + (v2 - v1)/(double) 3;
                vr = v1 + (double)2*(v2 - v1)/(double) 3;
                sum1 = 0;
                sum2 = 0;
                for (i = 0; i < n; i++)
                {
                    sum1 += abs(pts[i] - vl);
                    sum2 += abs(pts[i] - vr);
                }
                if (sum1 > sum2)
                    v1 = vl;
                else
                    v2 = vr;

           }
    sum1 = 0;
            for (i = 0; i < n; i++)
            {
                sum1 += abs(pts[i] - v1);
            }
    printf("%.10f\n", sum1);
    printf("%.10f %.10f\n", v1.real(), v1.imag());
    return 0;
}
