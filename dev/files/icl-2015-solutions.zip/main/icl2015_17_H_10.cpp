#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
#include <cstring>
#include <map>
#include <algorithm>
#include <ctime>

using namespace std;

typedef long long LL;

#define all(x) (x).begin(), (x).end()
#define INF 1E+6
#define INFll 1E+18
#define EPS 1E-6

typedef double dbl ;

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int n, s, f;
	cin >> n >> s >> f;

	if (f < s)
		swap(f, s);

	if (s == f || (f == s + 1 && s != 1 && f != n)) {
		cout << -1;
		return 0;
	}
	
	cout << 2 + (f - s - 2) / 2 + (f - s - 2) % 2;
	//cout << 2 + (f - s - 2) / 2 + (f - s - 2) % 2;

	return 0;
}