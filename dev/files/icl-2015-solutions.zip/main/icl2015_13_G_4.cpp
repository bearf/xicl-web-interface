# include <cstdio>
# include <algorithm>

using namespace std;

int n;

long long p[100100];
long long sum[100100];

int main ()
{
    int i, j;
    long long a, b, c, sum_up = 0, h12 = 12000000000000LL, ans = 1200000000000000000LL, curr;
    scanf ("%d", &n);
    for (i = 1; i <= n; i ++)
    {
        scanf ("%lld%lld%lld", &a, &b, &c);
        p[i] = a * 1000000000000LL + b * 1000000LL + c;
    }
    sort (p + 1, p + n + 1);
    for (i = 1; i <= n; i ++)
        sum[i] = sum[i - 1] + p[i];
    ans = 0;
    for (i = 1; i <= n; i ++)
        ans += h12 - p[i];
    for (i = n; i >= 1; i --)
    {
        curr = sum_up + (n - i) * p[i] + p[i] * (i - 1) - sum[i - 1];
        if (curr < ans)
            ans = curr;
        sum_up += h12 - p[i];
    }
    ///printf ("%lld\n", curr);
    printf ("%lld %lld %lld\n", ans / 1000000000000LL, (ans % 1000000000000LL) / 1000000LL, ans % 1000000LL);
    return 0;
}
