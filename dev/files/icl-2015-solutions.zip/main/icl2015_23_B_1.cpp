#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <deque>
#include <queue>
#include <complex>

using namespace std;

#define pb push_back
#define mp make_pair
#define pbk pop_back
#define fs first
#define sc second
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define all(x) (x).begin(), (x).end()
#define next _next
#define prev _prev
#define link _link
#define hash _hash
#define rank _rank
#ifdef LOCAL42
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif
#if _WIN32 || __WIN32__ || _WIN64 | __WIN64__
#define LLD "%I64d"
#else
#define LLD "%lld"
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));
const int MOD = int(1e9) + 9;
const int N = 333;

int dp[N][N][2];

inline void add(int& a, int b) {
	a += b;
	if (a >= MOD) {
		a -= MOD;
	}
}

int main() {
#ifdef LOCAL42
#define TASK "B"
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
#endif
	int n, k;
	cin >> n >> k;
	dp[0][0][(k == 0)] = 1;
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j <= min(i, k); ++j) {
			for (int z = 0; z < 2; ++z) {
				if (dp[i][j][z] == 0) {
					continue;
				}
				// 0
				add(dp[i + 1][j][z], dp[i][j][z]);
				// (
				if (j + 1 <= k) {
					add(dp[i + 1][j + 1][(z | (j + 1 == k))], dp[i][j][z]);
				}
				// )
				if (j > 0) {
					add(dp[i + 1][j - 1][z], dp[i][j][z]);
				}
			}
		}
	}
	cout << dp[n][0][1] << endl;
	return 0;
}