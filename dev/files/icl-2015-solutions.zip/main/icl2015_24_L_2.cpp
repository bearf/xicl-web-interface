#include<iostream>
#include<vector>
#include<map>
#include<string>
#include<string.h>
#include<algorithm>
#include<set>
using namespace std;

int d[100000 + 10];

int main() {
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		int v;
		scanf("%d", &v);
		d[i] = v;
	}/*
	 for (int i = 0; i < n; i++) {
	 if (i > 0) {
	 if (d[i-1] < d[i]) {
	 d[i-1] += 
	 }
	 }
	 }*/
	int max = d[0];
	for (int i = 1; i < n; i++) {
		if (d[i]>max) {
			max = d[i];
		}
	}
	if (max==0) {
		cout<<0;
		return 0;
	}
	long long int sum_1 = 0;
	for (int i = 0; i < n; i++) {
		if (d[i]==max)
			sum_1 += max;
	}
	int movedFrom = 0;
	int movedTo = 0;
	bool was = false;
	for (int i = 0; i < n; i++) {
		if (d[i]==max) {
			if (i > 0) {
				if (d[i] - d[i-1] > 2) {
					d[i]--;
					d[i-1]++;
					was = true;
					movedFrom = i;
					movedTo = i-1;
					break;
				}
			}
			if (i < n-1) {
				if (d[i] - d[i+1] > 2) {
					d[i]--;
					d[i+1]++;
					was = true;
					movedFrom = i;
					movedTo = i+1;
					break;
				}
			}
		}
	}
	max = d[0];
	for (int i = 1; i < n; i++) {
		if (d[i]>max) {
			max = d[i];
		}
	}
	if (was){
	long long int sum_2 = 0;
	for (int i = 0; i < n; i++) {
		if (d[i]==max)
			sum_2 += max;
	}
	if (sum_1 <= sum_2) {
		was = false;
		d[movedFrom]++;
		d[movedTo]--;
	}
	max = d[0];
	for (int i = 1; i < n; i++) {
		if (d[i]>max) {
			max = d[i];
		}
	}}
	if (!was) {
		for (int i = 0; i < n; i++) {
			if (d[i]==max) {
				if (i > 0) {
					if (d[i] == d[i-1]) {
						d[i]--;
						d[i-1]++;
						was = true;
						movedFrom = i;
						movedTo = i-1;
						break;
					}
				}
				if (i < n-1) {
					if (d[i] == d[i+1]) {
						d[i]--;
						d[i+1]++;
						was = true;
						movedFrom = i;
						movedTo = i+1;
						break;
					}
				}
			}
		}
	}
	max = d[0];
	for (int i = 1; i < n; i++) {
		if (d[i]>max) {
			max = d[i];
		}
	}
	if (was) {
	long long int sum_3 = 0;
	for (int i = 0; i < n; i++) {
		if (d[i]==max)
			sum_3 += max;
	}
	if (sum_1 <= sum_3) {
		was = false;
		d[movedFrom]++;
		d[movedTo]--;
	}
	max = d[0];
	for (int i = 1; i < n; i++) {
		if (d[i]>max) {
			max = d[i];
		}
	}}
	long long int sum = 0;
	for (int i = 0; i < n; i++) {
		if (d[i]==max)
			sum += max;
	}
	cout<<sum;
}