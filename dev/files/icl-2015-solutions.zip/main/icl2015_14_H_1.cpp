#include <bits/stdc++.h>

using namespace std;

int move(int l)
{
    int res = 0;
    while (l >= 3)
    {
        ++res;
        l -= 3;
    }
    res += l;
    return res;
}

int main()
{
#ifdef LOCAL
    freopen("h.in", "r", stdin);
#endif // LOCAL
    int n, s, f;
    cin >> n >> s >> f;
    --s, --f;
    if (s > f)
        swap(s, f);
    if (s == f)
    {
        cout << -1 << '\n';
        return 0;
    }
    if (s + 1 == f)
    {
        if (s > 0 && f + 1 < n)
            cout << -1 << '\n';
        else
            cout << 1 << '\n';
        return 0;
    }
    int res = 0;
    if (s > 0)
        ++res, ++s;
    if (f + 1 < n)
        ++res, --f;
    cout << move(f - s) + res << '\n';
}
