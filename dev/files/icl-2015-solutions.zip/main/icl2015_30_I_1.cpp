#include <iostream>
#include <vector>

using namespace std;

int main()
{
    long long n, m;
    cin >> n >> m;
    vector <vector <long long> > tp(2001, vector <long long> (2001, 0));
    for (int i = 0; i < 2001; i++){
        tp[i][0] = 1;
        tp[i][i] = 1;
    }
    for (int i = 2; i < 2001; i++){
        for (int j = 1; j < i; j++){
            if (tp[i - 1][j - 1] + tp[i - 1][j] < 10000000000000000) tp[i][j] = tp[i - 1][j - 1] + tp[i - 1][j];
            //cout << tp[i][j] << ' ';
        }
    }
    long long last = 1000000000000000000;
    for (int i = m; i > 0; i--){
        long long m1 = tp[0][i], ind = 0;
        for (int j = 1; j < 2001; j++){
            if (tp[j][i] >= m1 && tp[j][i] <= n && last > tp[j][i]){
                ind = j;
                m1 = tp[j][i];
            }
        }
        last = m1;
        n -= m1;
        cout << ind << ' ';
    }
    return 0;
}
