#include <iostream>
#include <cassert>
#define fin cin
#define fout cout

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

typedef long long ll;

const ll oo = 1e18;
const int maxx = 2200;

ll c[maxx][maxx];
ll n, m;


void solve()
{
    c[0][0] = 1;
    for (int i = 1; i < maxx; i++)
    {
        c[i][0] = 1;
        c[i][i] = 1;
        for (int j = 1; j < i; j++)
        {
            c[i][j] = c[i - 1][j - 1] + c[i - 1][j];
            if (c[i][j] > oo)
                c[i][j] = oo;
        }
    }
    int cur = maxx - 1;
    for (int i = m; i > 0; i--)
    {
        while (c[cur][i] > n)
            cur--;
        n -= c[cur][i];
        fout << cur << ' ';
        cur--;
    }
    fout << endl;
    assert(n == 0);
}


int main()
{
    fin >> n >> m;
    solve();
    return 0;
}
