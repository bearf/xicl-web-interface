#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

typedef long long ll;

ll n;
int m;

vector<int> stupid() {
	int l = 0, r = 1e9;
	while (r - l > 1) {
		int m = (l + r) >> 1;
		if (1LL * m * (m - 1) > 2 * n) r = m;
		else l = m;
	}
	vector<int> res;
	res.push_back(l);
	res.push_back(n - (1LL * l * (l - 1) / 2));
	return res;
}

vector<int> solve() {
	if (m == 2) return stupid();
	vector<vector<ll> > c(1, vector<ll>(m + 1, 0));
	c[0][0] = 1;
	int i = 1;
	while (1) {
		c.push_back(vector<ll>(m + 1, 0));
		for (int j = 0; j <= m; j++) {
			c[i][j] += c[i - 1][j];
			if (j + 1 <= m) c[i][j + 1] += c[i - 1][j];
		}
		if (c[i][m] >= n) break;
		i++;
	}
	vector<int> res;
	for (int j = m; j >= 1; j--) {
		while (c[i][j] > n) i--;
		n -= c[i][j];
		res.push_back(i--);	
	}
	return res;
}

void print(vector<int> v) {
	for (int i = 0; i < (int)v.size(); i++) printf("%d%c", v[i], " \n"[i + 1 == (int)v.size()]);
}

int main() {
	//freopen("task.in", "r", stdin);

	while (cin >> n >> m) {
		print(solve());
	}

	return 0;
}