#include <bits/stdc++.h>

using namespace std;

int main() {
	int n, s, f, ans = 2;
	cin >> n >> s >> f;
	if (s > f) {
		swap(s, f);
	}
	if (s == 1 && f == n) {
		cout << (n - 1) / 3 + (n - 1) % 3;
		return 0;
	}
	if (s == 1 && f != n) {
		cout << ((f - s - 1) / 3 + (f - s - 1) % 3) + 1;
		return 0;
	}
	if (s != 1 && f == n) {
		cout << ((f - s - 1) / 3 + (f - s - 1) % 3) + 1;
		return 0;
	}
	cout << ((f - s - 2) / 3 + (f - s - 2) % 3) + 2;
	return 0;
}