#include <iostream>
#include <string>
using namespace std;

//ifstream cin("input.txt");
//ofstream cout("output.txt");
string s;
int n;
double a, b, c;



int main(){
	cin >> n;
	getline(cin, s);
	for (int i = 0; i < n; i++){
		getline(cin, s);
		if (s.find("gold") != -1 && s.find("white") != -1)
		{
			b++;
		}
		else if(s.find("black") != -1 && s.find("blue") != -1)
			a++;
		else
			c++;
	}
	cout << a / (a + b + c) * 100 << endl << b / (a + b + c) * 100 << endl << c / (a + b + c) * 100;
}