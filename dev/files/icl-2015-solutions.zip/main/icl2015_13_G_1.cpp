#include<iostream>
#include<algorithm>
using namespace std;
struct time
{
    long long h;
    long long m;
    long long s;
    bool operator <(const time &p)const
    {
        if(h==p.h)
        {
            if(m==p.m)return s<p.s;
            return m<p.m;
        }
        return h<p.h;
    }
    time operator -(time p)
    {
        time c;
        c.s=s-p.s;
        if(c.s<0)
        {
            c.s+=1000000;
            p.m++;
        }
        c.m=m-p.m;
        if(c.m<0)
        {
            c.m+=1000000;
            p.h++;
        }
        c.h=h-p.h;
        return c;
    }
    time operator +( time p)
    {
        time c;
        c.s=s+p.s;
        if(c.s>=1000000)
        {
            c.s-=1000000;
            p.m++;
        }
        c.m=m+p.m;
        if(c.m>=1000000)
        {
            c.m-=1000000;
            p.h++;
        }
        c.h=h+p.h;
        return c;
    }
    time operator *(long long p)
    {
        time c;
        c.h=h*p;
        c.m=m*p;
        c.s=s*p;
        return c;
    }
}a[200005];
bool cmp(time b,time c)
{
    if(b.h==c.h)
    {
        if(b.m==c.m)return b.s<c.s;
        return b.m<c.m;
    }
    return b.h<c.h;
}
int main()
{
    long long n,i,l,r,m;
    time sm,sg,c,o,den,co;
    cin>>n;
    for(i=0;i<n;i++)
        cin>>a[i].h>>a[i].m>>a[i].s;
    sort(a,a+n);
    for(i=n;i<n*2;i++)
    {
        a[i].h=a[i-n].h+12;
        a[i].m=a[i-n].m;
        a[i].s=a[i-n].s;
    }
    sort(a,a+n);
    l=0;
    r=n-1;
    m=(l+r)/2+(r-l)%2;
    sm.h=sg.h=sm.m=sg.m=sm.s=sg.s=0;
    for(i=0;i<=m;i++)
        sm=sm+a[i];
    for(i=m+1;i<n;i++)
        sg=sg+a[i];
    c=a[m];
    o=(a[m]*(m-l+1))-sm+sg-(a[m]*(r-m));
    sm=sm-sm;
    sg=sg-sg;
    for(i=1;i<=n;i++)
        sm=sm+a[i];
    l=1;
    m=r=n;
    for(;r<2*n;r++)
    {
        if(r!=n)
        {
            sg=sg+a[r];
            sm=sm-a[l];
            l++;
            if(m<(l+r)/2+(r-l)%2)
            {
                sg=sg-a[m+1];
                sm=sm+a[m+1];
                m++;
            }
        }
        co=a[m]*(m-l+1)-sm+sg-a[m]*(r-m);
        time ga,va;
        ga=a[m]*(m-l+1)-sm;
        va=sg-a[m]*(r-m);
        if(co<o && m>=n)o=co;
    }
    cout<<o.h<<" "<<o.m<<" "<<o.s<<endl;
}
