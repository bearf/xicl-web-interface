#include <iostream>

using namespace std;

int main()
{
    long long p, q, k, a;
    cin >> p >> q;
    cout << p / q << ' ';
    p = p % q;
    k = 2;
    while (p != 0)
    {
        p = p * k;
        a = p / q;
        p = p % q;
        cout << a << ' ';
        //q = q * k;
        k++;

    }
    return 0;
}
