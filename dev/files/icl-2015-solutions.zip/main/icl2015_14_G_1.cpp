#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int maxn = 200000;
const ll q = 1000000;
const ll mod = q * q * 12;

int n;
ll a[maxn], b[maxn];

ll sum(int l, int r)
{
    return b[r] - b[l];
}

int main()
{
#ifdef LOCAL
    freopen("g.in", "r", stdin);
#endif // LOCAL
    cin >> n;
    for (int i = 0; i < n; ++i)
    {
        ll h, m, s;
        cin >> h >> m >> s;
        a[i] = h * q * q + m * q + s;
    }
    sort(a, a + n);
    b[0] = 0;
    for (int i = 0; i < n; ++i) b[i + 1] = b[i] + a[i];
    ll ans = mod * maxn;
    for (int i = 0; i < n; ++i)
    {
        ans = min(ans, a[i] * i - sum(0, i) + (mod + a[i]) * (n - 1 - i) - sum(i + 1, n));
    }
    cout << ans / q / q << " " << (ans / q) % q << " " << ans % q << endl;
    return 0;
}
