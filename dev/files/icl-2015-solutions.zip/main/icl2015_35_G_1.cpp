#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;
typedef long long ll;
#define mp make_pair

struct T
{
	ll h, m, s;
};

const int N = 1e5 + 100;

ll b[N];

bool operator <(T a, T b)
{
	if (a.h != b.h)
		return a.h < b.h;
	if (a.m != b.m)
		return a.m < b.m;
	return a.s < b.s;
}
int n;
T a[N];
ll to_add[N], S[N];
ll less_count[N], more_count[N];

ll getS(int i, int j)
{
	if (!i)
		return S[j];
	return S[j] - S[i - 1];
}

int main()
{
#ifdef XXX
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	cin >> n;
	for (int i = 0; i < n; i++)
	{
		ll h, m, s;
		cin >> h >> m >> s;
		T t;
		t.h = h;
		t.m = m;
		t.s = s;
		a[i] = t;
	}

	sort(a, a + n);

	const ll C = 1e6;

	for (int i = 0; i < n; i++)
	{
		b[i] = (a[i].h * C + a[i].m) * C + a[i].s;
	}

	ll mx = 12 * C * C;

	for (int i = 0; i < n; i++)
	{
		to_add[i] = (mx - b[i]);
	}

	for (int i = 1; i < n; i++)
	{
		if (b[i] == b[i - 1])
			less_count[i] = less_count[i - 1];
		else
			less_count[i] = i;
	}

	for (int i = n - 2; i >= 0; i--)
	{
		if (b[i] == b[i + 1])
			more_count[i] = more_count[i + 1];
		else
			more_count[i] = (n - 1) - i;
	}

	S[0] = to_add[0];
	for (int i = 1; i < n; i++)
	{
		S[i] = S[i - 1] + to_add[i];
	}

	ll ans = LLONG_MAX;
	for (int i = 0; i < n; i++)
	{
		int less_index = less_count[i] - 1;
		int more_index = (n - 1) - more_count[i] + 1;

		ll res = 0;

		if (more_index < n)
		{
			res += getS(more_index, n - 1);
			res += more_count[i] * b[i];
		}
		if (less_index >= 0)
		{
			res += getS(0, less_index);
			res -= less_count[i] * (mx - b[i]);
		}

		ans = min(res, ans);
	}

	ll s = ans % C;
	ans /= C;
	ll m = ans % C;
	ans /= C;

	cout << ans << ' ' << m << ' ' << s;

}