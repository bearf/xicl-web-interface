#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

//ifstream cin("input.txt");
//ofstream cout("output.txt");

long long pas[20005][1005];

long long f(long long m, long long pos, long long tec)
{
    long double ans = 0;
    ans += pas[tec][m];
    for (long long i = m - 2; i >= pos; i--)
    {
        //cout << pas[tec][i + 1] << endl;
        ans += pas[i][i + 1];
    }
    ans = min(ans, (long double)10000000000000000.0);
    return (long long)ans;
}

int main()
{
    pas[0][0] = pas[1][1] = pas[1][0] = 1;

    for (long long i = 2; i < 20005; i++)
    {
        pas[i][0] = 1;
        for (long long j = 1; j < 1005 and j <= i; j++)
            {
                pas[i][j] = pas[i - 1][j] + pas[i - 1][j - 1];
                if (pas[i][j] < 0)
                    pas[i][j] = 1000000000000000000;
                //cout << pas[i][j];
            }
    }

    for (long long i = 0; i < 10000; i++)
        for (long long j = 0; j < 10000; j++)
        if(pas[i][j] < 0)
            i = i;//cout << "BOOOY";
    long long n, m;
    cin >> n >> m;
    vector <long long> ans;
    long long last = 20000;
    for (long long i = m - 1; i >= 0; i--)
    {
        long long l = 0, r = last;
        while(r - l > 1)
        {
            long long mi = (r + l) / 2;
            //cout << mi << " " <<  f(m, i, mi) << endl;
            if (f(i + 1, 0, mi) <= n)
            {
                l = mi;
            }
            else
            {
                r = mi;
            }
        }
        n -= pas[l][i + 1];
        cout << l << " ";
        last = l;
    }
}
