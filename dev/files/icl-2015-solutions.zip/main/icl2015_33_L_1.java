#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>

using namespace std;

long long f_max(long long a, long long b){
    if(a > b)
        return a;

    return b;
}

long long f_min(long long a, long long b){
    if(a < b)
        return a;

    return b;
}

int main(){
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);

    long long n;
    vector<long long> p(100001, 0);

    cin >> n;

    vector<int> a(n + 2);

    for(int i = 1; i <= n; i++){
        cin >> a[i];
        p[a[i]]++;
    }

    vector<int> mx_l(n + 2), mx_r(n + 2);

    mx_l[0] = mx_r[n + 1] = 0;

    for(int i = 1; i <= n; i++)
        mx_l[i] = max(mx_l[i - 1], a[i]);

    for(int i = n; i >= 1; i--)
        mx_r[i] = max(mx_r[i + 1], a[i]);

    long long mn = 1e18;

    int b = a[1], c = a[2];

    p[b]--;
    p[b - 1]++;
    p[c]--;
    p[c + 1]++;

    b--;
    c++;

    long long mx = f_max(mx_r[3], f_max(b, c));

    mn = f_min(mn, mx * p[mx]);

    b++; c--;

    p[b]++;
    p[b - 1]--;
    p[c]++;
    p[c + 1]--;

    for(long long i = 2; i < n; i++){
        b = a[i];
        c = a[i + 1];

        p[b]--;
        p[b - 1]++;
        p[c]--;
        p[c + 1]++;

        b--; c++;

        mx = f_max(f_max(mx_l[i - 1], mx_r[i + 2]), f_max(b, c));

        mn = f_min(mn, mx * p[mx]);

        b++; c--;

        p[b]++;
        p[b - 1]--;
        p[c]++;
        p[c + 1]--;

        b = a[i];
        c = a[i - 1];

        p[b]--;
        p[b - 1]++;
        p[c]--;
        p[c + 1]++;

        b--; c++;

        mx = f_max(f_max(mx_l[i - 2], mx_r[i + 1]), f_max(b, c));

        mn = f_min(mn, mx * p[mx]);

        b++; c--;

        p[b]++;
        p[b - 1]--;
        p[c]++;
        p[c + 1]--;
    }

    b = a[n];
    c = a[n - 1];

    p[b]--;
    p[b - 1]++;
    p[c]--;
    p[c + 1]++;

    b--;
    c++;

    mx = f_max(mx_l[n - 2], f_max(b, c));

    mn = f_min(mn, mx * p[mx]);

    cout << mn;

    return 0;
}
