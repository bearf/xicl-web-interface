#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const ll H = ll(12) * ll(1e6) * ll(1e6);

const ll dist(ll a, ll b) {
    if (b < a) {
        return H - a + b;
    }
    return b - a;
}

int main() {
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);

    ll n;
    scanf("%lld", &n);

    vector<ll> a(n);
    for (int i = 0; i < n; i++) {
        ll h, m, s;
        scanf("%lld%lld%lld", &h, &m, &s);

        ll cur = h * ll(1e6) * ll(1e6) + m * ll(1e6) + s;
        a[i] = cur;
    }

    sort(a.begin(), a.end());

    ll cur = 0;
    for (int i = 1; i < n; i++) {
        cur += i * dist(a[i - 1], a[i]);
    }

    ll ans = cur;
    for (int i = 0; i < n; i++) {
        ll last = (i == 0 ? a[n - 1] : a[i - 1]);
        if (last == a[i]) continue;
        cur += n * dist(last, a[i]) - H;
        ans = min(ans, cur);
    }

    cout << ans / ll(1e6) / ll(1e6) << ' ' << ans / ll(1e6) % ll(1e6) << ' ' << ans % ll(1e6) << endl;
}
