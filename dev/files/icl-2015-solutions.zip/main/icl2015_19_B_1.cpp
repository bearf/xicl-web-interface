#include <stdio.h>

using namespace std;

const int BASE = 1e9 + 9;
const int N = 666;

int n, m, f[N][N][2];

void add(int &x, int y) {
	x += y;
	if (x >= BASE) x -= BASE;
}

int main() {
//	freopen("input.txt", "r", stdin);
	scanf("%d%d", &n, &m);
	f[0][0][0] = 1;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j <= m; j++) {	
			for (int e = 0; e < 2; e++) {
				if (f[i][j][e] == 0) continue;
				int ne = e;
				if (j == m) ne = 1;
				add(f[i + 1][j][ne], f[i][j][e]);
				if (j > 0) add(f[i + 1][j - 1][ne], f[i][j][e]);
				ne = e;
				if (j + 1 == m) ne = 1;
				if (j < m) add(f[i + 1][j + 1][ne], f[i][j][e]);
			}
		}
	}
	printf("%d\n", f[n][0][1]);
}