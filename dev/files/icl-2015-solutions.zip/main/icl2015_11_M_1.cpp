#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>

using namespace std;

string s;
int r1, r2, r3;

void proverka(){
    bool blue = false, black = false, white = false, gold = false;
    for (int i = 0; i < s.length() - 3; ++i){
        if (s[i] == 'g' && s[i + 1] == 'o' && s[i + 2] == 'l' && s[i + 3] == 'd'){
            gold = true;
        }
        if (s[i] == 'b' && s[i + 1] == 'l' && s[i + 2] == 'u' && s[i + 3] == 'e'){
            blue = true;
        }
    }
    for (int i = 0; i < s.length() - 4; ++i){
        if (s[i] == 'b' && s[i + 1] == 'l' && s[i + 2] == 'a' && s[i + 3] == 'c' && s[i + 4] == 'k'){
            black = true;
        }
        if (s[i] == 'w' && s[i + 1] == 'h' && s[i + 2] == 'i' && s[i + 3] == 't' && s[i + 4] == 'e'){
            white = true;
        }
    }
    if (blue && black){
        r1++;
    }
    else{
        if (white && gold){
            r2++;
        }
        else{
            r3++;
        }
    }
}

int main()
{
    int n;
    r1 = 0;
    r2 = 0;
    r3 = 0;
    cin >> n;
    getline(cin, s);
    for (int i = 0; i < n; ++i){
        getline(cin, s);
        proverka();
    }
    printf("%.10f %.10f %.10f", double(100) / n  * r1, double(100) / n * r2, double(100) / n * r3);
    return 0;
}
