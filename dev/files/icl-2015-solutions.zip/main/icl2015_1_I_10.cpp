#include <cstdio>
#include <cstring>
#include <iostream>
#include <set>
#include <queue>
#include <cmath>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;

#define ll long long
#define mp make_pair
#define pb push_back
#define forn(i, n) for(int i = 0; i < n; i++)
typedef long double ld;


const int inf = 1 << 30;
const ld eps = 1e-9;

const int tern_sz = 50;



int main(){
	ll s, f, ans = 0, m;
	ll n, k;
	cin >> n >> m;
	ll pr = 10000000000000001;
	for(int i = m; i > 0; i--){
        if(n == 0){
                cout << i - 1<< " ";
            continue;
        }
        if(i == 1 && n >= pr){
            return -10000;
        }
        if(i == 1){
            cout << n << " ";
            n = 0;
            return 0;
        }
        k = 1;
        ll p = i + 1;
        ll gcd = __gcd(k, (p - i));
        while((k / gcd) * (p / ((p - i) / gcd)) <= n &&
               (k / gcd) * (p / ((p - i) / gcd)) / (p / ((p - i) / gcd)) * gcd == k && pr > p){
           k = (k / gcd) * (p / ((p - i) / gcd)); p += 1; gcd = __gcd(k, (p - i));
        }
        n -= k;
        cout << p - 1 << " ";
        pr = p - 1;
	}

	return 0;
}
