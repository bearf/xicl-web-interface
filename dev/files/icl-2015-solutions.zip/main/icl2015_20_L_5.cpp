#include <bits/stdc++.h>

using namespace std;

int main() {
	long long mx = -1, n;
	cin >> n;
	vector<long long> a(n);
	for (long long i = 0; i < n; i++) {
		cin >> a[i];
		mx = max(mx, a[i]);
	}
	vector<long long> c;
	bool f = false;
	for (long long i = 0; i < n; i++) {
		if (mx == a[i]) {
			c.push_back(i);
		}
		if (a[i] == mx - 1) {
			f = true;
		}
	}
	if (c.size() >= 3) {
		for (long long i = 0; i < c.size(); i++) {
			if (c[i] != 0) {
				if (a[c[i] - 1] > 0) {
					cout << mx + 1;
					return 0;
				}
			}
			if (c[i] != n - 1) {
				if (a[c[i] + 1] > 0) {
					cout << mx + 1;
					return 0;
				}
			}
		}
		if (mx == 1) {
			cout << c.size();
		} else {
			cout << (c.size() - 1) * mx;
		}
		return 0;
	} else if (c.size() == 2) {
		for (long long i = 0; i < c.size(); i++) {
			if (c[i] != 0) {
				if (a[c[i] - 1] + 1 < mx) {
					cout << mx;
					return 0;
				}
			}
			if (c[i] != n - 1) {
				if (a[c[i] + 1] + 1 < mx) {
					cout << mx;
					return 0;
				}
			}
		}
		for (long long i = 0; i < c.size(); i++) {
			if (c[i] != 0) {
				if (a[c[i] - 1] > 0) {
					cout << mx + 1;
					return 0;
				}
			}
			if (c[i] != n - 1) {
				if (a[c[i] + 1] > 0) {
					cout << mx + 1;
					return 0;
				}
			}
		}
		cout << c.size();
		return 0;
	} else if (c.size() == 1) {
		if (f) {
			cout << mx;
			return 0;
		}
		for (long long i = 0; i < c.size(); i++) {
			if (c[i] != 0) {
				if (a[c[i] - 1] + 1 < mx - 1) {
					cout << mx - 1;
					return 0;
				}
			}
			if (c[i] != n - 1) {
				if (a[c[i] + 1] + 1 < mx - 1) {
					cout << mx - 1;
					return 0;
				}
			}
		}
		cout << mx;
		return 0;
	}
	return 0;
}