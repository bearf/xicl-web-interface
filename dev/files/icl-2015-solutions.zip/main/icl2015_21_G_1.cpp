#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int main(){
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	int n, h, m, s, i, j;
	_int64 sum = 0, ms = _I64_MAX, h12 = 12000000000000;
	cin >> n;
	vector <_int64> v(n), r(n);
	for (i = 0; i < n; i++){
		cin >> h >> m >> s;
		v[i] = 1ll*h * 1000000000000 + 1ll*m*1000000 + s;
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) if (i != j) v[i] > v[j] ? sum += v[i] - v[j] : sum += h12+v[i]-v[j];
		r[i] = sum;
		sum = 0;
	}
	for (i = 0; i < n; i++) if (r[i] < ms) ms = r[i];
	h = ms/1000000000000;
	m = ms/1000000-h*1000000;
	s = ms - m*1000000 - h*1000000000000;
	cout << h << " " << m << " " << s;
	return 0;
}