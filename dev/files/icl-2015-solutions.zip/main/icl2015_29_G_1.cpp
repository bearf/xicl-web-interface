#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

const long long mil=1000000;
int main()
{
	int n;
	cin>>n;
	long long h, m, s;
	vector<long long> a;
	for(int i=0; i<n; i++)
	{
		cin>>h>>m>>s;
		long long k=0;
		k+=s;
		k+=m*mil;
		k+=h*mil*mil;
		a.push_back(k);
	}
	sort(a.begin(), a.end());
	long long t1=0, t2=0;
	for(int i=1; i<a.size(); i++)
	{
		t1+=a[i]-a[0];
	}
	reverse(a.begin(), a.end());
	long long p=12*mil*mil;
	for(int i=0; i<a.size()-1; i++)
	{
		t2+=p-a[i]+a[a.size()-1];
	}
	long long ans = min(t1, t2);
	long long ans_h, ans_m, ans_s;
	ans_s = ans%mil;
	ans_m = ans/mil;
	ans_h = ans_m/mil;
	ans_m = ans_m%mil;
	cout<<ans_h<<' '<<ans_m<<' '<<ans_s<<endl;
	return 0;
}
