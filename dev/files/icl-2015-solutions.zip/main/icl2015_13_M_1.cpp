# include <iostream>
# include <string>

using namespace std;

int n;

string s;

int main ()
{
    int i, j, sz, law, lag, lab, labl, cnt0 = 0, cnt1 = 0, cnt2 = 0, sum = 0;
    cin >> n;
      getline (cin, s, '\n');
    for (i = 0; i < n; i ++)
    {
        law = lag = lab = labl = 0;
        getline (cin, s, '\n');
        sz = s.size ();
        for (j = 0; j < sz; j ++)
        {
            if (j >= 3)
            {
                if (s[j] == 'd' && s[j - 1] == 'l' && s[j - 2] == 'o' && s[j - 3] == 'g')
                    lag ++;

                if (s[j] == 'e' && s[j - 1] == 'u' && s[j - 2] == 'l' && s[j - 3] == 'b')
                    lab ++;
            }
            if (j >= 4)
            {
                if (s[j] == 'e' && s[j - 1] == 't' && s[j - 2] == 'i' && s[j - 3] == 'h' && s[j - 4] == 'w')
                    law ++;

                if (s[j] == 'k' && s[j - 1] == 'c' && s[j - 2] == 'a' && s[j - 3] == 'l' && s[j - 4] == 'b')
                   labl ++;
            }

        }
                    ///cout << law << lag << endl;
            if (law && lag)
                cnt0 ++;
            else
            {
                if (lab && labl)
                    cnt1 ++;
                else
                    cnt2 ++;
            }
    }
    sum = cnt0 + cnt1 + cnt2;
    ///cout << cnt0 << " " << cnt1 << " " << cnt2 << endl;
    printf ("%.6lf\n", double (cnt1) /  double (sum) * 100.0);

    printf ("%.6lf\n", double (cnt0) /  double (sum) * 100.0);

    printf ("%.6lf\n", double (cnt2) /  double (sum) * 100.0);
    return 0;
}
/**
4
this dress is blue and black
this dress is goldblackblue
eto plate kazhestia siasfaffa
no comments
**/
