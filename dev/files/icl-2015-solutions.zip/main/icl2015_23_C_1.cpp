#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <deque>
#include <queue>
#include <complex>

using namespace std;

#define pb push_back
#define mp make_pair
#define pbk pop_back
#define fs first
#define sc second
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define all(x) (x).begin(), (x).end()
#define next _next
#define prev _prev
#define link _link
#define hash _hash
#define rank _rank
#ifdef LOCAL42
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif
#if _WIN32 || __WIN32__ || _WIN64 | __WIN64__
#define LLD "%I64d"
#else
#define LLD "%lld"
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));
const int N = 333;
const int MOD = int(1e9) + 9;
const ll MOD2 = ll(MOD) * MOD;

bool used[N][N][2];
int dp[N][N][2];

inline void add(int& a, int b) {
	if ((a += b) >= MOD) {
		a -= MOD;
	}
}

inline bool check(int a, int b, int n) {
	if (a == 0 && b == n - 1) {
		return false;
	}
	if (a == 0 && b == n - 2) {
		return false;
	}
	if (b == n - 1 && a == 1) {
		return false;
	}
	return true;
}

int coeff[N][N];

int calc(int n, int k, bool fl) {
	if (n < 3) {
		if (fl) {
			return 0;
		}
		if (k == 0) {
			return 1;
		}
		return 0;
	}
	if (n == 3) {
		if (k == 1) {
			return 1;
		}
		return 0;
	}
	if (k == 0) {
		if (fl) {
			return 0;
		}
		return 1;
	}
	if (used[n][k][fl]) {
		return dp[n][k][fl];
	}
	used[n][k][fl] = true;
	if (fl) {
		ll res = 0;
		for (int i = 1; i < n - 1; ++i) {
			int l = max(k - n + i, 0), r = min(i, k) - 1;
			for (int k1 = l; k1 <= r; ++k1) {
				int k2 = k - k1 - 1;
				res += 1LL * calc(i + 1, k1, false) * calc(n - i, k2, false);
				if (res >= MOD2) {
					res -= MOD2;
				}
			}
		}
		dp[n][k][fl] = res % MOD;
	} else {
		dp[n][k][fl] = calc(n, k, true);
		for (int i = 1; i < n; ++i) {
			add(dp[n][k][fl], (1LL * calc(i, k, true) * coeff[n][i]) % MOD);
		}
	}
	return dp[n][k][fl];
}

int c[700][400];

inline int cnk(int n, int k) {
	for (int i = 0; i <= n; ++i) {
		c[i][0] = 1;
		for (int j = 1; j <= i; ++j) {
			c[i][j] = c[i - 1][j - 1];
			add(c[i][j], c[i - 1][j]);
		}
	}
	return c[n][k];
}

int pw(int a, int b) {
	int res = 1;
	while (b > 0) {
		if (b % 2 != 0) {
			res = (1LL * res * a) % MOD;
		}
		a = (1LL * a * a) % MOD;
		b /= 2;
	}
	return res;
}

inline void init(int n) {
	for (int it = 4; it <= n; ++it) {
		for (int i = 0; i < it; ++i) {
			for (int j = i + 1; j < it; ++j) {
				if (check(i, j, it)) {
					++coeff[it][j - i + 1];
				}
			}
		}
	}
}

int main() {
#ifdef LOCAL42
#define TASK "C"
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
#endif
	int n, k;
	cin >> n >> k;
	init(n);
	cout << calc(n, k, false) << endl;
	cout << (1LL * cnk(2 * (n - 2), n - 2) * pw(n - 1, MOD - 2)) % MOD << endl;
	cerr << 1.0 * clock() / CLOCKS_PER_SEC << endl;
	return 0;
}