#include <iostream>
#include <cstdio>
#include <cmath>

using namespace std;

int main()
{
    int n;
    cin >> n;
    long long h[n], m[n], s[n];
    long long a[n], ans = 0, mx = -1, cnt = 1;
    for(int i = 0;i <n;i++){
        cin >> h[i] >> m[i] >> s[i];
        if(h[i] <= 12)
            h[i] = h[i] + 12;
        //cout << m[i] * 10000 << endl;
        a[i] = h[i] * 1000000000000 + m[i] * 1000000 + s[i];
        //cout << h[i] * 1000000000000  << " "<<  m[i] * 1000000  <<  " " <<s[i] <<  "      " << a[i] <<endl;
        if(a[i] == mx)
            cnt++;
        else
        if(a[i] > mx){
                mx = a[i];
                cnt = 1;
        }
    }
    //cout << mx << endl;
    for(int i = 0;i<n;i++){
        long long m1, m2, m3;
        m1 = max(mx - 12000000000000, a[i]) - min(mx - 12000000000000, a[i]);
        m2 = max(a[i] - 12000000000000, mx) - min(a[i] - 12000000000000, mx);
        m3 = mx - a[i];
        //cout << m1 << " " << m2 << " " << m3 <<endl;
        ans = ans + min(m1,min(m2, m3));
    }
    if(cnt > 1)
        ans *= cnt;
    cout << ans/1000000000000 << " "<< ans%1000000000000 / 1000000 <<  " " <<ans%1000000;

}
