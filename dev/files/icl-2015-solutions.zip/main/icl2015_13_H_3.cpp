#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    int n,s,f,o=0;
    cin>>n>>s>>f;
    if(s==f || (abs(s-f)==1 && s!=1 && s!=n && f!=1 && f!=n))
    {
        cout<<-1<<endl;
        return 0;
    }
    else if(s>f)
    {
        if(s!=n)o++;
        else n=s-1;
        f=n-f+1;
    }
    else
    {
        if(s!=1)o++;
        else
        {
            n-=s;
            f-=s;
        }
    }
    if(f==n)o+=f/3+f%3;
    else o+=1+(f-1)/3+(f-1)%3;
    cout<<o<<endl;
}
