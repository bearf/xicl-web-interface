#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
#include <cstring>
#include <map>
#include <algorithm>
#include <ctime>

using namespace std;

typedef long long LL;

#define all(x) (x).begin(), (x).end()
#define INF 1E+9
#define INFll 1E+18

LL fact(LL n, LL m) {
	if (n >= m)
		return 0;
	
	LL ans =1;

	for (int i = 2; i <= n; ++i) {
		ans *= i;
		ans %= m;
	}

	return ans;
}

map <pair<LL, LL>, LL> a;

inline LL magic(LL n, LL k) {
	LL ans = 0;

	if (k == 1 && n > 1)
		return fact(n - 1, INFll);
	if (k * 2 > n)
		return 0;

	if (a.find(make_pair(n, k)) != a.end())
		return a[make_pair(n, k)];

	for (int i = 0; i < n; ++i) {
		for (int j = i + 1; j < n; ++j)
			for (int left = 0; left <= k - 1; ++left)
				ans += magic(n - j - 1, left) + magic(j - i - 1, k - 1- left);
	}

	a[make_pair(n, k)] = ans;

	return ans;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int n, k;
	cin >> n >> k;

	LL ans = 0;

	if (n < k * 2) {
		cout << 0;
		return 0;
	}

	cout << magic(n, k);

	return 0;
}