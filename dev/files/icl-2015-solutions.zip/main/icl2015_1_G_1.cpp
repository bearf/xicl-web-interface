#include <cstdio>
#include <cstring>
#include <iostream>
#include <set>
#include <queue>
#include <cmath>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;

#define ll long long
#define ld long double
#define mp make_pair
#define pb push_back
#define forn(i, n) for(int i = 0; i < n; i++)

const int inf = 1 << 30;
const ld eps = 1e-9;
const int maxn = 2e5;
const long long l12 = 1e12;
const long long l6 = 1e6;

struct time {
    ll h, m, s;
    time() {}
    time(ll h, ll m, ll s): h(h), m(m), s(s) {}
};

time operator+(time a, time b) {
    time c;
    c.h = a.h + b.h;
    c.m = a.m + b.m;
    c.s = a.s + b.s;
    c.m += c.s / l6;
    c.s %= l6;
    c.h += c.m / l6;
    c.m %= l6;
    c.h %= l12;
    return c;
}

time operator-(time a, time b) {
    time c;
    c.s = a.s - b.s;
    if (c.s < 0) {
        c.s += l6;
        a.m--;
    }
    c.m = a.m - b.m;
    if (c.m < 0) {
        c.m += l6;
        a.h--;
    }
    c.h = a.h - b.h;
    return c;
}

time operator*(int n, time a) {
    time c;
    c.h = a.h * n;
    c.m = a.m * n;
    c.s = a.s * n;
    c.m += c.s / l6;
    c.s %= l6;
    c.h += c.m / l6;
    c.m %= l6;
    return c;
}

time s[maxn];

bool cmp(time a, time b) {
    if (a.h == b.h) {
        if (a.m == b.m) return a.s < b.s;
        return a.m < b.m;
    }
    return a.h < b.h;
}

int main(){
    int n;
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cin >> s[i].h >> s[i].m >> s[i].s;
    }
    sort(s, s + n, cmp);
    time Max = time(12, 0, 0);
    time ans = time(0, 0, 0);
    for (int i = 1; i < n; ++i) {
        ans = ans + Max;
        ans = ans - s[i];
        ans = ans + s[0];
    }
    time cur = ans;
    for (int i = 1; i < n; ++i) {
        cur = cur + n * (s[i] - s[i - 1]);
        cur = cur - Max;
        if (cmp(cur, ans)) ans = cur;
    }
    cout << ans.h << ' ' << ans.m << ' ' << ans.s << endl;

	return 0;
}
