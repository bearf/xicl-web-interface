#include<iostream>
#include<vector>
#include<map>
#include<string>
#include<string.h>
#include<algorithm>
#include<set>
using namespace std;

int d[100000 + 10];

int main() {
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		int v;
		scanf("%d", &v);
		d[i] = v;
	}
	int max = d[0];
	for (int i = 1; i < n; i++) {
		if (d[i]>max) {
			max = d[i];
		}
	}
	if (max==0) {
		cout<<0;
		return 0;
	}
	int num_max = 0;
	int num_m_max = 0;
	for (int i = 0; i < n; i++) {
		if (d[i]==max) {
			num_max++;
		} else if (d[i] == max - 1) {
			num_m_max++;
		}
	}
	int ans_1 = INT_MAX;
	if ((((num_m_max + 1) * (max - 1) < num_max * max) && (num_max == 1)) || (num_max > 1)) { 
		for (int i = 0; i < n; i++) {
			if (d[i]==max) {
				if (i > 0) {
					if (d[i] - d[i-1] > 2) {
						ans_1 = (num_max == 1) ? (num_m_max + 1) * (max - 1) : (num_max - 1) * max;
						break;
					}
				}
				if (i < n-1) {
					if (d[i] - d[i+1] > 2) {
						ans_1 = (num_max == 1) ? (num_m_max + 1) * (max - 1) : (num_max - 1) * max;
						break;
					}
				}
			}
		}
	}
	int ans_2 = INT_MAX;
	if (num_max > 1) {
		for (int i = 0; i < n; i++) {
			if (d[i]==max) {
				if (i > 0) {
					if ((d[i] == max) && (d[i-1]>0)) {
						ans_2 = max + 1;
						break;
					}
				}
				if (i < n-1) {
					if ((d[i] == max) && (d[i+1]>0)) {
						ans_2 = max + 1;
						break;
					}
				}
			}
		}
	}
	int ans_3 = num_max * max;
	int ans = ans_1;
	if (ans_2 < ans) {
		ans = ans_2;
	}if (ans_3 < ans) {
		ans = ans_3;
	}
	cout<<ans;
}