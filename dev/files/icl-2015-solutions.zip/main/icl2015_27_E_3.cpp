#define _USE_MATH_DEFINES
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define sz(x) ((int)x.size())
#define fi first
#define se second
#define re return
#define y0 y248590
#define y1 y5427895
#define j0 j5234895
#define j1 j438759
#define prev prev348957
#define next next457834
#define sqrt(x) sqrt(abs(x))

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef pair<ll, ll> pll;
typedef vector<string> vs;
typedef long double ld;
typedef double D;

template<class T> T gcd (T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> inline T abs (T a) { re a < 0 ? -a : a; }
template<class T> inline T sqr (T a) { re ((a) * (a)); }

const ld pi = M_PI;

struct pt
{
	int x, y;

	inline ll d() const
	{
		return (ll)x * x + (ll)y * y;
	}
};

inline pt operator-(const pt &a, const pt &b)
{
	return {a.x - b.x, a.y - b.y};
}

inline bool operator<(const pt &a, const pt &b)
{
	if (a.y != b.y) return a.y < b.y;
	else return a.x < b.x;
}

inline ll operator*(const pt &a, const pt &b)
{
	return (ll)a.x * b.y - (ll)a.y * b.x;
}

const int maxn = 80005;
const ld eps = 1e-8;//1e-11;

int n;

pt p[maxn];
vector<pt> st;
pt start;

inline ld getshift(const pt &v, ld prev)
{
	while (prev > pi + eps) prev -= 2 * pi;
	while (prev < -pi - eps) prev += 2 * pi;
//	cout << v.x << ' ' << v.y << ' ' << (D)prev << endl;
	ld cur = atan2(v.y, v.x);
//	printf ("%.15f %.15f\n", (D)cur, (D)prev);
	if (cur > prev - eps) return cur - prev;
	return cur - prev + 2 * pi;
}

inline ld getf(const pt &v1, const pt &v2, ld ang)
{
	ld vx = cos(ang);
	ld vy = sin(ang);
//	cout << "getf " << v1.x << ' ' << v1.y << ' ' << v2.x << ' ' << v2.y << endl;
	return abs(v1.x * vy - v1.y * vx) * abs(v2.x * vx + v2.y * vy);
}

inline bool cmpang(const pt &a, const pt &b)
{
	ll vp = (a - start) * (b - start);
	if (vp != 0) re vp > 0;
	re (a - start).d() < (b - start).d();
}

inline pair<ld, ld> its(pt a, pt d, ld ang)
{
	ld vx = cos(ang);
	ld vy = sin(ang);
	pt sh = d - a;
	ld sp = sh.x * vx + sh. y * vy;
	return mp(a.x + vx * sp, a.y + vy * sp);
}

inline pair<pair<pair<ld, ld>, pair<ld, ld>>, pair<pair<ld, ld>, pair<ld, ld>>> getanssq(pt a, pt b, pt c, pt d, ld ang)
{
	return mp(mp(its(a, d, ang), its(a, b, ang)), mp(its(c, b, ang), its(c, d, ang)));
}

inline void out(pair<ld, ld> x)
{
	cout << (D)x.fi << ' ' << (D)x.se << endl;
}

int main () {
	scanf("%d", &n);
	for (int i = 0; i < n; i++) scanf("%d%d", &p[i].x, &p[i].y);
	swap(p[0], *min_element(p, p + n));
	start = p[0];
	sort(p, p + n, cmpang);
	p[n] = p[0];
	for (int i = 0; i <= n; i++)
	{
		while (st.size() > 1 && (st.back() - st[(int)st.size() - 2]) * (p[i] - st.back()) <= 0) st.pop_back();
		st.push_back(p[i]);
	}
	st.pop_back();
	n = st.size();
	for (int i = 0; i < n; i++) st.push_back(st[i]);
//	for (int i = 0; i < 2 * n; i++) cout << st[i].x << ' ' << st[i].y << endl;
	int cur1 = 0;
	while (st[cur1 + 1].x >= st[cur1].x) cur1++;
	int cur2 = cur1;
	while (st[cur2 + 1].y >= st[cur2].y) cur2++;
	int cur3 = cur2;
	while (st[cur3 + 1].x <= st[cur3].x) cur3++;
//	cout << cur1 << ' ' << cur2 << ' ' << cur3 << endl;
	int stop = cur1;
	ld curang = 0;
	ld answer = 1e9 * 1e9;
	int i = 0;
	pair<pair<pair<ld, ld>, pair<ld, ld>>, pair<pair<ld, ld>, pair<ld, ld>>> anssq;
	while (i <= stop)
	{
//		cout << "turn " << endl;
		while (getshift(st[i + 1] - st[i], curang) < eps) i++;
		while (getshift(st[cur1 + 1] - st[cur1], curang + pi / 2) < eps) cur1++;
		while (getshift(st[cur2 + 1] - st[cur2], curang + pi) < eps) cur2++;
		while (getshift(st[cur3 + 1] - st[cur3], curang + 3 * pi / 2) < eps) cur3++;
		ld shift = 4 * pi;
		shift = min(shift, getshift(st[i + 1] - st[i], curang));
		shift = min(shift, getshift(st[cur1 + 1] - st[cur1], curang + pi / 2));
		shift = min(shift, getshift(st[cur2 + 1] - st[cur2], curang + pi));
		shift = min(shift, getshift(st[cur3 + 1] - st[cur3], curang + 3 * pi / 2));
//		cout << "shift = " << (D)shift << endl;
		ld l = curang;
		ld r = curang + shift;
		for (int IT = 0; IT < 100; IT++)
		{
			ld ml = (2 * l + r) / 3;
			ld mr = (l + 2 * r) / 3;
			if (getf(st[i] - st[cur2], st[cur1] - st[cur3], ml) < getf(st[i] - st[cur2], st[cur1] - st[cur3], mr)) r = mr;
			else l = ml;
		}
//		cout << i << ' ' << cur1 << ' ' << cur2 << ' ' << cur3 << ' ' << (D)curang << ' ' << (D)l << ' ' << endl;
//		cout << st[cur1].x << ' ' << st[cur3].x << ' ' << st[cur3].y << endl;
		ld curans = getf(st[i] - st[cur2], st[cur1] - st[cur3], l);
		if (curans < answer)
		{
			answer = curans;
			anssq = getanssq(st[i], st[cur1], st[cur2], st[cur3], l);
		}
/*		cout << (D)answer << endl;
		cout << (D)getshift(st[i + 1] - st[i], curang) << endl;
		cout << (D)getshift(st[cur1 + 1] - st[cur1], curang + pi / 2) << endl;
		cout << (D)getshift(st[cur2 + 1] - st[cur2], curang + pi) << endl;
		cout << (D)getshift(st[cur3 + 1] - st[cur3], curang + 3 * pi / 2) << endl;*/
		curang += shift;
/*		cout << (D)getshift(st[i + 1] - st[i], curang) << endl;
		cout << (D)getshift(st[cur1 + 1] - st[cur1], curang + pi / 2) << endl;
		cout << (D)getshift(st[cur2 + 1] - st[cur2], curang + pi) << endl;
		cout << (D)getshift(st[cur3 + 1] - st[cur3], curang + 3 * pi / 2) << endl;*/
	}
	cout.precision(20);
//	cout << (D)answer << endl;
	out(anssq.fi.fi);
	out(anssq.fi.se);
	out(anssq.se.fi);
	out(anssq.se.se);
	re 0;
}
