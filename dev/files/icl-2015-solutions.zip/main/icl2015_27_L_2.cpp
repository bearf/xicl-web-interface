#define _USE_MATH_DEFINES
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define sz(x) ((int)x.size())
#define fi first
#define se second
#define re return
#define y0 y248590
#define y1 y5427895
#define j0 j5234895
#define j1 j438759
#define prev prev348957
#define next next457834
#define sqrt(x) sqrt(abs(x))

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef pair<ll, ll> pll;
typedef vector<string> vs;
typedef long double ld;
typedef double D;

template<class T> T gcd (T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> inline T abs (T a) { re a < 0 ? -a : a; }
template<class T> inline T sqr (T a) { re ((a) * (a)); }

const int maxn = 100005;

int n;

int a[maxn];
int maxa, kvmax, kvmax1;
ll answer;

void check(int t)
{
	if (t > maxa) answer = min(answer, (ll)t);
	else if (t == maxa)
	{
		answer = min(answer, (ll)maxa * kvmax);
	}
	else if (t == maxa - 1)
	{
		if (kvmax > 1) answer = min(answer, (ll)(kvmax - 1) * maxa);
		else answer = min(answer, (ll)(kvmax1 + 2) * (maxa - 1));
	} else
	{
		if (kvmax > 1) answer = min(answer, (ll)(kvmax - 1) * maxa);
		else answer = min(answer, (ll)(kvmax1 + 1) * (maxa - 1));
	}
}

int main () {
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
		if (a[i] > maxa)
		{
			maxa = a[i];
			kvmax = 0;
		}
		if (a[i] == maxa) kvmax++;
	}
	if (maxa == 0)
	{
		printf("%d\n", 0);
		return 0;
	}
	kvmax1 = 0;
	for (int i = 0; i < n; i++) if (a[i] == maxa - 1) kvmax1++;
	answer = (ll)kvmax * maxa;
	for (int i = 0; i < n; i++) if (a[i] == maxa)
	{
		if (i + 1 < n) check(a[i + 1] + 1);
		if (i - 1 >= 0) check(a[i - 1] + 1);
	}
	for (int i = 0; i < n; i++) if (a[i] != 0)
	{
		if (i + 1 < n && a[i + 1] == maxa) answer = min(answer, (ll)maxa + 1);
		if (i - 1 >= 0 && a[i - 1] == maxa) answer = min(answer, (ll)maxa + 1);
	}
	cout << answer << endl;
	re 0;
}
