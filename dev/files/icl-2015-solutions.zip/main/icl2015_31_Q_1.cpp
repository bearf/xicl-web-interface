#include <iostream>
#define fin cin
#define fout cout

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

typedef long long ll;

ll n, k;


ll c(ll n, ll k)
{
    ll res = 1;
    for (ll i = 1; i <= k; i++)
    {
        res *= (n - i + 1);
        res /= i;
    }
    return res;
}


ll katalan(ll k)
{
    return c(2 * k, k) / (k + 1);
}


int main()
{
    fin >> n >> k;
    if (n < 2 * k)
    {
        fout << 0 << endl;
        return 0;
    }
    fout << (c(n, 2 * k) * katalan(k));
    return 0;
}
