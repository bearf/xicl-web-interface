#define _CRT_SECURE_NO_WARNINGS
#include <ios>
#include <string>
#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <vector>
#include <map>
#include <iomanip>
using namespace std;

int n, a[200000], ma = -1, k = 0, mi = 2000000000, ind1 = -1, ind2 = -1;

int main()
{
	#ifdef _DEBUG
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	#endif
	cin >> n;
	for (int i = 0; i < n; i++){
		cin >> a[i];
		ma = max(ma, a[i]);
	}
	for (int i = 0; i < n; i++){
		if (a[i] == ma){
			k++;
		}
	}
	for (int i = 1; i < n - 1; i++){
		if (a[i] != 0){
			if (a[i - 1] == ma){
				mi = min(mi, min(ma + 1, ma * k));
			}else{
				if (a[i] == ma){
					if (a[i - 1] == ma - 1){
						mi = min(mi, ma * k);
					}else{
						mi = min(mi, ma * (k - 1));
					}
				}
			}
			if (a[i + 1] == ma){
				mi = min(mi, min(ma + 1, ma * k));
			}else{
				if (a[i] == ma){
					if (a[i + 1] == ma - 1){
						mi = min(mi, ma * k);
					}else{
						mi = min(mi, ma * (k - 1));
					}
				}
			}
		}
	}
	int i;
	i = n - 1;
	if (a[i - 1] == ma){
		mi = min(mi, min(ma + 1, ma * k));
	}else{
		if (a[i] == ma){
			if (a[i - 1] == ma - 1){
				mi = min(mi, ma * k);
			}else{
				mi = min(mi, ma * (k - 1));
			}
		}
	}
	i = 0;
	if (a[i + 1] == ma){
		mi = min(mi, min(ma + 1, ma * k));
	}else{
		if (a[i] == ma){
			if (a[i + 1] == ma - 1){
				mi = min(mi, ma * k);
			}else{
				mi = min(mi, ma * (k - 1));
			}
		}
	}
	cout << mi;
	/*if (k > 2){
		cout << ma + 1;
		return 0;
	}
	if (k == 2){
		if (ind1 == 0){
			if (a[1] < ma - 1){
				cout << ma;
				return 0;
			}else{
				if (ind2 == n - 1){
					if (a[n - 2] < ma - 1){
						cout << ma;
						return 0;
					}else{
						cout << ma + 1;
						return 0;
					}
				}else{
					if (a[ind2 - 1] < ma - 1 || a[ind2 + 1] < ma - 1){
						cout << ma;
					}else{
						cout << ma + 1;
					}
				}
			}
		}
		else if(ind1 == n - 1){
			if (a[n - 2] < ma - 1){
				cout << ma;
			}else{
				if ()
			}
		}else{

		}
	}*/
	return 0;
}