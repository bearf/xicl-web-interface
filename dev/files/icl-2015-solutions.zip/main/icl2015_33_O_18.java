import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.StringTokenizer;

public class Solution {

	boolean swap = false;

	Point[] houses;

	double[] steps = { 1, 0.1, 0.001, 0.000_1, 0.000_01, 0.000_001 };

	Line line;

	double count(double startX, double endX, double step) {

		Point p = line.at(startX);

		double minDist = 0;
		for (int i = 0; i < houses.length; i++) {
			minDist += p.squareDistance(houses[i]);
		}
		double ansX = startX;
		for (double x = startX; compareEps(x, endX) <= 0; x += step) {
			p = line.at(x);
			double dist = 0;
			for (int i = 0; i < houses.length; i++) {
				dist += p.squareDistance(houses[i]);
			}
			if (dist < minDist) {
				minDist = dist;
				ansX = x;
			}
		}

		return ansX;
	}

	void solve() throws NumberFormatException, IOException {
		Point linePoint1 = new Point(io.nextInt(), io.nextInt());
		Point linePoint2 = new Point(io.nextInt(), io.nextInt());

		if (compareEps(linePoint1.x, linePoint2.x) == 0) {
			swap = true;
			linePoint1.swap();
			linePoint2.swap();
		}

		Vector v = new Vector(linePoint2.x - linePoint1.x, linePoint2.y
				- linePoint1.y);
		v.normalize();

		if (v.x < 0) {
			v.x *= -1;
			v.y *= -1;
		}

		double minX = -10_111;
		double maxX = 10_111;

		int k = io.nextInt();
		houses = new Point[k];

		for (int i = 0; i < k; i++) {
			Point house = new Point(io.nextInt(), io.nextInt());
			if (swap) {
				house.swap();
			}
			houses[i] = house;
		}

		line = new Line(linePoint1, linePoint2);

		double ansX = count(minX, maxX, steps[0] * v.x);

		for (int i = 1; i < steps.length; i++) {
			ansX = count(ansX - (steps[i - 1] * v.x), ansX
					+ (steps[i - 1] * v.x), steps[i] * v.x);
		}

		Point ans = line.at(ansX);

		double fullLength = 0;

		for (int i = 0; i < houses.length; i++) {
			fullLength += Math.sqrt(houses[i].squareDistance(ans));
		}

		if (swap) {
			ans.swap();
		}

		String s = fullLength + "\n"
				+ String.format(Locale.US, "%.6f %.6f", ans.x, ans.y);
		io.println(s);
		System.err.println(s);

	}

	static final double EPS = 1e-9;

	int compareEps(double a, double b) {
		if (Math.abs(a - b) < EPS) {
			return 0;
		}
		if (a < b) {
			return -1;
		}
		return 1;
	}

	class Point {
		double x;
		double y;

		public Point(double x, double y) {
			this.x = x;
			this.y = y;
		}

		double squareDistance(Point p) {
			double dx = x - p.x;
			double dy = y - p.y;
			return dx * dx + dy * dy;
		}

		void swap() {
			double t = x;
			x = y;
			y = t;
		}

	}

	class Vector extends Point {

		public Vector(double x, double y) {
			super(x, y);
		}

		double length() {
			return Math.sqrt(new Point(0, 0).squareDistance(this));
		}

		void normalize() {
			double l = length();
			x /= l;
			y /= l;
		}

	}

	class Line {
		double k;
		double b;

		Line(Point p, Point q) {
			k = (q.y - p.y) / (q.x - p.x);
			b = q.y - k * q.x;
		}

		Point at(double x) {
			return new Point(x, k * x + b);
		}

	}

	// ~~~~~~~~~~~~~~~~~~~//
	public static void main(String[] args) throws IOException {
		Solution solution = new Solution();
		solution.io = new MyIO();
		solution.solve();
		solution.io.close();
	}

	MyIO io;

	static class MyIO {
		PrintWriter out;
		BufferedReader in;

		public MyIO() throws FileNotFoundException {
			File myIn = new File("input.txt");
			File myOut = new File("output.txt");

			if (myIn.exists()) {
				in = new BufferedReader(new FileReader(myIn));
				out = new PrintWriter(myOut);
				return;
			}

			in = new BufferedReader(new InputStreamReader(System.in));
			out = new PrintWriter(System.out);
		}

		void println(double d) {
			out.println(d);
		}

		void println(String s) {
			out.println(s);
		}

		void print(String s) {
			out.print(s);
		}

		void println(int i) {
			out.println(i);
		}

		void print(int i) {
			out.print(i);
		}

		String nextLine() throws IOException {
			return in.readLine();
		}

		StringTokenizer tokenizer = new StringTokenizer("");

		String next() throws IOException {
			while (!tokenizer.hasMoreElements()) {
				tokenizer = new StringTokenizer(nextLine());
			}
			return tokenizer.nextToken();
		}

		int nextInt() throws NumberFormatException, IOException {
			return Integer.parseInt(next());
		}

		long nextLong() throws NumberFormatException, IOException {
			return Long.parseLong(next());
		}

		void close() throws IOException {
			in.close();
			out.close();
		}
	}
}
