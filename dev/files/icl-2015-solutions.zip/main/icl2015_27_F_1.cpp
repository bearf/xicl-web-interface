#define _USE_MATH_DEFINES
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define sz(x) ((int)x.size())
#define fi first
#define se second
#define re return
#define y0 y248590
#define y1 y5427895
#define j0 j5234895
#define j1 j438759
#define prev prev348957
#define next next457834
#define sqrt(x) sqrt(abs(x))

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef pair<ll, ll> pll;
typedef vector<string> vs;
typedef long double ld;
typedef double D;

template<class T> T gcd (T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> inline T abs (T a) { re a < 0 ? -a : a; }
template<class T> inline T sqr (T a) { re ((a) * (a)); }

const int PN = 16;
const int P[PN] = {3, 5, 7, 11, 13, 17, 19, 21, 23, 29, 31, 37, 41, 43, 47, 53};
const int mod = 1000*1000*1000+9;

int n;
int m;
ld lgP[PN];

pair<ld, int> res[1000][PN];
int was[1000][PN];

vi v;

int power (int a, int b) {
	int c = 1;
	while (b) {
		if (b & 1) c = ((ll)c * a) % mod;
		a = ((ll)a * a) % mod;
		b /= 2;
	}
	re c;
}

pair<ld, int> go (int i, int j) {
	if (i == 0) re mp (0, 1);
	if (j == PN) re mp (1e100, 0);
	if (was[i][j]) re res[i][j];
	was[i][j] = 1;
	pair<ld, int> cur (1e100, 0);
	for (int t = 0; t < i; t++)
		if (v[i] % v[t] == 0) {
			pair<ld, int> tmp = go (t, j + 1);
			tmp.fi += lgP[j] * (v[i] / v[t] - 1);
			tmp.se = ((ll)tmp.se * power (P[j], v[i] / v[t] - 1)) % mod;
//			printf ("%d %d = %.10f %d\n", i, j, (D)tmp.fi, tmp.se);	
			cur = min (cur, tmp);
		}
//	printf ("%d %d = %.10f %d\n", i, j, (D)cur.fi, cur.se);	
	re res[i][j] = cur;
}

int main () {
	for (int i = 0; i < PN; i++)
		lgP[i] = log ((ld)P[i]);
	scanf ("%d", &n);
	for (int i = 1; i <= n; i++)
		if (n % i == 0)
			v.pb (i);
	pair<ld, int> res = go (sz (v) - 1, 0);
	printf ("%d\n", res.se);
//	fprintf (stderr, "%.10f\n", (D)res.fi);
	re 0;
}
