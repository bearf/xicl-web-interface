#define _USE_MATH_DEFINES

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <bitset>
#include <cassert>
#include <cmath>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) int(a.size())
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define all(a) a.begin(),a.end()

typedef pair<int,int> pt;
#define ft first
#define sc second

typedef long long li;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = 1e9;

int n, s, f;

bool read() {
	if(!(cin >> n >> s >> f))
		return false;
	return true;
}

void solve() {
	if (s == f) {
		puts("-1");
		return;
	}

	if(s > f)
		swap(s, f);

	int res = 0;

	if (s > 1) {
		res++;
		s = s + 1;
	}

	if (f < n) {
		res++;
		f = f - 1;
	}

	if (s > f) {
		puts("-1");
		return;
	}

	res += (f - s) / 3 + (f - s) % 3;
	printf("%d\n", res);
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif

	while (read()) {
		solve();
	}

	cerr << clock() * 1000 / CLOCKS_PER_SEC << endl;
	return 0;
}