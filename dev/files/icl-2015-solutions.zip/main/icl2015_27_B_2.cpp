#define _USE_MATH_DEFINES
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define sz(x) ((int)x.size())
#define fi first
#define se second
#define re return
#define y0 y248590
#define y1 y5427895
#define j0 j5234895
#define j1 j438759
#define prev prev348957
#define next next457834
#define sqrt(x) sqrt(abs(x))

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef pair<ll, ll> pll;
typedef vector<string> vs;
typedef long double ld;
typedef double D;

template<class T> T gcd (T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> inline T abs (T a) { re a < 0 ? -a : a; }
template<class T> inline T sqr (T a) { re ((a) * (a)); }

const int mod = 1000*1000*1000+9;

int n;
int m;
int res[2][310][310];

int main () {
	cin >> n >> m;
	res[0][0][0] = 1;
	for (int i = 0; i < n; i++) {
		int ci = i & 1;
		int ni = 1 - ci;
		memset (res[ni], 0, sizeof (res[ni]));
		for (int j = 0; j <= i; j++)
			for (int k = j; k <= i && k <= m; k++)
				for (int t = -1; t <= 1; t++)
					if (j + t >= 0)
						(res[ni][j + t][max (k, j + t)] += res[ci][j][k]) %= mod;
	}
	cout << res[n & 1][0][m] << endl;
	re 0;
}
