#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main(){
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);

    long long n;
    long long h, m, s;

    cin >> n;

    vector<long long> t(n);

    for(int i = 0; i < n; i++){
        cin >> h >> m >> s;

        t[i] = h * 1000000000000 + m * 1000000 + s;
    }

    sort(t.begin(), t.end());

    vector<long long> f(n), e(n);

    long long ans = 1e18;

    f[0] = 0;

    for(long long i = 1; i < n; i++){
        f[i] = f[i - 1] + (t[i] - t[i - 1]) * i;
    }

    long long p = 12000000000000;

    e[n - 1] = 0;

    for(long long i = n - 2; i >= 0; i--){
        e[i] = e[i + 1] + p - t[i + 1];
    }

    for(long long i = 0; i < n; i++){
        long long k = f[i] + e[i] + (n - i - 1) * t[i];

        if(k < ans)
            ans = k;
    }

    cout << ans / 1000000000000 << ' ' << ans % 1000000000000 / 1000000 << ' ' << ans % 1000000;

    return 0;
}
