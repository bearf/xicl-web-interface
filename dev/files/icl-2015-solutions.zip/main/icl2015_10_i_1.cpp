#define _USE_MATH_DEFINES

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <bitset>
#include <cassert>
#include <cmath>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) int(a.size())
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define all(a) a.begin(),a.end()

typedef pair<int,int> pt;
#define ft first
#define sc second

typedef long long li;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = 1e9;

li n;
int m;

bool read() {
	if (!(cin >> n >> m))
		return false;
	return true;
}

li C(li n, li k) {
	if (n < k)
		return 0;
	ld res = 1;
	int ft = 2;
	for (int i = n - k + 1; i <= n; ++i) {
		res *= i;
		while (ft <= k && res >= ft)
			res /= ft++;
		if (ft > k && res > 1e17)
			break;
	}
	if (res > 1e17)
		res = 1e17;
	return res + 0.5;
}

void solve() {
	vector<li> ans;
	forn (i, m) {
		li l = 0, r = 1e18;
		if (!ans.empty())
			r = ans.back() - 1;
		while(r - l > 1) {
			li mid = (r + l) / 2;
			if (C(mid, m - i) <= n)
				l = mid;
			else
				r = mid;
		}
		for (int cur = r; cur >= l; --cur)
			if (C(cur, m - i) <= n) {
				n -= C(cur, m - i);
				ans.push_back(cur);
				break;
			}
	}
	forn (i, ans.size())
		cout << ans[i] << ' ';
	li nn = 0;
	cout << endl;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif

	while (read()) {
		solve();
	}

	cerr << "TIME: " << clock() * 1000 / CLOCKS_PER_SEC << endl;
	return 0;
}