#include <bits/stdc++.h>
#include <vector>

using namespace std;

#ifdef FOOBAR
    ifstream fin("input.txt");
#define cin fin
#endif // FOOBAR

int n;
int mx = -1, k = 0, res;
vector<int> a;

int main() {
    ios_base::sync_with_stdio(false);

    cin >> n;

    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        if (x > mx) {
            mx = x;
            k = 1;
        } else if (x == mx) {
            k++;
        }

        a.push_back(x);
    }

    res = mx * k;

    if (res != 0) {
    if (k > 2) {
        if (a[0] == mx && a[1] > 0) {
            res = mx + 1;
        }

        for (int i = 1; i < n - 1; i++) {
            if (a[i] == mx && (a[i - 1] > 0 || a[i + 1] > 0)) {
                res = mx + 1;
            }
        }

        if (a[n - 1] == mx && a[n - 2] > 0) {
            res = mx + 1;
        }
    } else if (k > 1) {
        for (int i = 1; i < n; i++) {
            if (a[i] == mx && a[i - 1] == mx) {
                res = min(res, mx + 1);
            }
        }

        if (a[0] == mx && a[1] < mx - 2) {
            res = mx;
        }

        for (int i = 1; i < n - 1; i++) {
            if (a[i] == mx && (a[i - 1] < mx - 2 || a[i + 1] < mx - 2)) {
                res = mx;
            }
        }

        if (a[n - 1] == mx && a[n - 2] < mx - 2) {
            res = mx;
        }

    } else if (k == 1) {
        if (a[0] == mx && a[1] < mx - 2) {
            res = mx - 1;
        }

        for (int i = 1; i < n - 1; i++) {
            if (a[i] == mx && (a[i - 1] < mx - 2 || a[i + 1] < mx - 2)) {
                res = mx - 1;
            }
        }

        if (a[n - 1] == mx && a[n - 2] < mx - 2) {
            res = mx - 1;
        }
    }
    }

    cout << res;

    return 0;
}
