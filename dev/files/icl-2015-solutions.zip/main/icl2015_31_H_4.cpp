#include <iostream>
#include <cassert>
#define fin cin
#define fout cout

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

int n, s, f;


int solve(int n, int s, int f)
{
    if (s == f)
    {
        if (n == 1)
            return 0;
        return -1;
        //return 2;
    }
    if (s > f)
    {
        f = n - f + 1;
        s = n - s + 1;
    }
    assert(f >= s);
    if (s == f - 1)
    {
        if ((s == 1) && (f == n))
            return 1;
        if ((s == 1) || (f == n))
            return 1;
        return -1;
        //return 3;
    }
    return f - s;
}

int main()
{
    fin >> n >> s >> f;
    fout << solve(n, s, f) << endl;
    return 0;
}
