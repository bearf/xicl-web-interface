#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

//ifstream cin("input.txt");
//ofstream cout("output.txt");



vector <long long> a, b, c;
int n;
long long ans = 2e18, aa, ab, ac;
long long pans, paa, pab, pac;
long long s, q, w, qaa, qab, qac;

long long qwer(long long x, long long y, long long z){
	q = (x * 1000000 + y) * 1000000 + z;
	if (w >= q)
		return w - q;
	else 
		return w + 12000000000000 - q;
}




int main(){
	cin >> n;
	a.resize(n);
	b.resize(n);
	c.resize(n);
	for (int i = 0; i < n; i++)
	{
		cin >> a[i] >> b[i] >> c[i];
	}
	for (int i = 0; i < n; i++)
	{
		pans = 0;
		paa = 0;
		pab = 0;
		pac = 0;
		w = (a[i] * 1000000 + b[i]) * 1000000 + c[i];
		for (int j = 0; j < n; j++){
			if (i != j)
			{
				s = qwer(a[j], b[j], c[j]);
				qaa = s / 1000000000000;
				qab = s % 1000000000000 / 1000000;
				qac = s % 1000000;
				paa += qaa;
				pab += qab;
				pac += qac;
				pans = paa + pab + pac;
				if (pans > ans)
					break;
			}
		
		}
		if (ans > pans){
			ans = pans;
			aa = paa;
			ab = pab;
			ac = pac;
		}
	}
	cout << aa << ' ' << ab << ' ' << ac;
}