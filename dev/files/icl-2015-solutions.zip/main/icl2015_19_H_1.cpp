#include <iostream>

using namespace std;

int main()
{
  //
 //   freopen("in.txt", "r", stdin);
    int n, s, f;
    cin >> n >> s >> f;
    s--;
    f--;
    if (s > f)
        swap(s, f);
    int l = s;
    int r = n - 1 - f;
    int len = f - s;
    if (s == f) {
        printf("-1\n");
        return 0;
    }
//    cerr << s << " " << f << endl;
    if (s + 1 == f) {
        if (l == 0 || r == 0) {
            printf("1\n");
        }
        else
            printf("-1\n");
        return 0;
    }
    int ans = 0;
   // cerr << "s f l r len" << s << " " << f << " " << l << " " << r << endl;

    if (l > 0) {
        len--;
        ans++;
    }
    if (r > 0) {
        len--;
        ans++;
    }
   //cerr << "ans: " << ans << endl;
    ans += len / 3;
    ans += len % 3;
    printf("%d\n", ans);

    return 0;
}
