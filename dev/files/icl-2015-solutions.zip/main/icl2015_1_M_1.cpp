#include <cstdio>
#include <cstring>
#include <iostream>
#include <set>
#include <queue>
#include <cmath>
#include <vector>
#include <map>
#include <algorithm>
#include <string>
using namespace std;

#define ll long long
#define ld long double
#define mp make_pair
#define pb push_back
#define forn(i, n) for(int i = 0; i < n; i++)

const int inf = 1 << 30;
const ld eps = 1e-9;

int n, a, b, c;

string s[200];

char wh[] = "white", blac[] = "black", gol[] = "gold", bl[] = "blue";


bool white(string s){
	 int l = s.size();
	 bool ex;
	 forn(i, l - 4){
		 ex = true;
		 forn(j, 5) 
			 if (s[i + j] != wh[j]) ex = false;
		 if (ex) return true;
	 }
	 return false;
}

bool gold(string s){
	 int l = s.size();
	 bool ex;
	 forn(i, l - 3){
		 ex = true;
		 forn(j, 4) 
			 if (s[i + j] != gol[j]) ex = false;
		 if (ex) return true;
	 }
	 return false;
}

bool blue(string s){
	 int l = s.size();
	 bool ex;
	 forn(i, l - 3){
		 ex = true;
		 forn(j, 4) 
			 if (s[i + j] != bl[j]) ex = false;
		 if (ex) return true;
	 }
	 return false;
}

bool black(string s){
	 int l = s.size();
	 bool ex;
	 forn(i, l - 4){
		 ex = true;
		 forn(j, 5) 
			 if (s[i + j] != blac[j]) ex = false;
		 if (ex) return true;
	 }
	 return false;
}

int main(){
	scanf("%d\n", &n);
	forn(i, n){
		getline(cin, s[i]);
	}

	forn(i, n){
		if (white(s[i]) && gold(s[i])) b++;
		else{
			if (blue(s[i]) && black(s[i])) a++;
			else c++;
		}
	}

	printf("%.9Lf\n%.9Lf\n%.9Lf", (ld) a / (n + 0.0) * 100, b / (n + 0.0) * 100, c / (n + 0.0) * 100); 

	return 0;
}