#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iomanip>
using namespace std;
bool ser(string s, string pod)
{
    for (int i = 0; i < (int)s.length() - (int)pod.length() + 1; i++)
    {
        bool flag = false;
        for (int j = 0; j < pod.length(); j++)
            if (s[i + j] != pod[j])
                flag = true;
        if (!flag)
            return true;
    }
    return false;
}
int main()
{
    int n;
    cin >> n;
    string s1;
    getline(cin ,s1);
    int kol1 = 0;
    int kol2 = 0;
    int kol3 = 0;
    for (int i = 0; i < n; i++)
    {
        string s;
        getline(cin, s);
        if (ser(s, "gold") && ser(s, "white"))
        {
            kol2++;
        }
        else
            if (ser(s, "black") && ser(s, "blue"))
            {
                kol1++;
            }
            else
                kol3++;
    }
    cout <<setprecision(10) << fixed << kol1 / (n * 1.0) * 100<< "\n" << kol2 / (n * 1.0) * 100 << "\n" << kol3 / (n *1.0) * 100;
}
