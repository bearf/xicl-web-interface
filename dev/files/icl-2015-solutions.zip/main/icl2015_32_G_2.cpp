#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
typedef long long ll;

const ll a = 1e6;
const ll b = 1e12;
const ll d = 12*b;
int main(){
	//freopen("in.txt","r",stdin);
	int n;
	cin >> n;
	vector <vector <ll> >  t(4);
	
	for (int i = 0; i < n; i++) {
		ll h,m,s;
		cin >> h >> m >> s;
		if (h >=0 && h < 3)
			t[0].push_back(h*b + m*a + s);
		if (h >= 3 && h < 6)
			t[1].push_back(h*b + m*a + s);
		if (h >= 6 && h < 9)
			t[2].push_back(h*b + m*a + s);
		if (h >= 9)
			t[3].push_back(h*b + m*a + s);
	}
	for(int i = 0; i < 4; i++)
		sort(t[i].begin(), t[i].end());


	ll  r = 0;
	vector <ll> x(4, -1);
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < t[i].size(); j++) 
		  r += t[i].back() - t[i][j];
		if(!t[i].empty())
			x[i] = t[i].back();		
	}

	ll mn = -1;

	for (int i = 0; i < x.size(); i++) {
		if(x[i] == -1)
			continue;
		ll val = 0;
		for(int j  = 0; j < x.size(); j++){
			if(x[j] == -1)
				continue;
			if(i != j){
				ll aa = (x[i] - x[j]);
				if(aa < 0)
					aa += d;
				val += aa * t[j].size();
			}
		}
	    if(mn == -1 || mn > val)
			mn = val;
	}
	
	mn += r;

	ll hh = mn / b;
	mn = mn - hh * b;
	ll mm = mn / a;
	ll ss = mn - mm * a;

	cout<<hh<<' '<<mm<<' '<<ss<<endl;
	
}