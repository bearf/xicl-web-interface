#include <iostream>
#include <vector>
using namespace std;
int foundm(vector <int> v){
	int m = 0;
	for (int i = 0; i < v.size(); i++) {
		if (v[i] > v[m]) m = i;
	}
	return m;
}


int main(){
#ifdef _DEBAG
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#else
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	bool b = false;
	int n, i, r = 0, m = 0;
	cin >> n;
	vector <int> v(n);
	for (i = 0; i < n; i++){
		cin >> v[i];
		if (v[i] > v[m]) m = i;
	}
	for (i = 0; i < n; i++) if (v[i] == v[m] && i != m){
		if (i != 0)	if (v[i] <= v[i-1]+1){ r += v[i]; b = true; }
	    if (i != n && b != true) if (v[i] <= v[i + 1] + 1) r += v[i];
	}
	i = m;
	if (i != 0)	if (v[i] <= v[i-1]+2){ r += v[i]; b = true; }
	if (i != n && b != true) if (v[i] <= v[i + 1] + 2) r += v[i];
	cout << r;
	return 0;
}