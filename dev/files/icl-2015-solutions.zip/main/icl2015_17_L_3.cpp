#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
#include <cstring>
#include <map>
#include <algorithm>
#include <ctime>

using namespace std;

typedef long long LL;

#define all(x) (x).begin(), (x).end()
#define INF 1E+9
#define INFll 1E+18

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int n;
	cin >> n;

	vector <int> p(n);

	int mx = 0, k = 0;

	for (int i = 0; i < n; ++i) {
		cin >> p[i];
		if (p[i] == mx)
			++k;
		if (p[i] > mx) {
			mx = max(mx, p[i]);
			k = 1;
		}
	}

	if (k == 1) {
		for (int i = 0; i < n; ++i) {
			if (i && p[i] == mx && p[i-1] <= mx - 3) {
				cout << mx - 1;
				return 0;
			}
			if (i != n - 1 && p[i] == mx && p[i+1] <= mx - 3) {
				cout << mx - 1;
				return 0;
			}
		}	
		cout << mx;
		return 0;
	}
	else {
		for (int i = 0; i < n; ++i) {
			if (i && p[i] == mx && p[i - 1] != 0) {
				cout << mx + 1;
				return 0;
			}
			if (i != n - 1 && p[i] == mx && p[i + 1] != 0) {
				cout << mx + 1;
				return 0;
			}
		}
	}

	cout << mx * k;

	return 0;
}