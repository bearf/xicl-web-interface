#include<iostream>
using namespace std;
long long dp[50][50];
int main()
{
    long long i,j,l,r,n,k;
    cin>>n>>k;
    for(i=0;i<=n;i++)
        dp[i][0]=1;
    for(i=2;i<=n;i++)
    {
        for(j=1;j<=k;j++)
            for(r=0;r<i-1;r++)
                for(l=0;l<j;l++)
                    dp[i][j]+=dp[r][l]*dp[i-2-r][j-1-l];
        for(j=1;j<=k;j++)
            dp[i][j]=dp[i][j]*i/j/2;
    }
    cout<<dp[n][k]<<endl;
}
