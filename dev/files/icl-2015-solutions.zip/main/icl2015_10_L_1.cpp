#define _USE_MATH_DEFINES

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <bitset>
#include <cassert>
#include <cmath>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) int(a.size())
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define all(a) a.begin(),a.end()

typedef pair<int,int> pt;
#define ft first
#define sc second

typedef long long li;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = 1e9;

const int N = 100 * 1000 + 5;

int n;
li cnt[N], a[N], mx;

bool read() {
	if (!(cin >> n))
		return false;
	mx = 0;
	memset(cnt, 0, sizeof cnt);
	forn(i, n) {
		cin >> a[i];
		cnt[a[i]] ++;
		mx = max(mx, a[i]);
	}
	return true;
}

void solve() {
	li res = cnt[mx] * mx;
	forn(i, n) {
		if (!a[i])
			continue;
		for (int d = -1; d <= +1; d += 2) {
			int j = i + d;
			if (j < 0 || j >= n) continue;

			cnt[ a[i] ]--;
			cnt[ a[j] ]--;

			a[i]--;
			a[j]++;
		
			cnt[ a[i] ]++;
			cnt[ a[j] ]++;

			int cmx = mx + 1;
			while (!cnt[cmx])
				cmx--;

			res = min(res, cnt[cmx] * cmx);

			cnt[ a[i] ]--;
			cnt[ a[j] ]--;

			a[i]++;
			a[j]--;
		
			cnt[ a[i] ]++;
			cnt[ a[j] ]++;
		}
	}

	cout << res << endl;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif

	while (read()) {
		solve();
	}

	cerr << clock() * 1000 / CLOCKS_PER_SEC << endl;
	return 0;
}