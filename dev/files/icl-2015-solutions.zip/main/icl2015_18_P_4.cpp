	#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iomanip>
using namespace std;
int main(){
    long long f = 2;
    long long p, q;
    cin >> p >> q;
    vector<long long>a;
    long long g = __gcd(p, q);
    p /= g;
    q /= g;
    a.push_back(p / q);
    p = p % q;
    long long max1 = 1;
    while (p > 0)
    {
        long long q1 = (f * q) / __gcd(f, q);
        long long p1 = p * (q1 / q);
        long long koof = (q1 / f);
        long long kk = p1 / koof;
        a.push_back(min(kk, max1));
        p1 -= min(kk, max1) * koof;
        if (p1 == 0 || q1 == 0)
            break;
        g = __gcd(p1, q1);
        p1 /= g;
        q1 /= g;
        p = p1;
        q = q1;
        f *= (max1 + 2);
        max1++;
    }
    for (int i = 0; i < a.size(); i++)
        cout << a[i] << " ";
}
