#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <string>
#define ll long long
using namespace std;

const int MAXN = (int)1e5 + 47;
const int INF = (int)1e9;

int a[MAXN];

int n;

ll sum;

long long ans = 1e18;

int maxx = -1;

int num[MAXN];

bool good(int ind)
{
	return ind >= 0 && ind < n;
}

void solve(int ind)
{
	if(good(ind - 1))
	{
		num[a[ind]]--;
		num[a[ind - 1]]--;
		num[a[ind - 1] + 1]++;
		num[a[ind] - 1]++;
	}
	if(num[maxx + 1] != 0)
		ans = min(ans, num[maxx + 1] * (long long)(maxx + 1));
	else if(num[maxx] != 0)
		ans = min(ans, num[maxx] * (long long)maxx);
	else ans = min(ans, num[maxx - 1] * (long long)(maxx - 1));
	if(good(ind - 1))
	{
		num[a[ind]]++;
		num[a[ind - 1]]++;
		num[a[ind - 1] + 1]--;
		num[a[ind] - 1]--;
	}
	if(good(ind + 1))
	{
		num[a[ind]]--;
		num[a[ind + 1]]--;
		num[a[ind + 1] + 1]++;
		num[a[ind] - 1]++;
	}
	if(num[maxx + 1] != 0)
		ans = min(ans, num[maxx + 1] * (long long)(maxx + 1));
	else if(num[maxx] != 0)
		ans = min(ans, num[maxx] * (long long)maxx);
	else ans = min(ans, num[maxx - 1] * (long long)(maxx - 1));
	if(good(ind + 1))
	{
		num[a[ind]]++;
		num[a[ind + 1]]++;
		num[a[ind + 1] + 1]--;
		num[a[ind] - 1]--;
	}
}

int main()
{
	//freopen("input.in", "r", stdin);
	//freopen("output.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
		num[a[i]]++;
		maxx = max(maxx, a[i]);
	}
	for(int i = 0; i < n; i++)
	{
		solve(i);
	}
	cout << ans;
	return 0;
}