#include <bits/stdc++.h>

using namespace std;

const int N = 2e6;

long long n, k;
int m, pm;
int pr[N], rev[N];
vector<int> vec;

struct Num {
	int pt;
	vector<long long> pe;
	Num() {
		pt = 1;
		pe.resize(vec.size());
	}
	void operator *=(const Num& e) {
		for (int i = 0; i < pe.size(); i++) pe[i] += e.pe[i];
		pt = (pt * 1LL * e.pt) % m;
	}
	void operator /=(const Num& e) {
		for (int i = 0; i < pe.size(); i++) pe[i] -= e.pe[i];
		pt = (pt * 1LL * rev[e.pt]) % m;
	}
	void print() {
		cerr << pt << ", ";
		for (int i = 0; i < pe.size(); i++) cerr << pe[i] << " ";
		cerr << endl;
	}
};

int gcd(int x, int y) {
	while ((x > 0) && (y > 0)) {
		if (x > y) x %= y; else y %= x;
	}
	return x + y;
}

int pw(long long x, long long y) {
	x %= m;
	int res = 1;
	while (y) {
		if (y % 2) res = (res * 1LL * x) % m;
		x = (x * 1LL * x) % m;
		y /= 2;
	}
	return res;
}

Num fact(long long n) {
	Num res = Num();
	for (int i = 0; i < vec.size(); i++) {
		long long cnt = 0;
		long long nt = n;
		while (nt > 0) {
			nt /= vec[i];
			cnt += nt;
		}
		res.pe[i] = cnt;
	}
	int u = 1, v = 1;
	for (int i = 1; i < m; i++) {
		int ii = i;
		for (int j = 0; j < vec.size(); j++) {
			while (ii % vec[j] == 0) ii /= vec[j];
		}
		u = (u * 1LL * ii) % m;
		if (i <= n % m) {
//			cerr << ii << " ";
			v = (v * 1LL * ii) % m;
		}
	}
//	cerr << ": ";
//	cerr << u << " " << v << endl;
	u = pw(u, n / m);
	u = (u * 1LL * v) % m;
	res.pt = u;
	return res;
}

int main() {
//	freopen("input.txt", "r", stdin);
	cin >> n >> k >> m;
	for (int i = 2; i <= m; i++) pr[i] = i;
	for (int i = 2; i <= m; i++) {
		if (pr[i] == i) {
			for (int j = i + i; j <= m; j += i) pr[j] = i;
		}
	}
	pm = m;
	int last = -1;
	vec.clear();
	for (int i = m; i > 1; i /= pr[i]) {
		if (pr[i] != last) {
			pm -= pm / pr[i];
			vec.push_back(pr[i]);
		}
		last = pr[i];
	}
//	for (int i = 0; i < vec.size(); i++) cerr << vec[i] << " ";
//	cerr << endl;
	for (int i = 1; i < m; i++) rev[i] = pw(i, pm - 1);
	Num u = fact(n);
//	u.print();
	Num x = fact(k);
//	x.print();
	Num y = fact(n - k);
//	y.print();
	x *= y;
	u /= x;
	int ans = u.pt;
	for (int i = 0; i < u.pe.size(); i++) {
		int cur = pw(vec[i], u.pe[i]);
		ans = (ans * 1LL * cur) % m;
	}
	printf("%d\n", ans);
}