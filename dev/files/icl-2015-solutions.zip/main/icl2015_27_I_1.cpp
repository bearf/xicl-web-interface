#define _USE_MATH_DEFINES
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define sz(x) ((int)x.size())
#define fi first
#define se second
#define re return
#define y0 y248590
#define y1 y5427895
#define j0 j5234895
#define j1 j438759
#define prev prev348957
#define next next457834
#define sqrt(x) sqrt(abs(x))

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef pair<ll, ll> pll;
typedef vector<string> vs;
typedef long double ld;
typedef double D;

template<class T> T gcd (T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> inline T abs (T a) { re a < 0 ? -a : a; }
template<class T> inline T sqr (T a) { re ((a) * (a)); }

const int N = 2000;
const ll inf = 1e18;

ll n;
int m;

ll cnk[N][N];

int main () {
	for (int i = 0; i < N; i++)
		for (int j = 0; j <= i; j++)
			if (i == 0 || j % i == 0)
				cnk[i][j] = 1;
			else
				cnk[i][j] = min (cnk[i - 1][j] + cnk[i - 1][j - 1], inf);
	cin >> n >> m;
	if (m == 2) {
		ll l = 0, r = 2e8;
		while (r - l > 1) {
			ll s = (l + r) / 2;
			if (s * (s - 1) / 2 > n) r = s; else l = s;
		}
		cout << l << " " << n - l * (l - 1) / 2 << endl;
		n = 0;
	} else
	if (m <= 6) {
		ll cur = 1;
		int last = m - 1;
		for (; cur <= n; ) {
			last++;
			ll a = last;
			ll b = last - m;
			ll d = gcd (a, b);
			a /= d;
			b /= d;
			d = gcd (cur, b);
			cur /= d;
			b /= d;
			cur = cur * a;
		}
		for (int i = m; i > 0; i--) {
			for (int j = last; j > 0; j--) {
//				if (j < N) cur = cnk[j - 1][i]; else {
				if (j - 1 < i) cur = 0; else {
					int a = j - i;
					int b = j;
					ll d = gcd (a, b);
					a /= d;
					b /= d;
					d = gcd (cur, (ll)b);
					cur /= d;
					b /= d;
					cur = cur * a;
				}
//				cerr << cur << " " << j - 1 << " " << i << endl;
				if (cur <= n) {
					n -= cur;
					printf ("%d ", j - 1);
					last = j - 1;
					break;
				}
			}
//			cerr << cur << endl;
			if (cur != 0) {
				int a = i;
				int b = last - i + 1;
				ll d = gcd (a, b);
				a /= d;
				b /= d;
				d = gcd (cur, (ll)b);
				cur /= d;
				b /= d;
				cur *= a;
			}
//			cerr << cur << " " << last << " " << i - 1 << endl;
		}
	} else {
		ll last = N;
		for (int i = m; i >= 1; i--) {
			for (int j = last - 1; j >= 0; j--)
				if (cnk[j][i] <= n) {
					printf ("%d ", j);
					n -= cnk[j][i];
					last = j;
					break;
				}
		}
		printf ("\n");
	}	
	assert (n == 0);
	re 0;
}
