#include <string>
#include <cstring>
#include <iostream>
#include <fstream>
#include <deque>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <ctype.h>
#include <ctime>

#define _USE_MATH_DEFINES
#include <math.h>

#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define LL long long
#define mp make_pair
#define sqr(x) x*x

using namespace std;

void smain();

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif
	
	smain();

	return 0;
}

#define int long long
#define N 100001
int n, a[N];

int f(){
	int mx = *max_element(a, a + n);
	int cnt = 0;
	forn(i, n) if(a[i] == mx) cnt += 1;
	return cnt * mx;
}

int solve(){
	int mx = *max_element(a, a + n);
	int cnt = 0;
	forn(i, n) if(a[i] == mx) cnt += 1;
	int res = min(cnt * mx, mx + 1);

	if(res == 0){
		return res;
	}

	if(cnt == 1){
		int pos = max_element(a, a + n) - a;
		a[pos] -= 1;
		if(pos > 0 && a[pos] > 0){
			a[pos - 1] += 1;
			res = min(res, f());
			a[pos - 1] -= 1;
		}

		if(pos < n - 1 && a[pos] > 0){
			a[pos + 1] += 1;
			res = min(res, f());
			a[pos + 1] -= 1;
		}
		a[pos] += 1;
	}else{
		forn(i, n) if(a[i] == mx) {
			if(i > 0) {
				if(a[i - 1] < mx - 1) res = min(res, (cnt - 1) * mx);
			}
			if(i < n - 1) {
				if(a[i + 1] < mx - 1) res = min(res, (cnt - 1) * mx);
			}
		}
	}
	return res;
}

int solve_naive(){
	int res = N * N;
	forn(i, n){
		a[i] -= 1;
		if(i > 0) {
			a[i - 1] += 1;
			res = min(res, f());
			a[i - 1] -= 1;
		}
		if(i < n - 1) {
			a[i + 1] += 1;
			res = min(res, f());
			a[i + 1] -= 1;
		}
		a[i] += 1;
	}
	return res;
}

void smain() {
	cin >> n;
	forn(i, n) cin >> a[i];
	cout << solve() << endl;
}