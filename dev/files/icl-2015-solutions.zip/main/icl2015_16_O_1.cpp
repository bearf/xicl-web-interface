#include <bits/stdc++.h>

using namespace std;

struct Point {
    double x, y;

    Point() {}
    Point(double x, double y) : x(x), y(y) {}
};

double sqr(double x) {
    return x * x;
}

double dist(Point pt1, Point pt2) {
    return sqrt(sqr(pt1.x - pt2.x) + sqr(pt1.y - pt2.y));
}

int main() {
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);

    Point pt1, pt2;
    cin >> pt1.x >> pt1.y;
    cin >> pt2.x >> pt2.y;

    int k;
    cin >> k;

    vector<Point> pts(k);
    for (int i = 0; i < k; i++) {
        cin >> pts[i].x >> pts[i].y;
    }

    Point ptL = Point(pt1.x - 1000.0 * (pt1.x - pt2.x), pt1.y - 1000.0 * (pt1.y - pt2.y));
    Point ptR = Point(pt1.x + 1000.0 * (pt1.x - pt2.x), pt1.y + 1000.0 * (pt1.y - pt2.y));

        //cout << ptL.x << ' ' << ptL.y << endl;
        //cout << ptR.x << ' ' << ptR.y << endl;
        //cout << endl;

    double sumD1, sumD2;
    for (int i = 0; i < 5000; i++) {
        Point ptM1 = Point(ptL.x + (ptR.x - ptL.x) / 3.0, ptL.y + (ptR.y - ptL.y) / 3.0);
        Point ptM2 = Point(ptL.x + 2.0 * (ptR.x - ptL.x) / 3.0, ptL.y + 2.0 * (ptR.y - ptL.y) / 3.0);

        //cout << ptM1.x << ' ' << ptM1.y << endl;
        //cout << ptM2.x << ' ' << ptM2.y << endl;
        //cout << endl;

        sumD1 = 0.0, sumD2 = 0.0;
        for (int j = 0; j < k; j++) {
            sumD1 += dist(ptM1, pts[j]);
            sumD2 += dist(ptM2, pts[j]);
        }

        if (sumD1 < sumD2) {
            ptR = ptM2;
        } else {
            ptL = ptM1;
        }
    }

    printf("%.9lf\n", sumD1);
    printf("%.9lf %.9lf\n", ptL.x, ptL.y);
}
