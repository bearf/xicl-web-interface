#include <bits/stdc++.h>

using namespace std;

#define long long long

const long INF = 1000100010LL * 1000100010LL;
const int M = 1010;
const long K = 2000000;

vector<long> c[M];


long binom(long n, long k)
{
    if (k == 1)
        return n;
    if (k == 2)
        return n * (n - 1) / 2;

    return c[k][n];
}

void pre() {

    c[2].resize(K);
    for (long i = 0; i < K; ++i)
        c[2][i] = i * (i - 1) / 2;


    for (int j = 3; j < M; ++j) {
        //cerr << "j = " << j << "!\n";
        c[j].resize(j + 1);
        c[j][j] = 1;
        for (int i = j + 1; ; ++i)
            if (c[j][i - 1] + c[j - 1][i - 1] >= INF)
                break;
            else
                c[j].push_back(c[j][i - 1] + c[j - 1][i - 1]);
    }
}



long n, m, x[M];

void kill()
{
    long N = n;

    for (int i = m; i >= 1; --i) {
        long l = 0, r = INF, mid;

        if (i == 1)
            r = INF;
        if (i == 2)
            r = 1000000000LL;
        if (i >= 3)
            r = c[i].size() - 1;

        while (l < r)
        {
            mid = 1 + (l + r) / 2;
            assert(binom(mid, i) >= 0);
            if (binom(mid, i) > n)
                r = mid - 1;
            else
                l = mid;
            //cerr << "binom " << mid << " " << i << " -> " << binom(mid, i) << "!\n";
        }
        assert(binom(l, i) <= n);
        x[i] = l;
        //cerr << n << " - " << binom(l, i) << " \n";
        n -= binom(l, i);

        //cerr << n << "__\n";
    }
    assert(n == 0);
    for (int i = m; i >= 2; --i)
        assert(x[i] > x[i - 1]);
    assert(x[1] >= 0);
    long sum = 0;
    for (int i = m; i >= 1; --i) {
        assert(binom(x[i], i) >= 0);
        sum += binom(x[i], i);
    }
    assert(sum == N);

    for (int i = m; i >= 1; --i)
    {
        cout << x[i] << " ";
    }
    cout << "\n";
}

void test()
{
    for (int i = 1; ; ++i)
    for (int j = 2; j <= 200; ++j) {
        n = 1 + rand() % 1000000000, m = j;
        kill();
    }
}

int main()
{
#ifdef LOCAL
    freopen("i.in", "r", stdin);
#endif // LOCAL
    pre();
    //test();
    cin >> n >> m;
    kill();
    return 0;
}
