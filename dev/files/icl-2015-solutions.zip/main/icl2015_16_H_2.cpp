#include <bits/stdc++.h>

using namespace std;

int main() {
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);

    int n, s, f;
    cin >> n >> s >> f;

    if (f == s) {
        cout << -1 << endl;
        return 0;
    }

    --s, --f;

    bool rev = false;
    if (s > f) {
        rev = true;
        swap(s, f);
    }

    if (s != 0 && f != n - 1 && f - s == 1) {
        cout << -1 << endl;
        return 0;
    }

    int ans = 0;

    int v = s;
    //cout << v << endl;
    if (s > 0) {
        while (v - 2 >= 0) {
            v -= 2;
    //cout << v << endl;
        }
        ans++;
        if (v == 1) {
            v--;
        } else {
            v++;
        }
    //cout << v << endl;

        while (v < s) {
            v += 2;
    //cout << v << endl;
        }
    }
    while (v + 1 < f || (v + 1 == f && f == n - 1)) {
        v++;
    //cout << v << endl;
        ans++;
    }
    if (f < n - 1) {
        while (v + 2 < n) {
            v += 2;
    //cout << v << endl;
        }

        ans++;
        if (v == n - 2) {
            v++;
        } else {
            v--;
        }
    //cout << v << endl;

        while (v > f) {
            v -= 2;
    //cout << v << endl;
        }
    }

    cout << ans << endl;
}
