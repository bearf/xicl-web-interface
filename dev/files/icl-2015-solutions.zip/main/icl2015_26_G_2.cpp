#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
//    freopen("stdin", "r", stdin);
//    freopen("stdout", "w", stdout);

    int n,a,b,c;
    long long alarm[11000];

    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a>>b>>c;
        alarm[i] = a*1e12+b*1e6+c;
    }

    unsigned long long mintime = 12000000000000;
    for(int i=0;i<n;i++){ // kym koq se stremim
        unsigned long long time = 0;
        for(int j=0;j<n;j++) // obhojdane
        {
            if(alarm[i] < alarm[j]) time += 12*1e12 - (alarm[j] - alarm[i]);
            else time += alarm[i] - alarm[j];

        }
        if(mintime > time) mintime = time;
    }

    cout<<(mintime/1000000000000)<<' '<<(mintime % 1000000000000)/1000000<<' '<<(mintime%1000000)<<endl;

    return 0;
}
