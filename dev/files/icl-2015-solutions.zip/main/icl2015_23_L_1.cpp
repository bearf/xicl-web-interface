#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <deque>
#include <queue>
#include <complex>

using namespace std;

#define pb push_back
#define mp make_pair
#define pbk pop_back
#define fs first
#define sc second
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define all(x) (x).begin(), (x).end()
#define next _next
#define prev _prev
#define link _link
#define hash _hash
#define rank _rank
#ifdef LOCAL42
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif
#if _WIN32 || __WIN32__ || _WIN64 | __WIN64__
#define LLD "%I64d"
#else
#define LLD "%lld"
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));
const int N = int(1e5) + 100;

struct tr {

	int val;
	ll sum;

};

int maxv;
int a[N];
tr rmq[4 * N];

inline void calc(int v) {
	rmq[v] = rmq[v * 2];
	if (rmq[v * 2 + 1].val > rmq[v].val) {
		rmq[v] = rmq[v * 2 + 1];
	} else if (rmq[v * 2 + 1].val == rmq[v].val) {
		rmq[v].sum += rmq[v * 2 + 1].sum;
	}
}

inline void update(int a, int b) {
	a += maxv;
	rmq[a].val += b;
	rmq[a].sum += b;
	while (a > 1) {
		a /= 2;
		calc(a);
	}
}

int main() {
#ifdef LOCAL42
#define TASK "L"
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
#endif
	int n;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		scanf("%d", &a[i]);
	}
	maxv = 1;
	while (maxv < n) {
		maxv *= 2;
	}
	for (int i = 0; i < n; ++i) {
		rmq[i + maxv].val = a[i];
		rmq[i + maxv].sum = a[i];
	}
	for (int i = n; i < maxv; ++i) {
		rmq[i + maxv].val = -inf;
		rmq[i + maxv].sum = -inf;
	}
	for (int i = maxv - 1; i > 0; --i) {
		calc(i);
	}
	ll ans = rmq[1].sum;
	for (int i = 0; i < n; ++i) {
		if (a[i] == 0) {
			continue;
		}
		for (int j = -1; j <= 1; j += 2) {
			int ni = i + j;
			if (ni < 0 || ni >= n) {
				continue;
			}
			update(i, -1);
			update(ni, 1);
			ans = min(ans, rmq[1].sum);
			update(i, 1);
			update(ni, -1);
		}
	}
	cout << ans << endl;
	return 0;
}