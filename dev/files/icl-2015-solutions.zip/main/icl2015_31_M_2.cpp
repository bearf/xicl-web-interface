#include <iostream>
#include <string>
#define fin cin
#define fout cout

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

const int nmax = 110;

string s[nmax];
int n;


void read()
{
    fin >> n;
    getline(fin, s[0]);
    for (int i = 0; i < n; i++)
    {
        getline(fin, s[i]);
        //fout << s[i] << endl;
    }
}


bool ravno(int i, int j, string t)
{
    int k = t.length();
    return ((j <= s[i].length() - k) && (s[i].substr(j, k) == t));
}


void solve()
{
    int kol1 = 0, kol2 = 0, kol3 = 0;
    for (int i = 0; i < n; i++)
    {
        bool blue = false, black = false, white = false, gold = false;
        for (int j = 0; j < s[i].length(); j++)
        {
            if (ravno(i, j, "gold"))
                gold = true;
            if (ravno(i, j, "blue"))
                blue = true;
            if (ravno(i, j, "black"))
                black = true;
            if (ravno(i, j, "white"))
                white = true;
        }
        if (blue && black)
        {
            kol1++;
            continue;
        }
        if (white && gold)
        {
            kol2++;
            continue;
        }
        kol3++;
    }
    fout.precision(20);
    fout << (double)(kol1) / (double)(n) * 100.0 << endl << (double)(kol2) / (double)(n) * 100.0 << endl << (double)(kol3) / (double)(n) * 100.0 << endl;
}


int main()
{
    read();
    solve();
    return 0;
}
