#define _USE_MATH_DEFINES

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <bitset>
#include <cassert>
#include <cmath>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) int(a.size())
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define all(a) a.begin(),a.end()

typedef pair<int,int> pt;
#define ft first
#define sc second

typedef long long li;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = 1e9;

int MOD = 1e9 + 9;
int n, m;

bool read() {
	if (!(cin >> n >> m))
		return false;
	return true;
}

const int N = 305;
int dp[N][N][2];

void solve() {
	dp[0][0][0] = 1;
	if (m == 0)
		dp[0][0][0] = 0, dp[0][0][1] = 1;
	forn (i, n) {
		forn (j, m + 1) { 
			forn (k, 2) {	
				if (j)
					dp[i + 1][j - 1][k] = (dp[i + 1][j - 1][k] + dp[i][j][k]) % MOD;
				if (j + 1 == m && k == 0) {
					dp[i + 1][j + 1][1] = (dp[i + 1][j + 1][1] + dp[i][j][0]) % MOD;
				} else
					dp[i + 1][j + 1][k] = (dp[i + 1][j + 1][k] + dp[i][j][k]) % MOD;

				dp[i + 1][j][k] = (dp[i + 1][j][k] + dp[i][j][k]) % MOD;	
			}
		}
	}

	cout << dp[n][0][1] << endl;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif

	while (read()) {
		solve();
	}

	cerr << "TIME: " << clock() * 1000 / CLOCKS_PER_SEC << endl;
	return 0;
}