#include <cstdio>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <iomanip>
#define INF 1e9
#define EPS 1e-10
#ifdef CEMA
	#define err(...) fprintf(stdout, __VA_ARGS__)
	typedef double ld;
#else
	#define err(...) 42
	typedef long double ld;
#endif

using namespace std;

class point {
	public:
		ld x, y;
		point() {}
		point (ld x, ld y) : x(x), y(y) {
		}
};

class line {
	public:
		ld a, b, c;
		line() {}
		line(point p1, point p2) : a(p2.y - p1.y), b(p1.x - p2.x) {
			c = -p1.x * a - p1.y * b;
		}
        ld yof(ld x) {
        	return (-a * x - c) / b;
        }
};

const int MAXK(1e4 + 5);

int k;
point a, b, p[MAXK];

inline ld check(point t);

int main() {
	int x, y;
	scanf("%d%d", &x, &y);
	a.x = x, a.y = y;
	scanf("%d%d%d", &x, &y, &k);
	b.x = x, b.y = y;
	for  (int i(0); i < k; ++i) {
		scanf("%d%d", &x, &y);
		p[i].x = x, p[i].y = y;
	}
	line l(a, b);
	ld left(-INF), right(INF), mid1, mid2;
	err("%.10lf %.10lf %.10lf\n", l.a, l.b, l.c);
	point t;
	for (int _t(0); _t < 500; ++_t) {
//		err("left = %lf, right");
		mid1 = left + (right - left) / 3, mid2 = left + 2 * (right - left) / 3;
		if (fabs(l.b) < EPS) {
			if (check(point(a.x, mid1)) < check(point(a.x, mid2)))
				right = mid2;
			else
				left = mid1;
		} else
			if (fabs(l.a) < EPS) {
				if (check(point(mid1, a.y)) < check(point(mid2, a.y)))
					right = mid2;
				else
					left = mid1;
			} else {
				if (check(point(mid1, l.yof(mid1))) < check(point(mid2, l.yof(mid2))))
					right = mid2;
				else
					left = mid1;
			}
	}
	point ans;
	if (fabs(l.b) < EPS)
		ans = point(a.x, left);
	else
		if (fabs(l.a) < EPS)
			ans = point(left, a.y);
		else
			ans = point(left, l.yof(left));
	ld Ans(0);
	for (int i(0); i < k; ++i)
		Ans += sqrt((ans.x - p[i].x) * (ans.x - p[i].x) + (ans.y - p[i].y) * (ans.y - p[i].y));
	cout << fixed << setprecision(10) << Ans << '\n' << ans.x << ' ' << ans.y;
	return 0;
}

inline ld check(point t) {
	err("check of {%lf; %lf}\n", t.x, t.y);
	ld res(0);
	for (int i(0); i < k; ++i)
		res += sqrt((t.x - p[i].x) * (t.x - p[i].x) + (t.y - p[i].y) * (t.y - p[i].y));
	return res;
}