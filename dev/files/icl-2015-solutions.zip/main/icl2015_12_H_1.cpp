#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <string>
#include <algorithm>
#define ll long long
using namespace std;

int main()
{
	//freopen("input.in", "r", stdin);
	//freopen("output.out", "w", stdout);
	int n, s, f;
	cin >> n >> s >> f;
	if(s > f)
		swap(s, f);
	if(s == f || ((abs(s - f) == 1 && (f != 1 && f != n) && (s != 1 && s != n))))
	{
		cout << -1;
		return 0;
	}
	int gg = 0;
	if(s != 1)
	{
		gg++;
		s++;
	}
	if(f != n)
	{
		f--;
		gg++;
	}
	printf("%d", abs(f - s) / 3 + abs(f - s) % 3 + gg);
	return 0;
}