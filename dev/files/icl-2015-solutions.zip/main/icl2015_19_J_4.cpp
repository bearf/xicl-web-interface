#include <bits/stdc++.h>

using namespace std;

const int N = 3e6;

long long n, k;
int m, pm;
int pr[N], pp[N], fp[N];
vector<int> vec;
vector<int> pvec;
vector<int> ptvec;

int gcd(int x, int y) {
	while ((x > 0) && (y > 0)) {
		if (x > y) x %= y; else y %= x;
	}
	return x + y;
}

int pw(long long x, long long y, int m) {
	x %= m;
	int res = 1;
	while (y) {
		if (y % 2) res = (res * 1LL * x) % m;
		x = (x * 1LL * x) % m;
		y /= 2;
	}
	return res;
}

int get_copr(long long n) {
	for (int i = 0; i < vec.size(); i++) {
		while (n % vec[i] == 0) n /= vec[i];
	}
	return n % m;
}

int prfact(long long n, int pp) {
	if (n == 0) return 1;
//	cerr << n << " " << p << endl;
	int u = fp[pp - 1], v = fp[n % pp];
	u = pw(u, n / pp, pp);
	u = (u * 1LL * v) % pp;
	u = (u * 1LL * prfact(n / pp, pp)) % pp;
	return u;
}

pair<int, long long> fact(long long n, int p, int u, int pp) {
	long long cnt = 0;
	long long ni = n;
	while (ni > 0) {
		ni /= p;
		cnt += ni;
	}
	fp[0] = 1;
	for (int i = 1; i <= pp; i++) {
		fp[i] = fp[i - 1];
		if (i % p ==0) continue;
		fp[i] = (fp[i - 1] * 1LL * i) % pp;
	}
	int res = prfact(n, pp);
	return make_pair(res, cnt);
}
/*
void go(long long a, long long b, long long c, long long &x, long long &y) {
	if (b == 0) {
		x = c / a;
		y = 0;
		return;
	}
	long long q = a / b;
	long long x2, y2;
	go(b, a - q * b, c, x2, y2);
	x = y2;
	y = -q * y2 - x2;
}

void solve2(int a, int b, int c, int &x, int &y) {
	int d = gcd(a, b);
	go(a, b, c, x, y);
}

void solve(long long &a, long long &b, long long c, long long d) {
//	ax+b=cy+d
//	ax-cy=d-b
	long long x, y;
	solve2(a, c, d - b, x, y);
	c = a * x + b;
	d = a * c;
}
*/
int main() {
//	freopen("input.txt", "r", stdin);
//	freopen("1.txt", "w", stdout);
	cin >> n >> k >> m;
	for (int i = 2; i <= m; i++) pr[i] = i;
	for (int i = 2; i <= m; i++) {
		if (pr[i] == i) {
			for (int j = i + i; j <= m; j += i) pr[j] = i;
		}
	}
	pm = m;
	int last = -1;
	vec.clear();
	for (int i = m; i > 1; i /= pr[i]) {
		if (pr[i] != last) {
			pm -= pm / pr[i];
			vec.push_back(pr[i]);
			pvec.push_back(1);
			ptvec.push_back(pr[i]);
		} else {
			pvec.back()++;
			ptvec.back() *= vec.back();
		}
		last = pr[i];
	}
	vector<pair<int, int>> uu;
	for (int i = 0; i < vec.size(); i++) {
		pair<int, long long> t0 = fact(n, vec[i], pvec[i], ptvec[i]);
		pair<int, long long> t1 = fact(k, vec[i], pvec[i], ptvec[i]);
		pair<int, long long> t2 = fact(n - k, vec[i], pvec[i], ptvec[i]);
//		cerr << vec[i] << " " << pvec[i] << " " << ptvec[i] << endl;
//		cerr << t0.first << " " << t1.first << " " << t2.first << endl;
		int need = ptvec[i] - ptvec[i] / vec[i];
		t1.first = pw(t1.first, need - 1, ptvec[i]);
		t2.first = pw(t2.first, need - 1, ptvec[i]);
//		cerr << t0.first << " " << t1.first << " " << t2.first << endl;
		t0.first = (t0.first * 1LL * t1.first) % ptvec[i];
		t0.first = (t0.first * 1LL * t2.first) % ptvec[i];
		t0.second -= t1.second + t2.second;
//		cerr << vec[i] << ": " << t0.first << " " << t0.second << endl;
		uu.push_back(make_pair(ptvec[i], (t0.first * 1LL * pw(vec[i], t0.second, ptvec[i])) % ptvec[i]));
	}
//	for (int i = 0; i < uu.size(); i++) cerr << uu[i].first << " " << uu[i].second << endl;
	for (int i = 0; i < m; i++) {
		bool ok = true;
		for (int j = 0; j < uu.size(); j++) {
			if (i % uu[j].first != uu[j].second) {
				ok = false;
				break;
			}
		}
		if (!ok) continue;
		printf("%d\n", i);
		return 0;
	}
}
