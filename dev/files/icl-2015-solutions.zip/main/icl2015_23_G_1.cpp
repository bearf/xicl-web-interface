#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <deque>
#include <queue>
#include <complex>

using namespace std;

#define pb push_back
#define mp make_pair
#define pbk pop_back
#define fs first
#define sc second
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define all(x) (x).begin(), (x).end()
#define next _next
#define prev _prev
#define link _link
#define hash _hash
#define rank _rank
#ifdef LOCAL42
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif
#if _WIN32 || __WIN32__ || _WIN64 | __WIN64__
#define LLD "%I64d"
#else
#define LLD "%lld"
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));
const int N = int(1e5) + 100;

ll a[N], pref[N], suff[N];

int main() {
#ifdef LOCAL42
#define TASK "G"
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
#endif
	int n;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		int h, m, s;
		scanf("%d %d %d", &h, &m, &s);
		a[i] = h * ll(1e12) + m * ll(1e6) + s;
	}
	sort(a, a + n);
	for (int i = 0; i < n; ++i) {
		pref[i] = (i > 0 ? pref[i - 1] : 0) + a[i];
	}
	for (int i = n - 1; i >= 0; --i) {
		suff[i] = (i + 1 < n ? suff[i + 1] : 0) + a[i];
	}
	ll ans = -1;
	for (int i = 0; i < n; ++i) {
		ll cur = 0;
		if (i > 0) {
			cur += 1LL * i * a[i] - pref[i - 1];
		}
		if (i + 1 < n) {
			cur += ll(1e12) * 12 * (n - i - 1) - suff[i + 1] + 1LL * (n - i - 1) * a[i];
		}
		if (i == 0) {
			ans = cur;
		} else {
			ans = min(ans, cur);
		}
	}
	ll h = ans / ll(1e12);
	ans %= ll(1e12);
	ll m = ans / ll(1e6);
	ans %= ll(1e6);
	ll s = ans;
	cout << h << " " << m << " " << s << endl;
	return 0;
}