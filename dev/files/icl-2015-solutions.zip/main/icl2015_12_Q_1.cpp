#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <string>
#include <map>
#define ll long long
using namespace std;

ll dp[111][111];

bool was[111][111];

map <pair <int, int>, int> mp;

ll f(int u, int k)
{
	if(was[u][k])
		return dp[u][k];
	if(k == 0)
		return 1;
	if(u < 2)
		return 0;
	ll ans = 0;
	//cerr << u << " " << k << "\n";
	for(int i = 0; i < u; i++)
	{
		for(int j = i + 1; j < u; j++)
		{
			for(int k1 = 0; k1 <= k - 1; k1++)
			{
				ans += f(abs(j - i) - 1, k1) * f(u - abs(i - j) - 1, k - 1 - k1);
			}
		}
	}
	was[u][k] = true;
	return dp[u][k] = ans / k;
}

ll fact(ll k)
{
	if(k == 1)
		return 1;
	else return k * fact(k - 1);
}

int main()
{
	//freopen("input.in", "r", stdin);
	//freopen("output.out", "w", stdout);
	int n, k;
	cin >> n >> k;
	if(n / 2 < k)
	{
		cout << 0;
		return 0;
	}
	//cout << f(n, k) << endl;
	//cout << fact(k) << endl;
	cout << f(n, k); /*/ fact(k)*/
	return 0;
}