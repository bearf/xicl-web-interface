#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <string>
#include <algorithm>
#define ll long long
using namespace std;

const int MAX = 1e5 + 11;

const long long MAXX = 12 * 1e12;

int n;

vector <long long> v;

long long answer = 1e18;

ll times(int a, int b, int c)
{
	return (a * (ll)1e12 + b * (ll)1e6 + c); 
}

long long dist(long long v1, long long v2)
{
	if(v2 >= v1)
		return v2 - v1;
	else
		return MAXX - (v1 - v2);
}

int main()
{
	//freopen("input.in", "r", stdin);
	//freopen("output.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 0; i < n; i++)
	{
		int a, b, c;
		scanf("%d %d %d", &a, &b, &c);
		v.push_back(times(a, b, c));
	}
	long long ans = 0;
	sort(v.begin(), v.end());
	for(int i = 1; i < n; i++)
	{
		ans += dist(v[i], v[0]);
	}
	answer = min(answer, ans);
	for(int i = 1; i < n; i++)
	{
		ans -= dist(v[i], v[i - 1]);
		ans += dist(v[i - 1], v[i]) * (n - 1);
		answer = min(answer, ans);
	}
	ans = answer;
	long long a = ans / (long long)1e12;
	ans -= a * (long long)1e12;
	long long b = ans / (long long)1e6;
	ans -= b * (long long)1e6;
	cout << a << " " << b << " " << ans;
	return 0;
}