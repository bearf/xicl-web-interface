#include <bits/stdc++.h>

using namespace std;

#define sz(x) ((int) (x).size())

typedef long long ll;
typedef long double ld;
typedef complex <ld> Pt;

struct Point
{
    int x, y;

    Point() {}
    Point(int x, int y): x(x), y(y) {}

    bool operator<(const Point &a) const
    {
        return x < a.x || (x == a.x && y < a.y);
    }

    bool operator==(const Point &a) const
    {
        return x == a.x && y == a.y;
    }

    Point operator-(Point a)
    {
        return Point(x - a.x, y - a.y);
    }

    ll operator*(Point a)
    {
        return x * a.y - a.x * y;
    }

    ll operator%(Point a)
    {
        return x * a.x + a.y * y;
    }

    ld abs()
    {
        return sqrtl((ll) x * x + (ll) y * y);
    }
};

ll proj(Point a, Point b, Point c)
{
    Point x = b - a;
    Point y = c - a;
    return (x % y);
}

ll height(Point a, Point b, Point c)
{
    Point x = b - a;
    Point y = c - a;
    return (x * y);
}

vector <Point> p;

int main()
{
#ifdef LOCAL
    freopen("e.in", "r", stdin);
#endif // LOCAL
    int n;
    cin >> n;
    for (int i = 0; i < n; ++i)
    {
        int x, y;
        cin >> x >> y;
        p.emplace_back(x, y);
    }
    sort(p.begin(), p.end());
    p.resize(unique(p.begin(), p.end()) - p.begin());
    vector <Point> down, up;
    for (auto pt: p)
    {
        while (sz(down) > 1 && (down.back() - down[sz(down) - 2]) * (pt - down[sz(down) - 2]) <= 0)
            down.pop_back();
        while (sz(up) > 1 && (up.back() - up[sz(up) - 2]) * (pt - up[sz(up) - 2]) >= 0)
            up.pop_back();
        down.push_back(pt);
        up.push_back(pt);
    }
    up.pop_back();
    reverse(up.begin(), up.end());
    up.pop_back();
    vector <Point> hull = down;
    for (auto pt: up)
        hull.push_back(pt);
    n = sz(hull);
    for (int i = 0; i < n; ++i)
        hull.push_back(hull[i]);
    for (int i = 0; i < n; ++i)
        hull.push_back(hull[i]);

    int li, ri, ui;
    ri = 0;
    while (proj(hull[0], hull[1], hull[ri + 1]) > proj(hull[0], hull[1], hull[ri]))
        ++ri;
    ui = ri;
    while (height(hull[0], hull[1], hull[ui + 1]) > height(hull[0], hull[1], hull[ui]))
        ++ui;
    li = ui;
    while (proj(hull[0], hull[1], hull[li + 1]) < proj(hull[0], hull[1], hull[li]))
        ++li;
    ld best_s = 1e18;
    complex <ld> A, B, C, D;

    for (int i = 0; i < n; ++i)
    {
        while (proj(hull[i], hull[i + 1], hull[ri + 1]) > proj(hull[i], hull[i + 1], hull[ri]))
            ++ri;
        ui = ri;
        while (height(hull[i], hull[i + 1], hull[ui + 1]) > height(hull[i], hull[i + 1], hull[ui]))
            ++ui;
        li = ui;
        while (proj(hull[i], hull[i + 1], hull[li + 1]) < proj(hull[i], hull[i + 1], hull[li]))
            ++li;

        ld dist = (hull[i + 1] - hull[i]).abs();
        ld ch = height(hull[i], hull[i + 1], hull[ui]);
        ch /= dist;
        ld pr_r = proj(hull[i], hull[i + 1], hull[ri]);
        pr_r /= dist;
        ld pr_l = proj(hull[i], hull[i + 1], hull[li]);
        pr_l /= dist;
        ld cw = pr_r - pr_l;

        complex <ld> ca, cb, cc, cd;
        Pt vw(hull[i + 1].x - hull[i].x, hull[i + 1].y - hull[i].y);
        vw /= abs(vw);
        Pt vh = vw * Pt(0, 1);
        vh *= ch;
        ca = Pt(hull[i].x, hull[i].y) + vw * pr_l;
        cb = Pt(hull[i].x, hull[i].y) + vw * pr_r;
        cd = ca + vh, cc = cb + vh;

        ld cs = (ch * cw);
        if (best_s > cs)
        {
            best_s = cs;
            A = ca, B = cb, C = cc, D = cd;
        }
    }
//    cerr << best_s << '\n';
    cout << fixed;
    cout.precision(10);
    cout << A.real() << ' ' << A.imag() << '\n';
    cout << B.real() << ' ' << B.imag() << '\n';
    cout << C.real() << ' ' << C.imag() << '\n';
    cout << D.real() << ' ' << D.imag() << '\n';
    return 0;
}
