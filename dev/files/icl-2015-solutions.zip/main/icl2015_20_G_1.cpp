#include <bits/stdc++.h>

using namespace std;

int main() {
	long long n, t1 = 0, t2 = 0;
	cin >> n;
	vector<long long> arr(n);
	for (long long i = 0; i < n; i++) {
		long long k1, k2, k3;
		cin >> k1 >> k2 >> k3;
		arr[i] = (k1 * (long long)(1e6) + k2) * (long long)(1e6) + k3;
	}
	sort(arr.begin(), arr.end());
	for (long long i = 1; i < n; i++) {
		t1 += (12 * (long long)(1e12) - arr[i] + arr[0]) % (long long)(12e12);
	}
	for (long long i = 0; i < n - 1; i++) {
		t2 += arr[n - 1] - arr[i];
	}
	long long a, b, c;
	if (t1 < t2) {
		c = t1 % (long long)(1e6);
		t1 /= (long long)(1e6);
		b = t1 % (long long)(1e6);
		t1 /= (long long)(1e6);
		a = t1;
	} else {
		c = t2 % (long long)(1e6);
		t2 /= (long long)(1e6);
		b = t2 % (long long)(1e6);
		t2 /= (long long)(1e6);
		a = t2;
	}
	cout << a << " " << b << " " << c;
	return 0;
}