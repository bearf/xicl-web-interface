#include <bits/stdc++.h>

using namespace std;

const int N = 3e5;

int ans, n, a[N];
pair<int, int> ma[N], mb[N];

void upd(pair<int, int> &u, pair<int, int> v) {
	if (v.first > u.first) {
		u.first = v.first;
		u.second = 0;
	}
	if (v.first == u.first) u.second += v.second;
}

int main() {
//	freopen("input.txt", "r", stdin);
	scanf("%d", &n);
	for (int i = 0; i < n; i++) scanf("%d", &a[i]);
	ma[0] = make_pair(-1, -1);
	for (int i = 0; i < n; i++) {
		ma[i + 1] = ma[i];
		upd(ma[i + 1], make_pair(a[i], 1));
	}
	mb[n - 1] = make_pair(-1, -1);
	for (int i = n - 1; i > 0; i--) {
		mb[i - 1] = mb[i];
		upd(mb[i - 1], make_pair(a[i], 1));
	}
	long long ans = ma[n].second * 1LL * ma[n].first;
	for (int i = 0; i < n; i++) {
		if ((i + 1 < n) && (a[i] > 0)) {
			pair<int, int> cur = ma[i];
			upd(cur, mb[i + 1]);
			upd(cur, make_pair(a[i] - 1, 1));
			upd(cur, make_pair(a[i + 1] + 1, 1));
			ans = min(ans, cur.second * 1LL * cur.first);
		}
		if ((i - 1 >= 0) && (a[i] > 0)) {
			pair<int, int> cur = ma[i - 1];
			upd(cur, mb[i]);
			upd(cur, make_pair(a[i] - 1, 1));
			upd(cur, make_pair(a[i - 1] + 1, 1));
			ans = min(ans, cur.first * 1LL * cur.second);
		}
	}
	cout << ans << endl;
}