#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <string>
#include <algorithm>
#include <map>
#define ll  unsigned long long
using namespace std;

const int MAX = 1e5 + 11;

const ll MAXX = 12 * (ll)1e12;

int n;

vector <pair<ll, int> > v;

ll answer = (ll)18e18;

map <ll, int> mp;

ll times(int a, int b, int c)
{
	return (a * (ll)1e12 + b * (ll)1e6 + c); 
}

ll dist(ll v1, ll v2)
{
	if(v2 >= v1)
		return v2 - v1;
	else
		return MAXX - (v1 - v2);
}

int main()
{
	//freopen("input.in", "r", stdin);
	//freopen("output.out", "w", stdout);
	scanf("%d", &n);
	/*cout << 100000 << endl;
	cout << 0 << " " << 0 << " " << 0 << endl;
	for(int i = 1; i < 100000; i++)
		cout << 0 << " " << 0 << " " << 1 << endl;*/
	for(int i = 0; i < n; i++)
	{
		int a, b, c;
		scanf("%d %d %d", &a, &b, &c);
		mp[times(a, b, c)]++;
		//v.push_back(times(a, b, c));
	}
	for(map <ll, int>::iterator it = mp.begin(); it != mp.end(); it++)
		v.push_back(make_pair(it->first, it->second));
	ll ans = 0;
	sort(v.begin(), v.end());
	int size = v.size();
	for(int i = 1; i < size; i++)
	{
		ans += dist(v[i].first, v[0].first) * v[i].second;
	}
	answer = min(answer, ans);
	for(int i = 1; i < size; i++)
	{
		ans -= dist(v[i].first, v[i - 1].first) * v[i].second;
		ans += dist(v[i - 1].first, v[i].first) * (size - 1);
		answer = min(answer, ans);
	}
	ans = answer;
	ll a = ans / (ll)1e12;
	ans -= a * (ll)1e12;
	ll b = ans / (ll)1e6;
	ans -= b * (ll)1e6;
	cout << a << " " << b << " " << ans;
	return 0;
}