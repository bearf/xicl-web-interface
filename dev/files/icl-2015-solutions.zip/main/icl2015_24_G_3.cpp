#include<iostream>
#include<vector>
#include<map>
#include<string>
#include<string.h>
#include<algorithm>
#include<set>
using namespace std;

#define MAX_INP (100000 + 10)

long long int mas[MAX_INP];

long long razn[MAX_INP];
int main()
{
	int n;
	cin>>n;
	for (int i = 0; i < n; i++) {
		long long int h, m, s;
		cin>>h>>m>>s;
		long long int time = (h * 1000000 + m) * 1000000 + s;
		mas[i] = time;
	}
	sort(mas, mas + n);
	long long int cycle = ((long long int)12) * 1000000 * 1000000;
	/*long long int max_razr = mas[0]-mas[n - 1] + cycle;
	int max_ind = 0;
	for (int i = 1; i < n; i++) {
	if (mas[i]-mas[i-1]>max_razr) {
	max_razr = mas[i]-mas[i-1];
	max_ind = i;
	}
	}
	max_ind--;
	if (max_ind < 0) {
	max_ind += n;
	}
	long long int h, m, s;
	h = 0;
	m = 0;
	s = 0;*/
	for (int i = 1; i < n; i++) {
		razn[i-1] = mas[i] - mas[i-1];
	}
	razn[n-1] = mas[0] - mas[n-1];
	if (razn[n-1] < 0) {
		razn[n-1] += cycle;
	}
	/*long long int sum = 0;
	for (int j = 0; j < n; j++) {
		sum += razn[j];
	}*/
	long long int h = 0;
	long long int ms = 0;
	for (int i = 1; i < n; i++) {
		ms += razn[i] * i;
		h += ms / 1000000000000;
		ms %= 1000000000000;
	}
	long long int h_max = h;
	long long int ms_max = ms;

	for (int i = 1; i < n; i++) {
		long long slag = -(cycle - razn[i-1]) + (n-1) * razn[i-1];
		if (slag >= 0) {
			ms += slag;
			h += ms / 1000000000000;
			ms %= 1000000000000;
		} else {
			long long int slag_h = (-slag) / 1000000000000;
			long long int slag_ms = (-slag) % 1000000000000;
			ms -= slag_ms;
			h -= slag_h;
			while (ms<0) {
				ms += 1000000000000;
				h++;
			}
		}
		if (h < h_max) {
			h_max = h;
			ms_max = ms;
		} else if (h == h_max) {
			if (ms < ms_max) {
				h_max = h;
				ms_max = ms;
			}
		}
	}

	cout<<h_max<<' '<<(ms_max / 1000000)<<' '<<(ms_max % 1000000);

	/*long long int time = mas[max_ind];
	for (int i = 0; i < n; i++) {
	long long int slag = 0;
	if (mas[i]<=time) {
	slag = time - mas[i];
	} else {
	slag = time - mas[i] + cycle;
	}
	s += slag;
	m += s / 1000000;
	h += m / 1000000;
	s %= 1000000;
	m %= 1000000;
	}
	cout<<h<<' '<<m<<' '<<s;*/
}