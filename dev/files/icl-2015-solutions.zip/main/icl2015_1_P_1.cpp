#include <cstdio>
#include <cstring>
#include <iostream>
#include <set>
#include <queue>
#include <cmath>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;

#define ll long long
#define ld long double
#define mp make_pair
#define pb push_back
#define forn(i, n) for(int i = 0; i < n; i++)

const int inf = 1 << 30;
const ld eps = 1e-9;

vector <ll> ans;

ll p, q;

void sokr(ll &a, ll &b){
	if (!a) return;
	ll z = a;
	for(ll i = 2; i * i <= z; i++)
		if (a % i == 0 && b % i == 0){ a /= i; b /= i; }
	if (b % a == 0){ b /= a; a = 1; }
}

int main(){
	scanf("%d%d", &p, &q);

	ll nd = __gcd(p, q);
	p /= nd;
	q /= nd;

	ll n = p / q, m = 1, k = 2, a, tm, tn, step = 2;
	ans.pb(p / q);
	while (n != p || m != q){
        //printf("k: %lld\n", k);
        //printf("delim %lld %lld\n", (p * m - n * q) * k, m * q);
		a = ((p * m - n * q)) * k / (m * q);
		ans.pb(a);
		//printf("a: %lld\n", a);
		tn = n * k + a * m; tm = m * k;
		n = tn; m = tm;

		nd = __gcd(n, m);
        n /= nd;
        m /= nd;

		//printf("n, m : %lld %lld\n", n, m);
        step++;
		k *= step;
		//step++;

	}


	forn(i, (int) ans.size()) printf("%lld ", ans[i]);

	return 0;
}
