#define _USE_MATH_DEFINES

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <bitset>
#include <cassert>
#include <cmath>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) int(a.size())
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define all(a) a.begin(),a.end()

typedef pair<int,int> pt;
#define ft first
#define sc second

typedef long long li;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = 1e9;

li n, k;
int m;

int gcd(int a, int b) {
	return b == 0 ? a : gcd(b, a % b);
}

int mul(int a, int b) {
	return (li(a) * b) % m;		
}

const int M = 1e6 + 5;
int msz, ms[M], seq[M], mb;

void precalc() {
	msz = 0;
	ms[0] = 1;
	for (int i=  1; i <= m; ++i) {
		if (gcd(i, m) == 1) {
			seq[msz++] = i;
			ms[ msz ] = mul(ms[msz - 1], seq[msz - 1]);
		}
	}

	seq[msz] = m;

	mb = ms[msz];
}

int binpow(int a, li b) {
	int cur = a, res = 1;
	while (b) {
		if (b & 1)
			res = mul(res, cur);
		cur = mul(cur, cur);
		b >>= 1;
	}
	return res;
}

int gfact(li n) {
	int f = binpow(mb, n / m);
	n %= m;

	int pos = upper_bound(seq, seq + msz + 1, n) - seq;

	return mul(f, ms[pos]);
}

int T;
int used[M];

void dosome(li n, int c, int& f) {
	li cur = 1;

	while (n >= c) {
		cur *= c;
		if (cur < M) {
			if (used[cur] == T)
				return;
			used[cur] = T;
		}
		n /= c;
		f = mul(f, gfact(n));
	}

}

int fact(li n) {
	T++;
	int f = 1;
	for (int i = 1; i * i <= m; ++i) {
		if (m % i == 0) {
			dosome(n, i, f);
			if (i * i != m)
				dosome(n, m / i, f);
		}
	}

	return f;
}

li calcp(li n, int c) {
	li res = 0;
	while (n) {
		n /= c;
		res += n;
	}
	return res;
}

bool read() {
	if (!(cin >> n >> k >> m))
		return false;
	return true;
}

void solve() {
	precalc();
	int f = fact(n);
	f = mul(f, binpow(fact(k),     msz - 1));
	f = mul(f, binpow(fact(n - k), msz - 1));

	int mm = m;

	for (int i = 2; i * i <= mm; ++i) {
		int cnt = 0;

		while (mm % i == 0) {
			mm /= i;
			cnt++;
		}

		if (cnt) {
			li c = calcp(n, i) - calcp(k, i) - calcp(n - k, i);
			f = mul(f, binpow(i, c));
		}
	}

	if (mm > 1) {
		li c = calcp(n, mm) - calcp(k, mm) - calcp(n - k, mm);
		f = mul(f, binpow(mm, c));
	}

	cout << f << endl;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif

	while (read()) {
		solve();
	}

	cerr << clock() * 1000 / CLOCKS_PER_SEC << endl;
	return 0;
}