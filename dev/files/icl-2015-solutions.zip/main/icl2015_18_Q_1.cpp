#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
using namespace std;

int main()
{
    long long n,k,q[41][41];
    cin>>n>>k;
    if(n==1){
        cout<<0;
        return 0;
    }
    q[0][0]=1;
    for(int i=1;i<=k;i++)
        q[0][i]=0;
    for(int i=1;i<=n;i++){
        for(int j=0;j<=k;j++){
                q[i][j]=q[i-1][j];
            for(int l=0;l<=i-2;l++)
                for(int r=0;r<=j-1;r++)
                   q[i][j]+=q[l][r]*q[i-2-l][j-1-r];
        }
    }
    cout<<q[n][k];
}
