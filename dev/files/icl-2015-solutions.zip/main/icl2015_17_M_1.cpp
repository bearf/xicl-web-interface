#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
#include <cstring>
#include <map>
#include <algorithm>
#include <ctime>

using namespace std;

typedef long long LL;

#define all(x) (x).begin(), (x).end()
#define INF 1E+9
#define INFll 1E+18

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int n;
	scanf("%d\n", &n);

	string s;
	int man = 0, ufo = 0;
	bool gold, blue, wh, black;


	for (int i = 0; i < n; ++i) {
		getline(cin, s);
		gold = 0, blue = 0, wh = 0, black = 0;
		
		for (int j = 0; j < (int)s.length() - 3; ++j) {
			if (s.substr(j, 4) == "blue")
				blue = 1;
			if (s.substr(j, 4) == "gold")
				gold = 1;
		}
		for (int j = 0; j < (int)s.length() - 4; ++j) {
			if (s.substr(j, 5) == "white")
				wh = 1;
			if (s.substr(j, 5) == "black")
				black = 1;
		}

		if (black && blue)
			++man;
		if (gold && wh)
			++ufo;

	}

	printf("%.7lf\n%.7lf\n%.7lf\n", man * 100.0 / n, ufo * 100.0 / n, (n - man - ufo) * 100.0 / n);

	return 0;
}