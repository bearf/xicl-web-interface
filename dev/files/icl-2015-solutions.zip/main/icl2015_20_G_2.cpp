#include <bits/stdc++.h>

using namespace std;

int main() {
	long long n, t = 0, ans;
	cin >> n;
	vector<long long> arr(n);
	for (long long i = 0; i < n; i++) {
		long long k1, k2, k3;
		cin >> k1 >> k2 >> k3;
		arr[i] = (k1 * (long long)(1e6) + k2) * (long long)(1e6) + k3;
	}
	sort(arr.begin(), arr.end());
	for (long long i = 1; i < n; i++) {
		t += ((long long)(12e12) - arr[i] + arr[0]);
	}
	ans = t;
	for (long long i = 1; i < n; i++) {
		long long tm = 0;
		tm = t - ((long long)(12e12) - arr[i] + arr[i - 1]);
		tm += (arr[i] - arr[i - 1]) * (n - 1);
		t = tm;
		ans = min(ans, tm);
	}
	t = ans;
	long long a, b, c;
	c = t % (long long)(1e6);
	t /= (long long)(1e6);
	b = t % (long long)(1e6);
	t /= (long long)(1e6);
	a = t;
	cout << a << " " << b << " " << c;
	return 0;
}