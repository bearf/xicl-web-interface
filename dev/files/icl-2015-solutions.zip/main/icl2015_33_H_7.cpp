#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>

using namespace std;

int main(){
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);

    long long n, s, f;

    cin >> n >> s >> f;

    if(s > f){
        s = n - s + 1;
        f = n - f + 1;
    }

    if(s + 1 == f){
        if(s > 1 && f < n){
            cout << -1;
            return 0;
        }

        cout << 1;
        return 0;
    }

    long long ans = 0;

    if(s > 1){
        ans++;
        s++;
    }

    long long d = f - s;

    if(f == n){
        while(d > 3){
            ans++;
            d -= 3;
        }

        if(d == 1)
            ans++;
        else if(d == 2)
            ans += 2;
        else if(d == 3)
            ans += 2;

        cout << ans;
        return 0;
    }

    if(f < n)
        ans++;

    f--;

    d = f - s;

    while(d > 3){
            ans++;
            d -= 3;
        }

    if(d == 1)
        ans++;
    else if(d == 2)
        ans += 2;
    else if(d == 3)
        ans += 1;

    cout << ans;

    return 0;
}
