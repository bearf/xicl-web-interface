#include <string>
#include <cstring>
#include <iostream>
#include <fstream>
#include <deque>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <ctype.h>
#include <ctime>

#define _USE_MATH_DEFINES
#include <math.h>

#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define LL long long
#define mp make_pair
#define sqr(x) x*x

using namespace std;

void smain();

int main() {
#ifdef _DEBUG
	/*freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);*/
#endif
	
	smain();

	return 0;
}

#define int long long
#define MOD 1000000009
#define N 310
typedef struct{int d[N][N];}ta;
ta a, b;
int n, k;
void smain() {
	ta *cur = &a, * next = &b;
	cin>>n>>k;
	cur->d[0][0] = 1;
	for(int i=1; i <=n;++i){
		for(int kmax = 0; kmax<=k; ++kmax){
			for(int bal = 0; bal<=k; ++bal){
				int curRes = cur->d[kmax][bal];

				int nbal = bal + 1, nk = kmax;//(
				if(nbal>kmax){
					nk = nbal;
				}
				next->d[nk][nbal] = (next->d[nk][nbal] + curRes)%MOD;

				nbal = bal, nk = kmax;//0
				next->d[nk][nbal] = (next->d[nk][nbal] + curRes)%MOD;

				nbal = bal - 1, nk = kmax;//)
				if(nbal>=0){
					next->d[nk][nbal] = (next->d[nk][nbal] + curRes)%MOD;
				}
			}
		}
		memset(cur, 0, sizeof(ta));
		swap(cur, next);
	}
	cout<<cur->d[k][0]<<endl;
}