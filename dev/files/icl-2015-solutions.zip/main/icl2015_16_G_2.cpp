#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const ll H = ll(12) * ll(1000000) * ll(1000000);

const ll dist(ll a, ll b) {
    if (b < a) {
        return H - a + b;
    }
    return b - a;
}

int main() {
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
/*
    cout << ll(1e5) << endl;
    for (int i = 0; i < ll(1e5) - 1; i++) {
        cout << 0 << ' ' << 0 << ' ' << 0 << endl;
    }*/

    ll n;
    scanf("%lld", &n);

    vector<ll> a(n);
    for (int i = 0; i < n; i++) {
        ll h, m, s;
        scanf("%lld%lld%lld", &h, &m, &s);

        ll cur = h * ll(1000000) * ll(1000000) + m * ll(1000000) + s;
        a[i] = cur;
    }

    sort(a.begin(), a.end());

    if (a[n - 1] == a[0]) {
        cout << 0 << ' ' << 0 << ' ' << 0 << endl;
        return 0;
    }

    ll cur = 0;
    for (int i = 0; i < n - 1; i++) {
        cur += dist(a[i], a[n - 1]);
    }

    ll ans = cur;
    for (int i = 0; i < n; i++) {
        ll last = (i == 0 ? a[n - 1] : a[i - 1]);
        cur += n * dist(last, a[i]) - H;
        ans = min(ans, cur);
    }

    cout << ans / ll(1000000) / ll(1000000) << ' ' << ans / ll(1000000) % ll(1000000) << ' ' << ans % ll(1000000) << endl;
}
