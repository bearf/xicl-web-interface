#include <iostream>
#include <algorithm>


using namespace std;

int n, s, f;


int main(){
	cin >> n >> s >> f;
	if (f < s)
		swap(f, s);
	if (f - s == 1)
	{
		if (s == 1 || f == n)
			cout << 1;
		else
			cout << -1;
		return 0;
	}
	if ((f - s) % 2 == 0)
		cout << 3;
	else
		cout << 2;
}