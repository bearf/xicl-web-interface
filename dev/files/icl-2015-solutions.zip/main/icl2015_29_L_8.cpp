#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main()
{
	int n;
	cin >> n;
	long long p[10100];
	long long m1, m2=-1;
	cin >> p[0];
	m1=p[0];
	for (int i = 1; i<n; i++)
	{
		cin >> p[i];
		if (p[i]>m1)
		{
			m2 = m1;
			m1=p[i];
		}
		else
		if(p[i]>m2&&p[i]!=m1)
			m2=p[i];
	}

	long long kolm1=0,kolm2=0;
	for (int i = 0; i<n; i++)
	{
		if (p[i]==m1) kolm1++;
		else if(p[i] ==m2) kolm2++;
	}

	if (m1==0) cout << 0;
	else
		if (m2==-1) cout << m1+1;
	else
	if (kolm1 == 1)
	{
		if (m1-m2==1) cout << m1;
		else
		if (m1-m2 == 2)
		{
			if (p[0] == m1 && p[1] == m2 || p[n-1]==m1 && p[n-2] == m2) {cout << m1; return 0;}

			for (int i = 1; i<n-1; i++)
			{
				if (p[i] == m1 && p[i-1]==m2 || p[i]==m1 && p[i+1]==m2) {cout << m1; return 0;}
			}
			cout << m1-1;
		}
		else
			cout << m1-1;
	}
	else
	if (kolm1 == 2 )
	{
		long long mi = 101000;
		if (m1-m2!=1 )
			cout << m1;
		else
		{
		if (p[0] == m1 && p[1]==m1 || p[n-2]==m1 && p[n-1]==m1) mi = m1+1;
		if (p[0] == m1 && p[1]<m2 || p[n-2]<m2 && p[n-1]==m1) {cout << m1; return 0;} 
		for (int i = 1; i<n-1; i++)
		{
			if ((p[i] == m1 && p[i+1]==m1 || p[i]==m1 && p[i-1]==m1) && mi!=m1-1) mi = m1+1;
			if ((p[i] == m1 && p[i+1]<m2 || p[i]==m1 && p[i-1]<m2) && mi!=m1-1) {cout << m1; return 0;}
		}
		if (mi!=101000)
		cout << mi;
		else
			cout << m1*kolm1;
		return 0;
		}
	}
	else
	{
		if (p[0]==m1 && p[1] == m1 || p[n-2]==m1&&p[n-1]==m1) {cout << m1+1; return 0;}
		for (int i = 1; i<n-1; i++)
		{
			if (p[i]==m1 && p[i-1] == m1 || p[i]==m1&&p[i+1]==m1) {cout << m1+1; return 0;}
		}

		if (p[0]==m1 && p[1] < m1-1 || p[n-2]<m1-1&&p[n-1]==m1) {cout << (kolm1-1)*m1; return 0;}
		for (int i = 1; i<n-1; i++)
		{
			if (p[i]==m1 && p[i-1] < m1-1 || p[i]==m1&&p[i+1]<m1-1) {cout << (kolm1-1)*m1; return 0;}
		}	
		cout << kolm1*m1;
	}
}
