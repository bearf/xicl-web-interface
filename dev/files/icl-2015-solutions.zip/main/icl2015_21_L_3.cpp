#include <iostream>
#include <vector>
using namespace std;
int main(){
#ifdef _DEBAG
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#else
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	bool c = false;
	int n, i, r = 0, m = 0, b = 0;
	cin >> n;
	vector <int> v(n);
	for (i = 0; i < n; i++){
		cin >> v[i];
		if (v[i] > v[m]) m = i;
	}
	for (i = 0; i < n; i++) if (v[i] == v[m]) b++; 
	if ( b == 1){
		i = m;
		if (i != 0)	if (v[i] > v[i-1]+2) c = true;
		if (i != n-1) if (v[i] > v[i + 1] + 2) c = true;
		if ( c == true) cout << --v[m];
		else cout << v[m];
	}
	else {
		for (i = 0; i < n; i++) if (v[i] == v[m]){
			if (i != 0)	if (v[i]-1 >= v[i-1]+1) c = true;
			if (i != n-1) if (v[i]-1 >= v[i + 1] + 1) c = true;
			if (c == true) break;
		}
		if ( c == true) cout << v[m]*(b-1);
		else cout << v[m]*b;
	}
	return 0;
}