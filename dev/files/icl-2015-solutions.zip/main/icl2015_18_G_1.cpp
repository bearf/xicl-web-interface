#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iomanip>
using namespace std;
long long q[100002];
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        long long a,b,c;
        cin>>a>>b>>c;
        q[i]=a*1000000000000+b*1000000+c;
    }
    long long ans=0;
    sort(q,q+n);
    long long answer=12*1e17;
    long long inf=12*(long long)1e12;
    for(int i=1;i<n;i++)
        ans+=inf-(q[i]-q[0]);
    answer=min(answer,ans);
    for(int i=1;i<n;i++){
       ans=ans-(inf-(q[i]-q[i-1]))+(q[i]-q[i-1])*(n-1);
       answer=min(ans,answer);
    }
    ans=0;
    for(int i=0;i<n;i++)
        if(q[i]!=0)
          ans+=inf-q[i];
    answer=min(ans,answer);
    ans=0;
    for(int i=0;i<n;i++)
        ans+=inf-1-q[i];
    answer=min(ans,answer);
    long long h,m,s;
    s=answer%(long long)1e6;
    answer=(answer-s)/(long long)1e6;
    m=answer%(long long)1e6;
    answer=(answer-m)/(long long)1e6;
    h=answer;
    cout<<h<<" "<<m<<" "<<s;
}
