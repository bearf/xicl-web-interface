#include <bits/stdc++.h>
#include <vector>

using namespace std;

#ifdef FOOBAR
    ifstream fin("input.txt");
#define cin fin
#endif // FOOBAR

const int N = 1001;
long long c[N][N];

int main() {
    ios_base::sync_with_stdio(false);

    int n, m;
    cin >> n >> m;
    long long a[m + 1];

    for (int i=0; i<N; i++)
        c[i][0] = c[i][i] = 1;
    for (int i=1; i<N; i++)
        for (int j=1; j<i; j++)
            if (c[i-1][j-1] < 0 || c[i-1][j] < 0 || c[i-1][j-1] + c[i-1][j] > (1LL<<62))
                c[i][j] = -1;
            else
                c[i][j] = c[i-1][j-1] + c[i-1][j];

    int j;

    a[m + 1] = N;

    for (int i = m; i > 0; i--) {
        j = a[i + 1] - 1;
        while (j > 0 && c[j][i] > n) {
            j--;
        }

        a[i] = j;
        n -= c[i][j];
    }

    for (int i = m; i > 0; i--) {
        cout << a[i] << " ";
    }
    return 0;
}
