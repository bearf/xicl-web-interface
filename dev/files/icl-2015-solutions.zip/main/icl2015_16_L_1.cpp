#include <iostream>
#include <fstream>

using namespace std;

//ifstream cin("input.txt");
//ofstream cout("output.txt");

int a[100005];
int cnt[100005];
int umax = 100005 - 1;

int cahesk()
{
    if (cnt[umax + 1] != 0)
        return (umax + 1) * cnt[umax + 1];
    if (cnt[umax] != 0)
        return umax * cnt[umax];
    return (umax - 1) * cnt[umax - 1];
}

int main()
{
    int n;
    cin >> n;
    for (int i = 0; i < 100005; i++)
    {
        cnt[i] = 0;
    }
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
        cnt[a[i]]++;
    }
    while(cnt[umax] == 0)
        umax--;
    int mmin = 1234567890;
    for(int i = 0; i < n; i++)
    {
        if (a[i] != 0)
        {
            if (i != 0)
            {
                cnt[a[i]]--;
                cnt[a[i] - 1]++;
                cnt[a[i - 1]]--;
                cnt[a[i - 1] + 1]++;
                mmin = min(mmin, cahesk());
                cnt[a[i - 1] + 1]--;
                cnt[a[i - 1]]++;
                cnt[a[i] - 1]--;
                cnt[a[i]]++;
            }
            if (i != n - 1)
            {
                cnt[a[i]]--;
                cnt[a[i] - 1]++;
                cnt[a[i + 1]]--;
                cnt[a[i + 1] + 1]++;
                mmin = min(mmin, cahesk());
                cnt[a[i + 1] + 1]--;
                cnt[a[i + 1]]++;
                cnt[a[i] - 1]--;
                cnt[a[i]]++;
            }
        }
    }
    cout << mmin;
}
