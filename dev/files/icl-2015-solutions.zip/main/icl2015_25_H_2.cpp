#include <iostream>
#include <algorithm>


using namespace std;

int n, s, f;


int main(){
	cin >> n >> s >> f;
	if (f < s)
		swap(f, s);
	if (s == f)
	{
		cout << -1;
		return 0;
	}

	if (f - s == 1)
	{
		if (s == 1 || f == n)
			cout << 1;
		else
			cout << -1;
		return 0;
	}
	if (n > 3 && s == 1 && f == n)
	{
		if (n == 4)
			cout << 1;
		else if (n == 5)
			cout << 2;
		else if (n == 6)
			cout << 3;
		else if (n == 7)
			cout << 2;
		else
		{
			if ((n - 1) % 3 == 0)
				cout << ((n - 1) / 3);
			else if ((n - 1) % 3 == 1)
				cout << (n - 1) / 3 + 1;
			else
				cout << ((n - 1) / 3) + 2;
		}
		return 0;
	}
	if ((f - s - 1) % 2 == 0)
		cout << 3;
	else
		cout << 2;
}