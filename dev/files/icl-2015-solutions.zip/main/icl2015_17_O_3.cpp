#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
#include <cstring>
#include <map>
#include <algorithm>
#include <ctime>

using namespace std;

typedef long long LL;

#define all(x) (x).begin(), (x).end()
#define INF 1E+9
#define INFll 1E+18
#define EPS 1E-6

typedef double dbl ;

struct Point{
	dbl x, y;

	Point(dbl x = 0, dbl y = 0) {
		this->x = x;
		this->y = y;
	}
};

struct Vector{
	dbl x, y;
	Vector(dbl x = 0, dbl y = 0) {
		this->x = x;
		this->y = y;
	}
	Vector(Point from, Point to) {
		x = to.x - from.x;
		y = to.y - from.y;
	}
	void operator *=(dbl d) {
		x *= d;
		y *= d;
	}
	dbl len() {
		return hypot(x, y);
	}
	void operator /= (dbl d) {
		x /= d;
		y /= d;
	}
	void norm() {
		*this /= len();
	}
};

void operator-=(Point &p, Vector v) {
	p.x -= v.x;
	p.y -= v.y;
}
void operator+=(Point &p, Vector v) {
	p.x += v.x;
	p.y += v.y;
}
Vector operator * (Vector f, dbl d) {
	return Vector(f.x * d, f.y * d);
}

Vector operator - (Point f, Point s) {
	return Vector(f, s);
}
Point operator + (Point f, Vector v) {
	return Point(f.x + v.x, f.y + v.y);
}

dbl getans(Point m, const vector<Point> &ps) {
	dbl ans = 0;
	for (int i = 0; i < ps.size(); ++i) {
		ans += (ps[i] - m).len();
	}
	return ans;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	Point f, s;

	cin >> f.x >> f.y >> s.x >> s.y;

	Vector v(f, s);


	v.norm();

	s += v * INF;
	f -= v * INF;

	dbl cur;

	int n;

	cin >> n;
	vector<Point> ps(n);

	for (int i = 0; i < n; ++i)
		cin >> ps[i].x >> ps[i].y;

	while ((s - f).len() > EPS) {
		Point m1, m2;
		dbl l1, l2, len = (s - f).len();

		l1 = len / 3;
		l2 = len - len / 3;
		
		m1 = f + v * l1;
		m2 = f + v * l2;

		dbl f1 = getans(m1, ps), f2 = getans(m2, ps);

		if (f1 < f2)
			s = m2;
		else
			f = m1;
	}

	printf("%.9lf\n%.9lf %.9lf", getans(f, ps), f.x, f.y);

	return 0;
}