import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Time;
import java.util.Locale;
import java.util.StringTokenizer;

public class Solution {

	boolean swap = false;

	double[] hx;
	double[] hy;

	double[] steps = {1, 0.5, 0.25, 0.175, 0.01, 0.005, 0.000_1, 0.000_01, 0.000_001 };

	double count(double startX, double endX, double step) {

		double minDist = Long.MAX_VALUE;
		double ansX = -1337;
		for (double x = startX; compareEps(x, endX) <= 0; x += step) {
			double y = at(x);
			double dist = 0;
			for (int i = 0; i < hx.length; i++) {
				dist += dist(x, y, hx[i], hy[i]);
			}
			if (dist < minDist) {
				minDist = dist;
				ansX = x;
			}
		}

		return ansX;
	}

	double dist(double x1, double y1, double x2, double y2) {
		double dx = x1 - x2;
		double dy = y1 - y2;
		return Math.sqrt(dx * dx + dy * dy);
	}
	
	double k;
	double b;
	
	void makeLine(double x1, double y1, double x2, double y2) {
		k = (y2 - y1) / (x2 - x1);
		b = y1 - k * x1;
	}

	double at(double x) {
		return k * x + b;
	}
	
	void solve() throws NumberFormatException, IOException {
		Point linePoint1 = new Point(io.nextInt(), io.nextInt());
		Point linePoint2 = new Point(io.nextInt(), io.nextInt());

		if (compareEps(linePoint1.x, linePoint2.x) == 0) {
			swap = true;
			linePoint1.swap();
			linePoint2.swap();
		}

		Vector v = new Vector(linePoint2.x - linePoint1.x, linePoint2.y
				- linePoint1.y);
		v.normalize();

		if (v.x < 0) {
			v.x *= -1;
			v.y *= -1;
		}

		double minX = -10_111;
		double maxX = 10_111;

		int len = io.nextInt();
		hx = new double[len];
		hy = new double[len];

		for (int i = 0; i < len; i++) {
			if(!swap) {
				hx[i] = io.nextInt();
				hy[i] = io.nextInt();
			} else {
				hy[i] = io.nextInt();
				hx[i] = io.nextInt();
			}
		}

		Line line = new Line(linePoint1, linePoint2);

		k = line.k;
		b = line.b;
		
		double ansX = count(minX, maxX, 0.5);
		
		double lastStep = 0.5;
		
		while(lastStep >= 0.000_001) {
			ansX = count(ansX - lastStep * v.x, ansX + lastStep * v.x, lastStep / 2);
			lastStep /= 2;
		}
		
//		for (int i = 1; i < steps.length; i++) {
//			ansX = count(ansX - (steps[i - 1] * v.x), ansX
//					+ (steps[i - 1] * v.x), steps[i] * v.x);
//		}

		
		double x = ansX;
		double y = at(x);

		double fullLength = 0;

		
		for (int i = 0; i < hx.length; i++) {
			fullLength += dist(x, y, hx[i], hy[i]);
		}

		if (swap) {
			double t = x;
			x = y;
			y = t;
		}

		String s = fullLength + "\n"
				+ String.format(Locale.US, "%.6f %.6f", x, y);
		io.println(s);
		System.err.println(s);

	}

	static final double EPS = 1e-9;

	int compareEps(double a, double b) {
		if (Math.abs(a - b) < EPS) {
			return 0;
		}
		if (a < b) {
			return -1;
		}
		return 1;
	}

	class Point {
		double x;
		double y;

		public Point(double x, double y) {
			this.x = x;
			this.y = y;
		}

		double squareDistance(Point p) {
			double dx = x - p.x;
			double dy = y - p.y;
			return dx * dx + dy * dy;
		}

		void swap() {
			double t = x;
			x = y;
			y = t;
		}

	}

	class Vector extends Point {

		public Vector(double x, double y) {
			super(x, y);
		}

		double length() {
			return Math.sqrt(new Point(0, 0).squareDistance(this));
		}

		void normalize() {
			double l = length();
			x /= l;
			y /= l;
		}

	}

	class Line {
		double k;
		double b;

		Line(Point p, Point q) {
			k = (q.y - p.y) / (q.x - p.x);
			b = q.y - k * q.x;
		}

		Point at(double x) {
			return new Point(x, k * x + b);
		}

	}

	// ~~~~~~~~~~~~~~~~~~~//
	public static void main(String[] args) throws IOException {
		long st = System.currentTimeMillis();
		Solution solution = new Solution();
		solution.io = new MyIO();
		solution.solve();
		solution.io.close();
		System.err.println(System.currentTimeMillis() - st * 1.0 / 1000 + "secs");
	}

	MyIO io;

	static class MyIO {
		PrintWriter out;
		BufferedReader in;

		public MyIO() throws FileNotFoundException {
			File myIn = new File("input.txt");
			File myOut = new File("output.txt");

			if (myIn.exists()) {
				in = new BufferedReader(new FileReader(myIn));
				out = new PrintWriter(myOut);
				return;
			}

			in = new BufferedReader(new InputStreamReader(System.in));
			out = new PrintWriter(System.out);
		}

		void println(double d) {
			out.println(d);
		}

		void println(String s) {
			out.println(s);
		}

		void print(String s) {
			out.print(s);
		}

		void println(int i) {
			out.println(i);
		}

		void print(int i) {
			out.print(i);
		}

		String nextLine() throws IOException {
			return in.readLine();
		}

		StringTokenizer tokenizer = new StringTokenizer("");

		String next() throws IOException {
			while (!tokenizer.hasMoreElements()) {
				tokenizer = new StringTokenizer(nextLine());
			}
			return tokenizer.nextToken();
		}

		int nextInt() throws NumberFormatException, IOException {
			return Integer.parseInt(next());
		}

		long nextLong() throws NumberFormatException, IOException {
			return Long.parseLong(next());
		}

		void close() throws IOException {
			in.close();
			out.close();
		}
	}
}
