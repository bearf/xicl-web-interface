#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <vector>

using namespace std;

bool f(string s1, string s2){
    for(int i = 0; i < int(s2.length()) - int(s1.length()) + 1; i++){
        bool yes = true;

        for(int j = 0; j < s1.length(); j++)
            if(s1[j] != s2[i + j]){
                yes = false;
                break;
            }

        if(yes)
            return true;
    }

    return false;
}

int main(){
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);

    string s;

    int n;
    double a = 0, b = 0, c = 0;

    cin >> n;
    getline(cin, s);

    for(int i = 0; i < n; i++){
        getline(cin, s);

        if(f("blue", s) && f("black", s)){
            a++;
        }
        else if(f("gold", s) && f("white", s)){
            b++;
        }
        else
            c++;
    }

    double d = a + b + c;

    printf("%.6f\n", a/d * 100);
    printf("%.6f\n", b/d * 100);
    printf("%.6f", c/d * 100);

    return 0;
}
