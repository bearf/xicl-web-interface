#define _USE_MATH_DEFINES
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define sz(x) ((int)x.size())
#define fi first
#define se second
#define re return
#define y0 y248590
#define y1 y5427895
#define j0 j5234895
#define j1 j438759
#define prev prev348957
#define next next457834
#define sqrt(x) sqrt(abs(x))

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef pair<ll, ll> pll;
typedef vector<string> vs;
typedef long double ld;
typedef double D;

template<class T> T gcd (T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> inline T abs (T a) { re a < 0 ? -a : a; }
template<class T> inline T sqr (T a) { re ((a) * (a)); }

const int maxn = 100005;
const int BSZ = 200;

int n;
int c[maxn], lastt[maxn];
vector<ii> gr[maxn];
vector<ii> grc[maxn];
vector<pair<int, ii>> st[maxn];
int comp[maxn], which[maxn];
bool used[maxn];
int kv;
vector<pair<ii, ii>> ops;

void go(int cur, int pr, int last, int curd)
{
	if (used[cur] && pr != -1)
	{
		while (!st[kv].empty()) st[kv].pop_back();
		comp[cur] = kv;
		which[kv] = cur;
		grc[kv].clear();
		grc[kv].pb({last, curd});
		grc[last].pb({kv, curd});
		last = kv;
		kv++;
		curd = 0;
	}
	for (auto e : gr[cur]) if (e.fi != pr)
	{
		go(e.fi, cur, last, curd + e.se);
	}
}

void color(int cur, int pr, int maxd, int curc, int curt)
{
	if (maxd < 0) return;
	c[which[cur]] = curc;
	while (st[cur].size() > 0 && st[cur].back().fi <= maxd) st[cur].pop_back();
	st[cur].pb({maxd, {curc, curt}});
	for (auto e : grc[cur]) if (e.fi != pr)
	{
		color(e.fi, cur, maxd - e.se, curc, curt);
	}
}

inline bool cmpmy(pair<int, ii> a, const pair<int, ii> &b)
{
	return a.fi > b.fi;
}

void refresh(int cur, int pr, int id, int curd, int curstpt)
{
	if (used[cur] && pr != -1) return;
//	while (curstpt >= 0 && curd > (int)st[id][curstpt].fi) curstpt--;
	curstpt = upper_bound(st[id].begin(), st[id].begin () + curstpt + 1, mp(curd, mp(0, 0)), cmpmy) - st[id].begin() - 1;
	if (curstpt < 0) return;
//	cout << "refr " << cur << ' ' << id << ' ' << curstpt << endl;
//	cout << lastt[cur] << ' ' << st[id][curstpt].se.se << ' ' << st[id][curstpt].se.se << endl;
	if (lastt[cur] < st[id][curstpt].se.se)
	{
		c[cur] = st[id][curstpt].se.fi;
		lastt[cur] = st[id][curstpt].se.se;
	}
	for (auto e : gr[cur]) if (e.fi != pr)
	{
		refresh(e.fi, cur, id, curd + e.se, curstpt);
	}
}

int main () {
	scanf("%d", &n);
	for (int i = 1; i < n; i++)
	{
		int a, b, w;
		scanf("%d%d%d", &a, &b, &w);
		a--, b--;
		gr[a].pb({b, w});
		gr[b].pb({a, w});
	}
	int NQ;
	scanf("%d", &NQ);
	for (int Q = 0; Q < NQ; Q++)
	{
		int t;
		scanf("%d", &t);
		int a, d, c;
		if (t == 1)
		{
			scanf("%d%d%d", &a, &d, &c);
			a--;
			ops.pb({{1, a}, {d, c}});
		} else
		{
			scanf("%d", &a);
			a--;
			ops.pb({{2, a}, {0, 0}});
		}
	}
	for (int i =0 ; i < n; i++)
	{
		c[i] = 0;
		lastt[i] = -1;
	}
	for (int Q = 0; Q < NQ; Q += BSZ)
	{
		cerr << "next " << endl;
		for (int i = 0; i < n; i++) used[i] = false;
		for (int q = Q; q < NQ && q < Q + BSZ; q++) used[ops[q].fi.se] = true;
		kv = 0;
		for (int i = 0; i < n; i++) if (used[i])
		{
			grc[0].clear();
			while (!st[0].empty()) st[0].pop_back();
			comp[i] = 0;
			which[0] = i;
			kv = 1;
//			cout << "found " << i << endl;
			go(i, -1, 0, 0);
			break;
		}	
//		cout << kv << endl;
/*		for (int i = 0; i < kv; i++) printf("%d ", which[i]);
		printf("\n");
		for (int i = 0; i < kv; i++)
		{
			for (auto e : grc[i]) printf("(%d %d) ", e.fi, e.se);
			printf("\n");
		}*/
//		cout << "sadf" << endl;
		for (int q = Q; q < NQ && q < Q + BSZ; q++)
		{
			if (ops[q].fi.fi == 2)
			{
				printf("%d\n", c[ops[q].fi.se]);
			} else
			{
				color(comp[ops[q].fi.se], -1, ops[q].se.fi, ops[q].se.se, q);
			}
		}
/*		for (int i = 0; i < kv; i++)
		{
			for (auto t : st[i]) printf("(%d %d %d) ", t.fi, t.se.fi, t.se.se);
			printf("\n");
		}*/
		cerr << "refresh " << endl;
		for (int i = 0; i < kv; i++) refresh(which[i], -1, i, 0, (int)st[i].size() - 1);
//		for (int i = 0; i < n; i++) printf("%d ", c[i]);
//		printf("\n");
	}
	re 0;
}
