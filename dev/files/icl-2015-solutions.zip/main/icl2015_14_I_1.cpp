#include <bits/stdc++.h>

using namespace std;

#define long unsigned long long

const long INF = 100010001LL * 100010001LL;
const int M = 1010;

long binom(long n, long k)
{
    if (n < k)
        return 0;
    long ans = 1;
    for (long i = 1; i <= k; ++i)
    {
        long x = (n + 1 - i);
        if (ans / i >= INF / x)
            return INF;
        ans = (ans * x / i); //huiovyi
    }
    return ans;
}


long n, m, x[M];

void kill()
{
    cin >> n >> m;
    for (int i = m; i >= 1; --i) {
        long l = 0, r = INF, mid;
        while (l < r)
        {
            mid = 1 + (l + r) / 2;
            if (binom(mid, i) > n)
                r = mid - 1;
            else
                l = mid;
            //cerr << "binom " << mid << " " << i << " -> " << binom(mid, i) << "!\n";
        }

        if (binom(l, i) == 0)
            l = 0;
        x[i] = l;
        n -= binom(l, i);
        //cerr << n << "__\n";
    }

    for (int i = m; i >= 1; --i)
        if (x[i] == 0)
            x[i] = i - 1;

    for (int i = m; i >= 1; --i)
    {
        cout << x[i] << " ";
    }
    cout << "\n";
}

int main()
{
#ifdef LOCAL
    freopen("i.in", "r", stdin);
#endif // LOCAL
    kill();
    return 0;
}
