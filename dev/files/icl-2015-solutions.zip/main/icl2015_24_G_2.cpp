#include<iostream>
#include<vector>
#include<map>
#include<string>
#include<string.h>
#include<algorithm>
#include<set>
using namespace std;

#define MAX_INP (100000 + 10)

long long int mas[MAX_INP];
/*int lngcmp(const void* a, const void * b) {
long long int x = (long long int*)a;
long long int y = b;
}*/
int main()
{
	int n;
	cin>>n;
	for (int i = 0; i < n; i++) {
		long long int h, m, s;
		cin>>h>>m>>s;
		long long int time = (h * 1000000 + m) * 1000000 + s;
		mas[i] = time;
	}
	sort(mas, mas + n);
	long long int cycle = ((long long int)12) * 1000000 * 1000000;
	long long int max_razr = mas[0]-mas[n - 1] + cycle;
	int max_ind = 0;
	for (int i = 1; i < n; i++) {
		if (mas[i]-mas[i-1]>max_razr) {
			max_razr = mas[i]-mas[i-1];
			max_ind = i;
		}
	}
	max_ind--;
	if (max_ind < 0) {
		max_ind += n;
	}
	long long int h, m, s;
	h = 0;
	m = 0;
	s = 0;
	long long int time = mas[max_ind];
	for (int i = 0; i < n; i++) {
		long long int slag = 0;
		if (mas[i]<=time) {
			slag = time - mas[i];
		} else {
			slag = time - mas[i] + cycle;
		}
		s += slag;
		m += s / 1000000;
		h += m / 1000000;
		s %= 1000000;
		m %= 1000000;
	}
	cout<<h<<' '<<m<<' '<<s;
}