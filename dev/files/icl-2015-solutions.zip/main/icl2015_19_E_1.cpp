#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

typedef long long ll;

struct pt {
	int x, y;

	pt() {}
	pt(int x, int y) : x(x), y(y) {}

	void read() {
		scanf("%d%d", &x, &y);
	}

	pt operator+ (const pt &p) const {
		return pt(x + p.x, y + p.y);
	}

	pt operator- (const pt &p) const {
		return pt(x - p.x, y - p.y);
	}

	ll operator% (const pt &p) const {
		return 1LL * x * p.x + 1LL * y * p.y;
	}

	ll operator* (const pt &p) const {
		return 1LL * x * p.y - 1LL * y * p.x;
	}

	bool operator< (const pt &p) const {
		if (x != p.x) return x < p.x;
		return y < p.y;
	}

	void rotate() {
		swap(x, y);
		x *= -1;
	}

	int up() const {
		if (y > 0 || y == 0 && x > 0) return 1;
		if (y < 0 || y == 0 && x < 0) return -1;
		return 0;
	}
};

int n;
vector<pt> down, up;

void convex(vector<pt> &a) {
	int n = a.size();
	sort(a.begin(), a.end());
	pt p1 = a[0], p2 = a[n - 1];
	up.clear();
	down.clear();

	for (int i = 0; i < n; i++) {
		if (i == 0 || i == n - 1 || ((a[i] - p1) * (p2 - p1)) > 0) {
			while (down.size() > 1 && ((a[i] - down.back()) * (down[(int)down.size() - 1] - down[(int)down.size() - 2])) >= 0) down.pop_back();
			down.push_back(a[i]);
		}
		if (i == 0 || i == n - 1 || ((a[i] - p1) * (p2 - p1)) < 0) {
			while (up.size() > 1 && ((a[i] - up.back()) * (up[(int)up.size() - 1] - up[(int)up.size() - 2])) <= 0) up.pop_back();
			up.push_back(a[i]);
		}
	}
	a.clear();
	for (int i = 0; i < (int)down.size(); i++) a.push_back(down[i]);
	for (int i = (int)up.size() - 2; i > 0; i--) a.push_back(up[i]);
}

vector<pt> a;
vector<pt> v;
vector<int> p;
vector<pt> far;

bool cmp(int i, int j) {
	const pt &a = v[i];
	const pt &b = v[j];
	if (a.up() != b.up()) return a.up() < b.up();
	return (a * b) > 0;
}

void getLine(pt a, pt b, ll &A, ll &B, ll &C) {
	A = a.y - b.y;
	B = b.x - a.x;
	C = -(1LL * A * a.x + 1LL * B * a.y);
}

void solve(ll A1, ll B1, ll C1, ll A2, ll B2, ll C2, double &x, double &y) {
	ll det = A1 * B2 - A2 * B1;
	ll detx= C1 * B2 - C2 * B1;
	ll dety= A1 * C2 - A2 * C1;
	x = -detx / (double)det;
	y = -dety / (double)det;
}

double sqr(double x) {
	return x * x;
}

int main() {
	//freopen("task.in", "r", stdin);

	while (scanf("%d", &n) == 1) {
		a.resize(n);
		for (int i = 0; i < n; i++) a[i].read();
		convex(a);
		
		v.clear();
		p.clear();
		n = a.size();
		for (int i = 0; i < n; i++) {
			pt vv = (a[(i + 1) % n] - a[i]);
			for (int j = 0; j < 4; j++) {
				p.push_back(v.size());
				v.push_back(vv);
				far.push_back(pt());
				vv.rotate();
			}
		}

		sort(p.begin(), p.end(), cmp);
		int j = 0;
		for (int i = 0; i < (int)p.size(); i++) {
			pt cur = v[p[i]];
			while ((a[j] % cur) < (a[(j + 1) % n] % cur)) j = (j + 1) % n;

			if ((a[j] % cur) >= (a[(j - 1 + n) % n] % cur)) far[p[i]] = a[j];
			else far[p[i]] = a[(j - 1 + n) % n];
		}

		double ans = 1e20;
		double _x[4], _y[4];

		for (int i = 0; i < n; i++) {
			pt _vv = (a[(i + 1) % n] - a[i]);
			vector<pt> vv(4);

			for (int j = 0; j < 4; j++) {
				vv[j] = _vv;
				_vv.rotate();
			}

			vector<long long> A(4), B(4), C(4);
			for (int j = 0; j < 4; j++) {
				pt c1 = far[i * 4 + j];
				pt c2 = c1 + vv[(j + 1) % 4];
				getLine(c1, c2, A[j], B[j], C[j]);
			}

			vector<double> x(4), y(4);
			for (int j = 0; j < 4; j++) {
				solve(A[j], B[j], C[j], A[(j + 1) % 4], B[(j + 1) % 4], C[(j + 1) % 4], x[j], y[j]);
			}
			double o1 = sqrt(sqr(x[1] - x[0]) + sqr(y[1] - y[0]));
			double o2 = sqrt(sqr(x[2] - x[1]) + sqr(y[2] - y[1]));
			if (ans > o1 * o2) {
				ans = o1 * o2;
				for (int j = 0; j < 4; j++) {
					_x[j] = x[j];
					_y[j] = y[j];
				}
			}
		}
		for (int j = 0; j < 4; j++) printf("%.10lf %.10lf\n", _x[j], _y[j]);
		//cerr << ans << endl;
	}

	return 0;
}