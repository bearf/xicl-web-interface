#include <bits/stdc++.h>
#include <vector>

using namespace std;

#ifdef FOOBAR
    ifstream fin("input.txt");
#define cin fin
#endif // FOOBAR

int n;
long long mx = 0, k = 0;
long long mx2 = 0, k2 = 0;
long long res;
vector<int> a;

int main() {
    ios_base::sync_with_stdio(false);

    cin >> n;

    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        if (x > mx) {
            mx2 = mx;
            k2 = k;
            mx = x;
            k = 1;
        } else if (x == mx) {
            k++;
        }
        if (x < mx && x > mx2) {
            mx2 = x;
            k2 = 1;
        } else if (x == mx2) {
            k2++;
        }

        a.push_back(x);
    }

    res = mx * k;

    if (res != 0) {
    if (k > 2) {
        if (a[0] == mx && a[1] > 0) {
            res = mx + 1;
        }

        for (int i = 1; i < n - 1; i++) {
            if (a[i] == mx && (a[i - 1] > 0 || a[i + 1] > 0)) {
                res = mx + 1;
            }
        }

        if (a[n - 1] == mx && a[n - 2] > 0) {
            res = mx + 1;
        }

        if (res > mx*(k - 1)) {
            if (a[0] == mx && a[1] <= mx - 2) {
                res = mx*(k - 1);
            }

            for (int i = 1; i < n - 1; i++) {
                if (a[i] == mx && (a[i - 1] <= mx - 2 || a[i + 1] <= mx - 2)) {
                    res = mx*(k - 1);
                }
            }

            if (a[n - 1] == mx && a[n - 2] <= mx - 2) {
                res = mx*(k - 1);
            }
        }
    } else if (k > 1) {
        if (a[0] == mx && a[1] > 0) {
            res = mx + 1;
        }

        for (int i = 1; i < n - 1; i++) {
            if (a[i] == mx && (a[i - 1] > 0 || a[i + 1] > 0)) {
                res = mx + 1;
            }
        }

        if (a[n - 1] == mx && a[n - 2] > 0) {
            res = mx + 1;
        }

        if (a[0] == mx && a[1] <= mx - 2) {
            res = min(res, mx);
        }

        for (int i = 1; i < n - 1; i++) {
            if (a[i] == mx && (a[i - 1] <= mx - 2 || a[i + 1] <= mx - 2)) {
                res = min(res, mx);
            }
        }

        if (a[n - 1] == mx && a[n - 2] <= mx - 2) {
            res = min(res, mx);
        }

    } else if (k == 1 && mx - mx2 > 1) {
        if (a[0] == mx && a[1] < mx - 2) {
            res = mx - 1;
        }

        for (int i = 1; i < n - 1; i++) {
            if (a[i] == mx && (a[i - 1] < mx - 2 || a[i + 1] < mx - 2)) {
                res = mx - 1;
            }
        }

        if (a[n - 1] == mx && a[n - 2] < mx - 2) {
            res = mx - 1;
        }
    }
    }

    cout << res;

    return 0;
}
