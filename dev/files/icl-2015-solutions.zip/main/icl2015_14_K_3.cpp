#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

#define long long long

long mi, ma;

long solve(long n, long m, long k) {
    if (n <= 2 * m + 2)
    {
        if (k == n)
            return mi = ma = m - (n - 1) / 2;
        else
            if (k % 2 == n % 2)
                return mi = ma = 1;
            else
                return mi = ma = 0;
    }

    long t = 1, x = 0, s = 0;

    long in = -1;
    while (s + 2 * t + 2 * m <= n)
    {
        ++x;
        if (2 * m + s < k && k <= s + 2 * t + 2 * m)
            in = x;

        s += 2 * t;
        t *= 2;
    }


    if (k > s + 2 * m)
        return mi = ma = -1;

    if (in != 1)
    {
        if (in % 2 == x % 2)
            return mi = ma = 0;
        else
        {
            mi = 0, ma = 0;
            return 1;
        }
    }

    if (k % 2 != x % 2)
        return mi = ma = 0;
    else
    {
        mi = 0, ma = 1;
        return 12;
    }
}

int main()
{
#ifdef LOCAL
    freopen("k.in", "r", stdin);
#endif // LOCAL
    long n, m, q, k;
    cin >> n >> m >> q;
    while (q--)
    {
        cin >> k;
        k = n + 1 - k;
        solve(n, m, k);
        cout << mi << " " << ma << "\n";
    }
    return 0;
}
