#include <iostream>
#include <vector>
#include <math.h>
#include <cstdlib>

using namespace std;

long long n, p, i, cntm, ans, m;
vector <long long> a;

long long lft(long long v){
    if (a[v] == m && a[v - 1] == m - 1){
        return (cntm * m);
    }
    if (a[v] == m){
        if (a[v - 1] == m){
            return (m + 1);
        } else {
            return ((cntm - 1) * m);
        }
    } else {
        if (a[v - 1] == m){
            return (m + 1);
        }
    }
    return (cntm * m);
}

long long rght(long long v){
    if (a[v] == m && a[v + 1] == m - 1){
        return (cntm * m);
    }
    if (a[v] == m){
        if (a[v + 1] == m){
            return (m + 1);
        } else {
            return ((cntm - 1) * m);
        }
    } else {
        if (a[v + 1] == m){
            return (m + 1);
        }
    }
    return (cntm * m);
}

int main()
{
    cin >> n;
    ans = 100000000000;
    m = -1;
    cntm = 1;
    for (i = 0; i < n; i++){
        cin >> p;
        a.push_back(p);
        if (p > m){
            m = p;
            cntm = 1;
        } else {
            if (p == m){
                cntm++;
            }
        }
    }
    ans = cntm * m;
    if (cntm == 1){
        for (i = 1; i < n - 1; i++){
            if (a[i] == m){
                if (abs(a[i - 1] - m) > 2 || abs(a[i + 1] - m) > 2){
                    cout << m - 1 << endl;
                    exit(0);
                }
                cout << m << endl;
                exit(0);
            }
        }
        if (a[0] == m){
            if (abs(a[0] - a[1]) > 2){
                cout << m - 1 << endl;
                exit(0);
            } else {
                cout << m << endl;
                exit(0);
            }
        } else {
            if (abs(a[n - 1] - a[n - 2]) > 2){
                cout << m - 1 << endl;
                exit(0);
            } else {
                cout << m << endl;
                exit(0);
            }
        }
    }
    for (i = 1; i < n - 1; i++){
        if (a[i] != 0){
            ans = min(ans, lft(i));
            ans = min(ans, rght(i));
        }
    }
    if (a[0] != 0){
        ans = min(ans, rght(0));
    }
    if (a[n - 1] != 0){
        ans = min(ans, lft(n - 1));
    }
    cout << ans << endl;
    return 0;
}
