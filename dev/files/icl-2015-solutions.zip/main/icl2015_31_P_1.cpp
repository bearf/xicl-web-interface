#include <bits/stdc++.h>
#define fin cin
#define fout cout

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

typedef unsigned long long ll;

ll p, q;


void solve()
{
    ll fact = 1;
    for (ll i = 1; p > 0; i++)
    {
        fact *= i;
        ll a = (p * fact) / q;
        fout << a << ' ';
        ll pp = p * fact - a * q;
        ll qq = q * fact;
        ll gg = __gcd(pp, qq);
        //fout << pp << ' ' << qq << ' ' << gg << endl;
        pp /= gg;
        qq /= gg;
        //fout << p << ' ' << q    << endl;
        p = pp;
        q = qq;
    }
    fout << endl;
}


int main()
{
    fin >> p >> q;
    solve();
    return 0;
}
