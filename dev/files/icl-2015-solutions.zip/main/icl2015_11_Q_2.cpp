#include <iostream>

using namespace std;

int m[40];


int main()
{
    int n, k;
    cin >> n >> k;
    m[0] = 1;
    for (int i = 1; i<=n; i++){
        m[i] = m[i-1];
        if (i - k - 1 > 0)
            m[i] += m[k - 1] * m[i-k - 1];
    }
    if (n - k == 1){
        cout << 0;
    }
    else{
        cout << m[n];
    }
    return 0;
}
