#include <bits/stdc++.h>

#define pb push_back

using namespace std;

typedef long long ll;
typedef long double lf;

const int maxn = 100500;
const int mod = 1000000000 + 9;

vector<int> divs[maxn + 1], pr;
int n, ansval = -1;;
lf curans = 1e9;

ll power(ll x, ll p)
{
    if (!p) return 1;
    ll y = power(x, p / 2);
    y = y * y % mod;
    if (p & 1) y = y * x % mod;
    return y;
}

void rec(int n, int need, int modv, lf logv)
{
    if (logv > curans) return;
    if (need == 1)
    {
        curans = logv;
        ansval = modv;
        return;
    }
    for (int d : divs[need])
    {
        if (logv + (d - 1) * log(pr[n]) > curans)
            continue;
        rec(n + 1, need / d, (ll) modv * power(pr[n], d - 1) % mod, logv + (d - 1) * log(pr[n]));
    }
}

int main()
{
#ifdef LOCAL
    freopen("f.in", "r", stdin);
#endif // LOCAL
    int n;
    cin >> n;
    for (int i = 2; i <= n; ++i)
        for (int j = i; j <= n; j += i)
            divs[j].pb(i);
    for (int i = 2; i <= n; ++i)
       reverse(divs[i].begin(), divs[i].end());
    for (int c = 3; pr.size() < 20; c += 2)
    {
        bool ok = true;
        for (int d : pr)
            ok &= c % d != 0;
        if (ok) pr.pb(c);
        //cerr << c << endl;
    }
    rec(0, n, 1, 0);
    cout << ansval << endl;
   // cerr << power(3, 18) * power(5, 16) % mod << endl;
    return 0;
}
