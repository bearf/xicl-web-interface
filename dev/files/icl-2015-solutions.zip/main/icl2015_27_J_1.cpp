#define _USE_MATH_DEFINES
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define sz(x) ((int)x.size())
#define fi first
#define se second
#define re return
#define y0 y248590
#define y1 y5427895
#define j0 j5234895
#define j1 j438759
#define prev prev348957
#define next next457834
#define sqrt(x) sqrt(abs(x))

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef pair<ll, ll> pll;
typedef vector<string> vs;
typedef long double ld;
typedef double D;

template<class T> T gcd (T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> inline T abs (T a) { re a < 0 ? -a : a; }
template<class T> inline T sqr (T a) { re ((a) * (a)); }

ll n, k;
int m, M;
int p[20];
int q[20];
int z[20];
int res[20];
int pref[1000010];
int r;

int power (int a, ll b, int mod) {	
	int c = 1;
	while (b) {
		if (b & 1) c = ((ll)c * a) % mod;
		a = ((ll)a * a) % mod;
		b /= 2;
	}
	re c;
}

pair<ll, int> fact (ll n, int p, int pq) {
	if (n == 0) re mp (0, 1);
	ll tmp = n / pq;
	int cur = power (pref[pq], tmp, pq);
	cur = ((ll)cur * pref[n % pq]) % pq;
	pair<ll, int> tmp2 = fact (n / p, p, pq);
	tmp2.fi += n / p;
	tmp2.se = ((ll)tmp2.se * cur) % pq;
	re tmp2;
}

int main () {
	cin >> n >> k >> m;
	M = m;
	for (int i = 2; i <= m; i++)
		if (m % i == 0) {
			p[r] = i;
			q[r] = 0;
			z[r] = 1;
			while (m % i == 0) {
				m /= i;
				q[r]++;
				z[r] *= i;
			}
			r++;
		}
	for (int i = 0; i < r; i++) {
		int cur = 1;
		for (int j = 0; j <= z[i]; j++) {
			if (j % p[i] != 0)
				cur = ((ll)cur * j) % z[i];
			pref[j] = cur;
//			printf ("%d = %d\n", j, cur);
		}
		pair<ll, int> a = fact (n, p[i], z[i]);
		pair<ll, int> b = fact (k, p[i], z[i]);
		pair<ll, int> c = fact (n - k, p[i], z[i]);
//		printf ("%d %d %d %I64d %I64d %I64d\n", a.se, b.se, c.se, a.fi, b.fi, c.fi);
		a.fi -= b.fi + c.fi;
		a.se = ((ll)a.se * power (b.se, z[i] - z[i] / p[i] - 1, z[i])) % z[i];
		a.se = ((ll)a.se * power (c.se, z[i] - z[i] / p[i] - 1, z[i])) % z[i];
		while (a.se && a.fi) {
			a.se = ((ll)a.se * p[i]) % z[i];
			a.fi--;
		}
		res[i] = a.se;
	}
	for (int i = 0; i < M; i++) {
		int ok = 1;
		for (int j = 0; j < r; j++)
			if (i % z[j] != res[j]) {
				ok = 0;
				break;
			}
		if (ok) {
			printf ("%d\n", i);
			re 0;
		}
	}
	assert (true);
	re 0;
}
