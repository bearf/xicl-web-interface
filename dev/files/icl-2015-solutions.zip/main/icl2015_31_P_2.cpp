#include <bits/stdc++.h>
#define fin cin
#define fout cout

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

typedef unsigned long long ll;

ll p, q;


void solve()
{
    for (ll i = 1; p > 0; i++)
    {
        ll b = (p * i) / q;
        fout << b << ' ';
        p = p * i - b * q;
    }
    fout << endl;
}


int main()
{
    fin >> p >> q;
    solve();
    return 0;
}
