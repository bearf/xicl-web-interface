#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iomanip>
using namespace std;
long long q[100000],p[100001];
int main(){
    int n;
    cin >> n;
    long long  m=0;
    for(int i=0;i<n;i++){
        cin>>q[i];
        p[q[i]]++;
        m=max(m,q[i]);
    }
    long long ans=0;
    for(int i=0;i<n ;i++)
        if(q[i]==m){
        ans+=m;
        }
    for(int i=1;i<n-1;i++)
        if(q[i]!=0){
        if(q[i-1]+1>m){
            ans=min(ans,m+1);
        }
        else
            if(q[i-1]+1<m && q[i]==m){
                if(p[m]>1)
                ans=min(ans,(p[m]-1)*m);
                else
                if(q[i-1]+1==m-1){
                   ans=min(ans,(p[m-1]+2)*(m-1));
                }
                else
                    ans=min(ans,(p[m-1]+1)*(m-1));
            }
        if(q[i+1]+1>m){
            ans=min(ans,m+1);
        }
        else
            if(q[i+1]+1<m && q[i]==m){
                if(p[m]>1)
                ans=min(ans,(p[m]-1)*m);
                else
                if(q[i+1]+1==m-1){
                   ans=min(ans,(p[m-1]+2)*(m-1));
                }
                else
                    ans=min(ans,(p[m-1]+1)*(m-1));
            }
    }
    int i=n-1;
    if(q[i-1]+1>m){
            ans=min(ans,m+1);
        }
        else
            if(q[i-1]+1<m && q[i]==m){
                if(p[m]>1)
                ans=min(ans,(p[m]-1)*m);
                else
                if(q[i-1]+1==m-1){
                   ans=min(ans,(p[m-1]+2)*(m-1));
                }
                else
                    ans=min(ans,(p[m-1]+1)*(m-1));
            }
    i=0;
    if(q[i+1]+1>m){
            ans=min(ans,m+1);
        }
        else
            if(q[i+1]+1<m && q[i]==m){
                if(p[m]>1)
                ans=min(ans,(p[m]-1)*m);
                else
                if(q[i+1]+1==m-1){
                   ans=min(ans,(p[m-1]+2)*(m-1));
                }
                else
                    ans=min(ans,(p[m-1]+1)*(m-1));
            }
    cout<<ans;
}
