#include <cstdio>
#include <cstring>
#include <iostream>
#include <set>
#include <queue>
#include <cmath>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;

#define ll long long
#define ld long double
#define mp make_pair
#define pb push_back
#define forn(i, n) for(int i = 0; i < n; i++)

const int inf = 1 << 20;
const ld eps = 1e-9;

const int tern_sz = 200;

ld xx0, yy0, s;

ll n, x1, x2, yy1, y2, vx, vy;

ll x[11000], y[11000];

ld f(ld t){
	s = 0;
	xx0 = ((ld)x1) + vx * t; 
	yy0 = yy1 + (vy + 0.0) * t;

	forn(i, n) s += sqrt((ld) (x[i] - xx0) * (x[i] - xx0) + (y[i] - yy0) * (y[i] - yy0));

	return s;
}


int main(){
	scanf("%lld%lld%lld%lld", &x1, &yy1, &x2, &y2);
	scanf("%lld", &n);
	

	vx = x2 - x1; vy = y2 - yy1;

	forn(i, n) scanf("%lld%lld", &x[i], &y[i]);

	ld l = -inf, r = inf, tl, tr;
	forn(i, tern_sz){
		tl = (2 * l + r) / 3; tr =  (l + 2 * r) / 3;
		if (f(tl) < f(tr)) r = tr;
		else l = tl;
	}

	printf("%.9Lf\n%.9Lf %.9Lf", f(l), x1 + vx * l, yy1 + vy * l);

	return 0;
}