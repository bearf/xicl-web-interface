#include<iostream>
#include<vector>
#include<map>
#include<string>
#include<string.h>
#include<algorithm>
#include<set>
using namespace std;

#define MAX_INP (100000 + 10)

long long int mas[MAX_INP];

long long razn[MAX_INP];
int main()
{
	int n;
	cin>>n;
	map<long long,int> mp;

	for (int i = 0; i < n; i++) {
		long long int h, m, s;
		cin>>h>>m>>s;
		long long int time = (h * 1000000 + m) * 1000000 + s;
		mas[i] = time;
		mp[time]++;
	}
	sort(mas, mas + n);
	long long int cycle = ((long long int)12) * 1000000 * 1000000;

	for (int i = 1; i < n; i++) {
		razn[i-1] = mas[i] - mas[i-1];
	}
	razn[n-1] = mas[0] - mas[n-1];
	if (razn[n-1] < 0) {
		razn[n-1] += cycle;
	}

	long long int h = 0;
	long long int ms = 0;
	for (int i = 1; i < n; i++) {
		ms += razn[i] * i;
		h += ms / 1000000000000;
		ms %= 1000000000000;
	}
	long long int h_max = h;
	long long int ms_max = ms;

	int null_cnt = 0;
	for (int i = 1; i < n; i++) {
		int cnt = mp[mas[i]];
		long long slag=0;
		if(razn[i-1]==0 && cnt>1)
		{
			slag=0;
		}
		else
		{
			slag = -(cnt*cycle - razn[i-1]) + (n-1) * razn[i-1];
		}
		/*if (razn[i] == 0) {
			if (null_cnt == 0) {
				for (int j = i;;j++) {
					if (j == n) {
						j = 0;
					}
					if (j == i - 1)
						break;
					if (razn[j]==0) {
						null_cnt++;
					} else break;
				}
			}
			slag -= null_cnt * cycle;
			null_cnt--;*/
		
		if (slag >= 0) {
			ms += slag % cycle;
			h += ms / 1000000000000;
			ms %= 1000000000000;
		} else {
			long long int slag_h = ((-slag)) / 1000000000000;
			long long int slag_ms = ((-slag)) % 1000000000000;
			ms -= slag_ms;
			h -= slag_h;
			while (ms<0) {
				ms += 1000000000000;
				h--;
			}
			while (h < 0) {
				h += 12;
			}
		}
		if (h < h_max) {
			h_max = h;
			ms_max = ms;
		} else if (h == h_max) {
			if (ms < ms_max) {
				h_max = h;
				ms_max = ms;
			}
		}
	}

	cout<<h_max<<' '<<(ms_max / 1000000)<<' '<<(ms_max % 1000000);

}