#include <bits/stdc++.h>

using namespace std;

#define long long long

const int M = 1000100;

long n, k, m, f[M];

long bin(long x, long a, long mod) {
    long y = 1;
    while (a)
    {
        if (a & 1)
        {
            y = (y * x) % mod;
        }
        x = (x * x) % mod;
        a >>= 1;
    }
    return y;
}

void pre(long p, long mod) {
    f[0] = 1;
    for (long i = 1; i <= mod; ++i)
        if (i % p == 0)
            f[i] = f[i - 1];
        else
            f[i] = (i * f[i - 1]) % mod;
}

long get(long n, long p, long mod) {
    if (n < p)
        return f[n];
    long k = (n / mod);

    long ans = (f[n % mod] * bin(f[mod], k, mod)) % mod;
    ans = (ans * get(n / p, p, mod)) % mod;
    return ans;
}

long getPw(long n, long p) {
    long ans = 0;
    while (n)
    {
        ans += n / p;
        n /= p;
    }
    return ans;
}

void euclid(long a, long b, long &x, long &y) {
    if (b == 0)
    {
        x = 1, y = 0;
        return;
    }
    long x1, y1;
    euclid(b, a % b, x1, y1);
    x = y1;
    y = x1 - (a / b) * y1;
    assert(a * x + b * y == 1);
}

long combine(long a1, long mod1, long a2, long mod2) {
    long x, y;
    euclid(mod1, mod2, x, y);
    x = x * (a2 - a1);
    long ans = mod1 * x + a1;
    ans %= mod1 * mod2;
    if (ans < 0)
        ans += mod1 * mod2;
    assert(ans % mod1 == a1 && ans % mod2 == a2);
    return ans;
}

long kill() {
    long ans = 0, amod = 1;
    for (long i = 2; i <= m; ++i)
    if (m % i == 0)
    {
        long mod = 1;
        while (m % i == 0)
        {
            m /= i;
            mod *= i;
        }

        pre(i, mod);

        long f1 = get(n, i, mod);
        long f2 = get(k, i, mod);
        long f3 = get(n - k, i, mod);
        long f = (f1 * bin(f2, mod - mod / i - 1, mod)) % mod;
        f = (f * bin(f3, mod - mod / i - 1, mod)) % mod;

        long pw = getPw(n, i) - getPw(k, i) - getPw(n - k, i);
        while (pw)
        {
            f = (f * i) % mod;
            --pw;
        }

        //cerr << f << " for " << mod << "!\n";
        ans = combine(ans, amod, f, mod);
        amod *= mod;
    }
    return ans;
}

void test(long mod) {
    int N = 100;
    long c[N][N];
    for (int i = 0; i < N; ++i)
        fill(c[i], c[i] + N, 0);
    for (int i = 0; i < N; ++i)
        c[i][0] = 1;
    for (int i = 1; i < N; ++i)
        for (int j = 1; j <= i; ++j)
            c[i][j] = (c[i - 1][j] + c[i - 1][j - 1]) % mod;

    for (int i = 1; i < N; ++i)
    for (int j = 0; j <= i; ++j) {
        n = i;
        k = j;
        m = mod;
        if (c[i][j] != kill())
        {
            cout << "wrong on n = " << i << " k = " << j << " m = " << mod << "\n";
            exit(0);
        }
    }
}

int main()
{
#ifdef LOCAL
    freopen("j.in", "r", stdin);
#endif // LOCAL
    //for (int i = 2; i <= 100; ++i)
    //     test(i);
    cin >> n >> k >> m;
    cout << kill() << "\n";
    return 0;
}
