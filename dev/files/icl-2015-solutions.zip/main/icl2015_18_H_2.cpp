#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iomanip>
using namespace std;
int main(){
    int n,s,f,a,b,c;
    cin>>n>>s>>f;
    if(s==f){
        cout<<-1;
        return 0;
    }
    if(s<f){
        a=s-1;
        b=f-s-1;
        c=n-f;
    }
    else{
        a=n-s;
        b=s-f-1;
        a=f-1;
    }
    if(b==0){
        if(a==0)
           if(c==0)
            cout<<1;
           else
            cout<<1;
        else
           if(c>0)
             cout<<-1;
           else
             cout<<1;
        return 0;
    }
    int ans=0;
    if(a==0){
        if(c!=0){
        if(b%3==0)
           ans=b/3;
        if(b%3==1)
           ans=b/3+1;
        if(b%3==2)
            ans=b/3+2;
        ans++;
        }
        else{
           if(b%3==1)
            ans+=b/3+2;
           if(b%3==2)
            ans+=b/3+1;
           if(b%3==0)
            ans+=b/3+1;
        }
    }
    else{
        if(c!=0){
            if(b%3==1)
                ans=b/3;
            if(b%3==2)
                ans=b/3+1;
            if(b%3==0)
                ans=b/3+1;
            ans+=2;
        }
        else{
            if(b%3==2)
                ans+=b/3+2;
            if(b%3==0)
                ans+=b/3;
            if(b%3==1)
               ans+=b/3+1;
            ans++;
        }
    }
    cout<<ans;
}
