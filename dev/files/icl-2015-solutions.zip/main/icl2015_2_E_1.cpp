#include <string>
#include <cstring>
#include <iostream>
#include <fstream>
#include <deque>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <ctype.h>
#include <ctime>
#include <assert.h>

#define _USE_MATH_DEFINES
#include <math.h>

#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define LL long long
#define mp make_pair
#define sqr(x) x*x

using namespace std;

void smain();

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif
	
	smain();

	return 0;
}

#define int long long
#define N 100000
#define EPS 0.01

int n;
int x[N], y[N];
double nx[N], ny[N];

void smain(){
	cin >> n;
	forn(i, n) cin >> x[i] >> y[i];

	double res = (int)N * N;
	double pres[4][2];
	for(double ang = 0; ang < M_PI_2; ang += EPS){
		double minx = N, miny = N, maxx = -N, maxy = -N;
		forn(i, n) {
			nx[i] = cos(ang) * x[i] - sin(ang) * y[i];
			ny[i] = cos(ang) * x[i] + sin(ang) * y[i];
			if(nx[i] < minx) minx = nx[i];
			if(nx[i] > maxx) maxx = nx[i];
			if(ny[i] < miny) miny = ny[i];
			if(ny[i] > maxy) maxy = ny[i];
		}
		double t = (maxx - minx) * (maxy - miny);
		if(t < res) {
			res = t;
			pres[0][0] = minx, pres[0][1] = miny;
			pres[1][0] = maxx, pres[1][1] = miny;
			pres[2][0] = maxx, pres[2][1] = maxy;
			pres[3][0] = minx, pres[3][1] = maxy;
			forn(j, 4) {
				double tx = pres[j][0], ty = pres[j][1];
				pres[j][0] = cos(-ang) * tx - sin(-ang) * ty;
				pres[j][1] = cos(-ang) * tx + sin(-ang) * ty;
			}
		}
	}

	cout.precision(10);
	cout << fixed << endl;
	forn(j, 4) {
		cout << pres[j][0] << ' ' << pres[j][1] << endl;
	}

}