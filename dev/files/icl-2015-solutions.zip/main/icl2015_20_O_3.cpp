#include <bits/stdc++.h>

using namespace std;

const double eps = 1e-15;

struct point{
	double x, y;
	point() {}
	point(double _x, double _y) {
		x = _x;
		y = _y;
	}
};

struct vec{
	double x, y;
	vec(){
		x = y = 0;
	}
	vec(point a, point b) {
		x = b.x - a.x;
		y = b.y - a.y;
	}
};

double len(point a, point b) {
	return hypot(b.x - a.x, b.y - a.y);
}

bool operator <(point a, point b) {
	return (b.x - a.x > eps || (fabs(b.x - a.x) < eps && b.y - a.y > eps));
}

bool operator != (point a, point b) {
	return (b.x - a.x > eps || b.y - a.y > eps);
}

vector<point> h;

double f(point p0) {
	double L = -1000000.0;
	for (int i = 0; i < h.size(); i++) {
		L = max(L, len(p0, h[i]));
	}
	return L;
}

double ft(point p0) {
	double L = 0.0;
	for (int i = 0; i < h.size(); i++) {
		L += len(p0, h[i]);
	}
	return L;
}

int main() {
	int n;
	point p1, p2;
	cin >> p1.x >> p1.y >> p2.x >> p2.y;
	cin >> n;
	h.resize(n);
	for (int i = 0; i < n; i++) {
		cin >> h[i].x >> h[i].y;
	}
	vec tmp = vec(p1, p2);
	tmp.x *= 100000;
	tmp.y *= 100000;
	point right = point(p2.x + tmp.x, p2.y + tmp.y);
	tmp = vec(p2, p1);
	tmp.x *= 100000;
	tmp.y *= 100000;
	point left = point(p1.x + tmp.x, p1.y + tmp.y);
	point l = left, r = right;
	if (r < l) {
		swap(l, r);
	}
	while (l != r) {
		point m1 = point(l.x + (r.x - l.x) / 3, l.y + (r.y - l.y) / 3), m2 = point(r.x - (r.x - l.x) / 3, r.y - (r.y - l.y) / 3);
		if (f(m1) - f(m2) > eps) {
			l = m1;
		} else {
			r = m2;
		}
	}
	cout << fixed << setprecision(9);
	cout << ft(r) << endl;
	cout << r.x << " " << r.y;
	return 0;
}