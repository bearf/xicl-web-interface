#define _USE_MATH_DEFINES

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <cassert>
#include <vector>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <bitset>
#include <cassert>
#include <cmath>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) int(a.size())
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define all(a) a.begin(),a.end()

typedef pair<int,int> pt;
#define ft first
#define sc second

typedef long long li;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = 1e9;

li n;
int m;

bool read() {
	if (!(cin >> n >> m))
		return false;
	return true;
}

li C(li n, li k) {
	if (n < k)
		return 0;
	if (k == 1)
		return n;
	
	ld res = 1;
	int ft = 2;
	for (li i = n - k + 1; i <= n; ++i) {
		res *= i;
		while (ft <= k && res >= ft)
			res /= ft++;
		if (ft > k && res > 1e17)
			break;
	}
	if (res > 1e18)
		res = 1e18;
	return res + 0.5;
}

void solve() {
	li st = n;
	vector<li> ans;
	forn (i, m) {
		li l = 0, r = 1e18;
		if (!ans.empty())
			r = ans.back() - 1;
		while(r - l > 1) {
			li mid = (r + l) / 2;
			if (C(mid, m - i) <= n)
				l = mid;
			else
				r = mid;
		}
		for (li cur = r; cur >= l; --cur)
			if (C(cur, m - i) <= n) {
				n -= C(cur, m - i);
				ans.push_back(cur);
				break;
			}
	}
	forn (i, ans.size())
		cout << ans[i] << ' ';
	cout << endl;
	li nn = 0;
	forn (i, ans.size())
		nn += C(ans[ans.size() - 1 - i], i + 1);
	assert(nn == st);
	assert(ans.size() == m);
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif

	while (read()) {
		solve();
	}

	cerr << "TIME: " << clock() * 1000 / CLOCKS_PER_SEC << endl;
	return 0;
}