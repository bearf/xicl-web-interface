#include <bits/stdc++.h>
#include <vector>

using namespace std;

#ifdef FOOBAR
    ifstream fin("input.txt");
#define cin fin
#endif // FOOBAR

const int N = 301;

long long MOD = 1000 * 1000 * 1000 + 9;

long long c[N][N];
long long a[N][N];
long long b[N][N];

int main() {
    int n, k; cin >> n >> k;

    for (int i=0; i<=n; i++)
        c[i][0] = c[i][i] = 1;
    for (int i=0; i<=n; i++)
        for (int j=1; j<i; j++)
            c[i][j] = (c[i-1][j-1] + c[i-1][j]) % MOD;

    for (int i=0; i<=k; i++)
        a[0][i] = 1;
    for (int i=1; i<=n/2; i++)
        for (int j=i; j<=i+k && j<=n/2; j++)
            a[i][j] = a[i-1][j] + a[i][j-1];



    for (int i=0; i<=k-1; i++)
        b[0][i] = 1;
    for (int i=1; i<=n/2; i++)
        for (int j=i; j<=i+k-1 && j<=n/2; j++)
            b[i][j] = b[i-1][j] + b[i][j-1];

    long long ans = 0;
    for (int i=0; 2*i <= n; i++)
        ans = (ans + (a[i][i] - b[i][i]) * c[n][n-2*i]) % MOD;

    cout << ans << endl;

    return 0;
}
