#include <string>
#include <cstring>
#include <iostream>
#include <fstream>
#include <deque>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <ctype.h>
#include <ctime>

#define _USE_MATH_DEFINES
#include <math.h>

#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define LL long long
#define mp make_pair
#define sqr(x) x*x

using namespace std;

void smain();

int main() {
#ifdef _DEBUG
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif
	
	smain();

	return 0;
}

#define int long long

void smain() {
	int n, s, f, ll, res;
	for (;cin>>n>>s>>f;) {
		res = 0;

		if (s>f)
			swap(s,f);

		ll = s;

		if (s==f && n != 1) {
			cout<<-1<<'\n';
			continue;
		}

		if (s>1) {
			while (s>1) {
				if (s-2>=1) 
					s-=2;
				else
					break;
			}

			if (s==1)
				s++;
			else 
				s--;
			res++;

			while (s<ll) {
				s+=2;
			}
		}

		if (s==f && s != n) {
			cout << -1 <<'\n';
			continue;
		}

		if (f==n)
			ll=f;
		else
			ll=f-1;

		while (s+3<=ll) {
			s+=3;
			res++;
		}

		res += ll-s;
		s=ll;

		if (s==f) {
			cout<<res<<'\n';
			continue;
		}

		s+=2;

		while (s<n) {
			if (s+2<=n)
				s+=2;
			else
				break;
		}

		if (s==n)
			s--;
		else
			s++;
		res++;

		while (s>f)
			s-=2;

		cout<<res<<'\n';
	}
}