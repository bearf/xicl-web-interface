#include <iostream>
#include <algorithm>

using namespace std;

long long minimum(long long a, long long b)
{
    if (a < b)
        return a;
    return b;
}

int main()
{
    long long a[100000];
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) {
        long long h, m, s;
        cin >> h >> m >> s;
        a[i] = h * 1000000000000 + m * 1000000 + s;
    }
    sort(a, a + n);
    long long c[100000] = {0};
    for (int i = 0; i < n; i++) {
        if (a[i] != a[0]) {
            c[0] += a[0] + 12000000000000 - a[i];
        }
    }
    long long m = c[0];
    for (int i = 1; i < n; i++) {
        c[i] = c[i - 1];
        long long r = 0;
        if (a[i - 1] != a[i]) {
            r = a[i - 1] + 12000000000000 - a[i];
        }
        c[i] -= r;
        c[i] += (a[i] - a[i - 1]);
        if (c[i] < m) {
            m = c[i];
        }
    }
    cout << (m / 1000000000000) << " " << (m / 1000000 % 1000000) << " " << (m % 1000000);
    return 0;
}
