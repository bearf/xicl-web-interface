#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
#include <cstring>
#include <map>
#include <algorithm>
#include <ctime>

using namespace std;

typedef long long LL;

#define all(x) (x).begin(), (x).end()
#define INF 1E+9
#define INFll 1E+18

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int n;
	cin >> n;

	vector <LL> p(n);

	LL mx = 0, k = 0, tmpk = 0;

	for (int i = 0; i < n; ++i) {
		cin >> p[i];
		if (p[i] == mx)
			++k;
		if (p[i] > mx) {
			mx = max(mx, p[i]);
			k = 1;
		}
	}
	for (int i = 0; i < n; ++i)
		if (mx -1 == p[i])
			++tmpk;
	LL ans = INFll;
	if (k == 1) {
		for (int i = 0; i < n; ++i) {
			if (i && p[i] == mx && p[i-1] <= mx - 3) {
				ans = (mx - 1) * (tmpk + 1);
				break;
			}
			if (i != n - 1 && p[i] == mx && p[i+1] <= mx - 3) {
				ans = (mx - 1) * (tmpk + 1);
				break;
			}
		}
	}

	if (k >= 2) {
		for (int i = 0; i < n; ++i) {
			if (i && p[i] == mx && p[i - 1] > 0) {
				ans = mx + 1;
				break;
			}
			if (i != n - 1 && p[i] == mx && p[i + 1] > 0) {
				ans = mx + 1;
				break;
			}
		}

		for (int i = 0; i < n; ++i) {
			if (i && p[i] == mx && p[i - 1] <= mx - 2) {
				ans = min(ans, mx * (k - 1));
				break;
			}
			if (i != n - 1 && p[i] == mx && p[i + 1] <= mx - 2) {
				ans = min(ans, mx * (k - 1));
				break;
			}
		}
	}
	cout << min(ans, mx * k);

	return 0;
}