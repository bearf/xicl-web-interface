#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
struct point
{
    double x,y;
    point ()
    {
    }
    point (double t, double t1)
    {
        x = t;
        y = t1;
    }
    point operator * (double k)
    {
        return point (x * k, y * k);
    }
    point operator - (point k)
    {
        return point(x - k.x,y - k.y);
    }
    point operator + (point k)
    {
        return point(x + k.x,y + k.y);
    }
};

double dist (point a, point b)
{
    return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
}

point A,B;
point points[10100];
int n;
void read()
{
    int i;
    scanf("%lf%lf%lf%lf",&A.x,&A.y,&B.x,&B.y);
    scanf("%d",&n);
    for(i=1;i<=n;i++)
        scanf("%lf%lf",&points[i].x,&points[i].y);
}

double comp (double k)
{
    int i;
    double ans = 0;
    point now;
    now = B * k;
    for (i = 1; i <= n; i ++)
    {
        ans += dist (now, points[i]);
    }
    return ans;
}

void solve ()
{
    double l, r, mid1,mid2;
    double re1,re2;
    double eps=0.000001;
    l = -5000000.0;
    r = 5000000.0;
    while(r-l>eps)
    {
        mid1= l + (r - l)/3;
        mid2= l + 2 * (r - l)/3;
        re1=comp(mid1);
        re2=comp(mid2);
        if(re1<re2)
        {
            r=mid2;
        }
        else l=mid1;
    }
    printf ("%.5lf\n", sqrt (comp (l)));
    point now;
    now = B * l + A;
    printf ("%.5lf %.5lf", now.x, now.y);
}

int main()
{
    int i;
    read();
    for (i = 1; i <= n; i ++)
        points[i] = points[i] - A;
    B = B - A;
    solve();
}
