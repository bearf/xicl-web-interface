#include <cstdio>
#include <cstring>
#include <iostream>
#include <set>
#include <queue>
#include <cmath>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;

#define ll long long
#define ld long double
#define mp make_pair
#define pb push_back
#define forn(i, n) for(int i = 0; i < n; i++)

const int inf = 1 << 30;
const ld eps = 1e-9;
const int maxn = 2e5;
const long long l12 = 1e12;
const long long l6 = 1e6;


int main(){
    ll n, ma = 0, ma1, q, ans = 10000000001;
    cin >> n;
    vector<ll> a(n, 0);
    map<ll, ll> qq;
    forn(i, n){
      cin >> a[i];
      qq[a[i]]++;
      ma = max(a[i], ma);
    }
    ans = ma * qq[ma];
    forn(i, n){
        if(a[i] < 1)continue;
      if(i > 0){
        ll k1 = a[i - 1] + 1, k2 = a[i] - 1;
        qq[a[i]]--;
        qq[a[i - 1]] --;
        qq[k1]++; qq[k2]++;

        ma1 = max(k1, k2);
        if(qq[ma] > 0)ma1 = max(ma1, ma);
        ans = min(ans, qq[ma1] * ma1);
        qq[a[i]]++;
        qq[a[i - 1]] ++;
        qq[k1]--; qq[k2]--;
      }
      if(i < n - 1){
        ll k1 = a[i + 1] + 1, k2 = a[i] - 1;
        qq[a[i]]--;
        qq[a[i + 1]] --;
        qq[k1]++; qq[k2]++;
        ma1 = max(k1, k2);
        if(qq[ma] > 0)ma1 = max(ma1, ma);
        ans = min(ans, qq[ma1] * ma1);
        qq[a[i]]++;
        qq[a[i + 1]] ++;
        qq[k1]--; qq[k2]--;
      }
    }
    cout << ans;
	return 0;
}
