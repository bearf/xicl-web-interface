#include <iostream>
#define fin cin
#define fout cout
//�� ������ LL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

typedef long long ll;

const int nmax = 110000;

ll a[nmax];
ll ans, maxx, kol_of_max, kol_of_mm;
int n;


void read()
{
    fin >> n;
    for (int i = 0; i < n; i++)
        fin >> a[i];
}


void relax(int i, int j)
{
    //fout << i << ' ' << j << endl;
    if (a[i] == 0)
        return;
    if (a[j] == maxx)
    {
        ans = min(ans, a[j] + 1);
        //fout << ans << endl;
        return;
    }
    if (a[j] < maxx - 1)
    {
        //a[j] <= maxx - 2
        if (a[i] == maxx)
        {
            if (kol_of_max == 1)
            {
                if (a[j] == maxx - 2)
                    ans = min(ans, (kol_of_mm + 2) * (maxx - 1));
                else
                    ans = min(ans, (kol_of_mm + 1) * (maxx - 1));
            }
            else
                ans = min(ans, (kol_of_max - 1) * maxx);
        }
        else
        {
            //a[i] < maxx a[j] <= maxx - 2
        }
    }
    //a[i] < maxx a[j] < maxx - 1
    //fout << ans << endl;
}


void solve()
{
    maxx = 0;
    for (int i = 0; i < n; i++)
        maxx = max(maxx, a[i]);
    kol_of_max = 0;
    kol_of_mm = 0;
    for (int i = 0; i < n; i++)
    {
        if (a[i] == maxx)
            kol_of_max++;
        if (a[i] == maxx - 1)
            kol_of_mm++;
    }
    ans = kol_of_max * maxx;
    for (int i = 0; i < n; i++)
    {
        if (i > 0)
            relax(i, i - 1);
        if (i < n - 1)
            relax(i, i + 1);
    }
    fout << ans << endl;
}


int main()
{
    read();
    solve();
    return 0;
}
