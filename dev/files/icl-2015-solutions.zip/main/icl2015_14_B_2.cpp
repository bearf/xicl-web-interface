#include <bits/stdc++.h>

using namespace std;

const int maxn = 300;
const int mod = 1000000000 + 9;

int n, k;
int dp[maxn + 1][maxn + 1][maxn + 1];

int main()
{
#ifdef LOCAL
    freopen("b.in", "r", stdin);
#endif // LOCAL
    cin >> n >> k;
    memset(dp, 0, sizeof(dp));
    dp[0][0][0] = 1;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j <= i; ++j)
            for (int k = 0; k <= i; ++k)
            {
                dp[i + 1][max(j, k + 1)][k + 1] = (dp[i + 1][max(j, k + 1)][k + 1] + dp[i][j][k]) % mod;
                if (k > 0)
                    dp[i + 1][j][k - 1] = (dp[i + 1][j][k - 1] + dp[i][j][k]) % mod;
                dp[i + 1][j][k] = (dp[i + 1][j][k] + dp[i][j][k]) % mod;
            }
    cout << dp[n][k][0] << endl;
    return 0;
}
