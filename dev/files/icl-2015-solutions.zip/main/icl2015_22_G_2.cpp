#include <bits/stdc++.h>

using namespace std;

#ifdef FOOBAR
    ifstream fin("input.txt");
#define cin fin
#endif // FOOBAR

long long M = 1000000;
const int N = 200001;
long long a[N];

int main() {
    ios_base::sync_with_stdio(false);

    int n; cin >> n;

    for (int i=0; i<n; i++) {
        long long h, m, s; cin >> h >> m >> s;
        a[i] = h * M * M + m * M + s;
    }

    sort(a, a+n);
    long long s = 0;
    for (int i=0; i<n; i++) {
        a[n+i] = a[i] + 12 * M * M;
        s += a[n-1] - a[i];
    }

    long long ans = s;
    for (int i=0; i<n; i++) {
        s += (n-1)*(a[n+i]-a[n+i-1]) - (a[n+i-1] - a[i]);
        ans = min(ans, s);
    }

    long long sec = ans % M; ans /= M;
    long long m = ans % M; ans /= M;
    cout << ans << " " << m << " " << sec << endl;

    return 0;
}
