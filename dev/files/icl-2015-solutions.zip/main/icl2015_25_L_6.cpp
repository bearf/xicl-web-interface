#include <cstdio>
#include <iostream>
#include <algorithm>

using namespace std;


const int NMAX = 100001;

int n, ans = 9999999999, a[NMAX], mx, mx_ind, s1, s2;



int main()
{
	mx = -1;
	scanf("%d", &n);

	int max = -1, kol = 0;
	
	for(int i = 1; i <= n; i++)
	{
		scanf("%d", &a[i]);
		if (a[i] > max)
		{
			kol = 1;
			max = a[i];
		}
		else if (a[i] == max)
			kol++;
	}

	ans = kol * max;
	if (a[0] != 0)
	if (a[0] == max)
	{
		if (a[1] == max)
		{
			ans = min(ans,	max + 1);
		}
		else
			if (a[1] + 1 == max)
				ans = min((kol) * max, ans);
			else
				ans = min((kol - 1) * max, ans);
	}
	else
	{
		if (a[1] == max)
		{
			ans = min(ans,	max + 1);
		}
		else
			if (a[1] + 1 == max)
				ans = min((kol) * max, ans);
	}
	if (a[n - 1] != 0)
	{
		if (a[n - 1] == max)
	{
		if (a[n - 2] == max)
		{
			ans = min(ans,	max + 1);
		}
		else
			if (a[n - 2] + 1 == max)
				ans = min((kol) * max, ans);
			else
				ans = min((kol - 1) * max, ans);
	}
	else
	{
		if (a[n - 2] == max)
		{
			ans = min(ans,	max + 1);
		}
		else
			if (a[n - 2] + 1 == max)
				ans = min((kol) * max, ans);
	}
	
	}
	for (int i = 1; i < n - 1; i++)
	{
		if (a[i] != 0)
		{	if (a[i] == max)
			{
				if (a[i + 1] == max)
				{
					ans = min(ans,	max + 1);
				}
				else
					if (a[i + 1] + 1 == max)
						ans = min((kol) * max, ans);
				else
					ans = min((kol - 1) * max, ans);
			}
		else
			{
				if (a[i + 1] == max)
				{
					ans = min(ans,	max + 1);
				}
				else
					if (a[i + 1] + 1 == max)
						ans = min((kol) * max, ans);
			}
		if (a[i] == max)
			{
				if (a[i - 1] == max)
				{
					ans = min(ans,	max + 1);
				}
				else
					if (a[i - 1] + 1 == max)
						ans = min((kol) * max, ans);
				else
					ans = min((kol - 1) * max, ans);
			}
		else
			{
				if (a[i - 1] == max)
				{
					ans = min(ans,	max + 1);
				}
				else
					if (a[i - 1] + 1 == max)
						ans = min((kol) * max, ans);
			}
		}
	
	}
	printf("%d", ans);
}