#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const long long day = 12 * 1e12;
const long long lam = 1e6;

int main()
{
    //cout << day << endl;
    long long n, i,h, m, s, sum = 0, ans = 0;
    cin >> n;
    vector<long long> time(n);
    for (i = 0; i < n; i++)
    {
        cin >> h >> m >> s;
        time[i] = h * lam*lam + m * lam + s;
        //cout << time[i] << endl;
    }
    sum = 0;
    sort(time.begin(), time.end());

    for (i = 1; i < n; i++)
    {
        sum += time[0] + day - time[i];
    }
    ans = sum;
    //cout << sum << endl;
    for (i = 1; i < n; i++)
    {
        sum = sum - day + n*(time[i] - time[i - 1]);
        ans = min(ans , sum);
    }
    //cout << ans << endl;
    cout << ans / (lam * lam) << ' ';
    ans = ans % (lam * lam);
    cout << ans / lam << ' ';
    cout << ans % lam << endl;
    return 0;
}
