#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;
typedef long long ll;
#define mp make_pair

int get_beauty(ll n)
{
	/*if (dp[n] != -1)
		return dp[n];*/
	ll j = n;
	int res = 0;
	for (int i = 1; i <= n; i++)
	{
		while (i * j + (j * (j - 1)) / 2 > n) j--;
		if (i * j + (j * (j - 1)) / 2 == n) res++;
	}
	return res;
}

int get_beauty_print(ll n)
{
	/*if (dp[n] != -1)
		return dp[n];*/
	ll j = n;
	ll res = 0;
	for (int i = 1; i <= n; i++)
	{
		while (i * j + (j * (j - 1)) / 2 > n) j--;
		if (i * j + (j * (j - 1)) / 2 == n)
		{
			res++;
			printf(" (%d, %d) ", i, j);
		}
	}
	return res;
}

vector<int> factorize(int n)
{
	vector<int> res;
	for (ll i = 2; i * i <= n; i++)
	{
		int deg = 0;
		while (n % i == 0)
		{
			deg++;
			n /= i;
			res.push_back(i);
		}
	}
	if (n != 1)
		res.push_back(n);
	return res;
}

bool is_prime(int n)
{
	for (ll i = 2; i * i <= n; i++)
	{
		if (n % i == 0)
			return 0;
	}
	return 1;
}

vector<int> primes;

const int N = 1e5 + 100;

bool nonprime[N];

const ll M = 1e9 + 9;

ll binpow(ll n, int deg)
{
	if (deg == 0)
		return 1;
	if (deg % 2 == 0)
	{
		ll b = binpow(n, deg / 2);
		return (b * b) % M;
	}
	return (n * binpow(n, deg - 1)) % M;
}

int main()
{
#ifdef XXX
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	
	//memset(dp, 255, sizeof(dp));

	//cout << get_beauty(135135);
	//return 0;

	/*int beauty_query = 17;
	//cin >> beauty_query;
	//for (int beauty_query = 1; beauty_query < 11; beauty_query++)
	{
		for (int i = 1; true; i++)
		{
			//cout << i << ' ' << get_beauty(i) << endl;
			if (get_beauty(i) == beauty_query)
			{
				cout << i << endl;
				get_beauty_print(i);
				cout << endl << endl << endl;
				break;
			}
		}
	}

	vector<int> v = factorize(10395);

	*/
	
	for (ll i = 2; i < N; i++)
	{
		if (nonprime[i]) continue;
		for (int j = 2 * i; j < N; j += i)
			nonprime[j] = 1;
	}

	for (int i = 2; i < N; i++)
	{
		if (!nonprime[i])
			primes.push_back(i);
	}

	int n;
	cin >> n;
	if (n == 1)
	{
		cout << 1 << endl;
		return 0;
	}
	vector<int> v = factorize(n);
	reverse(v.begin(), v.end());

	bool is_deg2 = 1;
	for (int i = 0; i < v.size(); i++)
	{
		if (v[i] != 2)
			is_deg2 = 0;
	}

	if (is_deg2)
	{
		int step = 1;
		int p = 1;
		ll cur = 2;
		v.clear();
		v.push_back(1);
		while (cur != n)
		{
			if (step % 3 == 0)
				v[0] += (1 << p);
			else
				v.push_back(1);
			step++;
			cur *= 2;
		}

			ll ans = 1;
			int prime_index = 1;
	for (int i = 0; i < v.size(); i++)
	{
		ans *= binpow(primes[prime_index], v[i]);
		ans %= M;
		prime_index++;
	}

	cout << ans;
	return 0;
	}

	int prime_index = 1;

	ll ans = 1;

	for (int i = 0; i < v.size(); i++)
	{
		ans *= binpow(primes[prime_index], v[i] - 1);
		ans %= M;
		prime_index++;
	}

	cout << ans;

	return 0;
}