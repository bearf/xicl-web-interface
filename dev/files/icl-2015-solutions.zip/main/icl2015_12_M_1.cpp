#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <string>
using namespace std;

int n;

int gw, bb, another; 


void check(string s)
{
	int size = s.size();
	bool gold = false, white = false, blue = false, black = false;
	for(int i = 0; i <= size - 4; i++)
	{
		if(s.substr(i, 4) == "gold")
			gold = true;
	}
	for(int i = 0; i <= size - 5; i++)
	{
		if(s.substr(i, 5) == "white")
			white = true;
	}
	string t;
	for(int i = 0; i <= size - 4; i++)
	{
		t = s.substr(i, 4);
		if(t == "blue")
			blue = true;
	}
	for(int i = 0; i <= size - 5; i++)
	{
		if(s.substr(i, 5) == "black")
			black = true;
	}
	if(gold && white)
		gw++;
	else if(blue && black)
		bb++;
	else another++;
}

int main()
{
	//freopen("input.in", "r", stdin);
	//freopen("output.out", "w", stdout);
	cin >> n;
	getchar();
	for(int i = 0; i < n; i++)
	{
		char s[111];
		gets(s);
		check(s);
	}
	printf("%lf\n%lf\n%lf", ((1. * bb) / (1. * n)) * 100, ((1. * gw) / (1. * n)) * 100, ((1. * (n - (bb + gw))) / (1. * n)) * 100);
	return 0;
}