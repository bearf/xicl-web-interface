#include <string>
#include <cstring>
#include <iostream>
#include <fstream>
#include <deque>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <ctype.h>
#include <ctime>

#define _USE_MATH_DEFINES
#include <math.h>

#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define LL long long
#define mp make_pair
#define sqr(x) x*x

using namespace std;

void smain();

int main() {
#ifdef _DEBUG
	freopen("B.in", "r", stdin);
	freopen("B.out", "w", stdout);
#endif
	
	smain();

	return 0;
}

#define re return
#define int long long
#define MOD 1000000009
#define N 310

typedef struct{int d[N], k;}ta;


ta all[N];
void go(int h){
	if(all[h].k==1)re;

	for(int i = 1; i < h; ++i){
		go(h - i);

		int p=0;
		if(i == 1)p=1;

		for(int k = 0; k < h; ++k){
			all[h].d[k + p] = (all[h].d[k + p] + all[h - i].d[k])%MOD;
		}
	}

	for(int i = h - 1, cnt = 1; i >=3; --i, ++cnt)
	{
		int p = 0;
		if(i == h-1)p=1;
		for(int k = 0; k < h; ++k){
			all[h].d[k + p] = (all[h].d[k + p] + cnt * all[i].d[k])%MOD;
		}
	}

	all[h].k = 1;
}

void smain() {
	int n, k;
	cin>>n>>k;
	
	all[2].k = 1;
	all[2].d[0] = 1;

	all[3].k = 1;
	all[3].d[1] = 1;

	go(n);
	cout<<all[n].d[k];
}