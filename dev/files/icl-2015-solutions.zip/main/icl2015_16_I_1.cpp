//#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream cin("input.txt");
ofstream cout("output.txt");

long long pas[10005][1005];

long long f(long long m, long long pos, long long tec)
{
    long long ans = 0;
    for (long long i = pos; i < m; i++)
    {
        //cout << pas[tec][i + 1] << endl;
        ans += pas[tec][i + 1];
        if (ans < 0)
            ans = 1000000000000000000;
        tec++;
    }
    return ans;
}

int main()
{
    pas[0][0] = pas[1][1] = pas[1][0] = 1;

    for (long long i = 2; i < 10000; i++)
    {
        pas[i][0] = 1;
        for (long long j = 1; j < 1000 and j <= i; j++)
            {
                pas[i][j] = pas[i - 1][j] + pas[i - 1][j - 1];
                if (pas[i][j] < 0)
                    pas[i][j] = 1000000000000000000;
                //cout << pas[i][j];
            }
    }

    for (long long i = 0; i < 10000; i++)
        for (long long j = 0; j < 10000; j++)
        if(pas[i][j] < 0)
            i = i;//cout << "BOOOY";
    long long n, m;
    cin >> n >> m;
    vector <int> ans;
    for (long long i = 0; i < m; i++)
    {
        long long l = 0, r = 10000;
        while(r - l > 1)
        {
            long long mi = (r + l) / 2;
            //cout << mi << " " <<  f(m, i, mi) << endl;
            if (f(m, i, mi) <= n)
            {
                l = mi;
            }
            else
            {
                r = mi;
            }
        }
        n -= pas[l][i + 1];
        ans.push_back(l);
    }
    for (int i = ans.size() - 1; i >= 0; i--)
        cout << ans[i] << " ";
}
