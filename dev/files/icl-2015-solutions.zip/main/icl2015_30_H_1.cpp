#include <iostream>

using namespace std;

int main()
{
    long long n, s, f, ans = 0;
    cin >> n >> s  >> f;
    if (n == 2) {cout << 1; return 0;}
    if (s > f) swap(s, f);
    if (s != 1 && f != n && s + 1 == f) {cout << -1;return 0;}
    if (s > 1) {ans++; s = s + 1;}
    if (f < n) {ans++; f = f - 1;}
    ans += (f - s)/3 + (f - s)%3;
    cout << ans;

    return 0;
}
