#include <ios>
#include <string>
#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <vector>
#include <map>
#include <iomanip>
using namespace std;


long long rez = 0,n, s, f, a, b, c;

int main()
{
	#ifdef _DEBUG
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	#endif
	cin >> n >> s >> f;
	if(s == f)
	{
		cout << -1;
		return 0;
	}
	else if(s > f){
		swap(s, f);
	}
	a = s - 1;
	b = f - s - 1;
	c = n - f;
	//+
	if(a != 0 && b == 0 && c != 0)
		cout << -1;
	//+
	else if(a != 0 && b == 0 && c == 0)
		cout << 1;
	//+
	else if(a == 0 && b == 0 && c == 0)
		cout << 1;
	//+
	else if(a != 0 && b != 0 && c != 0)
	{
		rez += 2 + b/3 + 1;
		if(b % 3 == 1)
			rez -= 1;
		cout <<rez;
	}
	//+
	else if(b != 0 && a == 0 && c != 0)
	{
		b++;
		rez += 1 + b/3 + 1;
		if(b % 3 == 1)
			rez -= 1;
		cout << rez;
	}
	//+
	else if(b != 0 && c == 0 && a == 0)
	{
		b += 2;
		rez += b/3 + 1;
		if(b % 3 == 1)
			rez -= 1;
		cout << rez;
	}
	//+
	else if(a == 0 && b == 0 & c != 0)
		cout << 1;
	//+
	else if(a != 0 && b != 0 && c == 0)
	{
		b++;
		rez += 1 + b/3 + 1;
		if(b % 3 == 0)
			rez --;
		cout << rez;
	}
	else
		return 228;
	return 0;
}