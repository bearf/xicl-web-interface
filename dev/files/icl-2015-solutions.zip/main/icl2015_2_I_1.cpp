#include <string>
#include <cstring>
#include <iostream>
#include <fstream>
#include <deque>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <ctype.h>
#include <ctime>
#include <assert.h>

#define _USE_MATH_DEFINES
#include <math.h>

#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define LL long long
#define mp make_pair
#define sqr(x) x*x

using namespace std;

void smain();

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif
	
	smain();

	return 0;
}

#define int long long
#define N 2000
#define NMAX 1e17

int C[N][N];

double get_c(int n, int k){
	if(k > n) return 0;
	if(n < N && k < N) return C[n][k];
	if(k < 10) {
		double p = 1, q = 1;
		forn(i, k) p *= n - i, q *= i + 1;
		double res = p / q;
		return res;
	}
	if(n >= N) return NMAX + 1;
	assert(false);
}


int f(int n, int m, vector<int> &st) {
	if(m == 0) return n == 0 ? 0 : -1;
	int l = m, r = 300000000;
	while(l < r) {
		int mid = (l + r) / 2;
		double cc = get_c(mid, m);
		if(cc > n) r = mid;
		else l = mid + 1;
	}
	
	double cc = get_c(l, m);
	if(cc > n) l -= 1;
	for(; l > m; --l) {
		cc = get_c(l, m);
		int r = f(n - cc, m - 1, st);
		if(r >= 0){
			st.push_back(r);
			return l;
		}
	}
	return -1;
}

int calc(int m, vector<int> &r) {
	int res = 0;
	for(int i = m, j = 0; i > 0; --i, ++j){
		res += get_c(r[j], i);
	}
	return res;
}


void smain() {
	forn(i, N) C[i][0] = 1;
	for(int i=1; i <= N; ++i) for(int j=1; j <= N; ++j){
		C[i][j] = C[i-1][j-1] + C[i-1][j];
		if(C[i][j] < 0) C[i][j] = NMAX;
	}
	
	int n, m;
	vector<int> st(0);
	for(; cin >> n >> m; ){
		if(!st.empty()) st.clear();
		int r = f(n, m, st);
		assert(r >= 0);
		st.push_back(r);
		reverse(st.begin(), st.end());
		st.resize(st.size() - 1);
		for(auto i : st) cout << i << ' ';
		cout << endl;
	}
}