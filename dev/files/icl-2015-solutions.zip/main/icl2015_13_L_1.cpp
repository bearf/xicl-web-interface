# include <cstdio>
# include <algorithm>
# include <iostream>

using namespace std;

int n;

long long  used[100100];

long long max1, cnt1;

int max2, cnt2;

int p[100100];

long long ans = 1000000000000000LL;

int main ()
{
    int i;
    scanf ("%d", &n);
    for (i = 1; i <= n; i ++)
    {
        scanf ("%d", &p[i]);
        used[p[i]] ++;
    }
    for (i = 100000; i >= 0; i --)
        if (used[i])
            break;
    max1 = i; cnt1 = used[i];
    for (i = max1 - 1; i >= 0; i --)
        if (used[i])
            break;
    max2 = i; cnt2 = used[i];
    ans = max1 * cnt1;
    ///cout << max1 << " " << max2 << endl;
    for (i = 2; i <= n; i ++)
    {

        if (p[i] == 0)
            continue;
        used[p[i]] --;
        used[p[i] - 1] ++;
        used[p[i - 1]] --;
        used[p[i - 1] + 1] ++;
        if (used[max1 + 1] > 0 && max1 + 1 >= 0)
        {
            ans = min (ans, used[max1 + 1] * max1 + 1);
                    used[p[i]] ++;
        used[p[i] - 1] --;
        used[p[i - 1]] ++;
        used[p[i - 1] + 1] --;
            continue;
        }
        if (used[max1] > 0 && max1 >= 0)
        {
            ans = min (ans, used[max1] * max1);
                    used[p[i]] ++;
        used[p[i] - 1] --;
        used[p[i - 1]] ++;
        used[p[i - 1] + 1] --;
            continue;
        }
        if (used[max1 - 1] > 0&& max1 - 1 >= 0)
        {
            ans = min (ans, used[max1 - 1] * (max1 - 1));
                    used[p[i]] ++;
        used[p[i] - 1] --;
        used[p[i - 1]] ++;
        used[p[i - 1] + 1] --;
            continue;
        }
        if (used[max2] > 0 && max2 >= 0)
        {
            ans = min (ans, used[max2] * max2);
                    used[p[i]] ++;
        used[p[i] - 1] --;
        used[p[i - 1]] ++;
        used[p[i - 1] + 1] --;
            continue;
        }
                            used[p[i]] ++;
        used[p[i] - 1] --;
        used[p[i - 1]] ++;
        used[p[i - 1] + 1] --;

    }
    for (i = 1; i < n; i ++)
    {
        if (p[i] == 0)
            continue;

        used[p[i]] --;
        used[p[i] - 1] ++;
        used[p[i + 1]] --;
        used[p[i + 1] + 1] ++;
        if (used[max1 + 1] > 0 && max1 + 1 >= 0)
        {
            ans = min (ans, used[max1 + 1] * max1 + 1);
                used[p[i]] ++;
        used[p[i] - 1] --;
        used[p[i + 1]] ++;
        used[p[i + 1] + 1] --;
            continue;
        }
        if (used[max1] > 0 && max1 >= 0)
        {
            ans = min (ans, used[max1] * max1);
                used[p[i]] ++;
        used[p[i] - 1] --;
        used[p[i + 1]] ++;
        used[p[i + 1] + 1] --;
            continue;
        }
        if (used[max1 - 1] > 0 && max1 - 1 >= 0)
        {
            ans = min (ans, used[max1 - 1] * (max1 - 1));
                used[p[i]] ++;
        used[p[i] - 1] --;
        used[p[i + 1]] ++;
        used[p[i + 1] + 1] --;
            continue;
        }
        if (used[max2] > 0&& max2 >= 0)
        {
            ans = min (ans, used[max2] * max2);
                used[p[i]] ++;
        used[p[i] - 1] --;
        used[p[i + 1]] ++;
        used[p[i + 1] + 1] --;
            continue;
        }
            used[p[i]] ++;
        used[p[i] - 1] --;
        used[p[i + 1]] ++;
        used[p[i + 1] + 1] --;

    }
    printf ("%lld\n", ans);
    return 0;
}
