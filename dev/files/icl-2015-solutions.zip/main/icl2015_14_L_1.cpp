#include <bits/stdc++.h>

using namespace std;

map <int, int> m;
int b[1000001];

int main()
{
#ifdef LOCAL
    freopen("l.in", "r", stdin);
#endif // LOCAL
    int n;
    cin >> n;
    for (int i = 0; i < n; ++i)
    {
        int a;
        scanf("%d", &a);
        m[a]++;
        b[i] = a;
    }
    long long res = (long long) m.rbegin()->first * (long long) m.rbegin()->second;
    for (int i = 0; i < n; ++i)
    {
        if (b[i] == 0)
            continue;
        m[b[i]]--;
        m[b[i] - 1]++;
        if (i > 0)
        {
            m[b[i - 1]]--;
            m[b[i - 1] + 1]++;
            while (m.rbegin()->second == 0)
            {
                auto it = m.end();
                --it;
                m.erase(it);
            }
            res = min(res, (long long) m.rbegin()->first * (long long) m.rbegin()->second);
            m[b[i - 1] + 1]--;
            m[b[i - 1]]++;
        }
        if (i + 1 < n)
        {
            m[b[i + 1]]--;
            m[b[i + 1] + 1]++;
            while (m.rbegin()->second == 0)
            {
                auto it = m.end();
                --it;
                m.erase(it);
            }
            res = min(res, (long long) m.rbegin()->first * (long long) m.rbegin()->second);
            m[b[i + 1] + 1]--;
            m[b[i + 1]]++;
        }
        m[b[i]]++;
        m[b[i] - 1]--;
    }
    cout << res << endl;
}
