#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
#include <cstring>
#include <map>
#include <algorithm>
#include <ctime>

using namespace std;

typedef long long LL;

#define all(x) (x).begin(), (x).end()
#define INF 1E+9
#define INFll 1E+18

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int n;

	cin >>n;

	vector <LL> a;
	map <LL, int> tmp;
	for (int i = 0; i < n; ++i) {
		LL h, b, c;
		cin >> h >> b >> c;
		if (tmp.find(c + b * 1000000 + h * 1000000 * 1000000) == tmp.end()) {
			a.push_back(c + b * 1000000 + h * 1000000 * 1000000);
		}
		tmp[c + b * 1000000 + h * 1000000 * 1000000]++;
	}

	sort(all(a));

	LL cur = 0, ans = INFll;
	const LL full = 12ll * 1E+6 * 1E+6;

	for (int i = 1; i < a.size(); ++i) {
		cur += (full - a[i] + a[0]) * tmp[a[i]];
	}

	ans = cur;

	for (int i = 1; i < a.size(); ++i) {
		cur -= (full - a[i] + a[i - 1]) * tmp[i];
		cur += (n - tmp[a[i]]) * (a[i] - a[i - 1]);
		ans = min(ans, cur);
	}

	cout << ans / (LL)1E+12 << ' ' << ans / (LL)(1E+6) % (LL)(1E+6) << ' ' << ans % (LL)1E+6;

	return 0;
}