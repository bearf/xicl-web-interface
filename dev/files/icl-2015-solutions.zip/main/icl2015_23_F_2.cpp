#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <deque>
#include <queue>
#include <complex>

using namespace std;

#define pb push_back
#define mp make_pair
#define pbk pop_back
#define fs first
#define sc second
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define all(x) (x).begin(), (x).end()
#define next _next
#define prev _prev
#define link _link
#define hash _hash
#define rank _rank
#ifdef LOCAL42
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif
#if _WIN32 || __WIN32__ || _WIN64 | __WIN64__
#define LLD "%I64d"
#else
#define LLD "%lld"
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));

inline bool isPrime(int n) {
	for (int i = 2; i * i <= n; i++) {
		if (n % i == 0) {
			return false;
		}
	}
	return true;
}

const int M = 1e9 + 9;

inline int power(int a, int b) {
	if (b == 0)
		return 1;
	int res = power(a, b / 2);
	res = (1ll * res * res) % M;
	if (b & 1) {
		res = (1ll * res * a) % M;
	}
	return res;
}

vector<int> primes;

ld ans = 1e200;
vector<int> vans, curAns;

inline void backtrack(int x, int n, ld cur) {
	if (cur > ans) {
		return ;
	}
	if (n == 1) {
		if (ans > cur) {
			ans = cur;
			vans = curAns;
		}
		return ;
	}
	for (int i = 2; i * i <= n; i++) {
		if (i > curAns.back()) {
			continue;
		}
		if (n % i != 0) {
			continue;
		}
		curAns.pb(i);
		backtrack(x + 1, n / i, cur + log(primes[x]) * (i - 1));
		curAns.pop_back();
		curAns.pb(n / i);
		backtrack(x + 1, i, cur + log(primes[x]) * (n / i - 1));
		curAns.pop_back();
	}
	curAns.pb(n);
	backtrack(x + 1, 1, cur + log(primes[x]) * (n - 1));
	curAns.pop_back();
}

inline int f(int n) {
	int k = 0;
	for (int i = 1; i * i <= n; i++) {
		if (n % i == 0) {
			k += 2;
		}
	}
	primes.clear();
	for (int i = 3; len(primes) < k; i++) {
		if (isPrime(i)) {
			primes.pb(i);
		}
	}
	ans = 1e200;
	sort(all(primes));	
	backtrack(0, n, 0);
	int res = 1;
	for (int i = 1; i < len(vans); i++) {
		res = (1ll * res * power(primes[i - 1], vans[i] - 1)) % M;
	}
	return res;
}

inline int count(int n) {
	int ans = 0;
	for (int i = 1; i <= n; i++) {
		int cur = 0;
		for (int j = i; j <= n; j++) {
			cur += j;
			if (cur == n) {
				ans++;
				break;
			}
		}
	}
	return ans;
}

inline int stupid(int n) {
	for (int i = 1;; i++) {
		if (count(i) == n) {
			return i;
		}
	}
	assert(false);
}

inline void checkStupid() {
	int cc = 0;
	for (int i = 1;; i++) {
		if (++cc % 1000 == 0) {
			eprintf("%d: ans = %d\n", i, f(i));
		}
	}
}

int main() {
#ifdef LOCAL42
#define TASK "F"
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
#endif
	curAns.pb(inf);
	//checkStupid();
	int n; cin >> n;
	cout << f(n) << endl;
	return 0;
}