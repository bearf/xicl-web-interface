#include <bits/stdc++.h>

using namespace std;

#ifdef FOOBAR
    ifstream fin("input.txt");
#define cin fin
#endif // FOOBAR

int n, s, f;

int main() {
    ios_base::sync_with_stdio(false);

    cin >> n >> s >> f;

    if (s > f) {
        int k = s;
        s = f;
        f = k;
    }

    if (s > 1 && f < n && (f - s) == 1) {
        cout << -1;
        return 0;
    }

    int res = 0;

    if (s + 1 == f) {
        cout << 1;
        return 0;
    }

    res += (f - s);

    cout << res;

    return 0;
}
