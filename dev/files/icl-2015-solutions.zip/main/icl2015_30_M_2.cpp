#include <iostream>
#include <string>

using namespace std;

int main(){
    int n, cnt1 = 0, cnt2 = 0, cnt3 = 0, a = 0, b = 0, c = 0, d = 0;
    cin >> n;
    string x;
    getline(cin, x);
    string a1 = "blue", b1 = "black", c1 = "white", d1 = "gold";
    for (int i = 0; i < n; i++){
        getline(cin, x);
        if (x.find("blue") < x.size() && x.find("black") < x.size()) cnt1++;
        else if (x.find("white") < x.size() && x.find("gold") < x.size()) cnt2++;
        else cnt3++;
    }
    cout.precision(10);
    cout << 100 * cnt1 / double(n) << endl;
    cout << 100 * cnt2 / double(n) << endl;
    cout << 100 * cnt3 / double(n) << endl;
    return 0;
}
