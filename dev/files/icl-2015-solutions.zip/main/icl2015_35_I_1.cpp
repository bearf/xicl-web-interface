#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>

using namespace std;
typedef long long ll;
#define mp make_pair

const int N = 2000;
ll comb_dp[N][N];

ll C(int n, int k)
{
	if (k > n) return 0;
	if (n == k) return 1;
	if (k == 0) return 1;
	if (comb_dp[n][k] != -1)
		return comb_dp[n][k];
	return comb_dp[n][k] = C(n - 1, k) + C(n - 1, k - 1);
}

vector<int> ans;

bool f(ll n, int m, int mx)
{
	if (n == 0 && m == 0) return 1;
	if (n < 0) return 0;
	for (int i = mx - 1; i >= 0; i--)
	{
		if (f(n - C(i, m), m - 1, i))
		{
			ans.push_back(i);
			return 1;
		}
	}
	return 0;
}

void solveI()
{
	int n, m;
	cin >> n >> m;
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
			comb_dp[i][j] = -1;
	}
	f(n, m, 30);
	reverse(ans.begin(), ans.end());
	for (int i = 0; i < ans.size(); i++)
		cout << ans[i] << ' ';
}

int main()
{
#ifdef XXX
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	
	memset(comb_dp, 255, sizeof(comb_dp));
	ll n, m;
	cin >> n >> m;

	for (; m > 0; --m)
	{
		int i = 0;
		while (C(i, m) <= n)
		{
			++i;
		}
		--i;
		cout << i << " ";
		n -= C(i, m);
	}

	/*ll sum = 0;
	for (int q = 999; q > 0; q--)
	{
		int r;
		cin >> r;
		sum += C(r, q);
	}

	cout << sum;*/

	return 0;
}