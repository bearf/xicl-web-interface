#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
int n;
int a[100001];
int maxel = 0;
int cnt = 1;
long long bestres;
long long res = 0;

long long foo(){
    maxel = 0;
    for(int i = 0; i < n; i ++){
        if(a[i] > maxel){
            maxel = a[i];
            cnt = 1;
        }else if(a[i] == maxel){
            cnt ++;
        }
    }
    return maxel * cnt;
}

int main(){

    cin >> n;
    for(int i = 0; i < n; i ++){
        cin   >> a[i];
        if(a[i] > maxel){
            maxel = a[i];
            cnt = 1;
        }else if(a[i] == maxel){
            cnt ++;
        }
    }
    bestres = maxel * cnt;
    if (maxel == 0){
        cout  << bestres << endl;
        return 0;
    }else{
        for(int i = 0; i < n; i ++){
            if(a[i] == maxel){
                if(i > 0){
                    a[i]--;
                    a[i-1]++;
                    res = foo();
                    if(res < bestres){
                        bestres = res;
                    }
                    a[i]++;
                    a[i-1]--;
                }
                if(i < n - 1){
                    a[i]--;
                    a[i+1]++;
                    res = foo();
                    if(res < bestres){
                        bestres = res;
                    }
                    a[i]++;
                    a[i+1]--;
                }
            }
        }
    }
    cout   << bestres   << endl;

    return 0;
}
