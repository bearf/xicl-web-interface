#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <deque>
#include <queue>
#include <complex>

using namespace std;

#define pb push_back
#define mp make_pair
#define pbk pop_back
#define fs first
#define sc second
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define all(x) (x).begin(), (x).end()
#define next _next
#define prev _prev
#define link _link
#define hash _hash
#define rank _rank
#ifdef LOCAL42
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif
#if _WIN32 || __WIN32__ || _WIN64 | __WIN64__
#define LLD "%I64d"
#else
#define LLD "%lld"
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const int inf = int(1e9);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));
const int N = int(1e5) + 100;

int k = 0, step = 0, lev = 0, all;
int first[N], lst[N], used[N], prev[N], sz[N];
vector<pii> d[N], fen[N], levs[N];
int go[2 * N], cnt[2 * N], next[2 * N];

inline void add(int a, int b, int c) {
	go[++k] = b;
	cnt[k] = c;
	next[k] = first[a];
	first[a] = k;
}

void dfs1(int v) {
	lst[all++] = v;
	used[v] = step;
	sz[v] = 1;
	for (int i = first[v]; i > 0; i = next[i]) {
		if (used[go[i]] != step) {
			prev[go[i]] = v;
			dfs1(go[i]);
			sz[v] += sz[go[i]];
		}
	}
}

inline int get_sz(int v) {
	int max_sz = all - sz[v];
	for (int i = first[v]; i > 0; i = next[i]) {
		if (prev[go[i]] == v) {
			max_sz = max(max_sz, sz[go[i]]);
		}
	}
	return max_sz;
}

void dfs2(int v, int dist) {
	used[v] = step;
	d[lev].pb(mp(dist, v));
	for (int i = first[v]; i > 0; i = next[i]) {
		if (used[go[i]] != step) {
			dfs2(go[i], dist + cnt[i]);
		}
	}
}

void build(int v) {
	++step;
	all = 0;
	prev[v] = -1;
	dfs1(v);
	int root = lst[0], max_sz = get_sz(lst[0]);
	for (int i = 1; i < all; ++i) {
		int cur_sz = get_sz(lst[i]);
		if (cur_sz < max_sz) {
			root = lst[i];
			max_sz = cur_sz;
		}
	}
	++step;
	dfs2(root, 0);
	sort(all(d[lev]));
	reverse(all(d[lev]));
	for (int i = 0; i < sz(d[lev]); ++i) {
		levs[d[lev][i].sc].pb(mp(lev, i));
	}
	fen[lev].assign(sz(d[lev]), mp(0, 0));
	++lev;
	for (int i = first[root]; i > 0; i = next[i]) {
		int last = -1, u = go[i];
		for (int j = first[u]; j > 0; j = next[j]) {
			if (go[j] == root) {
				if (last == -1) {
					first[u] = next[j];
				} else {
					next[last] = next[j];
				}
				break;
			}
			last = j;
		}
	}
	for (int i = first[root]; i > 0; i = next[i]) {
		build(go[i]);
	}
}

inline pii get(vector<pii>& fen, int pos) {
	pii res(0, 0);
	while (pos >= 0) {
		res = max(res, fen[pos]);
		pos = (pos & (pos + 1)) - 1;
	}
	return res;
}

inline void update(vector<pii>& fen, int pos, pii val) {
	while (pos < sz(fen)) {
		fen[pos] = max(fen[pos], val);
		pos = (pos | (pos + 1));
	}
}

inline void color(int lev, int dist, int t, int c) {
	if (dist < 0) {
		return;
	}
	int pos = -1, l = 0, r = sz(d[lev]) - 1;
	while (l <= r) {
		int mid = (l + r) / 2;
		if (d[lev][mid].fs <= dist) {
			pos = mid;
			r = mid - 1;
		} else {
			l = mid + 1;
		}
	}
	assert(pos != -1);
	update(fen[lev], pos, mp(t, c));
}

int main() {
#ifdef LOCAL42
#define TASK "D"
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
#endif
	int n;
	cin >> n;
	for (int i = 0; i < n - 1; ++i) {
		int a, b, c;
		scanf("%d %d %d", &a, &b, &c);
		--a;
		--b;
		add(a, b, c);
		add(b, a, c);
	}
	build(0);
	int q;
	cin >> q;
	for (int i = 1; i <= q; ++i) {
		int t;
		scanf("%d", &t);
		if (t == 1) {
			int v, dist, c;
			scanf("%d %d %d", &v, &dist, &c);
			--v;
			for (int j = 0; j < sz(levs[v]); ++j) {
				color(levs[v][j].fs, dist - d[levs[v][j].fs][levs[v][j].sc].fs, i, c);
			}
			continue;
		}
		assert(t == 2);
		int v;
		scanf("%d", &v);
		--v;
		pii cur(0, 0);
		for (int j = 0; j < sz(levs[v]); ++j) {
			cur = max(cur, get(fen[levs[v][j].fs], levs[v][j].sc));
		}
		printf("%d\n", cur.sc);
	}
	return 0;
}