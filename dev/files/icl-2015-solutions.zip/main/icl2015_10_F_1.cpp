#define _USE_MATH_DEFINES

#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <bitset>
#include <cassert>
#include <iomanip>
#include <cmath>

using namespace std;

#define pb push_back
#define mp make_pair
#define sz(a) int(a.size())
#define forn(i,n) for (int i = 0; i < int(n); ++i)
#define all(a) a.begin(),a.end()

typedef pair<int,int> pt;
#define ft first
#define sc second

typedef unsigned long long li;
typedef long double ld;

const ld EPS = 1e-9;
const int INF = 1e9;

int n;

bool read() {
	if (!(cin >> n))
		return false;
	return true;
}

const int N = 100 * 1000 + 5;
const int P = 17;
int primes[N], pcnt;

const int BASE = 1e6;

struct bigint {
	vector <li> d; 

	bigint() {
		d.resize(0, 1);
	}

	bigint(li _d) {
		d.resize(_d, 1);
		normalize();
	}

	void normalize() {
		li rem = 0;
		forn(i, sz(d)) {
			li c = d[i] + rem;
			d[i] =( (c % BASE) + BASE) % BASE;
			rem = (c - d[i]) / BASE;
			if (rem && i == sz(d) - 1)
				d.pb(0);
		}

		while (sz(d) > 1 || d.back() == 0)
			d.pop_back();
	}

	int modulo(int mod) {
		
	}
};

bigint operator * (const bigint& a, const bigint& b) {
	bigint c;
	c.d.resize(sz(a.d) + sz(b.d) + 1);

	forn(i, sz(a.d))
		forn(j, sz(b.d))
			c.d[i + j] += a.d[i] * b.d[j];

	c.normalize();
	return c;
}

bigint operator < (const bigint& a, const bigint& b) {
	if (sz(a.d) != sz(b.d))
		return sz(a.d) < sz(b.d);

	for (int i = sz(a.d) - 1; i >= 0; --i)
		if (a.d[i] != b.d[i])
			return a.d[i] < b.d[i];

	return false;
}

ld dp[18][N], pw[18][N];
int ans[18][N], pwm[18][N];
bool used[18][N];
const int MOD = 1e9 + 9;

bool is_prime(int n) {
	for (int i = 2; i * i <= n; ++ i)
		if (n %i == 0)
			return false;
	return true;
}

void solve() {
	li m = 1;
	pcnt = 0;
	for (int i = 3; pcnt < P; ++i)
		if (is_prime(i)) {
			primes[pcnt++] = i;
			m *= i;
		}

	forn(i, P) {
		pwm[i][0] = pw[i][0] = 1;
		forn(j, N - 1) {
			pw[i][j + 1] = pw[i][j] * primes[i];
			pwm[i][j + 1] = (li(primes[i]) * pwm[i][j]) % MOD;
		}
	}

	dp[0][n] = 1;
	ans[0][n] = 1;
	used[0][n] = true;

	forn(i, P) {
		forn(j, n + 1) {
			if (j == 0 || n % j) continue;
			if (!used[i][j]) continue;

			int k = 1;
			for (k = 1; k * k <= j; ++k) {
				if (j % k == 0) {
					forn(t, 2) {
						if (!used[i + 1][j / k] || 
							dp[i + 1][j / k] > dp[i][j] * pw[i][k - 1]) {

							dp[i + 1][j / k] = dp[i][j] * pw[i][k - 1];
							ans[i + 1][j / k] = (li(pwm[i][k - 1]) * ans[i][j]) % MOD;
						}

						used[i + 1][j / k] = true;
						k = j / k;
					}
				}
			}
		}
	}
	cout << ans[P][1] << endl;
}

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif

	while (read()) {
		solve();
	}

	cerr << clock() * 1000 / CLOCKS_PER_SEC << endl;
	return 0;
}