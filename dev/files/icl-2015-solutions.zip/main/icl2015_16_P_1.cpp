#include <iostream>
#include <fstream>

using namespace std;

//ifstream cin("input.txt");
//ofstream cout("output.txt");

int main()
{
    long long p, q;
    cin >> p >> q;
    long long ans = 0;
    while(p >= q)
    {
        ans++;
        p -= q;
    }
    cout << ans << " ";
    long long i = 1;
    while(p != 0)
    {
        i++;
        long long l = 0, r = i;
        p = p * i;
        while (r - l > 1)
        {
            long long m = (r + l) / 2;
            if (p - m * q >= 0)
                l = m;
            else
                r = m;
        }
        p -= l * q;
        cout << l << " ";
    }
}
		