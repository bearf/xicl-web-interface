#define _CRT_SECURE_NO_WARNINGS
#include <ios>
#include <string>
#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <vector>
#include <map>
#include <iomanip>
using namespace std;

int n, fir, sec, thi, j;
char s[300];


int main()
{
	#ifdef _DEBUG
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	#endif

	cin>>n;
	gets(s);
	for(int i = 0; i < n; i++)
	{
		gets(s);
		for (j = 0; s[j] != '\0'; j++){}
		int size = j;
		bool p1=false,p2=false,p3=false,p4=false;
		for(int j=0; j < size;j++)
		{
			if(s[j]=='b')
			{
				if(j + 1 < size && s[j+1]=='l')
				{
					if(j + 2 < size && s[j+2]=='u')
					{
						if(j + 3 < size && s[j+3]=='e')
						{
							p1=true;
						}
					}else
					{
						if(j + 2 < size && s[j+2]=='a')
							if(j + 3 < size && s[j+3]=='c')
								if(j + 4 < size && s[j+4]=='k'){p2=true;}
					}
				}
			}
			if(j + 4 < size && s[j]=='w' && s[j+1]=='h' && s[j+2]=='i' && s[j+3]=='t' && s[j+4]=='e'){p3=true;}
			if(j + 3 < size && s[j]=='g' && s[j+1]=='o' && s[j+2]=='l' && s[j+3]=='d'){p4=true;}
			if(p1==true && p2==true){fir++; break;}
			if(p3==true && p4==true){sec++; break;}
		}
	}
	printf("%.7lf\n%.7lf\n%.7lf", ((fir * 1.0) / n) * 100, ((sec * 1.0) / n) * 100, (((n - fir - sec) * 1.0) / n) * 100);
	/*cout<<fixed<<setprecision(7)<<((fir*1.0)/n)*100<<endl;
	cout<<fixed<<setprecision(7)<<((sec*1.0)/n)*100<<endl;
	cout<<fixed<<setprecision(7)<<(((n-sec-fir)*1.0)/n)*100<<endl;*/
}