#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>

using namespace std;

//ifstream cin("input.txt");
//ofstream cout("output.txt");

int main()
{
    double n, cnt1 = 0, cnt2 = 0, cnt3 = 0;
    cin >> n;
    string tmp;
    getline(cin, tmp);
    for (int i = 0; i < n; i++)
    {
        string s;
        int f1 = 0, f2 = 0, f3 = 0, f4 = 0;
        getline(cin, s);
        if(s.size() <= 4)
        {
            cnt3++;
            continue;
        }
        for (int j = 0; j < s.size() - 4; j++)
        {
            if(s[j] == 'b' && s[j + 1] == 'l' && s[j + 2] == 'a' && s[j + 3] == 'c' && s[j + 4] == 'k')
                f1++;
            if(s[j] == 'w' && s[j + 1] == 'h' && s[j + 2] == 'i' && s[j + 3] == 't' && s[j + 4] == 'e')
                f2++;
        }
        for (int j = 0; j < s.size() - 3; j++)
        {
            if(s[j] == 'g' && s[j + 1] == 'o' && s[j + 2] == 'l' && s[j + 3] == 'd')
                f4++;
            if(s[j] == 'b' && s[j + 1] == 'l' && s[j + 2] == 'u' && s[j + 3] == 'e')
                f3++;
        }

        if(f1 >= 1 && f3 >= 1)
            cnt1++;
        else
            if(f2 >= 1 && f4 >= 1)
                cnt2++;
            else
                cnt3++;
    }

    cout << fixed << setprecision(20);
    cout << cnt1 / (cnt1 + cnt2 + cnt3) * 100 << endl << cnt2 / (cnt1 + cnt2 + cnt3) * 100 << endl << cnt3 / (cnt1 + cnt2 + cnt3) * 100;
}
/*
4
this dress is blue and black
this dress is goldblackblue
eto plate khwegvbfv irgugi
uidghfuoqwb
*/
