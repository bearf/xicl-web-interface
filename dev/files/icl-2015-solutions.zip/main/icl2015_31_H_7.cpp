#include <iostream>
#include <cassert>
#define fin cin
#define fout cout

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

int n, s, f, ii;


int go(int s, int f)
{
    ii = s;
    int res = 0;
    while (ii + 2 < f)
    {
        ii += 2;
        ii--;
        ii += 2;
        res++;
    }
    //fout << "I " << ii << ' ' << f << endl;
    res += f - ii;
    //fuck
    return res;
}


int solve(int n, int s, int f)
{
    if (s == f)
    {
        if (n == 1)
            return 0;
        //return -1;
        return 2;
    }
    if (s > f)
    {
        f = n - f + 1;
        s = n - s + 1;
    }
    assert(f >= s);
    if (s == f - 1)
    {
        if ((s == 1) || (f == n))
            return 1;
        if (f == n - 1)
            return 1;
        //return -1;
        return 3;
    }



    int ans = 0;
    int i = s;
    if (s > 1)
    {
        ans++;
        i++;
    }
    if (f == n)
        ans += go(i, f);
    else
        ans += go(i, f - 1) + 1;
    return ans;
}

int main()
{
    fin >> n >> s >> f;
    fout << solve(n, s, f) << endl;
    return 0;
}
