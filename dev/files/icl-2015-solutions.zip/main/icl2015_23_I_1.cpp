#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <deque>
#include <queue>
#include <complex>

using namespace std;

#define pb push_back
#define mp make_pair
#define pbk pop_back
#define fs first
#define sc second
#define sz(s) int((s).size())
#define len(s) int((s).size())
#define all(x) (x).begin(), (x).end()
#define next _next
#define prev _prev
#define link _link
#define hash _hash
#define rank _rank
#ifdef LOCAL42
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) 42
#endif
#if _WIN32 || __WIN32__ || _WIN64 | __WIN64__
#define LLD "%I64d"
#else
#define LLD "%lld"
#endif

typedef long long ll;
typedef long long llong;
typedef long long int64;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef unsigned long long ullong;
typedef unsigned long long lint;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long double ld;

const ll inf = ll(1e16);
const double eps = 1e-9;
const double pi = 4 * atan(double(1));

vector<ll> ans;

inline ll gcd(ll a, ll b) {
	while (b > 0) {
		a %= b;
		swap(a, b);
	}
	return a;
}

inline ll cnk(ll n, int k, ll need) {
	if (n < k) {
		return 0;
	}
	if (n - k < k) {
		k = n - k;
	}
	ll res = 1;
	for (int i = 1; i <= k; ++i) {
		ll x = n - i + 1;
		ll y = i;
		ll g = gcd(x, y);
		x /= g;
		y /= g;
		res /= y;
		if (res > need / x) {
			return need + 10;
		}
		res *= x;
	}
	return res;
}

int main() {
#ifdef LOCAL42
#define TASK "I"
	freopen(TASK ".in", "r", stdin);
	freopen(TASK ".out", "w", stdout);
#endif
	ll n;
	int m;
	cin >> n >> m;
	ll prev = inf;
	for (int i = m; i > 0; --i) {
		ll res = -1, val, l = 0, r = prev;
		while (l <= r) {
			ll mid = (l + r) / 2;
			ll cur = cnk(mid, i, n);
			if (cur <= n) {
				res = mid;
				val = cur;
				l = mid + 1;
			} else {
				r = mid - 1;
			}
		}
		assert(res != -1);
		prev = res - 1;
		n -= val;
		ans.pb(res);
	}
	assert(n == 0);
	for (int i = 0; i < sz(ans); ++i) {
		cout << ans[i] << " ";
	}
	cout << endl;
	return 0;
}