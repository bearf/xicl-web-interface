#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

//ifstream cin("input.txt");
//ofstream cout("output.txt");

long long pas[20005][1005];

int main()
{
    pas[0][0] = pas[1][1] = pas[1][0] = 1;

    for (long long i = 2; i < 20005; i++)
    {
        pas[i][0] = 1;
        for (long long j = 1; j < 1005 and j <= i; j++)
            {
                pas[i][j] = pas[i - 1][j] + pas[i - 1][j - 1];
                if (pas[i][j] < 0)
                    pas[i][j] = 1000000000000000000;
                //cout << pas[i][j];
            }
    }
    long long n, m;
    cin >> n >> m;
    long long last = 20000;
    for (long long i = m - 1; i >= 0; i--)
    {
        long long l = i, r = last;
        while(r - l > 1)
        {
            long long mi = (r + l) / 2;
            //cout << mi << " " <<  f(m, i, mi) << endl;
            if (pas[mi][i + 1] <= n)
            {
                l = mi;
            }
            else
            {
                r = mi;
            }
        }
        n -= pas[l][i + 1];
        cout << l << " ";
        last = l;
    }
}
