#include <string>
#include <cstring>
#include <iostream>
#include <fstream>
#include <deque>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <ctype.h>
#include <ctime>
#include <assert.h>

#define _USE_MATH_DEFINES
#include <math.h>

#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define LL long long
#define mp make_pair
#define sqr(x) x*x

using namespace std;

void smain();

int main() {
#ifdef _DEBUG
	freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
#endif
	
	smain();

	return 0;
}

#define int long long
#define N 2000
#define NMAX 1e17
#define MOD ((1LL << 61) - 1)//1000000007

int C[N][N];

int mulmod(int a, int n){
	int res = 0;
	for(; n; n >>= 1, a = (a + a) % MOD) if(n & 1) res = (res + a) % MOD;
	return res;
}

int powmod(int a, int n) {
	int res = 1;
	for(; n; n >>= 1, a = mulmod(a, a)) if(n & 1) res = mulmod(res, a);
	return res;
}

int powmod1(int a, int n) {
	int res = 1;
	for(; n; n >>= 1, a = a * a % MOD) if(n & 1) res = res * a % MOD;
	return res;
}

int rec(int n, int k){
	if(k == 0) return 1;
	//int res = (n - k) * powmod1(k + 1, MOD - 2) % MOD;
	//return res * rec(n, k - 1) % MOD;
	int res = mulmod(n - k, powmod(k + 1, MOD - 2));
	return mulmod(res, rec(n, k - 1));
}

double get_c(int n, int k){
	if(k > n) return 0;
	if(k == 0) return 1;
	if(k == 1) return n;
	if(k == 2) {
		if(n > 1000000000) return NMAX;
		return n * (n - 1) / 2;
	}
	if(k == 3) {
		if(n > 1000000) return NMAX;
		return n * (n - 1) * (n - 2) / 6;
	}
	if(n < N && k < N) return C[n][k];
	if(k < 10) {
		double p = 1, q = 1;
		forn(i, k) p *= n - i, q *= i + 1;
		double res = p / q;
		return res;
	}
	return NMAX + 1;
}

int get_ic(int n, int k){
	if(k > n) return 0;
	if(k == 0) return 1;
	if(k == 1) return n;
	if(k == 2) {
		if(n > 1000000000) return NMAX;
		return n * (n - 1) / 2;
	}
	if(k == 3) {
		if(n > 1000000) return NMAX;
		return n * (n - 1) * (n - 2) / 6;
	}
	if(n < N && k < N) return C[n][k];
	if(k < 20) {
		return rec(n, k);
	}
	return NMAX + 1;
}


int f(int n, int m, vector<int> &st) {
	if(m == 0) return n == 0 ? 0 : -1;
	int l = m, r = 20000000000LL;
	while(l < r) {
		int mid = (l + r) / 2;
		double cc = get_c(mid, m);
		if(cc > n) r = mid;
		else l = mid + 1;
	}
	
	if(get_c(l, m) > n) l -= 1;
	for(; l >= max(m - 1, 0LL); --l) {
		int cc = get_ic(l, m);
		int r = f(n - cc, m - 1, st);
		if(r >= 0){
			st.push_back(r);
			return l;
		}
	}
	return -1;
}

int calc(int m, vector<int> &r) {
	int res = 0;
	for(int i = m, j = 0; i > 0; --i, ++j){
		res += get_ic(r[j], i);
	}
	return res;
}


void smain() {

	forn(i, N) C[i][0] = 1;
	for(int i=1; i < N; ++i) for(int j=1; j < N; ++j){
		C[i][j] = C[i-1][j-1] + C[i-1][j];
		if(C[i][j] < 0) C[i][j] = NMAX;
	}
	
	int n, m;
	vector<int> st(0);


	for(; cin >> n >> m; ){
		if(!st.empty()) st.clear();
		int r = f(n, m, st);
		st.push_back(r);
		reverse(st.begin(), st.end());
		st.resize(st.size() - 1);
		for(auto i : st) cout << i << ' ';
		cout << endl;
	}
}