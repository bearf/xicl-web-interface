#include <iostream>
#include <algorithm>
#include <fstream>

using namespace std;

long long minimum(long long a, long long b)
{
    if (a < b)
        return a;
    return b;
}

int main()
{
    //ifstream cin("input.txt");
    long long a[100000];
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) {
        long long h, m, s;
        cin >> h >> m >> s;
        a[i] = h * 1000000000000 + m * 1000000 + s;
    }
    sort(a, a + n);
    long long c[100000] = {0};
    for (int i = 0; i < n; i++) {
        if (a[i] != a[0]) {
            c[0] += a[0] + 12000000000000 - a[i];
            //cout << c[0] << endl;
        }
    }
    long long m = c[0];
    for (int i = 1; i < n; i++) {
        if (a[i] == a[i - 1]) {
            c[i] = c[i - 1];
            continue;
        }
        c[i] = c[i - 1];
        long long r = a[i - 1] + 12000000000000 - a[i];
        c[i] -= r;
        c[i] += (n - 1) * (a[i] - a[i - 1]);
        int j = i + 1;
        while (j < n && a[j] == a[i]) {
            c[i] -= 12000000000000;
            j++;
        }
        if (c[i] < m) {
            m = c[i];
        }
    }
//    cout << c[0] << endl << c[1] << endl << c[2] << endl;
    cout << (m / 1000000000000) << " " << (m / 1000000 % 1000000) << " " << (m % 1000000);
    return 0;
}
