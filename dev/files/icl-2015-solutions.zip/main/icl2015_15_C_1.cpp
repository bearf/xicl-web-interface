#include <iostream>
#include <fstream>

using namespace std;

long long minimum(long long a, long long b)
{
    if (a < b)
        return a;
    return b;
}

int main()
{

    int n,k;
    cin>>n>>k;
    if (n-k==2)
    {
        if (n==4)
            cout<<2;
        else
            cout<<n;
    }
    else
       if (k==0)
        cout<<1;
       else
        cout<<0;




    return 0;
    }