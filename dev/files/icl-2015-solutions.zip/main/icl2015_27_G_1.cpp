#define _USE_MATH_DEFINES
#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define sz(x) ((int)x.size())
#define fi first
#define se second
#define re return
#define y0 y248590
#define y1 y5427895
#define j0 j5234895
#define j1 j438759
#define prev prev348957
#define next next457834
#define sqrt(x) sqrt(abs(x))

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef pair<ll, ll> pll;
typedef vector<string> vs;
typedef long double ld;
typedef double D;

template<class T> T gcd (T a, T b) { re a ? gcd (b % a, a) : b; }
template<class T> inline T abs (T a) { re a < 0 ? -a : a; }
template<class T> inline T sqr (T a) { re ((a) * (a)); }

const ll DAY = (ll)12 * 1000000 * 1000000;

int n;
int m;
vector<ll> v;

int main () {
	scanf ("%d", &n);
	for (int i = 0; i < n; i++) {
		int a, b, c;
		scanf ("%d%d%d", &a, &b, &c);
		v.pb (((ll)a * 1000000 + b) * 1000000 + c);
	}
	sort (all (v));
	ll sum = 0;
	for (int i = 0; i < sz (v); i++)
		sum += DAY - v[i];
	ll ans = sum;
	for (int i = 0; i < sz (v); i++) {
		ll last = 0;
		if (i > 0) last = v[i - 1];
		sum += (v[i] - last) * n;
		sum -= DAY;
		ans = min (ans, sum);
	}
	cout << ans / 1000000000000LL << " " << ans / 1000000 % 1000000 << " " << ans % 1000000 << endl;
	re 0;
}
