#include <iostream>
#include <algorithm>
#define fin cin
#define fout cout

using namespace std;

//ifstream fin("input.txt");
//ofstream fout("output.txt");

typedef long long ll;

const ll TMAX = 12e12;
const ll H = 1e12;
const ll M = 1e6;

const int nmax = 110000;

ll h[nmax], m[nmax], s[nmax], t[nmax], d[nmax];
int n;


void read()
{
    fin >> n;
    for (int i = 0; i < n; i++)
    {
        fin >> h[i] >> m[i] >> s[i];
        t[i] = h[i] * H + m[i] * M + s[i];
    }
}


void solve()
{
    sort(t, t + n);
    for (int i = 1; i < n; i++)
        d[i] = t[i] - t[i - 1];
    d[0] = t[0] - t[n - 1] + TMAX;
    ll sum_izn = 0;
    for (int i = 0; i < n; i++)
        sum_izn += i * d[i];
    //fout << sum_izn << endl;
    ll ans = sum_izn;
    for (int i = n - 1; i >= 0; i--)
    {
        sum_izn += TMAX - n * d[i];
        //fout << "s " << sum_izn << endl;
        ans = min(ans, sum_izn);
    }
    //fout << ans << endl;
    //fout << H << ' ' << M << endl;
    ll h = ans / H;
    ans -= h * H;
    ll m = ans / M;
    ans -= m * M;
    fout << h << ' ' << m << ' ' << ans << endl;
}


int main()
{
    read();
    solve();
    return 0;
}
