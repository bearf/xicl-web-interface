#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const long long MX = 1000000LL;

int main() {
	//freopen("task.in", "r", stdin);

	int n;
	while (scanf("%d", &n) == 1) {
		vector<int> a(n), b(n), c(n);
		vector<long long> v;
		for (int i = 0; i < n; i++) {
			scanf("%d%d%d", &a[i], &b[i], &c[i]);
			long long cur = 0;
			cur += c[i];
			cur += b[i] * MX;
			cur += a[i] * MX * MX;
			v.push_back(cur);
		}
		sort(v.begin(), v.end());

		long long ans = 4e18;
		long long cur = 0;
		cur += 1LL * (n - 1) * v[0];
		for (int i = 1; i < n; i++) {
			cur += 12LL * MX * MX - v[i];
		}
		ans = min(ans, cur);
		for (int i = 1; i < n; i++) {
			cur += (n - 1) * 1LL * (v[i] - v[i - 1]);
			cur -= 12LL * MX * MX - v[i] + v[i - 1];
			ans = min(ans, cur);
		}
		int h = ans / (MX * MX);
		int m = ans / MX % MX;
		int s = ans % MX;
		printf("%d %d %d\n", h, m, s);
	}

	return 0;
}