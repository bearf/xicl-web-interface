#include <iostream>

using namespace std;

long long minimum(long long a, long long b)
{
    if (a < b)
        return a;
    return b;
}

int main()
{
    int n;
    cin >> n;
    int m = -1;
    int mi = -1;
    long long p[100000];
    for (int i = 0; i < n; i++) {
        cin >> p[i];
        if (p[i] > m) {
            m = p[i];
            mi = i;
        }
    }
    long long z1 = 0;
    for (int i = 0; i < n; i++) {
        if (p[i] == m) {
            z1 += p[i];
        }
    }
    long long z2 = 1000006;
    for (int i = 0; i < n; i++) {
        if (p[i] == m) {
            if ((i > 0 && p[i - 1] > 0) || (i < n - 1 && p[i + 1] > 0)) {
                z2 = m + 1;
                break;
            }
        }
    }
    for (int i = 0; i < n; i++) {
        if (p[i] == m) {
            if (i > 0) {
                if ((p[i - 1] + 1 < p[i] - 1) && (i == n - 1 || p[i + 1] + 1 < p[i])) {
                    p[i]--;
                    p[i - 1]++;
                    break;
                }
            }
            if (i < n - 1) {
                if ((p[i + 1] + 1 < p[i] - 1) && (i == 0 || p[i - 1] + 1 < p[i])) {
                    p[i]--;
                    p[i + 1]++;
                    break;
                }
            }
        }
    }
    m = -1;
    for (int i = 0; i < n; i++) {
        if (p[i] > m) {
            m = p[i];
        }
    }
    long long z3 = 0;
    for (int i = 0; i < n; i++) {
        if (p[i] == m) {
            z3 += p[i];
        }
    }
    cout << minimum(z1, minimum(z2, z3));
    return 0;
}
