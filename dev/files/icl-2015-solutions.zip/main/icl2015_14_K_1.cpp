#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

int main()
{
#ifdef LOCAL
    freopen("k.in", "r", stdin);
#endif // LOCAL
    int n, m, q;
    cin >> n >> m >> q;
    int lb = 1, rb = n + 1;
    while (lb + 1 < rb)
    {
        int c = (lb + rb) / 2;
        if (m - (c - 1) / 2 >= 0)
            lb = c;
        else
            rb = c;
    }
    int c = lb;
    for (int i = 0; i < q; ++i)
    {
        int k;
        cin >> k;
        k = n - k + 1;
        int ans;
        if (k == c)
            ans = m - (c - 1) / 2;
        else if (k > c)
            ans = -1;
        else if ((k + c) % 2 == 0)
            ans = 1;
        else
            ans = 0;
        cout << ans << ' ' << ans << '\n';
    }
    return 0;
}
