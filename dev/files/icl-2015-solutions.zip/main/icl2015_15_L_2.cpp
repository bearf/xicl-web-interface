#include <iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;
    int m = -1;
    int mi = -1;
    int p[100000];
    for (int i = 0; i < n; i++) {
        cin >> p[i];
        if (p[i] > m) {
            m = p[i];
            mi = i;
        }
    }
    for (int i = 0; i < n; i++) {
        if (p[i] == m) {
            if (i > 0) {
                if ((p[i - 1] + 1 < p[i] - 1) && (i == n - 1 || p[i + 1] + 1 < p[i])) {
                    p[i]--;
                    p[i - 1]++;
                    break;
                }
            }
            if (i < n - 1) {
                if ((p[i + 1] + 1 < p[i] - 1) && (i == 0 || p[i - 1] + 1 < p[i])) {
                    p[i]--;
                    p[i + 1]++;
                    break;
                }
            }
        }
    }
    m = -1;
    for (int i = 0; i < n; i++) {
        if (p[i] > m) {
            m = p[i];
        }
    }
    int z = 0;
    for (int i = 0; i < n; i++) {
        if (p[i] == m) {
            z += p[i];
        }
    }
    cout << z;
    return 0;
}
